import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'backend.dart';
import 'store.dart';
import 'theme.dart';

/// "MERA AGENT HISA" (v1.4.6 — Agent System, AGENT-SYSTEM-SPEC §2)
///
/// Profile (DONO modes — passenger Profile tab aur driver Profile)
/// mein lagne wala hisa. Logged-in mobile (passenger = apna mobile
/// login, driver = driver record ka mobile) backend `agents`
/// table mein kisi ACTIVE agent se match kare to hi ye card
/// khulta hai — match na ho to hisa BILKUL nazar nahi ata
/// (SizedBox.shrink). Agent sirf Master se banta hai; yahan koi
/// agent NAHI banta.
///
/// Card mein sirf ye hai (spec ki sakht had — is se zyada NAHI):
///  (a) Agent ki apni profile: photo lagana/badlana + naam/sheher.
///  (b) Us ke drivers ki list: sirf naam, gaari, active/tasdeeq
///      status, kul (mukammal) rides, kul fee RECORD.
///  (c) Apna kul hisaab (RECORD ONLY): kul drivers, kul rides,
///      kul fare, kul fee — aur neeche wazeh line ke commission
///      ka faisla abhi nahi hua, ye sirf record hai. Koi percent,
///      koi "agent ki kamai" wali raqam NAHI dikhti.
class AgentSection extends StatefulWidget {
  final AppStore store;
  const AgentSection({super.key, required this.store});

  @override
  State<AgentSection> createState() => _AgentSectionState();
}

class _AgentSectionState extends State<AgentSection> {
  final ImagePicker _picker = ImagePicker();
  bool _loading = true;
  bool _photoBusy = false;
  AgentInfo? _agent;
  List<AgentDriverTally> _drivers = const [];
  String _localPhoto = '';

  AppStore get store => widget.store;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    // Dono pehchanen check hoti hain (same-device par aksar ek
    // hi number driver bhi hota hai aur passenger bhi).
    AgentInfo? found;
    for (final m in {store.passengerPhone, store.profile.phone}) {
      if (m.trim().isEmpty) continue;
      found = await AgentApi.fetchAgentForMobile(m);
      if (found != null) break;
    }
    if (!mounted) return;
    if (found == null) {
      setState(() {
        _agent = null;
        _loading = false;
      });
      return;
    }
    final drivers = await AgentApi.fetchAgentDrivers(found.code);
    String local = '';
    try {
      final prefs = await SharedPreferences.getInstance();
      local = prefs.getString('agent_photo_local_${found.code}') ?? '';
      if (local.isNotEmpty && !await File(local).exists()) local = '';
    } catch (_) {
      local = '';
    }
    if (!mounted) return;
    setState(() {
      _agent = found;
      _drivers = drivers;
      _localPhoto = local;
      _loading = false;
    });
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  /// Apni profile photo lagana/badlana: pehle source (camera /
  /// gallery), phir upload (driver-docs: agents/<code>/profile
  /// .jpg) — kamyabi par is phone par LOCAL file hi dikhti hai
  /// (bucket v132 se private hai; Master signed URL se dekhta
  /// hai).
  Future<void> _changePhoto() async {
    final agent = _agent;
    if (agent == null || _photoBusy) return;
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('Camera se photo lein'),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Gallery se photo chunein'),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (src == null || !mounted) return;
    XFile? img;
    try {
      img = await _picker.pickImage(source: src, imageQuality: 85);
    } catch (_) {
      _snack('Photo nahi li ja saki — dobara koshish karein.');
      return;
    }
    if (img == null) {
      _snack('Photo nahi li gayi — camera/gallery band ho gaya.');
      return;
    }
    setState(() => _photoBusy = true);
    final path = await AgentApi.uploadAgentPhoto(agent, File(img.path));
    if (!mounted) return;
    setState(() => _photoBusy = false);
    if (path == null) {
      _snack('Photo upload nahi ho saki — internet check karke dobara koshish karein.');
      return;
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('agent_photo_local_${agent.code}', img.path);
    } catch (_) {
      // Local nishan na lage to bhi upload ho chuka hai.
    }
    if (!mounted) return;
    setState(() => _localPhoto = img!.path);
    _snack('Profile photo lag gayi hai.');
  }

  static String _docLabel(String s) => switch (s) {
        'verified' => 'Ho gayi',
        'rejected' => 'Reject',
        _ => 'Baqi',
      };

  @override
  Widget build(BuildContext context) {
    // Load ho raha ho ya is mobile ka koi agent hi na ho — hisa
    // bilkul nazar nahi ata (spec: match na ho to ghayab).
    if (_loading || _agent == null) return const SizedBox.shrink();
    final a = _agent!;
    final totalRides = _drivers.fold<int>(0, (s, d) => s + d.rides);
    final totalFare = _drivers.fold<int>(0, (s, d) => s + d.fare);
    final totalFee = _drivers.fold<int>(0, (s, d) => s + d.fee);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.badge, color: Brand.green),
                SizedBox(width: 9),
                Text('Mera Agent Hisa',
                    style:
                        TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
              ],
            ),
            const SizedBox(height: 12),
            // (a) Agent ki apni profile
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Brand.green,
                  backgroundImage:
                      _localPhoto.isNotEmpty ? FileImage(File(_localPhoto)) : null,
                  child: _localPhoto.isNotEmpty
                      ? null
                      : Text(
                          a.name.isNotEmpty ? a.name[0].toUpperCase() : '?',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.bold),
                        ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(a.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 15.5)),
                      Text(
                        '${a.city.isEmpty ? '—' : a.city} · Code ${a.code}',
                        style: const TextStyle(
                            color: Colors.black54, fontSize: 12.5),
                      ),
                      const SizedBox(height: 2),
                      const Text('Agent (Master se bana hua)',
                          style: TextStyle(
                              color: Brand.green,
                              fontSize: 12,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                icon: _photoBusy
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.photo_camera, size: 18),
                label: Text(_localPhoto.isEmpty && a.photoPath.isEmpty
                    ? 'Apni Profile Photo Lagayein'
                    : 'Profile Photo Badlein'),
                onPressed: _photoBusy ? null : _changePhoto,
              ),
            ),
            const Divider(height: 22),
            // (c) Kul hisaab — RECORD ONLY
            const Text('Mera Kul Hisaab (Record)',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
            const SizedBox(height: 8),
            Row(
              children: [
                _stat('Drivers', '${_drivers.length}'),
                _stat('Rides', '$totalRides'),
                _stat('Kul Kiraya', rs(totalFare)),
                _stat('Kul Fee Record', rs(totalFee)),
              ],
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: Brand.lightBg,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Brand.fieldBorder),
              ),
              child: const Text(
                'Commission ka faisla abhi nahi hua — ye sirf record hai.',
                style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
              ),
            ),
            // (b) Us ke drivers ki list
            if (_drivers.isNotEmpty) ...[
              const Divider(height: 22),
              const Text('Mere Drivers',
                  style:
                      TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
              const SizedBox(height: 6),
              for (final d in _drivers) _driverRow(d),
            ] else ...[
              const SizedBox(height: 10),
              const Text(
                'Abhi aap ke code se koi driver register nahi hua. Driver registration mein aap ka code likhe to woh yahan nazar ayega.',
                style: TextStyle(fontSize: 12.5, color: Colors.black54),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value,
              style:
                  const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
          Text(label,
              style: const TextStyle(color: Colors.black54, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _driverRow(AgentDriverTally d) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(d.active ? Icons.check_circle : Icons.pending_actions,
              size: 19, color: d.active ? Brand.green : Brand.gold),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  d.name.isEmpty ? 'Naam darj nahi' : d.name,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 13.5),
                ),
                Text(
                  [
                    if (d.vehicle.isNotEmpty) d.vehicle,
                    if (d.plate.isNotEmpty) d.plate,
                  ].join(' · '),
                  style:
                      const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                Text(
                  d.active
                      ? 'ID Active hai'
                      : 'Tasdeeq: CNIC ${_docLabel(d.cnicStatus)} · Gaari ${_docLabel(d.gaariStatus)} · Licence ${_docLabel(d.licenceStatus)}',
                  style:
                      const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                Text(
                  'Rides: ${d.rides} · Fee record: ${rs(d.fee)}',
                  style: const TextStyle(fontSize: 12.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
