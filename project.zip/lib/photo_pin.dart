import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'backend.dart';
import 'theme.dart';

/// v1.4.32 PHOTO-PIN (malik ka hukm 2026-11-11): ride ke doran
/// doosre fareeq ki asal profile photo map par us ki jagah par
/// gol pin ki shakal mein nazar aye — passenger ko driver ki
/// photo us ki live jagah par, driver ko sawari ki photo pickup
/// par. Master app ke naqsha.dart wali hi PROVEN tarkeeb
/// (dart:ui se pin banana) yahan port ki gayi hai.
///
/// Photo signed URL se ati hai (Backend.fetchSignedPhotoUrl —
/// sign-doc-url ka JWT rasta shared ride par doosre fareeq ki
/// SIRF profile photo sign karta hai). Photo na mile to pin
/// naam ke pehle harf ke saath banta hai — khaali pin kabhi
/// NAHI. Bana hua pin session ke liye cache rehta hai — har
/// poll par dobara download/compose NAHI hota.
class PhotoPin {
  static final Map<String, Uint8List> _cache = {};
  static final Map<String, Future<Uint8List?>> _inflight = {};

  /// bucket+path se tayyar pin PNG. Path khaali ho to seedha
  /// harf wala pin. Nakami par null (map purani shakal mein
  /// chalta rehta hai — pin sirf izafa hai, rukawat NAHI)।
  static Future<Uint8List?> load({
    required String bucket,
    required String path,
    required String name,
  }) {
    final key = '$bucket|$path|${name.trim()}';
    final hit = _cache[key];
    if (hit != null) return Future<Uint8List?>.value(hit);
    final flying = _inflight[key];
    if (flying != null) return flying;
    final f = _loadReal(bucket, path, name, key);
    _inflight[key] = f;
    return f;
  }

  static Future<Uint8List?> _loadReal(
      String bucket, String path, String name, String key) async {
    try {
      Uint8List? photoBytes;
      if (path.isNotEmpty) {
        final url = await Backend.fetchSignedPhotoUrl(bucket, path);
        if (url != null && url.isNotEmpty) {
          photoBytes = await _download(url);
        }
      }
      final png = await composePin(
        letter: name.trim().isEmpty ? '?' : name.trim()[0].toUpperCase(),
        photoBytes: photoBytes,
      );
      _cache[key] = png;
      return png;
    } catch (_) {
      return null;
    } finally {
      _inflight.remove(key);
    }
  }

  static Future<Uint8List?> _download(String url) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = const Duration(seconds: 20);
      final req = await client
          .getUrl(Uri.parse(url))
          .timeout(const Duration(seconds: 20));
      final resp = await req.close().timeout(const Duration(seconds: 20));
      if (resp.statusCode < 200 || resp.statusCode >= 300) return null;
      final chunks = <int>[];
      await for (final d in resp) {
        chunks.addAll(d);
      }
      if (chunks.isEmpty) return null;
      return Uint8List.fromList(chunks);
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  /// Gol photo-pin — Master ke _composePin ki hu-bahu tarkeeb
  /// (96x106 logical @2x = 192x212 px, map par iconSize 0.5):
  /// brand sabz ring + nok, safed kinara, andar photo (warna
  /// gehra sabz daira + safed harf)।
  static Future<Uint8List> composePin({
    required String letter,
    Uint8List? photoBytes,
  }) async {
    const ring = Brand.green;
    const fill = Brand.deepGreen;
    const double w = 96, h = 106, dpr = 2.0;
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    canvas.scale(dpr);
    // Nok (neeche wala teer) — ring ke rang mein.
    final tail = Path()
      ..moveTo(w / 2 - 13, 66)
      ..lineTo(w / 2 + 13, 66)
      ..lineTo(w / 2, h - 4)
      ..close();
    canvas.drawPath(tail, Paint()..color = ring);
    const center = Offset(w / 2, 40);
    // Bahari ring
    canvas.drawCircle(center, 30, Paint()..color = ring);
    // Safed kinara
    canvas.drawCircle(center, 26.5, Paint()..color = Colors.white);
    // Andar ka daira (photo ya rang + harf)
    final inner = Rect.fromCircle(center: center, radius: 23.5);
    canvas.save();
    canvas.clipPath(Path()..addOval(inner));
    var drawn = false;
    if (photoBytes != null) {
      try {
        final codec = await ui.instantiateImageCodec(photoBytes,
            targetWidth: 128, targetHeight: 128);
        final frame = await codec.getNextFrame();
        final img = frame.image;
        // Darmiyan ka hissa crop (chehra aam tor par upar hota hai)
        final cropH = img.height * 0.82;
        final srcCrop = Rect.fromLTWH(0, 0, img.width.toDouble(), cropH);
        canvas.drawImageRect(img, srcCrop, inner, Paint());
        img.dispose();
        drawn = true;
      } catch (_) {
        drawn = false;
      }
    }
    if (!drawn) {
      canvas.drawRect(inner, Paint()..color = fill);
      _drawLetter(canvas, center, letter);
    }
    canvas.restore();
    final pic = recorder.endRecording();
    final image = await pic.toImage((w * dpr).round(), (h * dpr).round());
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    return data!.buffer.asUint8List();
  }

  static void _drawLetter(Canvas canvas, Offset center, String letter) {
    final tp = TextPainter(
      text: TextSpan(
        text: letter,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 25,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
  }
}
