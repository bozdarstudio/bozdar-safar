# White Filter - no custom ProGuard rules needed (release build is not minified).
