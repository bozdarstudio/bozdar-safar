import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Fare rules — INTERNAL only. Per-km rates are never shown to passengers;
/// the passenger only ever sees the TOTAL fare.
///
/// Neeche wali default values wohi hain jo hamesha se theen. v1.1.0 se
/// ye values runtime par SIRF Master (backend settings) se refresh ho
/// sakti hain — [applyServerSettings] sirf backend sync bulata hai.
/// Is app ke andar in ka koi editor NAHI hai aur passenger ko ye kabhi
/// nazar nahi aateen; hisaab ke usool (formulas) bilkul waisay hi hain.
class Fares {
  static Map<String, int> perKm = {
    'Rickshaw': 50,
    'Bike': 30,
    'Car': 70,
    'Taxi': 80,
    'Van': 95,
  };
  static Map<String, int> waitingPerMin = {
    'Rickshaw': 5,
    'Bike': 4,
    'Car': 10,
    'Taxi': 12,
    'Van': 15,
  };
  static int freeWaitingMinutes = 5;
  static int joiningDeposit = 500;

  /// PILOT MODE (malik ka faisla 2026-11-08): company banne tak
  /// joining deposit BAND hai. Default false (pilot) — backend
  /// settings mein `deposit_enabled` column (migration v131) aa
  /// jaye to Master wahan se isay on/off karega aur wohi value
  /// yahan server se lag jayegi. Deposit band hone ka matlab:
  ///  - deposit kisi gate (registration / ID Active / ride accept)
  ///    par NAHI rokta;
  ///  - 10% service fee phir bhi har mukammal ride par HISaab mein
  ///    likhi jati hai (DriverProfile.feeDue) — wallet se NAHI
  ///    kat-ti, kyunke wallet mein driver ka paisa jama hi nahi
  ///    hua; driver woh hisaab haftawar Master ko bhejta hai
  ///    (record-based settlement, koi gateway nahi).
  static bool depositEnabled = false;

  /// FEE SETTLE LIMIT (malik ka faisla 2026-11-08): driver ke
  /// zimme baqi service fee (feeDue) is had se upar jaye to woh
  /// ONLINE nahi ho sakta aur nayi ride qubool nahi kar sakta —
  /// pehle hisaab saaf karna hoga (Raast 0312 2635002 par bhej
  /// kar payment darj karein; Master tasdeeq kare to block khud
  /// khul jata hai). Default Rs 1000; Master backend settings
  /// (fee_settle_limit, migration v131) se badal sakta hai.
  static int feeSettleLimit = 1000;

  /// PTA TOGGLE (malik ka faisla 2026-11-08 ~15:38): PTA Proof
  /// (IMEI) ki machinery code mein rehti hai, lekin PTA tasdeeq
  /// ID ki LAZMI shart SIRF tab hai jab malik Master Settings se
  /// "PTA Proof lazmi" ON kare. Default FALSE (band) hai —
  /// backend settings mein `pta_required` column (migration
  /// v133) aa jaye to Master wahan se on/off karega aur wohi
  /// value yahan server se lag jayegi. Band hone ka matlab:
  ///  - wizard mein IMEI IKHTIYARI hai — registration ki
  ///    mukammal hone ki shart ([DriverProfile.registrationComplete])
  ///    mein IMEI nahi ginta; likha jaye to 15 digits + Luhn
  ///    durust hona phir bhi lazmi hai (typo yahin pakra jata hai);
  ///  - Master bhi baghair PTA tasdeeq ke ID Active kar sakta
  ///    hai (pta_status dossier/Tasdeeq mein waisa hi rehta hai).
  static bool ptaRequired = false;

  /// Service charges % — SIRF internal hissaab. Ye fee sirf Master app
  /// mein set hoti hai aur backend settings se is app tak puhanchti hai —
  /// passenger ko kabhi nazar nahi aati aur is app mein kahin se badli
  /// bhi nahi ja sakti. Driver ke apne wallet hisaab mein katauti
  /// "Service charges" ke tor par sirf usi ko dikhti hai.
  /// Default 10.0 (malik ka hukm 2026-11-08 ~15:01: fee ab 10% hai) —
  /// backend settings row bhi 10 par set + verify ho chuki hai,
  /// taaki sync ke baad bhi yehi rahe.
  static double feePercent = 10.0;

  /// Backend settings (Master) se values lagana — sirf wohi fields
  /// badalte hain jo server ne bheje hon aur durust hon. Formulas ko
  /// haath nahi lagta.
  static void applyServerSettings({
    double? feePercent,
    Map<String, int>? rates,
    Map<String, int>? waiting,
    int? freeWaitingMin,
    int? deposit,
    bool? depositEnabled,
    int? feeSettleLimit,
    bool? ptaRequired,
  }) {
    if (feePercent != null && feePercent > 0) {
      Fares.feePercent = feePercent;
    }
    if (rates != null) {
      for (final v in kVehicles) {
        final r = rates[v];
        if (r != null && r > 0) perKm[v] = r;
      }
    }
    if (waiting != null) {
      for (final v in kVehicles) {
        final w = waiting[v];
        if (w != null && w > 0) waitingPerMin[v] = w;
      }
    }
    if (freeWaitingMin != null && freeWaitingMin >= 0) {
      freeWaitingMinutes = freeWaitingMin;
    }
    if (deposit != null && deposit >= 0) {
      joiningDeposit = deposit;
    }
    // Sirf tab jab server ne asal value bheji ho (column maujood
    // ho) — warna pilot default (false) hi rehta hai.
    if (depositEnabled != null) {
      Fares.depositEnabled = depositEnabled;
    }
    if (feeSettleLimit != null && feeSettleLimit >= 0) {
      Fares.feeSettleLimit = feeSettleLimit;
    }
    // Sirf tab jab server ne asal value bheji ho (column maujood
    // ho) — warna default (false = PTA ikhtiyari) hi rehta hai.
    if (ptaRequired != null) {
      Fares.ptaRequired = ptaRequired;
    }
  }

  static int fareFor(String vehicle, double km) =>
      ((perKm[vehicle] ?? 50) * km).round();

  /// Waiting charge: first [freeWaitingMinutes] minutes free, then per-minute.
  static int waitingCharge(String vehicle, int elapsedMinutes) {
    final billable = elapsedMinutes - freeWaitingMinutes;
    if (billable <= 0) return 0;
    return billable * (waitingPerMin[vehicle] ?? 5);
  }

  static int monthlyAmount(String vehicle, double routeKm, int days) =>
      ((perKm[vehicle] ?? 50) * routeKm * days).round();

  static int serviceFee(int farePlusWaiting) =>
      (farePlusWaiting * feePercent / 100).round();
}

const List<String> kVehicles = ['Rickshaw', 'Bike', 'Car', 'Taxi', 'Van'];

/// Driver ko sirf itne km ke andar maujood pickups wali rides milti
/// hain — is se door ki sawari us driver ko dikhti hi nahi (booking
/// kahin aur khatm nahi hoti; doosra qareeb driver use le sakta hai).
/// INTERNAL: ye koi setting nahi hai — app mein kahin is ka editor ya
/// display nahi hai; sirf driver-facing maloomati jumlon mein "2 km ke
/// andar ki rides" ke tor par lafz aa sakta hai.
const double kDriverPickupRadiusKm = 2.0;

/// Is build ka version (pubspec ki versionName se milta julta rakhein).
const String kAppVersion = '1.4.16';

/// Is build ka version CODE (pubspec ka +NN hissa) — UPDATE GATE
/// (v1.4.8, malik ke rules 2026-11-09 00:12–00:15) isi number ka
/// Master ki settings (min_mandatory_version /
/// min_recommended_version) se muqabla karta hai, aur driver ke
/// duty-on par yehi code backend drivers.app_version mein report
/// hota hai taake Master ko pata ho kaun sa driver purani app par
/// hai.
const int kAppVersionCode = 39;

// ---------------------------------------------------------------------------
// Driver password (v1.2.5 — malik ka hukm)
//
// Har driver apna password KHUD lagata hai, aur ek password sirf EK hi
// driver ka ho sakta hai. Asal password kabhi save ya send NAHI hota —
// sirf us ka FINGERPRINT (neeche wala hash) phone par aur backend
// `drivers.pwd_fp` mein rehta hai. Fingerprint jaan boojh kar driver
// se WABASTA NAHI hai: wohi password = wohi fingerprint, har phone
// par — isi liye backend se pooch kar pata chal jata hai ke ye
// password pehle se kisi AUR driver ke paas to nahi. Pepper app ke
// code ki mustaqil value hai (secret nahi — maqsad sirf ye hai ke
// aam rainbow-table se fingerprint wapas password na ban jaye).
// ---------------------------------------------------------------------------

const String _kPwdPepper = 'safar-driver-pwd::v1::bozdar-safar';

/// Password ka deterministic fingerprint: (password + pepper) par
/// SHA-256 ke 10,000 rounds. Wohi password hamesha wohi fingerprint
/// deta hai — uniqueness check isi par chalta hai.
String passwordFingerprint(String password) {
  List<int> bytes = utf8.encode('$password|$_kPwdPepper');
  for (var i = 0; i < 10000; i++) {
    bytes = sha256.convert(bytes).bytes;
  }
  return bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
}

/// Nayi update hamesha isi link se milti hai — release asset ka naam
/// kabhi nahi badalta, sirf us ke andar ki file nayi ho jati hai.
const String kUpdateDownloadUrl =
    'https://github.com/bozdarstudio/bozdar-safar/releases/download/v1.0.0/BozdarSafar-v1.0.0.apk';

// ---------------------------------------------------------------------------
// UPDATE GATE (v1.4.8 — malik ke rules 2026-11-09 00:12–00:15)
//
// Master backend settings (settings row id=1 ke columns, migration
// v138) se do haddien (version CODES) aur update ka link ata hai:
//   minMandatoryVersion   — is se neeche wali app BILKUL band:
//                           app khulte hi update wali screen, koi
//                           rasta aage nahi (malik: "update karega
//                           to aage chalayega, warna app aage nahi
//                           khulegi").
//   minRecommendedVersion — is se neeche (lekin mandatory se upar)
//                           wali app chalti rehti hai, lekin har
//                           waqt banner + roz ek notification:
//                           "Bhai, app update karein — tabhi aap
//                           ko achi wali rides milengi" (malik ki
//                           naram sakhti — rides ki asal katauti
//                           backend dispatch ka kaam hai, ye gate
//                           sirf zor deta hai).
//   updateUrl             — Update button seedha yahi link kholta
//                           hai (default = permanent public link).
// Values [Fares] ki tarah STATIC hain — Backend._applySettings in
// ko lagata hai (cached settings se bhi, taake offline par bhi
// akhri maloom haddien chalti rahen). Haddien 0 hon to koi gate
// nahi (default — v138 migration se pehle bhi app bilkul aam
// chalti hai).
// ---------------------------------------------------------------------------
class UpdatePolicy {
  static int minMandatoryVersion = 0;
  static int minRecommendedVersion = 0;
  static String updateUrl = kUpdateDownloadUrl;

  /// 0 = koi gate nahi · 1 = recommended (banner + roz notification)
  /// · 2 = mandatory (blocking screen, aage koi rasta nahi).
  static int get level {
    if (minMandatoryVersion > 0 && kAppVersionCode < minMandatoryVersion) {
      return 2;
    }
    if (minRecommendedVersion > 0 &&
        kAppVersionCode < minRecommendedVersion) {
      return 1;
    }
    return 0;
  }

  /// Backend settings se values lagana — sirf durust values lagti
  /// hain; ghalat/na-mauood par purani (ya default) hi rehti hai.
  static void apply({int? mandatory, int? recommended, String? url}) {
    if (mandatory != null && mandatory >= 0) {
      minMandatoryVersion = mandatory;
    }
    if (recommended != null && recommended >= 0) {
      minRecommendedVersion = recommended;
    }
    if (url != null && url.trim().startsWith('http')) {
      updateUrl = url.trim();
    }
  }
}

/// Percent saaf likhna: 5 -> "5%", 7.5 -> "7.5%", 7.25 -> "7.25%".
String fmtPct(double p) {
  var s = p.toStringAsFixed(2);
  if (s.contains('.')) {
    s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }
  return '$s%';
}

/// "1.0.4" > "1.0.3" type muqabla — har hisa number ke tor par.
bool versionIsNewer(String remote, String local) {
  List<int> parts(String v) =>
      v.split('.').map((e) => int.tryParse(e) ?? 0).toList();
  final r = parts(remote);
  final l = parts(local);
  for (var i = 0; i < 3; i++) {
    final rv = i < r.length ? r[i] : 0;
    final lv = i < l.length ? l[i] : 0;
    if (rv != lv) return rv > lv;
  }
  return false;
}

// Zones = Pakistan ke SHEHER (owner ka hukm 2026-11-07: Karachi ke
// ilaqe khatm, app poore Pakistan mein chalegi). Master sirf in ki
// KHULA/BAND haalat control karta hai; naya sheher code se jodna hota
// hai taake us ke map coordinates bhi maujood hon.
const List<String> kZones = [
  'Karachi',
  'Hyderabad',
  'Sukkur',
  'Larkana',
  'Nawabshah',
  'Mirpurkhas',
  'Lahore',
  'Faisalabad',
  'Rawalpindi',
  'Islamabad',
  'Multan',
  'Gujranwala',
  'Sialkot',
  'Bahawalpur',
  'Sargodha',
  'Peshawar',
  'Mardan',
  'Abbottabad',
  'Quetta',
  'Gwadar',
  'Doosra Sheher',
];

/// Har sheher ka SOOBA — passenger ki "Qareebi Jagahen" list mein
/// sheher ke neeche yahi nazar ata hai (pehle har zone ke neeche
/// 'Karachi' likha rehta tha). Sheher kZones mein ho aur yahan na
/// ho to subtitle 'Pakistan' ajata hai.
const Map<String, String> kZoneProvince = {
  'Karachi': 'Sindh',
  'Hyderabad': 'Sindh',
  'Sukkur': 'Sindh',
  'Larkana': 'Sindh',
  'Nawabshah': 'Sindh',
  'Mirpurkhas': 'Sindh',
  'Lahore': 'Punjab',
  'Faisalabad': 'Punjab',
  'Rawalpindi': 'Punjab',
  'Islamabad': 'Islamabad Capital Territory',
  'Multan': 'Punjab',
  'Gujranwala': 'Punjab',
  'Sialkot': 'Punjab',
  'Bahawalpur': 'Punjab',
  'Sargodha': 'Punjab',
  'Peshawar': 'Khyber Pakhtunkhwa',
  'Mardan': 'Khyber Pakhtunkhwa',
  'Abbottabad': 'Khyber Pakhtunkhwa',
  'Quetta': 'Balochistan',
  'Gwadar': 'Balochistan',
  'Doosra Sheher': 'Pakistan',
};

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------

class Booking {
  String id;
  String passengerName;
  String passengerPhone;
  String pickupLabel;
  String dropLabel;
  double pickupLat;
  double pickupLng;
  double dropLat;
  double dropLng;
  bool hasDropPin;
  String vehicle;
  double distanceKm;
  int fare; // distance fare only; waiting is separate
  String note;
  String status; // pending | accepted | arrived | completed | cancelled | noshow
  DateTime createdAt;
  DateTime? arrivedAt;
  DateTime? completedAt;
  int waitingMinutes;
  int waitingCharge;
  String driverName;

  // --- v1.4.2 do-phone dispatch ki pehchan ---
  /// Backend rides row par darj asal driver id (accept ke baad).
  String assignedDriverId;
  /// Asal driver ki rabta/tafseel — backend drivers row se ati hai
  /// (passenger ki Driver Details screen ke liye; khaali = abhi nahi).
  String driverPhone;
  String driverVehicleDetail; // brand + model, e.g. "Toyota Corolla"
  String driverPlate;
  String driverPhotoPath; // driver-docs bucket ka path (ya khaali)
  /// Isi phone ke driver ne khud accept kiya hai (same-device) —
  /// aisi booking ki haalat LOCAL store hi tay karta hai; backend
  /// se mili status is par NAHI lagti.
  bool acceptedHere;
  /// Ye booking backend Pool feed se ayi hai (doosre phone ki) —
  /// accept sirf race-guarded claim se hota hai.
  bool fromBackend;

  // --- v1.4.4 LEGAL + SAFETY: cancel / early-complete ki WAJAH ------
  //
  // Malik ki khaas shart (2026-11-08): ride CANCEL ho ya sawari
  // beech raaste mein rukwa kar ride WAHEEN khatam (early complete)
  // kar de — dono surat mein app WAJAH poochti hai, aur wajah ride
  // ke record ke saath hamesha ke liye mehfooz rehti hai (backend
  // rides.cancel_reason / rides.end_reason, migration v134) taaki
  // company (Master) ko pata chale aur baad mein saboot rahe.
  /// Cancel ki wajah (jo cancel kare — sawari ya driver — usi se
  /// poochhi gayi; khaali = wajah darj nahi hui).
  String cancelReason;
  /// Early complete (beech raaste mein waheen khatam) ki wajah.
  String endReason;
  /// Ride apni asal manzil se pehle hi waheen khatam hui thi.
  bool endedEarly;

  // --- SABOOT (EVIDENCE) RECORDING (owner 2026-11-08) ------------
  //
  // Gambhir haalat mein active ride par driver ya sawari audio
  // saboot record karta hai. Recording KABHI delete nahi hoti.
  /// Is phone par mehfooz recording file ka local rasta (khaali
  /// = is ride ki koi local recording nahi). Upload fail ho to
  /// yehi rasta dobara koshish ki bunyaad hai.
  String evidenceLocalPath;
  /// Backend Storage (driver-docs bucket) mein upload shuda
  /// object ka rasta: evidence/<ride_id>/<role>_<timestamp>.m4a
  /// (khaali = abhi upload nahi hua).
  String evidenceRemotePath;
  /// Recording kis ne ki: 'driver' | 'passenger' (khaali = koi nahi).
  String evidenceBy;
  /// Master ko is saboot ki khabar (messages table) bheji ja
  /// chuki hai ya nahi — upload ki dobara koshishon par duplicate
  /// khabar rokne ke liye.
  bool evidenceMasterNotified;
  /// Driver ki sawari ko di gayi rating (1..5; 0 = abhi nahi di).
  /// Sawari → driver wali rating (RideRating / ratings table) se
  /// ALAG hai; ye ride ki apni row par jati hai (migration v134
  /// rides.passenger_rating) taaki Master ko nazar aye.
  int passengerRating;

  // --- v1.4.7 RIDE START CODE (spec §3) ------------------------------
  //
  /// Sawari ki app ka 6-digit code (v1.4.14 — owner ka hukm
  /// 2026-11-09: purana 4-digit code SUPERSEDED) — booking bante
  /// hi banta hai; code SAWARI ke paas hota hai (us ki app mein
  /// dikhta hai), driver "Pahunch gaya" ke baad sawari se pooch
  /// kar yehi code daale tab ride asal mein SHURU hoti hai.
  /// 0 = code abhi nahi bana (purani booking — v1.4.7 se pehle ki,
  /// un ke 4-digit codes waisay hi chalte rahenge)।
  /// Backend rides.start_code (v137) mein bhi jata hai taaki
  /// do-phone mode mein driver use wahin se parh sake.
  int startCode;

  /// Ride code se asal shuru ho chuki hai ya nahi.
  bool rideStarted;

  /// Driver ki ghalat code koshishon ki ginti (3 par Master ko
  /// khabar — ghalat banda ride shuru karne ki koshish to nahi kar
  /// raha).
  int startCodeAttempts;

  Booking({
    required this.id,
    required this.passengerName,
    required this.passengerPhone,
    required this.pickupLabel,
    required this.dropLabel,
    required this.pickupLat,
    required this.pickupLng,
    required this.dropLat,
    required this.dropLng,
    required this.hasDropPin,
    required this.vehicle,
    required this.distanceKm,
    required this.fare,
    required this.note,
    required this.status,
    required this.createdAt,
    this.arrivedAt,
    this.completedAt,
    this.waitingMinutes = 0,
    this.waitingCharge = 0,
    this.driverName = 'Rashid Bozdar',
    this.assignedDriverId = '',
    this.driverPhone = '',
    this.driverVehicleDetail = '',
    this.driverPlate = '',
    this.driverPhotoPath = '',
    this.acceptedHere = false,
    this.fromBackend = false,
    this.cancelReason = '',
    this.endReason = '',
    this.endedEarly = false,
    this.passengerRating = 0,
    this.evidenceLocalPath = '',
    this.evidenceRemotePath = '',
    this.evidenceBy = '',
    this.evidenceMasterNotified = false,
    this.startCode = 0,
    this.rideStarted = false,
    this.startCodeAttempts = 0,
  });

  int get total => fare + waitingCharge;

  Map<String, dynamic> toJson() => {
        'id': id,
        'passengerName': passengerName,
        'passengerPhone': passengerPhone,
        'pickupLabel': pickupLabel,
        'dropLabel': dropLabel,
        'pickupLat': pickupLat,
        'pickupLng': pickupLng,
        'dropLat': dropLat,
        'dropLng': dropLng,
        'hasDropPin': hasDropPin,
        'vehicle': vehicle,
        'distanceKm': distanceKm,
        'fare': fare,
        'note': note,
        'status': status,
        'createdAt': createdAt.toIso8601String(),
        'arrivedAt': arrivedAt?.toIso8601String(),
        'completedAt': completedAt?.toIso8601String(),
        'waitingMinutes': waitingMinutes,
        'waitingCharge': waitingCharge,
        'driverName': driverName,
        'assignedDriverId': assignedDriverId,
        'driverPhone': driverPhone,
        'driverVehicleDetail': driverVehicleDetail,
        'driverPlate': driverPlate,
        'driverPhotoPath': driverPhotoPath,
        'acceptedHere': acceptedHere,
        'fromBackend': fromBackend,
        'cancelReason': cancelReason,
        'endReason': endReason,
        'endedEarly': endedEarly,
        'passengerRating': passengerRating,
        'evidenceLocalPath': evidenceLocalPath,
        'evidenceRemotePath': evidenceRemotePath,
        'evidenceBy': evidenceBy,
        'evidenceMasterNotified': evidenceMasterNotified,
        'startCode': startCode,
        'rideStarted': rideStarted,
        'startCodeAttempts': startCodeAttempts,
      };

  factory Booking.fromJson(Map<String, dynamic> j) => Booking(
        id: j['id'] as String,
        passengerName: j['passengerName'] as String? ?? '',
        passengerPhone: j['passengerPhone'] as String? ?? '',
        pickupLabel: j['pickupLabel'] as String? ?? '',
        dropLabel: j['dropLabel'] as String? ?? '',
        pickupLat: (j['pickupLat'] as num?)?.toDouble() ?? 0,
        pickupLng: (j['pickupLng'] as num?)?.toDouble() ?? 0,
        dropLat: (j['dropLat'] as num?)?.toDouble() ?? 0,
        dropLng: (j['dropLng'] as num?)?.toDouble() ?? 0,
        hasDropPin: j['hasDropPin'] as bool? ?? false,
        vehicle: j['vehicle'] as String? ?? 'Rickshaw',
        distanceKm: (j['distanceKm'] as num?)?.toDouble() ?? 0,
        fare: (j['fare'] as num?)?.toInt() ?? 0,
        note: j['note'] as String? ?? '',
        status: j['status'] as String? ?? 'pending',
        createdAt:
            DateTime.tryParse(j['createdAt'] as String? ?? '') ?? DateTime.now(),
        arrivedAt: DateTime.tryParse(j['arrivedAt'] as String? ?? ''),
        completedAt: DateTime.tryParse(j['completedAt'] as String? ?? ''),
        waitingMinutes: (j['waitingMinutes'] as num?)?.toInt() ?? 0,
        waitingCharge: (j['waitingCharge'] as num?)?.toInt() ?? 0,
        driverName: j['driverName'] as String? ?? 'Rashid Bozdar',
        assignedDriverId: j['assignedDriverId'] as String? ?? '',
        driverPhone: j['driverPhone'] as String? ?? '',
        driverVehicleDetail: j['driverVehicleDetail'] as String? ?? '',
        driverPlate: j['driverPlate'] as String? ?? '',
        driverPhotoPath: j['driverPhotoPath'] as String? ?? '',
        acceptedHere: j['acceptedHere'] as bool? ?? false,
        fromBackend: j['fromBackend'] as bool? ?? false,
        cancelReason: j['cancelReason'] as String? ?? '',
        endReason: j['endReason'] as String? ?? '',
        endedEarly: j['endedEarly'] as bool? ?? false,
        passengerRating: (j['passengerRating'] as num?)?.toInt() ?? 0,
        evidenceLocalPath: j['evidenceLocalPath'] as String? ?? '',
        evidenceRemotePath: j['evidenceRemotePath'] as String? ?? '',
        evidenceBy: j['evidenceBy'] as String? ?? '',
        evidenceMasterNotified:
            j['evidenceMasterNotified'] as bool? ?? false,
        startCode: (j['startCode'] as num?)?.toInt() ?? 0,
        rideStarted: j['rideStarted'] as bool? ?? false,
        startCodeAttempts: (j['startCodeAttempts'] as num?)?.toInt() ?? 0,
      );
}

/// Ride cancel / beech raaste mein khatam karne ki WAJHON ki
/// tay-shuda list (v1.4.4 — malik ki khaas shart 2026-11-08).
/// Jo bhi cancel ya early-complete kare (sawari ya driver), app
/// usi se in mein se ek wajah chunwati hai; 'Doosri wajah' par
/// (aur ikhtiyari tor par kisi par bhi) apni baat bhi likhi ja
/// sakti hai — woh wajah ke saath jud kar mehfooz hoti hai.
const List<String> kRideReasonOptions = [
  'Plan badal gaya',
  'Driver dair se aaya',
  'Ghalat jagah aa gaya',
  'Yahan kaam tha',
  'Manzil badal gayi',
  'Emergency',
  'Doosri wajah',
];

class MonthlyPackage {
  String id;
  String passengerName;
  String pickup;
  String drop;
  String vehicle;
  double routeKm;
  int days;
  int monthlyAmount;
  DateTime createdAt;
  String status; // active

  MonthlyPackage({
    required this.id,
    required this.passengerName,
    required this.pickup,
    required this.drop,
    required this.vehicle,
    required this.routeKm,
    required this.days,
    required this.monthlyAmount,
    required this.createdAt,
    this.status = 'active',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'passengerName': passengerName,
        'pickup': pickup,
        'drop': drop,
        'vehicle': vehicle,
        'routeKm': routeKm,
        'days': days,
        'monthlyAmount': monthlyAmount,
        'createdAt': createdAt.toIso8601String(),
        'status': status,
      };

  factory MonthlyPackage.fromJson(Map<String, dynamic> j) => MonthlyPackage(
        id: j['id'] as String,
        passengerName: j['passengerName'] as String? ?? '',
        pickup: j['pickup'] as String? ?? '',
        drop: j['drop'] as String? ?? '',
        vehicle: j['vehicle'] as String? ?? 'Rickshaw',
        routeKm: (j['routeKm'] as num?)?.toDouble() ?? 0,
        days: (j['days'] as num?)?.toInt() ?? 26,
        monthlyAmount: (j['monthlyAmount'] as num?)?.toInt() ?? 0,
        createdAt:
            DateTime.tryParse(j['createdAt'] as String? ?? '') ?? DateTime.now(),
        status: j['status'] as String? ?? 'active',
      );
}

// ---------------------------------------------------------------------------
// v1.4.0 — Kami Fix Wave ke naye models
// ---------------------------------------------------------------------------

/// Passenger ki apni di hui driver rating (v1.4.0). Phone par pehle
/// mehfooz hoti hai, phir backend `ratings` table mein jati hai
/// (migration v129; table na ho to sirf phone par rehti hai — UI
/// kabhi nahi rukti). Ek booking par ek hi rating hoti hai —
/// [bookingId] hi pehchan hai (dobara tap = purani update ho jati
/// hai, doosri row nahi banti).
class RideRating {
  String bookingId;
  String driverId; // jis driver ki ride thi (is phone ka driverId — pilot)
  String driverName;
  String passengerName;
  int stars; // 1..5
  String comment;
  bool sent; // backend tak puhancha ya abhi queued hai
  DateTime createdAt;

  RideRating({
    required this.bookingId,
    required this.driverId,
    required this.driverName,
    required this.passengerName,
    required this.stars,
    required this.createdAt,
    this.comment = '',
    this.sent = false,
  });

  Map<String, dynamic> toJson() => {
        'bookingId': bookingId,
        'driverId': driverId,
        'driverName': driverName,
        'passengerName': passengerName,
        'stars': stars,
        'comment': comment,
        'sent': sent,
        'createdAt': createdAt.toIso8601String(),
      };

  factory RideRating.fromJson(Map<String, dynamic> j) => RideRating(
        bookingId: j['bookingId'] as String? ?? '',
        driverId: j['driverId'] as String? ?? '',
        driverName: j['driverName'] as String? ?? '',
        passengerName: j['passengerName'] as String? ?? '',
        stars: (j['stars'] as num?)?.toInt() ?? 0,
        comment: j['comment'] as String? ?? '',
        sent: j['sent'] as bool? ?? false,
        createdAt:
            DateTime.tryParse(j['createdAt'] as String? ?? '') ?? DateTime.now(),
      );
}

/// In-app Notification Centre ki ek entry (v1.4.0) — koi FCM/push
/// nahi hai; events app ke andar ke polls/sync ke doran booking ki
/// haalat badalne se bante hain, aur Master ke elanaat (backend
/// `announcements` table) bhi yahin ate hain. [key] har event ki
/// mustaqil pehchan hai — wohi event dobara kabhi nahi banta.
class AppNotification {
  String key;
  String kind; // ride | deposit | announcement
  String title;
  String body;
  bool read;
  DateTime createdAt;

  AppNotification({
    required this.key,
    required this.kind,
    required this.title,
    required this.body,
    required this.createdAt,
    this.read = false,
  });

  Map<String, dynamic> toJson() => {
        'key': key,
        'kind': kind,
        'title': title,
        'body': body,
        'read': read,
        'createdAt': createdAt.toIso8601String(),
      };

  factory AppNotification.fromJson(Map<String, dynamic> j) => AppNotification(
        key: j['key'] as String? ?? '',
        kind: j['kind'] as String? ?? 'ride',
        title: j['title'] as String? ?? '',
        body: j['body'] as String? ?? '',
        read: j['read'] as bool? ?? false,
        createdAt:
            DateTime.tryParse(j['createdAt'] as String? ?? '') ?? DateTime.now(),
      );
}

/// Passenger ki mehfooz jagah (v1.4.0) — sirf label nahi, us jagah ke
/// map coordinates bhi mehfooz hote hain taaki chip tap karne par
/// pickup/drop ke saath pin + route bhi wohi ban jaye jo asal booking
/// mein banta hai. Purani Ghar/Daftar wali labels (savedGhar/savedDaftar)
/// se alag — woh sirf drop text bharti theen; ye nayi list usi purani
/// sahulat ko coordinates ke saath aage barhati hai (purana flow bilkul
/// barkarar hai).
class SavedPlace {
  String id;
  String name; // 'Ghar' | 'Dafter' | apna naam
  String label; // jagah ki tafseel / pata
  double lat;
  double lng;
  bool hasPin;

  SavedPlace({
    required this.id,
    required this.name,
    required this.label,
    required this.lat,
    required this.lng,
    required this.hasPin,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'label': label,
        'lat': lat,
        'lng': lng,
        'hasPin': hasPin,
      };

  factory SavedPlace.fromJson(Map<String, dynamic> j) => SavedPlace(
        id: j['id'] as String? ?? '',
        name: j['name'] as String? ?? '',
        label: j['label'] as String? ?? '',
        lat: (j['lat'] as num?)?.toDouble() ?? 0,
        lng: (j['lng'] as num?)?.toDouble() ?? 0,
        hasPin: j['hasPin'] as bool? ?? false,
      );
}

class WalletTxn {
  String id;
  String type; // deposit | fee
  int amount; // deposit: +amount stored positive; fee: fee amount positive
  String method; // Cash | Raast | Easypaisa | JazzCash | '' (fee)
  DateTime date;
  String note;

  WalletTxn({
    required this.id,
    required this.type,
    required this.amount,
    required this.method,
    required this.date,
    required this.note,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'amount': amount,
        'method': method,
        'date': date.toIso8601String(),
        'note': note,
      };

  factory WalletTxn.fromJson(Map<String, dynamic> j) => WalletTxn(
        id: j['id'] as String,
        type: j['type'] as String? ?? 'deposit',
        amount: (j['amount'] as num?)?.toInt() ?? 0,
        method: j['method'] as String? ?? '',
        date: DateTime.tryParse(j['date'] as String? ?? '') ?? DateTime.now(),
        note: j['note'] as String? ?? '',
      );
}

/// Master ko bheje jane wale message ki categories (v1.2.7).
const List<String> kMessageCategories = [
  'Ride ka masla',
  'Payment ya Wallet',
  'Driver ki shikayat',
  'Sawari ki shikayat',
  'App mein kharabi',
  'Deegar',
];

/// Master Messaging (v1.2.7 — malik ka hukm): sawari ya driver app se
/// seedha Master (head) ko message bhej sakta hai — masla, shikayat ya
/// koi bhi baat. Message pehle PHONE par mehfooz hota hai, phir backend
/// `messages` table mein jata hai jahan se Master app parhta hai.
/// [sent] = backend tak puhancha ya abhi phone par queued hai (offline
/// par agli sync/app khulne par khud dobara koshish hoti hai);
/// [isRead] = Master ne parh liya (Master app se pull hota hai).
class MasterMessage {
  String id;
  String senderKey; // driver: driverId | passenger: deviceId
  String senderRole; // 'driver' | 'passenger'
  String senderName;
  String senderMobile;
  String senderZone;
  String category;
  String body;
  bool isRead;
  bool sent;
  DateTime createdAt;

  MasterMessage({
    required this.id,
    required this.senderKey,
    required this.senderRole,
    required this.senderName,
    required this.senderMobile,
    required this.senderZone,
    required this.category,
    required this.body,
    required this.createdAt,
    this.isRead = false,
    this.sent = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'senderKey': senderKey,
        'senderRole': senderRole,
        'senderName': senderName,
        'senderMobile': senderMobile,
        'senderZone': senderZone,
        'category': category,
        'body': body,
        'isRead': isRead,
        'sent': sent,
        'createdAt': createdAt.toIso8601String(),
      };

  factory MasterMessage.fromJson(Map<String, dynamic> j) => MasterMessage(
        id: j['id'] as String,
        senderKey: j['senderKey'] as String? ?? '',
        senderRole: j['senderRole'] as String? ?? '',
        senderName: j['senderName'] as String? ?? '',
        senderMobile: j['senderMobile'] as String? ?? '',
        senderZone: j['senderZone'] as String? ?? '',
        category: j['category'] as String? ?? '',
        body: j['body'] as String? ?? '',
        isRead: j['isRead'] as bool? ?? false,
        sent: j['sent'] as bool? ?? false,
        createdAt:
            DateTime.tryParse(j['createdAt'] as String? ?? '') ?? DateTime.now(),
      );
}

/// RIDE CHAT (v1.4.16) — passenger ↔ driver ki ACTIVE ride ke andar
/// wali chat. Backend table `ride_messages` (mukammal package ki
/// 01-ride-chat.sql — LIVE): columns id (uuid), ride_id (rides.id),
/// sender_kind ('passenger'|'driver'|'system'), sender_id
/// (passenger = device_id, driver = drivers.id), kind ('text' |
/// 'quick' | 'arrival' | 'started' | 'completed'), body, created_at.
///
/// NUMBER SHARE NAHI hota — chat hi rabta hai; is model mein
/// mobile ka koi field NAHI hai (design lock)।
///
/// Ye model phone par PERSIST nahi hota — chat sirf live backend
/// se ati hai (RideChatScreen apni state rakhta hai)। `sent=false`
/// wala message sirf local hai (server par darj nahi ho saka)।
class RideMessage {
  String id;
  String rideId;
  String senderKind;
  String senderId;
  String kind;
  String body;
  DateTime createdAt;
  bool sent;

  RideMessage({
    required this.id,
    required this.rideId,
    required this.senderKind,
    required this.senderId,
    required this.kind,
    required this.body,
    required this.createdAt,
    this.sent = true,
  });

  /// Backend `ride_messages` row se — har field defensive (koi
  /// column khaali/ghalat ho to chat crash NAHI hoti)।
  factory RideMessage.fromServer(Map<String, dynamic> j) => RideMessage(
        id: j['id'] as String? ?? '',
        rideId: j['ride_id'] as String? ?? '',
        senderKind: j['sender_kind'] as String? ?? '',
        senderId: j['sender_id'] as String? ?? '',
        kind: j['kind'] as String? ?? 'text',
        body: j['body'] as String? ?? '',
        createdAt:
            DateTime.tryParse(j['created_at'] as String? ?? '')?.toLocal() ??
                DateTime.now(),
        sent: true,
      );
}

class DriverProfile {
  String name = 'Rashid Bozdar';
  String phone = '';
  String vehicle = 'Rickshaw';
  String plate = '';
  // FORM USOOL (2026-11-08): sheher kahin pehle se set NAHI hota —
  // naya profile khaali zone se shuru hota hai; driver apna sheher
  // khud registration wizard ke aakhri qadam mein chunta hai.
  String zone = '';
  bool online = false;
  // HOTFIX v1.2.9: ye teenon ab SIRF local legacy record hain.
  // Backend ke cnic_status / licence_status / gaari_status columns
  // MASTER-OWNED hain — _pushDriver ab inhein NAHI bhejta, aur
  // driver khud apni tasdeeq kahin se set NAHI kar sakta (Profile ke
  // self-attestation ChoiceChips hata diye gaye hain). Asal Master
  // verdict master*Status fields mein pull hota hai.
  String cnicStatus = 'pending'; // legacy local — backend nahi jata
  String licenceStatus = 'none'; // has | none  (none = "Licence nahi hai") — registration DATA (wizard se)
  bool licenceVerified = false; // legacy local — backend nahi jata
  String vehiclePapers = 'pending'; // legacy local — backend nahi jata
  String selfieDate = ''; // yyyy-mm-dd
  String selfiePath = '';
  bool depositDone = false;
  int walletBalance = 0;
  int totalDeposited = 0;

  /// PILOT: jama shuda 10% service fee jo abhi Master ko bhejni
  /// baqi hai (haftawar hisaab). Deposit band hon to har mukammal
  /// ride ki fee wallet se katne ke bajaye YAHAN jama hoti hai;
  /// driver Raast 0312 2635002 par bhej kar Master se hisaab
  /// saaf karwata hai (Master apni taraf se settlement darj karta
  /// hai to ye rakam wahan ke hisaab se milai jati hai).
  int feeDue = 0;

  /// Fee block lag chuka hai (feeDue ek dafa settle limit tak
  /// pahunch gayi). FULL SETTLEMENT RULE (2026-11-08): ye sirf
  /// tab saaf hota hai jab feeDue poori zero ho — juzwi
  /// settlement se block NAHI khulta.
  bool feeBlockActive = false;

  /// Number tabdeeli par 12-ghante block ki aakhri muddat
  /// (epoch ms; 0 = koi block nahi). Waqt guzar jane par block
  /// khud khatam — koi manual unblock nahi.
  int numberBlockedUntilMs = 0;

  /// Device tabdeeli par 6-ghante block ki aakhri muddat (epoch
  /// ms; 0 = koi block nahi). Ek account = ek device (malik ka
  /// hukm 2026-11-08); doosri device par account khule to ye
  /// khud-ba-khud lag jata hai aur Master ko khabar jati hai.
  int deviceBlockedUntilMs = 0;

  /// Sharait (Terms) ki qubooliyat ka waqt (epoch ms; 0 = abhi
  /// qabool NAHI hua) — v1.4.4 LEGAL: driver registration ke
  /// aakhri qadam par "Mein ne parh liya, qabool hai" dabane par
  /// darj hota hai aur backend drivers.terms_accepted_at
  /// (migration v134) mein Master ke saboot ke liye jata hai.
  int termsAcceptedAtMs = 0;

  /// Master (backend) ne is driver ko ACTIVE kiya hai ya nahi — ye
  /// value SIRF backend se ati hai (drivers.active); app ke andar se
  /// kabhi set nahi hoti. Default false = pending.
  bool masterActive = false;

  /// Driver ki akhri maloom GPS jagah (v1.2.4) — Driver Mode mein
  /// position refresh / ride qubool / navigation stream se taza hoti
  /// rehti hai. Passenger isi se "driver kitni door hai, kitni dair
  /// mein ayega" ginata hai, aur backend `drivers` table ke lat/lng
  /// columns mein bhi yehi mirror jata hai (Master map par asal
  /// jagah isi se nazar ati hai). null = abhi tak position mili hi
  /// nahi — us surat mein passenger ko koi jhoota number NAHI dikhta.
  double? lastLat;
  double? lastLng;

  /// Driver ke apne password ka FINGERPRINT (v1.2.5) — asal password
  /// kabhi kahin save nahi hota. Khaali = abhi password set nahi hua;
  /// pehli duty-on par set karna lazmi hai.
  String pwdFp = '';

  /// Master ne aarzi password lagaya hai — driver ko agle duty-on
  /// par (aarzi password se unlock hone ke baad) apna naya password
  /// LAZMI lagana hai, baghair badle duty aage nahi barhti
  /// (FINAL-PACK C-PD). Ye flag SIRF backend `drivers` row ke
  /// `must_change_password` column se pull hota hai
  /// (refreshDriverStatus — defensive: column na ho to false);
  /// driver khud isay set NAHI karta, kamyab password-change par
  /// local flag saaf hota hai aur backend par bhi false push hota
  /// hai (Backend.pushDriverPasswordReset).
  bool mustChangePassword = false;

  /// Ghalat password ki koshishon ka hisaab (v1.2.5): 5 ghalat par
  /// [pwdLockUntilMs] tak duty unlock band. Dono persisted hain taaki
  /// app band karke lockout se bacha na ja sake.
  int pwdFailCount = 0;
  int pwdLockUntilMs = 0; // epoch ms; 0 = koi lock nahi

  bool get pwdLocked =>
      pwdLockUntilMs > DateTime.now().millisecondsSinceEpoch;

  /// Kis tareekh (yyyy-mm-dd) ki selfie backend par upload ho chuki
  /// hai — dobara upload rokne aur nakami par agli sync mein retry
  /// ke liye.
  String selfieUploadedDate = '';

  // --- Registration wizard (v1.2.6 — Yango-style qadam-ba-qadam form) ------
  //
  // Ye fields registration wizard bharata hai. Tasaveer ke LOCAL
  // paths yahan darj hain; backend par number/tafseel wale columns
  // aur documents ki STATUS jati hai — aur v1.2.8 se tasaveer khud
  // bhi bucket 'driver-docs' mein jati hain (docUploaded dekhein),
  // taaki Master Tasdeeq mein har cheez check kar sake.

  /// CNIC number (XXXXX-XXXXXXX-X) — backend `drivers.cnic_number`.
  String cnicNumber = '';
  String cnicFrontPath = ''; // CNIC samne wali tasveer (phone par)
  String cnicBackPath = ''; // CNIC peeche wali tasveer (phone par)

  /// Gaari ki tafseel — backend `drivers.vehicle_brand/model/year/color`.
  String vehicleBrand = ''; // e.g. Sazgar, Yamaha, Suzuki
  String vehicleModel = '';
  int vehicleYear = 0; // 0 = abhi nahi likha
  String vehicleColor = '';
  String vehiclePhotoPath = ''; // gaari ki tasveer (phone par)
  String vehicleRegPath = ''; // gaari ke kaghaz (registration) ki tasveer

  /// Driving licence — OPTIONAL hai (malik ka lock): na ho to
  /// [licenceStatus] 'none' rehta hai aur ye khaali rehte hain.
  /// Backend `drivers.licence_number`.
  String licenceNumber = '';
  String licencePhotoPath = ''; // licence ki tasveer (phone par)

  /// AGENT CODE (v1.4.6 — Agent System, migration v136): driver
  /// kis agent ke zariye aya. Registration wizard ke aakhri
  /// qadam mein IKHTIYARI field hai — sirf tab bhara jata hai jab
  /// code backend `agents` table mein ACTIVE agent se mil jaye.
  /// Backend `drivers.agent_code` mein jata hai; khaali = koi
  /// agent nahi. Agent app se NAHI banta — sirf Master banata hai.
  String agentCode = '';

  /// Mobile ka IMEI number (15 digits) — "PTA Proof" (malik ka
  /// hukm 2026-11-08, screenshot wala tareeqa supersede): driver
  /// registration form ke PTA Proof hisse mein *#06# dial karke
  /// apna IMEI khud likhta hai; form 15 digits + Luhn check se
  /// typo pakarta hai. IMEI backend drivers.imei mein jata hai;
  /// Master Tasdeeq mein usi IMEI ko 8484/DIRBS par check karke
  /// pta_status (Master-owned) ka faisla karta hai. PTA LAZMI
  /// shart sirf tab hai jab malik ne Master se "PTA Proof lazmi"
  /// ON kiya ho ([Fares.ptaRequired], migration v133) — default
  /// band hai, tab IMEI ikhtiyari rehta hai.
  String imei = '';

  /// Registration wali LIVE selfie (camera se) — ye profile photo hai;
  /// rozana duty selfie ([selfiePath]) se ALAG hai. Phone par rehti hai.
  String profilePhotoPath = '';

  // --- v1.4.7 PROPER BUILD: Email + OTP (spec §1) -------------------
  //
  /// Driver ki Gmail — registration mein LAZMI hai aur OTP se
  /// verify hoti hai. Backend `drivers.email` mein bhi jati hai
  /// (migration v137; column na ho to sirf local record rehta hai).
  String email = '';

  /// Email OTP tasdeeq ka waqt (epoch ms; 0 = verify NAHI hua).
  int emailVerifiedAtMs = 0;

  bool get emailVerified => emailVerifiedAtMs > 0 && email.trim().isNotEmpty;

  /// Is login-session ki OTP tasdeeq. Registration/Login par OTP
  /// pass hone par true; LOGOUT par false ho jati hai — dobara
  /// login par phir OTP lazmi (spec §1). Apne band phone par roz
  /// ke istemal mein (bina logout) OTP NAHI manga jata.
  bool otpSessionVerified = false;

  // --- v1.4.7: gaari ki mukammal tasaveer (spec §7) -----------------
  //
  // Front wali tasveer [vehiclePhotoPath] hi hai (purana column);
  // baqi chaar ke backend par alag columns nahi hain — ye bucket
  // 'driver-docs' mein tay-shuda paths (<driver_id>/vehicle_back.jpg
  // waghera) par jati hain jahan se Master Tasdeeq unhein parhta hai.
  String vehicleBackPath = '';
  String vehicleLeftPath = '';
  String vehicleRightPath = '';
  String vehicleInteriorPath = '';

  // --- v1.4.14: Route Permit + Fitness Certificate (owner faisla
  // 2026-11-09, SECURITY-LOCKDOWN-PLAN addendum §5) -----------------
  //
  // Dono kagaz IKHTIYARI hain: na hon to ID NAHI rukti. Tasaveer
  // baqi documents ki tarah bucket 'driver-docs' mein tay-shuda
  // paths (<driver_id>/route_permit.jpg, <driver_id>/fitness_cert.jpg)
  // par jati hain — drivers row par in ke alag columns NAHI hain
  // (vehicle_back waghera wala hi convention; Master wahan se
  // parhta hai)। Local paths phone par rehte hain।
  String permitPhotoPath = ''; // route permit ki tasveer (phone par)
  String fitnessPhotoPath = ''; // fitness certificate ki tasveer

  /// Khud-zimmedari TASDEEQ ki qubooliyat ka waqt (epoch ms; 0 =
  /// abhi qabool NAHI hua)। Wizard ke Permit/Fitness qadam par
  /// driver ye tasdeeq qabool karta hai: permit/fitness meri apni
  /// zimmedari hai; na honay par challan / gaari bandi / nuqsan ka
  /// zimmedar mein khud hun, Bozdar Safar nahi; ye app drivers ke
  /// liye bilkul free hai, koi fee nahi — drivers ke bhale ke liye
  /// hai, is liye har driver apne kagaz khud poore rakhe। Waqt
  /// phone par mehfooz rehta hai (saboot) aur best-effort backend
  /// patch bhi jata hai (Backend.pushPermitFitnessDecl — column
  /// `drivers.permit_fitness_decl_at` abhi maujood NAHI hai; woh
  /// server migration se ayega, tab tak local record hi saboot hai)।
  int permitFitnessDeclAtMs = 0;

  // --- v1.4.7: Gaari change (spec §7) --------------------------------
  //
  /// Gaari change ki haalat — backend `drivers.vehicle_change_status`
  /// ka mirror: '' (koi darkhwast nahi) | 'pending' | 'approved' |
  /// 'rejected' — Faisla sirf Master karta hai.
  String vehicleChangeStatus = '';

  /// Master ki reject wajah (vehicle_change_reason ka mirror).
  String vehicleChangeReason = '';

  /// Jo change bheja gaya tha (fields + photo paths) — Master ke
  /// faisle ka intezaar; approve par yehi asal profile par lagta
  /// hai, is liye local mehfooz rakhna lazmi hai.
  Map<String, dynamic> vehicleChangePending = {};

  /// Purani gaariyon ka record (backend `drivers.vehicle_history`
  /// jsonb ka mirror) — har approved change par purani gaari yahan
  /// chali jati hai; record kabhi delete nahi hota.
  List<dynamic> vehicleHistory = [];

  // --- v1.4.7: Selfie warning flow (spec §2) --------------------------
  //
  /// Ghalat/na-milti selfie ki ginti (3 par aadha ghanta block) —
  /// demand mukammal hone par saaf ho jati hai.
  int selfieWarnCount = 0;

  /// Selfie block ki aakhri muddat (epoch ms; 0 = koi block nahi) —
  /// teesri ghalti par 30 minute; Master ko report jati hai.
  int selfieBlockUntilMs = 0;

  bool get selfieBlocked =>
      selfieBlockUntilMs > DateTime.now().millisecondsSinceEpoch;

  /// Registration wizard mukammal ho gaya hai ya nahi. Purane (v1.2.5
  /// se pehle ke) profiles mein ye key JSON mein nahi hoti — wahan
  /// naam + mobile maujood hona hi purani registration mana jata hai
  /// (loadJson mein derivation dekhein).
  /// ⚠️ HOTFIX v1.2.9: ye flag AKELA registration ka saboot NAHI
  /// raha — legacy derivation (sirf naam+mobile) ki wajah se baghair
  /// kisi document photo ke profiles bhi "done" lagte thay, wizard
  /// kabhi khulta hi nahi tha aur photos kabhi upload nahi hoteen.
  /// Asal mukammal hone ki shart [registrationComplete] hai.
  bool registrationDone = false;

  /// Registration ASAL mein mukammal (HOTFIX v1.2.9 — RC2):
  /// wizard ka flag + CNIC number + tamaam LAZMI document tasaveer
  /// phone par maujood hon. Licence ki photo ikhtiyari hai (licence
  /// hi ikhtiyari hai). Wizard ke tamam prompt/gate isay istemal
  /// karte hain — taaki purana (legacy) driver jis ke paas photos
  /// nahi hain woh wizard mein jaye (pehle se bhara hua milega, sirf
  /// baqi cheezein jama karni hongi).
  bool get registrationComplete =>
      registrationDone &&
      cnicNumber.trim().isNotEmpty &&
      cnicFrontPath.isNotEmpty &&
      cnicBackPath.isNotEmpty &&
      vehiclePhotoPath.isNotEmpty &&
      vehicleRegPath.isNotEmpty &&
      // PTA toggle (v133): IMEI sirf tab lazmi jab malik ne
      // Master se "PTA Proof lazmi" ON kiya ho — default band
      // hai to registration IMEI ke baghair bhi mukammal hai.
      (!Fares.ptaRequired || imei.trim().length == 15) &&
      profilePhotoPath.isNotEmpty;

  // --- Registration documents ki backend upload (v1.2.8 — TASDEEQ) --------
  //
  // Tasdeeq ke liye registration ki document tasaveer backend Storage
  // bucket 'driver-docs' mein jati hain taaki Master har cheez ASAL
  // tasveer mein check kar sake. Ye map har kind (cnic_front, cnic_back,
  // vehicle, vehicle_reg, licence, profile) ke liye woh LOCAL path
  // rakhta hai jo aakhri dafa kamyabi se upload hua tha: kind ghayab
  // ho ya mojooda local path is se alag ho (photo dobara li gayi) to
  // dobara upload lazmi hai. Sirf phone par rehta hai — backend par
  // asal object path drivers ke *_path columns mein jata hai.
  Map<String, String> docUploaded = {};

  // --- Master ki tasdeeq ki haalat (backend se pull, sirf display) -------
  //
  // Ye teenon SIRF backend `drivers` row se ate hain (refreshDriverStatus)
  // aur Profile mein "Master ki Tasdeeq" ke tor par dikhte hain —
  // in mein 'verified' | 'pending' | 'rejected' | 'none' kuch bhi aa
  // sakta hai. Local gate/toggles (cnicStatus waghera) in se KABHI
  // nahi badalte; driver ki apni duty ka taala sirf masterActive hai.
  String masterCnicStatus = '';
  String masterGaariStatus = '';
  String masterLicenceStatus = '';
  String masterPtaStatus = '';

  // --- Master ki reject WAJAH (v1.4.1 — Owner Tasdeeq Duty) ---------
  //
  // Ye teenon bhi SIRF backend `drivers` row se ate hain (migration
  // v130 ke cnic_reject_reason / gaari_reject_reason /
  // licence_reject_reason columns) aur "Mere Kagaz" panel mein
  // Master ke lafz-ba-lafz dikhte hain. Driver inhein kabhi set
  // NAHI karta; Master tasdeeq kare to backend par khaali ho jate
  // hain aur agle pull par yahan bhi saaf ho jate hain.
  String masterCnicReason = '';
  String masterGaariReason = '';
  String masterLicenceReason = '';
  String masterPtaReason = '';

  // --- Dobara bhejna (resubmit) ki local haalat (v1.4.1) -------------
  //
  // Reject shuda document ki NAYI photo chunne par us kind ke liye
  // woh local path darj ho jata hai jo dobara bheja gaya. Isi se
  // "Mere Kagaz" panel us document ko foran "Dobara bhej diya —
  // Intezaar Mein" dikhata hai, jabke backend *_status Master ke
  // naye faisle tak waisa hi rehta hai (ya v130 trigger se khud
  // 'pending' ho jata hai). Marker sirf tab tak rehta hai jab tak
  // mojooda photo wohi resubmit wali hai aur Master ka pull shuda
  // faisla abhi 'rejected' hai.
  Map<String, String> docResubmitted = {};

  // Dobara-upload par backend ko bheja jane wala "nayi photo a
  // gayi" wala timestamp (per status-group: 'cnic' | 'gaari' |
  // 'licence'). Ye *_status NAHI hai — v130 ka trigger is timestamp
  // ke badalne par status khud 'pending' kar deta hai. Sirf ek push
  // ke liye rehta hai; _pushDriver ke baad saaf ho jata hai.
  Map<String, String> docResubmitAt = {};

  /// Ek status-group ('cnic'|'gaari'|'licence') ki Master wajah.
  String masterReasonFor(String group) => switch (group) {
        'cnic' => masterCnicReason,
        'gaari' => masterGaariReason,
        'licence' => masterLicenceReason,
        'pta' => masterPtaReason,
        _ => '',
      };

  /// Ek status-group ka Master faisla.
  String masterStatusFor(String group) => switch (group) {
        'cnic' => masterCnicStatus,
        'gaari' => masterGaariStatus,
        'licence' => masterLicenceStatus,
        'pta' => masterPtaStatus,
        _ => '',
      };

  /// Kisi bhi document par Master ka REJECT faisla aya hua hai.
  bool get hasRejectedDocUi =>
      masterCnicStatus == 'rejected' ||
      masterGaariStatus == 'rejected' ||
      masterLicenceStatus == 'rejected' ||
      masterPtaStatus == 'rejected';

  /// Is group ka koi document driver ne reject ke BAAD dobara
  /// bheja hai ya nahi (group ke kinds ki mojooda photo
  /// docResubmitted marker se milti ho aur faisla abhi rejected ho).
  bool docGroupResubmitted(String group) {
    if (masterStatusFor(group) != 'rejected') return false;
    final kinds = switch (group) {
      'cnic' => const ['cnic_front', 'cnic_back'],
      'gaari' => const ['vehicle', 'vehicle_reg'],
      'licence' => const ['licence'],
      _ => const <String>[],
    };
    String pathOf(String kind) => switch (kind) {
          'cnic_front' => cnicFrontPath,
          'cnic_back' => cnicBackPath,
          'vehicle' => vehiclePhotoPath,
          'vehicle_reg' => vehicleRegPath,
          'licence' => licencePhotoPath,
          _ => '',
        };
    for (final k in kinds) {
      final sent = docResubmitted[k];
      if (sent != null && sent.isNotEmpty && sent == pathOf(k)) return true;
    }
    return false;
  }

  bool get selfieToday {
    if (selfieDate.isEmpty) return false;
    final now = DateTime.now();
    final today =
        '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    return selfieDate == today;
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'phone': phone,
        'vehicle': vehicle,
        'plate': plate,
        'zone': zone,
        'online': online,
        'cnicStatus': cnicStatus,
        'licenceStatus': licenceStatus,
        'licenceVerified': licenceVerified,
        'vehiclePapers': vehiclePapers,
        'selfieDate': selfieDate,
        'selfiePath': selfiePath,
        'depositDone': depositDone,
        'walletBalance': walletBalance,
        'totalDeposited': totalDeposited,
        'feeDue': feeDue,
        'feeBlockActive': feeBlockActive,
        'numberBlockedUntilMs': numberBlockedUntilMs,
        'deviceBlockedUntilMs': deviceBlockedUntilMs,
        'termsAcceptedAtMs': termsAcceptedAtMs,
        'masterActive': masterActive,
        'lastLat': lastLat,
        'lastLng': lastLng,
        'pwdFp': pwdFp,
        'mustChangePassword': mustChangePassword,
        'pwdFailCount': pwdFailCount,
        'pwdLockUntilMs': pwdLockUntilMs,
        'selfieUploadedDate': selfieUploadedDate,
        'cnicNumber': cnicNumber,
        'cnicFrontPath': cnicFrontPath,
        'cnicBackPath': cnicBackPath,
        'vehicleBrand': vehicleBrand,
        'vehicleModel': vehicleModel,
        'vehicleYear': vehicleYear,
        'vehicleColor': vehicleColor,
        'vehiclePhotoPath': vehiclePhotoPath,
        'vehicleRegPath': vehicleRegPath,
        'licenceNumber': licenceNumber,
        'licencePhotoPath': licencePhotoPath,
        'agentCode': agentCode,
        'imei': imei,
        'profilePhotoPath': profilePhotoPath,
        // v1.4.7 PROPER BUILD
        'email': email,
        'emailVerifiedAtMs': emailVerifiedAtMs,
        'otpSessionVerified': otpSessionVerified,
        'vehicleBackPath': vehicleBackPath,
        'vehicleLeftPath': vehicleLeftPath,
        'vehicleRightPath': vehicleRightPath,
        'vehicleInteriorPath': vehicleInteriorPath,
        // v1.4.14: permit/fitness (ikhtiyari kagaz + tasdeeq)
        'permitPhotoPath': permitPhotoPath,
        'fitnessPhotoPath': fitnessPhotoPath,
        'permitFitnessDeclAtMs': permitFitnessDeclAtMs,
        'vehicleChangeStatus': vehicleChangeStatus,
        'vehicleChangeReason': vehicleChangeReason,
        'vehicleChangePending': vehicleChangePending,
        'vehicleHistory': vehicleHistory,
        'selfieWarnCount': selfieWarnCount,
        'selfieBlockUntilMs': selfieBlockUntilMs,
        'registrationDone': registrationDone,
        'docUploaded': docUploaded,
        'masterCnicStatus': masterCnicStatus,
        'masterGaariStatus': masterGaariStatus,
        'masterLicenceStatus': masterLicenceStatus,
        'masterCnicReason': masterCnicReason,
        'masterGaariReason': masterGaariReason,
        'masterLicenceReason': masterLicenceReason,
        'docResubmitted': docResubmitted,
        'docResubmitAt': docResubmitAt,
      };

  void loadJson(Map<String, dynamic> j) {
    name = j['name'] as String? ?? name;
    phone = j['phone'] as String? ?? '';
    vehicle = j['vehicle'] as String? ?? 'Rickshaw';
    plate = j['plate'] as String? ?? '';
    // Zone ka fallback bhi khaali hai (FORM USOOL 2026-11-08) —
    // purani JSON mein zone na ho to koi sheher khud nahi lagta.
    zone = j['zone'] as String? ?? '';
    online = j['online'] as bool? ?? false;
    cnicStatus = j['cnicStatus'] as String? ?? 'pending';
    licenceStatus = j['licenceStatus'] as String? ?? 'none';
    licenceVerified = j['licenceVerified'] as bool? ?? false;
    vehiclePapers = j['vehiclePapers'] as String? ?? 'pending';
    selfieDate = j['selfieDate'] as String? ?? '';
    selfiePath = j['selfiePath'] as String? ?? '';
    depositDone = j['depositDone'] as bool? ?? false;
    walletBalance = (j['walletBalance'] as num?)?.toInt() ?? 0;
    totalDeposited = (j['totalDeposited'] as num?)?.toInt() ?? 0;
    feeDue = (j['feeDue'] as num?)?.toInt() ?? 0;
    feeBlockActive = j['feeBlockActive'] as bool? ?? false;
    numberBlockedUntilMs =
        (j['numberBlockedUntilMs'] as num?)?.toInt() ?? 0;
    deviceBlockedUntilMs =
        (j['deviceBlockedUntilMs'] as num?)?.toInt() ?? 0;
    termsAcceptedAtMs = (j['termsAcceptedAtMs'] as num?)?.toInt() ?? 0;
    masterActive = j['masterActive'] as bool? ?? false;
    lastLat = (j['lastLat'] as num?)?.toDouble();
    lastLng = (j['lastLng'] as num?)?.toDouble();
    pwdFp = j['pwdFp'] as String? ?? '';
    // FINAL-PACK C-PD: purani JSON mein ye key nahi hoti — false.
    mustChangePassword = j['mustChangePassword'] as bool? ?? false;
    pwdFailCount = (j['pwdFailCount'] as num?)?.toInt() ?? 0;
    pwdLockUntilMs = (j['pwdLockUntilMs'] as num?)?.toInt() ?? 0;
    selfieUploadedDate = j['selfieUploadedDate'] as String? ?? '';
    cnicNumber = j['cnicNumber'] as String? ?? '';
    cnicFrontPath = j['cnicFrontPath'] as String? ?? '';
    cnicBackPath = j['cnicBackPath'] as String? ?? '';
    vehicleBrand = j['vehicleBrand'] as String? ?? '';
    vehicleModel = j['vehicleModel'] as String? ?? '';
    vehicleYear = (j['vehicleYear'] as num?)?.toInt() ?? 0;
    vehicleColor = j['vehicleColor'] as String? ?? '';
    vehiclePhotoPath = j['vehiclePhotoPath'] as String? ?? '';
    vehicleRegPath = j['vehicleRegPath'] as String? ?? '';
    licenceNumber = j['licenceNumber'] as String? ?? '';
    licencePhotoPath = j['licencePhotoPath'] as String? ?? '';
    // v1.4.6: purani JSON mein ye key nahi hoti — khaali default.
    agentCode = j['agentCode'] as String? ?? '';
    imei = j['imei'] as String? ?? '';
    profilePhotoPath = j['profilePhotoPath'] as String? ?? '';
    // v1.4.7: purani JSON mein ye keys nahi hotin — mehfooz defaults.
    email = j['email'] as String? ?? '';
    emailVerifiedAtMs = (j['emailVerifiedAtMs'] as num?)?.toInt() ?? 0;
    otpSessionVerified = j['otpSessionVerified'] as bool? ?? false;
    vehicleBackPath = j['vehicleBackPath'] as String? ?? '';
    vehicleLeftPath = j['vehicleLeftPath'] as String? ?? '';
    vehicleRightPath = j['vehicleRightPath'] as String? ?? '';
    vehicleInteriorPath = j['vehicleInteriorPath'] as String? ?? '';
    // v1.4.14: purani JSON mein ye keys nahi hotin — mehfooz defaults.
    permitPhotoPath = j['permitPhotoPath'] as String? ?? '';
    fitnessPhotoPath = j['fitnessPhotoPath'] as String? ?? '';
    permitFitnessDeclAtMs =
        (j['permitFitnessDeclAtMs'] as num?)?.toInt() ?? 0;
    vehicleChangeStatus = j['vehicleChangeStatus'] as String? ?? '';
    vehicleChangeReason = j['vehicleChangeReason'] as String? ?? '';
    final vcp = j['vehicleChangePending'];
    vehicleChangePending = vcp is Map
        ? vcp.map((k, v) => MapEntry(k.toString(), v))
        : {};
    final vh = j['vehicleHistory'];
    vehicleHistory = vh is List ? List<dynamic>.from(vh) : [];
    selfieWarnCount = (j['selfieWarnCount'] as num?)?.toInt() ?? 0;
    selfieBlockUntilMs = (j['selfieBlockUntilMs'] as num?)?.toInt() ?? 0;
    // Purani JSON (v1.2.5 se pehle) mein 'registrationDone' key nahi
    // hoti — wahan naam + mobile maujood hona hi registration tha
    // (backend._registered ki purani tareef), wohi yahan mana gaya.
    registrationDone = j['registrationDone'] as bool? ??
        (name.trim().isNotEmpty && phone.trim().isNotEmpty);
    // v1.2.8: purani JSON mein ye keys nahi hotin — khaali defaults.
    final du = j['docUploaded'];
    docUploaded = du is Map
        ? du.map((k, v) => MapEntry(k.toString(), v?.toString() ?? ''))
        : {};
    masterCnicStatus = j['masterCnicStatus'] as String? ?? '';
    masterGaariStatus = j['masterGaariStatus'] as String? ?? '';
    masterLicenceStatus = j['masterLicenceStatus'] as String? ?? '';
    // v1.4.1: purani JSON mein ye keys nahi hotin — khaali defaults.
    masterCnicReason = j['masterCnicReason'] as String? ?? '';
    masterGaariReason = j['masterGaariReason'] as String? ?? '';
    masterLicenceReason = j['masterLicenceReason'] as String? ?? '';
    final dr = j['docResubmitted'];
    docResubmitted = dr is Map
        ? dr.map((k, v) => MapEntry(k.toString(), v?.toString() ?? ''))
        : {};
    final dra = j['docResubmitAt'];
    docResubmitAt = dra is Map
        ? dra.map((k, v) => MapEntry(k.toString(), v?.toString() ?? ''))
        : {};
  }
}

// ---------------------------------------------------------------------------
// Store — one on-device store shared by BOTH sides (same device), exactly like
// the web app: a booking made on the Passenger side appears on the Driver side.
// ---------------------------------------------------------------------------

/// Ek LIVE selfie demand (v1.4.7, spec §2): kind 'random' (duty ke
/// doran achanak check) ya 'complaint' (sawari ki shikayat par
/// FORAN)। Jab tak demand mukammal na ho driver app aage nahi
/// chalti। [complaintId] = woh messages-table id jis shikayat par
/// demand bani (saboot Master ke paas isi se jura rehta hai)।
class SelfieDemand {
  final String kind; // 'random' | 'complaint'
  final String date; // yyyy-mm-dd (demand wale din ki)
  final String complaintId;

  const SelfieDemand({
    required this.kind,
    required this.date,
    this.complaintId = '',
  });

  bool get isComplaint => kind == 'complaint';
}

class AppStore extends ChangeNotifier {
  final DriverProfile profile = DriverProfile();
  List<Booking> bookings = [];

  /// v1.4.2: backend Pool feed se ayi doosre phones ki pending
  /// rides (persist NAHI hoti — har refresh par backend se taaza
  /// list ati hai). Driver ki Pool/Bookings screens local pending
  /// bookings ke saath inhein bhi dikhati hain; accept sirf
  /// race-guarded backend claim se hota hai (Backend.tryClaimRide).
  List<Booking> remotePool = [];
  List<MonthlyPackage> monthlyPackages = [];
  List<WalletTxn> txns = [];
  String savedGhar = '';
  String savedDaftar = '';
  String passengerName = '';
  String passengerPhone = '';

  // --- v1.4.7: Passenger Email + OTP (spec §1 — driver jaisa hi) ------
  //
  /// Sawari ki Gmail — pehli ID Gmail se banti hai, OTP tasdeeq ke
  /// baad hi ID aage badhti hai. Backend `passengers` table
  /// (migration v137, device_id PK) mein bhi record jata hai;
  /// table abhi na ho to local record hi asal hai.
  String passengerEmail = '';
  int passengerEmailVerifiedAtMs = 0;

  bool get passengerEmailVerified =>
      passengerEmailVerifiedAtMs > 0 && passengerEmail.trim().isNotEmpty;

  /// Is session ki passenger OTP tasdeeq — logout par saaf;
  /// dobara booking se pehle OTP lazmi (spec §1).
  bool passengerOtpSessionVerified = false;

  // --- v1.4.7: Passenger no-show sakhti (spec §5) ----------------------
  //
  /// Is sawari ki no-show ginti — 3 par booking band (Master ki
  /// blocked list wala hi darwaza). Har no-show par warning bhi
  /// jati hai (notification + passengers.warn_count backend par).
  int passengerWarnCount = 0;

  /// Jin booking ids par no-show warning pehle hi di ja chuki hai
  /// (dobara ginti rokne ke liye).
  Set<String> noShowWarnedIds = {};

  bool get passengerNoShowBlocked => passengerWarnCount >= 3;

  // --- v1.4.7: Agent deep link (spec §6) -------------------------------
  //
  /// Agent link (bozdarsafar://register?agent=CODE) se aya code —
  /// wizard ke Agent Code field mein pehle se bhara milta hai.
  /// Persisted hai taaki app band karke dobara kholne par bhi code
  /// mehfooz rahe; registration mukammal hone par saaf ho jata hai.
  String pendingAgentCode = '';

  // --- v1.4.7: Selfie demands (spec §2) ---------------------------------
  //
  /// Is waqt ki LIVE selfie demand (random ya complaint) — null =
  /// koi demand nahi. Jab tak ye mukammal na ho, driver app AAGE
  /// NAHI chalti (duty/rides band) — gate UI isi ko dekhti hai.
  SelfieDemand? currentSelfieDemand;

  /// Random selfie ka aaj ka schedule (persisted): date + waqt ki
  /// ISO list. Waqt pehle se pata NAHI hota — schedule roz duty
  /// par khud banta hai.
  String randomSelfieDate = '';
  List<String> randomSelfieTimes = [];

  /// Aaj ki kitni random selfies mukammal ho chuki hain.
  int randomSelfieDoneCount = 0;

  // --- v1.4.7: Support auto-jawab ki haalat (spec §4) -------------------
  //
  /// Jin support threads (sender_key) par GREETING pehle hi ja
  /// chuki hai — har thread par sirf EK dafa.
  Set<String> supportGreetedKeys = {};

  /// Badtameezi ki warnings ki ginti (is phone ke user ki apni
  /// support baaton par) — warning line app khud deti hai, block
  /// ka faisla Master ke paas rehta hai.
  int supportWarnCount = 0;

  /// Master ko bheje gaye messages (v1.2.7) — is phone se bheje gaye
  /// saare (driver + passenger dono roles), sab se naya sab se pehle.
  List<MasterMessage> masterMessages = [];

  // --- v1.4.0: notifications / ratings / saved places / dispatch -----------

  /// Notification Centre ki entries (sab se nayi sab se pehle).
  /// [notificationEvents] UI ka sink hai: jab app khuli ho aur koi
  /// NAYA event bane to UI (jo bhi screen saamne ho) is se banner/
  /// snackbar dikhati hai — events sirf asal tabdeeli par bante hain,
  /// dobara nahi (har event ki [AppNotification.key] mustaqil hai).
  List<AppNotification> notifications = [];
  final StreamController<AppNotification> notificationEvents =
      StreamController<AppNotification>.broadcast();

  /// Passenger ki di hui ratings (bookingId se pehchan).
  List<RideRating> ratings = [];

  /// Passenger ki mehfooz jagahen (Ghar / Daftar / apne naam wali).
  List<SavedPlace> savedPlaces = [];

  /// Booking status ka pichla maloom snapshot (status by booking id)
  /// — notification events isi ke muqable se bante hain. App band
  /// hone par bhi mehfooz rehta hai taaki dobara khulne par wohi
  /// events dobara na ban jayein.
  Map<String, String> bookingStatusSeen = {};

  /// Master ki BLOCKED passengers list (FINAL-PACK B-PD): backend
  /// `blocked_passengers` table se pull shuda mobile numbers.
  /// Settings sync wale chakkar (Backend._pullSettings) ke saath
  /// refresh hoti hai; table na ho / backend na mile to akhri
  /// maloom list hi rehti hai (khaali = koi block nahi). Booking
  /// banane se pehle passenger.dart isi list se check karta hai.
  List<String> blockedPassengers = [];

  /// Driver-cancel notice jin ride ids ke liye passenger ko pehle
  /// hi dikhaya ja chuka hai (FINAL-PACK D) — har cancelled ride
  /// par bara notice SIRF ek dafa ata hai. bookingStatusSeen wale
  /// pattern par persisted hai taaki app dobara khulne par wohi
  /// notice dobara na aye.
  Set<String> cancelNoticeSeen = {};

  /// LIVE CHAT (owner 2026-11-08): Master ke woh jawab (messages
  /// table ki sender_role='master' rows, sender_key = meri apni
  /// key) jo chat khol kar parhe ja chuke hain — unread badge isi
  /// se banta hai. Replies khud [masterMessages] list mein hi
  /// rehte hain (senderRole 'master' ke saath).
  Set<String> seenMasterReplyIds = {};

  /// Master replies ka pehla pull sirf snapshot hai (announcements
  /// wala usool) — purane jawabat par notification flood NAHI ata;
  /// us ke baad ane wala har NAYA jawab notification banta hai.
  bool masterRepliesPrimed = false;

  /// Duty ke doran driver ki LIVE jagah (v1.4.0 — two-phone dispatch):
  /// driver side ka location timer (~20s) GPS le kar yahan darj karta
  /// hai, phir 'location' hook backend `drivers` row par lat/lng/
  /// loc_at PATCH kar deta hai. Ye profile.lastLat/lastLng (jo
  /// same-device pilot + Master map ke liye hai) se alag NAHI hai —
  /// wohi value hai, bas push ka tareeqa halka (sirf location) hai.
  DateTime? lastLocationPushAt;

  /// Backend `announcements` (Master ke elanaat) ka akhri maloom
  /// snapshot — id -> pehle se dekha hua. Naya elaan ate hi
  /// notification banta hai; pehli dafa pull hone par purane elaan
  /// notification NAHI bante (sirf snapshot ban jata hai).
  Set<String> seenAnnouncementIds = {};
  bool announcementsPrimed = false;

  /// Backend se pull shuda apne (is phone ke driver ki) ratings ka
  /// ausat — Driver Profile mein dikhta hai. null = abhi koi rating
  /// nahi mili / backend se jawab nahi aya (us surat mein Profile
  /// mein kuch nahi dikhta — jhoota number kabhi nahi). Local di hui
  /// ratings se andaza code maujood hai ([localOwnRatingAverage]).
  double? backendRatingAvg;
  int backendRatingCount = 0;

  /// Two-phone dispatch (v1.4.0): booking banate waqt backend se
  /// mile sab se qareeb active+online driver ki maloomat — sirf
  /// passenger ko "qareeb driver maujood hai" type ittila ke liye;
  /// assignment ka asal faisla driver ke qubool karne se hi hota
  /// hai aur same-device pilot flow bilkul barkarar rehta hai.
  /// Kabhi bhi jhoti assignment NAHI dikhayi jati.
  String dispatchNote = '';
  bool loaded = false;

  /// Duty unlock (v1.2.5): password is app SESSION mein ek dafa durust
  /// likha gaya hai ya nahi. SIRF memory mein rehta hai — persisted
  /// NAHI hota, app band ho to dobara password lazmi hai.
  bool dutyUnlocked = false;

  // --- Backend (v1.1.0) ------------------------------------------------------

  /// Is phone ki mustaqil pehchan — pehli dafa banti hai, phir hamesha
  /// wohi rehti hai. Backend `devices` table ki key hai.
  String deviceId = '';

  /// Is phone ke driver ki backend pehchan (drivers table ki key) —
  /// pehli dafa banti hai, phir hamesha wohi rehti hai.
  String driverId = '';

  /// Sharait (Terms) ki AAM qubooliyat ka waqt (epoch ms; 0 = abhi
  /// qabool NAHI hua) — v1.4.4 LEGAL: pehli dafa app khulne par
  /// Sharait ka page lazmi dikhta hai aur baghair "Mein ne parh
  /// liya, qabool hai" dabaye app aage NAHI barhti. Waqt phone par
  /// mehfooz rehta hai. Driver ki apni qubooliyat is se ALAG hai
  /// (DriverProfile.termsAcceptedAtMs — registration ke aakhir
  /// mein, backend saboot ke saath).
  int termsAcceptedAtMs = 0;

  /// Sawari ne apna account/profile delete kar diya hai (v1.4.4):
  /// naam/number/mehfooz jagahen saaf ho chuki hain. Ride ke
  /// RECORDS delete NAHI hote — woh Privacy Policy ke mutabiq
  /// safety ke liye mehfooz archive mein rehte hain (isi liye
  /// bookings yahan se kabhi saaf NAHI hoti).
  bool passengerDeleted = false;

  /// Passenger ko nazar ane wale zones — default local [kZones];
  /// backend `zones` table se band ilaqe is list se nikal jate hain
  /// (server na mile to local list hi chalti hai).
  List<String> zoneNames = List<String>.of(kZones);

  /// Backend sync hook — backend.dart app start par set karta hai.
  /// Har store action isay khamoshi se bulata hai; hook null ho ya
  /// fail ho jaye, local kaam par koi asar nahi padta. Kinds:
  /// 'booking' (Booking), 'package' (MonthlyPackage), 'txn' (WalletTxn),
  /// 'profile' (null — driver row mirror), 'selfie' (String yyyy-mm-dd),
  /// 'message' (MasterMessage — Master inbox push).
  void Function(String kind, Object? payload)? syncHook;

  void _hook(String kind, Object? payload) {
    try {
      syncHook?.call(kind, payload);
    } catch (_) {
      // Sync kabhi local flow ko nahi rok sakta.
    }
  }

  /// Backend se aye hue zones lagana (khali list = koi tabdeeli nahi).
  void applyServerZones(List<String> visible) {
    if (visible.isEmpty) return;
    zoneNames = visible;
    notifyListeners();
  }

  /// Master ne driver ko active kiya ya nahi — backend pull se ata hai.
  void setMasterActive(bool v) {
    profile.masterActive = v;
    unawaited(_persist());
    notifyListeners();
  }

  /// Backend se pull shuda blocked passengers list lagana
  /// (FINAL-PACK B-PD) — sirf tab jab nayi list asal mein alag ho.
  /// Khaali list bhi asal jawab ho sakti hai (sab unblock) — is
  /// liye zones wale "khaali = koi tabdeeli nahi" usool ke bar-aks
  /// yahan khaali list bhi lag jati hai; backend fail ho to backend
  /// taraf se ye function bulta hi nahi aur purani list rehti hai.
  void applyBlockedPassengers(List<String> mobiles) {
    final cleaned = <String>[
      for (final m in mobiles)
        if (m.trim().isNotEmpty) m.trim(),
    ];
    if (cleaned.length == blockedPassengers.length &&
        cleaned.every(blockedPassengers.contains)) {
      return;
    }
    blockedPassengers = cleaned;
    unawaited(_persist());
    notifyListeners();
  }

  /// Ek mobile number sirf digits ki surat mein — blocked check
  /// mein format ka farq (spaces/dashes/+92 vs 0) ghair-mutaliq
  /// hai: +92 wali surat ko 0 wali se mila kar bhi parkha jata hai.
  static String _phoneDigits(String s) {
    var d = s.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.startsWith('92') && d.length > 10) d = '0${d.substring(2)}';
    return d;
  }

  /// Ye passenger number Master ki blocked list mein hai ya nahi
  /// (FINAL-PACK B-PD) — booking banane se pehle ka check.
  bool isPassengerBlocked(String phone) {
    final d = _phoneDigits(phone);
    if (d.isEmpty) return false;
    for (final b in blockedPassengers) {
      if (_phoneDigits(b) == d) return true;
    }
    return false;
  }

  /// Master ka must_change_password faisla backend pull se lagana
  /// (FINAL-PACK C-PD) — column na ho to caller false bhejta hai.
  void setMustChangePassword(bool v) {
    if (profile.mustChangePassword == v) return;
    profile.mustChangePassword = v;
    unawaited(_persist());
    notifyListeners();
  }

  /// Driver-cancel ka bara notice is ride ke liye pehle dikhaya
  /// ja chuka hai ya nahi (FINAL-PACK D).
  bool hasCancelNoticeSeen(String bookingId) =>
      cancelNoticeSeen.contains(bookingId);

  /// Notice dikhane se PEHLE nishan lagana — do polls (passenger
  /// side + Finding screen) ek saath ayein to bhi notice ek hi
  /// dafa banta hai. Memory mein foran, persist background mein.
  void markCancelNoticeSeen(String bookingId) {
    if (!cancelNoticeSeen.add(bookingId)) return;
    unawaited(_persist());
  }

  /// Driver ki taaza GPS jagah darj karna (v1.2.4) — Driver Mode ke
  /// position refresh, ride qubool aur navigation stream se bulta
  /// hai. Bilkul waisi hi purani value dobara aye to kuch nahi hota.
  /// Persist + notify ke saath 'profile' hook bhi chalta hai, taaki
  /// backend `drivers` row ke lat/lng bhi taza ho jayein.
  void setDriverPosition(double lat, double lng) {
    if (profile.lastLat == lat && profile.lastLng == lng) return;
    profile.lastLat = lat;
    profile.lastLng = lng;
    unawaited(_persist());
    notifyListeners();
    _hook('profile', null);
  }

  /// Update notice: checkForUpdate nayi version dekh le to true;
  /// dismissUpdate sirf is session ke liye banner chhupata hai.
  bool updateAvailable = false;
  bool updateDismissed = false;

  /// Backend settings pull ne [UpdatePolicy] ki haddien lagayi
  /// hain — UI ko taza karna taake UPDATE GATE (v1.4.8) foran
  /// laago ho jaye (mandatory screen / recommended banner)।
  void onServerPolicyChanged() {
    notifyListeners();
  }

  int _seq = 0;
  String newId() =>
      '${DateTime.now().millisecondsSinceEpoch}-${_seq++}';

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final b = prefs.getString('bookings');
    if (b != null) {
      bookings = (jsonDecode(b) as List)
          .map((e) => Booking.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    final m = prefs.getString('monthly');
    if (m != null) {
      monthlyPackages = (jsonDecode(m) as List)
          .map((e) => MonthlyPackage.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    final t = prefs.getString('txns');
    if (t != null) {
      txns = (jsonDecode(t) as List)
          .map((e) => WalletTxn.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    final p = prefs.getString('profile');
    if (p != null) {
      profile.loadJson(jsonDecode(p) as Map<String, dynamic>);
    }
    savedGhar = prefs.getString('place_ghar') ?? '';
    savedDaftar = prefs.getString('place_daftar') ?? '';
    passengerName = prefs.getString('passenger_name') ?? '';
    passengerPhone = prefs.getString('passenger_phone') ?? '';
    // v1.4.7: purani install par ye keys nahi hotin — mehfooz defaults.
    passengerEmail = prefs.getString('passenger_email') ?? '';
    passengerEmailVerifiedAtMs =
        prefs.getInt('passenger_email_verified_ms') ?? 0;
    passengerOtpSessionVerified =
        prefs.getBool('passenger_otp_session') ?? false;
    passengerWarnCount = prefs.getInt('passenger_warn_count') ?? 0;
    final nsw = prefs.getStringList('noshow_warned_ids');
    if (nsw != null) noShowWarnedIds = nsw.toSet();
    pendingAgentCode = prefs.getString('pending_agent_code') ?? '';
    randomSelfieDate = prefs.getString('random_selfie_date') ?? '';
    final rst = prefs.getStringList('random_selfie_times');
    if (rst != null) randomSelfieTimes = rst;
    randomSelfieDoneCount = prefs.getInt('random_selfie_done') ?? 0;
    final sgk = prefs.getStringList('support_greeted_keys');
    if (sgk != null) supportGreetedKeys = sgk.toSet();
    supportWarnCount = prefs.getInt('support_warn_count') ?? 0;
    final mm = prefs.getString('master_messages');
    if (mm != null) {
      try {
        masterMessages = (jsonDecode(mm) as List)
            .map((e) => MasterMessage.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {
        // Kharab cache — messages ki list taaza shuru.
        masterMessages = [];
      }
    }
    final nt = prefs.getString('notifications');
    if (nt != null) {
      try {
        notifications = (jsonDecode(nt) as List)
            .map((e) => AppNotification.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {
        notifications = [];
      }
    }
    final rt = prefs.getString('ratings');
    if (rt != null) {
      try {
        ratings = (jsonDecode(rt) as List)
            .map((e) => RideRating.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {
        ratings = [];
      }
    }
    final sp = prefs.getString('saved_places');
    if (sp != null) {
      try {
        savedPlaces = (jsonDecode(sp) as List)
            .map((e) => SavedPlace.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {
        savedPlaces = [];
      }
    }
    final bs = prefs.getString('booking_status_seen');
    if (bs != null) {
      try {
        final j = jsonDecode(bs);
        if (j is Map) {
          bookingStatusSeen =
              j.map((k, v) => MapEntry(k.toString(), v?.toString() ?? ''));
        }
      } catch (_) {
        bookingStatusSeen = {};
      }
    }
    // FINAL-PACK B-PD / D: blocked list + cancel-notice seen-set.
    final bp = prefs.getStringList('blocked_passengers');
    if (bp != null) blockedPassengers = bp;
    final cn = prefs.getStringList('cancel_notice_seen');
    if (cn != null) cancelNoticeSeen = cn.toSet();
    final smr = prefs.getStringList('seen_master_reply_ids');
    if (smr != null) seenMasterReplyIds = smr.toSet();
    masterRepliesPrimed = prefs.getBool('master_replies_primed') ?? false;
    final sa = prefs.getString('seen_announcements');
    if (sa != null) {
      try {
        final j = jsonDecode(sa);
        if (j is List) {
          seenAnnouncementIds = j.map((e) => e.toString()).toSet();
          announcementsPrimed = true;
        }
      } catch (_) {
        seenAnnouncementIds = {};
      }
    }
    final bra = prefs.getDouble('backend_rating_avg');
    if (bra != null && bra > 0) {
      backendRatingAvg = bra;
      backendRatingCount = prefs.getInt('backend_rating_count') ?? 0;
    }
    deviceId = prefs.getString('device_id') ?? '';
    driverId = prefs.getString('driver_id') ?? '';
    termsAcceptedAtMs = prefs.getInt('terms_accepted_ms') ?? 0;
    passengerDeleted = prefs.getBool('passenger_deleted') ?? false;
    if (deviceId.isEmpty || driverId.isEmpty) {
      final rnd = Random();
      String gen(String prefix) =>
          '$prefix-${DateTime.now().millisecondsSinceEpoch}-${rnd.nextInt(0x7fffffff).toRadixString(16)}';
      if (deviceId.isEmpty) deviceId = gen('dev');
      if (driverId.isEmpty) driverId = gen('drv');
      loaded = true;
      await _persist();
    }
    loaded = true;
    notifyListeners();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        'bookings', jsonEncode(bookings.map((e) => e.toJson()).toList()));
    await prefs.setString('monthly',
        jsonEncode(monthlyPackages.map((e) => e.toJson()).toList()));
    await prefs.setString(
        'txns', jsonEncode(txns.map((e) => e.toJson()).toList()));
    await prefs.setString('profile', jsonEncode(profile.toJson()));
    await prefs.setString('place_ghar', savedGhar);
    await prefs.setString('place_daftar', savedDaftar);
    await prefs.setString('passenger_name', passengerName);
    await prefs.setString('passenger_phone', passengerPhone);
    // v1.4.7 PROPER BUILD
    await prefs.setString('passenger_email', passengerEmail);
    await prefs.setInt(
        'passenger_email_verified_ms', passengerEmailVerifiedAtMs);
    await prefs.setBool('passenger_otp_session', passengerOtpSessionVerified);
    await prefs.setInt('passenger_warn_count', passengerWarnCount);
    await prefs.setStringList('noshow_warned_ids', noShowWarnedIds.toList());
    await prefs.setString('pending_agent_code', pendingAgentCode);
    await prefs.setString('random_selfie_date', randomSelfieDate);
    await prefs.setStringList('random_selfie_times', randomSelfieTimes);
    await prefs.setInt('random_selfie_done', randomSelfieDoneCount);
    await prefs.setStringList(
        'support_greeted_keys', supportGreetedKeys.toList());
    await prefs.setInt('support_warn_count', supportWarnCount);
    await prefs.setString('master_messages',
        jsonEncode(masterMessages.map((e) => e.toJson()).toList()));
    await prefs.setString('notifications',
        jsonEncode(notifications.map((e) => e.toJson()).toList()));
    await prefs.setString(
        'ratings', jsonEncode(ratings.map((e) => e.toJson()).toList()));
    await prefs.setString('saved_places',
        jsonEncode(savedPlaces.map((e) => e.toJson()).toList()));
    await prefs.setString('booking_status_seen', jsonEncode(bookingStatusSeen));
    await prefs.setStringList('blocked_passengers', blockedPassengers);
    await prefs.setStringList(
        'cancel_notice_seen', cancelNoticeSeen.toList());
    await prefs.setStringList(
        'seen_master_reply_ids', seenMasterReplyIds.toList());
    await prefs.setBool('master_replies_primed', masterRepliesPrimed);
    await prefs.setString(
        'seen_announcements', jsonEncode(seenAnnouncementIds.toList()));
    if (backendRatingAvg != null) {
      await prefs.setDouble('backend_rating_avg', backendRatingAvg!);
      await prefs.setInt('backend_rating_count', backendRatingCount);
    }
    await prefs.setString('device_id', deviceId);
    await prefs.setString('driver_id', driverId);
    await prefs.setInt('terms_accepted_ms', termsAcceptedAtMs);
    await prefs.setBool('passenger_deleted', passengerDeleted);
  }

  Future<void> save() async {
    await _persist();
    notifyListeners();
    // Driver row ka backend mirror (online toggle, profile edits,
    // wallet balance waghera sab is mein shamil hain).
    _hook('profile', null);
  }

  // --- Update notice ---------------------------------------------------------

  void dismissUpdate() {
    updateDismissed = true;
    notifyListeners();
  }

  /// App shuru hone par EK dafa, khamoshi se: GitHub release mein nayi
  /// version hai to banner ka flag on. Offline/error par bilkul khamosh —
  /// na error dikhta hai, na UI rukti hai.
  Future<void> checkForUpdate() async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = const Duration(seconds: 6);
      final req = await client
          .getUrl(Uri.parse(
              'https://api.github.com/repos/bozdarstudio/bozdar-safar/releases/tags/v1.0.0'))
          .timeout(const Duration(seconds: 6));
      req.headers.set(HttpHeaders.acceptHeader, 'application/vnd.github+json');
      final resp = await req.close().timeout(const Duration(seconds: 6));
      if (resp.statusCode != 200) return;
      final body =
          await resp.transform(utf8.decoder).join().timeout(
                const Duration(seconds: 6),
              );
      String? remote;
      final m = RegExp(r'Version:\s*(\d+\.\d+\.\d+)').firstMatch(body);
      if (m != null) {
        remote = m.group(1);
      } else {
        final j = jsonDecode(body) as Map<String, dynamic>;
        final tag = (j['tag_name'] as String? ?? '').replaceFirst('v', '');
        if (RegExp(r'^\d+\.\d+\.\d+$').hasMatch(tag)) remote = tag;
      }
      if (remote != null && versionIsNewer(remote, kAppVersion)) {
        updateAvailable = true;
        notifyListeners();
      }
    } catch (_) {
      // Khamosh — offline par kuch nahi hota.
    } finally {
      client?.close();
    }
  }

  // --- Passenger actions ----------------------------------------------------

  Future<void> addBooking(Booking b) async {
    // v1.4.14 RIDE START CODE: har nayi booking ka apna 6-digit
    // code (owner ka hukm 2026-11-09 — 4-digit wala purana lock
    // superseded) — sawari driver ko batati hai, driver wohi code
    // daale tab ride shuru hoti hai.
    if (b.startCode <= 0) {
      b.startCode = 100000 + Random().nextInt(900000);
    }
    bookings.insert(0, b);
    await save();
    _hook('booking', b);
  }

  Future<void> addMonthly(MonthlyPackage p) async {
    monthlyPackages.insert(0, p);
    await save();
    _hook('package', p);
  }

  // --- Master messages (v1.2.7) ----------------------------------------------

  /// Master ko naya message: pehle phone par mehfooz (aur sawari ka
  /// naam/mobile agli dafa ke liye yaad), phir 'message' hook se
  /// backend push. Offline ho to message queued rehta hai — backend
  /// sync agli app-khulne/sync par dobara koshish karta hai.
  Future<void> addMasterMessage(MasterMessage m) async {
    masterMessages.insert(0, m);
    if (m.senderRole == 'passenger') {
      if (m.senderName.trim().isNotEmpty) passengerName = m.senderName.trim();
      if (m.senderMobile.trim().isNotEmpty) {
        passengerPhone = m.senderMobile.trim();
      }
    }
    await _persist();
    notifyListeners();
    _hook('message', m);
  }

  /// Backend push kamyab — message ko "bheja gaya" darj karna (sirf
  /// persist + notify; dobara hook NAHI, warna fizool pushes honge).
  Future<void> markMessageSent(String id) async {
    final m = _messageById(id);
    if (m == null || m.sent) return;
    m.sent = true;
    await _persist();
    notifyListeners();
  }

  /// Master ne message parh liya ya nahi — backend pull se ati hai.
  Future<void> applyMessageRead(String id, bool read) async {
    final m = _messageById(id);
    if (m == null || m.isRead == read) return;
    m.isRead = read;
    await _persist();
    notifyListeners();
  }

  MasterMessage? _messageById(String id) {
    for (final m in masterMessages) {
      if (m.id == id) return m;
    }
    return null;
  }

  // --- LIVE CHAT: Master ke jawab (owner 2026-11-08) -------------------------
  //
  // PROTOCOL (Master app ke saath mushtarka): Master ka jawab
  // messages table mein ek nayi row hai — sender_role='master',
  // sender_key = USI shakhs ki key jis ko jawab ja raha hai
  // (driver = driverId, passenger = deviceId), sender_name
  // 'Master'. Backend.fetchMyThread woh rows pull karke yahan
  // deta hai; thread messages.dart mein inhi se banti hai.

  /// Na-parhe hue Master jawabat ki tadaad — Madad wale
  /// darwazon par badge ke liye.
  int get unreadMasterReplies => masterMessages
      .where((m) =>
          m.senderRole == 'master' && !seenMasterReplyIds.contains(m.id))
      .length;

  /// Backend se aye thread rows ko local list mein milana:
  /// apne messages ki is_read haalat taaza hoti hai; Master ke
  /// jawab nayi entries ban kar shamil hote hain. Pehla pull
  /// (primed na ho) sirf snapshot hai — koi notification nahi;
  /// us ke baad har NAYA jawab Notification Centre mein
  /// 'Master ka jawab aya hai' ka event banta hai (notification
  /// events se app khuli ho to banner bhi ata hai).
  Future<void> applyThreadMessages(
      String senderKey, List<MasterMessage> rows) async {
    var changed = false;
    // Pehla thread pull (khaali ho tab bhi) snapshot pakka kar
    // deta hai — us ke baad ka har naya jawab asal "naya" hai.
    final wasPrimed = masterRepliesPrimed;
    if (!wasPrimed) {
      masterRepliesPrimed = true;
      changed = true;
    }
    final newReplies = <MasterMessage>[];
    for (final r in rows) {
      if (r.senderKey != senderKey) continue;
      final local = _messageById(r.id);
      if (local == null) {
        final copy = MasterMessage(
          id: r.id,
          senderKey: r.senderKey,
          senderRole: r.senderRole,
          senderName: r.senderName,
          senderMobile: r.senderMobile,
          senderZone: r.senderZone,
          category: r.category,
          body: r.body,
          isRead: r.isRead,
          // Backend se ayi row — bhejna is ka kaam hi nahi.
          sent: true,
          createdAt: r.createdAt,
        );
        masterMessages.add(copy);
        changed = true;
        if (r.senderRole == 'master') newReplies.add(copy);
      } else if (local.isRead != r.isRead) {
        local.isRead = r.isRead;
        changed = true;
      }
    }
    if (newReplies.isNotEmpty && !wasPrimed) {
      // Pehle pull ke purane jawab — snapshot, notification nahi.
    } else if (newReplies.isNotEmpty) {
      // Sab se purana jawab pehle notify karein.
      newReplies.sort((a, b) => a.createdAt.compareTo(b.createdAt));
      for (final r in newReplies) {
        await _addNotification(AppNotification(
          key: 'master-reply:${r.id}',
          kind: 'message',
          title: 'Master ka jawab aya hai',
          body: r.body,
          createdAt: DateTime.now(),
        ));
      }
    }
    if (changed) {
      masterMessages.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      await _persist();
      notifyListeners();
    }
  }

  /// Chat khulne par is key ke saare Master jawab "parhe hue"
  /// darj — unread badge saaf ho jata hai.
  Future<void> markMasterRepliesSeen(String senderKey) async {
    var changed = false;
    for (final m in masterMessages) {
      if (m.senderRole == 'master' &&
          m.senderKey == senderKey &&
          seenMasterReplyIds.add(m.id)) {
        changed = true;
      }
    }
    if (!changed) return;
    await _persist();
    notifyListeners();
  }

  // --- Driver actions -------------------------------------------------------

  /// Returns null on success, or the Urdu reason the ride cannot be accepted.
  /// Yehi EK gate har accept raste par chalta hai — incoming cards
  /// ka Qubool aur aayenda ka Pool-pick bhi (design brief) isi ko
  /// bulayega, is liye ID-active wali shart yahin sab se pehle hai:
  /// Master ki tasdeeq ke baghair koi ride — pool ki khadi ride
  /// bhi — qubool NAHI ho sakti (v1.4.1, Owner Tasdeeq Duty).
  /// FEE AUTO-BLOCK + FULL SETTLEMENT RULE (malik ka hukm
  /// 2026-11-08): baqi service fee settle limit tak PAHUNCHTE hi
  /// (feeBlockActive) driver block ho jata hai, aur block SIRF
  /// tab khulta hai jab POORI baqi raqam ka hisaab saaf ho jaye
  /// (feeDue == 0) — juzwi (aadhi) payment se block NAHI khulta,
  /// chahe baqi had se neeche hi kyun na aa jaye. Paighaam ye
  /// baat bilkul saaf alfaaz mein kehta hai.
  String? feeBlockReason() {
    final due = profile.feeDue;
    if (due > 0 &&
        (profile.feeBlockActive || due >= Fares.feeSettleLimit)) {
      return 'Aap ke zimme service fee Rs $due baqi hai jo had (Rs ${Fares.feeSettleLimit}) tak pahunch chuki hai — is liye rides band hain. '
          'Yaad rahe: block SIRF tab khulega jab POORI baqi raqam ka hisaab saaf hoga — juzwi (aadhi) payment se block NAHI khulega. '
          'Poori raqam Raast se 0312 2635002 par bhej kar Wallet mein apni payment darj karein — Master ki tasdeeq par hisaab saaf hote hi rides dobara khul jayengi.';
    }
    return null;
  }

  /// NUMBER TABDEELI BLOCK (malik ka hukm 2026-11-08): driver
  /// apna mobile number badle to ID khud-ba-khud 12 GHANTE block
  /// — na online, na ride. Waqt poora hote hi block khud khatam
  /// (koi button nahi, sirf waqt). Baqi waqt paighaam mein saaf.
  String? numberBlockReason() {
    final until = profile.numberBlockedUntilMs;
    if (until <= 0) return null;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now >= until) return null;
    final mins = ((until - now) / 60000).ceil();
    final h = mins ~/ 60;
    final m = mins % 60;
    final wait = h > 0 ? '$h ghante $m minute' : '$m minute';
    return 'Aap ne apna mobile number badla hai — is liye aap ki ID 12 ghante ke liye block hai (abhi $wait baqi hain). '
        'Is doran aap online nahi ho sakte aur nayi ride nahi le sakte. Waqt poora hote hi block khud-ba-khud khatam ho jayega.';
  }

  /// DEVICE TABDEELI BLOCK (malik ka hukm 2026-11-08): account
  /// registered device ke ilawa kisi aur device par khule to ID
  /// 6 GHANTE block — na online, na ride. Paighaam mein wajah,
  /// baqi waqt aur mustaqil hidayat (device tabdeel na karein;
  /// zaruri ho to PEHLE Master ko message karein) sab saaf hai.
  String? deviceBlockReason() {
    final until = profile.deviceBlockedUntilMs;
    if (until <= 0) return null;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now >= until) return null;
    final mins = ((until - now) / 60000).ceil();
    final h = mins ~/ 60;
    final m = mins % 60;
    final wait = h > 0 ? '$h ghante $m minute' : '$m minute';
    return 'Aap ka account registered device ke ilawa kisi DOOSRI device par khula hai — is liye aap ki ID 6 ghante ke liye block hai (abhi $wait baqi hain). '
        'Usool: sirf EK hi device istemal karein, device tabdeel na karein. Agar device badalna zaruri ho to PEHLE Master ko message karke batayein. Waqt poora hote hi block khud khatam ho jayega.';
  }

  /// Device-tabdeeli block ki muddat darj karna (Backend ki
  /// detection se) — sirf persist + notify; backend push caller
  /// khud karta hai (loop nahi banta).
  Future<void> setDeviceBlockedUntil(int ms) async {
    if (profile.deviceBlockedUntilMs == ms) return;
    profile.deviceBlockedUntilMs = ms;
    await _persist();
    notifyListeners();
  }

  String? acceptBlockReason() {
    // v1.4.7 SELFIE DEMAND GATE (spec §2): live selfie demand
    // (random check ya shikayat wali) baqi ho to rides BAND —
    // selfie diye baghair app aage nahi chalti।
    if (currentSelfieDemand != null) {
      return currentSelfieDemand!.isComplaint
          ? 'Aap ke khilaf shikayat par live selfie lazmi hai — pehle selfie dein, phir ride qubool karein.'
          : 'Achanak selfie check aya hai — pehle live selfie dein, phir ride qubool karein.';
    }
    if (profile.selfieBlocked) {
      return 'Ghalat selfie ki wajah se ID abhi aadhe ghante ke liye band hai — waqt poora honay par dobara koshish karein.';
    }
    if (!profile.masterActive) {
      return 'Aap ki ID abhi Master ki tasdeeq mein hai';
    }
    final numBlock = numberBlockReason();
    if (numBlock != null) return numBlock;
    final devBlock = deviceBlockReason();
    if (devBlock != null) return devBlock;
    final feeBlock = feeBlockReason();
    if (feeBlock != null) return feeBlock;
    // PILOT (2026-11-08): deposit band ho to ye gate bilkul nahi
    // lagta — joining bilkul muft hai.
    if (Fares.depositEnabled && !profile.depositDone) {
      return 'Pehle Rs ${Fares.joiningDeposit} ka joining deposit darj karein — baghair deposit ride qubool nahi ho sakti.';
    }
    if (!profile.selfieToday) {
      return 'Aaj ki live selfie baqi hai — pehle selfie lein, phir ride qubool karein.';
    }
    return null;
  }

  Future<void> acceptBooking(Booking b) async {
    b.status = 'accepted';
    b.driverName = profile.name;
    b.acceptedHere = true;
    b.assignedDriverId = driverId;
    await save();
    _hook('booking', b);
  }

  /// Backend Pool feed se ayi ride ka race-guarded claim kamyab
  /// hone ke baad (Backend.tryClaimRide) — ride is phone ki asal
  /// bookings mein shamil ho jati hai aur aage ka poora flow
  /// (arrived / complete / waiting) aam local booking jaisa chalta
  /// hai. Claim se pehle ye ride sirf [remotePool] mein thi.
  Future<void> acceptRemoteBooking(Booking b) async {
    remotePool.removeWhere((x) => x.id == b.id);
    if (!bookings.any((x) => x.id == b.id)) {
      bookings.insert(0, b);
    }
    b.status = 'accepted';
    b.driverName = profile.name;
    b.acceptedHere = true;
    b.assignedDriverId = driverId;
    await save();
    _hook('booking', b);
  }

  Future<void> markArrived(Booking b) async {
    b.status = 'arrived';
    b.arrivedAt = DateTime.now();
    await save();
    _hook('booking', b);
  }

  /// RIDE START CODE ki jaanch (v1.4.7, spec §3; v1.4.14 se code
  /// 6-digit hai): sawari ka code mile to ride asal mein SHURU
  /// (rideStarted)।
  /// Ghalat code par koshish darj hoti hai; teesri ghalat koshish
  /// par Master ko khabar jati hai (kahi ghalat banda ride shuru
  /// karne ki koshish to nahi kar raha)। Purani booking (code 0)
  /// par code ki shart nahi — seedha shuru।
  Future<bool> verifyAndStartRide(Booking b, int code) async {
    if (b.startCode > 0 && code != b.startCode) {
      b.startCodeAttempts += 1;
      await save();
      if (b.startCodeAttempts == 3) {
        await addMasterMessage(MasterMessage(
          id: newId(),
          senderKey: driverId,
          senderRole: 'driver',
          senderName: profile.name,
          senderMobile: profile.phone,
          senderZone: profile.zone,
          category: 'Ride ka masla',
          body: 'START CODE REPORT — Ride ID: ${b.id}\n'
              'Driver ne 3 dafa GHALAT start code dala hai.\n'
              'Route: ${b.pickupLabel} → ${b.dropLabel} · Sawari: ${b.passengerName}\n'
              'Ye khabar hifazat ke liye hai — ho sakta hai sawari ne code ghalat bataya ho, ya koi aur ride shuru karne ki koshish kar raha ho.',
          createdAt: DateTime.now(),
        ));
      }
      return false;
    }
    b.rideStarted = true;
    await save();
    _hook('booking', b);
    return true;
  }

  int liveWaitingMinutes(Booking b) {
    if (b.arrivedAt == null) return 0;
    return DateTime.now().difference(b.arrivedAt!).inMinutes;
  }

  int liveWaitingCharge(Booking b) {
    if (b.arrivedAt == null) return 0;
    return Fares.waitingCharge(b.vehicle, liveWaitingMinutes(b));
  }

  /// Completes the ride. Returns null on success, or the blocking reason.
  /// Wallet NEVER goes negative: if the service fee would take it below
  /// zero the completion is refused and nothing is recorded.
  Future<String?> completeBooking(Booking b) async {
    final mins = liveWaitingMinutes(b);
    final wCharge = Fares.waitingCharge(b.vehicle, mins);
    final fee = Fares.serviceFee(b.fare + wCharge);
    // PILOT (deposit band): fee wallet se NAHI kat-ti aur balance
    // ki kami ride ko NAHI rok-ti — fee sirf hisaab mein jama
    // hoti hai (feeDue) jo driver haftawar Master ko bhejta hai.
    // Deposit ON ho to purana usool: fee wallet se kat-ti hai aur
    // wallet kabhi negative nahi hota.
    final pilot = !Fares.depositEnabled;
    if (!pilot && profile.walletBalance - fee < 0) {
      return 'Balance khatam — pehle deposit karein';
    }
    b.waitingMinutes = mins;
    b.waitingCharge = wCharge;
    b.status = 'completed';
    b.completedAt = DateTime.now();
    if (pilot) {
      profile.feeDue += fee;
      // FULL SETTLEMENT RULE: baqi fee had tak pahunchi to block
      // ka jhanda lag gaya — ab ye sirf poori settlement (feeDue
      // zero) par hi utrega.
      if (profile.feeDue >= Fares.feeSettleLimit) {
        profile.feeBlockActive = true;
      }
    } else {
      profile.walletBalance -= fee;
    }
    final feeTxn = WalletTxn(
      id: newId(),
      type: 'fee',
      amount: fee,
      method: '',
      date: DateTime.now(),
      note:
          'Service charges ${fmtPct(Fares.feePercent)} — ride ${b.pickupLabel} → ${b.dropLabel} (kiraya + waiting)${pilot ? ' · Haftawar hisaab — Master ko bhejna hai' : ''}',
    );
    txns.insert(0, feeTxn);
    await save();
    _hook('booking', b);
    _hook('txn', feeTxn);
    return null;
  }

  /// No-show: allowed once total waiting reaches 10 minutes. Waiting charges
  /// are recorded on the booking.
  Future<String?> markNoShow(Booking b) async {
    final mins = liveWaitingMinutes(b);
    if (mins < 10) {
      return 'No-show ke liye kul 10 minute intezaar lazmi hai — abhi $mins minute hue hain.';
    }
    b.waitingMinutes = mins;
    b.waitingCharge = Fares.waitingCharge(b.vehicle, mins);
    b.status = 'noshow';
    b.completedAt = DateTime.now();
    await save();
    _hook('booking', b);
    // v1.4.7 (spec §5): same-device par sawari bhi isi phone ki hai
    // to us ki warning bhi yahin darj ho jati hai (3 par block)।
    // Doosre phone ki sawari par warning us ke apne phone par
    // remote status dekh kar lagti hai (applyRemoteRideState)।
    if (passengerPhone.isNotEmpty &&
        b.passengerPhone.trim() == passengerPhone.trim()) {
      await recordPassengerNoShow(b.id);
    }
    return null;
  }

  /// Ride cancel — v1.4.4: [reason] woh wajah hai jo app ne
  /// cancel karne wale (sawari ya driver) se poochhi thi
  /// (kRideReasonOptions + apni baat). Wajah booking ke record
  /// ke saath hamesha rehti hai aur backend rides.cancel_reason
  /// (migration v134) mein Master ko nazar ati hai.
  Future<void> cancelBooking(Booking b, {String reason = ''}) async {
    b.status = 'cancelled';
    if (reason.trim().isNotEmpty) b.cancelReason = reason.trim();
    await save();
    _hook('booking', b);
  }

  /// Sawari ride ko beech raaste mein rukwa kar WAHEEN khatam
  /// (early complete) kare — v1.4.4, malik ki khaas shart.
  /// [reason] lazmi wajah hai jo app ne poochhi thi. Ye sirf
  /// RECORD + status hai: wallet/fee ka hisaab yahan NAHI chalta
  /// (woh driver ki apni completion par us ke phone par lagta
  /// hai — wahan ki booking acceptedHere honay ki wajah se is
  /// remote-final se overwrite bhi nahi hoti). Arrived ho to
  /// ab tak ka waiting bhi record mein darj ho jata hai.
  Future<void> passengerEndRideEarly(Booking b, String reason) async {
    if (b.arrivedAt != null) {
      b.waitingMinutes = liveWaitingMinutes(b);
      b.waitingCharge =
          Fares.waitingCharge(b.vehicle, b.waitingMinutes);
    }
    b.status = 'completed';
    b.completedAt = DateTime.now();
    b.endedEarly = true;
    if (reason.trim().isNotEmpty) b.endReason = reason.trim();
    await save();
    _hook('booking', b);
  }

  /// SABOOT recording ride ke record par darj karna (owner
  /// 2026-11-08): pehle LOCAL rasta (upload se pehle hi, taaki
  /// upload fail ho to saboot phone par mehfooz rahe aur dobara
  /// koshish ho sake), phir upload kamyab hone par remote rasta
  /// [markEvidenceUploaded] se. 'booking' hook ride push ko
  /// evidence_path bhi bhejne ki koshish karta hai (backend.dart
  /// defensive hai — column na ho to aam push hi chalta hai).
  /// Recording delete karne ka koi rasta yahan NAHI hai.
  Future<void> saveEvidenceLocal(
      Booking b, String localPath, String byRole) async {
    b.evidenceLocalPath = localPath;
    b.evidenceBy = byRole;
    await save();
    _hook('booking', b);
  }

  /// Saboot ka backend upload kamyab — storage wala rasta record
  /// par darj (sirf persist + hook; local rasta bhi rehta hai
  /// taaki is phone se dobara sunna hamesha mumkin ho).
  Future<void> markEvidenceUploaded(Booking b, String remotePath) async {
    if (b.evidenceRemotePath == remotePath) return;
    b.evidenceRemotePath = remotePath;
    await save();
    _hook('booking', b);
  }

  /// Driver ki sawari ko rating (v1.4.4): ride ke apne record
  /// par darj hoti hai (passengerRating) aur 'booking' hook se
  /// backend rides.passenger_rating (migration v134) mein jati
  /// hai — Master ko har ride ke saath nazar ati hai. Dobara
  /// rating = wohi record update.
  Future<void> savePassengerRating(Booking b, int stars) async {
    if (stars < 1 || stars > 5) return;
    b.passengerRating = stars;
    await _persist();
    notifyListeners();
    _hook('booking', b);
  }

  /// Driver apni service-fee payment darj karta hai (record-based
  /// settlement — pehle Raast/Easypaisa/JazzCash/Cash se Master ko
  /// bhejna, phir yahan darj). Ye sirf RECORD hai: feeDue is se
  /// NAHI ghat-ti — Master tasdeeq karke backend par 'fee_settled'
  /// entry lagata hai, wahan se [applyFeeSettlement] hisaab saaf
  /// karta hai. Isi liye jhooti entry se block nahi khul sakta.
  Future<void> addFeePayment(int amount, String method) async {
    final txn = WalletTxn(
      id: newId(),
      type: 'fee_payment',
      amount: amount,
      method: method,
      date: DateTime.now(),
      note: 'Service fee payment — $method · Master ki tasdeeq baqi hai',
    );
    txns.insert(0, txn);
    await save();
    _hook('txn', txn);
  }

  /// Master ki tasdeeq shuda fee settlement (backend ledger ki
  /// 'fee_settled' entry se) — baqi fee utni hi kam ho jati hai,
  /// zero se neeche kabhi nahi.
  Future<void> applyFeeSettlement(int amount) async {
    if (amount <= 0 || profile.feeDue <= 0) return;
    profile.feeDue =
        profile.feeDue > amount ? profile.feeDue - amount : 0;
    // FULL SETTLEMENT RULE: block sirf POORI settlement par
    // khulta hai — feeDue zero hui to jhanda bhi saaf.
    if (profile.feeDue == 0) profile.feeBlockActive = false;
    await _persist();
    notifyListeners();
  }

  Future<void> addDeposit(int amount, String method) async {
    profile.walletBalance += amount;
    profile.totalDeposited += amount;
    if (profile.totalDeposited >= Fares.joiningDeposit) {
      profile.depositDone = true;
    }
    final depTxn = WalletTxn(
      id: newId(),
      type: 'deposit',
      amount: amount,
      method: method,
      date: DateTime.now(),
      note: 'Deposit — $method',
    );
    txns.insert(0, depTxn);
    await save();
    _hook('txn', depTxn);
  }

  Future<void> setSelfie(String path) async {
    final now = DateTime.now();
    profile.selfiePath = path;
    profile.selfieDate =
        '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    await save();
    _hook('selfie', profile.selfieDate);
  }

  /// Backend ne kis tareekh ki selfie tasveer upload kar li — sirf
  /// persist + notify ('profile' hook NAHI, warna fizool pushes
  /// chalte rahenge; drivers row par is ka koi asar nahi).
  Future<void> markSelfieUploaded(String date) async {
    if (profile.selfieUploadedDate == date) return;
    profile.selfieUploadedDate = date;
    await _persist();
    notifyListeners();
  }

  /// Ek registration document ki tasveer backend par upload ho gayi
  /// (v1.2.8) — [kind] ke liye wohi [localPath] darj ho jata hai jo
  /// upload hua tha. Sirf persist + notify ('profile' hook NAHI,
  /// warna fizool pushes chalte rahenge; drivers row par is ka path
  /// backend khud agle _pushDriver mein likh deta hai).
  Future<void> markDocUploaded(String kind, String localPath) async {
    if (profile.docUploaded[kind] == localPath) return;
    profile.docUploaded[kind] = localPath;
    await _persist();
    notifyListeners();
  }

  /// Master ki tasdeeq ki haalat backend se pull (v1.2.8) — sirf
  /// Profile ke display ke liye mehfooz hoti hai; koi gate, koi
  /// local toggle is se nahi badalta. 'rejected' bhi waisa hi
  /// mehfooz hota hai aur Profile mein saaf nazar ata hai.
  Future<void> applyMasterDocStatuses({
    required String cnic,
    required String gaari,
    required String licence,
    String cnicReason = '',
    String gaariReason = '',
    String licenceReason = '',
    String pta = '',
    String ptaReason = '',
  }) async {
    if (profile.masterCnicStatus == cnic &&
        profile.masterGaariStatus == gaari &&
        profile.masterLicenceStatus == licence &&
        profile.masterCnicReason == cnicReason &&
        profile.masterGaariReason == gaariReason &&
        profile.masterLicenceReason == licenceReason &&
        profile.masterPtaStatus == pta &&
        profile.masterPtaReason == ptaReason) {
      return;
    }
    profile.masterCnicStatus = cnic;
    profile.masterGaariStatus = gaari;
    profile.masterLicenceStatus = licence;
    profile.masterCnicReason = cnicReason;
    profile.masterGaariReason = gaariReason;
    profile.masterLicenceReason = licenceReason;
    profile.masterPtaStatus = pta;
    profile.masterPtaReason = ptaReason;
    await _persist();
    notifyListeners();
  }

  /// Reject shuda document ki NAYI photo dobara bhej di gayi
  /// (v1.4.1) — [kind] ke liye woh [localPath] darj ho jata hai
  /// jo abhi chuna gaya. Sirf persist + notify ('profile' hook
  /// NAHI — photo ka asal upload store.save() ke hook se pehle hi
  /// tay ho chuka hota hai; ye marker sirf panel ki haalat hai).
  Future<void> markDocResubmitted(String kind, String localPath) async {
    if (profile.docResubmitted[kind] == localPath) return;
    profile.docResubmitted[kind] = localPath;
    await _persist();
    notifyListeners();
  }

  /// Resubmit timestamp (v130 trigger ke liye) darj karna — sirf
  /// persist; backend push [Backend.syncDriverDocs] apne waqt par
  /// _pushDriver se karta hai jo isay row mein shamil karta hai.
  Future<void> markDocResubmitAt(String group, String isoTime) async {
    profile.docResubmitAt[group] = isoTime;
    await _persist();
  }

  /// Resubmit timestamps push ho jane ke baad saaf karna — taaki
  /// har aam _pushDriver wohi purana timestamp dobara na bheje
  /// (warna v130 trigger ka "badla hua timestamp" wala nishan
  /// kharab ho jayega). Sirf persist; koi hook nahi.
  Future<void> clearDocResubmitAt() async {
    if (profile.docResubmitAt.isEmpty) return;
    profile.docResubmitAt = {};
    await _persist();
  }

  // --- Notifications (v1.4.0 — In-app Notification Centre) -------------------
  //
  // Koi FCM/push nahi hai. Events do tareeqon se bante hain:
  //  1) Booking ki haalat ka diff — jo bhi poll/sync booking ki
  //     status badle (passenger side ka ride poll, driver side ke
  //     apne actions, app khulne par), [observeBookingStatuses] ko
  //     bulaya jata hai; pichle snapshot se nayi haalat alag ho to
  //     EK notification banta hai (key mustaqil hai — dobara kabhi
  //     nahi). Pehli dafa dekhi gayi booking (snapshot mein nahi)
  //     sirf darj hoti hai, event nahi banti — purani rides par
  //     app khulte hi flood nahi ata.
  //  2) Master ke elanaat — backend `announcements` pull (backend.dart)
  //     [applyAnnouncements] ko deta hai; snapshot ke baad ane wala
  //     har naya elaan ek notification banta hai.
  // Naya event bante hi [notificationEvents] par bhi jata hai taaki
  // saamne khuli screen usi waqt banner dikha sake. List ki had 60.

  int get unreadNotifications => notifications.where((n) => !n.read).length;

  Future<void> _addNotification(AppNotification n) async {
    if (notifications.any((x) => x.key == n.key)) return;
    notifications.insert(0, n);
    if (notifications.length > 60) {
      notifications = notifications.sublist(0, 60);
    }
    await _persist();
    notifyListeners();
    try {
      notificationEvents.add(n);
    } catch (_) {
      // Koi listener na ho to koi baat nahi — entry list mein hai.
    }
  }

  /// Booking statuses ka mojooda snapshot pichle se milana. [role]
  /// batata hai ke is phone par kaun si side dekh rahi hai —
  /// notifications usi side ke hisab se bante hain:
  ///  passenger: accepted / arrived / completed (apni ride ki khabar)
  ///  driver: pending (nayi ride aayi)
  /// [remoteStatus] (v1.4.0 two-phone): backend ride row se mili
  /// taaza status (bookingId → status) — jab mojood ho to diff
  /// USI se hota hai (doosre phone par ride complete ho jane ki
  /// khabar yahin se banti hai), warna local booking ki apni haalat
  /// se. Local booking ki haalat is function se KABHI nahi badalti —
  /// ye sirf notification engine hai.
  /// Har tabdeeli par sirf EK event; snapshot hamesha taza ho jata
  /// hai taaki dobara khulne par purane events na banein.
  Future<void> observeBookingStatuses(String role,
      {Map<String, String>? remoteStatus}) async {
    final prev = Map<String, String>.from(bookingStatusSeen);
    var changed = false;
    for (final b in bookings) {
      final effective = remoteStatus?[b.id] ?? b.status;
      final old = prev[b.id];
      if (old == null) {
        // Pehli dafa dekhi — sirf snapshot; event nahi.
        bookingStatusSeen[b.id] = effective;
        changed = true;
        continue;
      }
      if (old == effective) continue;
      bookingStatusSeen[b.id] = effective;
      changed = true;
      if (role == 'passenger') {
        final route = '${b.pickupLabel} → ${b.dropLabel}';
        if (effective == 'accepted') {
          await _addNotification(AppNotification(
            key: 'ride:${b.id}:accepted',
            kind: 'ride',
            title: 'Driver ne ride qubool kar li',
            body: route,
            createdAt: DateTime.now(),
          ));
        } else if (effective == 'arrived') {
          await _addNotification(AppNotification(
            key: 'ride:${b.id}:arrived',
            kind: 'ride',
            title: 'Driver pohanch gaya hai',
            body: route,
            createdAt: DateTime.now(),
          ));
        } else if (effective == 'completed') {
          await _addNotification(AppNotification(
            key: 'ride:${b.id}:completed',
            kind: 'ride',
            title: 'Ride mukammal ho gayi',
            body: '$route · Kul kiraya Rs ${b.total}',
            createdAt: DateTime.now(),
          ));
        }
      } else if (role == 'driver') {
        if (effective == 'pending') {
          await _addNotification(AppNotification(
            key: 'ride:${b.id}:new',
            kind: 'ride',
            title: 'Nayi ride aayi hai',
            body: '${b.pickupLabel} → ${b.dropLabel} · ${b.vehicle}',
            createdAt: DateTime.now(),
          ));
        }
      }
    }
    if (changed) await _persist();
  }

  /// v1.4.2 DISPATCH FIX: backend se mili asal ride haalat ko
  /// passenger ki LOCAL booking par lagana — is ke baghair do-phone
  /// par passenger ki screen hamesha 'pending' par atki rehti thi
  /// aur ETA/raseed/rating kabhi nahi khulte thay (DISPATCH-AUDIT
  /// Sawal 3). Usool sakht hain:
  ///  - Jis booking ko IS phone ke driver ne khud accept kiya ho
  ///    (acceptedHere) us ki haalat local hi tay karta hai — remote
  ///    us par NAHI lagta (same-device flow bilkul waisa hi).
  ///  - Local FINAL haalat (completed/cancelled/noshow) kabhi
  ///    overwrite NAHI hoti.
  ///  - Remote FINAL haalat hamesha lag jati hai; darmiyani
  ///    haalat sirf aage ki taraf (pending → accepted → arrived).
  /// Driver ki tafseel (naam/number/gaari/plate/photo) jo backend
  /// ne bheji ho woh bhi darj ho jati hai — passenger ki Driver
  /// Details screen inhi se banti hai. Tabdeeli hui to true.
  Future<bool> applyRemoteRideState(
    String bookingId, {
    required String status,
    String driverId = '',
    String driverName = '',
    String driverPhone = '',
    String driverVehicleDetail = '',
    String driverPlate = '',
    String driverPhotoPath = '',
    int startCode = 0,
    bool rideStarted = false,
  }) async {
    Booking? found;
    for (final b in bookings) {
      if (b.id == bookingId) {
        found = b;
        break;
      }
    }
    if (found == null) return false;
    final b = found;
    if (b.acceptedHere) return false;
    const finals = {'completed', 'cancelled', 'noshow'};
    if (finals.contains(b.status)) return false;
    const order = {'pending': 0, 'accepted': 1, 'arrived': 2};
    var changed = false;
    if (status != b.status) {
      final remoteFinal = finals.contains(status);
      final forward = (order[status] ?? -1) > (order[b.status] ?? -1);
      if (!remoteFinal && !forward) return false;
      b.status = status;
      if (status == 'noshow') {
        // v1.4.7 (spec §5): doosre phone ke driver ne no-show lagaya
        // — is phone ki sawari par warning darj (3 par block)। Ye
        // booking is phone ke driver ne accept NAHI ki thi
        // (acceptedHere upar hi return ho chuka hai), is liye ye
        // is phone ki apni sawari booking hi hai।
        await recordPassengerNoShow(b.id);
      }
      if (status == 'arrived' && b.arrivedAt == null) {
        b.arrivedAt = DateTime.now();
      }
      if (status == 'completed' && b.completedAt == null) {
        b.completedAt = DateTime.now();
      }
      changed = true;
    }
    void setIf(String current, String next, void Function(String) set) {
      if (next.isNotEmpty && next != current) {
        set(next);
        changed = true;
      }
    }

    setIf(b.assignedDriverId, driverId, (v) => b.assignedDriverId = v);
    setIf(b.driverName, driverName, (v) => b.driverName = v);
    setIf(b.driverPhone, driverPhone, (v) => b.driverPhone = v);
    setIf(b.driverVehicleDetail, driverVehicleDetail,
        (v) => b.driverVehicleDetail = v);
    setIf(b.driverPlate, driverPlate, (v) => b.driverPlate = v);
    setIf(b.driverPhotoPath, driverPhotoPath, (v) => b.driverPhotoPath = v);
    // v1.4.7: start code pehli dafa backend se mile to darj;
    // ride asal shuru ho chuki ho to woh haalat bhi।
    if (startCode > 0 && b.startCode <= 0) {
      b.startCode = startCode;
      changed = true;
    }
    if (rideStarted && !b.rideStarted) {
      b.rideStarted = true;
      changed = true;
    }
    if (changed) await save();
    return changed;
  }

  /// Backend Pool feed ki taaza list lagana (driver side) — jo
  /// rides is phone ki apni local bookings mein pehle se hain woh
  /// yahan NAHI atin (dedupe id se; woh aam local raste se dikhti
  /// hain). Sirf memory mein rehti hai; notify se screens taza.
  void setRemotePool(List<Booking> rides) {
    final localIds = bookings.map((b) => b.id).toSet();
    remotePool =
        rides.where((b) => !localIds.contains(b.id)).toList();
    notifyListeners();
  }

  /// Driver ke wallet mein Master ki taraf se darj deposit ka event —
  /// addDeposit ke backend/ledger raste se jab Master recorded
  /// deposit pull ho (backend.dart deposit poll isi ko bulata hai).
  /// [txnKey] mustaqil hai taaki wohi deposit dobara notify na ho.
  Future<void> notifyMasterDeposit(String txnKey, int amount, bool approved) {
    return _addNotification(AppNotification(
      key: 'deposit:$txnKey',
      kind: 'deposit',
      title: approved ? 'Deposit tasdeeq ho gaya' : 'Deposit darj ho gaya',
      body: 'Master ne aap ka deposit Rs $amount record kar liya hai.',
      createdAt: DateTime.now(),
    ));
  }

  /// Backend se aye elanaat (announcements) lagana — pehli dafa sirf
  /// snapshot banta hai (koi notification nahi); us ke baad har naya
  /// elaan notification banta hai. [rows] backend ke raw rows hain
  /// (id/title/body/created_at) — table mojood na ho to backend kuch
  /// bhejta hi nahi, ye function chalta hi nahi.
  Future<void> applyAnnouncements(List<Map<String, dynamic>> rows) async {
    if (rows.isEmpty) return;
    final fresh = <Map<String, dynamic>>[];
    for (final r in rows) {
      final id = r['id']?.toString() ?? '';
      if (id.isEmpty) continue;
      if (!seenAnnouncementIds.contains(id)) {
        seenAnnouncementIds.add(id);
        fresh.add(r);
      }
    }
    if (!announcementsPrimed) {
      announcementsPrimed = true;
      await _persist();
      return;
    }
    // Sab se purana pehle notify karein taaki centre mein tartib
    // waqt ke hisab se rahe (list mein naya upar ata hai).
    for (final r in fresh.reversed) {
      final title = (r['title'] as String?)?.trim().isNotEmpty == true
          ? r['title'] as String
          : 'Safar ka elaan';
      final body = (r['body'] as String?) ?? '';
      final at =
          DateTime.tryParse(r['created_at']?.toString() ?? '') ??
              DateTime.now();
      await _addNotification(AppNotification(
        key: 'ann:${r['id']}',
        kind: 'announcement',
        title: title,
        body: body,
        createdAt: at,
      ));
    }
    await _persist();
  }

  Future<void> markAllNotificationsRead() async {
    var any = false;
    for (final n in notifications) {
      if (!n.read) {
        n.read = true;
        any = true;
      }
    }
    if (!any) return;
    await _persist();
    notifyListeners();
  }

  // --- Legal: Sharait ki qubooliyat + sawari ka account delete (v1.4.4) -----

  /// App khulne wali Sharait ki qubooliyat darj karna — waqt
  /// phone par hamesha ke liye mehfooz ho jata hai; dobara page
  /// sirf tab dikhta hai jab ye waqt darj hi na ho.
  Future<void> acceptTerms() async {
    if (termsAcceptedAtMs > 0) return;
    termsAcceptedAtMs = DateTime.now().millisecondsSinceEpoch;
    await _persist();
    notifyListeners();
  }

  /// Driver ki Sharait qubooliyat (registration ke aakhri qadam
  /// se) — waqt profile mein darj hota hai aur save() ke
  /// 'profile' hook se backend drivers.terms_accepted_at
  /// (migration v134) mein Master ke saboot ke liye jata hai.
  Future<void> acceptDriverTerms() async {
    if (profile.termsAcceptedAtMs > 0) return;
    profile.termsAcceptedAtMs = DateTime.now().millisecondsSinceEpoch;
    await save();
  }

  /// Sawari ka account/profile DELETE (v1.4.4): zaati maloomat
  /// (naam, mobile, mehfooz jagahen) phone se saaf ho jati hai.
  // ==========================================================================
  // v1.4.7 PROPER BUILD — store ke naye amal (spec ke §1/§2/§5/§6/§7)
  // ==========================================================================

  /// Deep link se aya agent code darj karna (main.dart ka
  /// MethodChannel ise bulata hai)। Code 'BS' + digits ki shakal
  /// mein saaf karke rakha jata hai; wizard use pehle se bhara
  /// dikhata hai। Registration mukammal hone par wizard khud saaf
  /// kar deta hai।
  Future<void> setPendingAgentCode(String code) async {
    final c = code.trim().toUpperCase();
    if (c.isEmpty || c == pendingAgentCode) return;
    pendingAgentCode = c;
    await _persist();
    notifyListeners();
  }

  /// Driver ki email OTP tasdeeq mukammal — teeno jagahein ek
  /// saath: profile record, session flag, aur (caller ki taraf se)
  /// backend push। Session flag hi dobara-login OTP gate ki
  /// bunyaad hai।
  Future<void> applyDriverEmailVerified(String email) async {
    profile.email = email.trim().toLowerCase();
    profile.emailVerifiedAtMs = DateTime.now().millisecondsSinceEpoch;
    profile.otpSessionVerified = true;
    await save();
  }

  /// Passenger ki email OTP tasdeeq mukammal।
  Future<void> applyPassengerEmailVerified(String email) async {
    passengerEmail = email.trim().toLowerCase();
    passengerEmailVerifiedAtMs = DateTime.now().millisecondsSinceEpoch;
    passengerOtpSessionVerified = true;
    await _persist();
    notifyListeners();
  }

  /// Driver LOGOUT (v1.4.7): duty band + session OTP flag saaf —
  /// dobara duty-on par password ke baad Email OTP lazmi hoga
  /// (jin ke paas verified email hai)। Profile/record kuch delete
  /// NAHI hota।
  Future<void> driverLogout() async {
    profile.online = false;
    profile.otpSessionVerified = false;
    await save();
  }

  /// Passenger LOGOUT (v1.4.7): session OTP flag saaf — agli
  /// booking se pehle Email OTP dobara lazmi hoga।
  Future<void> passengerLogout() async {
    passengerOtpSessionVerified = false;
    await _persist();
    notifyListeners();
  }

  /// Sawari ki no-show warning darj karna (spec §5) — ek booking
  /// par sirf ek dafa। Warning notification bhi banti hai; 3 par
  /// [passengerNoShowBlocked] booking ka darwaza band kar deta
  /// hai। Pehli dafa darj hui ho to true।
  Future<bool> recordPassengerNoShow(String bookingId) async {
    if (bookingId.isEmpty || noShowWarnedIds.contains(bookingId)) {
      return false;
    }
    noShowWarnedIds.add(bookingId);
    passengerWarnCount += 1;
    await _persist();
    notifyListeners();
    await _addNotification(AppNotification(
      key: 'noshow-warn:$bookingId',
      kind: 'warning',
      title: 'No-show warning ($passengerWarnCount/3)',
      body: passengerWarnCount >= 3
          ? 'Aap 3 dafa ride par nahi ayein — aap ki booking ab BAND hai। Madad ke liye Master se rabta karein: 0332 9467211।'
          : 'Aap ride par nahi ayein aur driver wapas chala gaya। Ye warning $passengerWarnCount/3 hai — 3 warnings par booking band ho jayegi।',
      createdAt: DateTime.now(),
    ));
    return true;
  }

  // --- Selfie demands (spec §2) ---------------------------------------

  static String todayKey() {
    final n = DateTime.now();
    return '${n.year}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
  }

  /// Aaj ka random-selfie schedule banana (sirf ek dafa roz) —
  /// duty ke doran 2 achanak waqt। Waqt driver ko PEHLE se pata
  /// NAHI hota: schedule isi phone par banta hai aur ghanta
  /// guzarne par hi demand khulti hai।
  Future<void> ensureRandomSelfieSchedule() async {
    final today = todayKey();
    if (randomSelfieDate == today && randomSelfieTimes.isNotEmpty) {
      return;
    }
    final now = DateTime.now();
    final rnd = Random();
    final times = <DateTime>[];
    // Pehla check: ab se 40 minute – 3 ghante ke andar।
    times.add(now.add(Duration(minutes: 40 + rnd.nextInt(140))));
    // Doosra check: pehle se 2 – 5 ghante baad (raat 11 baje se
    // aage nahi — duty aam tor par khatam ho chuki hoti hai; guzar
    // jaye to woh demand agle din ki pehli duty par khul jati hai)।
    var second = times.first.add(Duration(minutes: 120 + rnd.nextInt(180)));
    final cap = DateTime(now.year, now.month, now.day, 23, 0);
    if (second.isAfter(cap)) second = cap;
    if (second.isAfter(times.first)) times.add(second);
    randomSelfieDate = today;
    randomSelfieTimes = [for (final t in times) t.toIso8601String()];
    randomSelfieDoneCount = 0;
    await _persist();
  }

  /// Random demand waqt par hai ya nahi — chalti ride ke beech
  /// demand NAHI khulti (safety); ride khatam hote hi khul jati
  /// hai (caller har poll par dobara poochta hai)।
  SelfieDemand? dueRandomSelfie({required bool onRideNow}) {
    if (currentSelfieDemand != null) return currentSelfieDemand;
    if (profile.selfieBlocked) return null;
    if (randomSelfieDate != todayKey()) return null;
    if (onRideNow) return null;
    var passed = 0;
    final now = DateTime.now();
    for (final iso in randomSelfieTimes) {
      final t = DateTime.tryParse(iso);
      if (t != null && !t.isAfter(now)) passed++;
    }
    if (passed > randomSelfieDoneCount) {
      return SelfieDemand(kind: 'random', date: randomSelfieDate);
    }
    return null;
  }

  /// Nayi demand lagana (random schedule se ya complaint poll se)।
  void setSelfieDemand(SelfieDemand d) {
    if (currentSelfieDemand?.kind == d.kind &&
        currentSelfieDemand?.complaintId == d.complaintId &&
        currentSelfieDemand?.date == d.date) {
      return;
    }
    currentSelfieDemand = d;
    notifyListeners();
  }

  /// Demand mukammal — gate khulta hai, warning ginti saaf।
  Future<void> completeSelfieDemand(SelfieDemand d) async {
    if (d.kind == 'random') randomSelfieDoneCount += 1;
    profile.selfieWarnCount = 0;
    currentSelfieDemand = null;
    await _persist();
    notifyListeners();
  }

  /// Ghalat/na-milti selfie: warning ginti +1। Teesri par 30
  /// minute block (profile.safieBlockUntilMs) — caller Master ko
  /// report bhejta hai। Returns: ab block laga hai ya nahi।
  Future<bool> noteSelfieMismatch() async {
    profile.selfieWarnCount += 1;
    var blocked = false;
    if (profile.selfieWarnCount >= 3) {
      profile.selfieBlockUntilMs =
          DateTime.now().add(const Duration(minutes: 30)).millisecondsSinceEpoch;
      profile.selfieWarnCount = 0;
      blocked = true;
    }
    await _persist();
    notifyListeners();
    return blocked;
  }

  // --- Gaari change (spec §7) -------------------------------------------

  /// Gaari change ki darkhwast local darj — status 'pending',
  /// Master ke faisle ka intezaar। Backend push caller (UI) karta
  /// hai (photo uploads ke saath); nakami par darkhwast yahin
  /// mehfooz rehti hai aur dobara bhejne ka button Profile mein
  /// rehta hai।
  Future<void> submitVehicleChangeLocal(Map<String, dynamic> change) async {
    profile.vehicleChangePending = change;
    profile.vehicleChangeStatus = 'pending';
    profile.vehicleChangeReason = '';
    await save();
  }

  /// v137 pull (Backend.refreshDriverStatus) se aye naye driver
  /// fields lagana — email ka mirror + gaari change ka Master
  /// faisla। Faisla 'approved' ho to pending change asal profile
  /// par lag jata hai aur purani gaari history mein chali jati
  /// hai; 'rejected' par wajah profile par rehti hai।
  Future<void> applyV137DriverFields(Map<String, dynamic> row) async {
    var changed = false;
    final em = row['email'];
    if (em is String && em.isNotEmpty && profile.email.isEmpty) {
      profile.email = em;
      changed = true;
    }
    final ev = row['email_verified_at'];
    if (ev is String && ev.isNotEmpty && profile.emailVerifiedAtMs == 0) {
      final t = DateTime.tryParse(ev);
      if (t != null) {
        profile.emailVerifiedAtMs = t.millisecondsSinceEpoch;
        changed = true;
      }
    }
    final hist = row['vehicle_history'];
    if (hist is List) {
      profile.vehicleHistory = List<dynamic>.from(hist);
      changed = true;
    }
    final status = row['vehicle_change_status'];
    if (status is String && status.isNotEmpty) {
      if (status == 'approved' &&
          profile.vehicleChangeStatus == 'pending' &&
          profile.vehicleChangePending.isNotEmpty) {
        final c = profile.vehicleChangePending;
        // Purani gaari history mein — record kabhi delete nahi।
        profile.vehicleHistory = [
          ...profile.vehicleHistory,
          {
            'vehicle': profile.vehicle,
            'plate': profile.plate,
            'brand': profile.vehicleBrand,
            'model': profile.vehicleModel,
            'year': profile.vehicleYear,
            'color': profile.vehicleColor,
            'changed_at': DateTime.now().toIso8601String(),
          },
        ];
        String s(String k) => c[k]?.toString() ?? '';
        if (s('vehicle').isNotEmpty) profile.vehicle = s('vehicle');
        profile.plate = s('plate');
        profile.vehicleBrand = s('brand');
        profile.vehicleModel = s('model');
        profile.vehicleYear = (c['year'] as num?)?.toInt() ?? 0;
        profile.vehicleColor = s('color');
        if (s('photo_front_local').isNotEmpty) {
          profile.vehiclePhotoPath = s('photo_front_local');
        }
        if (s('photo_back_local').isNotEmpty) {
          profile.vehicleBackPath = s('photo_back_local');
        }
        if (s('photo_left_local').isNotEmpty) {
          profile.vehicleLeftPath = s('photo_left_local');
        }
        if (s('photo_right_local').isNotEmpty) {
          profile.vehicleRightPath = s('photo_right_local');
        }
        if (s('photo_interior_local').isNotEmpty) {
          profile.vehicleInteriorPath = s('photo_interior_local');
        }
        if (s('reg_local').isNotEmpty) profile.vehicleRegPath = s('reg_local');
        profile.vehicleChangePending = {};
        changed = true;
      }
      if (status != profile.vehicleChangeStatus) {
        profile.vehicleChangeStatus = status;
        changed = true;
      }
      final reason = row['vehicle_change_reason'];
      final r = reason is String ? reason : '';
      if (r != profile.vehicleChangeReason) {
        profile.vehicleChangeReason = r;
        changed = true;
      }
    }
    if (changed) await save();
  }

  /// Ride ke RECORDS (bookings) jaan boojh kar NAHI mitaye jate —
  /// Privacy Policy mein saaf likha hai ke woh safety ke liye
  /// mehfooz archive mein ek muddat (3 saal) rehte hain, taaki
  /// kal koi jhooti shikayat aye to asal record driver ki
  /// hifazat kare.
  ///
  /// v1.4.16 — SERVER DELETION BHI (asal sudhaar): ab ye local
  /// wipe deletion ka AAKHRI qadam hai. Pehle UI flow OTP se
  /// dobara tasdeeq karke Backend.deletePassengerAccountRemote
  /// (RPC `delete_my_account`) bulata hai — server par
  /// passengers row + rides + messages ki pehchan anonymize
  /// ho jati hai aur identity link khatam ho jata hai. RPC
  /// kamyab NA ho to ye function BILKUL nahi bulaya jata —
  /// deletion adhura nahi rehta aur user ko saaf error milta
  /// hai. Master ko khabar UI wali taraf se (RPC ke baad,
  /// is wipe se pehle) message bhej kar di jati hai।
  Future<void> deletePassengerProfile() async {
    passengerName = '';
    passengerPhone = '';
    passengerEmail = '';
    passengerEmailVerifiedAtMs = 0;
    passengerOtpSessionVerified = false;
    savedGhar = '';
    savedDaftar = '';
    savedPlaces = [];
    passengerDeleted = true;
    await _persist();
    notifyListeners();
  }

  /// DRIVER ACCOUNT ka LOCAL WIPE (v1.4.16) — sawari wale
  /// [deletePassengerProfile] ka driver hum-manzar. Ye SIRF
  /// tab bulaya jata hai jab server par
  /// Backend.deleteDriverAccountRemote (RPC
  /// `delete_my_driver_account`) KAMYAB ho chuka ho — warna
  /// driver ka phone par record mehfooz rehta hai aur deletion
  /// adhura nahi hota।
  ///
  /// Yahan driver ki pehchan ki har cheez saaf hoti hai:
  /// driverId, profile ke tamam zaati fields, photo paths,
  /// password fingerprint, selfie/wallet/fee ki local haalat
  /// aur Master-tasdeeq ke purane naksh. Is ke baad app driver
  /// ko "naya banda" samajhti hai — dobara registration poora
  /// amal (Master Tasdeeq samet) lazmi hoga. Sawari wala
  /// hissa (bookings/passenger fields) NAHI chhoota jata —
  /// woh alag pehchan hai।
  Future<void> deleteDriverProfileLocal() async {
    driverId = '';
    final p = profile;
    p.name = '';
    p.phone = '';
    p.plate = '';
    p.zone = '';
    p.online = false;
    p.cnicStatus = 'pending';
    p.licenceStatus = 'none';
    p.licenceVerified = false;
    p.vehiclePapers = 'pending';
    p.selfieDate = '';
    p.selfiePath = '';
    p.selfieUploadedDate = '';
    p.depositDone = false;
    p.walletBalance = 0;
    p.totalDeposited = 0;
    p.feeDue = 0;
    p.feeBlockActive = false;
    p.numberBlockedUntilMs = 0;
    p.deviceBlockedUntilMs = 0;
    p.termsAcceptedAtMs = 0;
    p.masterActive = false;
    p.pwdFp = '';
    p.mustChangePassword = false;
    p.pwdFailCount = 0;
    p.pwdLockUntilMs = 0;
    p.cnicNumber = '';
    p.cnicFrontPath = '';
    p.cnicBackPath = '';
    p.vehicleBrand = '';
    p.vehicleModel = '';
    p.vehicleYear = 0;
    p.vehicleColor = '';
    p.vehiclePhotoPath = '';
    p.vehicleBackPath = '';
    p.vehicleLeftPath = '';
    p.vehicleRightPath = '';
    p.vehicleInteriorPath = '';
    p.vehicleRegPath = '';
    p.permitPhotoPath = '';
    p.fitnessPhotoPath = '';
    p.permitFitnessDeclAtMs = 0;
    p.licenceNumber = '';
    p.licencePhotoPath = '';
    p.agentCode = '';
    p.imei = '';
    p.profilePhotoPath = '';
    p.email = '';
    p.emailVerifiedAtMs = 0;
    p.otpSessionVerified = false;
    p.vehicleChangeStatus = '';
    p.vehicleChangeReason = '';
    p.selfieWarnCount = 0;
    p.selfieBlockUntilMs = 0;
    p.registrationDone = false;
    p.masterCnicStatus = '';
    p.masterGaariStatus = '';
    p.masterLicenceStatus = '';
    p.masterPtaStatus = '';
    p.masterCnicReason = '';
    p.masterGaariReason = '';
    p.masterLicenceReason = '';
    p.masterPtaReason = '';
    await save();
    notifyListeners();
  }

  // --- Ratings (v1.4.0) -------------------------------------------------------

  RideRating? ratingFor(String bookingId) {
    for (final r in ratings) {
      if (r.bookingId == bookingId) return r;
    }
    return null;
  }

  /// Passenger ki rating: pehle phone par, phir 'rating' hook se
  /// backend `ratings` table mein (best-effort). Dobara rating =
  /// wohi record update hota hai.
  Future<void> saveRating(RideRating r) async {
    final i = ratings.indexWhere((x) => x.bookingId == r.bookingId);
    if (i >= 0) {
      r.sent = ratings[i].sent && ratings[i].stars == r.stars
          ? ratings[i].sent
          : false;
      ratings[i] = r;
    } else {
      ratings.insert(0, r);
    }
    await _persist();
    notifyListeners();
    _hook('rating', r);
  }

  Future<void> markRatingSent(String bookingId) async {
    final r = ratingFor(bookingId);
    if (r == null || r.sent) return;
    r.sent = true;
    await _persist();
    notifyListeners();
  }

  /// Is phone ke driver ki apni ratings ka local ausat (jo ratings
  /// is phone par sawari ne di hain) — backend wala ausat dastiyab
  /// na ho to Profile mein yehi fallback dikhta hai; koi rating hi
  /// na ho to null (kuch nahi dikhta).
  double? get localOwnRatingAverage {
    final mine =
        ratings.where((r) => r.driverId == driverId && r.stars > 0).toList();
    if (mine.isEmpty) return null;
    final sum = mine.fold<int>(0, (a, r) => a + r.stars);
    return sum / mine.length;
  }

  /// Backend se pull shuda apna ausat (backend.dart lagata hai).
  Future<void> applyBackendRating(double avg, int count) async {
    if (avg <= 0) return;
    if (backendRatingAvg == avg && backendRatingCount == count) return;
    backendRatingAvg = avg;
    backendRatingCount = count;
    await _persist();
    notifyListeners();
  }

  // --- Saved places (v1.4.0 — passenger) --------------------------------------

  /// Jagah save karna — wohi naam dobara aye to purani update ho
  /// jati hai (doosri entry nahi banti).
  Future<void> savePlace(SavedPlace place) async {
    final i = savedPlaces.indexWhere((x) => x.name == place.name);
    if (i >= 0) {
      savedPlaces[i] = place;
    } else {
      savedPlaces.add(place);
    }
    await _persist();
    notifyListeners();
  }

  Future<void> removePlace(String id) async {
    savedPlaces.removeWhere((x) => x.id == id);
    await _persist();
    notifyListeners();
  }

  // --- Two-phone dispatch (v1.4.0) --------------------------------------------

  /// Duty par driver ki live jagah darj karna — driver side ka
  /// location timer (~20s) GPS le kar yahan deta hai. Sirf tab kuch
  /// hota hai jab jagah waqai badli ho ya akhri push ko kaafi waqt
  /// ho gaya ho; har dafa 'location' hook se backend drivers row par
  /// SIRF lat/lng/loc_at ki halki PATCH jati hai (pura driver mirror
  /// nahi — woh apni jagah chalta rehta hai).
  void noteDriverLocation(double lat, double lng) {
    final now = DateTime.now();
    final last = lastLocationPushAt;
    final moved = profile.lastLat == null ||
        profile.lastLng == null ||
        (profile.lastLat! - lat).abs() > 0.00005 ||
        (profile.lastLng! - lng).abs() > 0.00005;
    profile.lastLat = lat;
    profile.lastLng = lng;
    if (!moved && last != null && now.difference(last).inSeconds < 20) {
      return;
    }
    lastLocationPushAt = now;
    unawaited(_persist());
    notifyListeners();
    _hook('location', null);
  }

  /// Booking banate waqt qareeb tareen backend driver ki maloomat
  /// (backend.dart gin kar deta hai) — passenger side sirf ittila
  /// dikhati hai, assignment kabhi is par nahi banti.
  void setDispatchNote(String note) {
    if (dispatchNote == note) return;
    dispatchNote = note;
    notifyListeners();
  }

  // --- Driver earnings report (v1.4.0) ----------------------------------------

  /// Ek muddat (from..to, dono shaamil) ki kamai ka khulasa — local
  /// bookings + ledger se (koi backend nahi). gross = mukammal
  /// rides ka kul (kiraya + waiting); fee = un par service charges;
  /// net = gross − fee.
  ({int rides, int gross, int fee, int net}) earningsBetween(
      DateTime from, DateTime to) {
    var rides = 0, gross = 0, fee = 0;
    for (final b in bookings) {
      final c = b.completedAt;
      if (b.status != 'completed' || c == null) continue;
      if (c.isBefore(from) || c.isAfter(to)) continue;
      rides++;
      gross += b.total;
      fee += Fares.serviceFee(b.fare + b.waitingCharge);
    }
    return (rides: rides, gross: gross, fee: fee, net: gross - fee);
  }

  ({int rides, int gross, int fee, int net}) earningsThisWeek() {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day)
        .subtract(Duration(days: now.weekday - 1));
    return earningsBetween(
        start, DateTime(now.year, now.month, now.day, 23, 59, 59));
  }

  ({int rides, int gross, int fee, int net}) earningsThisMonth() {
    final now = DateTime.now();
    return earningsBetween(DateTime(now.year, now.month, 1),
        DateTime(now.year, now.month + 1, 0, 23, 59, 59));
  }
}
