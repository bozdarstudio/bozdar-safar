import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'backend.dart';
import 'guide_audio.dart';
import 'store.dart';
import 'theme.dart';

/// LIVE SELFIE GATE (v1.4.7, spec §2) — random check aur
/// shikayat wali selfie demand ka darwaza।
///
/// Usool:
/// - Selfie sirf CAMERA se — gallery ka rasta hi nahi।
/// - App khud foran check karti hai (roshni + chehre ki mojoodgi
///   ki bunyadi jaanch) — random/milta-julta chehra nahi chalta:
///   asal mazboot layer Master ki tasdeeq hai (selfie complaint
///   ke saboot ke saath Master ko jati hai)।
/// - Ghalat selfie par 3 mauqay: har dafa «Apna asal face
///   dikhayen — jo aap ke CNIC par hai»; aakhri warning saaf
///   lafzon mein; teesri ghalti par ID aadha ghanta block +
///   Master ko report।
/// - Chalti ride ke beech demand NAHI ati (store.dueRandomSelfie
///   ki shart) — ye page hamesha ruki hui haalat mein khulta hai।
class SelfieGatePage extends StatefulWidget {
  final AppStore store;
  final SelfieDemand demand;

  const SelfieGatePage({super.key, required this.store, required this.demand});

  @override
  State<SelfieGatePage> createState() => _SelfieGatePageState();
}

class _SelfieGatePageState extends State<SelfieGatePage> {
  final ImagePicker _picker = ImagePicker();
  bool _busy = false;
  String? _note;
  bool _blockedNow = false;

  AppStore get store => widget.store;
  SelfieDemand get d => widget.demand;

  @override
  void initState() {
    super.initState();
    // Awaaz wali hidayat: chehra saaf dikhane ki (guidance_
    // selfie_face) — demand khulte hi chalti hai।
    WidgetsBinding.instance.addPostFrameCallback((_) {
      unawaited(GuideAudio.play('guidance/guidance_selfie_face.mp3'));
    });
  }

  /// Bunyadi chehra/roshni jaanch — chhota frame decode karke:
  /// (1) tasveer bohat andheri na ho, (2) darmiyan wale hisse
  /// mein jild ke rang jaise pixels ki makhsoos mojoodgi
  /// (chehre ka bunyadi nishan)। Ye jaanch jaan boojh kar
  /// sakht-giri nahi karti — milti-julti shakal ka asal faisla
  /// Master ki tasdeeq (layered check) karti hai; yahan sirf
  /// khaali/deewar/jeib wali tasveer rukti hai।
  Future<bool> _looksLikeFace(String path) async {
    try {
      final bytes = await File(path).readAsBytes();
      if (bytes.isEmpty) return false;
      final codec = await ui.instantiateImageCodec(bytes, targetWidth: 96);
      final frame = await codec.getNextFrame();
      final image = frame.image;
      final w = image.width;
      final h = image.height;
      final ByteData? data =
          await image.toByteData(format: ui.ImageByteFormat.rawRgba);
      image.dispose();
      if (data == null || w <= 0 || h <= 0) return false;
      final px = data.buffer.asUint8List();
      double lumSum = 0;
      var skin = 0;
      var center = 0;
      final x0 = (w * 0.25).floor(), x1 = (w * 0.75).ceil();
      final y0 = (h * 0.2).floor(), y1 = (h * 0.8).ceil();
      for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++) {
          final o = (y * w + x) * 4;
          if (o + 2 >= px.length) continue;
          final r = px[o], g = px[o + 1], b = px[o + 2];
          lumSum += 0.299 * r + 0.587 * g + 0.114 * b;
          if (x >= x0 && x < x1 && y >= y0 && y < y1) {
            center++;
            // Jild ke rang ki pehchan (aam heuristic usool):
            if (r > 60 && g > 40 && b > 20 && r > g && r > b) skin++;
          }
        }
      }
      final meanLum = lumSum / (w * h);
      if (meanLum < 26) return false; // bohat andhera — chehra nahi
      if (center == 0) return false;
      return skin / center >= 0.10; // darmiyan mein chehra maujood
    } catch (_) {
      // Jaanch khud fail ho to tasveer Master par jane dein —
      // asal faisla wahan hota hai (layered check)।
      return true;
    }
  }

  Future<void> _takeSelfie() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final XFile? img = await _picker.pickImage(source: ImageSource.camera);
      if (img == null) {
        if (mounted) {
          setState(() {
            _busy = false;
            _note =
                'Selfie nahi li gayi — camera band ho gaya ya permission nahi mili. Dobara koshish karein.';
          });
        }
        return;
      }
      final ok = await _looksLikeFace(img.path);
      if (!mounted) return;
      if (!ok) {
        final blocked = await store.noteSelfieMismatch();
        if (!mounted) return;
        if (blocked) {
          // Teesri ghalti — Master ko report (saboot record)।
          await store.addMasterMessage(MasterMessage(
            id: store.newId(),
            senderKey: store.driverId,
            senderRole: 'driver',
            senderName: store.profile.name,
            senderMobile: store.profile.phone,
            senderZone: store.profile.zone,
            category: 'Selfie Report',
            body: 'SELFIE BLOCK REPORT\n'
                'Driver ne ${d.isComplaint ? 'shikayat wali' : 'random check wali'} selfie demand par 3 dafa ghalat / na-milti selfie di hai.\n'
                'ID aadhe ghante (30 minute) ke liye khud-kar block kar di gayi hai.'
                '${d.complaintId.isEmpty ? '' : '\nComplaint ID: ${d.complaintId}'}',
            createdAt: DateTime.now(),
          ));
          if (!mounted) return;
          setState(() {
            _busy = false;
            _blockedNow = true;
            _note =
                'Teesri ghalat selfie — aap ki ID aadhe ghante (30 minute) ke liye block kar di gayi hai aur Master ko report bhej di gayi hai.';
          });
          return;
        }
        final left = 3 - store.profile.selfieWarnCount;
        if (left <= 1) {
          unawaited(GuideAudio.play('guidance/guidance_selfie_warn.mp3'));
        }
        setState(() {
          _busy = false;
          _note = left <= 1
              ? '«Apna asal face dikhayen — jo aap ke CNIC par hai» — ye AAKHRI martaba hai: asal face na dikhaya to ID aadhe ghante ke liye block kar di jayegi.'
              : '«Apna asal face dikhayen — jo aap ke CNIC par hai» — ye selfie durust nahi lagi. Dobara saaf roshni mein camera ki taraf dekh kar selfie lein. Baqi mauqay: $left';
        });
        return;
      }
      // Kamyab — record + Master tak saboot (best-effort uploads;
      // gate LOCAL kamyabi par khulta hai, record peeche se
      // pakka hota rehta hai)।
      final objectPath =
          '${store.driverId}/${d.date}_${d.kind}_${DateTime.now().millisecondsSinceEpoch}.jpg';
      unawaited(Backend.uploadSelfieToPath(img.path, objectPath)
          .then((uploaded) => Backend.completeSelfieDemand(
                driverId: store.driverId,
                date: d.date,
                kind: d.kind,
                imagePath: uploaded ?? '',
              )));
      await store.completeSelfieDemand(d);
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        setState(() {
          _busy = false;
          _note = 'Camera nahi khul saka — dobara koshish karein.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final blocked = _blockedNow || store.profile.selfieBlocked;
    final minsLeft = store.profile.selfieBlockUntilMs >
            DateTime.now().millisecondsSinceEpoch
        ? ((store.profile.selfieBlockUntilMs -
                    DateTime.now().millisecondsSinceEpoch) /
                60000)
            .ceil()
        : 0;
    return Scaffold(
      appBar: AppBar(
        title: Text(d.isComplaint ? 'Shikayat — Live Selfie' : 'Achanak Selfie Check'),
        automaticallyImplyLeading: false,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Icon(
            d.isComplaint ? Icons.report : Icons.face_retouching_natural,
            size: 72,
            color: d.isComplaint ? Brand.ajrakRed : Brand.green,
          ),
          const SizedBox(height: 14),
          Text(
            d.isComplaint
                ? 'Aap ke khilaf sawari ki shikayat ayi hai'
                : 'Duty ke doran achanak pehchan ki jaanch',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 10),
          Text(
            d.isComplaint
                ? 'Saboot ke liye ABHI live selfie dein — selfie Master ko shikayat ke record ke saath jayegi. Jab tak selfie na mile, app AAGE NAHI chalegi (duty aur rides band rahengi).'
                : 'Ye achanak check is liye hai taaki ID sirf asal driver hi istemal kare. Abhi live selfie dein — jab tak selfie na mile, nayi ride qubool nahi hogi.',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 14, height: 1.5),
          ),
          const SizedBox(height: 12),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Text(
                'Hidayat: «Apna asal face dikhayen — jo aap ke CNIC par hai» — saaf roshni mein, camera ki taraf seedha dekh kar selfie lein. Kisi aur ki tasveer ya purani photo nahi chalegi — selfie sirf camera se hogi.',
                style: TextStyle(fontSize: 13.5, height: 1.5),
              ),
            ),
          ),
          if (_note != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFDECEA),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(_note!,
                  style: const TextStyle(
                      color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
            ),
          ],
          const SizedBox(height: 20),
          if (blocked)
            Column(
              children: [
                Text(
                  'ID abhi block hai — taqreeban $minsLeft minute baqi hain. Waqt poora honay par dobara selfie ka mauqa milega.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, color: Brand.ajrakRed),
                ),
                const SizedBox(height: 14),
                OutlinedButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('Theek hai'),
                ),
              ],
            )
          else
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _busy ? null : _takeSelfie,
                icon: _busy
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.camera_alt),
                label: Text(_busy ? 'Ho raha hai…' : 'Live Selfie Lein'),
                style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 15)),
              ),
            ),
        ],
      ),
    );
  }
}
