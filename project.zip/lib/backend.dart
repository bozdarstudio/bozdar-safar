import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:shared_preferences/shared_preferences.dart';
import 'store.dart';
import 'theme.dart' show rs;

/// SAFAR backend sync (v1.1.0) — Supabase REST, sirf dart:io HttpClient.
///
/// Usool:
/// - Local store hamesha asal sach hai; backend us ka AAINA (mirror) hai
///   taaki Master app mein sab kuch nazar aye.
/// - Har network kaam best-effort hai: offline/error par bilkul khamosh —
///   UI kabhi nahi rukti, koi error kabhi nahi dikhta, app crash nahi hota.
/// - Settings ka rukh sirf EK taraf hai: Master (backend) → app. Is app
///   mein settings ka koi editor nahi; server na mile to akhri cached
///   values, woh bhi na hon to built-in defaults chalte hain.
/// - Column/table naam backend-schema.sql ke ain mutabiq hain.
class Backend {
  static const String _base =
      'https://ndcnqotfqpgkgsngewug.supabase.co/rest/v1';
  // Publishable (client) key — apps mein embed karna mehfooz hai;
  // secret key kabhi app mein nahi jati.
  static const String _key =
      'sb_publishable_3TWtf4zT6xJzuyb0fsMuWQ_Fjkyk3LE';
  static const String _storageBase =
      'https://ndcnqotfqpgkgsngewug.supabase.co/storage/v1';
  // Supabase Auth (v1.4.7) — SIRF email OTP proof ke liye.
  static const String _authBase =
      'https://ndcnqotfqpgkgsngewug.supabase.co/auth/v1';
  static const Duration _timeout = Duration(seconds: 8);

  static AppStore? _store;
  static bool _started = false;

  /// App start par EK dafa — main.dart se. Store ke sync hook ko jodta
  /// hai aur pehla sync (device entry, settings, zones, driver status)
  /// background mein chalata hai. Dobara bulane par kuch nahi hota.
  static void start(AppStore store) {
    if (_started) return;
    _started = true;
    _store = store;
    store.syncHook = _onHook;
    unawaited(_startup(store));
  }

  static Future<void> _startup(AppStore store) async {
    // Pehle cached settings (offline ho to bhi Master ki akhri setting
    // chalti rahe), phir fresh pull.
    await _applyCachedSettings();
    await touchDevice(store, 'passenger');
    await _pullSettings();
    await _pullZones(store);
    await refreshDriverStatus(store);
    if (_registered(store)) await _pushDriver(store);
    // v1.4.8: app khulte hi is build ka version code bhi report
    // (duty-on par driver.dart se bhi jata hai) — guarded PATCH,
    // column na ho to khamosh.
    await reportAppVersion(store);
    // RC2 follow-through (v1.2.9): owners jinki registration is
    // machine par mukammal ho chuki hai lekin drivers row kabhi
    // bani hi nahi — ensureDriverRow woh qasr poora kar deta hai
    // taaki woh Master Tasdeeq mein nazar ayen.
    if (store.profile.registrationComplete) {
      await ensureDriverRow(store);
    }
    // Registration documents ki tasaveer (v1.2.8 — TASDEEQ): jo kind
    // abhi upload nahi hua (ya photo badal gayi hai) woh yahan
    // khamoshi se dobara koshish hota hai — Master har document asal
    // tasveer mein check karega, is ke baghair ID active nahi hogi.
    await syncDriverDocs(store);
    // Aaj ki selfie ki TASVEER agar pichli koshish mein upload nahi
    // ho saki thi to yahan khamoshi se dobara koshish (best-effort).
    if (store.profile.selfieToday &&
        store.profile.selfieUploadedDate != store.profile.selfieDate) {
      await _pushSelfie(store, store.profile.selfieDate);
    }
    // Master messages (v1.2.7): queued messages ki dobara koshish +
    // "Master ne parh liya" wali haalat pull.
    await syncMessages(store);
    // v1.4.0: purani unsent ratings ki dobara koshish, Master ke
    // elanaat (announcements) pull, apna rating ausat pull, aur
    // passenger ke liye pichli booking ki status snapshot ko backend
    // ki taaza haalat se seed karna. Sab best-effort — koi table/
    // column na ho to khamoshi se kuch nahi hota.
    await syncRatings(store);
    await _pullAnnouncements(store);
    await pullOwnRatingAverage(store);
    await _primePassengerRideStatuses(store);
    // v1.4.2: offline/fail shuda booking pushes ki dobara koshish
    // aur driver side ke liye backend Pool feed ki pehli list.
    await syncRideOutbox(store);
    // SABOOT: pichli koshish mein upload se reh gayi recordings.
    await syncEvidenceOutbox(store);
    await refreshRemotePool(store);
    // Master ki tasdeeq shuda fee settlements (agar koi hon) —
    // baqi fee ka hisaab taaza rahe, auto-block ghalti se na lage.
    await syncFeeSettlements(store);
    // Device binding ki jaanch (ek account = ek device).
    await syncDeviceBinding(store);
  }

  /// DEVICE BINDING ki jaanch (malik ka hukm 2026-11-08): driver
  /// ki backend row mein jo device bandhi hai woh is phone se
  /// alag ho to DEVICE TABDEELI ka waqia hai:
  ///   (a) Master ko usi maujood message raste se khabar jati hai
  ///       (driver + purani/nayi device ke saath);
  ///   (b) driver ID khud-ba-khud 6 GHANTE block ho jati hai
  ///       (deviceBlockedUntilMs — online/accept dono band);
  ///   (c) nayi device row se bandh jati hai (identity push) taaki
  ///       waqia baar baar na uthe — block phir bhi muddat tak
  ///       rehta hai aur Master use apni app mein dekhta hai.
  /// Har (driver, device) jori par waqia sirf EK dafa darj hota
  /// hai. Row mein device khaali ho (purani registration) to pehli
  /// binding khamoshi se identity push se ho jati hai — koi block
  /// nahi, koi message nahi.
  static Future<void> syncDeviceBinding(AppStore store) async {
    if (!_registered(store)) return;
    final mine = store.deviceId;
    if (mine.isEmpty || store.driverId.isEmpty) return;
    final data = await _get(
        'drivers?select=device_id&id=eq.${Uri.encodeComponent(store.driverId)}');
    if (data is! List || data.isEmpty) return;
    final row = data.first;
    if (row is! Map) return;
    final bound = row['device_id']?.toString() ?? '';
    if (bound.isEmpty || bound == mine) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      final flagKey = 'device_change_seen_${store.driverId}_$mine';
      if (prefs.getBool(flagKey) == true) return;
      await prefs.setBool(flagKey, true);
    } catch (_) {
      return;
    }
    final until =
        DateTime.now().millisecondsSinceEpoch + 6 * 3600 * 1000;
    await store.setDeviceBlockedUntil(until);
    await store.addMasterMessage(MasterMessage(
      id: store.newId(),
      senderKey: store.driverId,
      senderRole: 'driver',
      senderName: store.profile.name,
      senderMobile: store.profile.phone,
      senderZone: store.profile.zone,
      category: 'Deegar',
      body: 'DEVICE TABDEELI: Driver ${store.profile.name} '
          '(${store.profile.phone}) ka account NAYI device par khula hai. '
          'Purani (registered) device: $bound · Nayi device: $mine. '
          'Driver ID khud-ba-khud 6 ghante ke liye block kar di gayi hai.',
      createdAt: DateTime.now(),
    ));
    await _pushDriver(store);
  }

  /// Master ne jo fee settlements tasdeeq ki hain (backend ledger
  /// par is driver ki 'fee_settled' entries) unhein local feeDue
  /// par lagana. Har entry sirf EK dafa lagti hai (applied ids
  /// phone par mehfooz rahte hain). Duty-on aur app start par
  /// chalti hai — block ka khulna isi se khud-ba-khud hota hai.
  static Future<void> syncFeeSettlements(AppStore store) async {
    if (store.driverId.isEmpty) return;
    final data = await _get(
        'ledger?select=id,amount&type=eq.fee_settled&driver_id=eq.${Uri.encodeComponent(store.driverId)}');
    if (data is! List || data.isEmpty) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      final applied =
          (prefs.getStringList('fee_settled_applied') ?? <String>[])
              .toSet();
      var changed = false;
      for (final r in data) {
        if (r is Map && r['id'] is String) {
          final id = r['id'] as String;
          if (applied.contains(id)) continue;
          final amt = (r['amount'] as num?)?.toInt() ?? 0;
          if (amt > 0) {
            await store.applyFeeSettlement(amt);
            applied.add(id);
            changed = true;
          }
        }
      }
      if (changed) {
        await prefs.setStringList(
            'fee_settled_applied', applied.toList());
      }
    } catch (_) {
      // Khamosh — agli sync par dobara koshish hogi.
    }
  }

  // --- HTTP helpers (sab khamosh — fail = null/false) ------------------------

  static Future<dynamic> _get(String path) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client.getUrl(Uri.parse('$_base/$path')).timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      final resp = await req.close().timeout(_timeout);
      final body = await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode != 200) return null;
      return jsonDecode(body);
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  /// PK par upsert (insert ya update) — PostgREST merge-duplicates.
  /// Jo columns bheje jate hain sirf wohi likhe jate hain.
  static Future<bool> _upsert(String table, Map<String, dynamic> row) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req =
          await client.postUrl(Uri.parse('$_base/$table')).timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      req.headers.set('Prefer', 'resolution=merge-duplicates,return=minimal');
      req.write(jsonEncode(row));
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      return resp.statusCode >= 200 && resp.statusCode < 300;
    } catch (_) {
      return false;
    } finally {
      client?.close();
    }
  }

  /// Sirf diye hue columns ka PATCH (HOTFIX v1.2.9) — 'drivers' row
  /// par kisi EK cheez ki durusti ke liye, jab pura [_upsert] mirror
  /// chalana woh columns bhi bhej de jo is waqt ghalat/purane hon.
  /// Kamyabi par true.
  static Future<bool> _patch(String table, String id, Map<String, dynamic> fields) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client
          .patchUrl(
              Uri.parse('$_base/$table?id=eq.${Uri.encodeComponent(id)}'))
          .timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      req.headers.set('Prefer', 'return=minimal');
      req.write(jsonEncode(fields));
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      return resp.statusCode >= 200 && resp.statusCode < 300;
    } catch (_) {
      return false;
    } finally {
      client?.close();
    }
  }

  // --- Devices ---------------------------------------------------------------

  /// Har app khulne par + mode badalne par: is phone ki entry taza.
  /// first_seen sirf pehli insert par banta hai (server default).
  static Future<void> touchDevice(AppStore store, String mode) async {
    if (store.deviceId.isEmpty) return;
    await _upsert('devices', {
      'device_id': store.deviceId,
      'last_seen': DateTime.now().toUtc().toIso8601String(),
      'last_mode': mode,
      'role': mode,
      'app_version': kAppVersion,
    });
  }

  // --- Settings (Master → app, ek rukh) --------------------------------------

  static Future<void> _applyCachedSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('srv_settings_json');
      if (raw == null) return;
      final j = jsonDecode(raw);
      if (j is Map<String, dynamic>) _applySettings(j);
    } catch (_) {
      // Cache kharab ho to defaults hi sahi.
    }
  }

  static Future<void> _pullSettings() async {
    // FINAL-PACK B-PD: blocked passengers list bhi ISI settings
    // sync chakkar ke saath refresh hoti hai (defensive — table
    // na ho / backend na mile to store ki akhri maloom list hi
    // rehti hai, app kabhi nahi rukta).
    final store = _store;
    if (store != null) await refreshBlockedPassengers(store);
    final data = await _get('settings?select=*&id=eq.1');
    if (data is! List || data.isEmpty) return;
    final row = data.first;
    if (row is! Map<String, dynamic>) return;
    _applySettings(row);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('srv_settings_json', jsonEncode(row));
    } catch (_) {
      // Cache na likha jaye to koi baat nahi — values lag chuki hain.
    }
  }

  static void _applySettings(Map<String, dynamic> s) {
    Map<String, int>? intMap(dynamic v) {
      if (v is! Map) return null;
      final out = <String, int>{};
      v.forEach((k, val) {
        final n = val is num ? val.toInt() : int.tryParse('$val');
        if (n != null) out['$k'] = n;
      });
      return out;
    }

    Fares.applyServerSettings(
      feePercent: (s['fee_percent'] as num?)?.toDouble(),
      rates: intMap(s['rate_per_km']),
      waiting: intMap(s['waiting_per_min']),
      freeWaitingMin: (s['free_waiting_min'] as num?)?.toInt(),
      deposit: (s['joining_deposit'] as num?)?.toInt(),
      // PILOT: deposit_enabled column (migration v131) abhi na ho
      // to null — pilot default (band) hi rehta hai.
      depositEnabled: s['deposit_enabled'] is bool
          ? s['deposit_enabled'] as bool
          : null,
      feeSettleLimit: (s['fee_settle_limit'] as num?)?.toInt(),
      // PTA TOGGLE: pta_required column (migration v133) abhi na
      // ho to null — default band (IMEI ikhtiyari) hi rehta hai.
      ptaRequired:
          s['pta_required'] is bool ? s['pta_required'] as bool : null,
    );

    // UPDATE GATE (v1.4.8, migration v138): Master ki haddien +
    // update link. Columns abhi na hon to null — gate band (0)
    // rehta hai, app aam chalti hai.
    UpdatePolicy.apply(
      mandatory: (s['min_mandatory_version'] as num?)?.toInt(),
      recommended: (s['min_recommended_version'] as num?)?.toInt(),
      url: s['update_url'] is String ? s['update_url'] as String : null,
    );
    // UI ko foran taza karo — mandatory screen ya recommended
    // banner settings ate hi laago ho jaye.
    _store?.onServerPolicyChanged();
  }


  /// Settings ka taaza pull — app resume par UPDATE GATE ki
  /// dobara jaanch ke liye (main.dart bulata hai). Khamosh
  /// best-effort: offline par kuch nahi hota.
  static Future<void> refreshSettings() => _pullSettings();

  /// APP VERSION REPORT (v1.4.8, migration v138): driver login /
  /// duty-on par is build ka version CODE backend drivers row ke
  /// `app_version` column mein darj hota hai — Master ko nazar
  /// ata hai ke kaun sa driver kis version par hai. Column abhi
  /// na ho to PATCH 400 se khamoshi se fail (guarded) — app
  /// kabhi nahi rukti.
  static Future<void> reportAppVersion(AppStore store) async {
    if (!_registered(store)) return;
    try {
      await _patch('drivers', store.driverId, {
        'app_version': kAppVersionCode,
      });
    } catch (_) {
      // _patch khud kabhi throw nahi karta — ye aakhri hifazat hai.
    }
  }

  // --- Blocked passengers (FINAL-PACK B-PD) ----------------------------------
  //
  // Master jin passenger numbers ko band karta hai woh backend
  // `blocked_passengers` table mein hain. Usool sakht defensive
  // hai: table na ho, column naam alag ho, ya backend tak pahuncha
  // hi na jaye — har surat mein app NAHI girta; fetch khaali list
  // deta hai aur refresh store ki purani list ko NAHI chherta jab
  // tak asal jawab na aye.

  /// Blocked passengers ke mobile numbers — asal fetch (jawab hi
  /// na aye to null, taaki caller purani list mehfooz rakh sake).
  static Future<List<String>?> _fetchBlockedOrNull() async {
    try {
      var data = await _get('blocked_passengers?select=mobile');
      if (data is! List) {
        // Column ka naam mukhtalif ho sakta hai — poori row ki
        // koshish; phir bhi na mile to null (error wali surat).
        data = await _get('blocked_passengers?select=*');
      }
      if (data is! List) return null;
      final out = <String>[];
      for (final r in data) {
        if (r is Map) {
          final v = r['mobile'] ??
              r['phone'] ??
              r['passenger_mobile'] ??
              r['number'];
          if (v != null && v.toString().trim().isNotEmpty) {
            out.add(v.toString().trim());
          }
        }
      }
      return out;
    } catch (_) {
      return null;
    }
  }

  /// Blocked passengers ki list — table/error ki har surat mein
  /// khaali list (kabhi crash nahi).
  static Future<List<String>> fetchBlockedPassengers() async {
    return await _fetchBlockedOrNull() ?? const <String>[];
  }

  /// Blocked list ko store mein taza karna — settings sync
  /// chakkar (_pullSettings) aur booking se pehle ka check
  /// (passenger.dart) yahi bulate hain. Jawab hi na aye to store
  /// ki akhri maloom list barkarar rehti hai.
  static Future<void> refreshBlockedPassengers(AppStore store) async {
    try {
      final list = await _fetchBlockedOrNull();
      if (list != null) store.applyBlockedPassengers(list);
    } catch (_) {
      // Khamosh — purani list hi chalti hai.
    }
  }

  // --- Zones -----------------------------------------------------------------

  /// Server par band (open=false) zone passenger ki list se nikal jata
  /// hai. Server khaali mile to local [kZones] hi rehte hain.
  ///
  /// SIRF woh sheher dikhte hain jo local [kZones] mein hain — server
  /// sirf un ki KHULA/BAND haalat batata hai. Server par purani
  /// Karachi-ilaqa wali rows abhi baqi hain (aur Master koi aisa naam
  /// bhi bhej sakta hai jis ka is app mein map coordinate nahi) —
  /// aise na-waqif naam is list mein NAHI ate, warna passenger purane
  /// ilaqe dobara dekh leta (owner ka hukm 2026-11-07: zones = sirf
  /// Pakistan ke sheher).
  static Future<void> _pullZones(AppStore store) async {
    final data = await _get('zones?select=name,open');
    if (data is! List || data.isEmpty) return;
    final openByName = <String, bool>{};
    for (final r in data) {
      if (r is Map && r['name'] is String) {
        openByName[r['name'] as String] = r['open'] == true;
      }
    }
    if (openByName.isEmpty) return;
    final visible = <String>[
      ...kZones.where((z) => openByName[z] != false),
    ];
    store.applyServerZones(visible);
  }

  // --- Driver ----------------------------------------------------------------

  /// Registration tabhi mana jata hai jab profile mein naam + mobile
  /// dono mojood hon (Profile Save se ate hain).
  static bool _registered(AppStore store) =>
      store.driverId.isNotEmpty &&
      store.profile.name.trim().isNotEmpty &&
      store.profile.phone.trim().isNotEmpty;

  /// Driver row ka pura mirror — registration (status pending: active
  /// hamesha akhri maloom Master value hi bhejte hain taaki Master ki
  /// ACTIVE tasdeeq is upsert se mit na jaye), online/offline,
  /// wallet balance. Documents ki STATUS (cnic/licence/gaari_status)
  /// is mirror mein NAHI jati — woh Master-owned hai (neeche note).
  static Future<void> _pushDriver(AppStore store) async {
    if (!_registered(store)) return;
    final p = store.profile;
    final row = <String, dynamic>{
      'id': store.driverId,
      'name': p.name,
      'mobile': p.phone,
      'vehicle': p.vehicle,
      'plate': p.plate,
      'zone': p.zone,
      'active': p.masterActive,
      'online': p.online,
      'on_ride': store.bookings
          .any((b) => b.status == 'accepted' || b.status == 'arrived'),
      // HOTFIX v1.2.9: cnic_status / licence_status / gaari_status
      // ab MASTER-OWNED hain — driver app in columns ko KABHI nahi
      // bhejti. Pehle har _pushDriver Master ke Tasdeeq/Reject faisle
      // ko local (hamesha 'pending'/'rejected'-lagne wale) values se
      // overwrite kar deta tha. Ab ye sirf Master PATCH se badalte
      // hain; driver app inhein sirf refreshDriverStatus se PULL
      // karke Profile mein dikhati hai.
      'wallet_balance': p.walletBalance,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    };
    // Driver ki akhri GPS jagah — schema ke lat/lng columns pehle se
    // maujood hain (Master map inhi se asal jagah dikhata hai). Sirf
    // tab bhejte hain jab position maloom ho: null bhej kar kisi
    // purani achhi value ko kabhi mitaya nahi jata.
    if (p.lastLat != null && p.lastLng != null) {
      row['lat'] = p.lastLat;
      row['lng'] = p.lastLng;
    }
    // Password ka sirf FINGERPRINT (v1.2.5) — asal password kabhi
    // network par nahi jata. Sirf tab bhejte hain jab set ho.
    if (p.pwdFp.isNotEmpty) {
      row['pwd_fp'] = p.pwdFp;
    }
    // DEVICE BINDING (2026-11-08, migration v131): is phone ki
    // device id driver ki row se bandhi jati hai — ek account,
    // ek device. device_blocked_until tab jata hai jab device
    // tabdeeli par 6-ghante block laga ho (Master ko nazar aye).
    if (store.deviceId.isNotEmpty) row['device_id'] = store.deviceId;
    if (p.deviceBlockedUntilMs > 0) {
      row['device_blocked_until'] = DateTime.fromMillisecondsSinceEpoch(
              p.deviceBlockedUntilMs,
              isUtc: true)
          .toIso8601String();
    }
    // Registration wizard (v1.2.6) ki tafseel — columns migration
    // backend-migration-v126.sql se bante hain. Sirf bhari hui values
    // bhejte hain (khaali bhej kar purani value nahi mitate).
    // (v1.2.8: document tasaveer ab Storage bucket 'driver-docs'
    // mein bhi jati hain — neeche wale *_path columns dekhein.)
    if (p.cnicNumber.isNotEmpty) row['cnic_number'] = p.cnicNumber;
    if (p.licenceNumber.isNotEmpty) {
      row['licence_number'] = p.licenceNumber;
    }
    if (p.vehicleBrand.isNotEmpty) row['vehicle_brand'] = p.vehicleBrand;
    if (p.vehicleModel.isNotEmpty) row['vehicle_model'] = p.vehicleModel;
    if (p.vehicleYear > 0) row['vehicle_year'] = p.vehicleYear;
    if (p.vehicleColor.isNotEmpty) row['vehicle_color'] = p.vehicleColor;
    // Registration documents ke backend object paths (v1.2.8) — sirf
    // us kind ka path jata hai jis ki tasveer asal mein upload ho
    // chuki hai (docUploaded marker maujood hai); path ka pattern
    // tay hai: <driver_id>/<kind>.jpg. Columns migration
    // backend-migration-v128.sql se bante hain.
    String? docPath(String kind) =>
        (p.docUploaded[kind]?.isNotEmpty ?? false)
            ? '${store.driverId}/$kind.jpg'
            : null;
    final cnicFront = docPath('cnic_front');
    if (cnicFront != null) row['cnic_front_path'] = cnicFront;
    final cnicBack = docPath('cnic_back');
    if (cnicBack != null) row['cnic_back_path'] = cnicBack;
    final vehiclePhoto = docPath('vehicle');
    if (vehiclePhoto != null) row['vehicle_photo_path'] = vehiclePhoto;
    final vehicleReg = docPath('vehicle_reg');
    if (vehicleReg != null) row['vehicle_reg_path'] = vehicleReg;
    final licencePhoto = docPath('licence');
    if (licencePhoto != null) row['licence_photo_path'] = licencePhoto;
    // PTA Proof — IMEI (2026-11-08): driver ne form mein jo IMEI
    // likha woh drivers.imei (migration v131) mein jata hai —
    // Master Tasdeeq mein usi ko check karta hai.
    if (p.imei.trim().isNotEmpty) row['imei'] = p.imei.trim();
    // AGENT CODE (v1.4.6, migration v136): driver kis agent ke
    // zariye aya. Sirf tab jata hai jab wizard mein kisi ACTIVE
    // agent ka code tasdeeq ho kar profile mein darj hua ho.
    // Column abhi na ho to neeche wala retry isay bhi gira deta
    // hai (v131Keys wali list mein shamil hai).
    if (p.agentCode.isNotEmpty) row['agent_code'] = p.agentCode;
    final profilePhoto = docPath('profile');
    if (profilePhoto != null) row['profile_photo_path'] = profilePhoto;
    // Dobara-bhejna (resubmit) ke timestamps (v1.4.1 + migration
    // v130): ye *_status NAHI hain — sirf "reject ke baad nayi
    // photo a gayi" ka nishan; database ka trigger in ke badalne
    // par mutaliqa status khud 'pending' kar deta hai. Sirf tab
    // jate hain jab syncDriverDocs ne koi resubmit darj kiya ho —
    // aam pushes mein ye columns bilkul NAHI jate (aur *_status /
    // *_reject_reason is mirror mein pehle ki tarah KABHI nahi
    // jate — woh Master-owned hain).
    final resubmits = p.docResubmitAt;
    if (resubmits['cnic'] != null) {
      row['cnic_resubmit_at'] = resubmits['cnic'];
    }
    if (resubmits['gaari'] != null) {
      row['gaari_resubmit_at'] = resubmits['gaari'];
    }
    if (resubmits['licence'] != null) {
      row['licence_resubmit_at'] = resubmits['licence'];
    }
    if (resubmits['pta'] != null) {
      row['pta_resubmit_at'] = resubmits['pta'];
    }
    // SHARAIT KI QUBOOLIYAT (v1.4.4, migration v134): driver ne
    // registration ke aakhir mein Sharait kab qabool keen — us ka
    // waqt Master ke saboot ke liye drivers.terms_accepted_at
    // mein jata hai. Column abhi na ho to neeche wala retry isay
    // nikaal kar baqi mirror bhej deta hai.
    if (p.termsAcceptedAtMs > 0) {
      row['terms_accepted_at'] = DateTime.fromMillisecondsSinceEpoch(
              p.termsAcceptedAtMs,
              isUtc: true)
          .toIso8601String();
    }
    // NUMBER TABDEELI BLOCK (2026-11-08, migration v131): number
    // badalne par 12-ghante block ki muddat Master ko bhi nazar
    // ani chahiye.
    if (p.numberBlockedUntilMs > 0) {
      row['number_blocked_until'] = DateTime.fromMillisecondsSinceEpoch(
              p.numberBlockedUntilMs,
              isUtc: true)
          .toIso8601String();
    }
    // v131 ke NAYE columns (pta_photo_path, pta_resubmit_at,
    // number_blocked_until, device_id, device_blocked_until) row
    // mein hon aur migration abhi NA lagi ho to poora upsert fail
    // hoga — us surat mein sirf naye columns nikaal kar dobara
    // bhej dete hain taake identity sync (baqi tamam fields) kabhi
    // na ruke. Migration lag jane ke baad pehli koshish hi kamyab.
    if (await _upsert('drivers', row)) return;
    const v131Keys = [
      'imei',
      'pta_resubmit_at',
      'number_blocked_until',
      'device_id',
      'device_blocked_until',
      // v134: Sharait qubooliyat ka waqt bhi isi retry se girta
      // hai jab migration abhi na lagi ho.
      'terms_accepted_at',
      // v136: agent_code bhi isi retry se girta hai jab migration
      // abhi na lagi ho.
      'agent_code',
    ];
    if (row.keys.any(v131Keys.contains)) {
      row.removeWhere((k, _) => v131Keys.contains(k));
      await _upsert('drivers', row);
    }
  }

  /// EK CNIC = EK ACCOUNT (malik ka hukm 2026-11-08): ye CNIC
  /// kisi AUR driver ki row mein pehle se darj hai ya nahi.
  /// Account shakhs (CNIC) ka hota hai, number/SIM ka nahi — is
  /// liye doosra/fake account CNIC wale qadam par hi rukta hai.
  /// Returns: true = CNIC pehle se istemal shuda (reject);
  /// false = khaali (ya sirf is driver ki apni row); null =
  /// backend tak pahuncha nahi — caller check ko pass NAHI
  /// samajhta (password check wala hi usool).
  /// Format ka farq (dashes hon ya na hon) ghair-mutaliq hai —
  /// sirf 13 digits milaye jate hain.
  static Future<bool?> cnicTakenByOther(
      String cnicDigits, String ownDriverId) async {
    if (cnicDigits.length != 13) return false;
    final data =
        await _get('drivers?select=id,cnic_number&cnic_number=not.is.null');
    if (data is! List) return null;
    for (final r in data) {
      if (r is Map) {
        final digits = (r['cnic_number']?.toString() ?? '')
            .replaceAll(RegExp(r'[^0-9]'), '');
        if (digits == cnicDigits &&
            r['id']?.toString() != ownDriverId) {
          return true;
        }
      }
    }
    return false;
  }

  /// Password UNIQUENESS check (v1.2.5): is fingerprint ke saath koi
  /// AUR driver backend par pehle se hai ya nahi.
  /// Returns: true = kisi aur ne ye password lagaya hua hai;
  /// false = khaali hai (ya sirf is driver ki apni row hai);
  /// null = backend tak pahuncha hi nahi (offline/error) — us surat
  /// mein check ko "pass" NAHI samjha jata; caller registration ko
  /// rok kar internet ka kehta hai.
  static Future<bool?> passwordFingerprintTaken(
      AppStore store, String fp) async {
    final data = await _get(
        'drivers?select=id&pwd_fp=eq.${Uri.encodeComponent(fp)}');
    if (data is! List) return null;
    for (final r in data) {
      if (r is Map && r['id'] != store.driverId) return true;
    }
    return false;
  }

  /// Master ne driver ko ACTIVE kiya hai ya nahi — app khulne par aur
  /// Profile ki refresh dabane par pull hota hai. Duty ka taala SIRF
  /// yahi [masterActive] hai — app apne aap ko KABHI active nahi
  /// karti; documents upload ho jana activation NAHI hai.
  /// Saath mein Master ki tasdeeq ki haalat (v1.2.8) bhi ati hai —
  /// sirf Profile ke display ke liye ('rejected' samait har value
  /// mehfooz hoti hai; koi local gate is se nahi badalta).
  static Future<void> refreshDriverStatus(AppStore store) async {
    if (store.driverId.isEmpty) return;
    // v1.4.1: pehle v130 ke wajah-columns ke saath pull — migration
    // abhi na lagi ho to woh SELECT fail hoga (data null), tab
    // purane columns par gir jate hain taaki masterActive/statuses
    // ka pull kabhi na ruke. Wajah us surat mein khaali rehti hai.
    // FINAL-PACK C-PD: must_change_password bhi isi pull mein ata
    // hai — column abhi na laga ho to ye SELECT fail hoga (data
    // null) aur neeche wale purane columns par gir jayenge; us
    // surat mein flag false hi rehta hai (defensive parse).
    var data = await _get(
        'drivers?select=active,cnic_status,gaari_status,licence_status,pta_status,cnic_reject_reason,gaari_reject_reason,licence_reject_reason,pta_reject_reason,must_change_password&id=eq.${Uri.encodeComponent(store.driverId)}');
    if (data is! List) {
      data = await _get(
          'drivers?select=active,cnic_status,gaari_status,licence_status&id=eq.${Uri.encodeComponent(store.driverId)}');
    }
    if (data is! List || data.isEmpty) return;
    final row = data.first;
    if (row is Map) {
      store.setMasterActive(row['active'] == true);
      String st(String key) => row[key] is String ? row[key] as String : '';
      await store.applyMasterDocStatuses(
        cnic: st('cnic_status'),
        gaari: st('gaari_status'),
        licence: st('licence_status'),
        cnicReason: st('cnic_reject_reason'),
        gaariReason: st('gaari_reject_reason'),
        licenceReason: st('licence_reject_reason'),
        pta: st('pta_status'),
        ptaReason: st('pta_reject_reason'),
      );
      // FINAL-PACK C-PD: aarzi-password wala flag — key mojood
      // ho aur true ho tabhi true; column na ho (fallback pull)
      // ya value kuch aur ho to false.
      store.setMustChangePassword(row['must_change_password'] == true);
    }
    // v1.4.7: v137 wale naye fields (email + gaari change ki
    // haalat) ka ALAG guarded pull — columns abhi na hon to ye
    // khamoshi se kuch nahi karta, upar wala asal pull is se
    // kabhi mutasir nahi hota.
    final v137 = await fetchDriverFields(store.driverId,
        'email,email_verified_at,vehicle_change,vehicle_change_status,vehicle_change_reason,vehicle_history');
    if (v137 != null) {
      await store.applyV137DriverFields(v137);
    }
  }

  // --- Store hooks → backend rows ---------------------------------------------

  static void _onHook(String kind, Object? payload) {
    final store = _store;
    if (store == null) return;
    switch (kind) {
      case 'booking':
        if (payload is Booking) unawaited(_pushRide(store, payload));
        break;
      case 'package':
        if (payload is MonthlyPackage) unawaited(_pushPackage(store, payload));
        break;
      case 'txn':
        if (payload is WalletTxn) unawaited(_pushLedger(store, payload));
        break;
      case 'profile':
        unawaited(_pushDriver(store));
        // Registration submit bhi isi hook se ata hai (store.save) —
        // document tasaveer bhi isi ke saath Master tak jati hain.
        unawaited(syncDriverDocs(store));
        // RC2 follow-through (v1.2.9): registration mukammal hote
        // hi drivers row durust tor par mojood hona bhi isi hook se
        // pakka hota hai (row na ho to banti hai, ho to registration
        // fields PATCH ho jate hain).
        if (store.profile.registrationComplete) {
          unawaited(ensureDriverRow(store));
        }
        break;
      case 'selfie':
        if (payload is String) unawaited(_pushSelfie(store, payload));
        break;
      case 'message':
        if (payload is MasterMessage) {
          unawaited(_pushMessage(store, payload));
        }
        break;
      case 'rating':
        if (payload is RideRating) {
          unawaited(_pushRating(store, payload));
        }
        break;
      case 'location':
        // Driver ki duty-wali live jagah — SIRF lat/lng/loc_at ki
        // halki PATCH (pura mirror nahi). Columns na hon (v129 se
        // pehle ki DB) to PATCH khamoshi se fail ho jata hai.
        unawaited(_pushDriverLocation(store));
        break;
    }
  }

  // --- Master messages (v1.2.7) ------------------------------------------------

  /// Ek message backend `messages` table mein bhejna. Kamyabi par
  /// store mein "sent" darj ho jata hai; nakami par message queued
  /// rehta hai aur [syncMessages] agli dafa dobara koshish karta hai —
  /// UI kabhi nahi rukti, koi error nahi dikhta.
  static Future<void> _pushMessage(AppStore store, MasterMessage m) async {
    final ok = await _upsert('messages', {
      'id': m.id,
      'sender_key': m.senderKey,
      'sender_role': m.senderRole,
      'sender_name': m.senderName,
      'sender_mobile': m.senderMobile,
      'sender_zone': m.senderZone,
      'category': m.category,
      'body': m.body,
      'is_read': m.isRead,
      'created_at': m.createdAt.toUtc().toIso8601String(),
    });
    if (ok) await store.markMessageSent(m.id);
  }

  /// Queued (abhi tak na bheje gaye) messages ki dobara koshish, phir
  /// apne tamam messages ki is_read haalat pull — app start par aur
  /// Master Messages screen khulne par chalti hai. Sab best-effort.
  static Future<void> syncMessages(AppStore store) async {
    for (final m in store.masterMessages.where((m) => !m.sent).toList()) {
      await _pushMessage(store, m);
    }
    final keys = <String>{
      for (final m in store.masterMessages)
        if (m.senderKey.isNotEmpty) m.senderKey,
    };
    for (final key in keys) {
      final data = await _get(
          'messages?select=id,is_read&sender_key=eq.${Uri.encodeComponent(key)}');
      if (data is! List) continue;
      for (final r in data) {
        if (r is Map && r['id'] is String) {
          await store.applyMessageRead(
              r['id'] as String, r['is_read'] == true);
        }
      }
    }
    // LIVE CHAT (owner 2026-11-08): Master ke jawabat bhi isi
    // chakkar se pull hote hain (fetchMyThread) — chat screen,
    // startup aur dono sides ke poll timers yahi bulate hain.
    await fetchMyThread(store);
  }

  /// LIVE CHAT — is phone ki har pehchan (driverId + deviceId +
  /// messages mein mojood keys) ke liye messages table se POORA
  /// thread pull: meri apni rows AUR Master ki jawab rows
  /// (sender_role='master', sender_key = meri wohi key — yehi
  /// mushtarka PROTOCOL hai). Rows store.applyThreadMessages
  /// mein jati hain jahan naya jawab notification bhi banta hai.
  /// Table/row na mile to khamosh — chat local list par rehti hai.
  static Future<void> fetchMyThread(AppStore store) async {
    final keys = <String>{
      if (store.driverId.isNotEmpty) store.driverId,
      if (store.deviceId.isNotEmpty) store.deviceId,
      for (final m in store.masterMessages)
        if (m.senderKey.isNotEmpty) m.senderKey,
    };
    for (final key in keys) {
      final data = await _get(
          'messages?select=*&sender_key=eq.${Uri.encodeComponent(key)}&order=created_at.asc');
      if (data is! List) continue;
      final rows = <MasterMessage>[];
      for (final r in data) {
        if (r is! Map) continue;
        final id = r['id']?.toString() ?? '';
        if (id.isEmpty) continue;
        rows.add(MasterMessage(
          id: id,
          senderKey: r['sender_key']?.toString() ?? key,
          senderRole: r['sender_role']?.toString() ?? '',
          senderName: r['sender_name']?.toString() ?? '',
          senderMobile: r['sender_mobile']?.toString() ?? '',
          senderZone: r['sender_zone']?.toString() ?? '',
          category: r['category']?.toString() ?? '',
          body: r['body']?.toString() ?? '',
          isRead: r['is_read'] == true,
          sent: true,
          createdAt:
              DateTime.tryParse(r['created_at']?.toString() ?? '') ??
                  DateTime.now(),
        ));
      }
      await store.applyThreadMessages(key, rows);
    }
  }

  // --- SABOOT (EVIDENCE) audio (owner 2026-11-08) -----------------------------
  //
  // Recording driver-docs bucket mein jati hai — wohi Storage
  // upload pattern jo registration documents ka hai
  // (_uploadDocImage: POST /object/<bucket>/<path>, x-upsert).
  // Path ka format tay hai: evidence/<ride_id>/<role>_<timestamp>
  // .m4a (recorder .aac de to .aac). Koi signed URL NAHI banta —
  // Master bucket se khud parhta hai; phone par dobara sunne ke
  // liye LOCAL file hi asal rasta hai.

  /// Ek saboot recording file backend par upload karna. Kamyabi
  /// par bucket ke andar ka object path, nakami par null.
  static Future<String?> uploadEvidenceAudio(
      String rideId, String role, File file) async {
    HttpClient? client;
    try {
      if (!await file.exists()) return null;
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) return null;
      final ext = file.path.toLowerCase().endsWith('.aac') ? 'aac' : 'm4a';
      final ts = DateTime.now().millisecondsSinceEpoch;
      final objectPath = 'evidence/$rideId/${role}_$ts.$ext';
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client
          .postUrl(Uri.parse('$_storageBase/object/driver-docs/$objectPath'))
          .timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader,
          ext == 'aac' ? 'audio/aac' : 'audio/mp4');
      req.headers.set('x-upsert', 'true');
      req.add(bytes);
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode >= 200 && resp.statusCode < 300) {
        return objectPath;
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  /// Saboot file ka public storage URL — dobara sunne ki
  /// koshish ke liye (bucket public ho tabhi chalta hai; warna
  /// local file hi asal playback rasta hai — caller error par
  /// saaf snack deta hai).
  static String evidencePublicUrl(String remotePath) =>
      '$_storageBase/object/public/driver-docs/$remotePath';

  /// Master ko saboot ki CANONICAL khabar — messages table se
  /// Master inbox + timeline mein jati hai (category 'Saboot
  /// Recording'). Booking par flag lag jata hai taaki upload ki
  /// dobara koshishon par ye khabar duplicate NA ho.
  static Future<void> notifyMasterEvidence(
      AppStore store, Booking b, String remotePath) async {
    if (b.evidenceMasterNotified) return;
    b.evidenceMasterNotified = true;
    final isDriver = b.evidenceBy == 'driver';
    await store.addMasterMessage(MasterMessage(
      id: store.newId(),
      senderKey: isDriver ? store.driverId : store.deviceId,
      senderRole: isDriver ? 'driver' : 'passenger',
      senderName: isDriver ? store.profile.name : b.passengerName,
      senderMobile: isDriver ? store.profile.phone : b.passengerPhone,
      senderZone: isDriver ? store.profile.zone : '',
      category: 'Saboot Recording',
      body: 'Saboot recording aayi hai — Ride: ${b.pickupLabel} → '
          '${b.dropLabel}, record karne wala: '
          '${isDriver ? 'Driver ${store.profile.name}' : 'Passenger ${b.passengerName}'}, '
          'file: $remotePath',
      createdAt: DateTime.now(),
    ));
  }

  /// Upload se reh gayi saboot recordings ki dobara koshish
  /// (app start par): local file mojood ho aur remote rasta abhi
  /// khaali ho to upload + record par nishan + Master ko khabar.
  static Future<void> syncEvidenceOutbox(AppStore store) async {
    for (final b in store.bookings.toList()) {
      if (b.evidenceLocalPath.isEmpty || b.evidenceRemotePath.isNotEmpty) {
        continue;
      }
      final remote = await uploadEvidenceAudio(
          b.id, b.evidenceBy.isEmpty ? 'passenger' : b.evidenceBy,
          File(b.evidenceLocalPath));
      if (remote == null) continue;
      await store.markEvidenceUploaded(b, remote);
      await notifyMasterEvidence(store, b, remote);
    }
  }

  static Future<void> _pushRide(AppStore store, Booking b) async {
    // v1.4.2 DISPATCH FIX: pickup/drop COORDINATES bhi bhejte hain
    // (migration v131 ke columns) — in ke baghair doosre phone ke
    // driver ko 2 km filter aur route map chal hi nahi sakta tha.
    // Migration abhi na lagi ho to pehli koshish (coordinates ke
    // saath) fail hogi — tab baghair coordinates ke dobara koshish
    // hoti hai taaki ride push kabhi na ruke (purani haalat par
    // bhi booking server tak lazmi pahunche).
    final row = <String, dynamic>{
      'id': b.id,
      // Booking sirf passenger banata hai; driver tab jodta hai jab
      // is phone ke driver ne use qubool kiya ho. Remote se qubool
      // shuda ride par asal driver id hi rehta hai.
      'driver_id':
          (b.status == 'pending' || b.status == 'cancelled')
              ? ''
              : (b.assignedDriverId.isNotEmpty
                  ? b.assignedDriverId
                  : store.driverId),
      'passenger_name': b.passengerName,
      'passenger_mobile': b.passengerPhone,
      'pickup': b.pickupLabel,
      'drop_off': b.dropLabel,
      'vehicle': b.vehicle,
      'km': b.distanceKm,
      'waiting_minutes': b.waitingMinutes,
      'fare': b.fare,
      'waiting_charges': b.waitingCharge,
      'fee': b.status == 'completed'
          ? Fares.serviceFee(b.fare + b.waitingCharge)
          : 0,
      'status': b.status,
      'date': b.createdAt.toUtc().toIso8601String(),
    };
    var ok = await _upsert('rides', {
      ...row,
      'pickup_lat': b.pickupLat,
      'pickup_lng': b.pickupLng,
      'drop_lat': b.dropLat,
      'drop_lng': b.dropLng,
      if (b.note.isNotEmpty) 'note': b.note,
      // v1.4.4 LEGAL + SAFETY (migration v134): cancel / early-
      // complete ki WAJAH aur driver ki sawari ko rating. Ye
      // columns abhi na lage hon to pehli koshish fail hogi aur
      // neeche wali baghair-in-ke koshish ride ko rokegi nahi —
      // wajah us surat mein sirf phone ke record mein rehti hai.
      if (b.cancelReason.isNotEmpty) 'cancel_reason': b.cancelReason,
      if (b.endReason.isNotEmpty) 'end_reason': b.endReason,
      if (b.endedEarly) 'ended_early': true,
      if (b.passengerRating > 0) 'passenger_rating': b.passengerRating,
      // SABOOT (owner 2026-11-08): upload shuda saboot ka storage
      // rasta rides row par bhi (column na ho to ye pehli koshish
      // fail hogi aur neeche wali baghair-is-ke koshish ride push
      // ko rokegi nahi — asal saboot khabar messages se jati hai).
      if (b.evidenceRemotePath.isNotEmpty)
        'evidence_path': b.evidenceRemotePath,
    });
    if (!ok) {
      ok = await _upsert('rides', row);
    }
    if (ok) await _markRidePushed(b);
    // v1.4.7 RIDE START CODE (spec §3): code alag guarded PATCH se
    // jata hai (v137 column) — upsert row mein shamil NAHI, taaki
    // column na hone par ride push kabhi na ruke. Do-phone mode
    // mein driver code isi se parhta hai.
    if (ok && b.startCode > 0) {
      unawaited(pushRideStartCode(b.id, b.startCode));
    }
    if (ok && b.rideStarted) {
      unawaited(pushRideStarted(b.id));
    }
  }

  /// Ride ki push-haalat ka nishan — sirf status nahi: v1.4.4 se
  /// wajah/rating ki tabdeeli (status wohi rehne par bhi) dobara
  /// push ki wajah banti hai, warna complete ke baad di gayi
  /// rating ya wajah backend tak kabhi nahi pohanchti thi.
  static String _ridePushSig(Booking b) =>
      '${b.status}|${b.passengerRating}|${b.cancelReason}|${b.endReason}|${b.endedEarly}|${b.evidenceRemotePath}';

  // --- Ride outbox (v1.4.2) ----------------------------------------------------
  //
  // DISPATCH-AUDIT Sawal 6 ka fix: booking ka backend push pehle
  // single-shot tha — offline bani booking server par KABHI nahi
  // jati thi. Ab har kamyab push ka (id → status) nishan mehfooz
  // rehta hai; startup par jo booking apni mojooda haalat ke
  // saath push nahi hui, woh dobara bheji jati hai.

  static const String _ridePushKey = 'ride_push_state_v1';

  static Future<Map<String, String>> _ridePushState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_ridePushKey);
      if (raw == null) return {};
      final j = jsonDecode(raw);
      if (j is Map) {
        return j.map((k, v) => MapEntry('$k', '$v'));
      }
    } catch (_) {
      // Cache kharab ho to khaali — dobara pushes se khud theek.
    }
    return {};
  }

  static Future<void> _markRidePushed(Booking b) async {
    try {
      final state = await _ridePushState();
      final sig = _ridePushSig(b);
      if (state[b.id] == sig) return;
      state[b.id] = sig;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_ridePushKey, jsonEncode(state));
    } catch (_) {
      // Nishan na lage to agli sync par dobara koshish hogi.
    }
  }

  /// Startup/reconnect par: jo local bookings apni mojooda haalat
  /// (status + wajah + rating) ke saath backend tak nahi gayin,
  /// unhein dobara bhejna. (Purane nishan sirf status the — woh
  /// naye signature se match nahi karte, is liye pehli dafa har
  /// booking ek martaba dobara push hoti hai; nuqsan koi nahi,
  /// upsert wohi row update karta hai.)
  static Future<void> syncRideOutbox(AppStore store) async {
    final state = await _ridePushState();
    for (final b in store.bookings.toList()) {
      if (state[b.id] != _ridePushSig(b)) {
        await _pushRide(store, b);
      }
    }
  }

  static Future<void> _pushPackage(AppStore store, MonthlyPackage p) async {
    await _upsert('packages', {
      'id': p.id,
      'driver_id': '',
      'customer_name': p.passengerName,
      'customer_mobile': '',
      'pickup': p.pickup,
      'drop_off': p.drop,
      'vehicle': p.vehicle,
      'km': p.routeKm,
      'days': p.days,
      'amount': p.monthlyAmount,
      'fee': Fares.serviceFee(p.monthlyAmount),
      'date': p.createdAt.toUtc().toIso8601String(),
    });
  }

  static Future<void> _pushLedger(AppStore store, WalletTxn t) async {
    // Schema ke ledger mein balance ka column NAHI hai — is liye
    // balance-after note ke aakhir mein likha jata hai. Deposit
    // positive, service-charges ki katauti negative jati hai taaki
    // Master mein kul hisaab seedha jumla ho sake.
    await _upsert('ledger', {
      'id': t.id,
      'ts': t.date.toUtc().toIso8601String(),
      'type': t.type,
      'driver_id': store.driverId,
      'amount': t.type == 'fee' ? -t.amount : t.amount,
      'note': '${t.note} · Balance: ${rs(store.profile.walletBalance)}',
    });
  }

  /// Rozana selfie (v1.2.5): pehle (driver_id, date, done) wali CHECK
  /// row — wohi jo Master pehle se parhta hai — phir asal TASVEER
  /// Storage bucket 'selfies' mein upload karke us ka path
  /// driver_selfies.image_path mein darj hota hai, taaki Master par
  /// driver ki rozana selfie asal mein bhi nazar aye. Tasveer ka
  /// upload hamesha best-effort hai: nakami par selfieUploadedDate
  /// set NAHI hota, agli sync/startup par khud dobara koshish hoti
  /// hai — duty kabhi is par nahi rukti.
  static Future<void> _pushSelfie(AppStore store, String date) async {
    if (store.driverId.isEmpty || date.isEmpty) return;
    await _upsert('driver_selfies', {
      'driver_id': store.driverId,
      'date': date,
      'done': true,
    });
    final p = store.profile;
    if (p.selfieDate != date || p.selfieUploadedDate == date) return;
    if (p.selfiePath.isEmpty) return;
    final path = await _uploadSelfieImage(store);
    if (path == null) return;
    final recorded = await _upsert('driver_selfies', {
      'driver_id': store.driverId,
      'date': date,
      'done': true,
      'image_path': path,
    });
    // Path darj na ho saka ho to "uploaded" bhi nahi kehte — agli
    // sync par dobara koshish hogi.
    if (recorded) await store.markSelfieUploaded(date);
  }

  /// Selfie ki tasveer Storage bucket 'selfies' mein:
  /// path = selfies/<driver_id>/<yyyy-mm-dd>.jpg (upsert — dobara
  /// upload ho to wohi file taza ho jati hai). Safalta par object
  /// path, nakami par null. Bucket + policies migration
  /// backend-migration-v125.sql se bante hain.
  static Future<String?> _uploadSelfieImage(AppStore store) async {
    HttpClient? client;
    try {
      final file = File(store.profile.selfiePath);
      if (!await file.exists()) return null;
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) return null;
      final objectPath =
          '${store.driverId}/${store.profile.selfieDate}.jpg';
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client
          .postUrl(Uri.parse('$_storageBase/object/selfies/$objectPath'))
          .timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'image/jpeg');
      req.headers.set('x-upsert', 'true');
      req.add(bytes);
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode >= 200 && resp.statusCode < 300) {
        return objectPath;
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  /// Abhi liye/set kiye hue password ka fingerprint backend drivers
  /// row par foran darj karna (v1.2.9 follow-through) — duty-on par
  /// _SetPasswordDialog ke baad driver.dart yahan se bulata hai.
  /// Sirf pwd_fp PATCH hota hai (row na ho to khamosh nakami;
  /// registration mukammal ho to caller ensureDriverRow istemal
  /// karta hai). Hamesha best-effort aur khamosh.
  static Future<void> pushDriverFingerprint(AppStore store) async {
    if (store.driverId.isEmpty || store.profile.pwdFp.isEmpty) return;
    await _patch('drivers', store.driverId, {
      'pwd_fp': store.profile.pwdFp,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  /// FINAL-PACK C-PD: lazmi password-change kamyab hone ke baad —
  /// naya pwd_fp backend par push AUR must_change_password=false
  /// bhi (ek hi PATCH). Column abhi na laga ho to PATCH fail hoga
  /// — tab sirf pwd_fp wala purana rasta (pushDriverFingerprint)
  /// chal jata hai aur local flag pehle hi saaf ho chuka hota hai
  /// (driver.dart flow). Hamesha best-effort aur khamosh.
  static Future<void> pushDriverPasswordReset(AppStore store) async {
    if (store.driverId.isEmpty || store.profile.pwdFp.isEmpty) return;
    final ok = await _patch('drivers', store.driverId, {
      'pwd_fp': store.profile.pwdFp,
      'must_change_password': false,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    });
    if (!ok) await pushDriverFingerprint(store);
  }

  /// RC2 follow-through (HOTFIX v1.2.9): owners jinka registration
  /// wizard se PEHLE ka hai, un ke backend rows kabhi bane hi nahi —
  /// kyunke registration ke sare purane raste upsert-style pushes
  /// (ledger/messages/waghaira) par munhasir thay, aur [_registered]
  /// ki gate (driverId + name + phone) pichli kisi push ke baghair
  /// pass nahi hoti. Nayi registration COMPLETE hote hi yahan se EK
  /// martaba row durust tor par banti hai: pehle GET (row hai ya
  /// nahi); hai to SIRF registration fields PATCH, nahi hai to
  /// mehfooz initial values ke saath full INSERT(_upsert).
  /// Kamyabi par true; offline/fail par false (khamosh, best-effort).
  static Future<bool> ensureDriverRow(AppStore store) async {
    if (store.driverId.isEmpty) return false;
    if (store.profile.name.trim().isEmpty ||
        store.profile.phone.trim().isEmpty) {
      return false;
    }
    final data = await _get(
        'drivers?select=id&id=eq.${Uri.encodeComponent(store.driverId)}');
    if (data is! List) return false;
    if (data.isNotEmpty) {
      // Row pehle se maujood hai — sirf registration ki maloomat
      // PATCH karein; status columns (Master-owned) ko hath NAHI.
      final p = store.profile;
      final fields = <String, dynamic>{
        'name': p.name,
        'mobile': p.phone,
        'vehicle': p.vehicle,
        'plate': p.plate,
        'zone': p.zone,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      };
      if (p.pwdFp.isNotEmpty) fields['pwd_fp'] = p.pwdFp;
      // NOTE: agent_code (v136) yahan NAHI jata — woh sirf
      // _pushDriver se jata hai jahan naye columns ka retry-strip
      // hai; is PATCH mein column na ho to poori durusti ruk
      // jayegi (imei wala hi usool).
      if (p.cnicNumber.isNotEmpty) fields['cnic_number'] = p.cnicNumber;
      if (p.licenceNumber.isNotEmpty) {
        fields['licence_number'] = p.licenceNumber;
      }
      if (p.vehicleBrand.isNotEmpty) fields['vehicle_brand'] = p.vehicleBrand;
      if (p.vehicleModel.isNotEmpty) fields['vehicle_model'] = p.vehicleModel;
      if (p.vehicleYear > 0) fields['vehicle_year'] = p.vehicleYear;
      if (p.vehicleColor.isNotEmpty) fields['vehicle_color'] = p.vehicleColor;
      return _patch('drivers', store.driverId, fields);
    }
    // Row maujood hi nahi — registration isi machine par mukammal
    // hui hai, to is phone ke store ki values is row ke liye durust
    // tareen hain. active hamesha false (tasdeeq Master ki hai);
    // document status columns bilkul NAHI bhejte (Master-owned,
    // backend ke apne defaults hi rahenge).
    final p = store.profile;
    await _pushDriver(store);
    final check = await _get(
        'drivers?select=id&id=eq.${Uri.encodeComponent(store.driverId)}');
    if (check is List && check.isNotEmpty) {
      // _pushDriver ne row upsert kar di (local masterActive is waqt
      // false hi hota hai — nayi registration kabhi khud active nahi
      // hoti; sirf token-race mehfooz karne ke liye active ko dobara
      // false par pakka kar dete hain).
      if (p.masterActive) {
        await _patch('drivers', store.driverId, {'active': false});
      }
      return true;
    }
    // Fallback: ghair-mutawaqqa surat (masalan _pushDriver ki write
    // kahin atak gayi ho) — zahir initial values ke saath khud
    // insert karein.
    final row = <String, dynamic>{
      'id': store.driverId,
      'name': p.name,
      'mobile': p.phone,
      'vehicle': p.vehicle,
      'plate': p.plate,
      'zone': p.zone,
      'active': false,
      'online': false,
      'on_ride': false,
      'wallet_balance': p.walletBalance,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    };
    if (p.pwdFp.isNotEmpty) row['pwd_fp'] = p.pwdFp;
    if (p.cnicNumber.isNotEmpty) row['cnic_number'] = p.cnicNumber;
    if (p.licenceNumber.isNotEmpty) row['licence_number'] = p.licenceNumber;
    if (p.vehicleBrand.isNotEmpty) row['vehicle_brand'] = p.vehicleBrand;
    if (p.vehicleModel.isNotEmpty) row['vehicle_model'] = p.vehicleModel;
    if (p.vehicleYear > 0) row['vehicle_year'] = p.vehicleYear;
    if (p.vehicleColor.isNotEmpty) row['vehicle_color'] = p.vehicleColor;
    if (p.lastLat != null && p.lastLng != null) {
      row['lat'] = p.lastLat;
      row['lng'] = p.lastLng;
    }
    return _upsert('drivers', row);
  }

  // --- Registration documents → Master Tasdeeq (v1.2.8) -----------------------

  static bool _docsSyncing = false;

  /// Registration ki document tasaveer Storage bucket 'driver-docs'
  /// mein bhejna taaki Master TASDEEQ screen mein har cheez asal
  /// tasveer mein check kar sake — baghair is ke koi ID chupke se
  /// active nahi hoti: driver app documents upload to kar sakti hai,
  /// lekin ACTIVE sirf Master karta hai (drivers.active, jo sirf
  /// [refreshDriverStatus] se pull hota hai).
  ///
  /// Har kind (cnic_front / cnic_back / vehicle / vehicle_reg /
  /// licence — sirf jab photo maujood ho — / profile) tab upload
  /// hota hai jab us ka local path khaali na ho AUR profile ke
  /// docUploaded marker se alag ho (matlab abhi upload nahi hua, ya
  /// photo dobara li gayi hai). Kamyabi par marker set hota hai aur
  /// aakhir mein _pushDriver drivers row par *_path columns likh
  /// deta hai. Sab best-effort: registration aur duty is par KABHI
  /// nahi rukti; nakami wali kind agli sync/startup par dobara
  /// koshish hoti hai.
  static Future<void> syncDriverDocs(AppStore store) async {
    if (_docsSyncing) return;
    if (!_registered(store)) return;
    final p = store.profile;
    final kinds = <String, String>{
      'cnic_front': p.cnicFrontPath,
      'cnic_back': p.cnicBackPath,
      'vehicle': p.vehiclePhotoPath,
      'vehicle_reg': p.vehicleRegPath,
      // v1.4.7 PHOTO SET (spec §7): gaari ki chaaron taraf +
      // andar ki tasaveer — object paths tay-shuda hain
      // (<driver_id>/vehicle_back.jpg waghera); Master Tasdeeq
      // inhein isi convention se parhta hai (alag columns nahi)।
      if (p.vehicleBackPath.isNotEmpty) 'vehicle_back': p.vehicleBackPath,
      if (p.vehicleLeftPath.isNotEmpty) 'vehicle_left': p.vehicleLeftPath,
      if (p.vehicleRightPath.isNotEmpty)
        'vehicle_right': p.vehicleRightPath,
      if (p.vehicleInteriorPath.isNotEmpty)
        'vehicle_interior': p.vehicleInteriorPath,
      if (p.licencePhotoPath.isNotEmpty) 'licence': p.licencePhotoPath,
      'profile': p.profilePhotoPath,
    };
    final pending = kinds.entries
        .where((e) => e.value.isNotEmpty && p.docUploaded[e.key] != e.value)
        .toList();
    if (pending.isEmpty) return;
    _docsSyncing = true;
    try {
      var anyUploaded = false;
      // v1.4.1 — resubmit pehchan: jo kind ka Master faisla abhi
      // 'rejected' hai aur us ki NAYI photo ab upload ho rahi hai,
      // woh "dobara bhejna" hai. Upload kamyab ho to us group ka
      // resubmit timestamp darj hota hai (neeche _pushDriver ke
      // saath jata hai; v130 trigger status khud 'pending' kar
      // deta hai — driver khud *_status NAHI likhta, yehi lock hai).
      final resubmitGroups = <String>{};
      String? groupOf(String kind) => switch (kind) {
            'cnic_front' || 'cnic_back' => 'cnic',
            'vehicle' ||
            'vehicle_reg' ||
            'vehicle_back' ||
            'vehicle_left' ||
            'vehicle_right' ||
            'vehicle_interior' =>
              'gaari',
            'licence' => 'licence',
            _ => null,
          };
      for (final e in pending) {
        final objectPath = await _uploadDocImage(store, e.value, e.key);
        if (objectPath != null) {
          await store.markDocUploaded(e.key, e.value);
          anyUploaded = true;
          final g = groupOf(e.key);
          if (g != null && p.masterStatusFor(g) == 'rejected') {
            resubmitGroups.add(g);
          }
        }
      }
      if (resubmitGroups.isNotEmpty) {
        final nowIso = DateTime.now().toUtc().toIso8601String();
        for (final g in resubmitGroups) {
          await store.markDocResubmitAt(g, nowIso);
        }
      }
      // Koi path naya bana ho to drivers row par bhi darj ho jaye —
      // Master Tasdeeq isi row se paths parhta hai.
      if (anyUploaded) await _pushDriver(store);
      // Resubmit timestamps EK push ke liye thay — saaf kar dein
      // taaki aam pushes wohi timestamp dobara na bhejen.
      if (resubmitGroups.isNotEmpty) await store.clearDocResubmitAt();
    } finally {
      _docsSyncing = false;
    }
  }

  /// Ek document ki tasveer bucket 'driver-docs' mein:
  /// path = driver-docs/<driver_id>/<kind>.jpg (upsert — dobara
  /// upload ho to wohi file taza ho jati hai). Safalta par object
  /// path, nakami par null. Bucket + policies migration
  /// backend-migration-v128.sql se bante hain. Bilkul
  /// [_uploadSelfieImage] wala andaaz.
  static Future<String?> _uploadDocImage(
      AppStore store, String localPath, String kind) async {
    HttpClient? client;
    try {
      final file = File(localPath);
      if (!await file.exists()) return null;
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) return null;
      final objectPath = '${store.driverId}/$kind.jpg';
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client
          .postUrl(Uri.parse('$_storageBase/object/driver-docs/$objectPath'))
          .timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'image/jpeg');
      req.headers.set('x-upsert', 'true');
      req.add(bytes);
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode >= 200 && resp.statusCode < 300) {
        return objectPath;
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  // =========================================================================
  // v1.4.0 — Kami Fix Wave: live dispatch / ratings / announcements / polls
  //
  // Ye saare naye backend raaste migration backend-migration-v129.sql
  // par munhasir hain (tables: ratings, announcements; columns:
  // drivers.lat/lng/loc_at, rides.driver_lat/driver_lng). Migration
  // abhi NA chala ho to har request khamoshi se fail hoti hai —
  // koi crash nahi, koi UI asar nahi; local store hamesha asal sach
  // rehta hai aur same-device pilot bilkul waisa hi chalta hai.
  // =========================================================================

  /// Duty par driver ki live jagah — SIRF lat/lng (+loc_at) ki PATCH.
  /// loc_at column na ho to pehli koshish fail hoti hai aur dobara
  /// sirf lat/lng ke saath koshish hoti hai (purani schema mein bhi
  /// lat/lng maujood hain) — dono khamosh.
  static Future<void> _pushDriverLocation(AppStore store) async {
    if (store.driverId.isEmpty) return;
    final lat = store.profile.lastLat;
    final lng = store.profile.lastLng;
    if (lat == null || lng == null) return;
    final ok = await _patch('drivers', store.driverId, {
      'lat': lat,
      'lng': lng,
      'loc_at': DateTime.now().toUtc().toIso8601String(),
    });
    if (!ok) {
      await _patch('drivers', store.driverId, {'lat': lat, 'lng': lng});
    }
  }

  /// Chal rahi ride par driver ki mojooda jagah `rides.driver_lat/
  /// driver_lng` mein likhna — passenger ka ETA isi se banta hai.
  /// Ride row backend par maujood na ho (ya columns na hon) to
  /// khamosh nakami; passenger ka poll phir same-device wali maloom
  /// jagah par fallback kar deta hai.
  static Future<void> pushRideDriverPosition(
      AppStore store, String rideId, double lat, double lng) async {
    if (rideId.isEmpty) return;
    await _patch('rides', rideId, {
      'driver_lat': lat,
      'driver_lng': lng,
    });
  }

  /// Passenger ke liye EK ride row ki taaza haalat pull — status
  /// screen + Meri Bookings ka poll (~15s) isi par chalta hai.
  /// Sirf is phone ki local bookings mein maujood ride ki row ati
  /// hai; status + driver_lat/driver_lng wapas milte hain.
  /// Nakami/table na ho to null — caller same-device haalat par
  /// rehta hai, kuch crash nahi hota.
  static Future<Map<String, dynamic>?> fetchRideRow(String rideId) async {
    // FINAL-PACK D: cancel_reason bhi pull hota hai (rides table
    // ka asal backend column — local Booking ka json key
    // 'cancelReason' is se alag hai) taaki passenger ko cancel ki
    // wajah notification + notice card mein nazar aye. Column na
    // ho to SELECT fail hoga — tab baghair wajah ke purani query
    // par gir jate hain (status/ETA ka poll kabhi nahi rukta).
    var data = await _get(
        'rides?select=id,status,driver_lat,driver_lng,driver_id,cancel_reason,start_code,ride_started&id=eq.${Uri.encodeComponent(rideId)}');
    if (data is! List) {
      data = await _get(
          'rides?select=id,status,driver_lat,driver_lng,driver_id,cancel_reason&id=eq.${Uri.encodeComponent(rideId)}');
    }
    if (data is! List) {
      data = await _get(
          'rides?select=id,status,driver_lat,driver_lng,driver_id&id=eq.${Uri.encodeComponent(rideId)}');
    }
    if (data is! List || data.isEmpty) return null;
    final row = data.first;
    return row is Map<String, dynamic> ? row : null;
  }

  // --- v1.4.5 DUTY SERVICE helpers ------------------------------------------
  // Foreground service ka isolate AppStore NAHI rakhta — use sirf
  // driver id se kaam hai. Ye do helpers usi liye store-free hain.

  /// Duty service ke liye: sirf driver id se us ki live jagah ki
  /// halki PATCH (drivers.lat/lng/loc_at) — [_pushDriverLocation]
  /// wala hi tareeqa, store ke baghair.
  static Future<void> servicePushDriverLocation(
      String driverId, double lat, double lng) async {
    if (driverId.isEmpty) return;
    final ok = await _patch('drivers', driverId, {
      'lat': lat,
      'lng': lng,
      'loc_at': DateTime.now().toUtc().toIso8601String(),
    });
    if (!ok) {
      await _patch('drivers', driverId, {'lat': lat, 'lng': lng});
    }
  }

  /// Duty service ke liye: is driver ki chal rahi (accepted/arrived)
  /// rides ki ids — un par driver_lat/lng likhna hai taaki passenger
  /// ka ETA background mein bhi taaza rahe.
  static Future<List<String>> fetchDriverActiveRideIds(
      String driverId) async {
    if (driverId.isEmpty) return const [];
    final data = await _get(
        'rides?select=id&driver_id=eq.${Uri.encodeComponent(driverId)}&status=in.(accepted,arrived)');
    if (data is! List) return const [];
    return [
      for (final r in data)
        if (r is Map && r['id'] is String) r['id'] as String,
    ];
  }

  /// Duty service ke liye: ride row par driver ki jagah — store-free
  /// roop ([pushRideDriverPosition] wala hi PATCH).
  static Future<void> servicePushRidePosition(
      String rideId, double lat, double lng) async {
    if (rideId.isEmpty) return;
    await _patch('rides', rideId, {'driver_lat': lat, 'driver_lng': lng});
  }

  // =========================================================================
  // v1.4.2 — DO-PHONE DISPATCH (DISPATCH-AUDIT ke lazmi fix #1, #2, #3, #6)
  //
  //  #1 Backend Pool feed: driver app ab backend se pending rides
  //     pull karti hai (coordinates samait jab v131 columns hon).
  //  #2 Atomic accept: claim SIRF conditional PATCH se hota hai
  //     (status=eq.pending shart ke saath) — pehla driver jeet-ta
  //     hai, doosre ko khaali jawab milta hai.
  //  #3 Passenger ki local status remote se lagti hai —
  //     applyRemoteRideState (store.dart) + driver ki asal tafseel
  //     fetchDriverCard se.
  //  #6 Bookings outbox: syncRideOutbox (upar).
  // =========================================================================

  /// Filter ke saath conditional PATCH — jawab mein updated rows
  /// (return=representation). Shart (masalan status=eq.pending) na
  /// mile to khaali list — race guard isi par hai. Nakami par null.
  static Future<List<dynamic>?> _patchWhere(
      String table, String filter, Map<String, dynamic> fields) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client
          .patchUrl(Uri.parse('$_base/$table?$filter'))
          .timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      req.headers.set('Prefer', 'return=representation');
      req.write(jsonEncode(fields));
      final resp = await req.close().timeout(_timeout);
      final body = await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode < 200 || resp.statusCode >= 300) return null;
      final decoded = jsonDecode(body);
      return decoded is List ? decoded : null;
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  /// Backend par khadi (pending) rides ki taaza list — driver ki
  /// Pool/Bookings screens ke liye. Coordinates wale columns
  /// (v131) na hon to baghair un ke dobara koshish hoti hai —
  /// labels/km/fare phir bhi ate hain, sirf radius filter aur
  /// route map us ride par nahi chalte.
  static Future<List<Booking>> fetchPendingPoolRides() async {
    const base =
        'id,passenger_name,passenger_mobile,pickup,drop_off,vehicle,km,fare,status,date';
    var data = await _get(
        'rides?select=$base,pickup_lat,pickup_lng,drop_lat,drop_lng,note,start_code&status=eq.pending&order=date.desc&limit=50');
    if (data is! List) {
      data = await _get(
          'rides?select=$base&status=eq.pending&order=date.desc&limit=50');
    }
    if (data is! List) return const [];
    final out = <Booking>[];
    for (final r in data) {
      if (r is! Map) continue;
      final id = r['id'];
      if (id is! String || id.isEmpty) continue;
      double dv(String k) => (r[k] as num?)?.toDouble() ?? 0;
      out.add(Booking(
        id: id,
        passengerName: r['passenger_name'] as String? ?? '',
        passengerPhone: r['passenger_mobile'] as String? ?? '',
        pickupLabel: r['pickup'] as String? ?? '',
        dropLabel: r['drop_off'] as String? ?? '',
        pickupLat: dv('pickup_lat'),
        pickupLng: dv('pickup_lng'),
        dropLat: dv('drop_lat'),
        dropLng: dv('drop_lng'),
        hasDropPin: dv('drop_lat') != 0 || dv('drop_lng') != 0,
        vehicle: r['vehicle'] as String? ?? 'Rickshaw',
        distanceKm: dv('km'),
        fare: (r['fare'] as num?)?.toInt() ?? 0,
        note: r['note'] as String? ?? '',
        status: 'pending',
        createdAt:
            DateTime.tryParse(r['date'] as String? ?? '') ?? DateTime.now(),
        fromBackend: true,
        // v1.4.7: do-phone ride ka start code (v137 column; abhi
        // na ho to pehli query fail → fallback query baghair is ke
        // ati hai aur code 0 rehta hai — accept ke baad driver
        // fetchRideFields se dobara le leta hai)।
        startCode: (r['start_code'] as num?)?.toInt() ?? 0,
      ));
    }
    return out;
  }

  /// Pool feed ko store mein taza karna — driver side ke timers
  /// aur screens yahi bulate hain. Sab best-effort/khamosh.
  static Future<void> refreshRemotePool(AppStore store) async {
    final rides = await fetchPendingPoolRides();
    store.setRemotePool(rides);
  }

  /// RACE-GUARDED accept (audit fix #2): ride sirf tab is driver
  /// ki hoti hai jab backend par woh ABHI BHI pending ho. Do
  /// driver ek saath dabayein to pehle ka PATCH row badal deta
  /// hai aur doosre ka PATCH (status=eq.pending shart) khaali
  /// jawab lata hai — false. Kamyabi par true.
  static Future<bool> tryClaimRide(AppStore store, String rideId) async {
    if (store.driverId.isEmpty) return false;
    final rows = await _patchWhere(
      'rides',
      'id=eq.${Uri.encodeComponent(rideId)}&status=eq.pending',
      {'status': 'accepted', 'driver_id': store.driverId},
    );
    return rows != null && rows.isNotEmpty;
  }

  static final Map<String, Map<String, dynamic>> _driverCardCache = {};

  /// Accept ke baad passenger ko dikhane ke liye asal driver ki
  /// tafseel (naam, mobile, gaari, plate, profile photo path) —
  /// backend `drivers` row se. Cache session ke liye hai (poll
  /// har 15s par dobara request nahi karta). Nakami par null.
  static Future<Map<String, dynamic>?> fetchDriverCard(
      String driverId) async {
    if (driverId.isEmpty) return null;
    final cached = _driverCardCache[driverId];
    if (cached != null) return cached;
    final data = await _get(
        'drivers?select=name,mobile,vehicle,vehicle_brand,vehicle_model,plate,profile_photo_path&id=eq.${Uri.encodeComponent(driverId)}');
    if (data is! List || data.isEmpty) return null;
    final row = data.first;
    if (row is! Map<String, dynamic>) return null;
    _driverCardCache[driverId] = row;
    return row;
  }

  /// Ek ride row (fetchRideRow) se passenger ki local booking par
  /// asal haalat + driver tafseel lagana — polls yahi bulate hain.
  /// Driver card sirf tab pull hota hai jab ride accept ho chuki
  /// ho aur tafseel abhi booking par na lagi ho.
  static Future<void> applyRemoteRowToBooking(
      AppStore store, Booking b, Map<String, dynamic> row) async {
    final st = row['status'];
    if (st is! String || st.isEmpty) return;
    final driverId = row['driver_id'] as String? ?? '';
    var name = '', phone = '', vehicleDetail = '', plate = '', photo = '';
    if (driverId.isNotEmpty &&
        (st == 'accepted' || st == 'arrived' || st == 'completed') &&
        b.driverPhone.isEmpty) {
      final card = await fetchDriverCard(driverId);
      if (card != null) {
        name = card['name'] as String? ?? '';
        phone = card['mobile'] as String? ?? '';
        final brand = card['vehicle_brand'] as String? ?? '';
        final model = card['vehicle_model'] as String? ?? '';
        vehicleDetail = [brand, model]
            .where((x) => x.trim().isNotEmpty)
            .join(' ')
            .trim();
        if (vehicleDetail.isEmpty) {
          vehicleDetail = card['vehicle'] as String? ?? '';
        }
        plate = card['plate'] as String? ?? '';
        photo = card['profile_photo_path'] as String? ?? '';
      }
    }
    await store.applyRemoteRideState(
      b.id,
      status: st,
      driverId: driverId,
      driverName: name,
      driverPhone: phone,
      driverVehicleDetail: vehicleDetail,
      driverPlate: plate,
      driverPhotoPath: photo,
      // v1.4.7: start code + ride-started ki taaza haalat (v137
      // columns; row mein na hon to purani default values)।
      startCode: (row['start_code'] as num?)?.toInt() ?? 0,
      rideStarted: row['ride_started'] == true,
    );
  }

  /// Booking banate waqt TWO-PHONE dispatch ki maloomat: backend
  /// `drivers` mein active + online drivers ki taaza jagah se pickup
  /// tak ki sab se kam seedhi doori (km). Qareeb tareen driver
  /// [kDriverPickupRadiusKm] ke andar ho to us ki doori (warna null).
  /// Drivers ki list khaali/fail ho to bhi null — same-device pilot
  /// aur local flow is par KABHI nahi rukta. Sirf ittila hai —
  /// assignment driver ke qubool karne se hi hoti hai.
  static Future<double?> nearestOnlineDriverKm(
      double pickupLat, double pickupLng) async {
    final data = await _get(
        'drivers?select=id,lat,lng&active=eq.true&online=eq.true');
    if (data is! List) return null;
    double? best;
    for (final r in data) {
      if (r is! Map) continue;
      final lat = (r['lat'] as num?)?.toDouble();
      final lng = (r['lng'] as num?)?.toDouble();
      if (lat == null || lng == null) continue;
      final d = _straightKm(pickupLat, pickupLng, lat, lng);
      if (best == null || d < best) best = d;
    }
    if (best == null) return null;
    return best <= kDriverPickupRadiusKm ? best : null;
  }

  /// Do points ke darmiyan seedhi doori (km) — haversine (backend
  /// ke andar latlong package se bachne ke liye halki si hisaab).
  static double _straightKm(
      double lat1, double lng1, double lat2, double lng2) {
    const r = 6371.0;
    final dLat = (lat2 - lat1) * math.pi / 180;
    final dLng = (lng2 - lng1) * math.pi / 180;
    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1 * math.pi / 180) *
            math.cos(lat2 * math.pi / 180) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    return r * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  }

  /// Passenger ki ghair-final bookings ki backend wali taaza status
  /// Notification Centre ke diff engine ko dena — taaki band app ke
  /// doran doosre phone par badli haalat (masalan ride complete)
  /// app khulte hi EK notification ban sake. v1.4.2 se status sirf
  /// notification tak NAHI rehti — applyRemoteRowToBooking asal
  /// haalat bhi local booking par lagata hai (audit fix #3), lekin
  /// sirf un bookings par jinhein is phone ke driver ne khud
  /// accept NAHI kiya (same-device flow bilkul waisa hi rehta hai).
  static Future<void> _primePassengerRideStatuses(AppStore store) async {
    final finals = <String>{'completed', 'cancelled', 'noshow'};
    final pending = store.bookings
        .where((b) => !finals.contains(b.status))
        .take(10)
        .toList();
    if (pending.isEmpty) return;
    final remote = <String, String>{};
    final rows = <String, Map<String, dynamic>>{};
    for (final b in pending) {
      final row = await fetchRideRow(b.id);
      if (row == null) continue;
      rows[b.id] = row;
      final st = row['status'];
      if (st is String && st.isNotEmpty) remote[b.id] = st;
    }
    if (remote.isNotEmpty) {
      await store.observeBookingStatuses('passenger',
          remoteStatus: remote);
    }
    // v1.4.2: sirf notification nahi — asal haalat bhi local
    // booking par lagti hai (audit fix #3), taaki app dobara
    // khulne par bhi passenger ko sahi status/ETA nazar aye.
    for (final b in pending) {
      final row = rows[b.id];
      if (row != null) await applyRemoteRowToBooking(store, b, row);
    }
  }

  // --- Ratings (v1.4.0) --------------------------------------------------------

  /// Ek rating backend `ratings` table mein bhejna (upsert —
  /// booking_id hi pehchan hai). Table na ho to khamosh nakami;
  /// rating phone par mehfooz rehti hai aur [syncRatings] agli
  /// sync par dobara koshish karta hai.
  static Future<void> _pushRating(AppStore store, RideRating r) async {
    final ok = await _upsert('ratings', {
      'booking_id': r.bookingId,
      'driver_id': r.driverId,
      'driver_name': r.driverName,
      'passenger_name': r.passengerName,
      'stars': r.stars,
      'comment': r.comment,
      'created_at': r.createdAt.toUtc().toIso8601String(),
    });
    if (ok) await store.markRatingSent(r.bookingId);
  }

  /// Abhi tak na bheji gayi ratings ki dobara koshish (app start par).
  static Future<void> syncRatings(AppStore store) async {
    for (final r in store.ratings.where((r) => !r.sent).toList()) {
      await _pushRating(store, r);
    }
  }

  /// Is phone ke driver ka backend wala rating ausat — Driver
  /// Profile ke "Meri Rating" ke liye. Sirf stars pull hotay hain
  /// aur ausat yahin gina jata hai (koi RPC nahi chahiye). Table/
  /// data na ho to kuch nahi hota — Profile pehle wali haalat par
  /// rehta hai.
  static Future<void> pullOwnRatingAverage(AppStore store) async {
    if (store.driverId.isEmpty) return;
    final data = await _get(
        'ratings?select=stars&driver_id=eq.${Uri.encodeComponent(store.driverId)}');
    if (data is! List || data.isEmpty) return;
    var sum = 0, count = 0;
    for (final r in data) {
      if (r is Map) {
        final s = (r['stars'] as num?)?.toInt();
        if (s != null && s > 0) {
          sum += s;
          count++;
        }
      }
    }
    if (count > 0) {
      await store.applyBackendRating(sum / count, count);
    }
  }

  // --- Announcements (v1.4.0) --------------------------------------------------

  /// Master ke elanaat (backend `announcements`, sab se naye 20)
  /// Notification Centre ke liye pull. Table na ho to _get null
  /// deta hai aur kuch nahi hota. Pehli dafa sirf snapshot banta
  /// hai (store.applyAnnouncements ka usool) — purane elanaat par
  /// notification flood nahi ata.
  static Future<void> _pullAnnouncements(AppStore store) async {
    final data = await _get(
        'announcements?select=id,title,body,created_at&order=created_at.desc&limit=20');
    if (data is! List || data.isEmpty) return;
    final rows = <Map<String, dynamic>>[];
    for (final r in data) {
      if (r is Map<String, dynamic>) rows.add(r);
    }
    if (rows.isNotEmpty) await store.applyAnnouncements(rows);
  }

  /// Dono sides ke home/profile khulne par dobara elanaat check —
  /// siden ke apne lifecycle se halki si call. Sab best-effort.
  static Future<void> refreshAnnouncements(AppStore store) =>
      _pullAnnouncements(store);

  // ==========================================================================
  // v1.4.7 — PROPER BUILD (spec PROPER-BUILD-SPEC-v147.md)
  //
  // Tasdeeq ki bunyaad: (1) Email + OTP — Supabase Auth email OTP sirf
  // EMAIL-PROOF ke liye; asal driver/passenger records purane hi
  // rehte hain, email sirf un par naya field hai. (2) Migration v137
  // ke columns (drivers.email, vehicle_change, driver_selfies.kind/
  // complaint_id, rides.start_code/ride_started, passengers table)
  // — har call GUARDED hai: column/table abhi na ho to call khamoshi
  // se fail hoti hai aur app purane tareeqe par chalti rehti hai;
  // koi hard-crash NAHI.
  // ==========================================================================

  /// Auth endpoint helper (POST /auth/v1/...) — REST walon se alag
  /// prefix; jawab ki shakal: kamyabi par decoded JSON ya khaali
  /// map, nakami par null.
  static Future<Map<String, dynamic>?> _authPost(
      String path, Map<String, dynamic> body) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req =
          await client.postUrl(Uri.parse('$_authBase/$path')).timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      req.write(jsonEncode(body));
      final resp = await req.close().timeout(_timeout);
      final text = await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode < 200 || resp.statusCode >= 300) return null;
      if (text.trim().isEmpty) return const {};
      final decoded = jsonDecode(text);
      return decoded is Map<String, dynamic> ? decoded : const {};
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  /// Email par 6-digit OTP bhejna (Supabase Auth signInWithOtp).
  /// create_user=true: naya email ho to Auth us ka record khud bana
  /// deta hai — ye record SIRF email-proof ke liye hai, app ka asal
  /// account system is se nahi badalta. NOTE (parent deploy check):
  /// Supabase Auth ke email template mein {{ .Token }} hona chahiye
  /// warna email mein code ki jagah sirf link ayega.
  static Future<bool> sendEmailOtp(String email) async {
    final e = email.trim().toLowerCase();
    if (e.isEmpty || !e.contains('@')) return false;
    final res = await _authPost('otp', {
      'email': e,
      'create_user': true,
    });
    return res != null;
  }

  /// OTP code verify karna — sahi code par Auth session milta hai;
  /// humein sirf "email sabit ho gaya" chahiye, session app mein
  /// istemal NAHI hota (discard ho jata hai).
  static Future<bool> verifyEmailOtp(String email, String code) async {
    final e = email.trim().toLowerCase();
    final c = code.trim();
    if (e.isEmpty || c.length != 6) return false;
    final res = await _authPost('verify', {
      'email': e,
      'token': c,
      'type': 'email',
    });
    return res != null && res['access_token'] != null;
  }

  /// Sirf diye hue columns ke saath EK driver row parhna (v137 ke
  /// naye columns ke liye — select mein ghalat column ho to poora
  /// GET 400 hota hai, is liye ye alag rakha hai aur nakami par
  /// null deta hai; refreshDriverStatus wala purana select is se
  /// kabhi mutasir nahi hota).
  static Future<Map<String, dynamic>?> fetchDriverFields(
      String driverId, String select) async {
    if (driverId.isEmpty) return null;
    final data = await _get(
        'drivers?select=$select&id=eq.${Uri.encodeComponent(driverId)}&limit=1');
    if (data is List && data.isNotEmpty && data.first is Map) {
      return Map<String, dynamic>.from(data.first as Map);
    }
    return null;
  }

  /// CNIC pehchan (spec §9 — ek banda, ek ID): CNIC number se
  /// maujood driver dhoondhna. Column (v126) maujood hai; nakami
  /// par null ("nahi mila" aur "check nahi ho saka" caller alag
  /// handle karta hai: dono par registration rukti NAHI, sirf
  /// asal takrao par rukti hai).
  static Future<Map<String, dynamic>?> fetchDriverByCnic(String cnic) async {
    final c = cnic.trim();
    if (c.isEmpty) return null;
    final data = await _get(
        'drivers?select=id,name,mobile,active&cnic_number=eq.${Uri.encodeComponent(c)}&limit=1');
    if (data is List && data.isNotEmpty && data.first is Map) {
      return Map<String, dynamic>.from(data.first as Map);
    }
    return null;
  }

  /// Plate ki pehchan (spec §7 — ek gaari = ek ID): tamam drivers
  /// ki plates (normalized muqabla caller karta hai). Nakami par
  /// null — takrao ka check "nahi ho saka" mana jata hai, jhooti
  /// block nahi banti.
  static Future<List<Map<String, dynamic>>?> fetchPlateOwners() async {
    final data = await _get('drivers?select=id,name,mobile,plate,active&limit=1000');
    if (data is! List) return null;
    return [
      for (final r in data)
        if (r is Map) Map<String, dynamic>.from(r),
    ];
  }

  /// Gaari change ki darkhwast backend par darj karna (v137
  /// vehicle_change jsonb + status). Columns abhi na hon to false —
  /// caller local record rakhta hai aur agli sync par dobara
  /// bhejta hai; driver ko jhooti kamyabi NAHI dikhti (darkhwast
  /// "is phone par mehfooz" rehti hai).
  static Future<bool> pushVehicleChange(
      String driverId, Map<String, dynamic> change) async {
    if (driverId.isEmpty) return false;
    return _patch('drivers', driverId, {
      'vehicle_change': change,
      'vehicle_change_status': 'pending',
      'vehicle_change_reason': '',
    });
  }

  /// Gaari change ki MUKAMMAL darkhwast (spec §7): pehle nayi
  /// gaari ki tasaveer bucket mein (vchange_<kind> paths par),
  /// phir change ka record drivers.vehicle_change mein। Koi
  /// photo upload na ho saki ho to bhi darkhwast jati hai —
  /// Master ko jo photo na mile woh change record mein khaali
  /// rehti hai (jhooti kamyabi nahi dikhayi jati; Profile par
  /// pending haalat waisi hi rehti hai)।
  static Future<bool> submitVehicleChange(
      AppStore store, Map<String, dynamic> change) async {
    if (store.driverId.isEmpty) return false;
    const photoKeys = {
      'photo_front_local': 'photo_front',
      'photo_back_local': 'photo_back',
      'photo_left_local': 'photo_left',
      'photo_right_local': 'photo_right',
      'photo_interior_local': 'photo_interior',
      'reg_local': 'reg_photo',
      'selfie_local': 'selfie_photo',
    };
    for (final e in photoKeys.entries) {
      final local = change[e.key]?.toString() ?? '';
      if (local.isEmpty) continue;
      final remote =
          await _uploadDocImage(store, local, 'vchange_${e.value}');
      if (remote != null) change[e.value] = remote;
    }
    return pushVehicleChange(store.driverId, change);
  }

  /// Driver ki email maloomat backend par (v137 drivers.email) —
  /// OTP tasdeeq ke baad hi bheja jata hai. Column na ho to
  /// khamosh false; local record asal saboot rehta hai.
  static Future<bool> pushDriverEmail(
      String driverId, String email, DateTime verifiedAt) async {
    if (driverId.isEmpty || email.isEmpty) return false;
    return _patch('drivers', driverId, {
      'email': email.trim().toLowerCase(),
      'email_verified_at': verifiedAt.toUtc().toIso8601String(),
    });
  }

  // --- Passengers table (v137) ----------------------------------------------

  /// Passenger ki backend row (device_id PK) — email/OTP haalat
  /// aur no-show ginti ka mustaqil record. Table abhi na ho to
  /// null; app local record par chalti rehti hai.
  static Future<Map<String, dynamic>?> fetchPassengerRow(
      String deviceId) async {
    if (deviceId.isEmpty) return null;
    final data = await _get(
        'passengers?select=*&device_id=eq.${Uri.encodeComponent(deviceId)}&limit=1');
    if (data is List && data.isNotEmpty && data.first is Map) {
      return Map<String, dynamic>.from(data.first as Map);
    }
    return null;
  }

  /// Passenger row upsert (jo fields diye, sirf wohi).
  static Future<bool> pushPassengerRow(
      String deviceId, Map<String, dynamic> fields) async {
    if (deviceId.isEmpty) return false;
    return _upsert('passengers', {'device_id': deviceId, ...fields});
  }

  /// Is phone ki sawari ka apna record passengers table mein
  /// taaza rakhna (email/OTP haalat + no-show ginti)। Table abhi
  /// na ho to khamosh nakami — local record asal hai।
  static Future<void> syncPassengerSelf(AppStore store) async {
    await pushPassengerRow(store.deviceId, {
      'name': store.passengerName,
      'mobile': store.passengerPhone,
      if (store.passengerEmail.isNotEmpty) 'email': store.passengerEmail,
      if (store.passengerEmailVerified)
        'email_verified_at': DateTime.fromMillisecondsSinceEpoch(
                store.passengerEmailVerifiedAtMs)
            .toUtc()
            .toIso8601String(),
      'warn_count': store.passengerWarnCount,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  // --- Ride start code (spec §3) ---------------------------------------------

  /// Booking ka start code backend ride row par (v137
  /// rides.start_code) — do-phone mode mein driver isi se code
  /// parhta hai. Column na ho to khamosh false; same-device mode
  /// local booking se hi chalta hai.
  static Future<bool> pushRideStartCode(String rideId, int code) async {
    if (rideId.isEmpty || code <= 0) return false;
    return _patch('rides', rideId, {'start_code': code});
  }

  /// Ride asal mein shuru hui — rides.ride_started = true.
  static Future<bool> pushRideStarted(String rideId) async {
    if (rideId.isEmpty) return false;
    return _patch('rides', rideId, {'ride_started': true});
  }

  /// EK ride row ke diye hue columns (driver side: start_code /
  /// ride_started ki taaza haalat). Nakami par null.
  static Future<Map<String, dynamic>?> fetchRideFields(
      String rideId, String select) async {
    if (rideId.isEmpty) return null;
    final data = await _get(
        'rides?select=$select&id=eq.${Uri.encodeComponent(rideId)}&limit=1');
    if (data is List && data.isNotEmpty && data.first is Map) {
      return Map<String, dynamic>.from(data.first as Map);
    }
    return null;
  }

  // --- Selfie demands (spec §2: random + complaint) ---------------------------

  /// Selfie DEMAND row darj karna (driver_selfies, kind ke saath —
  /// v137 PK (driver_id, date, kind)) — agar v137 abhi na laga ho
  /// to purani (driver_id, date) PK par conflict hoga aur false
  /// ayega — caller demand ko LOCAL rakhta hai, gate phir bhi
  /// chalta hai (gate local state par hai, backend sirf record).
  static Future<bool> insertSelfieDemand({
    required String driverId,
    required String date,
    required String kind, // 'random' | 'complaint'
    String complaintId = '',
  }) async {
    if (driverId.isEmpty || date.isEmpty) return false;
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req =
          await client.postUrl(Uri.parse('$_base/driver_selfies')).timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      req.headers.set(
          'Prefer', 'resolution=merge-duplicates,return=minimal');
      req.write(jsonEncode({
        'driver_id': driverId,
        'date': date,
        'done': false,
        'kind': kind,
        if (complaintId.isNotEmpty) 'complaint_id': complaintId,
      }));
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      return resp.statusCode >= 200 && resp.statusCode < 300;
    } catch (_) {
      return false;
    } finally {
      client?.close();
    }
  }

  /// Driver ki BAAQI (done=false) random/complaint demands —
  /// driver app ka poll isi se gate chalata hai. v137 columns na
  /// hon to null (gate sirf local demands par rahega).
  static Future<List<Map<String, dynamic>>?> fetchPendingSelfieDemands(
      String driverId) async {
    if (driverId.isEmpty) return null;
    final data = await _get(
        'driver_selfies?select=date,kind,complaint_id&driver_id=eq.${Uri.encodeComponent(driverId)}&done=eq.false&kind=in.(random,complaint)&order=date.asc&limit=20');
    if (data is! List) return null;
    return [
      for (final r in data)
        if (r is Map) Map<String, dynamic>.from(r),
    ];
  }

  /// Demand ki selfie mukammal — usi (driver, date, kind) row ko
  /// done=true + image path. Pehle kind-wali shakal, nakami par
  /// purani (bina kind) shakal ki koshish (v137 se pehle ki DB).
  static Future<bool> completeSelfieDemand({
    required String driverId,
    required String date,
    required String kind,
    String imagePath = '',
  }) async {
    if (driverId.isEmpty || date.isEmpty) return false;
    final fields = <String, dynamic>{
      'done': true,
      if (imagePath.isNotEmpty) 'image_path': imagePath,
    };
    Future<bool> patchWith(Map<String, String> query) async {
      HttpClient? client;
      try {
        client = HttpClient();
        client.connectionTimeout = _timeout;
        final q = query.entries
            .map((e) => '${e.key}=eq.${Uri.encodeComponent(e.value)}')
            .join('&');
        final req = await client
            .patchUrl(Uri.parse('$_base/driver_selfies?$q'))
            .timeout(_timeout);
        req.headers.set('apikey', _key);
        req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
        req.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
        req.headers.set('Prefer', 'return=minimal');
        req.write(jsonEncode(fields));
        final resp = await req.close().timeout(_timeout);
        await resp.transform(utf8.decoder).join().timeout(_timeout);
        return resp.statusCode >= 200 && resp.statusCode < 300;
      } catch (_) {
        return false;
      } finally {
        client?.close();
      }
    }

    if (await patchWith(
        {'driver_id': driverId, 'date': date, 'kind': kind})) {
      return true;
    }
    return patchWith({'driver_id': driverId, 'date': date});
  }

  /// Selfie ki tasveer 'selfies' bucket mein ek diye hue object
  /// path par upload (random/complaint selfies ke liye — rozana
  /// wali ka apna tareeqa [_uploadSelfieImage] hai).
  static Future<String?> uploadSelfieToPath(
      String localPath, String objectPath) async {
    HttpClient? client;
    try {
      final file = File(localPath);
      if (!await file.exists()) return null;
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) return null;
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client
          .postUrl(Uri.parse('$_storageBase/object/selfies/$objectPath'))
          .timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'image/jpeg');
      req.headers.set('x-upsert', 'true');
      req.add(bytes);
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode < 200 || resp.statusCode >= 300) return null;
      return objectPath;
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }
}

// ===========================================================================
// AGENT SYSTEM (v1.4.6 — migration v136, AGENT-SYSTEM-SPEC §2)
//
// Agent SIRF Master app se banta hai (backend `agents` table).
// Is app ka kaam sirf teen hai:
//  (1) Registration wizard mein IKHTIYARI agent code check —
//      ACTIVE agent mile to drivers.agent_code darj ho jata hai.
//  (2) Profile (dono modes) mein "Mera Agent Hisa" — logged-in
//      mobile kisi ACTIVE agent se match kare to agent apni
//      profile photo laga/badal sakta hai aur apne drivers ka
//      RECORD-ONLY hisaab dekh sakta hai.
//  (3) Agent ki profile photo ka upload (bucket 'driver-docs',
//      path agents/<code>/profile.jpg).
//
// COMMISSION YAHAN BILKUL NAHI hai: malik ka faisla baad mein
// hoga — is liye hisaab sirf record hai (rides/fare/fee ke
// jama-shuda number), koi percent ya agent ki "kamai" NAHI
// dikhti. Table abhi na lagi ho (migration v136 baqi) to tamam
// calls khamoshi se khaali/null deti hain — app kabhi nahi rukti.
// ===========================================================================

/// Backend `agents` table ki ek row.
class AgentInfo {
  final String id;
  final String name;
  final String mobile;
  final String cnic;
  final String city;
  final String code;
  final String photoPath; // driver-docs bucket path, khaali = nahi
  final bool active;

  const AgentInfo({
    required this.id,
    required this.name,
    required this.mobile,
    required this.cnic,
    required this.city,
    required this.code,
    required this.photoPath,
    required this.active,
  });

  factory AgentInfo.fromRow(Map r) => AgentInfo(
        id: r['id']?.toString() ?? '',
        name: r['name']?.toString() ?? '',
        mobile: r['mobile']?.toString() ?? '',
        cnic: r['cnic']?.toString() ?? '',
        city: r['city']?.toString() ?? '',
        code: r['code']?.toString() ?? '',
        photoPath: r['photo_path']?.toString() ?? '',
        active: r['active'] == true,
      );
}

/// Ek agent ke driver ka record-only khulasa: driver ki bunyadi
/// pehchan + us ki mukammal rides se bana hisaab. Is se zyada
/// driver ka koi data agent ko NAHI dikhta (spec ki sakht had).
class AgentDriverTally {
  final String driverId;
  final String name;
  final String vehicle; // type + brand/model jama shakal mein
  final String plate;
  final bool active;
  final String cnicStatus;
  final String gaariStatus;
  final String licenceStatus;
  final int rides; // mukammal (completed) rides
  final int fare; // kul kiraya (fare + waiting) — completed par
  final int fee; // kul fee RECORD — completed par

  const AgentDriverTally({
    required this.driverId,
    required this.name,
    required this.vehicle,
    required this.plate,
    required this.active,
    required this.cnicStatus,
    required this.gaariStatus,
    required this.licenceStatus,
    required this.rides,
    required this.fare,
    required this.fee,
  });
}

/// REFER BONUS ka hisaab (v1.4.7, spec §9 — malik ka faisla
/// 2026-11-08): har referred driver par ALAG bonus = us driver
/// ki PEHLE MAHINE ki WASOOL-SHUDA fee, cap Rs 15,000; shart =
/// pehle mahine mein 300 mukammal rides। ZERO-LOSS taalay:
/// (1) bonus sirf usi naye driver ki fee se banta hai — company
/// ki jeb se kabhi nahi; (2) pehle wasooli, phir bonus — fee
/// wasool na ho ya target miss ho to bonus ZERO; (3) nakli rides
/// par Master bonus rok sakta hai (faisla Master ka)।
/// "Pehla mahina" ka anchor: drivers table mein registration
/// date ka column NAHI hai, is liye hisaab driver ki PEHLI
/// mukammal ride ki tareekh se 30 din ginay jate hain — yehi
/// tareeqa P+D aur Master dono jagah ek jaisa hai।
class BonusMath {
  static const int capRs = 15000;
  static const int targetRides = 300;
  static const int windowDays = 30;

  static int bonusFor({
    required int firstMonthRides,
    required int settledInFirstMonth,
  }) {
    if (firstMonthRides < targetRides) return 0;
    return settledInFirstMonth < capRs ? settledInFirstMonth : capRs;
  }
}

/// Ek driver ke bonus hisaab ki khaam maloomat।
class BonusStats {
  final DateTime? anchor; // pehli mukammal ride ki tareekh
  final int firstMonthRides;
  final int settledInFirstMonth; // ledger fee_settled ka jod (window mein)

  const BonusStats({
    this.anchor,
    this.firstMonthRides = 0,
    this.settledInFirstMonth = 0,
  });

  int get bonus => BonusMath.bonusFor(
      firstMonthRides: firstMonthRides,
      settledInFirstMonth: settledInFirstMonth);
}

/// Agents ke asal static helpers — [Backend] ke wohi khamosh
/// usool (fail = khaali/null, UI kabhi nahi rukti). Private
/// helpers (Backend._get waghera) isi file/library ke andar
/// hone ki wajah se seedha istemal hote hain.
class AgentApi {
  /// Mobile ka muqabla har shakal mein ek jaisa: sirf digits,
  /// aur 92 wala aghaz 0 se badla hua (923xx ↔ 03xx).
  static String normMobile(String s) {
    var d = s.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.startsWith('92') && d.length == 12) d = '0${d.substring(2)}';
    return d;
  }

  static String normCode(String s) => s.trim().toUpperCase();

  /// Tamam agents — table na ho / net na ho to khaali list.
  static Future<List<AgentInfo>> fetchAgents() async {
    final data = await Backend._get('agents?select=*&order=created_at.desc');
    if (data is! List) return const [];
    return [
      for (final r in data)
        if (r is Map && (r['id']?.toString() ?? '').isNotEmpty)
          AgentInfo.fromRow(r),
    ];
  }

  /// Ek code se agent — registration wizard ka check. Code ki
  /// shakal normalize (bare haroof) kar ke exact match. Na mile
  /// ya table na ho to null (caller code ko ikhtiyari rakhta hai —
  /// registration NAHI rukti).
  static Future<AgentInfo?> fetchAgentByCode(String code) async {
    final c = normCode(code);
    if (c.isEmpty) return null;
    final data = await Backend._get(
        'agents?select=*&code=eq.${Uri.encodeComponent(c)}');
    if (data is! List || data.isEmpty) return null;
    final r = data.first;
    return r is Map ? AgentInfo.fromRow(r) : null;
  }

  /// Is mobile ka ACTIVE agent — Profile ke "Mera Agent Hisa" ka
  /// darwaza. Match digit-normalized hai taaki 03xx / 923xx dono
  /// shaklein chal jayein. Na mile to null — hisa bilkul nazar
  /// nahi ata.
  static Future<AgentInfo?> fetchAgentForMobile(String mobile) async {
    final m = normMobile(mobile);
    if (m.length < 10) return null;
    final agents = await fetchAgents();
    for (final a in agents) {
      if (a.active && normMobile(a.mobile) == m) return a;
    }
    return null;
  }

  /// Ek agent ke tamam drivers ka record-only khulasa: bunyadi
  /// pehchan (drivers table) + mukammal rides ka hisaab (rides
  /// table — fare mein waiting charges shamil, fee wohi jo ride
  /// par darj hai). agent_code column abhi na ho to drivers ki
  /// query fail hogi aur list khaali ayegi (defensive).
  static Future<List<AgentDriverTally>> fetchAgentDrivers(
      String code) async {
    final c = normCode(code);
    if (c.isEmpty) return const [];
    final data = await Backend._get(
        'drivers?select=id,name,vehicle,vehicle_brand,vehicle_model,plate,active,cnic_status,gaari_status,licence_status&agent_code=eq.${Uri.encodeComponent(c)}&order=name.asc');
    if (data is! List) return const [];
    final rows = [for (final r in data) if (r is Map) r];
    if (rows.isEmpty) return const [];
    final ids = [
      for (final r in rows)
        if ((r['id']?.toString() ?? '').isNotEmpty) r['id'].toString(),
    ];
    // Completed rides ka hisaab — ek hi query tamam drivers ke
    // liye (driver_id in (...)); ids hamari apni bani hui hain.
    final stats = <String, ({int rides, int fare, int fee})>{};
    if (ids.isNotEmpty) {
      final rides = await Backend._get(
          'rides?select=driver_id,fare,waiting_charges,fee&status=eq.completed&driver_id=in.(${ids.join(',')})&limit=10000');
      if (rides is List) {
        for (final r in rides) {
          if (r is! Map) continue;
          final did = r['driver_id']?.toString() ?? '';
          if (did.isEmpty) continue;
          final cur = stats[did] ?? (rides: 0, fare: 0, fee: 0);
          stats[did] = (
            rides: cur.rides + 1,
            fare: cur.fare +
                ((r['fare'] as num?)?.toInt() ?? 0) +
                ((r['waiting_charges'] as num?)?.toInt() ?? 0),
            fee: cur.fee + ((r['fee'] as num?)?.toInt() ?? 0),
          );
        }
      }
    }
    return [
      for (final r in rows)
        AgentDriverTally(
          driverId: r['id']?.toString() ?? '',
          name: r['name']?.toString() ?? '',
          vehicle: [
            r['vehicle']?.toString() ?? '',
            r['vehicle_brand']?.toString() ?? '',
            r['vehicle_model']?.toString() ?? '',
          ].where((s) => s.trim().isNotEmpty).join(' · '),
          plate: r['plate']?.toString() ?? '',
          active: r['active'] == true,
          cnicStatus: r['cnic_status']?.toString() ?? '',
          gaariStatus: r['gaari_status']?.toString() ?? '',
          licenceStatus: r['licence_status']?.toString() ?? '',
          rides: stats[r['id']?.toString()]?.rides ?? 0,
          fare: stats[r['id']?.toString()]?.fare ?? 0,
          fee: stats[r['id']?.toString()]?.fee ?? 0,
        ),
    ];
  }

  /// Bonus hisaab ke liye khaam data (v1.4.7, spec §9): har
  /// driver ki pehli mukammal ride (anchor) + 30 din ke andar
  /// ki mukammal rides + usi muddat ki WASOOL fee (ledger ki
  /// 'fee_settled' entries)। Do queries kul drivers ke liye —
  /// Master app ka hisaab bhi ain inhi usoolon par hai (wahan
  /// apni copy hai)।
  static Future<Map<String, BonusStats>> fetchBonusStats(
      List<String> driverIds) async {
    final out = <String, BonusStats>{};
    final ids = driverIds.where((e) => e.isNotEmpty).toList();
    if (ids.isEmpty) return out;
    final inList = ids.join(',');
    final anchors = <String, DateTime>{};
    final fmRides = <String, int>{};
    final rides = await Backend._get(
        'rides?select=driver_id,date&status=eq.completed&driver_id=in.($inList)&order=date.asc&limit=10000');
    if (rides is List) {
      for (final r in rides) {
        if (r is! Map) continue;
        final did = r['driver_id']?.toString() ?? '';
        final dt = DateTime.tryParse(r['date']?.toString() ?? '');
        if (did.isEmpty || dt == null) continue;
        final anchor = anchors.putIfAbsent(did, () => dt);
        if (dt.isBefore(
            anchor.add(const Duration(days: BonusMath.windowDays)))) {
          fmRides[did] = (fmRides[did] ?? 0) + 1;
        }
      }
    }
    final settled = <String, int>{};
    final ledger = await Backend._get(
        'ledger?select=driver_id,amount,ts&type=eq.fee_settled&driver_id=in.($inList)&limit=10000');
    if (ledger is List) {
      for (final r in ledger) {
        if (r is! Map) continue;
        final did = r['driver_id']?.toString() ?? '';
        final anchor = anchors[did];
        if (did.isEmpty || anchor == null) continue;
        final ts = DateTime.tryParse(r['ts']?.toString() ?? '');
        if (ts == null) continue;
        if (ts.isBefore(
            anchor.add(const Duration(days: BonusMath.windowDays)))) {
          settled[did] =
              (settled[did] ?? 0) + ((r['amount'] as num?)?.toInt() ?? 0);
        }
      }
    }
    for (final id in ids) {
      out[id] = BonusStats(
        anchor: anchors[id],
        firstMonthRides: fmRides[id] ?? 0,
        settledInFirstMonth: settled[id] ?? 0,
      );
    }
    return out;
  }

  /// Agent ki apni profile photo upload — bucket 'driver-docs',
  /// path agents/<code>/profile.jpg (x-upsert: dobara lagane par
  /// wohi file taza). Kamyabi par agents.photo_path bhi PATCH ho
  /// jata hai. Wapas object path, nakami par null.
  /// NOTE (v132 docs-privacy): bucket ab PRIVATE hai — doosre
  /// phone se photo public URL par NAHI khulti; is phone par
  /// caller LOCAL file hi dikhata hai, aur Master apni app mein
  /// signed URL se asal photo dekh sakta hai.
  static Future<String?> uploadAgentPhoto(
      AgentInfo agent, File file) async {
    HttpClient? client;
    try {
      if (!await file.exists()) return null;
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) return null;
      final objectPath = 'agents/${agent.code}/profile.jpg';
      client = HttpClient();
      client.connectionTimeout = Backend._timeout;
      final req = await client
          .postUrl(Uri.parse(
              '${Backend._storageBase}/object/driver-docs/$objectPath'))
          .timeout(Backend._timeout);
      req.headers.set('apikey', Backend._key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer ${Backend._key}');
      req.headers.set(HttpHeaders.contentTypeHeader, 'image/jpeg');
      req.headers.set('x-upsert', 'true');
      req.add(bytes);
      final resp = await req.close().timeout(Backend._timeout);
      await resp.transform(utf8.decoder).join().timeout(Backend._timeout);
      if (resp.statusCode < 200 || resp.statusCode >= 300) return null;
      // photo_path ka record — nakami par bhi upload zaya nahi:
      // agli dafa photo badalne par dobara likha jayega.
      await Backend._patch('agents', agent.id, {'photo_path': objectPath});
      return objectPath;
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }
}
