import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'store.dart';
import 'theme.dart';
import 'legal.dart';
import 'backend.dart';
import 'guide_audio.dart';
import 'lang.dart';
import 'otp.dart';
import 'login_page.dart';
import 'selfie_gate.dart';

/// Driver REGISTRATION WIZARD (v1.2.6 — malik ka hukm: "Register form
/// waise hi banao jaise Yango ka hai").
///
/// Yango Pro ke driver registration jaisi qadam-ba-qadam (step-by-step)
/// full-screen form: mobile → zaati maloomat/CNIC → password → gaari →
/// licence (ikhtiyari) → live selfie → ilaqa + jaiza → Register.
/// Driver Mode mein jab tak registration mukammal nahi, ye form khud
/// bhi khulta hai aur Profile se bhi dobara khul sakta hai (tafseel
/// mukammal/badlein). Purani Profile-wali save is ki jagah NAHI leti —
/// pehli registration yahin se hoti hai; Profile sirf editing ke liye.
///
/// Usool jo nahi badle:
/// - Password: v1.2.5 ke wohi usool (kam az kam 6 haroof, sirf
///   fingerprint, ek password sirf ek driver — backend uniqueness
///   check, internet ke baghair check skip NAHI hota).
/// - Licence OPTIONAL hai: "Licence nahi hai — skip karein" se aage
///   barh sakte hain; CNIC lazmi hai.
/// - Tasaveer phone par bhi rehti hain AUR backend Storage
///   (driver-docs bucket) mein bhi upload hoti hain — Master
///   TASDEEQ asal tasveer dekh kar hi karta hai (v1.2.8 se;
///   pehla "sirf phone par" wala khayal ghalat tha, v1.4.25
///   mein comment durust kiya gaya)। Backend par numbers/tafseel
///   aur documents ki STATUS bhi jati hai।
/// - Register hone par darkhwast Master ke paas jati hai — duty ki
///   asal tasdeeq masterActive (Master app) se hi ati hai.
/// v1.4.46 (malik ka hukm 2026-11-13): tartib ab Yango Pro /
/// Bykea Partner tarz ki hai — har qadam APNI screen par:
/// Khush-Aamdeed → Mobile → Gmail+Code → Naam+Sheher → Gaari →
/// CNIC Samne → CNIC Peeche → Gaari ke Kagaz → Licence →
/// Fitness/Insurance/Permit → Character → Live Selfie →
/// Password → Jaiza → Sharait → Jama-shuda screen। Data
/// fields, photo slots/keys, Backend calls, sharait ki
/// qubooliyat ka record aur submit ka rasta v1.4.45 wala hi
/// hai — sirf screens ki tartib aur shakal badli hai।
/// v1.4.48 GAARI KA RANG (malik ka hukm 2026-11-13): tay-shuda
/// rangon ki list — har entry (mehfooz honay wala canonical
/// Roman-Urdu NAAM, chip ke gole ka asal rang)। Driver gole par
/// tap karke rang chunta hai — parhna zaroori NAHI। Naam bilkul
/// isi shakal mein DriverProfile.vehicleColor mein jata hai,
/// wahan se backend `drivers.vehicle_color` column mein, aur
/// Master + sawari (booking ke baad wali pehchan) isi string ko
/// waisa hi dikhate hain — is liye naam kabhi badalna ho to
/// purane record bhi zehen mein rakhein।
const List<MapEntry<String, Color>> kVehicleColors = [
  MapEntry('Safed', Color(0xFFFFFFFF)),
  MapEntry('Kaala', Color(0xFF111111)),
  MapEntry('Golden', Color(0xFFD4A017)),
  MapEntry('Silver', Color(0xFFC0C0C0)),
  MapEntry('Sabz', Color(0xFF1E9E50)),
  MapEntry('Laal', Color(0xFFD32F2F)),
  MapEntry('Neela', Color(0xFF1565C0)),
  MapEntry('Peela', Color(0xFFF9D616)),
  MapEntry('Brown', Color(0xFF795548)),
  MapEntry('Cream', Color(0xFFF3E5C0)),
  MapEntry('Narangi', Color(0xFFFB8C00)),
  MapEntry('Doosra', Color(0xFF9E9E9E)),
];

class RegistrationWizard extends StatefulWidget {
  final AppStore store;
  const RegistrationWizard({super.key, required this.store});

  @override
  State<RegistrationWizard> createState() => _RegistrationWizardState();
}

class _RegistrationWizardState extends State<RegistrationWizard> {
  // v1.4.46: qadam titles ab NAYI tartib ke hain (har qadam apni
  // screen — index 0 Khush-Aamdeed hai, us ka title istemal nahi
  // hota kyunke wahan apni headline hai)।
  List<String> get _stepTitles => [
        '',
        tr('reg_t_mobile'),
        tr('reg_t_email'),
        tr('reg_t_name'),
        tr('guide_t_vehicle_type'),
        tr('reg_t_docs'),
        tr('reg_t_cnic_photo'),
        tr('reg_t_cnic_photo'),
        tr('reg_t_veh_docs'),
        tr('reg_t_licence'),
        tr('reg_t_fitness'),
        tr('reg_t_character'),
        tr('reg_t_selfie'),
        tr('reg_t_password'),
        tr('reg_t_summary'),
        tr('reg_t_terms'),
        // v1.4.75: index 16 — Gaari ki Tafseel (naya qadam,
        // Yango-form wali tartib: licence ke BAAD gaari ki
        // tafseel)। Purane indices (5-12) apni jagah mehfooz
        // hain taake hub/capture wali purani jaanchein na
        // tootein।
        tr('reg_t_veh_details'),
      ];

  /// Aakhri qadam (Sharait) ka index — Khush-Aamdeed index 0
  /// par hai, is liye kul form qadam 15 hain।
  static const int _lastStep = 15;

  // ===== v1.4.46 DESIGN: Documents HUB =====
  // Documents ke poore marhalay (capture qadam 6-12) ke samne
  // aik "Documents" list screen (qadam 5) aati hai — malik ki
  // manzoor-shuda design ki screen 5 jaisi। Har capture qadam
  // apni jagah (6-12) rakha gaya hai; hub har capture ke baad
  // khulta hai aur agli adhoori cheez dikhata hai। Back arrow
  // capture se HUB par wapas le jata hai (na ke pichle capture
  // par), taake driver hamesha list se aage barhe।
  static const int _hubStep = 5;

  /// Header mein nazar aane wale marhalay ki kul ta'adeed —
  /// v1.4.75 mein Yango-form wali tartib par 9 marhalay hain
  /// (Naam aur Sheher+Qisam alag alag qadam ban gaye)।
  static const int _totalPhases = 9;

  /// Documents marhalay ka capture qadam hai (6-12)?
  bool _isCaptureStep(int s) => s >= 6 && s <= 12;

  /// Header mein nazar aane wala marhala (9 marhalay):
  /// 1 Mobile, 2 Code, 3 Naam, 4 Sheher+Qisam, 5 Licence,
  /// 6 Gaari Tafseel, 7 Password, 8 Jaiza, 9 Sharait।
  /// v1.4.75 YANGO-FORM TARTIB (malik ka hukm 2026-11-24):
  /// wizard ka rasta — 0 Khush-Aamdeed (ijazatein), 1 Mobile,
  /// 2 Gmail+OTP (hamari pehchan ka nizam), 3 Naam (+CNIC
  /// number), 4 Sheher + gaari ki qisam, 9 Licence (number +
  /// issue date), 16 Gaari ki Tafseel (make/model/rang/saal/
  /// plate), 13 Password, 14 Jaiza, 15 Sharait → ID ban jati
  /// hai। Documents (tasaveer) wizard se bahar Home ki
  /// checklist ("Ye Qadam Mukammal Karein") mein hain —
  /// [_flow] dekhein। Qadam 5-8/10-12 ke purane capture
  /// screens is raste mein NAHI ate (un ke widgets neeche
  /// mehfooz hain lekin routed nahi hain)।
  int get _phase {
    // v1.4.77 GUIDE TARTIB: 1 Mobile, 2 Gmail+OTP, 3 Zaati
    // Maloomat, 4 Kaghazat (hub 5 + capture 6/7/9/12),
    // 5 Gaari (qisam 4 + tafseel 16), 6 Gaari ki Tasaveer (8),
    // 7 Password, 8 Jaiza/Status, 9 Sharait।
    if (_step == 1) return 1;
    if (_step == 2) return 2;
    if (_step == 3) return 3;
    if (_step == 5 || _step == 6 || _step == 7 || _step == 9 || _step == 12) {
      return 4;
    }
    if (_step == 4 || _step == 16) return 5;
    if (_step == 8) return 6;
    if (_step == 13) return 7;
    if (_step == 14) return 8;
    return 9;
  }

  /// Guide S4 ke capture qadam (hub se khulte hain, mukammal
  /// karke hub par wapas): 6 CNIC samne, 7 CNIC peeche,
  /// 9 Licence, 12 Live selfie।
  bool _isGuideCapture(int st) => st == 6 || st == 7 || st == 9 || st == 12;

  /// Har qadam ka bara pictorial icon (header mein) — anparh
  /// driver bhi sirf is nishan se samajh jaye ke ye screen kis
  /// cheez ki hai (malik ka hukm: har qadam par saaf icon)।
  IconData get _stepIcon {
    switch (_step) {
      case 1:
        return Icons.phone_android;
      case 2:
        return Icons.mark_email_unread;
      case 3:
        return Icons.person;
      case 4:
        return Icons.location_city;
      case 16:
        return Icons.directions_car;
      case 5:
        return Icons.photo_library;
      case 6:
      case 7:
        return Icons.credit_card;
      case 8:
        return Icons.description;
      case 9:
        return Icons.badge;
      case 10:
        return Icons.fact_check;
      case 11:
        return Icons.verified_user;
      case 12:
        return Icons.face;
      case 13:
        return Icons.lock;
      case 14:
        return Icons.checklist;
      case 15:
        return Icons.gavel;
      default:
        return Icons.app_registration;
    }
  }

  static const _brandSuggestions = <String, List<String>>{
    'Rickshaw': ['Sazgar', 'New Asia', 'Vespa', 'Super Power', 'Tez Raftaar'],
    'Bike': ['Honda', 'Yamaha', 'Suzuki', 'United', 'Super Star'],
    'Car': ['Suzuki', 'Toyota', 'Honda', 'Kia', 'Hyundai'],
    'Taxi': ['Suzuki', 'Toyota', 'Honda', 'Hyundai'],
    'Van': ['Suzuki Bolan', 'Toyota HiAce', 'Suzuki APV', 'Suzuki Every', 'Changan Karvaan'],
  };

  final ImagePicker _picker = ImagePicker();

  // --- v1.4.7: Email + OTP (spec §1) ----------------------------------
  // Gmail LAZMI hai; OTP usi email par jata hai aur tasdeeq ke
  // baad hi ID aage badhti hai. [_emailVerifiedFor] woh email hai
  // jis ki OTP tasdeeq is form mein ho chuki hai (ya profile mein
  // pehle se verified hai aur email wohi hai)।
  late final _emailCtrl = TextEditingController(text: p.email);
  String _emailVerifiedFor = '';

  // --- v1.4.7: Gaari ki baqi tasaveer (spec §7 photo set) --------------
  late String _vehicleBack = p.vehicleBackPath;
  late String _vehicleLeft = p.vehicleLeftPath;
  late String _vehicleRight = p.vehicleRightPath;
  late String _vehicleInterior = p.vehicleInteriorPath;

  // --- AWAAZ KI HIDAYAT (v1.4.5 — malik ka hukm 2026-11-08) ------
  // Har qadam par Urdu awaaz ki hidayat: clips pehle se bana kar
  // assets/guidance/ mein bundle hain (OFFLINE chalte hain —
  // internet ho ya na ho). Qadam khulte hi awaaz khud bajti hai;
  // AppBar ke speaker button se dobara suni ja sakti hai; CNIC /
  // gaari ki tasveer wale khano par tap karne par un ki apni
  // hidayat bhi bajti hai. Awaaz SIRF is wizard mein hai — baqi
  // poori app mein kahin awaaz nahi bajti.
  // v1.4.6 (Package A): player ab shared [GuideAudio] helper mein
  // hai (guide_audio.dart) — wizard apna AudioPlayer NAHI rakhta.

  /// Har step ki entry hidayat (index = v1.4.46 ki NAYI tartib
  /// ka step number)। Jis qadam ki apni clip nahi wahan null hai:
  /// awaaz khamosh rehti hai, screen ka likha hua matan hi asal
  /// hidayat hai। Clips wohi purani hain — sirf tartib badli hai,
  /// har clip apne MAWAAD (content) wale qadam par bajti hai।
  /// Gmail wale qadam par EmailOtpSection apni
  /// guidance_email.mp3 playGuideOnInit se khud bhi chalata hai।
  static const List<String?> _stepGuides = [
    null, // 0 Khush-Aamdeed — koi clip nahi
    'guidance/guidance_mobile.mp3', // 1 Mobile
    'guidance/guidance_email.mp3', // 2 Gmail + code
    'guidance/guidance_personal.mp3', // 3 Naam (+CNIC number)
    'guidance/guidance_vehicle.mp3', // 4 Sheher + Gaari ki qisam
    null, // 5 Documents HUB — list khud saaf hai, apni clip nahi
    'guidance/guidance_cnic_front.mp3', // 6 CNIC — samne
    'guidance/guidance_cnic_back.mp3', // 7 CNIC — peeche
    'guidance/guidance_vehicle_photo.mp3', // 8 Gaari ke kagaz/tasaveer
    'guidance/guidance_licence.mp3', // 9 Licence (ikhtiyari)
    // v1.4.19: is qadam ki hidayat guidance_gate_docs.mp3 hi
    // hai — purani guidance_permit.mp3 ka matan purane (sirf-
    // ikhtiyari) model ka tha, is liye woh is qadam par NAHI
    // bajti (clip file ane tak GuideAudio khamoshi se fail
    // hota hai — qadam NAHI rukta)।
    'guidance/guidance_gate_docs.mp3', // 10 Fitness+Insurance+Permit
    'guidance/guidance_character.mp3', // 11 Character Certificate
    'guidance/guidance_selfie.mp3', // 12 Live selfie
    'guidance/guidance_password.mp3', // 13 Password
    'guidance/guidance_review.mp3', // 14 Jaiza
    null, // 15 Sharait — is ki koi alag clip nahi
    'guidance/guidance_vehicle.mp3', // 16 Gaari ki Tafseel (v1.4.75)
  ];

  /// Radius wali awaaz ki hidayat — driver ki chuni hui
  /// zubaan mein (Urdu default). Offline bundle clips hain:
  /// guidance_radius_ur.mp3 / guidance_radius_en.mp3
  /// (owner ka jumla: "Aap apna kilometer yahan se set kar
  /// sakte hain — aap ko kitni doori tak ki sawari chahiye,
  /// woh chunein.")।
  String get _radiusGuideAsset => Lang.current == 'en'
      ? 'guidance/guidance_radius_en.mp3'
      : 'guidance/guidance_radius_ur.mp3';

  /// Mojooda step ki hidayat (dobara) chalana.
  void _playStepGuide() {
    if (_step < 0 || _step >= _stepGuides.length) return;
    if (_step == 14) {
      // Jaiza wala qadam: pehle aam review clip, phir RADIUS ki
      // hidayat — driver ko bol kar bataya jata hai ke woh apna
      // kilometer yahan se set kar sakta hai (final rule, owner
      // 2026-11-11 16:36)।
      final g = _stepGuides[_step];
      if (g != null) {
        unawaited(GuideAudio.playSequence([g, _radiusGuideAsset]));
      }
      return;
    }
    final g = _stepGuides[_step];
    if (g != null) unawaited(GuideAudio.play(g));
  }

  @override
  void initState() {
    super.initState();
    // v1.4.7: profile ki email pehle se verify shuda ho to
    // section "verify shuda" haalat se shuru hoti hai (email
    // badalne par EmailOtpSection khud tasdeeq khatam kar deti
    // hai — yahan sirf woh email yaad rakha jata hai)।
    if (p.emailVerified) _emailVerifiedFor = p.email.trim().toLowerCase();
    // v1.4.7 AGENT LINK (spec §6): agent ke link se app khuli ho
    // to code pehle se bhara mile — driver ko kuch likhna hi
    // nahi padta। Checked-code khaali rakha hai taaki aakhri
    // qadam par is ki backend jaanch lazmi ho (band agent ka
    // code nayi registration par nahi lagta — purana usool)।
    if (p.agentCode.isEmpty && store.pendingAgentCode.isNotEmpty) {
      _agentCodeCtrl.text = store.pendingAgentCode;
      _agentCheckedCode = '';
      _agentValidCode = '';
    }
    // Pehla qadam khulte hi us ki hidayat khud bajti hai.
    WidgetsBinding.instance
        .addPostFrameCallback((_) => _playStepGuide());
  }

  int _step = 0;
  bool _busy = false;
  bool _done = false;
  String? _error;

  /// v1.4.25: darkhwast ASAL mein backend (Master ki queue) tak
  /// pohanchi ya nahi — "Darkhwast Master ke paas chali gayi"
  /// ka dawa sirf isi par hoga; false ho to done screen imaandar
  /// khabar + "Dobara Bhejein" dikhati hai।
  bool _backendSent = false;
  bool _sendRetrying = false;

  AppStore get store => widget.store;
  DriverProfile get p => store.profile;

  // --- Form state (profile se shuru — edit par purani values dikhti hain)
  late final _mobileCtrl = TextEditingController(text: p.phone);
  late final _nameCtrl = TextEditingController(text: p.name);
  late final _cnicCtrl = TextEditingController(text: p.cnicNumber);
  late final _pwdCtrl = TextEditingController();
  late final _pwd2Ctrl = TextEditingController();
  late final _brandCtrl = TextEditingController(text: p.vehicleBrand);
  late final _modelCtrl = TextEditingController(text: p.vehicleModel);
  late final _colorCtrl = TextEditingController(text: p.vehicleColor);
  late final _plateCtrl = TextEditingController(text: p.plate);
  late final _licenceCtrl = TextEditingController(text: p.licenceNumber);
  // v1.4.75: licence ki ISSUE DATE ka khana (Yango-form wala
  // field)। v1.4.76: ab ye tareekh profile ke zariye backend
  // `drivers.licence_issue_date` column mein bhi save hoti
  // hai (column sql-fixes/drivers-licence-issue-date.sql se
  // banta hai; na laga ho to mirror push is ek column ko
  // gira deti hai — registration kabhi nahi rukti)। Dobara
  // registration/edit par profile mein mehfooz tareekh
  // pehle se bhari hui ati hai।
  late DateTime? _licenceIssueDate =
      DateTime.tryParse(p.licenceIssueDate);
  late final _licenceIssueCtrl = TextEditingController(
      text: _licenceIssueDate != null ? _fmtDate(_licenceIssueDate!) : '');
  // --- v1.4.77 GUIDE FIELDS ke controllers/state ---
  late DateTime? _licenceExpiryDate =
      DateTime.tryParse(p.licenceExpiryDate);
  late final _licenceExpiryCtrl = TextEditingController(
      text: _licenceExpiryDate != null ? _fmtDate(_licenceExpiryDate!) : '');
  late DateTime? _dob = DateTime.tryParse(p.dob);
  late final _dobCtrl = TextEditingController(
      text: _dob != null ? _fmtDate(_dob!) : '');
  late final _addressCtrl = TextEditingController(text: p.fullAddress);
  late final _emergencyNameCtrl =
      TextEditingController(text: p.emergencyName);
  late final _emergencyMobileCtrl =
      TextEditingController(text: p.emergencyMobile);
  // Licence ki alag tasaveer (Guide S4) — profile se bhari hui।
  late String _licenceFront = p.licenceFrontPath;
  late String _licenceBack = p.licenceBackPath;
  late String _licenceSelfie = p.licenceSelfiePath;
  // Registration kaghaz ki samne/peeche tasaveer (Guide S6)।
  late String _regFront = p.regFrontPath;
  late String _regBack = p.regBackPath;
  // Gaari (Guide S5): seating / ownership / features।
  late int _seating = p.seatingCapacity;
  late String _ownership = p.vehicleOwnership;
  late bool _featAc = p.vehicleFeatures.contains('AC');
  late bool _featLuggage = p.vehicleFeatures.contains('Luggage');
  // AGENT CODE (v1.4.6): aakhri qadam ka ikhtiyari field — profile
  // mein pehle se code ho (dobara registration/edit) to bhara
  // hua ata hai.
  late final _agentCodeCtrl = TextEditingController(text: p.agentCode);

  late String _vehicle = p.vehicle;
  late int? _year = p.vehicleYear > 0 ? p.vehicleYear : null;
  // FORM USOOL (owner, 2026-11-08): sheher pehle se set NAHI hota —
  // profile mein zone darj ho to wohi, warna khaali (null) aur
  // driver aakhri qadam mein apna sheher KHUD chunta hai. Pehle
  // yahan khamoshi se 'Karachi' lag jata tha — woh khatam.
  late String _zone = kZones.contains(p.zone) ? p.zone : '';
  // RADIUS — FINAL RULE (owner, 2026-11-11 16:36): registration
  // par 2 km PRE-SELECTED ata hai (profile ki maujooda value
  // 2–5 ke beech ho to wohi, warna 2 km); driver yahin se
  // 3/4/5 km kar sakta hai, 2 se kam NAHI ho sakta।
  late double _radiusKm =
      kRadiusOptionsKm.contains(p.radiusKm) ? p.radiusKm : 2.0;
  late String _cnicFront = p.cnicFrontPath;
  late String _cnicBack = p.cnicBackPath;
  late String _vehiclePhoto = p.vehiclePhotoPath;
  late String _vehicleReg = p.vehicleRegPath;
  late final _imeiCtrl = TextEditingController(text: p.imei);
  late String _licencePhoto = p.licencePhotoPath;
  late String _selfie = p.profilePhotoPath;

  // --- v1.4.14: Route Permit + Fitness wala qadam (naya qadam 6) ---
  // Tasaveer ikhtiyari hain; tasdeeq (checkbox) aage barhne ke
  // liye lazmi hai — ya phir driver yahin se registration khatam
  // karke bahir nikal sakta hai (koi zabardasti nahi)।
  late String _permitPhoto = p.permitPhotoPath;
  late String _fitnessPhoto = p.fitnessPhotoPath;
  // v1.4.19: do naye kagaz (record ke lazmi hisse) — profile se
  // pehle se bhare hue ate hain (adhoori registration mehfooz
  // rehti hai: driver baad mein aye to SIRF baqi kagaz lagata
  // hai, shuru se dobara NAHI)।
  late String _insurancePhoto = p.insurancePhotoPath;
  late String _characterPhoto = p.characterPhotoPath;
  late bool _permitDeclChecked = p.permitFitnessDeclAtMs > 0;
  late bool _licenceSkip =
      !(p.licenceStatus == 'has' || p.licenceNumber.isNotEmpty);

  /// Sharait ki qubooliyat (v1.4.4 LEGAL): review wale aakhri
  /// qadam par driver "Mein ne parh liya, qabool hai" par nishan
  /// lagata hai — baghair is ke register NAHI hota. Nishan lagte
  /// hi waqt profile mein darj ho jata hai (aur save par backend
  /// drivers.terms_accepted_at mein Master ke saboot ke liye
  /// jata hai). Pehle se qabool shuda ho to nishan laga hua ata hai.
  late bool _termsChecked = p.termsAcceptedAtMs > 0;

  /// AMANAT DEPOSIT ki alag tasdeeq (v1.4.21 — malik ka faisla
  /// 2026-11-10 20:05): review qadam par driver alag se nishan
  /// lagata hai ke us ne Amanat Deposit ki shartein samajh li
  /// hain — baghair is tasdeeq ke register NAHI hota. Asal
  /// shartein Sharait (legal.dart — "Amanat Deposit" wala hissa)
  /// mein hain; qubooliyat ka saboot termsAcceptedAtMs wala
  /// wohi waqt hai (tasdeeq usi sharait ki hai).
  bool _amanatChecked = false;

  /// Password jo is wizard mein uniqueness check PASS kar chuka hai —
  /// us ka fingerprint. Register dabane par profile mein lagta hai.
  /// (Profile par pehle se password ho to ye null rehta hai aur
  /// password wala qadam sirf maloomat dikhata hai.)
  String? _stagedFp;

  /// Jo password text check pass kar chuka hai — wohi dobara likha
  /// jaye to backend check dobara nahi chalta.
  String _checkedPw = '';

  /// AGENT CODE ki haalat (v1.4.6): [_agentCheckedCode] woh code
  /// hai jis ki backend jaanch ho chuki hai; [_agentValidCode]
  /// sirf tab bhara hota hai jab woh code kisi ACTIVE agent ka
  /// nikla ho — submit par profile mein sirf yehi jata hai.
  /// Code ikhtiyari hai: na mile to registration NAHI rukti,
  /// sirf halki warning ati hai. Profile ka purana code pehle
  /// se checked/valid mana jata hai (dobara edit par jab tak
  /// driver code BADLE nahi); agent baad mein band ho jaye to
  /// purana link/record waisa hi rehta hai (malik ka usool).
  late String _agentCheckedCode = p.agentCode;
  late String _agentValidCode = p.agentCode;

  /// FIX 2026-11-21 (postmortem kami #12): driver ne code likha
  /// lekin jaanch us waqt pakki na ho saki (internet fail, ya
  /// agent us waqt na mila/band tha) — woh code yahan rehta hai
  /// aur submit par store.pendingAgentCode mein mehfooz ho jata
  /// hai taaki agli sync par khud lag jaye (Backend ka
  /// retryPendingAgentCode)। Pehle aisi haalat mein code
  /// khamoshi se GHUM jata tha aur driver hamesha ke liye
  /// partner-fee hisaab se bahar reh jata tha।
  String _agentPendingCode = '';

  @override
  void dispose() {
    unawaited(GuideAudio.stop());
    // v1.4.77 AUTO-SAVE DRAFT: wizard jis haalat mein bhi band
    // ho, bhari hui maloomat phone par mehfooz ho jati hai —
    // dobara kholne par wahi se continue hota hai।
    unawaited(_saveDraft());
    _mobileCtrl.dispose();
    _nameCtrl.dispose();
    _cnicCtrl.dispose();
    _imeiCtrl.dispose();
    _pwdCtrl.dispose();
    _pwd2Ctrl.dispose();
    _brandCtrl.dispose();
    _modelCtrl.dispose();
    _colorCtrl.dispose();
    _plateCtrl.dispose();
    _licenceCtrl.dispose();
    _licenceIssueCtrl.dispose();
    _licenceExpiryCtrl.dispose();
    _dobCtrl.dispose();
    _addressCtrl.dispose();
    _emergencyNameCtrl.dispose();
    _emergencyMobileCtrl.dispose();
    _agentCodeCtrl.dispose();
    _emailCtrl.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  // --- Tasveer chunna --------------------------------------------------------

  // Quality check thresholds (v1.4.6 Package A — conservative:
  // sirf WAZEH kharab tasveer rukti hai, aam tasveer kabhi nahi).
  static const double _kDarkLuminanceThreshold = 26.0;
  static const double _kBlurVarianceThreshold = 15.0;

  /// Halki quality jaanch: picked file ke bytes se chhota (96px
  /// wide) frame decode karke mean luminance (andhera) aur
  /// grayscale Laplacian variance (dhundlapan) napta hai.
  ///
  /// Wapas: 'dark' | 'blur' | null (theek hai).
  /// Check KHUD fail ho (exception / decode na ho) to null —
  /// quality check registration ko KABHI nahi rokti.
  Future<String?> _checkPhotoQuality(String path) async {
    try {
      final bytes = await File(path).readAsBytes();
      if (bytes.isEmpty) return null;
      final codec = await ui.instantiateImageCodec(
        bytes,
        targetWidth: 96,
      );
      final frame = await codec.getNextFrame();
      final image = frame.image;
      final int w = image.width;
      final int h = image.height;
      final ByteData? data =
          await image.toByteData(format: ui.ImageByteFormat.rawRgba);
      image.dispose();
      if (data == null) return null;
      final Uint8List px = data.buffer.asUint8List();
      final int count = w * h;
      if (count <= 0 || px.length < count * 4) return null;

      // Grayscale + mean luminance (ek hi pass).
      final Float64List gray = Float64List(count);
      double lumSum = 0;
      for (var i = 0; i < count; i++) {
        final int o = i * 4;
        final double lum =
            0.299 * px[o] + 0.587 * px[o + 1] + 0.114 * px[o + 2];
        gray[i] = lum;
        lumSum += lum;
      }
      final double meanLum = lumSum / count;
      if (meanLum < _kDarkLuminanceThreshold) return 'dark';

      // Laplacian variance — 3x3 kernel [0,1,0; 1,-4,1; 0,1,0],
      // andar wale pixels par stride sampling (bare frame par
      // har doosra pixel) taaki hisaab halka rahe.
      if (w < 3 || h < 3) return null;
      const int stride = 2;
      double lapSum = 0;
      double lapSqSum = 0;
      int n = 0;
      for (var y = 1; y < h - 1; y += stride) {
        for (var x = 1; x < w - 1; x += stride) {
          final int idx = y * w + x;
          final double lap = gray[idx - w] +
              gray[idx + w] +
              gray[idx - 1] +
              gray[idx + 1] -
              4 * gray[idx];
          lapSum += lap;
          lapSqSum += lap * lap;
          n++;
        }
      }
      if (n == 0) return null;
      final double mean = lapSum / n;
      final double variance = (lapSqSum / n) - (mean * mean);
      if (variance < _kBlurVarianceThreshold) return 'blur';
      return null;
    } catch (_) {
      // Check fail = photo apply ho jaye (kabhi rok NAHI).
      return null;
    }
  }

  /// Camera ya gallery se tasveer — selfie wale qadam ke ilawa har
  /// jagah dono option hain (mojooda app ka image picking pattern).
  /// v1.4.6: apply se PEHLE halki quality jaanch (andhera/dhundla)
  /// — fail par awaaz wali hidayat + snack, photo apply NAHI hoti.
  Future<void> _pickPhoto(void Function(String path) apply,
      {bool cameraOnly = false, bool faceCheck = false}) async {
    ImageSource? src = cameraOnly ? ImageSource.camera : null;
    if (!cameraOnly) {
      src = await showModalBottomSheet<ImageSource>(
        context: context,
        builder: (ctx) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt, color: Brand.green),
                title: Text(tr('reg_pick_camera')),
                onTap: () => Navigator.pop(ctx, ImageSource.camera),
              ),
              ListTile(
                leading:
                    const Icon(Icons.photo_library, color: Brand.green),
                title: Text(tr('reg_pick_gallery')),
                onTap: () => Navigator.pop(ctx, ImageSource.gallery),
              ),
            ],
          ),
        ),
      );
    }
    if (src == null || !mounted) return;
    try {
      // v1.4.47 FIX (2026-11-22 — Master wala fix mirror):
      // picker par hi size ghata do (maxWidth/maxHeight 1600,
      // quality 80) — bari asal tasveer upload par 400/timeout
      // ka sabab banti thi; halki tasveer sust net par bhi
      // aram se jati hai।
      final img = await _picker.pickImage(
          source: src, maxWidth: 1600, maxHeight: 1600, imageQuality: 80);
      if (img == null) {
        // HOTFIX v1.2.9 (RC3): camera/gallery band karne par
        // khamoshi se wapas NAHI — wajah batao (duty selfie wala
        // wohi jumla/andaaz).
        if (mounted) {
          _snack(tr('sf_snack_nophoto'));
        }
        return;
      }
      // --- Quality jaanch (apply se pehle) ---
      final String? issue = await _checkPhotoQuality(img.path);
      if (!mounted) return;
      if (issue == 'dark') {
        unawaited(GuideAudio.play('guidance/guidance_error_dark.mp3'));
        _snack(tr('reg_photo_dark'));
        return;
      }
      if (issue == 'blur') {
        unawaited(GuideAudio.play('guidance/guidance_error_blur.mp3'));
        _snack(tr('reg_photo_blur'));
        return;
      }
      // LIVE SELFIE ki chehra-jaanch (fix 2026-11-21): sirf
      // selfie wale qadam par (faceCheck) — wohi gate jo
      // random check aur rozana duty selfie par lagta hai
      // (evaluateSelfieFace)। Chehra na lage ya jaanch hi
      // na ho sake to photo apply NAHI hoti — dobara selfie।
      if (faceCheck) {
        final face = await evaluateSelfieFace(img.path);
        if (!mounted) return;
        if (face == SelfieFaceResult.error) {
          _snack(tr('sf_note_check_error'));
          return;
        }
        if (face == SelfieFaceResult.noFace) {
          unawaited(
              GuideAudio.play('guidance/guidance_selfie_face.mp3'));
          _snack(tr('reg_selfie_noface'));
          return;
        }
      }
      if (mounted) setState(() => apply(img.path));
      // v1.4.77: photo lagte hi draft mehfooz (auto-save)।
      unawaited(_saveDraft());
    } catch (_) {
      unawaited(GuideAudio.play('guidance/guidance_error_upload.mp3'));
      if (mounted) _snack(tr('pick_photo_failed'));
    }
  }

  // --- v1.4.77 AUTO-SAVE DRAFT (Guide S3) -----------------------------------
  // Form ki maujooda haalat profile mein jama karna — BINA
  // registrationDone lagaye aur BINA backend bheje (woh sirf
  // asal _submit par hota hai)। Draft sirf phone par mehfooz
  // hota hai (store.saveLocalOnly) taaki adhoori darkhwast
  // Master ki queue mein na jaye; dobara wizard khule to saare
  // khane profile se pehle se bhare hue milte hain।
  void _collectDraft() {
    final v = p;
    v.name = _nameCtrl.text.trim();
    v.phone = _digits(_mobileCtrl.text);
    final cnicDigits = _digits(_cnicCtrl.text);
    v.cnicNumber =
        cnicDigits.length == 13 ? _formatCnic(cnicDigits) : cnicDigits;
    final email = _emailCtrl.text.trim().toLowerCase();
    v.email = email;
    if (_emailVerifiedFor == email && email.isNotEmpty) {
      v.emailVerifiedAtMs = DateTime.now().millisecondsSinceEpoch;
      v.otpSessionVerified = true;
    }
    v.dob = _dob != null ? _isoDate(_dob!) : '';
    v.fullAddress = _addressCtrl.text.trim();
    v.emergencyName = _emergencyNameCtrl.text.trim();
    v.emergencyMobile = _digits(_emergencyMobileCtrl.text);
    v.zone = _zone;
    v.vehicle = _vehicle;
    v.vehicleBrand = _brandCtrl.text.trim();
    v.vehicleModel = _modelCtrl.text.trim();
    v.vehicleYear = _year ?? 0;
    v.vehicleColor = _colorCtrl.text.trim();
    v.plate = _plateCtrl.text.trim();
    v.imei = _digits(_imeiCtrl.text);
    if (_stagedFp != null) v.pwdFp = _stagedFp!;
    // Tasaveer (sare khane — jo laga hai wohi mehfooz)।
    v.cnicFrontPath = _cnicFront;
    v.cnicBackPath = _cnicBack;
    v.vehiclePhotoPath = _vehiclePhoto;
    v.vehicleBackPath = _vehicleBack;
    v.vehicleLeftPath = _vehicleLeft;
    v.vehicleRightPath = _vehicleRight;
    v.vehicleInteriorPath = _vehicleInterior;
    v.regFrontPath = _regFront;
    v.regBackPath = _regBack;
    v.vehicleRegPath = _regFront.isNotEmpty ? _regFront : _vehicleReg;
    v.permitPhotoPath = _permitPhoto;
    v.fitnessPhotoPath = _fitnessPhoto;
    v.insurancePhotoPath = _insurancePhoto;
    v.characterPhotoPath = _characterPhoto;
    v.profilePhotoPath = _selfie;
    // Licence: skip par saaf, warna number + tareekhein + tasaveer।
    if (_licenceSkip) {
      v.licenceStatus = 'none';
      v.licenceVerified = false;
      v.licenceNumber = '';
      v.licenceIssueDate = '';
      v.licenceExpiryDate = '';
      v.licencePhotoPath = '';
      v.licenceFrontPath = '';
      v.licenceBackPath = '';
      v.licenceSelfiePath = '';
    } else {
      v.licenceStatus = 'has';
      v.licenceNumber = _licenceCtrl.text.trim();
      v.licenceIssueDate =
          _licenceIssueDate != null ? _isoDate(_licenceIssueDate!) : '';
      v.licenceExpiryDate =
          _licenceExpiryDate != null ? _isoDate(_licenceExpiryDate!) : '';
      v.licenceFrontPath = _licenceFront;
      v.licenceBackPath = _licenceBack;
      v.licenceSelfiePath = _licenceSelfie;
      v.licencePhotoPath =
          _licenceFront.isNotEmpty ? _licenceFront : _licencePhoto;
    }
    // Gaari (Guide S5)।
    v.seatingCapacity = _seating;
    v.vehicleOwnership = _ownership;
    v.vehicleFeatures = [
      if (_featAc) 'AC',
      if (_featLuggage) 'Luggage',
    ].join(',');
    v.radiusKm = _radiusKm;
  }

  Future<void> _saveDraft() async {
    try {
      _collectDraft();
      await store.saveLocalOnly();
    } catch (_) {
      // Draft save ki nakami form ko KABHI nahi rokti।
    }
  }

  // --- Validation -------------------------------------------------------------

  String _digits(String s) => s.replaceAll(RegExp(r'[^0-9]'), '');

  bool _fail(String msg) {
    setState(() => _error = msg);
    return false;
  }

  /// IMEI ki durusti: 15 digits + Luhn check digit (aakhri digit
  /// baqion se hisaab hota hai — ek digit ki typo bhi pakri jati
  /// hai). Ye sirf TYPO ki jaanch hai; PTA-approved hai ya nahi,
  /// ye faisla Master Tasdeeq mein 8484/DIRBS check se karta hai.
  bool _validImei(String d) {
    if (d.length != 15) return false;
    var sum = 0;
    for (var i = 0; i < 15; i++) {
      var n = int.tryParse(d[i]) ?? -1;
      if (n < 0) return false;
      if (i.isOdd) {
        n *= 2;
        if (n > 9) n -= 9;
      }
      sum += n;
    }
    return sum % 10 == 0;
  }

  /// Plate ki normalized shakal (bare haroof + number; spaces/
  /// dashes khatam) — takrao ki jaanch har jagah isi par hoti hai।
  static String _normPlate(String s) =>
      s.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

  /// EK GAARI = EK ID wala hold (spec §7 — wazahat ka rasta):
  /// plate doosri ID par mile to driver yahan SAARI tafseel
  /// likhta hai; "bhejein" par baat Master ke inbox mein
  /// ('Gaari Transfer' category) jati hai aur true wapas ata hai।
  Future<bool> _showPlateTransferDialog(String plateNorm) async {
    final ctrl = TextEditingController();
    final sent = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text(tr('reg_plate_title')),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                trf('reg_plate_body', {'plate': plateNorm}),
                style: const TextStyle(fontSize: 13.5, height: 1.45),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: ctrl,
                maxLines: 4,
                decoration: InputDecoration(
                  labelText: tr('reg_plate_label'),
                  border: const OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('reg_cancel')),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('reg_plate_send')),
          ),
        ],
      ),
    );
    final tafseel = ctrl.text.trim();
    ctrl.dispose();
    if (sent != true) return false;
    await store.addMasterMessage(MasterMessage(
      id: store.newId(),
      senderKey: store.driverId,
      senderRole: 'driver',
      senderName: _nameCtrl.text.trim(),
      senderMobile: _digits(_mobileCtrl.text),
      senderZone: '',
      category: 'Gaari Transfer',
      body: 'GAARI TRANSFER WAZAHAT\n'
          'Plate: ${_plateCtrl.text.trim()} (normalized: $plateNorm)\n'
          'Gaari: $_vehicle · ${_brandCtrl.text.trim()} ${_modelCtrl.text.trim()}\n'
          'Masla: ye gaari pehle se doosri driver ID par darj hai — registration wahin ruk gayi hai.\n'
          'Driver ki wazahat: ${tafseel.isEmpty ? '(tafseel nahi likhi)' : tafseel}',
      createdAt: DateTime.now(),
    ));
    return true;
  }

  Future<bool> _validateStep() => _validateStepFor(_step);

  /// Documents HUB ka "Aage Barhein": documents marhalay ki HAR
  /// lazmi jaanch ek ek karke chalti hai — wohi asal usool, koi
  /// jaanch skip NAHI hoti। Pehli nakami par usi ki khabar rukti
  /// hai (driver hub se us kagaz ki satr khol kar theek karta
  /// hai): CNIC samne (6), CNIC peeche (7), gaari ke kagaz/
  /// tasaveer (8), licence (9 — skip par khud pass), fitness ki
  /// tasdeeq (10), character (11 — hamesha pass), selfie (12)।
  Future<bool> _validateHub() async {
    // v1.4.77: hub ab Guide S4 (Kaghazat) ka hai — CNIC
    // samne/peeche (6/7), Licence (9 — skip par khud pass),
    // Live selfie (12)। Gaari ki tasaveer (8) is ke BAAD apne
    // qadam par validate hoti hain (Guide S6 ki tartib)।
    for (final s in const [6, 7, 9, 12]) {
      if (!await _validateStepFor(s)) return false;
    }
    return true;
  }

  Future<bool> _validateStepFor(int step) async {
    setState(() => _error = null);
    // v1.4.46: jaanchein wohi purani hain — sirf NAYI tartib ke
    // qadmon par taqseem hain (har check apne mawaad wale qadam
    // par): email wali jaanch Gmail qadam par, CNIC wali CNIC
    // qadmon par, sheher wali Naam+Sheher qadam par, sharait
    // wali Sharait qadam par।
    switch (step) {
      case 1:
        // Mobile (purana qadam 1)।
        final d = _digits(_mobileCtrl.text);
        if (!(d.length == 11 && d.startsWith('03'))) {
          return _fail(tr('reg_err_mobile'));
        }
        return true;
      case 2:
        // Gmail + OTP (purane Zaati Maloomat qadam ka email
        // hissa): Gmail lazmi hai aur us ki OTP tasdeeq ke
        // baghair ID aage NAHI badhti।
        final email = _emailCtrl.text.trim().toLowerCase();
        if (!(email.length >= 5 &&
            email.contains('@') &&
            email.split('@').last.contains('.'))) {
          return _fail(tr('reg_err_email'));
        }
        if (_emailVerifiedFor != email) {
          return _fail(tr('reg_err_email_unverified'));
        }
        return true;
      case 3:
        // Naam + CNIC number (v1.4.75: sheher is qadam se
        // nikal kar apne alag qadam 4 — Sheher + Qisam — par
        // chala gaya hai; us ki jaanch bhi wahin hoti hai)।
        if (_nameCtrl.text.trim().length < 3) {
          return _fail(tr('reg_err_name'));
        }
        // v1.4.68: CNIC NUMBER ki jaanch bhi ab yahin hoti hai
        // (khana isi qadam par hai — CNIC ki TASAVEER Home ki
        // checklist se baad mein lagti hain, lekin number ID
        // banne se pehle pakka hota hai)। EK CNIC = EK ACCOUNT
        // (malik ka hukm 2026-11-08): ye CNIC kisi aur driver
        // account mein pehle se darj ho to doosra account yahin
        // ruk jata hai — purane qadam 6 wali ain jaanch, sirf
        // jagah badli hai।
        if (_digits(_cnicCtrl.text).length != 13) {
          return _fail(tr('reg_err_cnic'));
        }
        // v1.4.77 GUIDE S3: Date of birth lazmi (date picker
        // se), sheher lazmi (khana ab isi page par hai), aur
        // mukammal pata lazmi। Emergency contact recommended
        // hai — bhara jaye to number durust hona lazmi hai।
        if (_dob == null) {
          return _fail(tr('guide_err_dob'));
        }
        if (_zone.isEmpty) {
          return _fail(tr('reg_err_zone'));
        }
        if (_addressCtrl.text.trim().length < 8) {
          return _fail(tr('guide_err_address'));
        }
        final emName = _emergencyNameCtrl.text.trim();
        final emMobile = _digits(_emergencyMobileCtrl.text);
        if ((emName.isNotEmpty || emMobile.isNotEmpty) &&
            !(emMobile.length == 11 && emMobile.startsWith('03'))) {
          return _fail(tr('guide_err_emergency'));
        }
        setState(() => _busy = true);
        final cnicTaken3 = await Backend.cnicTakenByOther(
            _digits(_cnicCtrl.text), store.driverId);
        if (!mounted) return false;
        setState(() => _busy = false);
        if (cnicTaken3 == null) {
          return _fail(tr('reg_err_cnic_net'));
        }
        if (cnicTaken3) {
          return _fail(tr('reg_err_cnic_taken'));
        }
        return true;
      case 4:
        // Gaari ki QISAM (v1.4.77: sheher Zaati Maloomat wale
        // page par chala gaya — Guide S3; is qadam par sirf
        // qisam ke cards hain)। Qisam hamesha set rehti hai
        // (profile ki default value; driver cards se badal
        // sakta hai) — alag jaanch nahi।
        return true;
      case 16:
        // Gaari ki TAFSEEL ki jaanch (v1.4.75: pehle ye qadam 4
        // par thi — ab licence ke baad wale naye qadam 16 par
        // hai। Tasaveer ki jaanch Kagaz wale qadam 8 par hai)।
        if (_brandCtrl.text.trim().isEmpty) {
          return _fail(tr('reg_err_brand'));
        }
        if (_modelCtrl.text.trim().isEmpty) {
          return _fail(tr('reg_err_model'));
        }
        if (_year == null) return _fail(tr('reg_err_year'));
        if (_colorCtrl.text.trim().isEmpty) {
          return _fail(tr('reg_err_color'));
        }
        // v1.4.77 GUIDE S5: seating capacity + ownership lazmi
        // hain (features ikhtiyari hain — un ki jaanch nahi)।
        if (_seating <= 0) {
          return _fail(tr('guide_err_seating'));
        }
        if (_ownership.isEmpty) {
          return _fail(tr('guide_err_ownership'));
        }
        // v1.4.7 PLATE RULE (spec §7 + malik ki voice line
        // 2026-11-08 23:48): kam az kam EK side (samne ya peeche)
        // par number lazmi hai — plate hi na ho to qadam yahin
        // rukta hai aur awaaz wali hidayat chalti hai।
        if (_plateCtrl.text.trim().isEmpty) {
          unawaited(GuideAudio.play('guidance/guidance_plate.mp3'));
          return _fail(tr('reg_err_plate_empty'));
        }
        // PTA Proof: IMEI ki shart Master ke switch par hai
        // (settings.pta_required, migration v133; Fares.ptaRequired).
        // Default BAND hai — IMEI filhal IKHTIYARI hai: khaali ho
        // to koi rok nahi; LIKHA jaye to durust (15 digits + Luhn
        // check digit — typo yahin pakra jata hai) hona lazmi hai.
        // Master switch ON kare to IMEI lazmi ho jata hai.
        final imeiDigits = _digits(_imeiCtrl.text);
        if (Fares.ptaRequired &&
            (imeiDigits.length != 15 || !_validImei(imeiDigits))) {
          return _fail(tr('reg_err_imei_req'));
        }
        if (!Fares.ptaRequired &&
            imeiDigits.isNotEmpty &&
            (imeiDigits.length != 15 || !_validImei(imeiDigits))) {
          return _fail(tr('reg_err_imei_opt'));
        }
        // v1.4.7 EK GAARI = EK ID (spec §7): ye plate kisi AUR
        // driver ki ID par pehle se ho to registration wahin rukti
        // hai — lekin band gali NAHI: driver apni saari tafseel
        // Master ko likh sakta hai; Master manzoor kare to gaari
        // purani ID se hat kar is ID par lag jayegi। Check khud
        // fail ho (net na mile) to registration NAHI rukti — asal
        // takrao hi rokta hai (warna net ki kharabi par har
        // registration atki rahegi); backend unique index (v137)
        // peeche ki asal hifazat hai।
        final plateNorm = _normPlate(_plateCtrl.text);
        if (plateNorm.length >= 4) {
          setState(() => _busy = true);
          // v1.4.23: takrao ka check ab plate_taken RPC se (sirf
          // boolean) — tamam drivers ki plates ki list ab app tak
          // ati hi nahi (flip ke baad woh parhai band hai)।
          final plateTaken = await Backend.plateTakenByOther(
              _plateCtrl.text, store.driverId);
          if (!mounted) return false;
          setState(() => _busy = false);
          if (plateTaken == true) {
            final sent = await _showPlateTransferDialog(plateNorm);
            if (!mounted) return false;
            if (sent) {
              return _fail(tr('reg_err_plate_sent'));
            }
            return _fail(
                trf('reg_err_plate_taken', {'plate': plateNorm}));
          }
        }
        return true;
      case _hubStep:
        // Documents HUB — saari lazmi jaanchein ek saath।
        return _validateHub();
      case 6:
        // CNIC — samne (purane Zaati Maloomat qadam ka CNIC
        // hissa: number + backend jaanch + samne wali tasveer)।
        if (_digits(_cnicCtrl.text).length != 13) {
          return _fail(tr('reg_err_cnic'));
        }
        // EK CNIC = EK ACCOUNT (malik ka hukm 2026-11-08):
        // account shakhs (CNIC) ka hota hai, number/SIM ka nahi.
        // Ye CNIC kisi aur driver account mein pehle se darj ho
        // to doosra/fake account yahin ruk jata hai. Password
        // wale qadam wala hi usool: internet na mile to check
        // pass NAHI mana jata.
        setState(() => _busy = true);
        final cnicTaken = await Backend.cnicTakenByOther(
            _digits(_cnicCtrl.text), store.driverId);
        if (!mounted) return false;
        setState(() => _busy = false);
        if (cnicTaken == null) {
          return _fail(tr('reg_err_cnic_net'));
        }
        if (cnicTaken) {
          return _fail(tr('reg_err_cnic_taken'));
        }
        if (_cnicFront.isEmpty) {
          return _fail(tr('reg_err_cnic_front'));
        }
        return true;
      case 7:
        // CNIC — peeche।
        if (_cnicBack.isEmpty) {
          return _fail(tr('reg_err_cnic_back'));
        }
        return true;
      case 8:
        // Gaari ki tasaveer + kaghazat — GUIDE S6 (Boz ka naya
        // hukm 2026-11-24): chaaron taraf ki tasaveer lazmi
        // hain — samne (_vehiclePhoto), peeche (_vehicleBack),
        // bayein (_vehicleLeft), dayein (_vehicleRight) — aur
        // registration kaghaz ki samne/peeche tasaveer।
        // 2026-11-22 wala 2-photo usool supersede ho gaya।
        // Fitness/Permit/Insurance ke khane isi page par hain
        // lekin IKHTIYARI/sharti hain — un par qadam NAHI
        // rukta (Insurance ka pakka usool 2026-11-24 01:10)।
        if (_vehiclePhoto.isEmpty) {
          return _fail(tr('reg_err_veh_front'));
        }
        if (_vehicleBack.isEmpty) {
          return _fail(tr('reg_err_veh_back'));
        }
        if (_vehicleLeft.isEmpty) {
          return _fail(tr('reg_err_veh_left'));
        }
        if (_vehicleRight.isEmpty) {
          return _fail(tr('reg_err_veh_right'));
        }
        if (_regFront.isEmpty || _regBack.isEmpty) {
          return _fail(tr('reg_err_veh_reg'));
        }
        return true;
      case 9:
        // Driving licence — v1.4.68: is qadam par sirf NUMBER
        // darj hota hai (ya "licence nahi hai" wala skip)।
        // Licence ki TASVEER ab ID banne ke baad Home ki
        // checklist se lagti hai — is liye photo ki shart yahan
        // khatam hai (purani v1.4.35 wali "number ho to photo
        // lazmi" wali rok ab checklist par hai: number darj
        // karne wala driver checklist mein licence ki photo
        // wala qadam dekhega)।
        if (_licenceSkip) return true;
        if (_licenceCtrl.text.trim().isEmpty) {
          return _fail(tr('reg_err_licence'));
        }
        // v1.4.75: licence ki ISSUE DATE bhi lazmi hai
        // (Yango-form wala khana) — number ho aur tareekh na
        // ho to tafseel adhoori mani jati hai।
        if (_licenceIssueDate == null) {
          return _fail(tr('reg_err_lic_issue'));
        }
        // v1.4.77 GUIDE S4: EXPIRY DATE + licence ki tasaveer
        // (samne/peeche/pakre selfie) bhi lazmi hain — number
        // diya hai to ye sab bhi (licence optional usool
        // barkarar: na ho to skip ka rasta maujood hai)।
        if (_licenceExpiryDate == null) {
          return _fail(tr('guide_err_lic_expiry'));
        }
        if (_licenceFront.isEmpty && _licencePhoto.isEmpty) {
          return _fail(tr('guide_err_lic_front'));
        }
        if (_licenceBack.isEmpty) {
          return _fail(tr('guide_err_lic_back'));
        }
        if (_licenceSelfie.isEmpty) {
          return _fail(tr('guide_err_lic_selfie'));
        }
        return true;
      case 10:
        // Fitness + Insurance + Permit (purana qadam 6)।
        // v1.4.19 DARMIYANI MODEL (malik ka FINAL faisla
        // 2026-11-10 18:18): Fitness Certificate aur Insurance
        // ke khane is qadam par maujood hain — jis ke paas hai
        // woh yahin upload kar deta hai; na hon to qadam NAHI
        // rukta (rehnumai neeche di hai, baad mein "Mere Kagaz"
        // se bhi lag jate hain)। In ki tasdeeq Master karega aur
        // saare kagaz verify hon to 'Mukammal Tasdeeq' darja
        // milta hai। Khud-zimmedari ki TASDEEQ (permit wala
        // hisaab, v1.4.14 se) barkarar hai — is qadam se aage
        // barhne ke liye woh qabool karna lazmi hai (saboot
        // waqt ke saath mehfooz hota hai)।
        if (!_permitDeclChecked && p.permitFitnessDeclAtMs == 0) {
          return _fail(tr('reg_err_decl'));
        }
        return true;
      case 11:
        // Police Character Certificate (purana qadam 7)।
        // v1.4.19 DARMIYANI MODEL: Police Character Certificate
        // ka khana maujood hai aur har driver se manga jata hai
        // (Karachi/Sindh mein official rule abhi na aya ho, phir
        // bhi; Punjab mein baghair is ke tasdeeq mukammal nahi
        // hoti) — lekin certificate ki tangi par registration
        // NAHI rukti: photo ho to yahin lag jati hai, na ho to
        // rehnumai se banwa kar baad mein "Mere Kagaz" se lag
        // jayegi। Tasdeeq Master karega; ye kagaz 'Mukammal
        // Tasdeeq' darje ke set mein shamil hai।
        return true;
      case 12:
        // Live selfie (purana qadam 8)।
        if (_selfie.isEmpty) {
          return _fail(tr('reg_err_selfie'));
        }
        return true;
      case 13:
        // Password (purana qadam 3)।
        return _validatePasswordStep();
      case 14:
        // Jaiza (purane Jaiza qadam ka AGENT CODE hissa)।
        // AGENT CODE (v1.4.6): ikhtiyari hai — likha jaye to
        // backend `agents` mein jaanch hoti hai: ACTIVE agent
        // mile to code pakka ho jata hai (drivers.agent_code);
        // na mile to sirf halki warning — registration KABHI
        // nahi rukti, driver baghair code ke aage barh sakta hai.
        // Band (inactive) agent ka code nayi registration par
        // NAHI lagta (yahin se ruk jata hai: active check lazmi).
        // v1.4.14 (faisla D-1 — agents ke liye email lazmi):
        // agent code tab hi lagta hai jab driver ki Gmail OTP
        // se verify shuda ho — email tasdeeq ke baghair koi
        // agent link NAHI banta। (Wizard ka Gmail wala qadam
        // isay pehle hi lazmi kar chuka hai; ye guard usool ko
        // yahan bhi wazeh rakhta hai।)
        final emailOk =
            _emailVerifiedFor == _emailCtrl.text.trim().toLowerCase();
        final agentCode = _agentCodeCtrl.text.trim().toUpperCase();
        if (agentCode.isEmpty) {
          _agentValidCode = '';
          _agentPendingCode = '';
        } else if (!emailOk) {
          // Email tasdeeq ke baghair code pakka NAHI lag sakta
          // (usool wohi hai) — lekin code ghumta bhi nahi:
          // pending mehfooz rehta hai (fix 2026-11-21)।
          _agentValidCode = '';
          _agentPendingCode = agentCode;
        } else if (agentCode != _agentCheckedCode) {
          setState(() => _busy = true);
          final agent = await AgentApi.fetchAgentByCode(agentCode);
          if (!mounted) return false;
          setState(() => _busy = false);
          _agentCheckedCode = agentCode;
          if (agent != null && agent.active) {
            _agentValidCode = agentCode;
            _agentPendingCode = '';
          } else {
            _agentValidCode = '';
            // FIX 2026-11-21 (kami #12): lookup fail ho (internet
            // na ho) ya agent us waqt na mile — code khamoshi se
            // GHUM nahi hota. Pending mehfooz rehta hai; agli
            // sync par Backend.retryPendingAgentCode use dobara
            // jaanch kar ACTIVE agent milne par hi pakka lagata
            // hai (ghalat/band code kabhi profile par nahi lagta)।
            _agentPendingCode = agentCode;
            _snack(tr('reg_snack_agent_code'));
          }
        }
        return true;
      case 15:
        // Sharait (purane Jaiza qadam ki lazmi shartein)।
        // v1.4.4 LEGAL: Sharait ki qubooliyat lazmi hai — baghair
        // "Mein ne parh liya, qabool hai" ke register NAHI hota.
        if (!_termsChecked && store.profile.termsAcceptedAtMs == 0) {
          return _fail(tr('reg_err_terms'));
        }
        // AMANAT DEPOSIT (v1.4.21): is ki alag tasdeeq bhi
        // lazmi hai — driver saaf samjhe ke Rs 500 sirf us ki
        // amanat hai, us mein se sirf fees kategi aur baqi
        // us ki apni raqam hai jo chhorne par wapas milegi.
        if (!_amanatChecked) {
          return _fail(tr('reg_err_amanat'));
        }
        return true;
      default:
        return true;
    }
  }

  /// Password wala qadam — v1.2.5 ke AIN usool: min 6, match, aur
  /// backend uniqueness check (internet ke baghair aage nahi).
  Future<bool> _validatePasswordStep() async {
    if (p.pwdFp.isNotEmpty) return true; // pehle se set hai
    final pw = _pwdCtrl.text;
    if (pw.isNotEmpty && pw == _checkedPw && _stagedFp != null) {
      return true; // yehi password pehle check pass kar chuka hai
    }
    if (pw.length < 6) {
      return _fail(tr('reg_err_pw_min'));
    }
    if (pw != _pwd2Ctrl.text) {
      return _fail(tr('reg_err_pw_match'));
    }
    setState(() => _busy = true);
    final fp = passwordFingerprint(pw);
    final taken = await Backend.passwordFingerprintTaken(store, fp);
    if (!mounted) return false;
    setState(() => _busy = false);
    if (taken == null) {
      return _fail(tr('reg_err_pw_net'));
    }
    if (taken) {
      _pwdCtrl.clear();
      _pwd2Ctrl.clear();
      _stagedFp = null;
      _checkedPw = '';
      return _fail(tr('reg_err_pw_taken'));
    }
    _stagedFp = fp;
    _checkedPw = pw;
    return true;
  }

  /// Wizard ka seedha rasta (qadam indices ki tartib) —
  /// Aage/Peeche sirf isi fehrist par chalte hain।
  /// v1.4.75 YANGO-FORM TARTIB: 0 Ijazatein/Khush-Aamdeed,
  /// 1 Mobile, 2 Gmail+OTP, 3 Naam, 4 Sheher+Qisam, 9 Licence,
  /// 16 Gaari Tafseel, 13 Password, 14 Jaiza, 15 Sharait।
  /// Beech wale purane capture qadam (5-8, 10-12) is raste
  /// mein nahi hain: documents ID banne ke BAAD Home ki
  /// checklist se lagte hain (driver.dart ka
  /// _docsChecklistCard)।
  // v1.4.77 GUIDE TARTIB: 0 Khush-Aamdeed, 1 Mobile,
  // 2 Gmail+OTP, 3 Zaati Maloomat (S3), 4 Gaari ki Qisam,
  // 5 Kaghazat HUB (S4 — capture 6/7/9/12 hub se), 16 Gaari
  // ki Tafseel (S5), 8 Gaari ki Tasaveer/Kaghazat (S6),
  // 13 Password, 14 Jaiza/Status (S7), 15 Sharait।
  static const List<int> _flow = [0, 1, 2, 3, 4, 5, 16, 8, 13, 14, 15];

  Future<void> _next() async {
    if (_busy) return;
    if (!await _validateStep()) return;
    if (!mounted) return;
    // v1.4.77: har mukammal qadam par draft auto-save।
    await _saveDraft();
    if (!mounted) return;
    // Guide S4 ke capture qadam mukammal karke HUB par wapas।
    if (_isGuideCapture(_step)) {
      _goHub();
      return;
    }
    _advance();
  }

  /// Documents HUB par wapas jana — v1.4.68: hub wizard ke
  /// raste se nikal gaya hai; ye helper sirf purane (ab
  /// unrouted) hub/capture screens ki khaatir mehfooz hai।
  void _goHub() {
    setState(() {
      _error = null;
      _step = _hubStep;
    });
    _playStepGuide();
  }

  /// Hub ki list se kisi capture qadam ko kholna — v1.4.68:
  /// sirf purane unrouted hub screen ke liye mehfooz।
  void _openCapture(int s) {
    setState(() {
      _error = null;
      _step = s;
    });
    _playStepGuide();
  }

  /// Baghair jaanch ke ek qadam aage — sirf [_flow] ki tartib
  /// par (licence wale "skip" jaisi jaghon ke liye bhi yehi
  /// istemal hota hai; wahan jaanch skip par khud pass hoti
  /// hai)। Naya qadam khulte hi us ki awaaz wali hidayat khud
  /// bajti hai।
  void _advance() {
    setState(() {
      _error = null;
      final i = _flow.indexOf(_step);
      if (i >= 0 && i < _flow.length - 1) _step = _flow[i + 1];
    });
    _playStepGuide();
  }

  void _back() {
    unawaited(_saveDraft());
    // Capture qadam se peeche = Kaghazat HUB (guide S4)।
    if (_isGuideCapture(_step)) {
      _goHub();
      return;
    }
    setState(() {
      _error = null;
      final i = _flow.indexOf(_step);
      if (i > 0) _step = _flow[i - 1];
    });
    _playStepGuide();
  }

  // --- Register (submit) ------------------------------------------------------

  Future<void> _submit() async {
    final v = store.profile;
    // v1.4.17 FCM: ye submit PEHLI registration hai ya purani
    // ID ki edit — Master ko push sirf pehli dafa jati hai
    // (har edit par khabar shor hogi)।
    final firstRegistration = !v.registrationDone;
    // NUMBER TABDEELI = 12 GHANTE BLOCK (malik ka hukm
    // 2026-11-08): pehle se registered driver apna number badle
    // to ID khud-ba-khud 12 ghante block — na online, na ride.
    // Waqt poora hote hi block khud khatam ho jata hai. Pehli
    // registration (purana number khaali) par ye NAHI lagta.
    final oldPhone = v.phone;
    final oldImei = v.imei;
    final oldLicenceNumber = v.licenceNumber;
    // v1.4.77: saari maloomat/tasaveer ek hi jagah se profile
    // mein — wohi _collectDraft jo auto-save bhi chalaata hai
    // (taaki submit aur draft ki tafseel kabhi alag na ho)।
    _collectDraft();
    final newPhone = _digits(_mobileCtrl.text);
    if (v.registrationDone &&
        oldPhone.isNotEmpty &&
        newPhone.isNotEmpty &&
        newPhone != oldPhone) {
      v.numberBlockedUntilMs =
          DateTime.now().millisecondsSinceEpoch + 12 * 3600 * 1000;
    }
    // PTA Proof — IMEI badla ho to Master ka pta_status dobara
    // 'pending' (v131 trigger pta_resubmit_at se)।
    final newImei = _digits(_imeiCtrl.text);
    if (newImei.isNotEmpty && oldImei.isNotEmpty && newImei != oldImei) {
      v.docResubmitAt['pta'] = DateTime.now().toUtc().toIso8601String();
    }
    // Licence number badla ho to purani tasdeeq khatam।
    if (!_licenceSkip && oldLicenceNumber != v.licenceNumber) {
      v.licenceVerified = false;
    }
    // Route Permit / Fitness ki khud-zimmedari TASDEEQ ka waqt
    // (saboot ke liye; pehli qubooliyat par hi waqt lagta hai)।
    if (_permitDeclChecked && v.permitFitnessDeclAtMs == 0) {
      v.permitFitnessDeclAtMs =
          DateTime.now().millisecondsSinceEpoch;
    }
    // AGENT CODE (v1.4.6): sirf wohi code jo aakhri qadam ki
    // jaanch mein kisi ACTIVE agent ka nikla ho (ya profile ka
    // purana barkarar code)। Ghalat/na-mila code kabhi profile
    // mein nahi jata।
    v.agentCode = _agentValidCode;
    v.registrationDone = true;
    // Kagazat ki rukawatein registration ke waqt hi saaf (v1.2.9):
    // purane self-attestation wale local jhande nayi tasaveer par
    // dobara 'pending' ho jate hain — faisla ab sirf Master ka hai.
    v.cnicStatus = 'pending';
    v.vehiclePapers = 'pending';
    // store.save() → 'profile' hook → backend drivers row (numbers,
    // tafseel, fingerprint) Master tak mirror ho jata hai. Document
    // STATUS columns is mirror mein NAHI jate (Master-owned hain).
    await store.save();
    // v1.4.7: email ka backend record (v137 drivers.email) —
    // best-effort; column abhi na ho to local record asal hai।
    if (v.emailVerified) {
      unawaited(Backend.pushDriverEmail(
          store.driverId,
          v.email,
          DateTime.fromMillisecondsSinceEpoch(v.emailVerifiedAtMs)));
    }
    // v1.4.14: tasdeeq ke waqt ka backend record (guarded —
    // column abhi na ho to khamosh; local waqt asal saboot hai)
    // aur pehchan ka link (identity_links — OTP session se
    // driver ki pehchan bandhna; documents ki upload se pehle
    // hona chahiye taaki Phase 4 ki storage policies par link
    // pehle se maujood ho — syncDriverDocs is ke baad ke sync
    // par chalta hai)।
    if (v.permitFitnessDeclAtMs > 0) {
      // v1.4.25: Recorded wala roop — nakami par pending nishan
      // lagta hai aur startup dobara koshish karta hai (pehle
      // ye call khamoshi se fail hoti thi jab ke column abhi
      // schema mein hai hi nahi; draft sql-v148 mein hai)।
      unawaited(Backend.pushPermitFitnessDeclRecorded(
          store.driverId, v.permitFitnessDeclAtMs));
    }
    unawaited(Backend.linkIdentities(store));
    // v1.4.17 FCM: pehli registration mukammal — Master ko
    // foran khabar (Tasdeeq ki queue ke saath saath push bhi)।
    // Fire-and-forget; function deploy na ho to khamosh।
    if (firstRegistration) {
      unawaited(Backend.invokePush({
        'audience': 'masters',
        'title': 'Nayi Driver Registration',
        'body':
            '${v.name} · ${v.zone} · ${v.vehicle}${v.plate.isEmpty ? '' : ' · ${v.plate}'} — Tasdeeq ke liye tayyar hai',
        'data': {'driver_id': store.driverId},
      }));
    }
    // v1.4.7: agent link ka code istemal ho gaya — pending saaf
    // (refer ek-dafa lock: code ab profile mein mustaqil hai)।
    // FIX 2026-11-21 (kami #12): pending sirf tab saaf hota hai
    // jab code asal mein profile par LAG gaya ho. Jo code is
    // run mein tasdeeq ke baghair reh gaya (_agentPendingCode)
    // woh pending mein mehfooz ho jata hai — agli sync par
    // Backend.retryPendingAgentCode use pakka karne ki koshish
    // karega; code kabhi khamoshi se ghum nahi hoga।
    if (_agentPendingCode.isNotEmpty && v.agentCode.isEmpty) {
      await store.setPendingAgentCode(_agentPendingCode);
    }
    if (v.agentCode.isNotEmpty && store.pendingAgentCode.isNotEmpty) {
      await store.clearPendingAgentCode();
    }
    // v1.4.25 BACKEND TASDEEQ (postmortem #4): pehle "Darkhwast
    // Master ke paas chali gayi" ka dawa baghair kisi tasdeeq ke
    // ho jata tha — pushes saare unawaited thay aur fail bhi ho
    // jayein to screen kamyabi dikhati thi। Ab asal jawab ka
    // intezaar hota hai: drivers row Master ki queue mein asal
    // mein maujood hai ya nahi (ensureDriverRow ka bool jawab)।
    // Na pohanchay to done screen imaandar khabar + "Dobara
    // Bhejein" dikhayegi; registration is phone mein mukammal
    // mehfooz hai aur app dobara khulte hi startup sync
    // (ensureDriverRow + documents) khud dobara koshish karega।
    var sent = false;
    try {
      sent = await Backend.ensureDriverRow(store).timeout(
          const Duration(seconds: 15),
          onTimeout: () => false);
    } catch (_) {
      sent = false;
    }
    _backendSent = sent;
    if (mounted) setState(() => _done = true);
  }

  /// "Dobara Bhejein" — done screen se darkhwast ki dobara
  /// koshish (v1.4.25): drivers row + documents dono ka rasta
  /// dobara chalaya jata hai; kamyabi par screen asal kamyabi
  /// wali shakl mein badal jati hai।
  Future<void> _retrySendRegistration() async {
    if (_sendRetrying) return;
    setState(() => _sendRetrying = true);
    var sent = false;
    try {
      sent = await Backend.ensureDriverRow(store).timeout(
          const Duration(seconds: 15),
          onTimeout: () => false);
      if (sent) {
        await Backend.syncDriverDocs(store);
      }
    } catch (_) {
      sent = false;
    }
    if (!mounted) return;
    setState(() {
      _sendRetrying = false;
      _backendSent = sent;
    });
  }

  static String _formatCnic(String d) {
    if (d.length != 13) return d;
    return '${d.substring(0, 5)}-${d.substring(5, 12)}-${d.substring(12)}';
  }

  // --- Build ------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Driver Registration'),
        leading: IconButton(
          icon: const Icon(Icons.close),
          // v1.4.77: band karne se pehle draft auto-save —
          // adhoora form dobara wahi se continue hoga।
          onPressed: () async {
            await _saveDraft();
            if (mounted) Navigator.of(context).pop();
          },
        ),
        actions: [
          // Dobara sunein — is qadam ki awaaz wali hidayat phir se.
          IconButton(
            icon: const Icon(Icons.volume_up),
            tooltip: tr('reg_guide_tip'),
            onPressed: _playStepGuide,
          ),
        ],
      ),
      body: _done ? _doneView() : _formView(),
    );
  }

  /// v1.4.46: JAMA-SHUDA / HAALAT wali screen — Register ke baad
  /// yehi asal status screen hai (koi saada dialog nahi): jo
  /// kagaz asal mein jama hue un ki checklist, tasdeeq ke baad
  /// ID active hone ki khabar, aur Home/Login par wapas jane ka
  /// button। _submit() is screen se PEHLE mukammal hota hai —
  /// screen hamesha asal haalat dikhati hai।
  ///
  /// v1.4.25 wala usool barkarar: do shaklein — asal kamyabi
  /// (backend tasdeeq ke saath) ya imaandar "abhi nahi gayi"
  /// (retry ke saath)। Dawa hamesha asal haalat ke mutabiq hoga।
  Widget _doneView() {
    if (!_backendSent) {
      return ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 24),
          const Center(
            child:
                Icon(Icons.cloud_off, color: Brand.ajrakRed, size: 84),
          ),
          const SizedBox(height: 16),
          Text(tr('reg_done_local_title'),
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Text(
            tr('reg_done_local_body'),
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 15, height: 1.5),
          ),
          const SizedBox(height: 20),
          _submittedChecklist(),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _sendRetrying ? null : _retrySendRegistration,
              icon: _sendRetrying
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.refresh, size: 19),
              label: Text(_sendRetrying ? tr('reg_sending') : tr('reg_retry')),
            ),
          ),
          const SizedBox(height: 10),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(tr('reg_later')),
          ),
        ],
      );
    }
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        const SizedBox(height: 24),
        const Center(
          child: Icon(Icons.check_circle, color: Brand.green, size: 84),
        ),
        const SizedBox(height: 16),
        Text(tr('reg_done_title'),
            textAlign: TextAlign.center,
            style: const TextStyle(
                fontSize: 22, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        Text(
          tr('reg_done_body'),
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 15),
        ),
        const SizedBox(height: 20),
        _doneStatusList(),
        const SizedBox(height: 16),
        _submittedChecklist(),
        // v1.4.68: kagazat baqi hon to driver ko yahin saaf
        // bata diya jata hai ke baqi kaam kahan se hoga — Home
        // ki checklist; woh ghabra kar dobara registration ki
        // taraf NAHI jata।
        if (!(p.cnicFrontPath.isNotEmpty &&
            p.cnicBackPath.isNotEmpty &&
            p.vehiclePhotoPath.isNotEmpty &&
            p.vehicleBackPath.isNotEmpty &&
            p.vehicleLeftPath.isNotEmpty &&
            p.vehicleRightPath.isNotEmpty &&
            p.vehicleRegPath.isNotEmpty &&
            p.profilePhotoPath.isNotEmpty)) ...[
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF6E0),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Brand.gold),
            ),
            child: Text(tr('reg_done_docs_note'),
                style: const TextStyle(
                    fontSize: 13.5, height: 1.45, color: Brand.ink)),
          ),
        ],
        const SizedBox(height: 24),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Brand.greenDark,
              foregroundColor: Brand.goldLight,
              minimumSize: const Size.fromHeight(52),
            ),
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(tr('reg_ok')),
          ),
        ),
      ],
    );
  }

  /// v1.4.46 DESIGN (screen 8 + doosri design ka tracker):
  /// "Registration Mukammal!" ki haalat wali satrein — Maloomat
  /// ✓ Jama, Documents ✓ Jama ya ● Baqi hai (v1.4.68: asal
  /// haalat — tasaveer checklist se lagti hain), Tasdeeq ●
  /// Jaari hai — aur neeche
  /// "Tasdeeq jaari hai" tracker (mukammal qadam sabz, jaari
  /// qadam sunehre gole mein ghari)। Ye sirf ASAL haalat ki
  /// numaish hai: ye screen asal submit ke BAAD hi khulti hai
  /// (is liye "Jama" sach hai), aur Tasdeeq hamesha "Jaari hai"
  /// hi dikhti hai kyunke asal tasdeeq Master karta hai — ID
  /// active hona is screen ka dawa NAHI hai।
  Widget _doneStatusList() {
    // v1.4.68: Documents ki haalat ab ASAL hai — ID basic
    // maloomat par ban jati hai aur tasaveer Home ki checklist
    // se baad mein lagti hain, is liye "Documents Jama" sirf
    // tab jab asal mein saari lazmi tasaveer phone par maujood
    // hon; warna "Baqi hai" (jhooti kamyabi NAHI dikhti)।
    // v1.4.77: set ab Guide wala hai — CNIC dono + gaari ki
    // CHAAR tasaveer + kaghaz + selfie।
    final docsDone = p.cnicFrontPath.isNotEmpty &&
        p.cnicBackPath.isNotEmpty &&
        p.vehiclePhotoPath.isNotEmpty &&
        p.vehicleBackPath.isNotEmpty &&
        p.vehicleLeftPath.isNotEmpty &&
        p.vehicleRightPath.isNotEmpty &&
        p.vehicleRegPath.isNotEmpty &&
        p.profilePhotoPath.isNotEmpty;
    Widget statusRow(String label, String status, bool done) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          children: [
            Container(
              width: 26,
              height: 26,
              decoration: BoxDecoration(
                color: done ? Brand.green : Brand.gold,
                shape: BoxShape.circle,
              ),
              child: Icon(done ? Icons.check : Icons.hourglass_top,
                  size: 15,
                  color: done ? Colors.white : Brand.greenDark),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(label,
                  style: const TextStyle(
                      fontSize: 14.5, fontWeight: FontWeight.w700)),
            ),
            Text(status,
                style: TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                    color: done ? Brand.green : Brand.greenDark)),
          ],
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        // v1.4.60: card ke rang Din/Raat se (Pal)।
        color: Pal.panel(context),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Pal.divider(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          statusRow(tr('reg_done_st_info'), tr('reg_done_jama'), true),
          statusRow(tr('reg_done_st_docs'),
              docsDone ? tr('reg_done_jama') : tr('reg_rev_pending'),
              docsDone),
          statusRow(tr('reg_done_st_verify'), tr('reg_done_jaari'), false),
          const SizedBox(height: 10),
          const Divider(height: 1),
          const SizedBox(height: 12),
          // Tracker: Maloomat ✓ — Documents ✓ — Tasdeeq (ghari,
          // jaari hai)।
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _trackerDot(done: true),
              _trackerLine(),
              _trackerDot(done: docsDone),
              _trackerLine(),
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: Brand.gold,
                  shape: BoxShape.circle,
                  border:
                      Border.all(color: Brand.greenDark, width: 1.6),
                ),
                child: const Icon(Icons.schedule,
                    size: 19, color: Brand.greenDark),
              ),
            ],
          ),
          const SizedBox(height: 7),
          Center(
            child: Text(
              '${tr('reg_done_st_verify')} · ${tr('reg_done_jaari')}',
              style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ),
        ],
      ),
    );
  }

  Widget _trackerDot({required bool done}) {
    return Container(
      width: 26,
      height: 26,
      decoration: BoxDecoration(
        color: done ? Brand.green : Brand.fieldBorder,
        shape: BoxShape.circle,
      ),
      child: Icon(done ? Icons.check : Icons.circle,
          size: 14, color: Colors.white),
    );
  }

  Widget _trackerLine() {
    return Container(
      width: 34,
      height: 3,
      margin: const EdgeInsets.symmetric(horizontal: 4),
      color: Brand.green,
    );
  }

  /// Jama-shuda kagazon ki checklist (v1.4.46) — har kagaz ki
  /// ASAL haalat: photo lagi hai to sahi ka nishan, na lagi ho
  /// (ikhtiyari kagaz) to "Baqi hai"। Ye sirf numaish hai — koi
  /// data nahi badalta।
  Widget _submittedChecklist() {
    Widget row(String label, bool done, {String? pendingText}) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Icon(
              done
                  ? Icons.check_circle
                  : Icons.radio_button_unchecked,
              size: 20,
              color: done ? Brand.green : Brand.ajrakRed,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(label,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 13.5,
                      color: Brand.ink)),
            ),
            Text(
              done
                  ? tr('reg_rev_photo_done')
                  : (pendingText ?? tr('reg_rev_pending')),
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: done ? Brand.green : Brand.ajrakRed),
            ),
          ],
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Brand.lightBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Brand.fieldBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(tr('reg_done_checklist_title'),
              style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 14.5,
                  color: Brand.ink)),
          const SizedBox(height: 8),
          row(tr('reg_th_cnic_f'), _cnicFront.isNotEmpty),
          row(tr('reg_th_cnic_b'), _cnicBack.isNotEmpty),
          row(tr('reg_th_paper'), _vehicleReg.isNotEmpty),
          row(tr('chk_slot_reg_front'), _regFront.isNotEmpty),
          row(tr('chk_slot_reg_back'), _regBack.isNotEmpty),
          row(tr('reg_th_vehicle'), _vehiclePhoto.isNotEmpty),
          // v1.4.77 GUIDE S6: gaari ki baqi tasaveer bhi।
          row(tr('reg_slot_back'), _vehicleBack.isNotEmpty),
          row(tr('reg_slot_left'), _vehicleLeft.isNotEmpty),
          row(tr('reg_slot_right'), _vehicleRight.isNotEmpty),
          row(tr('chk_slot_lic_front'),
              _licenceFront.isNotEmpty || _licencePhoto.isNotEmpty,
              pendingText:
                  _licenceSkip ? tr('reg_rev_nolicence') : null),
          row(tr('chk_slot_lic_back'), _licenceBack.isNotEmpty,
              pendingText:
                  _licenceSkip ? tr('reg_rev_nolicence') : null),
          row(
            'Licence',
            !_licenceSkip && _licencePhoto.isNotEmpty,
            pendingText:
                _licenceSkip ? tr('reg_rev_nolicence') : null,
          ),
          row('Fitness', _fitnessPhoto.isNotEmpty),
          row('Insurance', _insurancePhoto.isNotEmpty),
          row('Character Certificate', _characterPhoto.isNotEmpty),
          row('Selfie', _selfie.isNotEmpty),
        ],
      ),
    );
  }

  Widget _formView() {
    // Khush-Aamdeed (qadam 0) ki apni poori screen hai — wahan
    // na progress hai, na neeche wale Aage/Peeche button (us ke
    // apne bare button hain)।
    if (_step == 0) return _stepWelcome();
    return Column(
      children: [
        // v1.4.46 DESIGN header (malik ki manzoor-shuda design
        // ki har screen wala andaaz): peeche ka teer, darmiyan
        // mein stylish LOGO (v1.4.50 NAAM LOCK — malik ka hukm:
        // naam har jagah logo ki shakal mein). Logo ke "Safar"
        // akshar safed hain, is liye halki bg par logo gehri
        // sabz badge ke andar rakha hai taake har lafz saaf
        // parha jaye; neeche qadam ka bara pictorial icon +
        // title aur sabz progress bar।
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
          child: Row(
            children: [
              IconButton(
                icon:
                    const Icon(Icons.arrow_back, color: Brand.greenDark),
                tooltip: tr('reg_back'),
                onPressed: _busy ? null : _back,
              ),
              Expanded(
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: Brand.greenDark,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Image.asset(
                      'assets/branding/mr-safar-logo.png',
                      height: 40,
                      fit: BoxFit.contain,
                      semanticLabel: 'Boz Safar',
                    ),
                  ),
                ),
              ),
              // Dayein taraf utni hi khaali jagah — wordmark
              // bilkul darmiyan rahe।
              const SizedBox(width: 48),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
          child: Row(
            children: [
              // Qadam ka bara icon — anparh driver bhi sirf is
              // nishan se samajh jaye ke ye screen kis cheez ki
              // hai (malik ka hukm: har qadam par saaf icon)।
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: Brand.green.withOpacity(0.12),
                  shape: BoxShape.circle,
                ),
                child: Icon(_stepIcon, size: 25, color: Brand.green),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                        trf('reg_step',
                            {'n': '$_phase', 'total': '$_totalPhases'}),
                        style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: Theme.of(context).colorScheme.primary)),
                    Text(_stepTitles[_step],
                        style: const TextStyle(
                            fontSize: 16.5, fontWeight: FontWeight.w900)),
                  ],
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
          child: LinearProgressIndicator(
            value: _phase / _totalPhases,
            color: Brand.green,
            backgroundColor: Brand.fieldBorder,
            minHeight: 6,
            borderRadius: BorderRadius.circular(3),
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _stepBody(),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!,
                    style: const TextStyle(
                        color: Brand.ajrakRed,
                        fontWeight: FontWeight.w700,
                        fontSize: 14)),
              ],
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _busy ? null : _back,
                    child: Text(tr('reg_back')),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: _step == _lastStep
                      ? ElevatedButton(
                          // Design ke rang: gehra sabz button,
                          // sunehra matan (ooncha contrast)।
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Brand.greenDark,
                            foregroundColor: Brand.goldLight,
                            minimumSize: const Size.fromHeight(52),
                          ),
                          onPressed: () async {
                            // Register se pehle aakhri qadam ki
                            // jaanch (Sharait ki qubooliyat lazmi
                            // hai — FORM USOOL)।
                            if (await _validateStep()) _submit();
                          },
                          child: Text(tr('reg_register')),
                        )
                      : ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Brand.greenDark,
                            foregroundColor: Brand.goldLight,
                            minimumSize: const Size.fromHeight(52),
                          ),
                          onPressed: _busy ? null : _next,
                          icon: const Icon(Icons.arrow_forward, size: 19),
                          label: Text(
                              _busy ? tr('reg_checking') : tr('reg_next')),
                        ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _stepBody() {
    switch (_step) {
      case 1:
        return _stepMobile();
      case 2:
        return _stepEmail();
      case 3:
        return _stepName();
      case 4:
        return _stepCityType();
      // v1.4.77 GUIDE: Kaghazat HUB (5) + us ke capture qadam
      // (6 CNIC samne, 7 CNIC peeche, 9 Licence, 12 Selfie)
      // wizard ke raste mein WAPAS hain — Guide S4 ki tartib।
      case 5:
        return _stepDocsHub();
      case 6:
        return _stepCnicFront();
      case 7:
        return _stepCnicBack();
      case 9:
        return _stepLicence();
      case 12:
        return _stepSelfie();
      case 16:
        return _stepVehicleDetails();
      case 8:
        return _stepVehicleDocs();
      case 13:
        return _stepPassword();
      case 14:
        return _stepReview();
      case 15:
        return _stepTerms();
      default:
        return _stepMobile();
    }
  }

  // --- Qadam 0: Khush-Aamdeed (v1.4.46 — Yango Pro / Bykea Partner tarz) ---

  /// Pehli screen: headline, faide, aur bara "Registration Shuru
  /// Karein" button। Pehle se account walon ke liye numaya
  /// Login button bhi yahin hai — woh asal LoginPage kholta
  /// hai (v1.4.47: mobile number ya Gmail + OTP se maujooda
  /// account is phone par ajata hai; pehle wala chhota
  /// TextButton sirf wizard band kar deta tha)।
  Widget _stepWelcome() {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          // Logo — v1.4.50 NAAM LOCK: naam text ki bajaye
          // stylish logo ki shakal mein; "Safar" ke safed
          // aksharon ki wajah se gehri sabz badge ke andar,
          // taake halki bg par bhi har lafz saaf parha jaye।
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 18, vertical: 8),
              decoration: BoxDecoration(
                color: Brand.greenDark,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Image.asset(
                'assets/branding/mr-safar-logo.png',
                height: 46,
                fit: BoxFit.contain,
                semanticLabel: 'Boz Safar',
              ),
            ),
          ),
          const SizedBox(height: 18),
          // Rickshaw ki ASAL photo — design ka visual (wohi
          // photo jo Gaari wale qadam par card mein bhi hai);
          // file na mile to rickshaw ka icon (kabhi khaali
          // screen nahi)।
          ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Image.asset(
              'assets/vehicles/rickshaw.jpg',
              height: 190,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (ctx, err, stack) => Container(
                height: 190,
                color: Brand.lightBg,
                child: const Icon(Icons.electric_rickshaw,
                    size: 72, color: Brand.green),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            tr('reg_welcome_heading'),
            textAlign: TextAlign.center,
            style: const TextStyle(
                fontSize: 26, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 4),
          Text(
            tr('reg_welcome_title'),
            textAlign: TextAlign.center,
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: Brand.green),
          ),
          const SizedBox(height: 4),
          Text(
            tr('reg_welcome_sub'),
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 15.5,
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: 24),
          _benefitRow(Icons.percent, tr('reg_welcome_b1')),
          _benefitRow(Icons.badge, tr('reg_welcome_b2')),
          _benefitRow(Icons.schedule, tr('reg_welcome_b3')),
          const SizedBox(height: 22),
          // IJAZATEIN (v1.4.68 — malik ka hukm 2026-11-22):
          // registration shuru karne se pehle driver ko saaf
          // bata diya jata hai ke app ko kaun si ijazatein
          // chahiye hongi aur kyun — taake aage chal kar phone
          // pooche to driver ghabraye nahi aur "Allow" kar de।
          // Ye sirf maloomat hai; asal ijazat phone apne waqt
          // par khud mangta hai (yahan koi ijazat nahi mangi
          // jati)।
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Brand.lightBg,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Brand.fieldBorder),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.verified_user,
                        size: 20, color: Brand.green),
                    const SizedBox(width: 8),
                    Text(tr('reg_perm_title'),
                        style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                            color: Brand.ink)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(tr('reg_perm_intro'),
                    style: const TextStyle(
                        fontSize: 13, height: 1.45, color: Brand.ink)),
                const SizedBox(height: 8),
                _benefitRow(Icons.location_on, tr('reg_perm_loc')),
                _benefitRow(Icons.phone, tr('reg_perm_phone')),
                _benefitRow(
                    Icons.notifications, tr('reg_perm_notif')),
              ],
            ),
          ),
          const SizedBox(height: 28),
          SizedBox(
            height: 54,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Brand.greenDark,
                foregroundColor: Brand.goldLight,
              ),
              onPressed: _next,
              icon: const Icon(Icons.arrow_forward, size: 20),
              label: Text(tr('reg_welcome_start'),
                  style: const TextStyle(
                      fontSize: 16.5, fontWeight: FontWeight.w800)),
            ),
          ),
          const SizedBox(height: 12),
          // LOGIN ka numaya darwaza (v1.4.47 — malik ka hukm
          // 2026-11-22): pehle ye sirf ek chhota TextButton tha
          // jo wizard band karke banda ko wapas phenk deta tha
          // (malik khud is mein phansa) — ab ye asal LoginPage
          // kholta hai (mobile number ya Gmail + OTP se
          // maujooda account is phone par ajata hai)। Login
          // kamyab ho to wizard bhi band ho jata hai।
          // v1.4.74 (malik ka hukm 2026-11-22 — fix-pack):
          // Login button ab "Shuru Karein" ke BARABAR bara hai
          // (wahi 54 height, wahi harf) aur bhara hua (filled)
          // hai — pehli nazar mein saaf dikhe, driver ko
          // dhoondna na pare।
          SizedBox(
            height: 54,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Brand.green,
                foregroundColor: Colors.white,
              ),
              onPressed: () async {
                final ok = await Navigator.of(context).push<bool>(
                  MaterialPageRoute(
                    builder: (_) => DriverLoginPage(store: widget.store),
                  ),
                );
                if (ok == true && mounted) {
                  Navigator.of(context).pop(true);
                }
              },
              icon: const Icon(Icons.login, size: 20),
              label: Text(tr('reg_welcome_login'),
                  style: const TextStyle(
                      fontSize: 16.5, fontWeight: FontWeight.w800)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _benefitRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 23, color: Brand.green),
          const SizedBox(width: 11),
          Expanded(
            child: Text(text,
                style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w600,
                    height: 1.35)),
          ),
        ],
      ),
    );
  }

  // --- Step 1: Mobile ---------------------------------------------------------

  Widget _stepMobile() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _infoText(tr('reg_mobile_intro')),
        const SizedBox(height: 14),
        TextField(
          controller: _mobileCtrl,
          keyboardType: TextInputType.phone,
          maxLength: 11,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: InputDecoration(
            labelText: tr('reg_mobile_label'),
            helperText: tr('help_mobile'),
            prefixIcon: const Icon(Icons.phone),
          ),
        ),
      ],
    );
  }

  // --- Qadam 2: Gmail + Code --------------------------------------------------

  /// v1.4.46: EmailOtpSection bilkul waisa hi hai jaisa pehle
  /// Zaati Maloomat wale qadam par tha — wohi widget, wohi
  /// controller, wohi tasdeeq ki haalat (_emailVerifiedFor)।
  /// Sirf screen alag hai taaki ek screen par ek hi kaam ho।
  Widget _stepEmail() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // v1.4.7 EMAIL + OTP (spec §1): Gmail lazmi — code usi
        // par jata hai, tasdeeq ke baghair ye qadam aage NAHI
        // badhta (validation case 2 dekhein)।
        Text(tr('reg_email_title'),
            style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        _infoText(tr('reg_email_intro'), size: 12.5),
        const SizedBox(height: 8),
        EmailOtpSection(
          emailCtrl: _emailCtrl,
          alreadyVerifiedEmail: p.emailVerified ? p.email : '',
          playGuideOnInit: true,
          onVerified: (email) => _emailVerifiedFor = email,
        ),
      ],
    );
  }

  // --- Qadam 3: Naam + Sheher ---------------------------------------------------

  /// Naam (purane Zaati Maloomat qadam se) aur sheher (purane
  /// Jaiza qadam se) — sheher pehle se set NAHI hota (FORM
  /// USOOL 2026-11-08): _zone khaali ho to dropdown khaali
  /// (hint) dikhta hai aur driver apna sheher khud chunta hai।
  // --- Qadam 3: Naam (v1.4.75 — Yango-form tartib) -----------------------------

  /// Sirf naam + CNIC number — "Bilkul waisi jaisi CNIC par
  /// hai"। Sheher is qadam se nikal kar apne alag qadam
  /// (4 — Sheher + Qisam) par chala gaya hai। CNIC number
  /// ka khana hamari pehchan ke nizam ki wajah se yahin
  /// hai; us ki jaanch bhi isi qadam par hoti hai
  /// (validation case 3) — CNIC ki TASAVEER ID banne ke
  /// baad Home ki checklist se lagti hain।
  Widget _stepName() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _infoText(tr('reg_name_city_intro')),
        const SizedBox(height: 14),
        TextField(
          controller: _nameCtrl,
          decoration: InputDecoration(
            labelText: tr('reg_name_label'),
            helperText: tr('help_name'),
            prefixIcon: const Icon(Icons.person),
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _cnicCtrl,
          keyboardType: TextInputType.number,
          inputFormatters: [_CnicInputFormatter()],
          decoration: InputDecoration(
            labelText: tr('reg_cnic_label'),
            helperText: tr('help_cnic'),
            prefixIcon: const Icon(Icons.badge),
          ),
        ),
        const SizedBox(height: 14),
        // v1.4.77 GUIDE S3: DATE OF BIRTH — date picker se
        // (CNIC par likhi tareekh)।
        TextField(
          controller: _dobCtrl,
          readOnly: true,
          onTap: _pickDob,
          decoration: InputDecoration(
            labelText: tr('guide_dob_label'),
            hintText: tr('guide_dob_hint'),
            prefixIcon: const Icon(Icons.cake),
          ),
        ),
        const SizedBox(height: 14),
        // Sheher (Guide S3 ka address hissa) — FORM USOOL:
        // pehle se set NAHI hota, driver khud chunta hai।
        DropdownButtonFormField<String>(
          value: _zone.isEmpty ? null : _zone,
          isExpanded: true,
          hint: Text(tr('reg_city_hint'),
              style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant, fontWeight: FontWeight.w500)),
          items: kZones
              .map((z) => DropdownMenuItem(value: z, child: Text(z)))
              .toList(),
          onChanged: (v) => setState(() => _zone = v ?? _zone),
          decoration: InputDecoration(
            labelText: tr('reg_city_label'),
            helperText: tr('help_city'),
            prefixIcon: const Icon(Icons.location_on),
          ),
        ),
        const SizedBox(height: 14),
        // v1.4.77 GUIDE S3: MUKAMMAL PATA।
        TextField(
          controller: _addressCtrl,
          maxLines: 2,
          decoration: InputDecoration(
            labelText: tr('guide_address_label'),
            helperText: tr('guide_address_helper'),
            prefixIcon: const Icon(Icons.home),
          ),
        ),
        const SizedBox(height: 14),
        // v1.4.77 GUIDE S3: EMERGENCY CONTACT (recommended)।
        TextField(
          controller: _emergencyNameCtrl,
          decoration: InputDecoration(
            labelText: tr('guide_emergency_name'),
            prefixIcon: const Icon(Icons.emergency),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _emergencyMobileCtrl,
          keyboardType: TextInputType.phone,
          maxLength: 11,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: InputDecoration(
            labelText: tr('guide_emergency_mobile'),
            helperText: tr('guide_emergency_helper'),
            prefixIcon: const Icon(Icons.phone_in_talk),
            counterText: '',
          ),
        ),
        const SizedBox(height: 16),
        // v1.4.77 GUIDE S3: PROFILE PHOTO — wohi live selfie
        // jo Kaghazat (S4) mein bhi gini jati hai (ek hi
        // photo, do jagah nahi mangi jati)।
        _photoSlot(
          label: tr('guide_profile_photo'),
          path: _selfie,
          icon: Icons.face,
          onPick: () => _pickPhoto((v) => _selfie = v,
              cameraOnly: true, faceCheck: true),
        ),
      ],
    );
  }


  // --- Qadam 4: Sheher + Gaari ki Qisam (v1.4.75) ------------------------------

  /// Video wali tartib ka qadam: pehle sheher, phir gaari/
  /// bike ki qisam। Qisam ki ASAL tasaveerein dekh kar
  /// driver apni sawari chunta hai (parhna zaroori nahi) —
  /// ye cards pehle Gaari wale qadam par thay; gaari ki
  /// TAFSEEL (brand/model/rang/saal/plate) ab licence ke
  /// baad qadam 16 par hai।
  Widget _stepCityType() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(tr('reg_type_title'),
            style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        _infoText(tr('reg_veh_intro')),
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.15,
          children: [
            for (final v in kVehicles) _vehicleCard(v),
          ],
        ),
      ],
    );
  }


  /// Maloomati matan ka DARK andaaz (malik ka hukm 2026-11-13:
  /// halki / feeki / dhundhli likhai kahin NAHI — har lafz gehra
  /// aur saaf parhne wala)। Saare subtitles, hints aur helper
  /// note isi se likhe jate hain: qareeb-kaala rang (Brand.ink)
  /// + kam az kam w500 wazan।
  Text _infoText(String text, {double size = 13.5}) {
    return Text(
      text,
      style: TextStyle(
        fontSize: size,
        height: 1.45,
        color: Theme.of(context).colorScheme.onSurfaceVariant,
        fontWeight: FontWeight.w500,
      ),
    );
  }

  // --- Qadam 5: Documents HUB (v1.4.46 DESIGN — screen 5) -------------

  /// Documents ki LIST screen — malik ki manzoor-shuda design
  /// ki screen 5 bilkul waisi: har kagaz ki aik satr (bara
  /// icon, naam, chhoti hidayat, haalat)। Jo cheez lag gayi us
  /// par sabz gole mein sahi ka nishan + "Ho Gaya"; jo baqi hai
  /// us par aage ka teer। Satr par tap = wohi purana capture
  /// qadam khulta hai; capture mukammal karke driver wapas
  /// yahin ata hai aur satr "Ho Gaya" ho jati hai। Is screen ka
  /// "Aage Barhein" documents marhalay ki saari lazmi jaanchein
  /// dobara chalata hai (validation dekhein) — koi jaanch skip
  /// NAHI hoti।
  Widget _stepDocsHub() {
    // v1.4.77 GUIDE S4: hub par sirf zaati kaghazat hain —
    // CNIC samne/peeche, Licence (number + issue/expiry +
    // front/back/selfie), aur saaf profile selfie। Har satr
    // ki haalat saaf hai (lag gaya / baqi); reject ki wajah
    // aur dobara upload ka rasta Home ki checklist par bhi
    // waisa hi rehta hai। Gaari ki tasaveer/kaghazat Guide
    // S6 ke apne qadam (8) par hain।
    final licenceDone = !_licenceSkip &&
        (_licenceFront.isNotEmpty || _licencePhoto.isNotEmpty) &&
        _licenceBack.isNotEmpty &&
        _licenceSelfie.isNotEmpty &&
        _licenceExpiryDate != null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _infoText(tr('reg_docs_sub')),
        const SizedBox(height: 14),
        _hubRow(
          icon: Icons.credit_card,
          title: tr('reg_cnic_front'),
          hint: tr('reg_hub_cnic_f_hint'),
          done: _cnicFront.isNotEmpty,
          onTap: () => _openCapture(6),
        ),
        _hubRow(
          icon: Icons.credit_card,
          title: tr('reg_cnic_back'),
          hint: tr('reg_hub_cnic_b_hint'),
          done: _cnicBack.isNotEmpty,
          onTap: () => _openCapture(7),
        ),
        _hubRow(
          icon: Icons.badge,
          title: tr('reg_t_licence'),
          hint: tr('reg_hub_lic_hint'),
          done: licenceDone,
          optionalDone: _licenceSkip,
          onTap: () => _openCapture(9),
        ),
        _hubRow(
          icon: Icons.face,
          title: tr('reg_t_selfie'),
          hint: tr('reg_hub_selfie_hint'),
          done: _selfie.isNotEmpty,
          onTap: () => _openCapture(12),
        ),
      ],
    );
  }


  /// Hub ki aik satr: gol halqe mein bara icon (tasveeri
  /// ishaara — parhne ke baghair bhi samajh aye ke ye kis
  /// kagaz ki satr hai), naam, DARK hidayat, aur haalat —
  /// mukammal ho to "Ho Gaya" + sabz gole mein sahi ka nishan,
  /// warna aage ka teer।
  /// [optionalDone] = ikhtiyari cheez driver ne jaan kar chhor
  /// di (licence skip) — woh bhi mukammal mani jati hai (sabz
  /// nishan), kyunke aage barhna us par nahi rukta।
  Widget _hubRow({
    required IconData icon,
    required String title,
    required String hint,
    required bool done,
    bool optionalDone = false,
    required VoidCallback onTap,
  }) {
    final complete = done || optionalDone;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          decoration: BoxDecoration(
            // v1.4.60: card ke rang Din/Raat se (Pal)।
            color: Pal.panel(context),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: complete ? Brand.green : Pal.divider(context),
              width: complete ? 1.8 : 1.2,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: Brand.green.withOpacity(0.12),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, size: 24, color: Brand.green),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 14.5, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(hint,
                        style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w500,
                            color: Theme.of(context).colorScheme.onSurfaceVariant)),
                  ],
                ),
              ),
              if (complete) ...[
                Text(tr('reg_docs_done'),
                    style: const TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: Brand.green)),
                const SizedBox(width: 6),
                Container(
                  width: 26,
                  height: 26,
                  decoration: const BoxDecoration(
                    color: Brand.green,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.check,
                      size: 17, color: Colors.white),
                ),
              ] else
                const Icon(Icons.chevron_right,
                    size: 26, color: Brand.greenDark),
            ],
          ),
        ),
      ),
    );
  }

  // --- Qadam 6: CNIC — Samne -----------------------------------------------------

  /// SAMNE wali tasveer apni screen par, guide frame ke saath
  /// (v1.4.46)। CNIC NUMBER ka khana design ki tartib ke mutabiq
  /// ab "Apni Maloomat Dein" (qadam 3) par hai — lekin number ki
  /// jaanch (shakal + backend par EK CNIC = EK ACCOUNT) ab bhi
  /// ISI qadam ki validation mein hoti hai; koi jaanch nahi
  /// hati, sirf khane ki jagah badli hai। Photo slot wohi purana
  /// _photoSlot hai (guideAsset wali awaaz + quality jaanch
  /// samait); upload/submit par key 'cnicFront' wali hi purani
  /// mapping chalti hai (profile.cnicFrontPath)।
  Widget _stepCnicFront() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(tr('reg_cnic_front'),
            style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        _framedPhotoSlot(
          hint: tr('reg_frame_cnic_front'),
          onPick: () => _pickPhoto((v) => _cnicFront = v),
          guideAsset: 'guidance/guidance_cnic_front.mp3',
          slot: _photoSlot(
            label: tr('reg_cnic_front'),
            path: _cnicFront,
            icon: Icons.credit_card,
            onPick: () => _pickPhoto((v) => _cnicFront = v),
            guideAsset: 'guidance/guidance_cnic_front.mp3',
            large: true,
          ),
        ),
      ],
    );
  }

  // --- Qadam 7: CNIC — Peeche ----------------------------------------------------

  Widget _stepCnicBack() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(tr('reg_cnic_back'),
            style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        _framedPhotoSlot(
          hint: tr('reg_frame_cnic_back'),
          onPick: () => _pickPhoto((v) => _cnicBack = v),
          guideAsset: 'guidance/guidance_cnic_back.mp3',
          slot: _photoSlot(
            label: tr('reg_cnic_back'),
            path: _cnicBack,
            icon: Icons.credit_card,
            onPick: () => _pickPhoto((v) => _cnicBack = v),
            guideAsset: 'guidance/guidance_cnic_back.mp3',
            large: true,
          ),
        ),
      ],
    );
  }

  /// Guide frame (v1.4.46): sunehre kinare wala khana — driver
  /// ko pehle se pata chalta hai ke kagaz ko frame ke andar
  /// rakh kar tasveer leni hai। Andar asal photo slot wohi
  /// purana hai; ye sirf us ke gird frame + hidayat hai।
  /// Neeche design (screen 6) wala bara GOAL camera button bhi
  /// hai — us par tap se wohi amal hota hai jo slot par tap se
  /// (pehle awaaz wali hidayat, phir camera/gallery)।
  Widget _framedPhotoSlot({
    required String hint,
    required Widget slot,
    required VoidCallback onPick,
    String? guideAsset,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Brand.cream,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Brand.gold, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.center_focus_strong,
                  size: 19, color: Brand.green),
              const SizedBox(width: 7),
              Expanded(
                child: Text(hint,
                    style: const TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                        height: 1.35,
                        color: Brand.ink)),
              ),
            ],
          ),
          const SizedBox(height: 10),
          slot,
          const SizedBox(height: 12),
          Center(
            child: Column(
              children: [
                InkWell(
                  onTap: () {
                    if (guideAsset != null) {
                      unawaited(GuideAudio.play(guideAsset));
                    }
                    onPick();
                  },
                  customBorder: const CircleBorder(),
                  child: Container(
                    width: 62,
                    height: 62,
                    decoration: const BoxDecoration(
                      color: Brand.green,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.photo_camera,
                        color: Colors.white, size: 30),
                  ),
                ),
                const SizedBox(height: 5),
                Text(tr('reg_take_photo'),
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, color: Brand.green)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- Step 3: Password ---------------------------------------------------------

  Widget _stepPassword() {
    if (p.pwdFp.isNotEmpty) {
      return Card(
        child: ListTile(
          leading: const Icon(Icons.lock, color: Brand.green),
          title: Text(tr('reg_pw_set_title'),
              style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(tr('reg_pw_set_sub'),
              style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant, fontWeight: FontWeight.w500)),
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Tasveeri ishaara: password = hifazat (dhaal ka nishan)।
        Center(
          child: Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: Brand.green.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.shield, size: 34, color: Brand.green),
          ),
        ),
        const SizedBox(height: 12),
        _infoText(tr('reg_pw_intro')),
        const SizedBox(height: 14),
        TextField(
          controller: _pwdCtrl,
          obscureText: true,
          decoration: InputDecoration(
            labelText: tr('reg_pw_label'),
            helperText: tr('help_password'),
            prefixIcon: const Icon(Icons.lock),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _pwd2Ctrl,
          obscureText: true,
          decoration: InputDecoration(
            labelText: tr('reg_pw2_label'),
            helperText: tr('help_password2'),
            prefixIcon: const Icon(Icons.lock_outline),
          ),
        ),
      ],
    );
  }

  // --- Qadam 4: Gaari ki maloomat ----------------------------------------------

  /// v1.4.46: gaari ki QISAM ab bare selectable cards (grid) mein
  /// hai — baqi tafseel (brand/model/saal/rang/plate/IMEI) wohi
  /// purani hai। Tasaveer is qadam se nikal kar apne alag
  /// "Gaari ke Kagaz" qadam (7) par chali gayi hain — slots aur
  /// un ki keys bilkul wohi purani hain।
  /// v1.4.48: rang wala ek chip — asal rang ka gola + naam;
  /// chuna hua chip sabz kinara + halki sabz tint + sahi ke
  /// nishan ke saath। Tap par naam _colorCtrl mein chala jata
  /// hai (validation/save wohi purana rasta)।
  Widget _colorChip(MapEntry<String, Color> c) {
    final selected = _colorCtrl.text.trim() == c.key;
    return InkWell(
      onTap: () => setState(() => _colorCtrl.text = c.key),
      borderRadius: BorderRadius.circular(24),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFE7F2EC) : Colors.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: selected ? Brand.green : Colors.black26,
            width: selected ? 2 : 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                color: c.value,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.black38, width: 1),
              ),
            ),
            const SizedBox(width: 7),
            Text(c.key,
                style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13.5,
                    color: Brand.green)),
            if (selected) ...[
              const SizedBox(width: 5),
              const Icon(Icons.check_circle, size: 17, color: Brand.green),
            ],
          ],
        ),
      ),
    );
  }

  // --- Qadam 16: Gaari ki Tafseel (v1.4.75) ------------------------------------

  /// Licence ke baad ka qadam — video wali tartib ke fields:
  /// make (brand) → model → rang → saal → number plate।
  /// Gaari ki QISAM is qadam par NAHI hai — woh Sheher wale
  /// qadam (4) par tasaveer wale cards se chuni jati hai।
  /// PTA/IMEI wala hissa (hamari apni shart — Master ke
  /// switch par) aakhir mein barkarar hai।
  Widget _stepVehicleDetails() {
    final years = <int>[
      for (var y = DateTime.now().year + 1; y >= 1990; y--) y
    ];
    final suggestions = _brandSuggestions[_vehicle] ?? const <String>[];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _infoText(tr('reg_veh_details_intro')),
        const SizedBox(height: 6),
        _infoText(tr('guide_category_note'), size: 12.5),
        const SizedBox(height: 14),
        TextField(
          controller: _brandCtrl,
          decoration: InputDecoration(
            labelText: tr('reg_brand_label'),
            helperText: tr('help_brand'),
            prefixIcon: const Icon(Icons.factory),
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: suggestions
              .map((s) => ChoiceChip(
                    label: Text(s),
                    selected: _brandCtrl.text.trim() == s,
                    onSelected: (_) =>
                        setState(() => _brandCtrl.text = s),
                  ))
              .toList(),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _modelCtrl,
          decoration: InputDecoration(
            labelText: tr('reg_model_label'),
            helperText: tr('help_model'),
            prefixIcon: const Icon(Icons.directions_car),
          ),
        ),
        const SizedBox(height: 16),
        // v1.4.48 GAARI KA RANG: khaali text field ki jagah ab
        // rangon ke CHIPS hain — har chip par asal rang ka gola
        // + Roman-Urdu naam। Driver apni gaari ke rang wale gole
        // par tap karta hai (parhne ki zaroorat nahi); chuna hua
        // naam wohi _colorCtrl mein jata hai jis se validation
        // (qadam 4 — rang LAZMI hai), save (profile.vehicleColor)
        // aur Jaiza ki satr pehle se chalti hain।
        Row(
          children: [
            const Icon(Icons.palette, color: Brand.green, size: 20),
            const SizedBox(width: 8),
            Text(tr('reg_color_heading'),
                style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                    color: Theme.of(context).colorScheme.primary)),
          ],
        ),
        const SizedBox(height: 4),
        _infoText(tr('reg_color_hint'), size: 12.5),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final c in kVehicleColors) _colorChip(c),
          ],
        ),
        const SizedBox(height: 16),
        // v1.4.75 tartib: rang ke baad SAAL, phir number plate
        // (video wali tartib: make/model/rang/saal/plate)।
        DropdownButtonFormField<int>(
          value: _year,
          isExpanded: true,
          decoration: InputDecoration(
            labelText: tr('reg_year_label'),
            helperText: tr('help_year'),
            prefixIcon: const Icon(Icons.calendar_month),
          ),
          items: years
              .map((y) => DropdownMenuItem(value: y, child: Text('$y')))
              .toList(),
          onChanged: (v) => setState(() => _year = v),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _plateCtrl,
          decoration: InputDecoration(
            labelText: tr('reg_plate_field'),
            helperText: tr('help_plate'),
            prefixIcon: const Icon(Icons.pin),
          ),
        ),
        const SizedBox(height: 16),
        // v1.4.77 GUIDE S5: SEATING CAPACITY (lazmi)।
        DropdownButtonFormField<int>(
          value: _seating > 0 ? _seating : null,
          isExpanded: true,
          decoration: InputDecoration(
            labelText: tr('guide_seating_label'),
            prefixIcon: const Icon(Icons.event_seat),
          ),
          items: [
            for (var n = 1; n <= 20; n++)
              DropdownMenuItem(value: n, child: Text('$n')),
          ],
          onChanged: (v) => setState(() => _seating = v ?? 0),
        ),
        const SizedBox(height: 16),
        // v1.4.77 GUIDE S5: OWNERSHIP (lazmi) — apni / ghar
        // ki / kiraye ki / company ki।
        Text(tr('guide_ownership_label'),
            style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final o in const [
              ('Self', 'guide_own_self'),
              ('Family', 'guide_own_family'),
              ('Rented', 'guide_own_rented'),
              ('Company', 'guide_own_company'),
            ])
              ChoiceChip(
                label: Text(tr(o.$2)),
                selected: _ownership == o.$1,
                onSelected: (_) => setState(() => _ownership = o.$1),
              ),
          ],
        ),
        const SizedBox(height: 16),
        // v1.4.77 GUIDE S5: FEATURES (ikhtiyari)।
        Text(tr('guide_features_label'),
            style: const TextStyle(fontWeight: FontWeight.w800)),
        CheckboxListTile(
          value: _featAc,
          onChanged: (v) => setState(() => _featAc = v ?? false),
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          dense: true,
          title: Text(tr('guide_feat_ac')),
        ),
        CheckboxListTile(
          value: _featLuggage,
          onChanged: (v) => setState(() => _featLuggage = v ?? false),
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          dense: true,
          title: Text(tr('guide_feat_luggage')),
        ),
        const SizedBox(height: 8),
        const Text('PTA Proof',
            style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        _infoText(
          Fares.ptaRequired ? tr('reg_pta_req') : tr('reg_pta_opt'),
          size: 12.5,
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _imeiCtrl,
          keyboardType: TextInputType.number,
          maxLength: 15,
          decoration: InputDecoration(
            labelText: tr('reg_imei_label'),
            helperText: tr('help_imei'),
            prefixIcon: const Icon(Icons.verified),
            counterText: '',
          ),
        ),
      ],
    );
  }

  // --- Qadam 7: Gaari ke kagaz + tasaveer ---------------------------------------

  /// v1.4.46: registration book (kaghaz) ki tasveer PEHLE, phir
  /// gaari ki tasaveer।
  /// AASAN MODEL (malik ka hukm 2026-11-22): gaari ki SIRF 2
  /// tasaveer — side wali aur peeche wali। Purana 6-khano wala
  /// set (samne/bayein/dayein/andar) khatam kar diya gaya hai
  /// taake banda pehli koshish mein ID bana le। Side wali
  /// tasveer wohi purani jagah par jati hai (vehiclePhotoPath →
  /// vehicle_photo_path / object 'vehicle'), peeche wali bhi
  /// wohi purani jagah par (vehicleBackPath → object
  /// 'vehicle_back') — backend mein koi tabdeeli nahi।
  Widget _stepVehicleDocs() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(tr('reg_veh_photos'),
            style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        _infoText(tr('guide_veh_docs_intro'), size: 12.5),
        const SizedBox(height: 10),
        // Registration kaghaz — samne / peeche (Guide S6)।
        Row(
          children: [
            Expanded(
              child: _photoSlot(
                label: tr('chk_slot_reg_front'),
                path: _regFront,
                icon: Icons.description,
                onPick: () => _pickPhoto((v) => _regFront = v),
                guideAsset: 'guidance/guidance_vehicle_reg.mp3',
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _photoSlot(
                label: tr('chk_slot_reg_back'),
                path: _regBack,
                icon: Icons.description,
                onPick: () => _pickPhoto((v) => _regBack = v),
                guideAsset: 'guidance/guidance_vehicle_reg.mp3',
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        // Gaari ki tasaveer — samne / peeche।
        Row(
          children: [
            Expanded(
              child: _photoSlot(
                label: tr('reg_slot_front'),
                path: _vehiclePhoto,
                icon: Icons.photo_camera,
                onPick: () => _pickPhoto((v) => _vehiclePhoto = v),
                guideAsset: 'guidance/guidance_vehicle_photo.mp3',
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _photoSlot(
                label: tr('reg_slot_back'),
                path: _vehicleBack,
                icon: Icons.photo_camera,
                onPick: () => _pickPhoto((v) => _vehicleBack = v),
                guideAsset: 'guidance/guidance_vehicle_photo.mp3',
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        // Gaari ki tasaveer — bayein / dayein (Guide S6)।
        Row(
          children: [
            Expanded(
              child: _photoSlot(
                label: tr('reg_slot_left'),
                path: _vehicleLeft,
                icon: Icons.photo_camera,
                onPick: () => _pickPhoto((v) => _vehicleLeft = v),
                guideAsset: 'guidance/guidance_vehicle_photo.mp3',
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _photoSlot(
                label: tr('reg_slot_right'),
                path: _vehicleRight,
                icon: Icons.photo_camera,
                onPick: () => _pickPhoto((v) => _vehicleRight = v),
                guideAsset: 'guidance/guidance_vehicle_photo.mp3',
              ),
            ),
          ],
        ),
        const SizedBox(height: 18),
        // Ikhtiyari / sharti kaghazat (Guide S6): Fitness /
        // Permit jahan laagu, Insurance IKHTIYARI (Boz ka
        // pakka usool 2026-11-24 01:10 — na ho to ID/online
        // nahi rukta)। In par is qadam ki jaanch NAHI rukti।
        Text(tr('guide_optional_docs'),
            style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        _photoSlot(
          label: tr('reg_fit_slot'),
          path: _fitnessPhoto,
          icon: Icons.fact_check,
          onPick: () => _pickPhoto((v) => _fitnessPhoto = v),
          guideAsset: 'guidance/guidance_gate_docs.mp3',
        ),
        const SizedBox(height: 10),
        _photoSlot(
          label: tr('reg_ins_slot'),
          path: _insurancePhoto,
          icon: Icons.shield,
          onPick: () => _pickPhoto((v) => _insurancePhoto = v),
          guideAsset: 'guidance/guidance_gate_docs.mp3',
        ),
        const SizedBox(height: 10),
        _photoSlot(
          label: tr('reg_permit_slot'),
          path: _permitPhoto,
          icon: Icons.assignment,
          onPick: () => _pickPhoto((v) => _permitPhoto = v),
        ),
      ],
    );
  }


  Widget _vehicleCard(String v) {
    final selected = _vehicle == v;
    // B7 (DESIGN WAVE): har gaari ka APNA icon — passenger side
    // wale sahi icons (Rickshaw = electric_rickshaw, Taxi =
    // local_taxi); pehle Rickshaw/Taxi bhi airport_shuttle par thay.
    // v1.4.46: ye icon ab sirf FALLBACK hai — card par asal photo
    // na mile to yehi nazar ata hai।
    final icon = v == 'Bike'
        ? Icons.two_wheeler
        : v == 'Car'
            ? Icons.directions_car
            : v == 'Taxi'
                ? Icons.local_taxi
                : v == 'Rickshaw'
                    ? Icons.electric_rickshaw
                    : Icons.airport_shuttle;
    // v1.4.46 (malik ka hukm): card par gaari ki ASAL PHOTO —
    // assets/vehicles/<type>.jpg (har card par sirf wohi ek
    // gaari, alag se kati hui)। Photo file abhi na ayi ho to
    // errorBuilder se icon wala andaaz aa jata hai — card kabhi
    // khaali ya tooti hui nahi dikhti।
    final asset = 'assets/vehicles/${v.toLowerCase()}.jpg';
    return InkWell(
      onTap: () => setState(() => _vehicle = v),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        decoration: BoxDecoration(
          // v1.4.60: gaari card ke rang Din/Raat se (Pal)।
          color: Pal.panel(context),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: selected ? Brand.gold : Pal.divider(context),
              width: selected ? 2.5 : 1.2),
        ),
        child: Column(
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(12)),
                child: Image.asset(
                  asset,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (ctx, err, stack) => Container(
                    width: double.infinity,
                    color: Brand.lightBg,
                    child: Icon(icon, size: 44, color: Brand.green),
                  ),
                ),
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                // v1.4.60: naam wali patti bhi Din/Raat se।
                color: selected ? Brand.green : Pal.panelAlt(context),
                borderRadius: const BorderRadius.vertical(
                    bottom: Radius.circular(12)),
              ),
              child: Text(
                v,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontWeight: FontWeight.w800,
                    color: selected ? Colors.white : Pal.text(context)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Tareekh ki saaf shakal: 5/3/2021 (v1.4.75)।
  String _fmtDate(DateTime d) => '${d.day}/${d.month}/${d.year}';

  /// Backend `date` column ke liye ISO format (yyyy-MM-dd)।
  String _isoDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  /// Licence ki issue date chunna (v1.4.75) — calendar aaj
  /// par band hota hai: issue date mustaqbil ki NAHI ho
  /// sakti। Chunte hi khana bhar jata hai aur Jaiza par
  /// bhi yehi tareekh dikhti hai।
  Future<void> _pickLicenceIssueDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _licenceIssueDate ?? DateTime(now.year - 2),
      firstDate: DateTime(1980),
      lastDate: now,
    );
    if (picked == null) return;
    setState(() {
      _licenceIssueDate = picked;
      _licenceIssueCtrl.text = _fmtDate(picked);
      _error = null;
    });
  }

  /// Date of birth chunna (v1.4.77 — Guide S3)।
  Future<void> _pickDob() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _dob ?? DateTime(now.year - 25),
      firstDate: DateTime(1940),
      lastDate: now,
    );
    if (picked == null) return;
    setState(() {
      _dob = picked;
      _dobCtrl.text = _fmtDate(picked);
      _error = null;
    });
  }

  /// Licence ki expiry date chunna (v1.4.77 — Guide S4)।
  Future<void> _pickLicenceExpiryDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate:
          _licenceExpiryDate ?? DateTime(now.year + 3),
      firstDate: DateTime(1980),
      lastDate: DateTime(now.year + 25),
    );
    if (picked == null) return;
    setState(() {
      _licenceExpiryDate = picked;
      _licenceExpiryCtrl.text = _fmtDate(picked);
      _error = null;
    });
  }

  // --- Step 5: Driving licence (OPTIONAL) ---------------------------------------

  Widget _stepLicence() {
    if (_licenceSkip) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.info_outline, color: Brand.green),
              title: Text(tr('reg_lic_skip_title'),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(tr('reg_lic_skip_sub'),
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurfaceVariant, fontWeight: FontWeight.w500)),
            ),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => setState(() {
              _licenceSkip = false;
              _error = null;
            }),
            icon: const Icon(Icons.badge),
            label: Text(tr('reg_lic_have_btn')),
          ),
        ],
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _infoText(tr('reg_lic_intro')),
        const SizedBox(height: 14),
        TextField(
          controller: _licenceCtrl,
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            labelText: tr('reg_lic_label'),
            helperText: tr('help_licence'),
            prefixIcon: const Icon(Icons.badge),
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _licenceIssueCtrl,
          readOnly: true,
          onTap: _pickLicenceIssueDate,
          decoration: InputDecoration(
            labelText: tr('reg_lic_issue_label'),
            hintText: tr('reg_lic_issue_hint'),
            helperText: tr('help_lic_issue'),
            prefixIcon: const Icon(Icons.calendar_month),
          ),
        ),
        const SizedBox(height: 14),
        // v1.4.77 GUIDE S4: EXPIRY DATE ka khana।
        TextField(
          controller: _licenceExpiryCtrl,
          readOnly: true,
          onTap: _pickLicenceExpiryDate,
          decoration: InputDecoration(
            labelText: tr('guide_lic_expiry_label'),
            hintText: tr('reg_lic_issue_hint'),
            prefixIcon: const Icon(Icons.event_busy),
          ),
        ),
        const SizedBox(height: 16),
        // v1.4.77 GUIDE S4: licence ki tasaveer — samne +
        // peeche + licence pakre hue live selfie। Number
        // diya hai to ye lazmi hain (optional usool: licence
        // hi na ho to skip ka rasta neeche hai)।
        Row(
          children: [
            Expanded(
              child: _photoSlot(
                label: tr('chk_slot_lic_front'),
                path: _licenceFront.isNotEmpty
                    ? _licenceFront
                    : _licencePhoto,
                icon: Icons.badge,
                onPick: () => _pickPhoto((v) {
                  _licenceFront = v;
                  _licencePhoto = v;
                }),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _photoSlot(
                label: tr('chk_slot_lic_back'),
                path: _licenceBack,
                icon: Icons.badge,
                onPick: () => _pickPhoto((v) => _licenceBack = v),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        _photoSlot(
          label: tr('chk_slot_lic_selfie'),
          path: _licenceSelfie,
          icon: Icons.face,
          onPick: () => _pickPhoto((v) => _licenceSelfie = v,
              cameraOnly: true, faceCheck: true),
        ),
        // Skip ka button SIRF tab — jab licence number khaali
        // ho (number darj kar diya to wohi record banega; skip
        // karna ho to number khaali karke skip karein)।
        if (_licenceCtrl.text.trim().isEmpty) ...[
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () {
                setState(() {
                  _licenceSkip = true;
                  _error = null;
                });
                _next();
              },
              child: Text(tr('reg_lic_skip_btn')),
            ),
          ),
        ],
      ],
    );
  }


  // --- Step 6 (v1.4.19): Fitness + Insurance + Route Permit ----
  //
  // v1.4.14 mein ye qadam Route Permit + Fitness ka tha। v1.4.19
  // DARMIYANI MODEL (malik ka FINAL faisla 2026-11-10 18:18):
  // Fitness Certificate aur Gaari ki Insurance har driver ke
  // record ke lazmi kagaz hain — khane yahan maujood hain, jis
  // ke paas hai woh upload kar deta hai, Master tasdeeq karta
  // hai aur asal haalat dono apps mein dikhti hai — LEKIN in ki
  // tangi par na registration rukti hai, na (is build mein)
  // online; woh sakhti sirf Master ke full_docs_required flag
  // se ayegi। Saare kagaz verified hon to 'Mukammal Tasdeeq'
  // darja milta hai। Route Permit ab bhi ikhtiyari hai (us ki
  // khud-zimmedari wali tasdeeq barkarar hai)। Har kagaz ke
  // neeche REHNUMAI hai (malik ka hukm ~18:12): kagaz na ho to
  // driver ko rasta bhi dikhana hai।
  Widget _stepFitnessInsurance() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          tr('reg_fit_intro'),
          style: const TextStyle(fontSize: 13.5, height: 1.5),
        ),
        const SizedBox(height: 14),
        _photoSlot(
          label: tr('reg_fit_slot'),
          path: _fitnessPhoto,
          icon: Icons.fact_check,
          onPick: () => _pickPhoto((v) => _fitnessPhoto = v),
          guideAsset: 'guidance/guidance_gate_docs.mp3',
        ),
        const SizedBox(height: 6),
        _infoText(tr('rehnumai_fitness'), size: 12.5),
        const SizedBox(height: 16),
        _photoSlot(
          label: tr('reg_ins_slot'),
          path: _insurancePhoto,
          icon: Icons.shield,
          onPick: () => _pickPhoto((v) => _insurancePhoto = v),
          guideAsset: 'guidance/guidance_gate_docs.mp3',
        ),
        const SizedBox(height: 6),
        _infoText(tr('rehnumai_insurance'), size: 12.5),
        const SizedBox(height: 16),
        _photoSlot(
          label: tr('reg_permit_slot'),
          path: _permitPhoto,
          icon: Icons.assignment,
          onPick: () => _pickPhoto((v) => _permitPhoto = v),
        ),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF6E0),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Brand.gold),
          ),
          child: Text(
            tr('reg_fit_gold'),
            style: const TextStyle(
                fontSize: 13, height: 1.55, color: Brand.ink),
          ),
        ),
        const SizedBox(height: 10),
        CheckboxListTile(
          value: _permitDeclChecked,
          onChanged: (v) =>
              setState(() => _permitDeclChecked = v ?? false),
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          title: Text(
            tr('reg_fit_decl'),
            style: const TextStyle(
                fontSize: 13.5, fontWeight: FontWeight.w600),
          ),
        ),
        const SizedBox(height: 6),
        // WAZEH EXIT (owner ka hukm): account na banana ho to
        // yahin se khatam karke bahir — registration adhoori
        // rehti hai, koi penalty nahi, koi zabardasti nahi।
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(tr('reg_exit_btn')),
          ),
        ),
        const SizedBox(height: 4),
        _infoText(tr('reg_exit_note'), size: 12),
      ],
    );
  }

  // --- Step 7 (v1.4.19): Police Character Certificate ------------
  //
  // DARMIYANI MODEL (malik ka FINAL faisla 2026-11-10 18:18):
  // ye kagaz SAB drivers se manga jata hai — Karachi/Sindh mein
  // is ka official rule abhi nahi aya, lekin record mein wahan
  // ka driver bhi bana kar upload karega; Punjab mein baghair
  // is ke tasdeeq mukammal nahi hoti। Ek hi usool, koi
  // sheher-exception nahi — LEKIN certificate ki tangi par
  // registration NAHI rukti (validation case 11 hamesha pass):
  // khana + rehnumai + Master tasdeeq + 'Mukammal Tasdeeq'
  // darje mein shumaar — yehi darmiyani rasta hai। Certificate
  // abhi na ho to driver form band karke baad mein wapas a
  // sakta hai — registration mehfooz rehti hai, sirf yehi
  // photo lagani baqi rehti hai ("Mere Kagaz" se bhi lagti hai)।
  Widget _stepCharacter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          tr('reg_char_intro'),
          style: const TextStyle(fontSize: 13.5, height: 1.5),
        ),
        const SizedBox(height: 14),
        _photoSlot(
          label: tr('reg_char_slot'),
          path: _characterPhoto,
          icon: Icons.badge,
          onPick: () => _pickPhoto((v) => _characterPhoto = v),
          guideAsset: 'guidance/guidance_character.mp3',
        ),
        const SizedBox(height: 10),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF6E0),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Brand.gold),
          ),
          child: Text(tr('rehnumai_character'),
              style: const TextStyle(
                  fontSize: 13, height: 1.55, color: Brand.ink)),
        ),
        const SizedBox(height: 10),
        _infoText(tr('reg_char_note'), size: 12.5),
      ],
    );
  }

  // --- Step 8: Live selfie ------------------------------------------------------

  Widget _stepSelfie() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _infoText(tr('reg_selfie_intro')),
        const SizedBox(height: 18),
        Center(
          child: ClipOval(
            child: _selfie.isNotEmpty && File(_selfie).existsSync()
                ? Image.file(File(_selfie),
                    width: 170, height: 170, fit: BoxFit.cover)
                : Container(
                    width: 170,
                    height: 170,
                    color: Brand.fieldBorder,
                    child: const Icon(Icons.face,
                        size: 80, color: Brand.green),
                  ),
          ),
        ),
        const SizedBox(height: 18),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: () =>
                _pickPhoto((v) => _selfie = v,
                    cameraOnly: true, faceCheck: true),
            icon: const Icon(Icons.camera_alt),
            label: Text(
                _selfie.isEmpty ? tr('reg_selfie_take') : tr('reg_selfie_retake')),
          ),
        ),
      ],
    );
  }

  // --- v1.4.77 GUIDE S7: Darkhwast ki Haalat wala card -----------
  // Draft / Jama / Jaanch mein / Manzoor / Radd (wajah ke
  // saath) / Band — asal haalat profile + Master ke pull
  // shuda faislon se banti hai; koi jaali haalat NAHI।
  Widget _guideStatusCard() {
    String label;
    String note;
    Color color;
    IconData icon;
    final blocked =
        store.numberBlockReason() ?? store.deviceBlockReason();
    final rejectedGroups = ['cnic', 'gaari', 'licence']
        .where((g) => p.masterStatusFor(g) == 'rejected')
        .toList();
    if (blocked != null) {
      label = tr('guide_status_band');
      note = blocked;
      color = Brand.ajrakRed;
      icon = Icons.block;
    } else if (rejectedGroups.isNotEmpty) {
      label = tr('guide_status_radd');
      final reasons = rejectedGroups
          .map((g) => p.masterReasonFor(g))
          .where((r) => r.isNotEmpty)
          .join(' · ');
      note = reasons.isNotEmpty ? reasons : tr('guide_review_status_note');
      color = Brand.ajrakRed;
      icon = Icons.cancel;
    } else if (p.masterActive) {
      label = tr('guide_status_manzoor');
      note = tr('guide_review_status_note');
      color = Brand.green;
      icon = Icons.verified;
    } else if (p.registrationDone) {
      label = '${tr('guide_status_jama')} · ${tr('guide_status_jaanch')}';
      note = tr('guide_review_status_note');
      color = const Color(0xFFB8860B);
      icon = Icons.hourglass_top;
    } else {
      label = tr('guide_status_draft');
      note = tr('guide_review_status_note');
      color = const Color(0xFFB8860B);
      icon = Icons.edit_note;
    }
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Pal.panel(context),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color, width: 1.4),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 22),
              const SizedBox(width: 8),
              Text(tr('guide_status_title'),
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 13)),
            ],
          ),
          const SizedBox(height: 6),
          Text(label,
              style: TextStyle(
                  fontWeight: FontWeight.w900, fontSize: 16, color: color)),
          const SizedBox(height: 4),
          Text(note, style: const TextStyle(fontSize: 12.5, height: 1.4)),
        ],
      ),
    );
  }

  // --- Qadam 13: Jaiza ------------------------------------------------------------

  /// v1.4.46: Jaiza ab apna alag qadam hai — Radius + Agent Code
  /// + saari maloomat ka khulasa। Sheher yahan se nikal kar
  /// Naam wale qadam (3) par chala gaya hai (record mein wohi
  /// _zone jata hai); Sharait apne alag aakhri qadam (14) par
  /// hain। Radius ki awaaz wali hidayat is qadam par khud bajti
  /// hai (_playStepGuide) aur speaker button se dobara bhi sun
  /// sakte hain।
  Widget _stepReview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // v1.4.77 GUIDE S7: darkhwast ki haalat sab se upar।
        _guideStatusCard(),
        const SizedBox(height: 18),
        // RADIUS (FINAL RULE, owner 2026-11-11 16:36): driver
        // apna pickup daira yahan set karta hai — 2 km pehle
        // se laga (pre-selected) ata hai, 5 km tak badha
        // sakta hai, 2 se kam NAHI. Wohi jumla neeche likha
        // bhi ata hai।
        Row(
          children: [
            Expanded(
              child: Text(tr('reg_radius_title'),
                  style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
            IconButton(
              icon: const Icon(Icons.volume_up, color: Brand.green),
              tooltip: tr('reg_radius_tip'),
              onPressed: () =>
                  unawaited(GuideAudio.play(_radiusGuideAsset)),
            ),
          ],
        ),
        _infoText(tr('reg_radius_text'), size: 13),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: [
            for (final km in kRadiusOptionsKm)
              ChoiceChip(
                label: Text('${km.toStringAsFixed(0)} km'),
                selected: _radiusKm == km,
                onSelected: (sel) {
                  if (sel) setState(() => _radiusKm = km);
                },
              ),
          ],
        ),
        _infoText(tr('reg_radius_note'), size: 12),
        const SizedBox(height: 18),
        // AGENT CODE (v1.4.6): ikhtiyari field — jaiza se pehle.
        // Agent ne bheja ho to us ka code; warna khaali chhor
        // dein, registration is ke baghair bhi mukammal hoti hai.
        TextField(
          controller: _agentCodeCtrl,
          textCapitalization: TextCapitalization.characters,
          decoration: InputDecoration(
            labelText: tr('reg_agent_label'),
            hintText: tr('reg_agent_hint'),
            helperText: tr('help_agent'),
            border: const OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 18),
        Text(tr('reg_review_title'),
            style: const TextStyle(
                fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        _reviewRow('Mobile', _digits(_mobileCtrl.text)),
        _reviewRow(tr('reg_rev_name'), _nameCtrl.text.trim()),
        _reviewRow('CNIC', _formatCnic(_digits(_cnicCtrl.text))),
        // v1.4.77 GUIDE S3 rows।
        if (_dob != null)
          _reviewRow(tr('guide_dob_label'), _fmtDate(_dob!)),
        _reviewRow(tr('guide_address_label'), _addressCtrl.text.trim()),
        if (_emergencyNameCtrl.text.trim().isNotEmpty ||
            _emergencyMobileCtrl.text.trim().isNotEmpty)
          _reviewRow(tr('guide_emergency_name'),
              '${_emergencyNameCtrl.text.trim()} · ${_emergencyMobileCtrl.text.trim()}'),
        _reviewRow(
            'Gmail',
            _emailCtrl.text.trim().isEmpty
                ? '—'
                : '${_emailCtrl.text.trim()}${_emailVerifiedFor == _emailCtrl.text.trim().toLowerCase() ? tr('reg_rev_verified') : ''}'),
        _reviewRow('Password',
            p.pwdFp.isNotEmpty || _stagedFp != null ? tr('reg_rev_set') : '—'),
        _reviewRow(tr('reg_rev_vehicle'),
            '$_vehicle · ${_brandCtrl.text.trim()} ${_modelCtrl.text.trim()}'),
        _reviewRow(tr('reg_rev_year_color'),
            '${_year ?? '—'} · ${_colorCtrl.text.trim()}'),
        _reviewRow('Number plate', _plateCtrl.text.trim()),
        // v1.4.77 GUIDE S5 rows।
        if (_seating > 0)
          _reviewRow(tr('guide_seating_label'), '$_seating'),
        if (_ownership.isNotEmpty)
          _reviewRow(tr('guide_ownership_label'), _ownership),
        if (_featAc || _featLuggage)
          _reviewRow(tr('guide_features_label'),
              [if (_featAc) 'AC', if (_featLuggage) 'Luggage'].join(', ')),
        _reviewRow(
            'Licence',
            _licenceSkip
                ? tr('reg_rev_nolicence')
                : (_licenceCtrl.text.trim().isEmpty
                    ? '—'
                    : _licenceCtrl.text.trim())),
        // v1.4.75: issue date bhi Jaiza mein saaf dikhe —
        // driver apni bhari hui tareekh yahin tasdeeq kar le।
        if (!_licenceSkip && _licenceIssueDate != null)
          _reviewRow(
              tr('reg_rev_lic_issue'), _fmtDate(_licenceIssueDate!)),
        // v1.4.77 GUIDE S4: expiry date bhi Jaiza mein।
        if (!_licenceSkip && _licenceExpiryDate != null)
          _reviewRow(tr('guide_lic_expiry_label'),
              _fmtDate(_licenceExpiryDate!)),
        // v1.4.19: naye kagazon ki haalat bhi jaize mein saaf —
        // lagi hai ya baqi (baqi ho to registration NAHI rukti,
        // baad mein Mere Kagaz se lag jayegi)।
        _reviewRow('Fitness Certificate',
            _fitnessPhoto.isNotEmpty
                ? tr('reg_rev_photo_done')
                : tr('reg_rev_pending')),
        _reviewRow('Insurance',
            _insurancePhoto.isNotEmpty
                ? tr('reg_rev_photo_done')
                : tr('reg_rev_pending')),
        _reviewRow('Character Certificate',
            _characterPhoto.isNotEmpty
                ? tr('reg_rev_photo_done')
                : tr('reg_rev_pending')),
        _reviewRow('Zone', _zone),
        _reviewRow(tr('reg_rev_radius'), '${_radiusKm.toStringAsFixed(0)} km'),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _thumb(tr('reg_th_cnic_f'), _cnicFront),
            _thumb(tr('reg_th_cnic_b'), _cnicBack),
            _thumb(tr('reg_th_vehicle'), _vehiclePhoto),
            _thumb(tr('reg_slot_back'), _vehicleBack),
            _thumb(tr('reg_slot_left'), _vehicleLeft),
            _thumb(tr('reg_slot_right'), _vehicleRight),
            _thumb(tr('reg_th_paper'), _vehicleReg),
            if (!_licenceSkip && _licenceFront.isNotEmpty)
              _thumb(tr('chk_slot_lic_front'), _licenceFront),
            if (!_licenceSkip && _licenceBack.isNotEmpty)
              _thumb(tr('chk_slot_lic_back'), _licenceBack),
            if (!_licenceSkip && _licencePhoto.isNotEmpty &&
                _licenceFront.isEmpty)
              _thumb('Licence', _licencePhoto),
            if (_fitnessPhoto.isNotEmpty) _thumb('Fitness', _fitnessPhoto),
            if (_insurancePhoto.isNotEmpty)
              _thumb('Insurance', _insurancePhoto),
            if (_characterPhoto.isNotEmpty)
              _thumb('Character', _characterPhoto),
            _thumb('Selfie', _selfie),
          ],
        ),
        const SizedBox(height: 14),
        _infoText(tr('reg_review_note'), size: 12),
      ],
    );
  }

  // --- Qadam 14: Sharait ------------------------------------------------------------

  /// Aakhri qadam (v1.4.46): Sharait ki qubooliyat — pehle ye
  /// hissa Jaiza wale qadam ke neeche tha, ab apni alag screen
  /// hai। v1.4.4 LEGAL wala usool bilkul waisa hi: qabool karne
  /// ka waqt darj ho jata hai (store.acceptDriverTerms — profile
  /// + backend) aur Master ko saboot ke tor par nazar ata hai;
  /// Amanat Deposit ki alag tasdeeq (v1.4.21) bhi yahin hai।
  /// Baghair dono nishanon ke Register NAHI hota (validation
  /// case 15)।
  Widget _stepTerms() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Brand.lightBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Brand.fieldBorder),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.description, size: 19, color: Brand.green),
                  const SizedBox(width: 8),
                  Text(tr('legal_gate_title'),
                      style: const TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 14.5,
                          color: Brand.ink)),
                ],
              ),
              const SizedBox(height: 4),
              Text(tr('reg_terms_intro'),
                  style: const TextStyle(
                      fontSize: 12.5,
                      height: 1.45,
                      color: Brand.onLightSub,
                      fontWeight: FontWeight.w500)),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                        builder: (_) =>
                            const TermsPage(showDriverTerms: true)),
                  ),
                  style:
                      TextButton.styleFrom(foregroundColor: Brand.green),
                  icon: const Icon(Icons.menu_book, size: 17),
                  label: Text(tr('reg_terms_read')),
                ),
              ),
              CheckboxListTile(
                value: _termsChecked,
                onChanged: (v) async {
                  setState(() => _termsChecked = v ?? false);
                  if (v == true) {
                    // Qabool karte hi waqt darj (profile + backend).
                    await store.acceptDriverTerms();
                  }
                },
                title: Text(tr('legal_gate_accept'),
                    style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                        color: Brand.ink)),
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.zero,
                dense: true,
              ),
              // AMANAT DEPOSIT ki alag tasdeeq (v1.4.21): driver
              // ki apni raqam ka muamla hai — is liye aam sharait
              // wale nishan ke ilawa is ki tasdeeq alag satr mein।
              CheckboxListTile(
                value: _amanatChecked,
                onChanged: (v) =>
                    setState(() => _amanatChecked = v ?? false),
                title: Text(tr('reg_amanat_decl'),
                    style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 12.5,
                        color: Brand.ink)),
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.zero,
                dense: true,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _reviewRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(label,
                style: TextStyle(
                    fontWeight: FontWeight.w700, color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ),
          Expanded(
            child: Text(value.isEmpty ? '—' : value,
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _thumb(String label, String path) {
    final ok = path.isNotEmpty && File(path).existsSync();
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: ok
              ? Image.file(File(path),
                  width: 64, height: 64, fit: BoxFit.cover)
              : Container(
                  width: 64,
                  height: 64,
                  color: Brand.fieldBorder,
                  child: const Icon(Icons.image_not_supported,
                      color: Brand.ajrakRed),
                ),
        ),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(fontSize: 10)),
      ],
    );
  }

  // --- Photo slot (tasveer wali jagah) ------------------------------------------

  Widget _photoSlot({
    required String label,
    required String path,
    required IconData icon,
    required VoidCallback onPick,
    // v1.4.5: is khane ki apni awaaz wali hidayat (assets/guidance)
    // — tap par pehle awaaz bajti hai, phir camera/gallery khulta
    // hai, taaki anparh driver bhi sun kar sahi tasveer lagaye.
    String? guideAsset,
    // v1.4.46: CNIC wale bare qadmon par slot bhi bara
    // hota hai (alag screen par poora frame mile)।
    bool large = false,
  }) {
    final ok = path.isNotEmpty && File(path).existsSync();
    return InkWell(
      onTap: () {
        if (guideAsset != null) unawaited(GuideAudio.play(guideAsset));
        onPick();
      },
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          // v1.4.60: photo card ke rang Din/Raat se (Pal)।
          color: Pal.panel(context),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: ok ? Brand.green : Pal.divider(context),
              width: ok ? 1.8 : 1.2),
        ),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: ok
                  ? Image.file(File(path),
                      width: double.infinity, height: large ? 170 : 92, fit: BoxFit.cover)
                  : Container(
                      width: double.infinity,
                      height: large ? 170 : 92,
                      color: Brand.lightBg,
                      child: Icon(icon, size: 40, color: Brand.green),
                    ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(ok ? Icons.check_circle : Icons.add_a_photo,
                    size: 16,
                    color: ok ? Brand.green : Brand.ajrakRed),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(label,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.w700)),
                ),
              ],
            ),
            Text(ok ? tr('reg_slot_change') : tr('reg_slot_required'),
                style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w600,
                    color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }
}

/// CNIC ka input formatter: sirf number, kul 13, khud-ba-khud
/// XXXXX-XXXXXXX-X ki shakal (5-7-1) banata hai.
class _CnicInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    var d = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.length > 13) d = d.substring(0, 13);
    final buf = StringBuffer();
    for (var i = 0; i < d.length; i++) {
      if (i == 5 || i == 12) buf.write('-');
      buf.write(d[i]);
    }
    final out = buf.toString();
    return TextEditingValue(
      text: out,
      selection: TextSelection.collapsed(offset: out.length),
    );
  }
}
