plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bozdar.whitefilter"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.bozdar.whitefilter"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // On-device person segmentation (bundled model, works offline).
    // Mask buffer format: one float per pixel, foreground confidence 0.0..1.0.
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
}
