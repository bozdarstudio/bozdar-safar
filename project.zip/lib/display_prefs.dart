import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'lang.dart';
import 'theme.dart';

// =====================================================================
// v1.4.30 — DISPLAY PASAND: Din / Raat / Khud-ba-khud (EK BUTTON)
// (malik ka hukm 2026-11-11 17:10 + tashheesh 17:11)
//
// EK hi pasand hai aur EK hi button (DisplayModeButton) isay
// badalta hai — is se POORI APP ka theme AUR har map ka style
// DONO ek saath badalte hain (alag alag button NAHI hain):
//   Day   → halka Safar theme + CARTO Voyager (roshan map)
//   Night → gehra Safar theme + CARTO Dark Matter (gehra map)
//   Auto  → phone ki apni brightness ke mutabiq
// Pasand SharedPreferences mein mehfooz rehti hai — band karke
// kholne par bhi wohi rehti hai. Passenger + driver dono modes
// mein yehi ek pasand chalti hai.
// =====================================================================

enum DisplayMode { day, night, auto }

class DisplayPrefs {
  static const String _key = 'display_mode_v1';

  static final ValueNotifier<DisplayMode> notifier =
      ValueNotifier<DisplayMode>(DisplayMode.day);

  static bool _loaded = false;

  static Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      notifier.value = switch (prefs.getString(_key)) {
        'night' => DisplayMode.night,
        'auto' => DisplayMode.auto,
        _ => DisplayMode.day,
      };
    } catch (_) {
      // Pasand na mile to Day — app rukti nahi।
    }
  }

  static Future<void> set(DisplayMode m) async {
    notifier.value = m;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key, m.name);
    } catch (_) {}
  }

  /// Button ka amal: Day → Night → Auto → Day …
  static Future<void> cycle() => set(switch (notifier.value) {
        DisplayMode.day => DisplayMode.night,
        DisplayMode.night => DisplayMode.auto,
        DisplayMode.auto => DisplayMode.day,
      });

  static ThemeMode get themeMode => switch (notifier.value) {
        DisplayMode.day => ThemeMode.light,
        DisplayMode.night => ThemeMode.dark,
        DisplayMode.auto => ThemeMode.system,
      };

  /// Is waqt asal mein RAAT wala nazara hai ya nahi (map ka
  /// style chunne ke liye) — Auto par phone ki brightness।
  static bool isDarkNow(BuildContext context) => switch (notifier.value) {
        DisplayMode.day => false,
        DisplayMode.night => true,
        DisplayMode.auto =>
          MediaQuery.platformBrightnessOf(context) == Brightness.dark,
      };
}

/// v1.4.42 (H1R — owner hukm 2026-11-13 02:40): Din/Raat ka
/// CHHOTA GOL ICON button — koi likhai NAHI, sirf nishani
/// (sooraj / chaand / auto)। Map ke side controls wali
/// column mein yehi rehta hai; amal wohi hai jo pill wala
/// button karta tha — tap par Day → Night → Auto → Day
/// (DisplayPrefs.cycle), poori app + map ek saath badalte
/// hain। Function bilkul khatam NAHI hua, sirf shakal
/// badli hai: likha hua "Raat" pill header se gaya, gol
/// icon map ke controls mein aa gaya।
class DisplayModeIconButton extends StatelessWidget {
  const DisplayModeIconButton({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<DisplayMode>(
      valueListenable: DisplayPrefs.notifier,
      builder: (context, mode, _) {
        final icon = switch (mode) {
          DisplayMode.day => Icons.light_mode,
          DisplayMode.night => Icons.dark_mode,
          DisplayMode.auto => Icons.brightness_auto,
        };
        return Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => DisplayPrefs.cycle(),
            customBorder: const CircleBorder(),
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Brand.deepGreen.withOpacity(0.92),
                border: Border.all(color: Brand.gold, width: 1),
              ),
              child: Icon(icon, color: Brand.goldLight, size: 18),
            ),
          ),
        );
      },
    );
  }
}

/// EK display button — header aur map ke side controls, dono
/// jagah yehi ek button hai aur yehi ek pasand badalta hai।
class DisplayModeButton extends StatelessWidget {
  final bool compact;
  const DisplayModeButton({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<DisplayMode>(
      valueListenable: DisplayPrefs.notifier,
      builder: (context, mode, _) {
        final (icon, label) = switch (mode) {
          DisplayMode.day => (Icons.light_mode, tr('display_day')),
          DisplayMode.night => (Icons.dark_mode, tr('display_night')),
          DisplayMode.auto =>
            (Icons.brightness_auto, tr('display_auto')),
        };
        return Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => DisplayPrefs.cycle(),
            borderRadius: BorderRadius.circular(20),
            child: Container(
              padding: EdgeInsets.symmetric(
                  horizontal: compact ? 8 : 10, vertical: 6),
              decoration: BoxDecoration(
                color: Brand.deepGreen.withOpacity(0.92),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Brand.gold, width: 1),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: Brand.goldLight, size: 15),
                  const SizedBox(width: 5),
                  Text(label,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
