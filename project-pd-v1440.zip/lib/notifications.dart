import 'dart:async';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:url_launcher/url_launcher.dart';
import 'backend.dart';
import 'lang.dart';
import 'store.dart';
import 'support_auto.dart';
import 'theme.dart';

// ===========================================================================
// v1.4.0 — Kami Fix Wave ke mushtarka UI hisse:
//  - Notification bell (dono modes) + Notification Centre screen
//  - Foreground banner: naya event ate hi saamne wali screen par snackbar
//  - SOS button (active ride — passenger + driver dono)
//  - Ride ki RASEED (receipt) dialog + share
//  - Rating wale sitare (passenger, completed ride par)
// Ye sab is liye EK file mein hain taaki passenger.dart aur
// driver.dart dono baghair duplicate code ke wohi cheezein istemal
// kar sakein. Fare/display ke tamam locks in par bhi laagu hain:
// yahan koi per-km rate kabhi render NAHI hota — sirf jo kul raqam
// booking ke record mein pehle se hai (fare + waiting = total).
// ===========================================================================

/// Notification bell — AppBar-style rows mein lagta hai (BrandHeader
/// ke neeche wale toggle ke saath wali patti mein). Na-parhe events
/// par laal badge. Tap = Notification Centre; khulte hi saare
/// "parha hua" ho jate hain.
class NotificationBell extends StatelessWidget {
  final AppStore store;

  /// v1.4.5: ghanti ab BrandHeader ke gehri sabz patti ke ANDAR
  /// hai — wahan icon halka (cream) rang mein dikhta hai.
  final bool onDark;
  const NotificationBell({super.key, required this.store, this.onDark = false});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final unread = store.unreadNotifications;
        return IconButton(
          tooltip: 'Notifications',
          onPressed: () async {
            await Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => NotificationCentreScreen(store: store),
              ),
            );
            await store.markAllNotificationsRead();
          },
          icon: Badge(
            label: Text('$unread'),
            isLabelVisible: unread > 0,
            child: Icon(Icons.notifications,
                color: onDark ? Brand.cream : Brand.greenDark),
          ),
        );
      },
    );
  }
}

/// Notification Centre — saari entries (nayi upar), Master ke
/// elanaat bhi yahin. Khaali ho to saaf paigham.
class NotificationCentreScreen extends StatelessWidget {
  final AppStore store;
  const NotificationCentreScreen({super.key, required this.store});

  IconData _iconFor(String kind) => kind == 'announcement'
      ? Icons.campaign
      : kind == 'deposit'
          ? Icons.account_balance_wallet
          : Icons.directions_car;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final list = store.notifications;
          if (list.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Abhi koi notification nahi hai.\nRide ki khabar aur Safar ke elanaat yahan ayenge.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 14, color: Colors.black54),
                ),
              ),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: list.length,
            itemBuilder: (context, i) {
              final n = list[i];
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                color: n.read ? null : const Color(0xFFFFF6DA),
                child: ListTile(
                  leading: Icon(_iconFor(n.kind), color: Brand.green),
                  title: Text(n.title,
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text(
                      '${n.body}\n${fmtDate(n.createdAt)} ${fmtTime(n.createdAt)}'),
                  isThreeLine: n.body.isNotEmpty,
                ),
              );
            },
          );
        },
      ),
    );
  }
}

/// Foreground banner ka listener — jo screen saamne ho, naya
/// notification event ate hi us par ek snackbar dikhata hai
/// (ride accepted / driver pohanch gaya / elaan waghera). Dono
/// sides (PassengerSide/DriverSide) apni state mein is mixin ko
/// shamil karti hain; dispose par subscription band ho jati hai.
mixin NotificationBannerMixin<T extends StatefulWidget> on State<T> {
  StreamSubscription<AppNotification>? _notifSub;

  /// initState mein super ke baad bulayein — [store] us side ka
  /// mushtarka store hai.
  void listenNotificationBanners(AppStore store) {
    _notifSub = store.notificationEvents.stream.listen((n) {
      if (!mounted) return;
      final messenger = ScaffoldMessenger.maybeOf(context);
      if (messenger == null) return;
      messenger.showSnackBar(
        SnackBar(
          content: Text(
            n.body.isEmpty ? n.title : '${n.title} — ${n.body}',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          duration: const Duration(seconds: 4),
        ),
      );
    });
  }

  void cancelNotificationBanners() {
    _notifSub?.cancel();
    _notifSub = null;
  }
}

// ---------------------------------------------------------------------------
// SOS — active ride ke doran hifazat ka button (passenger + driver)
// ---------------------------------------------------------------------------

/// Laal SOS button. Tap → tasdeeq wala dialog → teen amal:
///  1) 1122 par call (Emergency / Rescue — tel:1122)
///  2) Master ko khabar — mojooda Master-messages raste se ek
///     SOS message Master inbox mein jata hai jis mein ride ki
///     tafseel (driver/sawari ke naam, gaari, jagah) hoti hai
///     (v1.4.4 — malik ki khaas safety shart). v1.4.25: is
///     message ki category alag 'SOS' hai taaki Master inbox
///     mein aam messages se ALAG pehchan ke saath dikhe, aur
///     saath push notification ki asal koshish bhi hoti hai
///     (invokePush — deploy/jawab ki haalat pushLog mein darj
///     rehti hai; dawa sirf wohi hai jo asal hai: khabar inbox
///     ke liye bhej di jati hai, fori phone-alert ka dawa NAHI).
///  3) "Ghar walon ko bhejo" — ride ki live tafseel (kaun, gaari,
///     plate, pickup → drop, waqt) WhatsApp par share — bilkul
///     passenger ke mojooda share-my-ride jaisa tareeqa (wa.me link).
class SosButton extends StatelessWidget {
  final AppStore store;
  final Booking booking;

  /// 'passenger' ho to share text mein driver ki pehchan jati hai;
  /// 'driver' ho to sawari ki maloomat.
  final String role;
  const SosButton({
    super.key,
    required this.store,
    required this.booking,
    required this.role,
  });

  Future<void> _confirm(BuildContext context) async {
    final b = booking;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.sos, color: Brand.ajrakRed, size: 28),
            SizedBox(width: 8),
            Text('SOS — Madad'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Khuda na khasta koi pareshani ho to foran madad lein:',
              style: TextStyle(fontSize: 13.5),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () async {
                  Navigator.pop(ctx);
                  final ok = await launchUrl(Uri.parse('tel:1122'));
                  if (!ok && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Call nahi ho saki.')),
                    );
                  }
                },
                icon: const Icon(Icons.emergency, size: 19),
                label: const Text('1122 par call karein (Emergency)'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Brand.ajrakRed,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                ),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () async {
                  Navigator.pop(ctx);
                  // v1.4.25: category alag 'SOS' — Master inbox
                  // mein aam 'Ride ka masla' messages se alag
                  // pehchan ke saath dikhega।
                  await store.addMasterMessage(MasterMessage(
                    id: store.newId(),
                    senderKey:
                        role == 'driver' ? store.driverId : store.deviceId,
                    senderRole: role,
                    senderName: role == 'driver'
                        ? store.profile.name
                        : b.passengerName,
                    senderMobile: role == 'driver'
                        ? store.profile.phone
                        : b.passengerPhone,
                    senderZone: store.profile.zone,
                    category: 'SOS',
                    body: 'SOS — MADAD KI ZAROORAT! '
                        '${role == 'driver' ? 'Driver' : 'Sawari'} ne chalti ride mein SOS dabai hai.\n'
                        'Ride: ${b.pickupLabel} → ${b.dropLabel} (${b.vehicle})\n'
                        'Driver: ${b.driverName}${b.driverPlate.isNotEmpty ? ' · Plate ${b.driverPlate}' : ''}\n'
                        'Sawari: ${b.passengerName}${b.passengerPhone.isNotEmpty ? ' · ${b.passengerPhone}' : ''}\n'
                        'Waqt: ${fmtDate(DateTime.now())} ${fmtTime(DateTime.now())}',
                    createdAt: DateTime.now(),
                  ));
                  // Master ke phone par push ki asal koshish bhi
                  // (function deploy/jawab ki haalat pushLog mein
                  // darj rehti hai — dawa is par NAHI bandha)।
                  unawaited(Backend.invokePush({
                    'audience': 'masters',
                    'title': 'SOS — Madad ki zaroorat!',
                    'body':
                        '${b.pickupLabel} → ${b.dropLabel} · ${b.vehicle} — chalti ride mein SOS aya hai',
                    'data': {'ride_id': b.id, 'sos': '1'},
                  }));
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text(
                              'SOS khabar Master ke inbox mein bhej di gayi hai. Shadeed emergency mein 1122 par call karein.')),
                    );
                  }
                },
                icon: const Icon(Icons.support_agent, size: 19),
                label: const Text('Master ko khabar bhejein'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Brand.deepGreen,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                ),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  Navigator.pop(ctx);
                  final text = _shareText();
                  final uri = Uri.parse(
                      'https://wa.me/?text=${Uri.encodeComponent(text)}');
                  final ok = await launchUrl(uri,
                      mode: LaunchMode.externalApplication);
                  if (!ok && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('WhatsApp nahi khul saka.')),
                    );
                  }
                },
                icon: const Icon(Icons.share, size: 18),
                label: const Text('Ride ghar walon ko bhejo (WhatsApp)'),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '${b.pickupLabel} → ${b.dropLabel} · ${b.vehicle}',
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Band Karein'),
          ),
        ],
      ),
    );
  }

  String _shareText() {
    final b = booking;
    final p = store.profile;
    final who = role == 'passenger'
        ? 'Driver: ${b.driverName} (${p.vehicle}${p.plate.isEmpty ? '' : ' · Plate ${p.plate}'})'
        : 'Sawari: ${b.passengerName}${b.passengerPhone.isEmpty ? '' : ' (${b.passengerPhone})'} · Gaari: ${b.vehicle}';
    return 'SOS — Safar ride ki tafseel:\n'
        '$who\n'
        'Route: ${b.pickupLabel} → ${b.dropLabel}\n'
        'Waqt: ${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)}\n'
        'Main is ride mein hun — zaroorat par madad karein.';
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: () => _confirm(context),
        icon: const Icon(Icons.sos, size: 20),
        label: const Text('SOS — Hifazat'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Brand.ajrakRed,
          padding: const EdgeInsets.symmetric(vertical: 11),
          textStyle:
              const TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// RASEED (Receipt) — mukammal ride ki saaf raseed + share
// ---------------------------------------------------------------------------

/// Raseed ka mutan (text) — dialog aur WhatsApp share dono yahi
/// istemal karte hain. Sirf wohi numbers jo booking record mein
/// pehle se hain: base kiraya (fare), waiting charges, kul total —
/// koi per-km rate kabhi NAHI likha jata (fare display lock).
String receiptText(AppStore store, Booking b) {
  final p = store.profile;
  return 'SAFAR — Ride ki Raseed\n'
      'Ride ID: ${b.id}\n'
      'Tareekh: ${fmtDate(b.completedAt ?? b.createdAt)} ${fmtTime(b.completedAt ?? b.createdAt)}\n'
      'Route: ${b.pickupLabel} → ${b.dropLabel}\n'
      'Doori: ${b.distanceKm.toStringAsFixed(1)} km\n'
      'Kiraya: ${rs(b.fare)}\n'
      'Waiting charges: ${rs(b.waitingCharge)}\n'
      // v1.4.24 TAX (SRB): tax ki ALAG line — sawari ki kul
      // adaigi tax samait hai; tax na laga ho to purani shakal
      // bilkul barkarar rehti hai।
      '${b.hasTax ? '${taxLabelFor(b.vehicle)}: ${rs(b.taxAmount)}\n' : ''}'
      'KUL: ${rs(b.hasTax ? b.grandTotal : b.total)}\n'
      'Gaari: ${b.vehicle}${p.plate.isEmpty ? '' : ' · Plate ${p.plate}'}\n'
      'Driver: ${b.driverName}\n'
      'Adaigi: Cash';
}

/// Mukammal ride ki RASEED dialog mein dikhana — ride id, tareekh,
/// route, doori, kiraaye ki tafseel (base + waiting), kul, gaari +
/// driver + plate, payment method (Cash), aur Share button
/// (WhatsApp par text — app ke mojooda share wale tareeqe se).
Future<void> showReceiptDialog(
    BuildContext context, AppStore store, Booking b) async {
  final p = store.profile;
  Widget row(String label, String value, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 118,
            child: Text(label,
                style: const TextStyle(fontSize: 13, color: Colors.black54)),
          ),
          Expanded(
            child: Text(value,
                style: TextStyle(
                    fontSize: 13.5,
                    fontWeight: bold ? FontWeight.w900 : FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  await showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      title: const Row(
        children: [
          Icon(Icons.receipt_long, color: Brand.green, size: 26),
          SizedBox(width: 8),
          Text('Ride ki Raseed'),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            row('Ride ID', b.id),
            row('Tareekh',
                '${fmtDate(b.completedAt ?? b.createdAt)} ${fmtTime(b.completedAt ?? b.createdAt)}'),
            row('Route', '${b.pickupLabel} → ${b.dropLabel}'),
            row('Doori', '${b.distanceKm.toStringAsFixed(1)} km'),
            const Divider(),
            row('Kiraya', rs(b.fare)),
            row('Waiting', rs(b.waitingCharge)),
            // v1.4.24 TAX (SRB): tax ki alag line + kul (tax
            // samait) — tax company ki kamai NAHI, sarkari hai;
            // yehi tafseel malik ke design (20:50) ka asal amal hai।
            if (b.hasTax) row(taxLabelFor(b.vehicle), rs(b.taxAmount)),
            row(b.hasTax ? 'KUL (tax samait)' : 'KUL',
                rs(b.hasTax ? b.grandTotal : b.total),
                bold: true),
            const Divider(),
            row('Gaari',
                '${b.vehicle}${p.plate.isEmpty ? '' : ' · Plate ${p.plate}'}'),
            row('Driver', b.driverName),
            row('Adaigi', 'Cash'),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Band Karein'),
        ),
        ElevatedButton.icon(
          onPressed: () async {
            final uri = Uri.parse(
                'https://wa.me/?text=${Uri.encodeComponent(receiptText(store, b))}');
            final ok =
                await launchUrl(uri, mode: LaunchMode.externalApplication);
            if (!ok && ctx.mounted) {
              ScaffoldMessenger.of(ctx).showSnackBar(
                const SnackBar(content: Text('WhatsApp nahi khul saka.')),
              );
            }
          },
          icon: const Icon(Icons.share, size: 17),
          label: const Text('Share Karein'),
        ),
      ],
    ),
  );
}

// ---------------------------------------------------------------------------
// v1.4.4 — WAJAH wala sheet, Report/Shikayat, Driver ki sawari ko rating
// ---------------------------------------------------------------------------

/// WAJAH poochhne wala mushtarka bottom sheet (v1.4.4 — malik ki
/// khaas shart): tay-shuda wajahen ([options], aam tor par
/// kRideReasonOptions) mein se ek chunna lazmi hai; neeche apni
/// baat likhne ki jagah bhi hai (likhi jaye to wajah ke saath jud
/// kar mehfooz hoti hai). "Jama Karein" par mukammal wajah text
/// wapas ata hai; sheet band karne par null (koi action nahi).
Future<String?> showReasonSheet(
  BuildContext context, {
  required String title,
  required List<String> options,
  // v1.4.30 (audit F-3): khaali = maujooda zubaan ka default
  // submit label (tr 'reason_submit') — English mode mein bhi
  // sheet ab Roman Urdu par NAHI atki rehti।
  String submitLabel = '',
  // v1.4.29 (owner hukm 2026-11-11 16:29): ARRIVED stage par
  // wajah COMPULSORY — sheet swipe/back se band hi NAHI hoti;
  // passenger ya wajah de kar aage barhe ya "Wapas" se cancel
  // ka irada hi chhor de। Skip ka koi rasta NAHI।
  bool mustGiveReason = false,
}) async {
  var selected = -1;
  final textCtrl = TextEditingController();
  final result = await showModalBottomSheet<String>(
    context: context,
    isDismissible: !mustGiveReason,
    enableDrag: !mustGiveReason,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (sheetCtx) => StatefulBuilder(
      builder: (sheetCtx, setSheetState) => Padding(
        padding: EdgeInsets.fromLTRB(
          18,
          12,
          18,
          22 + MediaQuery.of(sheetCtx).viewInsets.bottom,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 5,
                  decoration: BoxDecoration(
                    color: Brand.fieldBorder,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(title,
                  style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w900,
                      color: Brand.greenDark)),
              const SizedBox(height: 4),
              Text(
                tr('reason_note'),
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
              const SizedBox(height: 8),
              ...options.asMap().entries.map((e) {
                final isSel = selected == e.key;
                return InkWell(
                  onTap: () => setSheetState(() => selected = e.key),
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Row(
                      children: [
                        Container(
                          width: 22,
                          height: 22,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color:
                                  isSel ? Brand.green : const Color(0xFFB9CFC6),
                              width: 2,
                            ),
                          ),
                          child: isSel
                              ? Center(
                                  child: Container(
                                    width: 11,
                                    height: 11,
                                    decoration: const BoxDecoration(
                                      color: Brand.green,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                )
                              : null,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          // Numaish maujooda zubaan mein; chunne
                          // par wapas ASAL canonical wajah jati
                          // hai (record ek jaisa rehta hai)।
                          child: Text(reasonOptionLabel(e.value),
                              style: const TextStyle(fontSize: 15)),
                        ),
                      ],
                    ),
                  ),
                );
              }),
              const SizedBox(height: 6),
              TextField(
                controller: textCtrl,
                maxLines: 2,
                decoration: InputDecoration(
                  labelText: tr('reason_own_words'),
                  hintText: tr('reason_own_hint'),
                  border: const OutlineInputBorder(),
                  isDense: true,
                ),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: selected < 0
                      ? null
                      : () {
                          final base = options[selected];
                          final extra = textCtrl.text.trim();
                          Navigator.pop(
                            sheetCtx,
                            extra.isEmpty ? base : '$base — $extra',
                          );
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Brand.deepGreen,
                    disabledBackgroundColor: Brand.lightBg,
                    disabledForegroundColor: Colors.black38,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    textStyle: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800),
                  ),
                  child: Text(
                      submitLabel.isEmpty ? tr('reason_submit') : submitLabel),
                ),
              ),
              // Lazmi-wajah wali haalat mein saaf "Wapas" —
              // is se sheet band hoti hai aur CANCEL NAHI
              // hota (wajah ke baghair cancel ka koi rasta
              // NAHI hai)।
              if (mustGiveReason)
                Center(
                  child: TextButton(
                    onPressed: () => Navigator.pop(sheetCtx),
                    child: Text(tr('reason_back_no_cancel')),
                  ),
                ),
            ],
          ),
        ),
      ),
    ),
  );
  textCtrl.dispose();
  return result;
}

/// Ek mukammal ride ki REPORT / Shikayat (v1.4.4): category +
/// apni baat → mojooda Master-messages raste se Master inbox
/// mein jata hai, ride ke poore hawale ke saath. Sawari aur
/// driver dono istemal kar sakte hain ([role]).
Future<void> showReportDialog(
  BuildContext context,
  AppStore store,
  Booking b, {
  required String role,
}) async {
  var category = kMessageCategories[2]; // 'Driver ki shikayat'
  if (role == 'driver') category = kMessageCategories[3];
  final textCtrl = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setD) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Report / Shikayat'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('${b.pickupLabel} → ${b.dropLabel}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 13.5)),
              Text(
                '${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)} · ${b.vehicle} · ${rs(b.total)}',
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(
                  labelText: 'Shikayat ki qism',
                  isDense: true,
                ),
                items: kMessageCategories
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) => setD(() => category = v ?? category),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: textCtrl,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Apni baat likhein',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Rehne Dein'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Report Bhejein'),
          ),
        ],
      ),
    ),
  );
  if (ok != true) {
    textCtrl.dispose();
    return;
  }
  final detail = textCtrl.text.trim();
  textCtrl.dispose();
  // v1.4.7 COMPLAINT SELFIE (spec §2): sawari ki report jis driver
  // ke khilaf hai us ki pehchan body mein machine-readable line
  // ('DriverId: ...') ke saath jati hai — driver ki app apni ID
  // dekh kar selfie demand pehchanti hai, aur Master inbox mein
  // bhi yehi line saboot ke saath rehti hai।
  final targetDriverId = role == 'passenger'
      ? (b.assignedDriverId.isNotEmpty
          ? b.assignedDriverId
          : (b.acceptedHere ? store.driverId : ''))
      : '';
  final reportMsg = MasterMessage(
    id: store.newId(),
    senderKey: role == 'driver' ? store.driverId : store.deviceId,
    senderRole: role,
    senderName:
        role == 'driver' ? store.profile.name : b.passengerName,
    senderMobile:
        role == 'driver' ? store.profile.phone : b.passengerPhone,
    senderZone: store.profile.zone,
    category: category,
    body: 'RIDE REPORT — Ride ID: ${b.id}\n'
        'Route: ${b.pickupLabel} → ${b.dropLabel} (${b.vehicle})\n'
        'Waqt: ${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)} · Kul kiraya ${rs(b.total)}\n'
        'Driver: ${b.driverName} · Sawari: ${b.passengerName}'
        '${targetDriverId.isEmpty ? '' : '\nDriverId: $targetDriverId'}'
        '${detail.isEmpty ? '' : '\nBaat: $detail'}',
    createdAt: DateTime.now(),
  );
  await store.addMasterMessage(reportMsg);
  if (targetDriverId.isNotEmpty) {
    // Demand ka backend record (driver_selfies, kind='complaint',
    // complaint_id = is report ki id) — driver ki app poll karke
    // gate lagati hai; driver ISI phone par ho to gate foran।
    unawaited(Backend.insertSelfieDemand(
      driverId: targetDriverId,
      date: AppStore.todayKey(),
      kind: 'complaint',
      complaintId: reportMsg.id,
    ));
    if (targetDriverId == store.driverId) {
      store.setSelfieDemand(SelfieDemand(
        kind: 'complaint',
        date: AppStore.todayKey(),
        complaintId: reportMsg.id,
      ));
    }
  }
  // Support auto-jawab (greeting/ack/shikayat ka tayyar jawab)।
  await SupportAuto.onUserMessage(store, reportMsg);
  if (context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Report Master ko bhej di gayi hai.')),
    );
  }
}

/// Driver ki SAWARI ko rating wali patti (v1.4.4) — mukammal ride
/// par driver 1–5 sitare de sakta hai. Rating ride ke apne record
/// par (Booking.passengerRating) rehti hai aur backend
/// rides.passenger_rating mein Master ko nazar ati hai. Pehle se
/// di ho to wohi sitare bharay nazar ate hain; dobara tap = update.
class PassengerRatingRow extends StatefulWidget {
  final AppStore store;
  final Booking booking;
  const PassengerRatingRow(
      {super.key, required this.store, required this.booking});

  @override
  State<PassengerRatingRow> createState() => _PassengerRatingRowState();
}

class _PassengerRatingRowState extends State<PassengerRatingRow> {
  AppStore get store => widget.store;
  Booking get b => widget.booking;

  @override
  Widget build(BuildContext context) {
    final stars = b.passengerRating;
    return Row(
      children: [
        const Text('Sawari ko rating: ',
            style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
        for (var i = 1; i <= 5; i++)
          InkWell(
            onTap: () async {
              await store.savePassengerRating(b, i);
              if (mounted) setState(() {});
            },
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: const EdgeInsets.all(2),
              child: Icon(
                i <= stars ? Icons.star : Icons.star_border,
                color: Brand.gold,
                size: 24,
              ),
            ),
          ),
        if (stars > 0)
          const Text(' darj hai',
              style: TextStyle(fontSize: 12, color: Colors.black54)),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Rating — passenger ki di gayi 1–5 sitare wali rating
// ---------------------------------------------------------------------------

/// Completed ride par rating wali patti: sitare tap karke chunna,
/// ikhtiyari comment, "Rating Bhejein". Rating pehle se di ho to
/// wohi sitare bharay nazar ate hain aur dobara bhejna usi record
/// ko update karta hai. Sirf passenger ke istemal ke liye.
class RatingRow extends StatefulWidget {
  final AppStore store;
  final Booking booking;
  const RatingRow({super.key, required this.store, required this.booking});

  @override
  State<RatingRow> createState() => _RatingRowState();
}

class _RatingRowState extends State<RatingRow> {
  int _stars = 0;
  bool _saving = false;
  final _commentCtrl = TextEditingController();

  AppStore get store => widget.store;
  Booking get b => widget.booking;

  @override
  void initState() {
    super.initState();
    final r = store.ratingFor(b.id);
    _stars = r?.stars ?? 0;
    _commentCtrl.text = r?.comment ?? '';
  }

  @override
  void dispose() {
    _commentCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_stars <= 0 || _saving) return;
    setState(() => _saving = true);
    await store.saveRating(RideRating(
      bookingId: b.id,
      // v1.4.2: rating ASAL driver ko jati hai — do-phone par woh
      // backend se aya assignedDriverId hai; same-device par wohi
      // is phone ka driverId hota hai.
      driverId: b.assignedDriverId.isNotEmpty
          ? b.assignedDriverId
          : store.driverId,
      driverName: b.driverName,
      passengerName: b.passengerName,
      stars: _stars,
      comment: _commentCtrl.text.trim(),
      createdAt: DateTime.now(),
    ));
    if (!mounted) return;
    setState(() => _saving = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Shukriya! Aap ki rating darj ho gayi.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final already = store.ratingFor(b.id) != null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Driver ko rating dein',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
        const SizedBox(height: 2),
        Row(
          children: [
            for (var i = 1; i <= 5; i++)
              IconButton(
                onPressed: () => setState(() => _stars = i),
                icon: Icon(
                  i <= _stars ? Icons.star : Icons.star_border,
                  color: Brand.gold,
                  size: 30,
                ),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 40, minHeight: 40),
                tooltip: '$i sitare',
              ),
            const Spacer(),
            if (already && !_saving)
              const Text('Rating di hui hai',
                  style: TextStyle(fontSize: 12, color: Colors.black54)),
          ],
        ),
        TextField(
          controller: _commentCtrl,
          decoration: const InputDecoration(
            labelText: 'Comment (ikhtiyari)',
            isDense: true,
          ),
          maxLines: 1,
        ),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: _stars <= 0 || _saving ? null : _save,
            child: Text(_saving
                ? 'Darj ho raha hai…'
                : already
                    ? 'Rating Update Karein'
                    : 'Rating Bhejein'),
          ),
        ),
      ],
    );
  }
}

// ===========================================================================
// SABOOT (EVIDENCE) RECORDING — owner 2026-11-08
//
// Gambhir haalat (badtamizi waghera) mein ACTIVE ride par driver
// aur sawari DONO ke liye ek hi mushtarka widget:
//  - 'Saboot Recording' button: dabane se audio recording shuru
//    (LAAL nishan + chalta timer screen par), dobara dabane se band.
//  - Microphone ki ijazat pehli dafa record package ke
//    hasPermission() se mangi jati hai (system dialog wahi hai);
//    inkar par Roman Urdu snack wajah ke saath — ijazat ke
//    baghair recording NAHI hoti.
//  - Band hone par file pehle ride ke LOCAL record mein mehfooz
//    (store.saveEvidenceLocal), phir backend Storage ke
//    driver-docs bucket mein upload (Backend.uploadEvidenceAudio
//    — path evidence/<ride_id>/<role>_<timestamp>.m4a) aur Master
//    ko messages se khabar (category 'Saboot Recording').
//    Upload fail ho to local file rehti hai aur app start par
//    Backend.syncEvidenceOutbox dobara koshish karta hai.
//  - Recording dobara sunna: EvidencePlayRow — audioplayers ka
//    APNA halka instance (GuideAudio wala player bilkul NAHI);
//    local file se, woh na ho to storage ke public URL se koshish.
//  - Recording DELETE karne ka koi button/flow yahan NAHI hai —
//    saboot kabhi delete nahi hota (jaaan boojh kar).
// ===========================================================================

class EvidenceRecorderButton extends StatefulWidget {
  final AppStore store;
  final Booking booking;

  /// 'driver' | 'passenger'
  final String role;

  /// Record karne wale ka naam (Master wali khabar ke liye).
  final String recorderName;
  const EvidenceRecorderButton({
    super.key,
    required this.store,
    required this.booking,
    required this.role,
    required this.recorderName,
  });

  @override
  State<EvidenceRecorderButton> createState() =>
      _EvidenceRecorderButtonState();
}

class _EvidenceRecorderButtonState extends State<EvidenceRecorderButton> {
  final AudioRecorder _recorder = AudioRecorder();
  bool _recording = false;
  bool _busy = false;
  int _elapsedSec = 0;
  Timer? _timer;
  String? _currentPath;

  AppStore get store => widget.store;
  Booking get b => widget.booking;

  @override
  void dispose() {
    _timer?.cancel();
    // Screen band ho jaye to recording latki na rahe — recorder
    // band (file discard NAHI hoti agar stop se mili ho; chalti
    // recording ka hissa recorder khud file mein rakhta hai).
    if (_recording) {
      unawaited(_recorder.stop());
    }
    unawaited(_recorder.dispose());
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  String get _elapsedText {
    final m = (_elapsedSec ~/ 60).toString().padLeft(2, '0');
    final s = (_elapsedSec % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Future<void> _toggle() async {
    if (_busy) return;
    if (_recording) {
      await _stopAndSave();
      return;
    }
    setState(() => _busy = true);
    try {
      // Microphone ki ijazat — pehli dafa system dialog yahin se
      // ata hai (record package ka hasPermission wohi mangta hai).
      var granted = false;
      try {
        granted = await _recorder.hasPermission();
      } catch (_) {
        granted = false;
      }
      if (!granted) {
        _snack(
            'Microphone ki ijazat nahi mili — saboot recording nahi ho sakti. Phone ki Settings mein Bozdar Safar ko microphone ki ijazat dein, phir dobara dabayein.');
        return;
      }
      final dir = await getApplicationDocumentsDirectory();
      final evDir = Directory('${dir.path}/evidence');
      if (!await evDir.exists()) {
        await evDir.create(recursive: true);
      }
      final ts = DateTime.now().millisecondsSinceEpoch;
      final path =
          '${evDir.path}/evidence_${b.id}_${widget.role}_$ts.m4a';
      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 64000,
          sampleRate: 44100,
          numChannels: 1,
        ),
        path: path,
      );
      _currentPath = path;
      _elapsedSec = 0;
      _timer?.cancel();
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() => _elapsedSec++);
      });
      if (mounted) setState(() => _recording = true);
    } catch (_) {
      _snack('Recording shuru nahi ho saki — dobara koshish karein.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _stopAndSave() async {
    setState(() => _busy = true);
    _timer?.cancel();
    String? path;
    try {
      path = await _recorder.stop();
    } catch (_) {
      path = null;
    }
    path ??= _currentPath;
    if (mounted) {
      setState(() {
        _recording = false;
        _busy = false;
      });
    }
    if (path == null || path.isEmpty) {
      _snack('Recording file nahi mili — saboot mehfooz nahi ho saka.');
      return;
    }
    // 1) Pehle LOCAL record — upload se pehle saboot mehfooz.
    await store.saveEvidenceLocal(b, path, widget.role);
    _snack('Saboot recording mehfooz ho gayi — Master ko bheji ja rahi hai…');
    // 2) Backend upload (driver-docs bucket).
    final remote =
        await Backend.uploadEvidenceAudio(b.id, widget.role, File(path));
    if (remote != null) {
      await store.markEvidenceUploaded(b, remote);
      await Backend.notifyMasterEvidence(store, b, remote);
      _snack('Saboot Master ko bhej diya gaya hai.');
      return;
    }
    // 3) Upload fail — Master ko phir bhi khabar (local rasta +
    //    "upload baqi" note ke saath); canonical file-wali khabar
    //    dobara koshish kamyab hone par jayegi
    //    (Backend.syncEvidenceOutbox — evidenceMasterNotified
    //    flag yahan NAHI lagate, warna woh khabar kabhi na jati).
    try {
      final isDriver = widget.role == 'driver';
      await store.addMasterMessage(MasterMessage(
        id: store.newId(),
        senderKey: isDriver ? store.driverId : store.deviceId,
        senderRole: widget.role,
        senderName: widget.recorderName,
        senderMobile:
            isDriver ? store.profile.phone : b.passengerPhone,
        senderZone: isDriver ? store.profile.zone : '',
        category: 'Saboot Recording',
        body: 'Saboot recording aayi hai — Ride: ${b.pickupLabel} → '
            '${b.dropLabel}, record karne wala: '
            '${isDriver ? 'Driver' : 'Passenger'} ${widget.recorderName}, '
            'file abhi phone mein hai (upload baqi hai, dobara koshish '
            'khud hogi) — local: $path',
        createdAt: DateTime.now(),
      ));
    } catch (_) {
      // Khabar na bhi jaye to saboot local record mein hai.
    }
    _snack(
        'Upload nahi ho saka — recording is phone mein mehfooz hai, internet ate hi dobara koshish hogi.');
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final hasEvidence =
        b.evidenceLocalPath.isNotEmpty || b.evidenceRemotePath.isNotEmpty;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (_recording) ...[
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: const Color(0xFFFDECEA),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Brand.ajrakRed, width: 1.4),
            ),
            child: Row(
              children: [
                const Icon(Icons.fiber_manual_record,
                    color: Colors.red, size: 18),
                const SizedBox(width: 8),
                const Text('RECORDING HO RAHI HAI',
                    style: TextStyle(
                        color: Brand.ajrakRed,
                        fontWeight: FontWeight.w900,
                        fontSize: 13)),
                const Spacer(),
                Text(_elapsedText,
                    style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        color: Brand.ajrakRed)),
              ],
            ),
          ),
          const SizedBox(height: 8),
        ],
        SizedBox(
          width: double.infinity,
          child: _recording
              ? ElevatedButton.icon(
                  onPressed: _busy ? null : _toggle,
                  icon: const Icon(Icons.stop),
                  label: const Text('Recording Band Karein'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Brand.ajrakRed,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                )
              : OutlinedButton.icon(
                  onPressed: _busy ? null : _toggle,
                  icon: const Icon(Icons.mic, color: Brand.ajrakRed),
                  label: Text(
                      _busy
                          ? 'Saboot…'
                          : hasEvidence
                              ? 'Saboot Recording (aur record karein)'
                              : 'Saboot Recording',
                      style: const TextStyle(color: Brand.ajrakRed)),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(
                        color: Brand.ajrakRed, width: 1.3),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
        ),
        if (hasEvidence && !_recording) ...[
          const SizedBox(height: 6),
          EvidencePlayRow(store: store, booking: b),
        ],
      ],
    );
  }
}

/// Saboot recording dobara sunna — audioplayers ka APNA halka
/// instance (GuideAudio se bilkul alag) taaki rehnumai wali
/// awaazein aur saboot ek doosre ko na rokein. Pehle LOCAL file;
/// woh is phone par na ho (doosra phone / file gayab) to storage
/// ke public URL se koshish — bucket public na ho to saaf snack.
/// Delete ka koi option NAHI hai.
class EvidencePlayRow extends StatefulWidget {
  final AppStore store;
  final Booking booking;
  const EvidencePlayRow(
      {super.key, required this.store, required this.booking});

  @override
  State<EvidencePlayRow> createState() => _EvidencePlayRowState();
}

class _EvidencePlayRowState extends State<EvidencePlayRow> {
  final AudioPlayer _player = AudioPlayer();
  bool _playing = false;
  bool _busy = false;
  StreamSubscription<PlayerState>? _sub;

  Booking get b => widget.booking;

  @override
  void initState() {
    super.initState();
    _sub = _player.onPlayerStateChanged.listen((s) {
      if (mounted) {
        setState(() => _playing = s == PlayerState.playing);
      }
    });
  }

  @override
  void dispose() {
    unawaited(_sub?.cancel());
    unawaited(_player.dispose());
    super.dispose();
  }

  Future<void> _togglePlay() async {
    if (_busy) return;
    if (_playing) {
      await _player.pause();
      return;
    }
    setState(() => _busy = true);
    try {
      final local = b.evidenceLocalPath;
      if (local.isNotEmpty && await File(local).exists()) {
        await _player.play(DeviceFileSource(local));
      } else if (b.evidenceRemotePath.isNotEmpty) {
        await _player
            .play(UrlSource(Backend.evidencePublicUrl(b.evidenceRemotePath)));
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('Recording file is phone par nahi mili.')));
        }
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content:
                Text('Recording nahi chal saki — file Master ke paas mehfooz hai.')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFFDECEA),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: _busy ? null : _togglePlay,
            icon: Icon(_playing ? Icons.pause_circle : Icons.play_circle,
                color: Brand.ajrakRed, size: 30),
            tooltip: _playing ? 'Rokein' : 'Saboot recording sunein',
          ),
          const SizedBox(width: 4),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Saboot Recording',
                    style: TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 13)),
                Text(
                  b.evidenceRemotePath.isNotEmpty
                      ? 'Master ko bheji ja chuki hai — sunne ke liye play dabayein'
                      : 'Abhi is phone mein hai — upload baqi hai',
                  style: const TextStyle(
                      fontSize: 11.5, color: Colors.black54),
                ),
              ],
            ),
          ),
          const Icon(Icons.lock_outline, size: 15, color: Colors.black38),
        ],
      ),
    );
  }
}
