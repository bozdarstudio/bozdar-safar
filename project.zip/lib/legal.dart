import 'dart:async';
import 'package:flutter/material.dart';
import 'agent_section.dart';
import 'backend.dart';
import 'lang.dart';
import 'otp.dart';
import 'profile_photo.dart';
import 'store.dart';
import 'theme.dart';

// ===========================================================================
// v1.4.4 — LEGAL + SAFETY: Sharait (Terms) + Privacy Policy
//
// Malik ka hukm (2026-11-08): app ke andar saari qanooni sharait
// lazmi hain taaki baad mein koi phans na sakay. Saara mutan seedhi
// saada Roman Urdu mein hai taaki har sawari/driver ko samajh aye.
//
//  - [TermsPage] / [PrivacyPage]: parhne wale pages — Driver
//    Profile se bhi khulte hain, sawari ki Profile se bhi, aur
//    registration ke aakhri qadam se bhi ("Sharait dobara parhein").
//  - [TermsGateScreen]: pehli dafa app khulne par lazmi — baghair
//    "Mein ne parh liya, qabool hai" dabaye app aage NAHI barhti;
//    qubooliyat ka waqt mehfooz ho jata hai (store.termsAcceptedAtMs;
//    driver ki apni qubooliyat registration mein alag se
//    drivers.terms_accepted_at mein bhi jati hai — migration v134).
// ===========================================================================

class LegalSection {
  final String title;
  final List<String> lines;
  const LegalSection(this.title, this.lines);
}

const List<LegalSection> kTermsSawari = [
  LegalSection('Sawari (Passenger) ki Sharait', [
    'M.R Safar sirf ek technology platform hai — ye aap ko qareebi tasdeeq-shuda driver se jorta hai. Gaari aur safar ki asal zimmedari driver ki hai.',
    'Kiraya hamesha CASH mein seedha driver ko ada hota hai. App ke andar koi paisa nahi rukta aur na hi koi advance liya jata hai.',
    'Ride pakki hone se PEHLE aap ko kiraya nahi dikhaya jata — kul kiraya booking pakki hote hi nazar ata hai, aur wohi tay-shuda kiraya hai (koi mol-bhav nahi).',
    'Apna qeemti samaan (mobile, paisa, zewar, documents) aap ki apni zimmedari hai. Gaari mein reh jane wali cheez ki ittela foran Master ko message karke dein — hum driver se rabta karke poori koshish karenge, lekin samaan ki zimmedari company par nahi hoti.',
    'Driver ke pohanchnay ke baad pehle chand minute intezaar muft hai; us se zyada intezaar par munasib waiting charges kul kiraye mein shamil ho jate hain (hisaab booking par saaf likha hota hai).',
  ]),
  LegalSection('Ride Cancel karne ki Policy', [
    'Aap ride kabhi bhi cancel kar sakte hain — cancel par app aap se WAJAH poochhegi. Ye wajah ride ke record ke saath mehfooz rehti hai taaki koi galat-fehmi ya jhooti shikayat ho to asal baat sab ke saamne ho.',
    'Agar aap beech raaste mein rukwa kar ride waheen khatam (complete) kar dein, to bhi app wajah poochhegi — aur woh wajah bhi record mein mehfooz rahegi.',
    'Driver ke pohanchnay se pehle cancel karna bilkul muft hai. Driver pohanch jaye aur dair tak intezaar karna pare to waiting charges lag sakte hain.',
    'Baar baar bila-wajah cancel karne par Master aap se rabta kar sakta hai, aur ghalat istemal par app ka istemal roka ja sakta hai.',
    'Ride ke doran koi masla ho to SOS button dabayein — woh aap ko 1122 se jorta hai aur Master ko bhi khabar bhejta hai.',
    'APP SE BAHIR SAFAR (v1.4.20): Agar driver aap ko kahe ke ride cancel karke seedha us ke saath chalein, to cancel ke baad woh safar M.R Safar ke record se BAHIR ho jayega — us safar mein hifazat, kiraye ya kisi bhi masle ki zimmedari M.R Safar ki NAHI hogi, woh aap ki apni hogi. Mahfooz safar ke liye ride hamesha app ke andar mukammal karein.',
  ]),
];

const List<LegalSection> kTermsDriver = [
  LegalSection('Driver ki Sharait', [
    'Aap ki gaari ka INSURANCE aur REGISTRATION (kaghaz) har waqt VALID rakhna AAP KI APNI zimmedari hai. Kaghaz khatam ya jaali hon to ID band ho sakti hai aur kisi nuqsan ki zimmedari bhi aap par hogi.',
    'Traffic ke tamam qanoon ki pabandi lazmi hai — speed, signal, seat belt/helmet aur sawari ki hifazat sab se pehle hai.',
    'Khuda na khasta HADSA ho jaye to SAB SE PEHLE 1122 par call karke madad bulayein, phir foran Master ko message karke ittila dein.',
    'M.R Safar sirf ek TECHNOLOGY PLATFORM hai — driver company ka MULAZIM NAHI hai. Har driver apni gaari, apne waqt aur apni kamai ka khud zimmedar hai.',
    'Ride qubool karne ke baad sawari ko waqt par lena, aaram se aur hifazat se manzil tak pohanchana aap ki zimmedari hai. Sawari se badtameezi, zyada kiraya mangna ya tay-shuda kiraye se inkaar sakht mana hai.',
    'Rozana duty se pehle LIVE SELFIE lazmi hai. Account sirf EK hi device par chalega — device badalna ho to pehle Master ko message karke batayein, warna ID khud-ba-khud chand ghante block ho jati hai.',
    'Ek CNIC par sirf EK driver account banta hai. Mobile number badalne par ID 12 ghante ke liye khud-ba-khud block ho jati hai.',
    'APP SE BAHIR RIDE SAKHT MANA HAI (v1.4.20): Sawari ko ride cancel karwa kar app se BAHIR le jana sakht mana hai. Aisa karne par ID BLOCK kar di jayegi.',
  ]),
  LegalSection('Service Fee aur Hisaab', [
    'Har mukammal ride par 10% SERVICE FEE banti hai. Ye fee driver ke AMANAT DEPOSIT balance se khud-ba-khud kat jati hai (neeche wali Amanat Deposit ki shartein parhein) — alag se koi fee talab NAHI ki jati.',
    'Hisaab system ke record mein rehta hai — har ride ki fee backend mein khud darj hoti hai. Jama aur wasool ki ginti SIRF Master ke record se hoti hai; driver khud app mein koi jama ya payment darj NAHI kar sakta.',
    'Apni kamai, deposit jama, kati hui fees, baqi balance aur tamam rides ka poora record aap ki app (Wallet) aur Master ke paas mehfooz rehta hai — kisi jhagray ki surat mein yehi record saboot hota hai.',
  ]),
  // AMANAT DEPOSIT (v1.4.21 — malik ka faisla 2026-11-10 20:05):
  // owner ki shartein SAAF-SAAF, usi ke matlab par — ye raqam
  // sirf driver ki AMANAT hai; sirf fees kategi; fees ke ilawa
  // ek rupee bhi idhar udhar NAHI ho sakta; baqi har waqt
  // driver ki apni hai aur chhorne par poori wapas milegi।
  LegalSection('Amanat Deposit — Aap ki Raqam, Sirf Aap ki Amanat', [
    'Duty shuru karne se pehle har driver Rs 500 ka AMANAT DEPOSIT jama karta hai — apne Easypaisa, JazzCash ya bank account se company ke bank account (BankIslami) mein bank transfer (IBAN) ke zariye; asal IBAN app ke Deposit wale hisse mein milta hai. Driver ke apne account ya number se company ka koi talluk NAHI hai aur woh number kahin darj NAHI hota. Jama ki entry SIRF Master karta hai, aur sirf tab jab raqam asal mein wasool ho jaye; driver khud app mein koi jama darj NAHI kar sakta.',
    'Ye raqam sirf aur sirf DRIVER ki apni AMANAT hai — ye M.R Safar ki KAMAI NAHI hai aur na hi company ki milkiyat hai.',
    'Is amanat mein se SIRF driver ki apni mukammal rides ki 10% service fees kategi — har ride ki fee us ride ke record ke saath khud hisaab ho jati hai.',
    'Fees ke ilawa M.R Safar driver ki is raqam se EK RUPEE bhi idhar udhar NAHI kar sakta. Is raqam par hamara koi aur lena dena NAHI hai — na koi aur katauti, na koi aur charge.',
    'Baqi raqam har waqt driver ki apni hai — jaise woh apni raqam nikaal sakta hai; kaam chhorne par us ki baqi poori raqam usay WAPAS milegi.',
    'Poora hisaab — kitna jama hua, kitni fees kati, kitna baqi hai — app mein har waqt driver ko saaf nazar ayega (Wallet — "Mera Deposit (Amanat)"), aur wohi hisaab Master ke paas bhi mehfooz rahega.',
    'Deposit balance khatam (zero ya us se kam) ho jaye to online honay aur nayi ride qubool karne ke liye pehle Rs 500 ka top-up lazmi hai — wasool honay par Master ke darj karte hi balance barh jata hai.',
  ]),
];

const List<LegalSection> kPrivacySections = [
  LegalSection('Hum kya data jama karte hain — aur kyun', [
    'Sawari ka naam aur mobile number — sirf ride ki pehchan aur rabte ke liye.',
    'Driver ka naam, mobile, CNIC, gaari ki tafseel aur documents ki tasaveer — sirf Tasdeeq (verification) ke liye, taaki sawari ko mehfooz aur asal driver mile.',
    'Ride ki tafseel (kahan se kahan, waqt, kiraya) aur driver ki duty ke doran ki location — sirf ride chalane, hisaab rakhne aur hifazat ke liye.',
    'Driver ki rozana live selfie — sirf ye pakka karne ke liye ke account asal driver hi chala raha hai.',
  ]),
  LegalSection('Ride ke records — mehfooz archive', [
    'Har ride ka record (waqt, jagahen, kiraya, cancel ya beech raaste mein khatam karne ki wajah, ratings) SAFETY ke liye mehfooz archive mein ek muddat — 3 SAAL — tak rehta hai.',
    'Isi liye ACCOUNT DELETE karne se aap ki PEHCHAN (naam, number, email aur login) phone aur server — dono se khatam ho jati hai, lekin ride ke HISAAB wale records (waqt, kiraya, jagahen) baghair naam/number ke mehfooz rehte hain. Agar kal koi jhooti shikayat ya jhagra ho to yehi record asal baat saaf karta hai — ye aap ki aur driver, dono ki hifazat hai.',
  ]),
  LegalSection('Aap ka data kisko dikhta hai', [
    'Aap ka data sirf MASTER (M.R Safar ke malik) ko dikhta hai — wahi Tasdeeq, hisaab aur shikayat ke liye use dekhta hai.',
    'Aap ka data kisi teesre shakhs ya company ko NAHI becha jata aur na hi kisi advertisement ke liye istemal hota hai.',
    'Qanoon ki taraf se lazmi talab ho (masalan police ki tehqeeqat) to record mutaliqa idare ko diya ja sakta hai.',
    'Apna account delete karne ka ikhtiyar aap ke paas hamesha hai — Profile mein "Account Delete Karein" se. Delete se pehle aap ki Gmail par OTP code bhej kar dobara tasdeeq hoti hai — tasdeeq ke baghair account delete NAHI hota. Delete ke baad naam/number dobara darj kiye baghair nayi booking nahi ho sakti.',
  ]),
];

// ===========================================================================
// v1.4.34 (P-2) — ENGLISH legal text: upar wali Roman Urdu lists
// ASAL aur default hain (zara bhi tabdeel nahi). English mode mein
// neeche wali parallel lists istemal hoti hain — mutan wohi hai,
// sirf zubaan badli hai. Getter functions maujooda zubaan ke
// mutabiq sahi list dete hain.
// ===========================================================================

const List<LegalSection> kTermsSawariEn = [
  LegalSection('Passenger Terms', [
    'M.R Safar is only a technology platform — it connects you with a nearby verified driver. The vehicle and the journey are the driver\'s own responsibility.',
    'The fare is always paid in CASH directly to the driver. No money is held inside the app and no advance is taken.',
    'You are NOT shown the fare BEFORE the ride is confirmed — the total fare appears as soon as the booking is confirmed, and that is the fixed fare (there is no bargaining).',
    'Your valuable belongings (mobile, money, jewellery, documents) are your own responsibility. If something is left in the vehicle, inform Master by message at once — we will contact the driver and try our best, but the company is not responsible for belongings.',
    'The first few minutes of waiting after the driver arrives are free; for waiting longer than that, reasonable waiting charges are included in the total fare (the calculation is written clearly on the booking).',
  ]),
  LegalSection('Ride Cancellation Policy', [
    'You may cancel a ride at any time — on cancelling, the app will ask you for a REASON. That reason is saved with the ride record so that if there is any misunderstanding or false complaint, the real facts are in front of everyone.',
    'If you stop midway and end (complete) the ride there, the app will still ask for a reason — and that reason is also saved in the record.',
    'Cancelling before the driver arrives is completely free. If the driver has arrived and has to wait a long time, waiting charges may apply.',
    'On repeated cancellations without reason, Master may contact you, and on misuse, use of the app may be stopped.',
    'If there is any problem during the ride, press the SOS button — it connects you to 1122 and also sends news to Master.',
    'TRAVEL OUTSIDE THE APP (v1.4.20): If a driver tells you to cancel the ride and travel directly with him, then after the cancellation that journey will be OUTSIDE M.R Safar\'s record — in that journey, M.R Safar will NOT be responsible for safety, fare or any problem; it will be your own. For a safe journey, always complete the ride inside the app.',
  ]),
];

const List<LegalSection> kTermsDriverEn = [
  LegalSection('Driver Terms', [
    'Keeping your vehicle\'s INSURANCE and REGISTRATION (papers) VALID at all times is YOUR OWN responsibility. If the papers are expired or fake, the ID may be closed and the responsibility for any loss will also be on you.',
    'Following all traffic laws is compulsory — speed, signals, seat belt/helmet and the passenger\'s safety come first.',
    'God forbid, if an ACCIDENT happens, FIRST call 1122 and call for help, then inform Master by message at once.',
    'M.R Safar is only a TECHNOLOGY PLATFORM — the driver is NOT an employee of the company. Every driver is himself responsible for his vehicle, his time and his earnings.',
    'After accepting a ride, taking the passenger on time and reaching the destination comfortably and safely is your responsibility. Misbehaving with the passenger, demanding extra fare or refusing the fixed fare is strictly forbidden.',
    'A LIVE SELFIE before duty every day is compulsory. The account will run on only ONE device — if you want to change the device, first inform Master by message, otherwise the ID blocks itself for a few hours.',
    'Only ONE driver account is made on one CNIC. On changing the mobile number, the ID blocks itself for 12 hours.',
    'RIDES OUTSIDE THE APP ARE STRICTLY FORBIDDEN (v1.4.20): Getting the passenger to cancel the ride and taking him outside the app is strictly forbidden. On doing so, the ID will be BLOCKED.',
  ]),
  LegalSection('Service Fee and Accounts', [
    'A 10% SERVICE FEE is made on every completed ride. This fee is deducted automatically from the driver\'s AMANAT DEPOSIT balance (read the Amanat Deposit terms below) — no separate fee is demanded.',
    'The account stays in the system record — every ride\'s fee is recorded in the backend itself. Deposits and receipts are counted ONLY from Master\'s record; the driver cannot enter any deposit or payment in the app himself.',
    'Your earnings, deposit paid in, fees deducted, remaining balance and the full record of all rides stay safe in your app (Wallet) and with Master — in case of any dispute, this record is the evidence.',
  ]),
  LegalSection('Amanat Deposit — Your Money, Only Your Trust', [
    'Before starting duty, every driver deposits an AMANAT DEPOSIT of Rs 500 — from his own Easypaisa, JazzCash or bank account by bank transfer (IBAN) to the company bank account (BankIslami); the actual IBAN is shown in the app\'s Deposit section. The company has no connection with the driver\'s own account or number, and that number is not recorded anywhere. The deposit entry is made ONLY by Master, and only when the money has actually been received; the driver cannot enter any deposit in the app himself.',
    'This money is only and only the DRIVER\'s own AMANAT (trust) — it is NOT M.R Safar\'s EARNINGS and not the company\'s property.',
    'From this amanat, ONLY the 10% service fees of the driver\'s own completed rides are deducted — every ride\'s fee is accounted by itself with that ride\'s record.',
    'Apart from fees, M.R Safar CANNOT move even ONE RUPEE of the driver from this money here or there. We have no other dealing on this money — no other deduction, no other charge.',
    'The remaining money is the driver\'s own at all times — just as he can take his money out; on leaving the work, his full remaining money will be RETURNED to him.',
    'The full account — how much was deposited, how much fee was deducted, how much is remaining — will be clearly visible to the driver in the app at all times (Wallet — "My Deposit (Amanat)"), and the same account will also stay safe with Master.',
    'If the deposit balance ends (zero or less), then to go online and accept a new ride, a top-up of Rs 500 is required first — on receipt, as soon as Master enters it, the balance increases.',
  ]),
];

const List<LegalSection> kPrivacySectionsEn = [
  LegalSection('What data we collect — and why', [
    'The passenger\'s name and mobile number — only for the ride\'s identification and contact.',
    'The driver\'s name, mobile, CNIC, vehicle details and document photos — only for Verification, so that the passenger gets a safe and genuine driver.',
    'Ride details (from where to where, time, fare) and the driver\'s location during duty — only for running the ride, keeping accounts and safety.',
    'The driver\'s daily live selfie — only to make sure the account is being run by the genuine driver himself.',
  ]),
  LegalSection('Ride records — safe archive', [
    'Every ride\'s record (time, places, fare, the reason for cancelling or ending midway, ratings) stays in a safe archive for a period — 3 YEARS — for SAFETY.',
    'That is why, on ACCOUNT DELETE, your IDENTITY (name, number, email and login) is removed from both the phone and the server, but the ACCOUNT records of rides (time, fare, places) stay saved without name/number. If tomorrow there is a false complaint or dispute, this record makes the real facts clear — it is the safety of both you and the driver.',
  ]),
  LegalSection('Who can see your data', [
    'Your data is visible only to MASTER (the owner of M.R Safar) — he sees it for Verification, accounts and complaints.',
    'Your data is NOT sold to any third person or company and is not used for any advertisement.',
    'If law requires it (for example a police investigation), the record may be given to the relevant institution.',
    'You always have the right to delete your account — from "Delete Account" in Profile. Before deleting, re-verification is done by sending an OTP code to your Gmail — without verification the account is NOT deleted. After deleting, a new booking cannot be made without entering the name/number again.',
  ]),
];

/// v1.4.34 (P-2): maujooda zubaan ke mutabiq Sharait/Privacy lists।
List<LegalSection> legalTermsSawari() =>
    Lang.isEn ? kTermsSawariEn : kTermsSawari;
List<LegalSection> legalTermsDriver() =>
    Lang.isEn ? kTermsDriverEn : kTermsDriver;
List<LegalSection> legalPrivacy() =>
    Lang.isEn ? kPrivacySectionsEn : kPrivacySections;

Widget _sectionsView(List<LegalSection> sections) {
  return ListView(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
    children: [
      for (final s in sections) ...[
        Text(s.title,
            style: const TextStyle(
                fontSize: 16.5,
                fontWeight: FontWeight.w900,
                color: Brand.greenDark)),
        const SizedBox(height: 8),
        for (final line in s.lines) ...[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.only(top: 7),
                child: Icon(Icons.circle, size: 6, color: Brand.green),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(line,
                    style: const TextStyle(fontSize: 13.5, height: 1.45)),
              ),
            ],
          ),
          const SizedBox(height: 8),
        ],
        const SizedBox(height: 14),
      ],
    ],
  );
}

/// Sharait (Terms) ka page. 20:40 TARMIM (malik ka hukm
/// 2026-11-10): har cheez apni jagah — default mein SIRF
/// Sawari ki sharait; Driver ki sharait (Service Fee, Amanat
/// Deposit, top-up) sirf driver wale hisse se khulti hain
/// ([showDriverTerms] = true — driver registration aur driver
/// Profile se). Sawari ki screens par deposit/fees/top-up ka
/// koi zikr NAHI ata.
class TermsPage extends StatelessWidget {
  final bool showDriverTerms;
  const TermsPage({super.key, this.showDriverTerms = false});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('legal_terms_title'))),
      body: _sectionsView(showDriverTerms
          ? [...legalTermsSawari(), ...legalTermsDriver()]
          : legalTermsSawari()),
    );
  }
}

/// Privacy Policy ka page.
class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Privacy Policy')),
      body: _sectionsView(legalPrivacy()),
    );
  }
}

/// Pehli dafa app khulne par LAZMI wala darwaza: Sharait parh kar
/// "Mein ne parh liya, qabool hai" dabaye baghair aage nahi barha
/// ja sakta. Qabool karne ka waqt store mein mehfooz ho jata hai.
class TermsGateScreen extends StatelessWidget {
  final AppStore store;
  const TermsGateScreen({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 18, 16, 4),
              child: Text(tr('legal_gate_title'),
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: Brand.greenDark)),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Text(
                tr('legal_gate_intro'),
                style: const TextStyle(fontSize: 13, color: Colors.black54),
              ),
            ),
            // 20:40 TARMIM: ye darwaza har user (sawari samait)
            // ke saamne ata hai — is liye yahan SIRF Sawari ki
            // sharait. Driver ki sharait (fees/deposit/top-up)
            // driver registration mein alag di aur qabool
            // karwayi jati hain.
            Expanded(child: _sectionsView(legalTermsSawari())),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => store.acceptTerms(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Brand.deepGreen,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    textStyle: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w900),
                  ),
                  child: Text(tr('legal_gate_accept')),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: TextButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const PrivacyPage()),
                ),
                child: Text(tr('legal_gate_privacy')),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Profile pages mein lagne wali mushtarka patti: Sharait +
/// Privacy ke darwaze aur (agar darj ho) qubooliyat ka waqt.
class LegalLinksCard extends StatelessWidget {
  final AppStore store;

  /// Driver ki apni qubooliyat ka waqt (registration wali) —
  /// driver Profile se ata hai; sawari ke liye null.
  final int? driverAcceptedAtMs;

  /// 20:40 TARMIM: true sirf driver wale hisse (driver Profile)
  /// se — tab Sharait mein Driver ki sharait (fees/deposit/
  /// top-up) bhi khulti hain. Sawari ki Profile se false —
  /// wahan sirf Sawari ki sharait.
  final bool showDriverTerms;
  const LegalLinksCard(
      {super.key,
      required this.store,
      this.driverAcceptedAtMs,
      this.showDriverTerms = false});

  @override
  Widget build(BuildContext context) {
    final acceptedMs =
        driverAcceptedAtMs ?? store.termsAcceptedAtMs;
    return Card(
      child: Column(
        children: [
          ListTile(
            leading: const Icon(Icons.description, color: Brand.green),
            title: Text(tr('legal_terms_title'),
                style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(showDriverTerms
                ? tr('legal_sub_both')
                : tr('legal_sub_passenger')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                  builder: (_) => TermsPage(showDriverTerms: showDriverTerms)),
            ),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.privacy_tip, color: Brand.green),
            title: const Text('Privacy Policy',
                style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(tr('legal_privacy_sub')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const PrivacyPage()),
            ),
          ),
          if (acceptedMs > 0) ...[
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 9, 16, 11),
              child: Row(
                children: [
                  const Icon(Icons.verified, size: 16, color: Brand.green),
                  const SizedBox(width: 7),
                  Expanded(
                    child: Text(
                      trf('legal_accepted', {
                        'date': fmtDate(
                            DateTime.fromMillisecondsSinceEpoch(acceptedMs)),
                        'time': fmtTime(
                            DateTime.fromMillisecondsSinceEpoch(acceptedMs))
                      }),
                      style: const TextStyle(
                          fontSize: 12.5, color: Colors.black54),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// Sawari ki Profile screen (v1.4.4) — naam/number ki haalat,
/// Sharait/Privacy ke darwaze, aur ACCOUNT DELETE (profile saaf;
/// ride ke records Privacy Policy ke mutabiq mehfooz rahte hain).
/// v1.4.5 (B4): Profile ka asal body — alag screen mein bhi aur
/// passenger bottom-nav ke Profile tab mein bhi yehi chalta hai.
/// [onAfterDelete]: account delete ke baad kya ho (screen par
/// pop; tab mein kuch nahi — list wahin taaza ho jati hai).
class PassengerProfileBody extends StatelessWidget {
  final AppStore store;
  final VoidCallback? onAfterDelete;
  const PassengerProfileBody(
      {super.key, required this.store, this.onAfterDelete});

  /// ACCOUNT DELETE ka poora flow (v1.4.16 — asal mukammal
  /// deletion):
  ///   0) Gmail pehle se verify shuda hona lazmi hai — warna
  ///      pehle isi Profile ki Email wali card se verify karwaya
  ///      jata hai (baghair pehchan ki tasdeeq ke koi account
  ///      delete nahi kar sakta)।
  ///   1) Tasdeeqi dialog (asal behavior ki wazahat)।
  ///   2) OTP se DOBARA tasdeeq — OtpGatePage (maujooda pattern):
  ///      code usi verify-shuda Gmail par jata hai।
  ///   3) Server RPC `delete_my_account` — pehchan server par
  ///      anonymize + identity link khatam. RPC fail ho to
  ///      flow YAHEEN ruk jata hai: saaf error, local data ko
  ///      haath NAHI lagta — deletion kabhi adhura nahi rehta।
  ///   4) Master ko khabar (purani behhavior — naam/number
  ///      local se, taaki Master ko pata ho kis ne delete kiya)।
  ///   5) Local wipe (deletePassengerProfile) — sab se aakhir।
  Future<void> _deleteAccount(BuildContext context) async {
    final email = store.passengerEmail.trim().toLowerCase();
    if (email.isEmpty || !store.passengerEmailVerified) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: Text(tr('legal_del_verify_first_title')),
          content: Text(
            tr('legal_del_verify_first_body'),
            style: const TextStyle(fontSize: 13.5, height: 1.45),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(tr('legal_ok')),
            ),
          ],
        ),
      );
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text(tr('legal_del_title')),
        content: Text(
          tr('legal_del_body'),
          style: const TextStyle(fontSize: 13.5, height: 1.45),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('legal_del_cancel')),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Brand.ajrakRed),
            child: Text(tr('legal_del_next')),
          ),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    // Qadam 2: OTP se dobara tasdeeq (maujooda OtpGate pattern)।
    final verified = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => OtpGatePage(
          email: email,
          title: tr('legal_del_otp_title'),
        ),
      ),
    );
    if (verified != true || !context.mounted) return;
    // Qadam 3: server par asal deletion (RPC)। Fail = rukawat,
    // saaf error — local data bilkul nahi chhoota jata।
    final done = await Backend.deletePassengerAccountRemote(email);
    if (!context.mounted) return;
    if (!done) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(tr('legal_del_server_fail')),
        ),
      );
      return;
    }
    // Qadam 4: Master ko khabar (naam/number local se — RPC ke
    // baad, wipe se pehle; message queued bhi rahe to agli sync
    // par chala jayega)।
    final name = store.passengerName.trim();
    final phone = store.passengerPhone.trim();
    await store.addMasterMessage(MasterMessage(
      id: store.newId(),
      senderKey: store.deviceId,
      senderRole: 'passenger',
      senderName: name,
      senderMobile: phone,
      senderZone: '',
      category: 'Deegar',
      body: 'ACCOUNT DELETE: Sawari ${name.isEmpty ? '(naam darj nahi tha)' : name}'
          '${phone.isEmpty ? '' : ' ($phone)'} ne OTP tasdeeq ke baad apna account delete kar diya hai. '
          'Server par us ki pehchan (naam/number/email) anonymize ho gayi hai aur login band ho gaya hai; '
          'rides ka hisaab baghair pehchan ke mehfooz archive mein rahega.',
      createdAt: DateTime.now(),
    ));
    // Qadam 5: local wipe — sab se aakhir, sirf server kamyabi par।
    await store.deletePassengerProfile();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(tr('legal_del_done'))),
    );
    onAfterDelete?.call();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          return ListView(
            padding: const EdgeInsets.all(14),
            children: [
              // Board style sir-khata (brief §6): goal sabz avatar
              // (naam ka pehla harf — passenger ki photo ka koi
              // feature hai hi nahi, jaali photo NAHI), naam +
              // mobile. Verified pill passenger par NAHI lagti
              // (us ke liye koi tasdeeq system hai hi nahi).
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Brand.green, Brand.deepGreen],
                  ),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Brand.gold, width: 1.6),
                ),
                child: Row(
                  children: [
                    InitialAvatar(name: store.passengerName),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            store.passengerName.isEmpty
                                ? tr('legal_greeting')
                                : store.passengerName,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w900),
                          ),
                          Text(
                            store.passengerPhone.isEmpty
                                ? tr('legal_name_hint')
                                : store.passengerPhone,
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 12.5),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.person, color: Brand.green),
                          const SizedBox(width: 9),
                          Text(tr('legal_my_info'),
                              style: const TextStyle(
                                  fontWeight: FontWeight.w900, fontSize: 15)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      _row(tr('legal_row_name'),
                          store.passengerName.isEmpty ? '—' : store.passengerName),
                      _row(tr('legal_row_mobile'),
                          store.passengerPhone.isEmpty ? '—' : store.passengerPhone),
                      const SizedBox(height: 4),
                      Text(
                        tr('legal_info_note'),
                        style: const TextStyle(
                            fontSize: 12, color: Colors.black54),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              // v1.4.22 MERI PHOTO (malik ka hukm 2026-11-10
              // 23:36): sawari bhi apni profile photo laga/badla
              // sakti hai — kul 3 dafa ki hadd, baqi moqay likhe
              // hue, hadd par sada likha notice।
              ProfilePhotoCard(store: store, forDriver: false),
              const SizedBox(height: 10),
              // v1.4.7: Gmail + OTP card (spec §1) + no-show
              // warnings ki haalat (spec §5) + Logout।
              _PassengerEmailCard(store: store),
              const SizedBox(height: 10),
              // AGENT HISA (v1.4.6): is mobile ka ACTIVE agent ho
              // to "Mera Agent Hisa" card yahin khulta hai — na ho
              // to widget khud ghayab rehta hai (SizedBox.shrink).
              AgentSection(store: store),
              const SizedBox(height: 10),
              LegalLinksCard(store: store),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.delete_forever,
                      color: Brand.ajrakRed),
                  title: Text(tr('legal_del_tile'),
                      style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          color: Brand.ajrakRed)),
                  subtitle: Text(tr('legal_del_tile_sub')),
                  onTap: () => _deleteAccount(context),
                ),
              ),
            ],
          );
        },
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            child: Text(label,
                style: const TextStyle(
                    fontWeight: FontWeight.w700, color: Colors.black54)),
          ),
          Expanded(
            child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}

/// Sawari ka Gmail/OTP card (v1.4.7, spec §1/§5) — email verify
/// ki haalat, no-show warnings ki ginti, aur Logout (dobara
/// booking par OTP lazmi)।
class _PassengerEmailCard extends StatefulWidget {
  final AppStore store;
  const _PassengerEmailCard({required this.store});

  @override
  State<_PassengerEmailCard> createState() => _PassengerEmailCardState();
}

class _PassengerEmailCardState extends State<_PassengerEmailCard> {
  late final _emailCtrl =
      TextEditingController(text: widget.store.passengerEmail);

  AppStore get store => widget.store;

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.mark_email_read, color: Brand.green),
                const SizedBox(width: 9),
                Text(tr('legal_email_card_title'),
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 15)),
              ],
            ),
            const SizedBox(height: 8),
            if (store.passengerEmailVerified)
              Row(
                children: [
                  const Icon(Icons.verified, color: Brand.green, size: 18),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      trf('legal_email_verified',
                          {'email': store.passengerEmail}),
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              )
            else
              EmailOtpSection(
                emailCtrl: _emailCtrl,
                onVerified: (email) async {
                  await store.applyPassengerEmailVerified(email);
                  unawaited(Backend.syncPassengerSelf(store));
                  // v1.4.14: pehchan bandhna (identity_links)।
                  unawaited(Backend.linkIdentities(store));
                  if (mounted) setState(() {});
                },
              ),
            if (store.passengerWarnCount > 0) ...[
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: store.passengerNoShowBlocked
                      ? const Color(0xFFFDECEA)
                      : const Color(0xFFFFF6E0),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  store.passengerNoShowBlocked
                      ? trf('legal_noshow_blocked',
                          {'count': '${store.passengerWarnCount}'})
                      : trf('legal_noshow_warn',
                          {'count': '${store.passengerWarnCount}'}),
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: store.passengerNoShowBlocked
                          ? Brand.ajrakRed
                          : const Color(0xFF8D6E00)),
                ),
              ),
            ],
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  await store.passengerLogout();
                  // v1.4.14: Auth session bhi saaf — dobara login
                  // OTP se naya session banayega (plan §8.1.1)।
                  unawaited(Backend.clearSession());
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text(tr('legal_logout_snack'))));
                  setState(() {});
                },
                icon: const Icon(Icons.logout, size: 17),
                label: const Text('Logout'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Alag screen wala roop — Profile tab ke ilawa jahan se bhi
/// khule (purane darwaze), body wohi [PassengerProfileBody] hai.
class PassengerProfileScreen extends StatelessWidget {
  final AppStore store;
  const PassengerProfileScreen({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('legal_profile_title'))),
      body: PassengerProfileBody(
        store: store,
        onAfterDelete: () => Navigator.of(context).pop(),
      ),
    );
  }
}
