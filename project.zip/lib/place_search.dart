// =====================================================================
// place_search.dart — ASAL JAGAH SEARCH (GEOCODING)
// v1.4.29 izafa (owner hukm 2026-11-11 15:51 — SAB SE ZAROORI):
// booking mein naam type karne par asal jagahon ke naam ayen aur
// chunne par app usi jagah par jaye। Pehle geocoding tha hi nahi
// (sirf pin chalta tha) — ab dono raste hain: SEARCH + PIN।
//
// SERVICE: Nominatim (OpenStreetMap) — muft, bina API key ke।
//  - countrycodes=pk: sirf Pakistan (saare sheher — Karachi tak
//    mehdood NAHI); sheher ka naam har result ke label mein saaf
//    dikhta hai taake ek hi naam ki do sheheron wali jagahen
//    alag pehchani jayen।
//  - viewbox bias (bounded=0): maujooda jagah/sheher ke aas paas
//    ke results ko TARJEEH milti hai, pabandi NAHI lagti।
//  - Debounce UI taraf hai (passenger.dart, 400ms); yahan har
//    call ek hi request hai। Timeout 8s (route_service jaisa)।
//  - Service down/ khata aye to [PlaceSearchException] — UI saaf
//    paighaam deti hai; JAALI suggestion kabhi NAHI banti (yahan
//    koi hardcoded/fake result NAHI hai)।
// =====================================================================

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:latlong2/latlong.dart' as ll2;

/// Ek search result — asal jagah।
class PlaceResult {
  /// Chhota asal naam (masalan "Mazar-e-Quaid")।
  final String name;

  /// Saaf pehchan wala label: naam + sheher (+ sooba jab
  /// zaroorat ho) — masalan "Mazar-e-Quaid, Karachi"। Yehi
  /// label field mein aur booking ke label mein jata hai
  /// (search se chunne par "Map Pin Wali Jagah" NAHI ata)।
  final String label;

  /// Poora Nominatim display_name (subtitle/ tafseel ke liye)।
  final String displayName;

  final ll2.LatLng point;

  const PlaceResult({
    required this.name,
    required this.label,
    required this.displayName,
    required this.point,
  });

  /// Nominatim ke ek JSON item se result banao (unit-test
  /// honay wala hissa)।
  factory PlaceResult.fromNominatimJson(Map<String, dynamic> j) {
    final display = (j['display_name'] ?? '').toString();
    var name = (j['name'] ?? '').toString().trim();
    if (name.isEmpty && display.isNotEmpty) {
      name = display.split(',').first.trim();
    }
    final addr = (j['address'] as Map?) ?? const {};
    String pick(List<String> keys) {
      for (final k in keys) {
        final v = (addr[k] ?? '').toString().trim();
        if (v.isNotEmpty) return v;
      }
      return '';
    }

    final city = pick(['city', 'town', 'village', 'county']);
    final state = pick(['state']);
    // Label: naam, sheher (naam se mukhtalif ho to), aur jab
    // sheher na mile to sooba — taake do sheheron ki ek-naam
    // jagahen alag dikhen।
    final parts = <String>[name];
    if (city.isNotEmpty && city != name) parts.add(city);
    if (city.isEmpty && state.isNotEmpty && state != name) {
      parts.add(state);
    }
    return PlaceResult(
      name: name,
      label: parts.join(', '),
      displayName: display,
      point: ll2.LatLng(
        double.tryParse('${j['lat']}') ?? 0,
        double.tryParse('${j['lon']}') ?? 0,
      ),
    );
  }
}

/// Search na ho sakne ki khata — UI is par saaf paighaam
/// dikhati hai (jaali result NAHI)।
class PlaceSearchException implements Exception {
  final String message;
  const PlaceSearchException(this.message);
  @override
  String toString() => 'PlaceSearchException: $message';
}

class PlaceSearch {
  static const String _host = 'nominatim.openstreetmap.org';

  /// Request ka URI — test honay wala hissa।
  /// [near] diya jaye to viewbox us ke gird banta hai (bias,
  /// bounded=0 — tarjeeh sirf, pabandi nahi)।
  static Uri buildUri(String query, {ll2.LatLng? near}) {
    final params = <String, String>{
      'format': 'jsonv2',
      'limit': '8',
      'countrycodes': 'pk',
      'addressdetails': '1',
      'q': query,
    };
    if (near != null) {
      // ~55 km ka viewbox — aas paas ke results pehle ayenge,
      // lekin bounded=0 ki wajah se poora Pakistan phir bhi
      // search hota hai (owner ki shart: sirf Karachi NAHI)।
      const d = 0.5;
      params['viewbox'] =
          '${near.longitude - d},${near.latitude + d},${near.longitude + d},${near.latitude - d}';
      params['bounded'] = '0';
    }
    return Uri.https(_host, '/search', params);
  }

  /// JSON jawaab ko results mein badlo — test honay wala hissa।
  static List<PlaceResult> parseResults(String body) {
    final decoded = jsonDecode(body);
    if (decoded is! List) return const [];
    final out = <PlaceResult>[];
    for (final e in decoded) {
      if (e is Map<String, dynamic>) {
        final r = PlaceResult.fromNominatimJson(e);
        if (r.point.latitude != 0 && r.name.isNotEmpty) out.add(r);
      }
    }
    return out;
  }

  /// Asal network search। Khata par [PlaceSearchException]।
  static Future<List<PlaceResult>> search(
    String query, {
    ll2.LatLng? near,
  }) async {
    final q = query.trim();
    if (q.length < 3) return const [];
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    try {
      final req =
          await client.getUrl(buildUri(q, near: near)).timeout(
                const Duration(seconds: 8),
              );
      // Nominatim ki policy: pehchan wala User-Agent lazmi।
      req.headers.set(HttpHeaders.userAgentHeader,
          'BozdarSafarApp/1.4.29 (ride booking place search)');
      final res = await req.close().timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) {
        throw PlaceSearchException('HTTP ${res.statusCode}');
      }
      final body = await res.transform(utf8.decoder).join();
      return parseResults(body);
    } on PlaceSearchException {
      rethrow;
    } catch (e) {
      throw PlaceSearchException('$e');
    } finally {
      client.close(force: true);
    }
  }
}
