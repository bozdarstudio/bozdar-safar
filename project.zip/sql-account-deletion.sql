-- =====================================================================
-- Bozdar Safar — v1.4.16 · ACCOUNT DELETION (server-side RPCs)
--
-- App ke "Account Delete Karein" flow ka server hissa. Ab tak
-- deletion sirf phone ka local data saaf karta tha; server par
-- account waisa hi rehta tha. Ye file do SECURITY DEFINER RPCs
-- banati hai:
--
--   delete_my_account(p_email)         — sawari (passenger)
--   delete_my_driver_account(p_email)  — driver
--
-- ADDITIVE ONLY (Phase 0 wale usool par): sirf naye functions
-- bante hain — koi table/policy/data pehle se change NAHI hota.
-- Idempotent — dobara chalana mehfooz (CREATE OR REPLACE).
--
-- TASDEEQ KA USOOL (koi doosra account chhune ka rasta NAHI):
--   * RPC sirf AUTHENTICATED session se chalti hai.
--   * p_email LAZMI session ke JWT email ke barabar ho — yehi
--     asal tasdeeq hai (email ka malik hona OTP se pehle hi
--     sabit ho chuka hota hai; app deletion se pehle dobara
--     OTP gate lagati hai).
--   * Account ki pehchan DO raston se milti hai aur dono isi
--     email/session se bandhe hain: (1) identity_links mein is
--     Auth user ki rows, (2) passengers/drivers row jis ka
--     email == p_email. Is ke ilawa koi row NAHI chhooti.
--   * Master (owner) ka email settings.master_email se match
--     ho to RPC foran false — malik ka account is raste se
--     kabhi delete NAHI ho sakta.
--
-- DELETE vs ANONYMIZE (Master ke record qanoon ke mutabiq):
--   * PEHCHAN delete/anonymize hoti hai: naam, mobile, email,
--     CNIC, password fingerprint, photo paths, selfie records,
--     identity link aur (agar is Auth user ki koi aur pehchan
--     baqi na rahe to) Auth login record bhi khatam.
--   * RECORD mehfooz rehta hai lekin ANONYMIZED shakl mein:
--     rides (fare/km/date/status) aur ledger (rakam/tareekh)
--     waise hi rehte hain — sirf un par likha naam/number
--     'Deleted User'/khaali ho jata hai. Is liye kal koi
--     jhooti shikayat aye to hisaab ka record maujood hai,
--     lekin us se kisi ki zaati pehchan NAHI milti.
--   * blocked_passengers (Master ka safety record) jaan boojh
--     kar NAHI chhoota jata — woh pehchan nahi, safety faisla
--     hai, aur us ka mobile Master ke paas pehle se mehfooz hai.
--
-- Rollback: drop function public.delete_my_account(text);
--           drop function public.delete_my_driver_account(text);
-- =====================================================================

-- ---------------------------------------------------------------------
-- SAWARI (passenger) — delete_my_account
--   passengers.device_id hi sawari ki pehchan hai; rides par
--   passenger_key wohi device_id hai (Phase 0, A-1)।
--   devices table mein naam/mobile/email koi column hai hi
--   nahi (sirf device_id/role/last_mode/app_version) — wahan
--   anonymize karne ko kuch nahi; asal pehchan passengers +
--   rides + messages mein hoti hai, wohi saaf hoti hai।
-- ---------------------------------------------------------------------
create or replace function public.delete_my_account(p_email text)
returns boolean
language plpgsql security definer set search_path = public as $$
declare
  v_email  text := lower(btrim(coalesce(p_email, '')));
  v_jwt    text := lower(coalesce(auth.jwt() ->> 'email', ''));
  v_uid    uuid := auth.uid();
  v_master text := lower(coalesce(
    (select master_email from public.settings where id = 1), ''));
  v_devices text[] := '{}';
  d text;
begin
  -- Tasdeeq ki shartein — ek bhi fail ho to KUCH nahi hota।
  if auth.role() <> 'authenticated' or v_uid is null then
    return false;
  end if;
  if v_email = '' or v_jwt = '' or v_email <> v_jwt then
    return false;
  end if;
  if v_master <> '' and v_email = v_master then
    return false;  -- owner ka account is raste se kabhi nahi
  end if;

  -- Is account ke tamam device — (1) identity_links (is Auth
  -- user ke bandhe hue), (2) passengers.email ka match. Dono
  -- isi session/email se bandhe hain; teesra rasta nahi।
  select coalesce(array_agg(distinct subject_id), '{}')
    into v_devices
    from public.identity_links
   where kind = 'passenger' and auth_user_id = v_uid;
  v_devices := v_devices || coalesce(
    (select array_agg(device_id) from public.passengers
      where lower(coalesce(email, '')) = v_email), '{}');
  select coalesce(array_agg(distinct x), '{}')
    into v_devices from unnest(v_devices) as x;

  if coalesce(array_length(v_devices, 1), 0) = 0 then
    return false;  -- is email/session ka koi sawari account nahi
  end if;

  foreach d in array v_devices loop
    -- passengers row: pehchan anonymize (row rehti hai taaki
    -- warn/block ka safety record device se juda rahe)।
    update public.passengers
       set name = 'Deleted User',
           mobile = '',
           email = null,
           email_verified_at = null,
           updated_at = now()
     where device_id = d;
    -- rides: hisaab mehfooz, pehchan khatam।
    update public.rides
       set passenger_name = 'Deleted User',
           passenger_mobile = ''
     where passenger_key = d;
    -- Master chat: is sawari ki rows par naam/number anonymize
    -- (baat-cheet ka record rehta hai, pehchan nahi)।
    update public.messages
       set sender_name = 'Deleted User',
           sender_mobile = ''
     where sender_key = d and sender_role = 'passenger';
  end loop;

  -- Identity link khatam — sirf IS Auth user ki sawari wali
  -- rows (us ki driver/agent pehchan ho to woh mehfooz)।
  delete from public.identity_links
   where kind = 'passenger' and auth_user_id = v_uid;

  -- Login record bhi khatam — lekin SIRF tab jab is Auth user
  -- ki ab koi aur pehchan (driver/agent) baqi na rahi ho;
  -- warna woh pehchan zinda hai aur login usi ka hai।
  if not exists (select 1 from public.identity_links
                  where auth_user_id = v_uid) then
    delete from auth.users where id = v_uid;
  end if;

  return true;
end $$;

revoke execute on function public.delete_my_account(text) from public;
grant execute on function public.delete_my_account(text) to authenticated;

-- ---------------------------------------------------------------------
-- DRIVER — delete_my_driver_account
--   drivers.id hi pehchan hai; rides.driver_id / ledger.driver_id
--   usi id se hisaab rakhti hain — id row ANONYMIZED shakl mein
--   rehti hai taaki Master ka fee/ledger record na toote, lekin
--   us id se ab kisi insaan ki pehchan NAHI milti (naam, mobile,
--   CNIC, email, password fingerprint, device/IMEI, tamam photo
--   paths — sab khatam; account active bhi nahi rehta)।
--   Selfie pehchan hai, hisaab nahi — driver_selfies ki rows
--   delete hoti hain. NOTE: Storage bucket 'selfies'/'driver-docs'
--   mein is driver ki photo FILES is SQL se delete NAHI hotin —
--   woh deploy ke waqt bucket safai ki alag checklist hai;
--   database se un ka rasta (paths) yahin null ho jata hai।
-- ---------------------------------------------------------------------
create or replace function public.delete_my_driver_account(p_email text)
returns boolean
language plpgsql security definer set search_path = public as $$
declare
  v_email  text := lower(btrim(coalesce(p_email, '')));
  v_jwt    text := lower(coalesce(auth.jwt() ->> 'email', ''));
  v_uid    uuid := auth.uid();
  v_master text := lower(coalesce(
    (select master_email from public.settings where id = 1), ''));
  v_drivers text[] := '{}';
  drv text;
begin
  -- Tasdeeq ki shartein — passenger wali ain shartein।
  if auth.role() <> 'authenticated' or v_uid is null then
    return false;
  end if;
  if v_email = '' or v_jwt = '' or v_email <> v_jwt then
    return false;
  end if;
  if v_master <> '' and v_email = v_master then
    return false;  -- owner ka account is raste se kabhi nahi
  end if;

  -- Is account ke tamam driver ids — (1) identity_links,
  -- (2) drivers.email ka match. Teesra rasta nahi।
  select coalesce(array_agg(distinct subject_id), '{}')
    into v_drivers
    from public.identity_links
   where kind = 'driver' and auth_user_id = v_uid;
  v_drivers := v_drivers || coalesce(
    (select array_agg(id) from public.drivers
      where lower(coalesce(email, '')) = v_email), '{}');
  select coalesce(array_agg(distinct x), '{}')
    into v_drivers from unnest(v_drivers) as x;

  if coalesce(array_length(v_drivers, 1), 0) = 0 then
    return false;  -- is email/session ka koi driver account nahi
  end if;

  foreach drv in array v_drivers loop
    -- drivers row: pehchan ki HAR cheez khatam, ID band।
    update public.drivers
       set name = 'Deleted User',
           mobile = '',
           email = null,
           email_verified_at = null,
           cnic_number = null,
           licence_number = null,
           pwd_fp = null,
           device_id = null,
           imei = null,
           cnic_front_path = null,
           cnic_back_path = null,
           vehicle_photo_path = null,
           vehicle_reg_path = null,
           licence_photo_path = null,
           profile_photo_path = null,
           vehicle_history = '[]'::jsonb,
           vehicle_change = null,
           online = false,
           on_ride = false,
           active = false,
           updated_at = now()
     where id = drv;
    -- Selfies: pehchan — delete (hisaab nahi)।
    delete from public.driver_selfies where driver_id = drv;
    -- Master chat: is driver ki rows par naam/number anonymize।
    update public.messages
       set sender_name = 'Deleted User',
           sender_mobile = ''
     where sender_key = drv and sender_role = 'driver';
    -- rides / ledger jaan boojh kar NAHI chhooye jate: un par
    -- driver ki pehchan sirf yehi (ab anonymized) id hai, aur
    -- fare/fee ka hisaab Master ke record ke liye mehfooz hai।
  end loop;

  -- Identity link khatam — sirf IS Auth user ki driver rows।
  delete from public.identity_links
   where kind = 'driver' and auth_user_id = v_uid;

  -- Login record — wohi usool: koi aur pehchan (passenger/
  -- agent) baqi ho to login zinda rehta hai।
  if not exists (select 1 from public.identity_links
                  where auth_user_id = v_uid) then
    delete from auth.users where id = v_uid;
  end if;

  return true;
end $$;

revoke execute on function public.delete_my_driver_account(text) from public;
grant execute on function public.delete_my_driver_account(text) to authenticated;

-- ACCOUNT DELETION KHATAM.
