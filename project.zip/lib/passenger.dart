import 'dart:async';
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import 'store.dart';
import 'theme.dart';
import 'legal.dart';
import 'messages.dart';
import 'notifications.dart';
import 'backend.dart';
import 'route_service.dart';
import 'safar_map.dart';
import 'main.dart' show ModeToggleButton, UpdateBanner;

const LatLng kKarachiCenter = LatLng(24.8608, 67.0011); // Karachi sheher

const Map<String, String> kStatusUrdu = {
  'pending': 'Driver ke jawab ka intezaar',
  'accepted': 'Driver ne qubool kar li',
  'arrived': 'Driver pohanch gaya hai',
  'completed': 'Ride mukammal',
  'cancelled': 'Mansookh',
  'noshow': 'Sawari nahi aayi (No-show)',
};

class PassengerSide extends StatefulWidget {
  final AppStore store;
  final VoidCallback onSwitchToDriver;
  const PassengerSide(
      {super.key, required this.store, required this.onSwitchToDriver});

  @override
  State<PassengerSide> createState() => _PassengerSideState();
}

class _PassengerSideState extends State<PassengerSide>
    with NotificationBannerMixin {
  int _tab = 0; // 0 Booking | 1 Meri Bookings | 2 Monthly

  // v1.4.0 two-phone dispatch: active ride ki backend wali taaza
  // haalat (status + driver ki live jagah) ka poll — screen par
  // jo bhi active booking khuli ho, us ke liye ETA line isi se
  // taza hoti hai. Backend/columns na hon to poll khamosh rehta
  // hai aur same-device pilot ki haalat hi chalti hai.
  Timer? _ridePoll;
  final Map<String, ({double lat, double lng})> _remoteDriverPos = {};
  // (rating prompt ka state _FindingDriverViewState ke paas hai.)


  // Booking form — MapLibre 3D map: pickup/drop tap se lagte hain,
  // route line OSRM se (offline par seedhi line fallback).
  LatLng _pickup = kKarachiCenter;
  LatLng? _drop;
  bool _dropArmed = false;
  List<LatLng>? _routePoints;
  String _routeSig = '';
  int _routeToken = 0;
  // Maujooda pickup/drop jori ke ASAL ROUTE ki sadak wali doori (km) —
  // kiraya isi par banta hai (v1.2.1). Null = is jori ka road route
  // abhi dastiyab nahi (offline/seedhi-line fallback); tab kiraya
  // seedhi doori se banta hai. _routeKmSig woh jori hai jis ke liye
  // ye doori hai — jori badle to purani doori istemal nahi hoti.
  double? _routeKm;
  String _routeKmSig = '';
  bool _satellite = false;
  LatLng? _focusPoint;
  int _focusSeq = 0;
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _pickupCtrl = TextEditingController();
  final _dropCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  String _vehicle = 'Rickshaw';
  double _distanceKm = 2.0;

  // Monthly form — pickup/drop dono ke pins bhi rehte hain (zone tap
  // ya map tap se); dono pins lag jayein to route OSRM se ata hai
  // aur monthly hisaab USI asal road-km par banta hai (v1.4.0).
  // Pins se pehle _mRouteKm sirf 2.0 ka placeholder hai jo form ki
  // kisi nazar ane wali jagah par istemal nahi hota (kul raqam
  // hamesha sirf package pakka hone par dialog mein dikhti hai).
  final _mPickupCtrl = TextEditingController();
  final _mDropCtrl = TextEditingController();
  String _mVehicle = 'Rickshaw';
  double _mRouteKm = 2.0;
  int _mDays = 26;
  LatLng? _mPickupPin;
  LatLng? _mDropPin;
  bool _mRouteIsRoad = false;
  int _mRouteToken = 0;

  // NOTE (v1.0.5): km chip selectors HATA diye gaye hain — doori hamesha
  // AUTO hisaab (pickup pin se drop pin) se aati hai; passenger ko koi
  // km field, per-km rate ya formula kabhi nazar nahi aata.
  static const List<int> _dayChips = [20, 24, 26, 30];

  AppStore get store => widget.store;

  @override
  void initState() {
    super.initState();
    _nameCtrl.text = store.passengerName;
    // v1.4.0: foreground notification banners (ride ki khabar app
    // khuli ho to foran snackbar mein bhi ati hai) + elanaat ka
    // halka pull + active rides ka backend poll.
    listenNotificationBanners(store);
    unawaited(Backend.refreshAnnouncements(store));
    _ridePoll = Timer.periodic(const Duration(seconds: 15), (_) {
      unawaited(_pollActiveRides());
    });
    unawaited(_pollActiveRides());
  }

  @override
  void dispose() {
    cancelNotificationBanners();
    _ridePoll?.cancel();
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _pickupCtrl.dispose();
    _dropCtrl.dispose();
    _noteCtrl.dispose();
    _mPickupCtrl.dispose();
    _mDropCtrl.dispose();
    super.dispose();
  }

  /// Ghair-final rides (pending/accepted/arrived) ki backend
  /// haalat ka poll:
  ///  - driver ki LIVE jagah (rides.driver_lat/lng) ETA ke liye mehfooz
  ///  - status local se alag ho to notification BHI banta hai aur
  ///    (v1.4.2 dispatch fix) asal haalat local booking par BHI lag
  ///    jati hai — Backend.applyRemoteRowToBooking, jo asal driver
  ///    ki tafseel bhi le ata hai. Is ke baghair do-phone par
  ///    passenger ki screen hamesha 'pending' par atki rehti thi.
  ///    Jis booking ko isi phone ke driver ne accept kiya ho, us
  ///    par remote NAHI lagta (store ke usool).
  /// Koi row/column na mile to bilkul khamosh.
  Future<void> _pollActiveRides() async {
    final actives = store.bookings
        .where((b) =>
            b.status == 'pending' ||
            b.status == 'accepted' ||
            b.status == 'arrived')
        .toList();
    var posChanged = false;
    final remote = <String, String>{};
    for (final b in actives) {
      final row = await Backend.fetchRideRow(b.id);
      if (row == null) continue;
      final lat = (row['driver_lat'] as num?)?.toDouble();
      final lng = (row['driver_lng'] as num?)?.toDouble();
      if (lat != null && lng != null) {
        final old = _remoteDriverPos[b.id];
        if (old == null || old.lat != lat || old.lng != lng) {
          _remoteDriverPos[b.id] = (lat: lat, lng: lng);
          posChanged = true;
        }
      }
      final st = row['status'];
      if (st is String && st.isNotEmpty) remote[b.id] = st;
      await Backend.applyRemoteRowToBooking(store, b, row);
    }
    if (remote.isNotEmpty) {
      await store.observeBookingStatuses('passenger', remoteStatus: remote);
    }
    if ((posChanged || remote.isNotEmpty) && mounted) setState(() {});
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  bool get _fareReady =>
      _pickupCtrl.text.trim().isNotEmpty && _dropCtrl.text.trim().isNotEmpty;

  static double _roundKm(double km) {
    final r = (km * 10).round() / 10;
    return r < 0.5 ? 0.5 : r;
  }

  /// SEEDHI (crow-flies) doori — ye sirf FALLBACK hai: jab pickup/drop
  /// jori ka asal sadak route (OSRM/cache) dastiyab na ho (masalan
  /// pehli dafa bilkul offline hon), tab kiraya isi se banta hai.
  /// Drop pin na ho to andar ka default istemal hota hai — passenger
  /// se doori kabhi poochhi nahi jati.
  double get _autoKm {
    if (_drop == null) return _distanceKm;
    final d = const Distance().as(LengthUnit.Kilometer, _pickup, _drop!);
    return _roundKm(d);
  }

  /// Kiraaye ki asal doori: maujooda pickup/drop jori ke ROUTE ki
  /// sadak wali doori (per-km rate isi par lagta hai — v1.2.1 fix).
  /// Road route dastiyab na ho to seedhi doori (_autoKm) fallback.
  double get _fareKm {
    final rk = _routeKm;
    if (_drop != null && rk != null) return rk;
    return _autoKm;
  }

  void _setPickup(LatLng point) {
    setState(() => _pickup = point);
    _refreshRoute();
  }

  static String _pairSig(LatLng a, LatLng b) =>
      '${a.latitude.toStringAsFixed(3)},${a.longitude.toStringAsFixed(3)}|${b.latitude.toStringAsFixed(3)},${b.longitude.toStringAsFixed(3)}';

  /// Pickup/drop ke liye asal sadak ka route (OSRM ya cache; offline par
  /// seedhi line) — map par line bhi isi se banti hai AUR kiraya bhi:
  /// route ki SADAK wali doori (_routeKm) hi kiraaye ki bunyaad hai
  /// (v1.2.1). Sirf seedhi-line fallback mile to _routeKm null rehta
  /// hai aur kiraya seedhi doori (_autoKm) se banta hai.
  Future<void> _refreshRoute() async {
    final drop = _drop;
    if (drop == null) {
      if (_routePoints != null && mounted) {
        setState(() => _routePoints = null);
      }
      _routeSig = '';
      _routeKm = null;
      _routeKmSig = '';
      return;
    }
    final sig = _pairSig(_pickup, drop);
    if (sig == _routeSig) return;
    _routeSig = sig;
    // Jori badal gayi — purani jori ki route doori ab kiraaye mein
    // istemal nahi hogi; nayi doori fetch mukammal hone par hi set hogi.
    _routeKm = null;
    _routeKmSig = '';
    final token = ++_routeToken;
    final r = await RouteService.fetch(_pickup, drop);
    if (mounted && token == _routeToken) {
      setState(() {
        _routePoints = r.points;
        if (r.isStraightFallback) {
          _routeKm = null;
          _routeKmSig = '';
        } else {
          _routeKm = _roundKm(r.distanceKm);
          _routeKmSig = sig;
        }
      });
    }
  }

  Future<void> _myLocation() async {
    try {
      final service = await Geolocator.isLocationServiceEnabled();
      if (!service) {
        if (mounted) _snack('Location service band hai — pehle on karein.');
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        if (mounted) _snack('Location ki ijazat nahi mili.');
        return;
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      if (!mounted) return;
      final ll = LatLng(pos.latitude, pos.longitude);
      setState(() {
        _pickup = ll;
        _focusPoint = ll;
        _focusSeq++;
        if (_pickupCtrl.text.trim().isEmpty) {
          _pickupCtrl.text = 'Meri Location';
        }
      });
      _refreshRoute();
    } catch (_) {
      if (mounted) {
        _snack('Location nahi mil saki — map par tap karke pickup lagayein.');
      }
    }
  }

  void _placeDrop(LatLng point) {
    setState(() {
      _drop = point;
      _dropArmed = false;
    });
    _refreshRoute();
  }

  Future<void> _confirmBooking() async {
    if (_nameCtrl.text.trim().isEmpty) {
      _snack('Apna naam likhein.');
      return;
    }
    if (!_fareReady) {
      _snack('Pickup aur drop dono jagah likhein.');
      return;
    }
    store.passengerName = _nameCtrl.text.trim();
    // Kiraya ASAL SADAK ki doori par banta hai (v1.2.1): agar maujooda
    // jori ki route doori abhi state mein nahi hai, to booking se pehle
    // EK dafa route le kar usi ki doori istemal karein (cache se foran
    // mil jata hai; waqt ki had 6 second). Route na mile (offline) to
    // seedhi doori par hi booking ban jayegi — booking is wajah se
    // lambi rukegi nahi, aur fail ho to khamoshi se fallback hoga.
    var km = _fareKm;
    final dropPin = _drop;
    if (dropPin != null) {
      final sig = _pairSig(_pickup, dropPin);
      if (_routeKm == null || _routeKmSig != sig) {
        try {
          final r = await RouteService.fetch(_pickup, dropPin)
              .timeout(const Duration(seconds: 6));
          if (!r.isStraightFallback && r.distanceKm > 0) {
            km = _roundKm(r.distanceKm);
            _routeKm = km;
            _routeKmSig = sig;
            if (mounted) {
              setState(() => _routePoints = r.points);
            }
          }
        } catch (_) {
          // Route na mila — km seedhi doori (_fareKm) hi rahega.
        }
      }
    }
    final b = Booking(
      id: store.newId(),
      passengerName: _nameCtrl.text.trim(),
      passengerPhone: _phoneCtrl.text.trim(),
      pickupLabel: _pickupCtrl.text.trim(),
      dropLabel: _dropCtrl.text.trim(),
      pickupLat: _pickup.latitude,
      pickupLng: _pickup.longitude,
      dropLat: _drop?.latitude ?? 0,
      dropLng: _drop?.longitude ?? 0,
      hasDropPin: _drop != null,
      vehicle: _vehicle,
      distanceKm: km,
      fare: Fares.fareFor(_vehicle, km),
      note: _noteCtrl.text.trim(),
      status: 'pending',
      createdAt: DateTime.now(),
      driverName: store.profile.name,
    );
    await store.addBooking(b);
    if (!mounted) return;
    // v1.4.0 TWO-PHONE DISPATCH (b): booking banne ke BAAD (aur
    // kiraya wale dialog se pehle — koi fare yahan NAHI dikhta,
    // sirf "driver qareeb hai" ki ittila) backend ke active+online
    // drivers mein sab se qareeb driver ginna. Jawab na aye/backend
    // khaali ho to khamoshi — mojooda same-device pilot bilkul
    // waise hi chalta hai, ye sirf bonus maloomat hai. Assignment
    // is se NAHI hoti — driver ke qubool karne se hi hoti hai.
    try {
      final nearKm = await Backend.nearestOnlineDriverKm(
              b.pickupLat, b.pickupLng)
          .timeout(const Duration(seconds: 5), onTimeout: () => null);
      if (nearKm != null) {
        store.setDispatchNote(
            'Qareeb driver maujood hai — sirf ${nearKm.toStringAsFixed(1)} km door. Jawab ka intezaar karein.');
      } else {
        store.setDispatchNote('');
      }
    } catch (_) {
      store.setDispatchNote('');
    }
    if (!mounted) return;
    // Kul kiraya PEHLI dafa yahin nazar aata hai — booking pakki hone
    // ke BAAD (owner ka lock, v1.0.7). Us se pehle kahin koi price nahi.
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Brand.green, size: 26),
            SizedBox(width: 8),
            Text('Booking Pakki Ho Gayi'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('${b.pickupLabel} → ${b.dropLabel}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text(b.vehicle, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Brand.deepGreen,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                children: [
                  const Text('TOTAL KIRAYA',
                      style: TextStyle(
                          color: Brand.goldLight,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.2)),
                  Text(rs(b.total),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.w900)),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Doori: ${b.distanceKm.toStringAsFixed(1)} km',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Colors.black87),
            ),
            const SizedBox(height: 6),
            const Text(
              'Booking driver ko bhej di gayi hai — jawab ka intezaar karein.',
              style: TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Theek Hai'),
          ),
        ],
      ),
    );
    if (!mounted) return;
    // Booking pakki hone ke BAAD "Driver Dhoonda Ja Raha Hai" wali
    // screen (Careem ki "Finding your Captain" style, v1.0.8) — ye
    // booking ki halat wali screen hai, asal driver assignment nahi.
    final result = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (_) => _FindingDriverView(store: store, booking: b),
      ),
    );
    if (!mounted) return;
    if (result == 'bookings') {
      setState(() => _tab = 1);
    } else if (result == 'cancelled') {
      setState(() => _tab = 0);
      _snack('Ride mansookh ho gayi.');
    }
  }

  void _clearBookingForm() {
    setState(() {
      _pickupCtrl.clear();
      _dropCtrl.clear();
      _noteCtrl.clear();
      _drop = null;
      _dropArmed = false;
      _distanceKm = 2.0;
      _routeKm = null;
      _routeKmSig = '';
      _vehicle = 'Rickshaw';
    });
    _snack('Koi booking nahi bani — sab saaf kar diya gaya.');
  }

  Future<void> _savePlace(bool isGhar) async {
    final current = isGhar ? store.savedGhar : store.savedDaftar;
    final ctrl = TextEditingController(text: current);
    final label = isGhar ? 'Ghar' : 'Daftar';
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('$label ki jagah save karein'),
        content: TextField(
          controller: ctrl,
          decoration: InputDecoration(labelText: '$label ka pata / jagah'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Rehne Dein')),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: const Text('Save Karein')),
        ],
      ),
    );
    if (result != null) {
      if (isGhar) {
        store.savedGhar = result;
      } else {
        store.savedDaftar = result;
      }
      await store.save();
      if (mounted) _snack('$label save ho gaya.');
    }
  }

  void _applyPlace(bool isGhar) {
    final v = isGhar ? store.savedGhar : store.savedDaftar;
    if (v.isEmpty) {
      _savePlace(isGhar);
    } else {
      setState(() => _dropCtrl.text = v);
    }
  }

  // --- Saved places (v1.4.0) ----------------------------------------------
  // Mehfooz jagah (naam + label + pin) chip se manzil ban jati hai;
  // "Jagah save karein" button maujooda pickup ya drop ko kisi bhi
  // naam (Ghar / Daftar / apna naam) se mehfooz karta hai. Sirf
  // is phone ki store mein rehti hain — koi backend nahi.

  void _applySavedPlace(SavedPlace sp) {
    setState(() {
      _dropCtrl.text = sp.label;
      if (sp.hasPin) {
        _drop = LatLng(sp.lat, sp.lng);
        _dropArmed = false;
      }
    });
    _refreshRoute();
  }

  Future<void> _saveCurrentPlace() async {
    final nameCtrl = TextEditingController();
    final useDrop = _dropCtrl.text.trim().isNotEmpty;
    final label = useDrop ? _dropCtrl.text.trim() : _pickupCtrl.text.trim();
    if (label.isEmpty) {
      _snack('Pehle pickup ya manzil likhein, phir save karein.');
      return;
    }
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Jagah save karein'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Jagah: $label',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(
                labelText: 'Naam (Ghar / Daftar / apna naam)',
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              children: [
                ActionChip(
                  label: const Text('Ghar'),
                  onPressed: () => Navigator.pop(ctx, 'Ghar'),
                ),
                ActionChip(
                  label: const Text('Daftar'),
                  onPressed: () => Navigator.pop(ctx, 'Daftar'),
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Rehne Dein')),
          ElevatedButton(
            onPressed: () {
              final n = nameCtrl.text.trim();
              if (n.isEmpty) {
                Navigator.pop(ctx);
              } else {
                Navigator.pop(ctx, n);
              }
            },
            child: const Text('Save Karein'),
          ),
        ],
      ),
    );
    nameCtrl.dispose();
    if (result == null || result.isEmpty) return;
    final pinLat = useDrop ? (_drop?.latitude ?? _pickup.latitude) : _pickup.latitude;
    final pinLng = useDrop
        ? (_drop?.longitude ?? _pickup.longitude)
        : _pickup.longitude;
    await store.savePlace(SavedPlace(
      id: store.newId(),
      name: result,
      label: label,
      lat: pinLat,
      lng: pinLng,
      hasPin: useDrop ? _drop != null : true,
    ));
    if (mounted) _snack('"$result" save ho gaya.');
  }

  /// Mehfooz jagah mitana (chips wali patti ke neeche chhota sa
  /// manage button) — sirf jab saved places mojood hon.
  Future<void> _manageSavedPlaces() async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Mehfooz Jagahen'),
        content: ListenableBuilder(
          listenable: store,
          builder: (context, _) {
            if (store.savedPlaces.isEmpty) {
              return const Text('Koi jagah save nahi hai.');
            }
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final sp in store.savedPlaces)
                  ListTile(
                    dense: true,
                    leading: const Icon(Icons.place, color: Brand.green),
                    title: Text(sp.name),
                    subtitle: Text(sp.label),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline,
                          color: Brand.ajrakRed),
                      onPressed: () => store.removePlace(sp.id),
                    ),
                  ),
              ],
            );
          },
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Band Karein')),
        ],
      ),
    );
    if (mounted) setState(() {});
  }

  // -------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const BrandHeader(sideLabel: 'PASSENGER APP'),
          if (store.updateAvailable && !store.updateDismissed)
            UpdateBanner(store: store),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
            child: Row(
              children: [
                Expanded(
                  child: ModeToggleButton(
                      toDriver: true, onTap: widget.onSwitchToDriver),
                ),
                const SizedBox(width: 6),
                // v1.4.0: Notification Centre ki ghanti (unread badge).
                NotificationBell(store: store),
              ],
            ),
          ),
          // Malik ki passenger mode artwork (brand board) — header + toggle
          // ke foran neeche.
          const ModeBanner(asset: 'assets/mode-passenger.png'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Row(
              children: [
                _tabBtn(0, Icons.map, 'Booking'),
                const SizedBox(width: 8),
                _tabBtn(1, Icons.list_alt, 'Meri Bookings'),
                const SizedBox(width: 8),
                _tabBtn(2, Icons.calendar_month, 'Monthly'),
              ],
            ),
          ),
          Expanded(
            child: _tab == 0
                ? _bookingView()
                : _tab == 1
                    ? _myBookingsView()
                    : _monthlyView(),
          ),
        ],
      ),
    );
  }

  Widget _tabBtn(int idx, IconData icon, String label) {
    final selected = _tab == idx;
    return Expanded(
      child: OutlinedButton.icon(
        onPressed: () => setState(() => _tab = idx),
        icon: Icon(icon, size: 18),
        label: Text(label),
        style: OutlinedButton.styleFrom(
          backgroundColor: selected ? Brand.goldLight : Colors.white,
          foregroundColor: Brand.greenDark,
          side: BorderSide(
              color: selected ? Brand.gold : const Color(0xFFB9CFC6),
              width: selected ? 1.8 : 1.2),
          padding: const EdgeInsets.symmetric(vertical: 10),
          textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
    );
  }

  IconData _vehicleIcon(String v) => v == 'Car'
      ? Icons.directions_car
      : v == 'Bike'
          ? Icons.two_wheeler
          : v == 'Taxi'
              ? Icons.local_taxi
              : v == 'Van'
                  ? Icons.airport_shuttle
                  : Icons.electric_rickshaw;

  /// Gaariyon ki Roman-Urdu taglines — sab price-free hain (owner lock).
  static const Map<String, String> _vehicleTaglines = {
    'Rickshaw': 'Shehar ki sawari, sab ki pasand',
    'Bike': 'Jaib par halki, traffic ke liye behtareen',
    'Car': 'Aaram deh sawari, family ke liye behtareen',
    'Taxi': 'AC taxi, waqt par pohanchne ki zamanat',
    'Van': 'Poori family aur samaan ke liye wasee jagah',
  };

  /// Careem "Ride details" style vehicle row (v1.0.8): icon left, bold
  /// naam + grey Roman-Urdu tagline, radio circle right, selected row
  /// highlighted. Koi price NAHI — owner ka lock (v1.0.7 se barqarar):
  /// booking se pehle kiraya kahin nazar nahi aata; kul kiraya sirf
  /// ride pakki hone ke BAAD dikhta hai.
  Widget _vehicleRow({
    required String vehicle,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFFE7F2EC) : Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? Brand.green : Brand.fieldBorder,
              width: selected ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              Icon(_vehicleIcon(vehicle), color: Brand.green, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(vehicle,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(_vehicleTaglines[vehicle] ?? '',
                        style: const TextStyle(
                            fontSize: 12.5, color: Colors.black54)),
                  ],
                ),
              ),
              Container(
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: selected ? Brand.green : const Color(0xFFB9CFC6),
                    width: 2,
                  ),
                ),
                child: selected
                    ? Center(
                        child: Container(
                          width: 11,
                          height: 11,
                          decoration: const BoxDecoration(
                            color: Brand.green,
                            shape: BoxShape.circle,
                          ),
                        ),
                      )
                    : null,
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// "Qareebi Jagahen" row — Careem ke Nearby Locations jaisi: pin,
  /// bold zone naam, grey subtitle. Tap par zone manzil (drop) ban
  /// jata hai. Koi heart icon nahi.
  Widget _zoneRow(String zone) {
    final isDrop = _dropCtrl.text.trim() == zone;
    return InkWell(
      onTap: () {
        setState(() {
          _dropCtrl.text = zone;
          final c = kZoneCoords[zone];
          if (c != null) {
            _drop = c;
            _dropArmed = false;
          }
        });
        _refreshRoute();
      },
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: isDrop ? Brand.green : Brand.lightBg,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.location_on,
                  size: 19, color: isDrop ? Colors.white : Brand.green),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(zone,
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 14)),
                  Text(kZoneProvince[zone] ?? 'Pakistan',
                      style: const TextStyle(
                          fontSize: 12, color: Colors.black45)),
                ],
              ),
            ),
            if (isDrop)
              const Icon(Icons.check_circle, color: Brand.green, size: 20),
          ],
        ),
      ),
    );
  }

  // --- Booking view: full map + overlay sheet (inDrive style) ---------------

  Widget _bookingView() {
    final size = MediaQuery.of(context).size;
    return Stack(
      children: [
        Positioned.fill(
          child: SafarMapView(
            center: _pickup,
            initialZoom: 13.5,
            tilt: 50,
            pickup: _pickup,
            drop: _drop,
            routePoints: _routePoints,
            zonePoints: [
              for (final z in store.zoneNames)
                if (kZoneCoords[z] != null) kZoneCoords[z]!,
            ],
            interactive: true,
            fitToRoute: true,
            externalStyleControl: true,
            satellite: _satellite,
            onSatelliteChanged: (v) => setState(() => _satellite = v),
            onTapPoint: (p) {
              if (_dropArmed) {
                _placeDrop(p);
              } else {
                _setPickup(p);
              }
            },
            onLongPressPoint: _placeDrop,
            focusPoint: _focusPoint,
            focusSeq: _focusSeq,
          ),
        ),
        // Map quick actions
        Positioned(
          top: 10,
          right: 12,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              FloatingActionButton.small(
                heroTag: 'gps',
                onPressed: _myLocation,
                backgroundColor: Colors.white,
                foregroundColor: Brand.green,
                child: const Icon(Icons.my_location),
              ),
              const SizedBox(height: 4),
              const Text('Meri\nLocation',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
              const SizedBox(height: 10),
              FloatingActionButton.small(
                heroTag: 'droppin',
                onPressed: () => setState(() => _dropArmed = !_dropArmed),
                backgroundColor: _dropArmed ? Brand.gold : Colors.white,
                foregroundColor: Brand.green,
                child: const Icon(Icons.add_location_alt),
              ),
              const SizedBox(height: 4),
              const Text('Drop\nPin',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
              const SizedBox(height: 10),
              FloatingActionButton.small(
                heroTag: 'mapstyle',
                onPressed: () => setState(() => _satellite = !_satellite),
                backgroundColor: _satellite ? Brand.gold : Colors.white,
                foregroundColor: Brand.green,
                child: const Icon(Icons.layers),
              ),
              const SizedBox(height: 4),
              const Text('Map\nStyle',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
            ],
          ),
        ),
        Positioned(
          top: 10,
          left: 12,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.92),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Brand.gold),
            ),
            child: const Text(
              'Pickup: map par tap karein\nDrop: lamba dabayein ya Drop Pin button se',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
            ),
          ),
        ),
        // Booking sheet overlaid on the map — Careem style safed sheet
        // (v1.0.8): gol kinare, halki parchhai, andar drag handle.
        Positioned(
          left: 10,
          right: 10,
          bottom: 10,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(26),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.22),
                  blurRadius: 18,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: ConstrainedBox(
              constraints: BoxConstraints(maxHeight: size.height * 0.55),
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
                child: _bookingForm(),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _bookingForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Sheet ka drag handle (Careem style safed sheet, v1.0.8).
        Center(
          child: Container(
            width: 44,
            height: 5,
            decoration: BoxDecoration(
              color: Brand.fieldBorder,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Text('Kahan jana hai?',
            style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w900,
                color: Brand.greenDark)),
        const SizedBox(height: 4),
        const Text(
          'Pehle manzil (drop) chunein, phir pickup jagah. Kul kiraya booking pakki hone ke baad samne aayega — kiraya pakka hai, koi mol-bhav nahi.',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 12),
        // Drop / Pickup — Careem style: ek saaf card, dot-line markers,
        // manzil (drop) PEHLE, pickup doosra.
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Brand.fieldBorder),
          ),
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 4),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  const SizedBox(height: 17),
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: Brand.ajrakRed,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                  Container(
                    width: 2,
                    height: 36,
                    color: Brand.fieldBorder,
                  ),
                  Container(
                    width: 12,
                    height: 12,
                    decoration: const BoxDecoration(
                      color: Brand.green,
                      shape: BoxShape.circle,
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  children: [
                    TextField(
                      controller: _dropCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Drop jagah (manzil)',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                    const Divider(height: 1, color: Brand.fieldBorder),
                    TextField(
                      controller: _pickupCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Pickup jagah',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        const Text('Qareebi Jagahen',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 4),
        const Text(
          'Kisi zone par tap karein — wohi aap ki manzil (drop) ban jayegi.',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 6),
        // Backend zones: Master ne jo ilaqa band kiya ho woh is list
        // mein nahi ata; server na mile to local kZones hi dikhte hain.
        ...store.zoneNames.map((z) => _zoneRow(z)),
        const SizedBox(height: 8),
        // v1.4.0 — SavedPlaces ke quick chips (jo mehfooz jagahen is
        // phone par hain): tap = woh jagah manzil (drop) ban jati hai
        // aur pin bhi lag jata hai (route/doori khud update). Purani
        // Ghar/Daftar wali row is ke foran neeche apni jagah barkarar.
        if (store.savedPlaces.isNotEmpty) ...[
          Wrap(
            spacing: 6,
            runSpacing: 4,
            children: [
              for (final sp in store.savedPlaces)
                ActionChip(
                  avatar: Icon(
                      sp.name == 'Ghar'
                          ? Icons.home
                          : sp.name == 'Daftar'
                              ? Icons.work
                              : Icons.place,
                      size: 16),
                  label: Text(sp.name),
                  onPressed: () => _applySavedPlace(sp),
                ),
            ],
          ),
          const SizedBox(height: 4),
        ],
        Row(
          children: [
            const Text('Save jagah: ',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            ActionChip(
              label: const Text('Ghar'),
              onPressed: () => _applyPlace(true),
            ),
            const SizedBox(width: 6),
            ActionChip(
              label: const Text('Daftar'),
              onPressed: () => _applyPlace(false),
            ),
            const Spacer(),
            TextButton.icon(
              onPressed: () => _savePlace(true),
              icon: const Icon(Icons.edit, size: 15),
              label: const Text('Ghar set', style: TextStyle(fontSize: 12)),
            ),
            TextButton.icon(
              onPressed: () => _savePlace(false),
              icon: const Icon(Icons.edit, size: 15),
              label: const Text('Daftar set', style: TextStyle(fontSize: 12)),
            ),
          ],
        ),
        // v1.4.0: maujooda pickup/drop ko kisi bhi naam se mehfooz
        // jagah banana + mehfooz jagahen manage karna.
        Row(
          children: [
            TextButton.icon(
              onPressed: _saveCurrentPlace,
              icon: const Icon(Icons.bookmark_add_outlined, size: 15),
              label: const Text('Ye jagah save karein',
                  style: TextStyle(fontSize: 12)),
            ),
            if (store.savedPlaces.isNotEmpty)
              TextButton.icon(
                onPressed: _manageSavedPlaces,
                icon: const Icon(Icons.bookmarks_outlined, size: 15),
                label: const Text('Jagahen manage',
                    style: TextStyle(fontSize: 12)),
              ),
          ],
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _nameCtrl,
          decoration: const InputDecoration(
              labelText: 'Aap ka naam', prefixIcon: Icon(Icons.person)),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _phoneCtrl,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
              labelText: 'Mobile number', prefixIcon: Icon(Icons.phone)),
        ),
        const SizedBox(height: 14),
        const Text('Ride ki Tafseel',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 8),
        ...kVehicles.map((v) => _vehicleRow(
              vehicle: v,
              selected: _vehicle == v,
              onTap: () => setState(() => _vehicle = v),
            )),
        // Safar ki doori (v1.2.2) — SIRF maloomat hai, kiraya nahi:
        // wohi _fareKm jo kiraaye ki bunyaad hai (route ki sadak wali
        // doori; route load hone se pehle seedhi doori). Drop pin lagte
        // hi nazar aati hai aur route aate hi khud update ho jati hai.
        // Kiraya (Rs) booking se pehle kahin NAHI dikhta — lock barkarar.
        if (_drop != null) ...[
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.route, size: 16, color: Brand.green),
              const SizedBox(width: 6),
              Text(
                'Safar ki doori: ${_fareKm.toStringAsFixed(1)} km',
                style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Brand.greenDark),
              ),
            ],
          ),
        ],
        const SizedBox(height: 6),
        TextField(
          controller: _noteCtrl,
          decoration: const InputDecoration(
            labelText: 'Driver ke liye note (gate number, samaan, bacche...)',
            prefixIcon: Icon(Icons.note_alt),
          ),
        ),
        const SizedBox(height: 10),
        // Waiting note — sirf ek halki si line (koi number/price nahi).
        const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.schedule, size: 15, color: Colors.black45),
            SizedBox(width: 6),
            Expanded(
              child: Text(
                'Driver ke pohanchnay ke baad thora intezaar bilkul muft hai — zyada intezaar par munasib waiting charges kul kiraya mein shamil ho jayenge.',
                style: TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        // EK bara full-width button — Careem ke "CHALO!" wali jagah par,
        // Safar ke apne gehre sabz rang mein.
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _confirmBooking,
            style: ElevatedButton.styleFrom(
              backgroundColor: Brand.deepGreen,
              padding: const EdgeInsets.symmetric(vertical: 17),
              textStyle:
                  const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
            ),
            child: const Text('Ride Pakki Karein'),
          ),
        ),
        Center(
          child: TextButton(
            onPressed: _clearBookingForm,
            child: const Text('Rehne Dein'),
          ),
        ),
      ],
    );
  }

  // --- Meri Bookings ---------------------------------------------------------

  /// TRIP SHARE (v1.4.4): ride ki tafseel — driver ka naam, gaari,
  /// number plate, pickup/drop — SYSTEM SHARE SHEET se bhejna
  /// (WhatsApp, SMS, jo app user chune). Do-phone par pehchan ASAL
  /// driver ki jati hai (booking par backend se ayi hui); share
  /// sheet kisi wajah se na khule to purana WhatsApp (wa.me)
  /// tareeqa fallback hai.
  Future<void> _shareRide(Booking b) async {
    final p = store.profile;
    final twoPhone = b.assignedDriverId.isNotEmpty && !b.acceptedHere;
    final dName = twoPhone ? b.driverName : p.name;
    final dVehicle = twoPhone
        ? (b.driverVehicleDetail.isNotEmpty
            ? b.driverVehicleDetail
            : b.vehicle)
        : p.vehicle;
    final dPlate = twoPhone ? b.driverPlate : p.plate;
    final text = 'Bozdar Safar — meri ride ki tafseel:\n'
        'Driver: $dName ($dVehicle${dPlate.isEmpty ? '' : ' · Number plate $dPlate'})\n'
        'Route: ${b.pickupLabel} → ${b.dropLabel}\n'
        'Waqt: ${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)}\n'
        'Main is ride mein safar kar raha/rahi hun.';
    try {
      await Share.share(text, subject: 'Bozdar Safar — meri ride');
      return;
    } catch (_) {
      // Share sheet na khuli — WhatsApp wala purana tareeqa.
    }
    final uri = Uri.parse('https://wa.me/?text=${Uri.encodeComponent(text)}');
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) _snack('Share nahi ho saka.');
  }

  /// Driver ko call — v1.4.2: do-phone par ASAL driver ka number
  /// booking par backend se ata hai (driverPhone); same-device par
  /// woh khaali hota hai to is phone ke profile number par girte
  /// hain (pilot wala purana rawaiya).
  Future<void> _callDriverFor(Booking b) async {
    final phone = (b.driverPhone.isNotEmpty
            ? b.driverPhone
            : store.profile.phone)
        .trim();
    if (phone.isEmpty) {
      _snack('Driver ka number abhi set nahi hai.');
      return;
    }
    final ok = await launchUrl(Uri.parse('tel:$phone'));
    if (!ok && mounted) _snack('Call nahi ho saki.');
  }

  /// Master ko Message screen (v1.2.7) — "Meri Bookings" ke neeche
  /// wale darwaze se khulti hai; booking wali screen/flow bilkul
  /// nahi chheri gayi (display lock).
  Future<void> _openMessages() async {
    await Navigator.of(context).push(
      MaterialPageRoute<bool>(
        builder: (_) => MasterMessagesScreen(store: store, role: 'passenger'),
      ),
    );
    if (mounted) setState(() {});
  }

  Widget _myBookingsView() {
    return Column(
      children: [
        // Meri Profile (v1.4.4): naam/number ki haalat, Sharait +
        // Privacy ke darwaze, aur account delete — legal.dart ki
        // PassengerProfileScreen.
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
          child: Card(
            margin: EdgeInsets.zero,
            child: ListTile(
              leading: const Icon(Icons.person, color: Brand.green),
              title: const Text('Meri Profile',
                  style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text(
                  'Meri maloomat, Sharait, Privacy Policy aur account delete.'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => PassengerProfileScreen(store: store),
                ),
              ),
            ),
          ),
        ),
        // Master ko Message (v1.2.7): masla/shikayat seedha Master
        // (head) ko — hamesha nazar ane wala darwaza, bookings hon
        // ya na hon.
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
          child: Card(
            margin: EdgeInsets.zero,
            child: ListTile(
              leading: const Icon(Icons.mail_outline, color: Brand.green),
              title: const Text('Master ko Message',
                  style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text(
                  'Koi masla ya shikayat ho to seedha Master (head) ko message bhejein.'),
              trailing: const Icon(Icons.chevron_right),
              onTap: _openMessages,
            ),
          ),
        ),
        Expanded(child: _myBookingsList()),
      ],
    );
  }

  Widget _myBookingsList() {
    final list = store.bookings;
    if (list.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Abhi koi booking nahi hai.\nBooking wale hisse se pehli ride pakki karein.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15, color: Colors.black54),
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: list.length,
      itemBuilder: (context, i) {
        final b = list[i];
        final p = store.profile;
        final confirmed = b.status == 'accepted' || b.status == 'arrived';
        // v1.4.0: two-phone dispatch se mili driver ki LIVE jagah —
        // mojood ho to ETA isi se, warna same-device wali jagah se.
        final remote = _remoteDriverPos[b.id];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.route, color: Brand.green),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text('${b.pickupLabel} → ${b.dropLabel}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 15)),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  '${b.vehicle} · ${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)}',
                  style: const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                if (b.note.isNotEmpty)
                  Text('Note: ${b.note}',
                      style: const TextStyle(fontSize: 12)),
                // v1.4.4: cancel / early-complete ki WAJAH record
                // mein saaf nazar aye — yehi woh saboot hai jo
                // Master ko bhi backend par dikhta hai.
                if (b.status == 'cancelled' && b.cancelReason.isNotEmpty)
                  Text('Mansookh ki wajah: ${b.cancelReason}',
                      style: const TextStyle(
                          fontSize: 12, color: Brand.ajrakRed)),
                if (b.status == 'completed' && b.endedEarly)
                  Text(
                      'Beech raaste mein yahin khatam hui${b.endReason.isEmpty ? '' : ' — wajah: ${b.endReason}'}',
                      style: const TextStyle(
                          fontSize: 12, color: Colors.black54)),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Chip(
                      label: Text(kStatusUrdu[b.status] ?? b.status),
                      backgroundColor: confirmed
                          ? const Color(0xFFDFF5E6)
                          : b.status == 'completed'
                              ? const Color(0xFFE8F0FE)
                              : const Color(0xFFF3E9C8),
                      labelStyle: const TextStyle(fontSize: 12),
                    ),
                    const Spacer(),
                    Text(rs(b.total),
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 17)),
                  ],
                ),
                if (b.status == 'completed') ...[
                  Text(
                    'Total kiraya: ${rs(b.total)} · Doori: ${b.distanceKm.toStringAsFixed(1)} km',
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  // v1.4.0: mukammal ride ki RASEED (dialog + share).
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () => showReceiptDialog(context, store, b),
                      icon: const Icon(Icons.receipt_long, size: 18),
                      label: const Text('Raseed Dekhein'),
                    ),
                  ),
                  const SizedBox(height: 6),
                  // v1.4.4: is ride ki REPORT / Shikayat — Master
                  // inbox mein ride ke hawale ke saath jati hai.
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () =>
                          showReportDialog(context, store, b, role: 'passenger'),
                      icon: const Icon(Icons.report_outlined, size: 18),
                      label: const Text('Report / Shikayat Karein'),
                      style: OutlinedButton.styleFrom(
                          foregroundColor: Brand.ajrakRed),
                    ),
                  ),
                  const Divider(),
                  // v1.4.0: driver ki rating — 1–5 sitare + comment.
                  RatingRow(store: store, booking: b),
                ],
                if (confirmed) ...[
                  const Divider(),
                  const Text('Driver ki Pehchan',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  // v1.4.2: do-phone par pehchan ASAL driver ki
                  // (booking par backend se ayi hui); same-device
                  // par pehle wala local profile hi dikhta hai.
                  if (b.assignedDriverId.isNotEmpty && !b.acceptedHere)
                    Text(
                        '${b.driverName} · ${b.driverVehicleDetail.isNotEmpty ? b.driverVehicleDetail : b.vehicle}${b.driverPlate.isEmpty ? '' : ' · Plate ${b.driverPlate}'}')
                  else
                    Text(
                        '${p.name} · ${p.vehicle}${p.plate.isEmpty ? '' : ' · Plate ${p.plate}'} · ${p.zone}'),
                  if (store.backendRatingAvg != null)
                    Row(
                      children: [
                        const Icon(Icons.star, size: 15, color: Brand.gold),
                        const SizedBox(width: 4),
                        Text(
                          'Driver rating: ${store.backendRatingAvg!.toStringAsFixed(1)}',
                          style: const TextStyle(
                              fontSize: 12.5, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                  const Text(
                    'Driver CNIC-verified hai aur har booking record mein hai.',
                    style: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                  _DriverEtaLine(
                      store: store,
                      booking: b,
                      remoteLat: remote?.lat,
                      remoteLng: remote?.lng),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _callDriverFor(b),
                          icon: const Icon(Icons.call, size: 18),
                          label: const Text('Madad — Driver ko call karein'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Brand.ajrakRed,
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            textStyle: const TextStyle(
                                fontSize: 13, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () => _shareRide(b),
                      icon: const Icon(Icons.share, size: 18),
                      label: const Text('Ride ghar walon ko WhatsApp karein'),
                    ),
                  ),
                  const SizedBox(height: 6),
                  // v1.4.0: SOS — active ride ke doran hifazat.
                  SosButton(store: store, booking: b, role: 'passenger'),
                ],
                if (b.status == 'pending')
                  const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text(
                      'Booking driver ko bheji gayi hai — Driver Mode mein is ka jawab ayega.',
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  // --- Monthly package ---------------------------------------------------------

  bool get _monthlyReady =>
      _mPickupCtrl.text.trim().isNotEmpty &&
      _mDropCtrl.text.trim().isNotEmpty;

  int get _monthlyTotal =>
      Fares.monthlyAmount(_mVehicle, _mRouteKm, _mDays);

  /// Monthly form ke pins se asal OSRM road route ginna (v1.4.0):
  /// dono pins lagte hi route ata hai aur _mRouteKm usi road-km par
  /// set ho jata hai — monthly hisaab phir asal sadak wali doori par
  /// banta hai. Koi pin na ho / route fail ho to mojooda km rehti
  /// hai (2.0 ka placeholder sirf tab, jab dono pins abhi na lage
  /// hon). Route ka koi number user ko NAHI dikhta — sirf kul
  /// monthly raqam package pakka hone par dialog mein ati hai.
  Future<void> _refreshMonthlyRoute() async {
    final from = _mPickupPin;
    final to = _mDropPin;
    if (from == null || to == null) return;
    final token = ++_mRouteToken;
    try {
      final r = await RouteService.fetch(
        LatLng(from.latitude, from.longitude),
        LatLng(to.latitude, to.longitude),
      );
      if (!mounted || token != _mRouteToken) return;
      final km = (r.distanceM / 1000);
      if (km <= 0) return;
      setState(() {
        _mRouteKm = km;
        _mRouteIsRoad = true;
      });
    } catch (_) {
      // Route na mila — mojooda km hi rahegi (crash nahi).
    }
  }

  /// Monthly field ke text se zone ka pin nikalna — user zone ka
  /// naam likhe (masalan "Clifton") to kZoneCoords se pin mil jata
  /// hai; koi aur text ho to pin saaf ho jata hai.
  LatLng? _zonePinFor(String text) => kZoneCoords[text.trim()];

  void _onMonthlyPickupChanged() {
    _mPickupPin = _zonePinFor(_mPickupCtrl.text);
    _refreshMonthlyRoute();
  }

  void _onMonthlyDropChanged() {
    _mDropPin = _zonePinFor(_mDropCtrl.text);
    _refreshMonthlyRoute();
  }

  Future<void> _confirmMonthly() async {
    if (!_monthlyReady) {
      _snack('Rozana pickup aur rozana drop dono likhein.');
      return;
    }
    // Dono pins mojood hon lekin route abhi na aya ho (ya confirm se
    // pehle fields badle gaye hon) to pakka karne se pehle EK dafa
    // asal route ki koshish — bilkul booking flow jaisa usool.
    // Route na mile to mojooda km par hi package banta hai.
    if (_mPickupPin != null && _mDropPin != null && !_mRouteIsRoad) {
      try {
        await _refreshMonthlyRoute()
            .timeout(const Duration(seconds: 8), onTimeout: () {});
      } catch (_) {
        // Koi baat nahi — mojooda km par aage barhte hain.
      }
      if (!mounted) return;
    }
    final pkg = MonthlyPackage(
      id: store.newId(),
      passengerName: _nameCtrl.text.trim(),
      pickup: _mPickupCtrl.text.trim(),
      drop: _mDropCtrl.text.trim(),
      vehicle: _mVehicle,
      routeKm: _mRouteKm,
      days: _mDays,
      monthlyAmount: _monthlyTotal,
      createdAt: DateTime.now(),
    );
    await store.addMonthly(pkg);
    if (!mounted) return;
    // Kul monthly raqam PEHLI dafa yahin nazar aati hai — package pakka
    // hone ke BAAD (owner ka lock, v1.0.7). Form mein koi amount nahi.
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Brand.green, size: 26),
            SizedBox(width: 8),
            Text('Package Pakka Ho Gaya'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('${pkg.pickup} → ${pkg.drop}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text('${pkg.vehicle} · ${pkg.days} din',
                style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Brand.deepGreen,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                children: [
                  const Text('KUL MONTHLY RAQAM',
                      style: TextStyle(
                          color: Brand.goldLight,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.2)),
                  Text(rs(pkg.monthlyAmount),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.w900)),
                ],
              ),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Theek Hai'),
          ),
        ],
      ),
    );
    if (!mounted) return;
    setState(() {});
  }

  void _clearMonthly() {
    setState(() {
      _mPickupCtrl.clear();
      _mDropCtrl.clear();
      _mVehicle = 'Rickshaw';
      _mRouteKm = 2.0;
      _mDays = 26;
      _mPickupPin = null;
      _mDropPin = null;
      _mRouteIsRoad = false;
    });
    _snack('Koi package nahi bana — sab saaf kar diya gaya.');
  }

  Widget _monthlyView() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('Monthly Package',
            style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w900,
                color: Brand.greenDark)),
        const SizedBox(height: 4),
        const Text(
          'Rickshaw / gaari mahine ke liye pakki karein — school, office ya madrassa ke liye rozana wohi pehchana driver, wohi jagah, wohi waqt.',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _mPickupCtrl,
          decoration: const InputDecoration(
              labelText: 'Rozana PICKUP jagah',
              prefixIcon: Icon(Icons.home)),
          onChanged: (_) => setState(_onMonthlyPickupChanged),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _mDropCtrl,
          decoration: const InputDecoration(
              labelText: 'Rozana DROP jagah',
              prefixIcon: Icon(Icons.school)),
          onChanged: (_) => setState(_onMonthlyDropChanged),
        ),
        // Zone quick-picks — tap se pickup/drop ka pin bhi lag jata
        // hai (asal route ke liye). Koi price/rate yahan NAHI dikhta
        // (fare lock) — sirf jagah ke naam hain, booking form jaisi.
        const SizedBox(height: 6),
        Wrap(
          spacing: 6,
          runSpacing: 2,
          children: [
            for (final z in store.zoneNames)
              ActionChip(
                label: Text(z, style: const TextStyle(fontSize: 12)),
                onPressed: () {
                  setState(() {
                    if (_mPickupCtrl.text.trim().isEmpty ||
                        _mDropCtrl.text.trim().isNotEmpty) {
                      _mPickupCtrl.text = z;
                      _onMonthlyPickupChanged();
                    } else {
                      _mDropCtrl.text = z;
                      _onMonthlyDropChanged();
                    }
                  });
                },
              ),
          ],
        ),
        const SizedBox(height: 10),
        const Text('Gaari',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 8),
        ...kVehicles.map((v) => _vehicleRow(
              vehicle: v,
              selected: _mVehicle == v,
              onTap: () => setState(() => _mVehicle = v),
            )),
        const SizedBox(height: 4),
        const Text('Mahine mein kitne din?',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: _dayChips
              .map((d) => ChoiceChip(
                    label: Text('$d din'),
                    selected: _mDays == d,
                    onSelected: (_) => setState(() => _mDays = d),
                  ))
              .toList(),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _confirmMonthly,
                child: const Text('Monthly Package Pakka Karein'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton(
                onPressed: _clearMonthly,
                child: const Text('Rehne Dein'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        const Text('Mere Monthly Packages',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.monthlyPackages.isEmpty)
          const Text('Abhi koi monthly package nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...store.monthlyPackages.map((p) => Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: const Icon(Icons.calendar_month, color: Brand.green),
                title: Text('${p.pickup} → ${p.drop}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(
                    '${p.vehicle} · ${p.days} din · ${fmtDate(p.createdAt)}'),
                trailing: Text(rs(p.monthlyAmount),
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 15)),
              ),
            )),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// "Driver Dhoonda Ja Raha Hai" — Careem ki "Finding your Captain" style
// screen (v1.0.8). Ye booking ki HALAT wali screen hai: booking darj ho
// chuki hai aur driver ke jawab ka intezaar hai — koi jhooti driver
// assignment nahi dikhayi jati. Pops with 'bookings' ya 'cancelled'.
// ---------------------------------------------------------------------------

class _FindingDriverView extends StatefulWidget {
  final AppStore store;
  final Booking booking;
  const _FindingDriverView({required this.store, required this.booking});

  @override
  State<_FindingDriverView> createState() => _FindingDriverViewState();
}

class _FindingDriverViewState extends State<_FindingDriverView> {
  // v1.4.0 two-phone dispatch (c): is screen par ride row ka poll
  // (~15s) — driver ki LIVE jagah (rides.driver_lat/lng) ETA ke
  // liye, aur backend par badli status ka notification diff.
  Timer? _poll;
  double? _remoteLat;
  double? _remoteLng;
  bool _ratingPromptShown = false;

  AppStore get store => widget.store;
  Booking get booking => widget.booking;

  @override
  void initState() {
    super.initState();
    _poll = Timer.periodic(
        const Duration(seconds: 15), (_) => unawaited(_pollOnce()));
    unawaited(_pollOnce());
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybePrompt());
  }

  @override
  void dispose() {
    _poll?.cancel();
    super.dispose();
  }

  Future<void> _pollOnce() async {
    final row = await Backend.fetchRideRow(booking.id);
    if (row == null || !mounted) return;
    final lat = (row['driver_lat'] as num?)?.toDouble();
    final lng = (row['driver_lng'] as num?)?.toDouble();
    if (lat != null && lng != null && (lat != _remoteLat || lng != _remoteLng)) {
      setState(() {
        _remoteLat = lat;
        _remoteLng = lng;
      });
    }
    final st = row['status'];
    if (st is String && st.isNotEmpty && st != booking.status) {
      await store.observeBookingStatuses('passenger',
          remoteStatus: {booking.id: st});
    }
    // v1.4.2: asal haalat + driver tafseel local booking par —
    // is screen ka title, ETA line aur rating prompt sab isi par
    // chalte hain (do-phone par yehi woh kadri thi jo gayab thi).
    await Backend.applyRemoteRowToBooking(store, booking, row);
    if (mounted) {
      setState(() {});
      _maybePrompt();
    }
  }

  /// Ride complete nazar aye (local ya backend par) aur rating
  /// abhi na di ho to EK dafa star prompt khud khul jata hai —
  /// passenger chahe to band kar ke Meri Bookings se baad mein
  /// bhi de sakta hai.
  void _maybePrompt() {
    if (!mounted || _ratingPromptShown) return;
    final idx = store.bookings.indexWhere((x) => x.id == booking.id);
    final status = idx >= 0 ? store.bookings[idx].status : booking.status;
    if (status != 'completed') return;
    if (store.ratingFor(booking.id) != null) return;
    _ratingPromptShown = true;
    _showRatingDialog();
    if (mounted) setState(() {});
  }

  Future<void> _showRatingDialog() async {
    var stars = 0;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: const Text('Ride kaisi rahi?'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                  '${booking.pickupLabel} → ${booking.dropLabel}\nDriver ${booking.driverName} ko rating dein:',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 13)),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (var i = 1; i <= 5; i++)
                    IconButton(
                      onPressed: () => setD(() => stars = i),
                      icon: Icon(
                        i <= stars ? Icons.star : Icons.star_border,
                        color: Brand.gold,
                        size: 34,
                      ),
                    ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Baad Mein'),
            ),
            ElevatedButton(
              onPressed: stars <= 0
                  ? null
                  : () async {
                      await store.saveRating(RideRating(
                        bookingId: booking.id,
                        driverId: booking.assignedDriverId.isNotEmpty
                            ? booking.assignedDriverId
                            : store.driverId,
                        driverName: booking.driverName,
                        passengerName: booking.passengerName,
                        stars: stars,
                        comment: '',
                        createdAt: DateTime.now(),
                      ));
                      if (ctx.mounted) Navigator.pop(ctx);
                    },
              child: const Text('Rating Bhejein'),
            ),
          ],
        ),
      ),
    );
  }

  IconData _vehicleIcon(String v) => v == 'Car'
      ? Icons.directions_car
      : v == 'Bike'
          ? Icons.two_wheeler
          : v == 'Taxi'
              ? Icons.local_taxi
              : v == 'Van'
                  ? Icons.airport_shuttle
                  : Icons.electric_rickshaw;

  Future<void> _callDriver(BuildContext context) async {
    // v1.4.2: asal driver ka number booking se (backend), warna
    // same-device pilot ka profile number.
    final phone = (booking.driverPhone.isNotEmpty
            ? booking.driverPhone
            : store.profile.phone)
        .trim();
    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Driver ka number abhi set nahi hai.')),
      );
      return;
    }
    final ok = await launchUrl(Uri.parse('tel:$phone'));
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Call nahi ho saki.')),
      );
    }
  }

  /// Cancel — v1.4.4 (malik ki khaas shart): wajah LAZMI
  /// poochhi jati hai (mushtarka showReasonSheet — tay-shuda
  /// list + apni baat) aur ride ke record ke saath hamesha ke
  /// liye mehfooz hoti hai (Master ko backend par nazar ati hai).
  Future<void> _showCancelSheet(BuildContext context) async {
    final reason = await showReasonSheet(
      context,
      title: 'Ride kyun mansookh kar rahe hain?',
      options: kRideReasonOptions,
    );
    if (reason == null || !context.mounted) return;
    await store.cancelBooking(booking, reason: reason);
    if (context.mounted) Navigator.pop(context, 'cancelled');
  }

  /// Beech raaste mein ride WAHEEN khatam (early complete) —
  /// v1.4.4: sawari yahan utar jaye to wajah ke saath ride
  /// mukammal darj hoti hai; wajah record mein rehti hai aur
  /// Master ko nazar ati hai. Us ke baad rating ka prompt bhi
  /// aam usool se khul jata hai.
  Future<void> _endRideHere(BuildContext context) async {
    final reason = await showReasonSheet(
      context,
      title: 'Ride yahan kyun khatam kar rahe hain?',
      options: kRideReasonOptions,
      submitLabel: 'Ride Yahan Khatam Karein',
    );
    if (reason == null || !context.mounted) return;
    await store.passengerEndRideEarly(booking, reason);
    if (!context.mounted) return;
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Ride yahin khatam ho gayi — wajah darj hai.')),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybePrompt());
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final b = booking;
        final pickup = LatLng(b.pickupLat, b.pickupLng);
        final drop = LatLng(b.dropLat, b.dropLng);
        final searching = b.status == 'pending';
        final title = searching
            ? 'Driver Dhoonda Ja Raha Hai'
            : (kStatusUrdu[b.status] ?? b.status);
        return Scaffold(
          body: Stack(
            children: [
              Positioned.fill(
                child: SafarRouteMap(
                  pickup: pickup,
                  drop: b.hasDropPin ? drop : null,
                  interactive: true,
                ),
              ),
              // Safed sheet — Careem style, gol upar kinare + drag handle.
              Positioned(
                left: 10,
                right: 10,
                bottom: 10,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(26),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.22),
                        blurRadius: 18,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Center(
                        child: Container(
                          width: 44,
                          height: 5,
                          decoration: BoxDecoration(
                            color: Brand.fieldBorder,
                            borderRadius: BorderRadius.circular(3),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(title,
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              color: Brand.greenDark)),
                      if (searching) ...[
                        const SizedBox(height: 10),
                        const _FindingProgressLine(),
                        const SizedBox(height: 8),
                        const Text(
                          'Booking darj ho gayi hai — driver ke jawab ka intezaar karein.',
                          style:
                              TextStyle(fontSize: 12.5, color: Colors.black54),
                        ),
                        // v1.4.0 two-phone dispatch: booking banate waqt
                        // backend se mili qareeb driver ki ittila — sirf
                        // maloomat, koi price NAHI (fare lock barkarar).
                        if (store.dispatchNote.isNotEmpty) ...[
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              const Icon(Icons.radar,
                                  size: 15, color: Brand.green),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  store.dispatchNote,
                                  style: const TextStyle(
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.w700,
                                      color: Brand.greenDark),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ] else ...[
                        const SizedBox(height: 4),
                        const Text(
                          'Booking ki halat upar likhi hai — tafseel neeche dekhein.',
                          style:
                              TextStyle(fontSize: 12.5, color: Colors.black54),
                        ),
                      ],
                      const SizedBox(height: 14),
                      // Route dots: grey = pickup, green = drop.
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            children: [
                              const SizedBox(height: 3),
                              Container(
                                width: 11,
                                height: 11,
                                decoration: const BoxDecoration(
                                  color: Colors.grey,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              Container(
                                width: 2,
                                height: 26,
                                color: Brand.fieldBorder,
                              ),
                              Container(
                                width: 11,
                                height: 11,
                                decoration: const BoxDecoration(
                                  color: Brand.green,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(b.pickupLabel,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14)),
                                const SizedBox(height: 20),
                                Text(b.dropLabel,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      const Text('Booking ki Tafseel',
                          style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                              color: Colors.black54)),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(_vehicleIcon(b.vehicle),
                              color: Brand.green, size: 26),
                          const SizedBox(width: 10),
                          Text(b.vehicle,
                              style: const TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w800)),
                          const Spacer(),
                          const Text('Total Kiraya: ',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.black54)),
                          Text(rs(b.total),
                              style: const TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w900)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      // v1.4.2 (brief §5): asal driver ki pehchan —
                      // naam, gaari, plate (backend se; data na ho
                      // to kuch nahi dikhta, jaali tafseel kabhi nahi).
                      if ((b.status == 'accepted' || b.status == 'arrived') &&
                          b.assignedDriverId.isNotEmpty &&
                          !b.acceptedHere) ...[
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 20,
                              backgroundColor: Brand.green,
                              child: Text(
                                b.driverName.isNotEmpty
                                    ? b.driverName[0].toUpperCase()
                                    : '?',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 17),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(b.driverName,
                                      style: const TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w900)),
                                  Text(
                                      '${b.driverVehicleDetail.isNotEmpty ? b.driverVehicleDetail : b.vehicle}${b.driverPlate.isEmpty ? '' : ' · ${b.driverPlate}'}',
                                      style: const TextStyle(
                                          fontSize: 12.5,
                                          color: Colors.black54)),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                      ],
                      _DriverEtaLine(
                          store: store,
                          booking: b,
                          remoteLat: _remoteLat,
                          remoteLng: _remoteLng),
                      // v1.4.0: driver ki rating assigned-driver card par
                      // (backend ausat dastiyab ho to) — warna kuch nahi.
                      if (store.backendRatingAvg != null &&
                          (b.status == 'accepted' ||
                              b.status == 'arrived' ||
                              b.status == 'completed'))
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Row(
                            children: [
                              const Icon(Icons.star,
                                  size: 15, color: Brand.gold),
                              const SizedBox(width: 4),
                              Text(
                                'Driver rating: ${store.backendRatingAvg!.toStringAsFixed(1)}',
                                style: const TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        ),
                      InkWell(
                        onTap: () => _callDriver(context),
                        borderRadius: BorderRadius.circular(10),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 6),
                          child: Row(
                            children: [
                              Icon(Icons.headset_mic,
                                  color: Brand.ajrakRed, size: 21),
                              SizedBox(width: 10),
                              Text('Madad Chahiye?',
                                  style: TextStyle(
                                      color: Brand.ajrakRed,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 14)),
                              Spacer(),
                              Icon(Icons.call,
                                  color: Brand.ajrakRed, size: 18),
                            ],
                          ),
                        ),
                      ),
                      // v1.4.0: SOS — ride active ho (accepted/arrived)
                      // to hifazat ka button yahin bhi.
                      if (b.status == 'accepted' || b.status == 'arrived') ...[
                        const SizedBox(height: 6),
                        SosButton(
                            store: store, booking: b, role: 'passenger'),
                        // v1.4.4: beech raaste mein yahan utarna ho
                        // to ride WAHEEN khatam — wajah ke saath;
                        // ya ride mansookh — wajah ke saath. Dono
                        // ki wajah record mein hamesha rehti hai.
                        const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () => _endRideHere(context),
                            icon: const Icon(Icons.flag, size: 18),
                            label: const Text('Ride Yahan Khatam Karein'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Brand.deepGreen,
                              padding:
                                  const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                        Center(
                          child: TextButton(
                            onPressed: () => _showCancelSheet(context),
                            style: TextButton.styleFrom(
                              foregroundColor: Brand.ajrakRed,
                            ),
                            child: const Text('Ride Mansookh Karein'),
                          ),
                        ),
                      ],
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () =>
                              Navigator.pop(context, 'bookings'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Brand.deepGreen,
                            padding:
                                const EdgeInsets.symmetric(vertical: 15),
                          ),
                          child: const Text('Meri Bookings Dekhein'),
                        ),
                      ),
                      // v1.4.0: ride complete ho jaye to yahin se
                      // RASEED + RATING.
                      if (b.status == 'completed') ...[
                        const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: () =>
                                showReceiptDialog(context, store, b),
                            icon: const Icon(Icons.receipt_long, size: 18),
                            label: const Text('Raseed Dekhein'),
                          ),
                        ),
                        const SizedBox(height: 8),
                        RatingRow(store: store, booking: b),
                      ],
                      if (searching)
                        Center(
                          child: TextButton(
                            onPressed: () => _showCancelSheet(context),
                            style: TextButton.styleFrom(
                              foregroundColor: Brand.ajrakRed,
                            ),
                            child: const Text('Ride Mansookh Karein'),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Searching wali sabz progress line — bharti hui animation.
class _FindingProgressLine extends StatefulWidget {
  const _FindingProgressLine();

  @override
  State<_FindingProgressLine> createState() => _FindingProgressLineState();
}

class _FindingProgressLineState extends State<_FindingProgressLine>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1500),
  )..repeat();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(4),
      child: Container(
        height: 4,
        color: Brand.fieldBorder,
        alignment: Alignment.centerLeft,
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (context, _) => FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: 0.12 + 0.88 * _ctrl.value,
            child: Container(color: Brand.green),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Driver ki doori + aane ka waqt (ETA) — v1.2.4. Sirf ACCEPTED booking
// par dikhta hai (driver tay ho chuka aur aa raha hai); us se pehle
// (pending/searching) kuch nahi — booking se pehle wali "koi maloomat
// nahi" wali lock bilkul barkarar hai.
//
// Doori = driver ki akhri maloom GPS jagah (v1.4.0: pehle backend
// ride row ki driver_lat/lng — two-phone live dispatch; warna
// DriverProfile.lastLat/lng, jo Driver Mode ke refresh/qubool/
// nav-stream se taza hoti hai) se pickup tak ki seedhi doori
// (latlong Distance, 1 decimal km).
// Waqt = pehle OSRM route ka asal duration (RouteService cache/fetch,
// driver → pickup), woh na mile to sheher ki ausat raftaar se andaza
// (neeche wale INTERNAL constants; kabhi display nahi hote):
// Rickshaw 20, Bike 30, Car 25 km/h. Minute hamesha UP round, kam az
// kam 1. Koi jhoota countdown nahi — value sirf position/store ke
// taza hone par badalti hai.
// Driver ki position maloom hi na ho to saaf likha ata hai ke
// location jald nazar aayegi — koi number nahi banaya jata.
// ---------------------------------------------------------------------------

const Map<String, double> _kEtaCitySpeedKmh = {
  'Rickshaw': 20,
  'Bike': 30,
  'Car': 25,
};

class _DriverEtaLine extends StatefulWidget {
  final AppStore store;
  final Booking booking;

  /// v1.4.0 two-phone dispatch: backend ride row (rides.driver_lat/
  /// driver_lng) se mili driver ki LIVE jagah. Mojood ho to ETA isi
  /// se banta hai; warna DriverProfile.lastLat/lastLng wala mojooda
  /// same-device tareeqa — pilot bilkul barkarar.
  final double? remoteLat;
  final double? remoteLng;
  const _DriverEtaLine(
      {required this.store,
      required this.booking,
      this.remoteLat,
      this.remoteLng});

  @override
  State<_DriverEtaLine> createState() => _DriverEtaLineState();
}

class _DriverEtaLineState extends State<_DriverEtaLine> {
  String _sig = '';
  int? _osrmEtaMin;

  Booking get b => widget.booking;
  AppStore get store => widget.store;

  /// Asal driver ki jagah — pehle backend wali live jagah, warna
  /// is phone par maloom akhri jagah.
  (double, double)? _driverPos() {
    final lat = widget.remoteLat ?? store.profile.lastLat;
    final lng = widget.remoteLng ?? store.profile.lastLng;
    if (lat == null || lng == null) return null;
    return (lat, lng);
  }

  /// Driver ki jagah maloom ho aur booking ke paas pickup pin ho to
  /// seedhi doori (km); warna null (= koi number nahi dikhana).
  double? _driverKm() {
    final pos = _driverPos();
    if (pos == null) return null;
    if (b.pickupLat == 0 && b.pickupLng == 0) return null;
    return const Distance().as(LengthUnit.Kilometer,
        LatLng(pos.$1, pos.$2), LatLng(b.pickupLat, b.pickupLng));
  }

  /// Is hisaab ki pehchan — booking, us ki halat, driver ki jagah
  /// (3 decimal tak) aur pickup. In mein se kuch badle to ETA dobara
  /// gina jata hai; warna purani value hi rehti hai (churn nahi).
  String _sigNow() {
    final pos = _driverPos();
    final p = pos == null
        ? 'none'
        : '${pos.$1.toStringAsFixed(3)},${pos.$2.toStringAsFixed(3)}';
    return '${b.id}|${b.status}|$p|'
        '${b.pickupLat.toStringAsFixed(3)},${b.pickupLng.toStringAsFixed(3)}';
  }

  int _speedEtaMin(double km) {
    final speed = _kEtaCitySpeedKmh[b.vehicle] ?? 20;
    final mins = (km / speed * 60).ceil();
    return mins < 1 ? 1 : mins;
  }

  Future<void> _resolve() async {
    final sig = _sig;
    final pos = _driverPos();
    if (pos == null) return;
    if (b.pickupLat == 0 && b.pickupLng == 0) return;
    try {
      final r = await RouteService.fetch(
          LatLng(pos.$1, pos.$2), LatLng(b.pickupLat, b.pickupLng));
      if (!mounted || _sig != sig) return;
      if (!r.isStraightFallback && r.durationS > 0) {
        final mins = (r.durationS / 60).ceil();
        setState(() => _osrmEtaMin = mins < 1 ? 1 : mins);
      }
    } catch (_) {
      // Khamosh — raftaar wala andaza hi rehta hai.
    }
  }

  @override
  void initState() {
    super.initState();
    _sig = _sigNow();
    unawaited(_resolve());
  }

  @override
  void didUpdateWidget(_DriverEtaLine oldWidget) {
    super.didUpdateWidget(oldWidget);
    final now = _sigNow();
    if (now != _sig) {
      _sig = now;
      _osrmEtaMin = null;
      unawaited(_resolve());
    }
  }

  @override
  Widget build(BuildContext context) {
    // Sirf tab jab driver tay ho aur aa raha ho. Arrived par driver
    // pohanch chuka hota hai — wahan halat wali line hi kaafi hai.
    if (b.status != 'accepted') return const SizedBox.shrink();
    final km = _driverKm();
    if (km == null) {
      return const Padding(
        padding: EdgeInsets.only(bottom: 10),
        child: Row(
          children: [
            Icon(Icons.near_me, size: 17, color: Colors.black45),
            SizedBox(width: 6),
            Expanded(
              child: Text('Driver ki location jald nazar aayegi',
                  style: TextStyle(fontSize: 13.5, color: Colors.black54)),
            ),
          ],
        ),
      );
    }
    final eta = _osrmEtaMin ?? _speedEtaMin(km);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          const Icon(Icons.near_me, size: 17, color: Brand.green),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              'Driver ${km.toStringAsFixed(1)} km door hai · '
              'Takreeban $eta minute mein pahunchega',
              style: const TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w800,
                  color: Brand.greenDark),
            ),
          ),
        ],
      ),
    );
  }
}
