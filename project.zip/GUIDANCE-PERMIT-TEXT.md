# v1.4.14 — Nayi awaaz wali hidayat: Route Permit + Fitness wala qadam

**Zaroori file (abhi banana baqi hai):** `assets/guidance/guidance_permit.mp3`
- Wohi awaaz/andaaz jo maujooda guidance set ka hai (guidance_licence.mp3 wali hi awaaz), offline bundle ke liye.
- File `assets/guidance/` mein rakhte hi app khud chala legi — code mein wiring ho chuki hai
  (registration wizard ka qadam 6 + dono photo khano ki guideAsset).
- Jab tak mp3 nahi banti, GuideAudio khamoshi se fail hota hai — registration NAHI rukti.

## Bolne wali lines (Roman Urdu script — TTS ke liye ain yahi parhna hai)

> Assalam-o-Alaikum bhai. Ye qadam Route Permit aur Fitness Certificate ka hai.
> Agar ye dono kagaz aap ke paas hain to in ki tasveer yahan laga dein — aap ka record pakka ho jayega.
> Aur agar ye kagaz abhi aap ke paas nahi hain to ghabrane ki koi baat nahi — aap ki ID nahi rukegi.
> Lekin ye baat saaf samajh lein: Route Permit aur Fitness Certificate rakhna aap ki apni zimmedari hai.
> Ye kagaz na honay ki wajah se agar challan ho jaye, gaari band ho jaye, ya koi aur nuqsan ho jaye, to us ke zimmedar aap khud honge — Bozdar Safar us ka zimmedar nahi hoga.
> Ye app drivers ke liye bilkul free hai — koi fee nahi li jati. Ye app drivers aur ghareebon ke bhale ke liye banayi gayi hai, is liye har driver apne kagaz khud poore rakhe.
> Kagaz mil jayein to baad mein Profile ke "Mere Kagaz" hisse se in ki tasveer laga sakte hain.
> Account banana chahein to neeche wali tasdeeq par nishan laga kar Aage dabayein.
> Aur agar abhi account nahi banana chahte to bhi aap ki marzi hai — neeche "Abhi nahi" wala button dabakar yahin se bahir nikal sakte hain. Koi zabardasti nahi hai.
