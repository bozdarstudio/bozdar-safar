import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import 'store.dart';
import 'theme.dart';
import 'legal.dart';
import 'messages.dart';
import 'health_engine.dart';
import 'ride_chat.dart';
import 'notifications.dart';
import 'backend.dart';
import 'duty_service.dart';
import 'otp.dart';
import 'photo_avatar.dart';
import 'route_service.dart';
import 'booking_flow.dart';
import 'lang.dart';
import 'place_search.dart';
import 'safar_map.dart';
import 'main.dart' show ModeToggleButton, UpdateBanner;

const LatLng kKarachiCenter = LatLng(24.8608, 67.0011); // Karachi sheher

const Map<String, String> kStatusUrdu = {
  'pending': 'Driver ke jawab ka intezaar',
  'accepted': 'Driver ne qubool kar li',
  'arrived': 'Driver pohanch gaya hai',
  'completed': 'Ride mukammal',
  'cancelled': 'Mansookh',
  'noshow': 'Sawari nahi aayi (No-show)',
};

class PassengerSide extends StatefulWidget {
  final AppStore store;
  final VoidCallback onSwitchToDriver;
  const PassengerSide(
      {super.key, required this.store, required this.onSwitchToDriver});

  @override
  State<PassengerSide> createState() => _PassengerSideState();
}

class _PassengerSideState extends State<PassengerSide>
    with NotificationBannerMixin {
  // v1.4.5 (B4): bottom nav — 0 Home (booking) | 1 Meri Bookings |
  // 2 Monthly (sirf Home ke Monthly card se; nav mein slot nahi) |
  // 3 Madad | 4 Profile.
  int _tab = 0;

  /// Pickup user ne khud map par lagaya hai ya nahi — auto-center
  /// (apni location) sirf tab tak chalta hai jab tak user ne khud
  /// pickup na lagaya ho.
  bool _pickupTouched = false;

  /// Ride-watch wali service is side se chalu hai ya nahi —
  /// notification ijazat sirf pehli activation par mangte hain.
  bool _watchAsked = false;

  /// _FindingDriverView ("Driver Dhoonda Ja Raha Hai" wali active
  /// screen) is waqt khuli hai ya nahi (FINAL-PACK D) — khuli ho
  /// to driver-cancel ka bara notice WAHI screen apne poll se
  /// dikhati hai; is side ka poll sirf data taaza karta hai taaki
  /// notice do jagah se ek saath na aye (seen-set bhi yehi rokta
  /// hai).
  bool _findingOpen = false;

  // v1.4.0 two-phone dispatch: active ride ki backend wali taaza
  // haalat (status + driver ki live jagah) ka poll — screen par
  // jo bhi active booking khuli ho, us ke liye ETA line isi se
  // taza hoti hai. Backend/columns na hon to poll khamosh rehta
  // hai aur same-device pilot ki haalat hi chalti hai.
  Timer? _ridePoll;
  final Map<String, ({double lat, double lng})> _remoteDriverPos = {};
  // (rating prompt ka state _FindingDriverViewState ke paas hai.)


  // Booking form — MapLibre 3D map: pickup/drop tap se lagte hain,
  // route line OSRM se (offline par seedhi line fallback).
  LatLng _pickup = kKarachiCenter;
  LatLng? _drop;
  bool _dropArmed = false;
  // v1.4.28: pin-lagane ka khaas mode — panel ghayab, poora map,
  // upar hidayat patti; map tap = drop pin, phir mode khud band।
  bool _pinMode = false;
  // v1.4.28 (YANGO-style flow, malik ka hukm): Home par pehle
  // sirf map + "Kahan Jana Hai?" bar + gaari tiles dikhte hain;
  // booking ka form (sheet) tab khulta hai jab sawari bar ya
  // kisi tile ko dabaye — _flowOpen usi ka nishan hai।
  bool _flowOpen = false;
  List<LatLng>? _routePoints;
  String _routeSig = '';
  int _routeToken = 0;
  // Maujooda pickup/drop jori ke ASAL ROUTE ki sadak wali doori (km) —
  // kiraya isi par banta hai (v1.2.1). Null = is jori ka road route
  // abhi dastiyab nahi (offline/seedhi-line fallback); tab kiraya
  // seedhi doori se banta hai. _routeKmSig woh jori hai jis ke liye
  // ye doori hai — jori badle to purani doori istemal nahi hoti.
  double? _routeKm;
  String _routeKmSig = '';
  bool _satellite = false;
  LatLng? _focusPoint;
  int _focusSeq = 0;
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _pickupCtrl = TextEditingController();
  final _dropCtrl = TextEditingController();

  // v1.4.29 ASAL JAGAH SEARCH (geocoding — owner hukm
  // 2026-11-11 15:51): dono fields mein type karte hi asal
  // jagahon ke naam (Nominatim, countrycodes=pk)। Debounce
  // 400ms — har harf par request NAHI jati। 
  Timer? _searchDebounce;
  int _searchSeq = 0;
  String _searchField = 'drop';
  List<PlaceResult> _suggestions = const [];
  bool _searchBusy = false;
  bool _searchFailed = false;
  bool _searchDone = false;

  /// Field mein likhna badla — debounce ke baad asal search।
  void _onPlaceTextChanged(String field, String text) {
    _searchField = field;
    setState(() {});
    _searchDebounce?.cancel();
    final q = text.trim();
    if (q.length < 3) {
      setState(() {
        _suggestions = const [];
        _searchBusy = false;
        _searchFailed = false;
        _searchDone = false;
      });
      return;
    }
    _searchDebounce = Timer(
      const Duration(milliseconds: 400),
      () => _runPlaceSearch(field, q),
    );
  }

  Future<void> _runPlaceSearch(String field, String q) async {
    final seq = ++_searchSeq;
    setState(() {
      _searchBusy = true;
      _searchFailed = false;
    });
    try {
      // Bias: maujooda pickup ke aas paas ke results ko
      // tarjeeh (pabandi NAHI — poora Pakistan search hota hai)।
      final results = await PlaceSearch.search(q, near: _pickup);
      if (!mounted || seq != _searchSeq || _searchField != field) return;
      setState(() {
        _suggestions = results;
        _searchBusy = false;
        _searchDone = true;
      });
    } catch (_) {
      if (!mounted || seq != _searchSeq) return;
      setState(() {
        _suggestions = const [];
        _searchBusy = false;
        _searchFailed = true;
        _searchDone = true;
      });
    }
  }

  /// Suggestion par tap: (a) camera usi jagah par, (b) point
  /// pickup/drop set, (c) field mein ASAL naam ("Map Pin Wali
  /// Jagah" NAHI — search se chuni jagah ka asal label)।
  void _applySearchPlace(String field, PlaceResult place) {
    _searchDebounce?.cancel();
    setState(() {
      _suggestions = const [];
      _searchBusy = false;
      _searchDone = false;
    });
    if (field == 'drop') {
      _dropCtrl.text = place.label;
      _placeDrop(place.point);
    } else {
      _pickupTouched = true;
      setState(() {
        _pickup = place.point;
        _pickupCtrl.text = place.label;
      });
      _refreshRoute();
    }
    setState(() {
      _focusPoint = place.point;
      _focusSeq++;
    });
  }
  final _noteCtrl = TextEditingController();
  String _vehicle = 'Rickshaw';

  // Monthly form — pickup/drop dono ke pins bhi rehte hain (zone ke
  // naam se); dono pins lag jayein to route OSRM se ata hai aur
  // monthly hisaab USI asal road-km par banta hai (v1.4.0).
  // Pins/route se pehle _mRouteKm sirf 2.0 ka placeholder hai jo
  // form ki kisi nazar ane wali jagah par istemal nahi hota —
  // aur v1.4.25 se package is placeholder par BANTI bhi nahi:
  // dono pins + asal road route lazmi hain (fare gate booking
  // wala wohi usool; kul raqam hamesha sirf package pakka hone
  // par dialog mein dikhti hai).
  final _mPickupCtrl = TextEditingController();
  final _mDropCtrl = TextEditingController();
  String _mVehicle = 'Rickshaw';
  double _mRouteKm = 2.0;
  int _mDays = 26;
  LatLng? _mPickupPin;
  LatLng? _mDropPin;
  bool _mRouteIsRoad = false;
  int _mRouteToken = 0;

  // NOTE (v1.0.5): km chip selectors HATA diye gaye hain — doori hamesha
  // AUTO hisaab (pickup pin se drop pin) se aati hai; passenger ko koi
  // km field, per-km rate ya formula kabhi nazar nahi aata.
  static const List<int> _dayChips = [20, 24, 26, 30];

  AppStore get store => widget.store;

  // v1.4.27 (#23): ghanti/push par tap → is ride ki darkhwast
  // (rideOpenSignal)। Ride is sawari ki bookings mein ho to
  // 'Meri Bookings' tab khul jata hai। Cold start par darkhwast
  // pehle se signal mein ho sakti hai — initState ke aakhir
  // mein ek dafa wohi jaanch chali jati hai।
  int _rideOpenSeenSeq = 0;

  void _onRideOpenRequest() {
    final seq = rideOpenSignal.seq;
    if (seq == _rideOpenSeenSeq) return;
    _rideOpenSeenSeq = seq;
    final id = rideOpenSignal.rideId;
    if (id == null || !mounted) return;
    if (store.bookings.any((b) => b.id == id)) {
      rideOpenSignal.consume();
      setState(() => _tab = 1);
    }
  }

  @override
  void initState() {
    super.initState();
    rideOpenSignal.addListener(_onRideOpenRequest);
    WidgetsBinding.instance
        .addPostFrameCallback((_) => _onRideOpenRequest());
    _nameCtrl.text = store.passengerName;
    // v1.4.0: foreground notification banners (ride ki khabar app
    // khuli ho to foran snackbar mein bhi ati hai) + elanaat ka
    // halka pull + active rides ka backend poll.
    listenNotificationBanners(store);
    unawaited(Backend.refreshAnnouncements(store));
    _ridePoll = Timer.periodic(const Duration(seconds: 15), (_) {
      unawaited(_pollActiveRides());
    });
    unawaited(_pollActiveRides());
    // v1.4.5 (owner hukm): map passenger ki APNI location par
    // center rahe — khulne par khamoshi se GPS se pickup wahi
    // lag jata hai jahan woh khara hai (user ne khud pickup
    // lagaya ho to hath nahi lagta).
    unawaited(_centerOnUserSilently());
  }

  /// Khulne par map ko user ki apni jagah par le ana — bilkul
  /// khamosh (koi snack nahi); ijazat/GPS na mile to map pehle
  /// wali default jagah par hi rehta hai.
  Future<void> _centerOnUserSilently() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return;
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        return;
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      if (!mounted || _pickupTouched) return;
      final ll = LatLng(pos.latitude, pos.longitude);
      setState(() {
        _pickup = ll;
        _focusPoint = ll;
        _focusSeq++;
        if (_pickupCtrl.text.trim().isEmpty) {
          _pickupCtrl.text = 'Meri Location';
        }
      });
      _refreshRoute();
    } catch (_) {}
  }

  /// v1.4.5: active ride ho to background khabar wali service ko
  /// taaza rakhna — driver duty is phone par chal rahi ho to
  /// service driver mode mein hai aur watch usi ki config se
  /// taaza ho jata hai; warna passenger mode. Ride final ho
  /// jaye (watch khaali) to service band.
  Future<void> _syncRideWatchService() async {
    final watch = DutyService.watchFromStore(store);
    if (store.profile.online) {
      if (await DutyService.isRunning && watch.isNotEmpty) {
        await DutyService.startOrUpdate(
          mode: 'driver',
          driverId: store.driverId,
          watch: watch,
          title: 'Bozdar Safar — aap duty par hain',
          text: 'Nayi rides ki khabar aur aap ki location chal rahi hai',
        );
      }
      return;
    }
    if (watch.isEmpty) {
      await DutyService.stop();
      return;
    }
    if (!_watchAsked) {
      _watchAsked = true;
      await DutyService.ensureNotificationPermission();
    }
    await DutyService.startOrUpdate(
      mode: 'passenger',
      driverId: '',
      watch: watch,
      title: 'Bozdar Safar',
      text: 'Aap ki ride chal rahi hai — khabar yahin milegi',
    );
  }

  @override
  void dispose() {
    rideOpenSignal.removeListener(_onRideOpenRequest);
    cancelNotificationBanners();
    _ridePoll?.cancel();
    _searchDebounce?.cancel();
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _pickupCtrl.dispose();
    _dropCtrl.dispose();
    _noteCtrl.dispose();
    _mPickupCtrl.dispose();
    _mDropCtrl.dispose();
    super.dispose();
  }

  /// Ghair-final rides (pending/accepted/arrived) ki backend
  /// haalat ka poll:
  ///  - driver ki LIVE jagah (rides.driver_lat/lng) ETA ke liye mehfooz
  ///  - status local se alag ho to notification BHI banta hai aur
  ///    (v1.4.2 dispatch fix) asal haalat local booking par BHI lag
  ///    jati hai — Backend.applyRemoteRowToBooking, jo asal driver
  ///    ki tafseel bhi le ata hai. Is ke baghair do-phone par
  ///    passenger ki screen hamesha 'pending' par atki rehti thi.
  ///    Jis booking ko isi phone ke driver ne accept kiya ho, us
  ///    par remote NAHI lagta (store ke usool).
  /// Koi row/column na mile to bilkul khamosh.
  int _lastPackageSyncMs = 0;

  Future<void> _pollActiveRides() async {
    // v1.4.29 AUTO-EXPIRE (owner hukm 2026-11-11): 10 minute
    // se purani apni pending booking khud cancelled — backend
    // par bhi hook se update; passenger ko saaf paighaam।
    final expired = await store.expireStalePendings();
    if (expired.isNotEmpty && mounted) {
      _snack('${tr('expired_msg')} — booking mansookh ho gayi.');
      setState(() {});
    }
    // v1.4.25: monthly packages par driver-assign ki taaza haalat
    // bhi isi poll se (har ~60 second mein ek dafa) — sawari ko
    // "driver pakka ho gaya" khud nazar ajata hai।
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    if (nowMs - _lastPackageSyncMs > 60000) {
      _lastPackageSyncMs = nowMs;
      unawaited(Backend.syncOwnPackages(store));
    }
    final actives = store.bookings
        .where((b) =>
            b.status == 'pending' ||
            b.status == 'accepted' ||
            b.status == 'arrived')
        .toList();
    var posChanged = false;
    final remote = <String, String>{};
    // FINAL-PACK D: driver-cancel notice ke ummeedwar — poll ke
    // aakhir mein (loop ke baad) dikhaye jate hain.
    final cancelNotices = <Booking>[];
    for (final b in actives) {
      // Poll se PEHLE ki local haalat — cancel ki pehchan isi
      // tabdeeli se hoti hai (pehle active thi, ab cancelled).
      final prevStatus = b.status;
      final row = await Backend.fetchRideRow(b.id);
      if (row == null) continue;
      final lat = (row['driver_lat'] as num?)?.toDouble();
      final lng = (row['driver_lng'] as num?)?.toDouble();
      if (lat != null && lng != null) {
        final old = _remoteDriverPos[b.id];
        if (old == null || old.lat != lat || old.lng != lng) {
          _remoteDriverPos[b.id] = (lat: lat, lng: lng);
          posChanged = true;
        }
      }
      final st = row['status'];
      if (st is String && st.isNotEmpty) remote[b.id] = st;
      await Backend.applyRemoteRowToBooking(store, b, row);
      // FINAL-PACK D: backend par pehli dafa 'cancelled' nazar
      // aye aur cancel driver ki taraf se ho (ride accepted /
      // arrived thi ya driver assign tha) to bara notice. Wajah
      // backend row ke cancel_reason column se (fetchRideRow woh
      // pull karta hai) — local booking par darj kar dete hain
      // taaki notice + Meri Bookings dono mein wohi wajah rahe.
      // Finding screen khuli ho to notice WAHAN ka poll dikhata
      // hai — yahan sirf wajah darj hoti hai, nishan NAHI lagta.
      if (st == 'cancelled' && prevStatus != 'cancelled') {
        final remoteReason = row['cancel_reason']?.toString() ?? '';
        if (remoteReason.trim().isNotEmpty &&
            b.cancelReason.trim().isEmpty) {
          b.cancelReason = remoteReason.trim();
        }
        if (!_findingOpen &&
            _claimDriverCancelNotice(
                b, prevStatus, row['driver_id']?.toString() ?? '')) {
          cancelNotices.add(b);
        }
      }
    }
    // v1.4.7: is poll mein koi booking no-show hui ho to warning
    // ka backend record bhi taaza (passengers.warn_count — spec §5)।
    if (actives.any((b) => b.status == 'noshow')) {
      unawaited(Backend.syncPassengerSelf(store));
    }
    if (remote.isNotEmpty) {
      await store.observeBookingStatuses('passenger', remoteStatus: remote);
    }
    if ((posChanged || remote.isNotEmpty) && mounted) setState(() {});
    // Har poll ke saath background watch service ki config taaza.
    unawaited(_syncRideWatchService());
    // LIVE CHAT: Master ke jawabat bhi isi ~15s poll chakkar se
    // ate hain (naya jawab = store notification + banner).
    unawaited(Backend.syncMessages(store));
    // Driver-cancel notices — ek waqt mein ek.
    for (final b in cancelNotices) {
      await _showDriverCancelNotice(b);
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  bool get _fareReady =>
      _pickupCtrl.text.trim().isNotEmpty && _dropCtrl.text.trim().isNotEmpty;

  /// v1.4.28 PROGRESSIVE DISCLOSURE: booking ki tafseel
  /// (gaariyan, note, "Ride Pakki Karein", Monthly card) sirf
  /// tab khulti hai jab drop PIN + usi jori ka ASAL route dono
  /// maujood hon — usool booking_flow.dart mein hai (fare gate
  /// v1.4.25 se bandha hua: asal route ke baghair tafseel bhi
  /// nahi, booking bhi nahi)।
  bool get _bookingReady => bookingDetailsReady(
        hasDropPin: _drop != null,
        routeKm: _routeKm,
        routeSigMatches:
            _drop != null && _routeKmSig == _pairSig(_pickup, _drop!),
      );

  /// Pin-mode kholna: drop arm + panel ki jagah poora map +
  /// hidayat patti (build mein). Kis rasta se bhi khule —
  /// "Map Se Pin Lagayein" button, Drop Pin FAB, ya bina pin
  /// ke "Ride Pakki Karein" — rawaiya ek hi hai।
  void _enterPinMode() {
    setState(() {
      _pinMode = true;
      _dropArmed = true;
    });
  }

  /// Pin-mode band (Wapas) — pin nahi lagta, panel wapas ata
  /// hai jaisa tha।
  void _exitPinMode() {
    setState(() {
      _pinMode = false;
      _dropArmed = false;
    });
  }

  static double _roundKm(double km) {
    final r = (km * 10).round() / 10;
    return r < 0.5 ? 0.5 : r;
  }

  // v1.4.25: purane _autoKm (seedhi/crow-flies doori) aur
  // _fareKm (us par girne wala fallback) getters HATA diye gaye
  // hain — wohi woh rasta tha jis se fare 2.0 km default ya
  // seedhi doori par lock ho jata tha (postmortem #5)। Ab
  // kiraaye ki wahid bunyaad _routeKm hai (asal sadak route);
  // woh na ho to booking banti hi NAHI (gate _confirmBooking
  // mein hai)। Passenger se doori kabhi poochhi nahi jati।

  void _setPickup(LatLng point) {
    _pickupTouched = true;
    setState(() {
      _pickup = point;
      // v1.4.28: map se pickup lage aur field khaali ho to
      // saaf label khud lag jata hai (user ka likha hua kabhi
      // NAHI badalta) — warna pin-only rasta form ke naam
      // wale gate par ruk jata tha।
      if (_pickupCtrl.text.trim().isEmpty) {
        _pickupCtrl.text = kPinPlaceLabel;
      }
    });
    _refreshRoute();
  }

  static String _pairSig(LatLng a, LatLng b) =>
      '${a.latitude.toStringAsFixed(3)},${a.longitude.toStringAsFixed(3)}|${b.latitude.toStringAsFixed(3)},${b.longitude.toStringAsFixed(3)}';

  /// Pickup/drop ke liye asal sadak ka route (OSRM ya cache; offline par
  /// seedhi line) — map par line bhi isi se banti hai AUR kiraya bhi:
  /// route ki SADAK wali doori (_routeKm) hi kiraaye ki wahid bunyaad
  /// hai (v1.2.1). Sirf seedhi-line fallback mile to _routeKm null
  /// rehta hai — aur v1.4.25 se us surat mein booking banti hi NAHI
  /// (fare gate _confirmBooking mein hai)।
  Future<void> _refreshRoute() async {
    final drop = _drop;
    if (drop == null) {
      if (_routePoints != null && mounted) {
        setState(() => _routePoints = null);
      }
      _routeSig = '';
      _routeKm = null;
      _routeKmSig = '';
      return;
    }
    final sig = _pairSig(_pickup, drop);
    if (sig == _routeSig) return;
    _routeSig = sig;
    // Jori badal gayi — purani jori ki route doori ab kiraaye mein
    // istemal nahi hogi; nayi doori fetch mukammal hone par hi set hogi.
    _routeKm = null;
    _routeKmSig = '';
    final token = ++_routeToken;
    final r = await RouteService.fetch(_pickup, drop);
    if (mounted && token == _routeToken) {
      setState(() {
        _routePoints = r.points;
        if (r.isStraightFallback) {
          _routeKm = null;
          _routeKmSig = '';
        } else {
          _routeKm = _roundKm(r.distanceKm);
          _routeKmSig = sig;
        }
      });
    }
  }

  Future<void> _myLocation() async {
    try {
      final service = await Geolocator.isLocationServiceEnabled();
      if (!service) {
        if (mounted) _snack('Location service band hai — pehle on karein.');
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        if (mounted) _snack('Location ki ijazat nahi mili.');
        return;
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      if (!mounted) return;
      _pickupTouched = true;
      final ll = LatLng(pos.latitude, pos.longitude);
      setState(() {
        _pickup = ll;
        _focusPoint = ll;
        _focusSeq++;
        if (_pickupCtrl.text.trim().isEmpty) {
          _pickupCtrl.text = 'Meri Location';
        }
      });
      _refreshRoute();
    } catch (_) {
      if (mounted) {
        _snack('Location nahi mil saki — map par tap karke pickup lagayein.');
      }
    }
  }

  void _placeDrop(LatLng point) {
    _pickupTouched = true;
    setState(() {
      _drop = point;
      _dropArmed = false;
      // v1.4.28: pin lag gaya — pin-mode khud band, panel
      // dobara khul jata hai (route ate hi tafseel ke saath)।
      _pinMode = false;
      // Pin-only rasta mukammal ho sake is liye khaali drop
      // field ko saaf label mil jata hai (geocoding nahi hai,
      // jaali pata NAHI banta; likha hua naam kabhi nahi
      // badalta)।
      _dropCtrl.text = pinLabelIfEmpty(_dropCtrl.text);
    });
    _refreshRoute();
  }

  /// v1.4.17 FCM: pickup pin ke sab se qareeb zone (sheher) ka
  /// naam — push ke duty_drivers audience ko sheher ki had
  /// bandhne ke liye. 40 km se door koi zone na ho to khaali
  /// (server apni geo-jaanch khud bhi rakhta hai)।
  String _pickupZoneName() {
    var best = '';
    var bestKm = 40.0;
    const dist = Distance();
    for (final e in kZoneCoords.entries) {
      final km = dist.as(LengthUnit.Kilometer, _pickup, e.value);
      if (km < bestKm) {
        bestKm = km;
        best = e.key;
      }
    }
    return best;
  }

  Future<void> _confirmBooking() async {
    if (_nameCtrl.text.trim().isEmpty) {
      _snack('Apna naam likhein.');
      return;
    }
    if (!_fareReady) {
      _snack('Pickup aur drop dono jagah likhein.');
      return;
    }
    // FINAL-PACK B-PD — PASSENGER BLOCK check: ride banane se
    // PEHLE number Master ki blocked list mein parkha jata hai.
    // Pehle store ki list ek dafa backend se taaza (defensive —
    // jawab na aye to akhri maloom list hi chalti hai), phir
    // check: blocked ho to saaf paighaam aur ride NAHI banti.
    try {
      await Backend.refreshBlockedPassengers(store)
          .timeout(const Duration(seconds: 4), onTimeout: () {});
    } catch (_) {
      // Khamosh — store ki maloom list par check phir bhi hoga.
    }
    if (!mounted) return;
    final myPhone = _phoneCtrl.text.trim().isNotEmpty
        ? _phoneCtrl.text.trim()
        : store.passengerPhone;
    // v1.4.23: server se seedha check (is_passenger_blocked RPC)
    // — flip ke baad blocked list ki parhai owner-only hai, is
    // liye store ki list purani reh sakti hai; RPC ka 'true' hi
    // asal pabandi hai। Jawab na aye (null/timeout) to neeche
    // wali local list hi faisla karti hai।
    var remoteBlocked = false;
    try {
      remoteBlocked = await Backend.isPassengerBlockedRemote(myPhone)
              .timeout(const Duration(seconds: 4),
                  onTimeout: () => null) ==
          true;
    } catch (_) {
      remoteBlocked = false;
    }
    if (!mounted) return;
    if (remoteBlocked || store.isPassengerBlocked(myPhone)) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.block, color: Brand.ajrakRed, size: 24),
              SizedBox(width: 8),
              Text('Ride Nahi Ban Sakti'),
            ],
          ),
          content: const Text(
              'Maazrat — is number par ride band hai. Mazeed maloomat ke liye Master se rabta karein (0332 9467211).'),
          actions: [
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Theek Hai'),
            ),
          ],
        ),
      );
      return;
    }
    // v1.4.7 NO-SHOW BLOCK (spec §5): 3 dafa ride par na ane
    // wali sawari ki booking band — Master se rabta hi rasta।
    if (store.passengerNoShowBlocked) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.block, color: Brand.ajrakRed, size: 24),
              SizedBox(width: 8),
              Text('Booking Band Hai'),
            ],
          ),
          content: const Text(
              'Aap 3 dafa ride mangwa kar nahi ayein, is liye aap ki booking ab band hai. Mazeed maloomat ke liye Master se rabta karein (0332 9467211).'),
          actions: [
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Theek Hai'),
            ),
          ],
        ),
      );
      return;
    }
    // v1.4.7 EMAIL + OTP (spec §1 — sawari par bhi AIN wohi
    // usool): pehli ID Gmail se banti hai; OTP tasdeeq ke
    // baghair ID aage NAHI badhti; logout ke baad dobara OTP।
    if (!store.passengerEmailVerified) {
      final ok = await Navigator.of(context).push<bool>(MaterialPageRoute(
        builder: (_) => _PassengerEmailPage(store: store),
      ));
      if (ok != true || !mounted) {
        if (mounted) {
          _snack('Pehle apni Gmail OTP se verify karein — baghair tasdeeq booking nahi banti.');
        }
        return;
      }
    } else if (!store.passengerOtpSessionVerified) {
      final ok = await Navigator.of(context).push<bool>(MaterialPageRoute(
        builder: (_) => OtpGatePage(
            email: store.passengerEmail, title: 'Email OTP Tasdeeq'),
      ));
      if (ok != true || !mounted) {
        if (mounted) {
          _snack('Email OTP tasdeeq ke baghair booking nahi banti.');
        }
        return;
      }
      store.passengerOtpSessionVerified = true;
      await store.save();
      // v1.4.14: OTP kamyabi = session mehfooz — passenger ki
      // device pehchan Auth pehchan se bandh do (identity_links)।
      unawaited(Backend.linkIdentities(store));
      if (!mounted) return;
    }
    store.passengerName = _nameCtrl.text.trim();
    // v1.4.25 FARE GATE (postmortem #5): booking sirf tab pakki
    // hogi jab (1) drop ka PIN laga ho aur (2) usi jori ka ASAL
    // sadak route (OSRM ya cache) mil jaye। Pehle pin na honay
    // par fare 2.0 km ke default par, aur route na milne par
    // seedhi (crow-flies) doori par LOCK ho jata tha — dono
    // raste hamesha ke liye band: pin na ho to sawari ko saaf
    // wajah + kya karna hai bataya jata hai; route na mile to
    // booking NAHI banti aur dobara koshish ka kaha jata hai।
    final dropPin = _drop;
    if (dropPin == null) {
      // v1.4.28: sirf snack par NAHI rukna — pin-lagane wala
      // mode KHUD khul jata hai (panel ghayab, poora map +
      // hidayat patti) taake sawari wahin se pin laga le;
      // pehle panel map ko dhak deta tha aur sawari pin
      // lagaa hi nahi sakta tha (malik ki live-test shikayat)।
      _enterPinMode();
      _snack(kPinNeededSnack);
      return;
    }
    final sig = _pairSig(_pickup, dropPin);
    if (_routeKm == null || _routeKmSig != sig) {
      try {
        final r = await RouteService.fetch(_pickup, dropPin)
            .timeout(const Duration(seconds: 6));
        if (!r.isStraightFallback && r.distanceKm > 0) {
          _routeKm = _roundKm(r.distanceKm);
          _routeKmSig = sig;
          if (mounted) {
            setState(() => _routePoints = r.points);
          }
        }
      } catch (_) {
        // Route na mila — neeche wala gate booking rok dega।
      }
    }
    if (!mounted) return;
    final km = _routeKm;
    if (km == null || _routeKmSig != sig) {
      _snack('Route abhi nahi mil saka — internet check karke dobara koshish karein. Baghair pakki route ke booking nahi banti, taaki kiraya kabhi ghalat na bane.');
      return;
    }
    final b = Booking(
      id: store.newId(),
      passengerName: _nameCtrl.text.trim(),
      passengerPhone: _phoneCtrl.text.trim(),
      pickupLabel: _pickupCtrl.text.trim(),
      dropLabel: _dropCtrl.text.trim(),
      pickupLat: _pickup.latitude,
      pickupLng: _pickup.longitude,
      dropLat: _drop?.latitude ?? 0,
      dropLng: _drop?.longitude ?? 0,
      hasDropPin: _drop != null,
      vehicle: _vehicle,
      distanceKm: km,
      fare: Fares.fareFor(_vehicle, km),
      note: _noteCtrl.text.trim(),
      status: 'pending',
      createdAt: DateTime.now(),
      driverName: store.profile.name,
    );
    // v1.4.24 TAX (SRB) — ANDAZA: booking ke waqt tax pickup
    // sheher se sirf fare par (waiting abhi 0 hai) gin kar
    // booking par darj kar dete hain taake sawari ko confirm
    // wale hisaab mein kiraye ke saath tax ki ALAG line aur kul
    // adaigi saaf nazar aye. Ye FINAL nahi hai: completion par
    // driver apne registered sheher aur (fare + waiting) par
    // isay pakka karega (wahi asal record hai — Master ke Tax
    // Khata se wohi milta hai). Pickup sheher tax list mein na
    // ho to tax 0 rehta hai (masalan Punjab — PRA ruling baqi)।
    final pickupCity = _pickupZoneName();
    if (kTaxCitiesSindh.contains(pickupCity)) {
      b.taxCity = pickupCity;
      b.taxAmount = taxOnAmounts(
        total: b.fare,
        fee: Fares.serviceFee(b.fare),
        vehicle: b.vehicle,
        city: pickupCity,
      );
    }
    await store.addBooking(b);
    // v1.4.25 BACKEND TASDEEQ (postmortem #4): "Booking Pakki"
    // ka dawa ab sirf tab hoga jab booking ASAL mein backend
    // tak pohanch jaye — pehle kamyabi ka dialog baghair kisi
    // tasdeeq ke ajata tha, aur push fail hone par sawari ko
    // pata hi nahi chalta tha। Na pohanchay to saaf khabar +
    // "Dobara Bhejein" ka rasta; booking phone mein mehfooz
    // rehti hai aur ride outbox agli app-start par khud dobara
    // bhejega (jhooti tasalli bilkul NAHI)।
    var pushed = false;
    try {
      pushed = await Backend.pushRideNow(store, b).timeout(
          const Duration(seconds: 12),
          onTimeout: () => false);
    } catch (_) {
      pushed = false;
    }
    if (!pushed && mounted) {
      final retry = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: const Row(
            children: [
              Icon(Icons.cloud_off, color: Brand.ajrakRed, size: 26),
              SizedBox(width: 8),
              Expanded(child: Text('Booking Mehfooz Hai')),
            ],
          ),
          content: const Text(
              'Aap ki booking is phone mein ban gayi hai, lekin abhi server tak NAHI gayi — internet ka masla lagta hai.\n\n'
              'Fikr na karein: booking kahin nahi jayegi. Internet ate hi, ya app dobara khulte hi, woh khud server tak chali jayegi.\n\n'
              'Kya abhi dobara koshish karein?',
              style: TextStyle(fontSize: 13.5, height: 1.45)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Baad Mein'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Dobara Bhejein'),
            ),
          ],
        ),
      );
      if (retry == true) {
        try {
          pushed = await Backend.pushRideNow(store, b).timeout(
              const Duration(seconds: 12),
              onTimeout: () => false);
        } catch (_) {
          pushed = false;
        }
        if (pushed && mounted) {
          _snack('Booking server tak pohanch gayi hai.');
        }
      }
    }
    if (!pushed) {
      if (mounted) {
        _snack('Booking phone mein mehfooz hai — server par bhejna abhi baqi hai.');
        setState(() {});
      }
      return;
    }
    if (!mounted) return;
    // v1.4.17 FCM: duty par mojood drivers ko foran khabar
    // (Edge Function 'send-push' DEPLOY hai; call kabhi fail
    // ho to khamosh fail hoti hai — duty-service polling wala
    // rasta barkarar hai)।
    // Fire-and-forget: booking ka flow is par NAHI rukta।
    unawaited(Backend.invokePush({
      'audience': 'duty_drivers',
      'zone': _pickupZoneName(),
      'title': 'Nayi Ride',
      'body': '${b.pickupLabel} → ${b.dropLabel} · ${b.vehicle}',
      'data': {'ride_id': b.id},
    }));
    if (!mounted) return;
    // v1.4.0 TWO-PHONE DISPATCH (b): booking banne ke BAAD (aur
    // kiraya wale dialog se pehle — koi fare yahan NAHI dikhta,
    // sirf "driver qareeb hai" ki ittila) backend ke active+online
    // drivers mein sab se qareeb driver ginna. Jawab na aye/backend
    // khaali ho to khamoshi — mojooda same-device pilot bilkul
    // waise hi chalta hai, ye sirf bonus maloomat hai. Assignment
    // is se NAHI hoti — driver ke qubool karne se hi hoti hai.
    try {
      final nearKm = await Backend.nearestOnlineDriverKm(
              b.pickupLat, b.pickupLng)
          .timeout(const Duration(seconds: 5), onTimeout: () => null);
      if (nearKm != null) {
        store.setDispatchNote(
            'Qareeb driver maujood hai — sirf ${nearKm.toStringAsFixed(1)} km door. Jawab ka intezaar karein.');
      } else {
        store.setDispatchNote('');
      }
    } catch (_) {
      store.setDispatchNote('');
    }
    if (!mounted) return;
    // Kul kiraya PEHLI dafa yahin nazar aata hai — booking pakki hone
    // ke BAAD (owner ka lock, v1.0.7). Us se pehle kahin koi price nahi.
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Brand.green, size: 26),
            SizedBox(width: 8),
            Text('Booking Pakki Ho Gayi'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('${b.pickupLabel} → ${b.dropLabel}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text(b.vehicle, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Brand.deepGreen,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                children: [
                  const Text('TOTAL KIRAYA',
                      style: TextStyle(
                          color: Brand.goldLight,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.2)),
                  Text(rs(b.total),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.w900)),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Doori: ${b.distanceKm.toStringAsFixed(1)} km',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Colors.black87),
            ),
            // v1.4.24 TAX (SRB): kiraye ke saath tax ki ALAG saaf
            // line aur KUL adaigi (tax samait) — ye hisaab booking
            // pakki honay ke BAAD ka hai (booking se pehle fare ka
            // lock barkarar hai). Tax waiting ke baghair andaza
            // hai; waiting par final hisaab ride khatam honay par
            // raseed mein pakka ayega।
            if (b.hasTax) ...[
              const SizedBox(height: 6),
              Text(
                '${taxLabelFor(b.vehicle)}: ${rs(b.taxAmount)}',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Colors.black87),
              ),
              const SizedBox(height: 2),
              Text(
                'Kul adaigi (tax samait): ${rs(b.grandTotal)}',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    color: Brand.greenDark),
              ),
              const SizedBox(height: 2),
              const Text(
                'Tax kiraye se alag sarkari tax hai — ye company ki kamai nahi hai.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11, color: Colors.black45),
              ),
            ],
            // v1.4.7 RIDE START CODE (spec §3): sawari driver ko
            // ye code batati hai — driver ye code daale tab ride
            // asal mein shuru hogi।
            if (b.startCode > 0) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF6E0),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Brand.gold, width: 1.2),
                ),
                child: Column(
                  children: [
                    const Text('Aap ka RIDE START CODE',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.1,
                            color: Color(0xFFB8860B))),
                    Text('${b.startCode}',
                        style: const TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 8)),
                    const Text(
                      'Driver aye to use YE code batayein — driver ye code daale ga tab ride shuru hogi. Code kisi aur ko na batayein.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 6),
            const Text(
              'Booking driver ko bhej di gayi hai — jawab ka intezaar karein.',
              style: TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Theek Hai'),
          ),
        ],
      ),
    );
    if (!mounted) return;
    // Booking pakki hone ke BAAD "Driver Dhoonda Ja Raha Hai" wali
    // screen (Careem ki "Finding your Captain" style, v1.0.8) — ye
    // booking ki halat wali screen hai, asal driver assignment nahi.
    _findingOpen = true;
    final result = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (_) => _FindingDriverView(store: store, booking: b),
      ),
    );
    _findingOpen = false;
    if (!mounted) return;
    if (result == 'bookings') {
      setState(() => _tab = 1);
    } else if (result == 'cancelled') {
      setState(() => _tab = 0);
      _snack('Ride mansookh ho gayi.');
    } else if (result != null && result.startsWith('rebook:')) {
      // FINAL-PACK D: Finding screen ke driver-cancel notice se
      // "Dobara Ride Mangayein" — purani ride se foran nayi ride.
      final oldId = result.substring('rebook:'.length);
      for (final old in store.bookings) {
        if (old.id == oldId) {
          await _rebookFromCancelled(old);
          break;
        }
      }
    }
  }

  /// FINAL-PACK D — DOBARA RIDE: driver ke cancel ki hui ride ki
  /// pickup/drop/vehicle/pins booking form mein bhar kar seedha
  /// wohi mojooda _confirmBooking wala rasta chalaya jata hai —
  /// passenger ko form dobara NAHI bharna parta. Kiraya nayi ride
  /// ka naye hisaab se hi banta hai (fare lock barkarar).
  Future<void> _rebookFromCancelled(Booking old) async {
    if (!mounted) return;
    setState(() {
      _tab = 0;
      _nameCtrl.text = old.passengerName;
      _phoneCtrl.text = old.passengerPhone;
      _pickupCtrl.text = old.pickupLabel;
      _dropCtrl.text = old.dropLabel;
      _noteCtrl.text = old.note;
      _vehicle = old.vehicle;
      if (old.pickupLat != 0 || old.pickupLng != 0) {
        _pickup = LatLng(old.pickupLat, old.pickupLng);
        _pickupTouched = true;
      }
      _drop = old.hasDropPin
          ? LatLng(old.dropLat, old.dropLng)
          : null;
      _dropArmed = false;
    });
    _refreshRoute();
    await _confirmBooking();
  }

  /// FINAL-PACK D — driver-cancel ka bara notice dikhana hai ya
  /// nahi, is ka faisla: status pehli dafa 'cancelled' hua ho,
  /// ride driver ke paas gayi hui ho (pichli haalat accepted /
  /// arrived, ya driver assign tha), aur is ride ka notice pehle
  /// na dikhaya gaya ho (store ka seen-set). Passenger ne KHUD
  /// cancel kiya ho to us ki local haalat pehle hi 'cancelled'
  /// hoti hai — woh booking poll ki active list mein ati hi nahi,
  /// aur yahan bhi prevStatus 'cancelled' par ye notice NAHI
  /// banta. Shart puri ho to nishan pehle lagta hai, notice baad
  /// mein — notice har ride par SIRF ek dafa.
  bool _claimDriverCancelNotice(
      Booking b, String prevStatus, String remoteDriverId) {
    if (store.hasCancelNoticeSeen(b.id)) return false;
    final hadDriver = prevStatus == 'accepted' ||
        prevStatus == 'arrived' ||
        b.assignedDriverId.isNotEmpty ||
        remoteDriverId.isNotEmpty;
    if (!hadDriver) return false;
    store.markCancelNoticeSeen(b.id);
    return true;
  }

  /// Notice card/dialog: wajah ke saath + 'Dobara Ride
  /// Mangayein' (purani ride se foran nayi) + 'Band Karein'.
  Future<void> _showDriverCancelNotice(Booking b) async {
    if (!mounted) return;
    final reason = b.cancelReason.trim();
    final rebook = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.cancel, color: Brand.ajrakRed, size: 26),
            SizedBox(width: 8),
            Expanded(child: Text('Driver ne ride band kar di')),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${b.pickupLabel} → ${b.dropLabel}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(
              'Wajah: ${reason.isEmpty ? 'wajah nahi batayi gayi' : reason}',
              style: const TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 6),
            const Text(
              'Pareshan na hon — wohi pickup aur manzil par dobara ride foran mangayi ja sakti hai.',
              style: TextStyle(fontSize: 12.5, color: Colors.black54),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Band Karein'),
          ),
          ElevatedButton.icon(
            onPressed: () => Navigator.pop(ctx, true),
            icon: const Icon(Icons.refresh, size: 17),
            label: const Text('Dobara Ride Mangayein'),
          ),
        ],
      ),
    );
    if (rebook == true) await _rebookFromCancelled(b);
  }

  void _clearBookingForm() {
    setState(() {
      _pickupCtrl.clear();
      _dropCtrl.clear();
      _noteCtrl.clear();
      _drop = null;
      _dropArmed = false;
      _pinMode = false;
      _flowOpen = false;
      _routeKm = null;
      _routeKmSig = '';
      _vehicle = 'Rickshaw';
    });
    _snack('Koi booking nahi bani — sab saaf kar diya gaya.');
  }

  Future<void> _savePlace(bool isGhar) async {
    final current = isGhar ? store.savedGhar : store.savedDaftar;
    final ctrl = TextEditingController(text: current);
    final label = isGhar ? 'Ghar' : 'Daftar';
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('$label ki jagah save karein'),
        content: TextField(
          controller: ctrl,
          decoration: InputDecoration(labelText: '$label ka pata / jagah'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Rehne Dein')),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: const Text('Save Karein')),
        ],
      ),
    );
    if (result != null) {
      if (isGhar) {
        store.savedGhar = result;
      } else {
        store.savedDaftar = result;
      }
      await store.save();
      if (mounted) _snack('$label save ho gaya.');
    }
  }

  void _applyPlace(bool isGhar) {
    final v = isGhar ? store.savedGhar : store.savedDaftar;
    if (v.isEmpty) {
      _savePlace(isGhar);
    } else {
      setState(() => _dropCtrl.text = v);
    }
  }

  // --- Saved places (v1.4.0) ----------------------------------------------
  // Mehfooz jagah (naam + label + pin) chip se manzil ban jati hai;
  // "Jagah save karein" button maujooda pickup ya drop ko kisi bhi
  // naam (Ghar / Daftar / apna naam) se mehfooz karta hai. Sirf
  // is phone ki store mein rehti hain — koi backend nahi.

  void _applySavedPlace(SavedPlace sp) {
    setState(() {
      _dropCtrl.text = sp.label;
      if (sp.hasPin) {
        _drop = LatLng(sp.lat, sp.lng);
        _dropArmed = false;
      }
    });
    _refreshRoute();
  }

  /// v1.4.28: pichhli ride ki manzil dobara drop banana —
  /// Yango-style "recent" row ka amal: label + pin dono usi
  /// purani booking se ate hain, route khud taaza banta hai;
  /// pickup maujooda hi rehta hai।
  void _applyRecentDrop(Booking b) {
    setState(() {
      _dropCtrl.text = b.dropLabel;
      _drop = LatLng(b.dropLat, b.dropLng);
      _dropArmed = false;
      _pinMode = false;
    });
    _refreshRoute();
  }

  /// Home bar / gaari tile se booking flow kholna — tile wali
  /// surat mein gaari pehle se chuni hui (preselect) hoti hai।
  void _openFlow({String? vehicle}) {
    setState(() {
      if (vehicle != null) _vehicle = vehicle;
      _flowOpen = true;
    });
  }

  Future<void> _saveCurrentPlace() async {
    final nameCtrl = TextEditingController();
    final useDrop = _dropCtrl.text.trim().isNotEmpty;
    final label = useDrop ? _dropCtrl.text.trim() : _pickupCtrl.text.trim();
    if (label.isEmpty) {
      _snack('Pehle pickup ya manzil likhein, phir save karein.');
      return;
    }
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Jagah save karein'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Jagah: $label',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(
                labelText: 'Naam (Ghar / Daftar / apna naam)',
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              children: [
                ActionChip(
                  label: const Text('Ghar'),
                  onPressed: () => Navigator.pop(ctx, 'Ghar'),
                ),
                ActionChip(
                  label: const Text('Daftar'),
                  onPressed: () => Navigator.pop(ctx, 'Daftar'),
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Rehne Dein')),
          ElevatedButton(
            onPressed: () {
              final n = nameCtrl.text.trim();
              if (n.isEmpty) {
                Navigator.pop(ctx);
              } else {
                Navigator.pop(ctx, n);
              }
            },
            child: const Text('Save Karein'),
          ),
        ],
      ),
    );
    nameCtrl.dispose();
    if (result == null || result.isEmpty) return;
    final pinLat = useDrop ? (_drop?.latitude ?? _pickup.latitude) : _pickup.latitude;
    final pinLng = useDrop
        ? (_drop?.longitude ?? _pickup.longitude)
        : _pickup.longitude;
    await store.savePlace(SavedPlace(
      id: store.newId(),
      name: result,
      label: label,
      lat: pinLat,
      lng: pinLng,
      hasPin: useDrop ? _drop != null : true,
    ));
    if (mounted) _snack('"$result" save ho gaya.');
  }

  /// Mehfooz jagah mitana (chips wali patti ke neeche chhota sa
  /// manage button) — sirf jab saved places mojood hon.
  Future<void> _manageSavedPlaces() async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Mehfooz Jagahen'),
        content: ListenableBuilder(
          listenable: store,
          builder: (context, _) {
            if (store.savedPlaces.isEmpty) {
              return const Text('Koi jagah save nahi hai.');
            }
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final sp in store.savedPlaces)
                  ListTile(
                    dense: true,
                    leading: const Icon(Icons.place, color: Brand.green),
                    title: Text(sp.name),
                    subtitle: Text(sp.label),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline,
                          color: Brand.ajrakRed),
                      onPressed: () => store.removePlace(sp.id),
                    ),
                  ),
              ],
            );
          },
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Band Karein')),
        ],
      ),
    );
    if (mounted) setState(() {});
  }

  // -------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    // Bottom nav ka selected slot: Monthly (2) Home ke andar ka
    // darwaza hai, is liye nav par Home hi numaya rehta hai.
    final navIndex = _tab == 2
        ? 0
        : _tab == 3
            ? 2
            : _tab == 4
                ? 3
                : _tab;
    final activeCount = store.bookings
        .where((b) =>
            b.status == 'pending' ||
            b.status == 'accepted' ||
            b.status == 'arrived')
        .length;
    return Scaffold(
      body: Column(
        children: [
          // v1.4.5 (B5): ghanti + avatar header ke ANDAR (brief §3).
          BrandHeader(
            sideLabel: 'PASSENGER APP',
            actions: [
              NotificationBell(store: store, onDark: true),
              InitialAvatar(
                name: store.passengerName,
                onTap: () => setState(() => _tab = 4),
              ),
              const SizedBox(width: 2),
            ],
          ),
          // v1.4.8: recommended band par banner har waqt (policy),
          // warna aam update notice apne rawaiye par.
          if (UpdatePolicy.level == 1 ||
              (store.updateAvailable && !store.updateDismissed))
            UpdateBanner(store: store),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
            child: ModeToggleButton(
                toDriver: true, onTap: widget.onSwitchToDriver),
          ),
          // v1.4.28 (malik ka hukm 2026-11-11): passenger side ki
          // BARI banner tasveer (ladki + rickshaw wali ModeBanner)
          // booking screen se KHATAM — woh map ki jagah gherti thi
          // aur sawari ko pin lagane mein rukawat banti thi. Ab
          // header/toggle ke foran neeche map + compact panel hai.
          // Asset file aur driver side ki banner apni jagah
          // barkarar hain.
          Expanded(
            child: _tab == 0
                ? _bookingView()
                : _tab == 1
                    ? _myBookingsView()
                    : _tab == 2
                        ? _monthlyView()
                        : _tab == 3
                            ? _madadView()
                            : _menuView(),
          ),
        ],
      ),
      // v1.4.5 (B4 — brief §3-A): purani chip patti KHATAM, board
      // wala bottom nav: Home / Meri Bookings / Madad / Profile.
      // Monthly ka darwaza Home ke andar barkarar hai (neeche
      // wala card) — koi feature ghayab NAHI hua.
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: navIndex,
        onTap: (i) => setState(() {
          _tab = i == 0
              ? 0
              : i == 1
                  ? 1
                  : i == 2
                      ? 3
                      : 4;
        }),
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
        selectedItemColor: Brand.green,
        unselectedItemColor: Colors.black45,
        items: [
          const BottomNavigationBarItem(
              icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
            icon: Badge(
              label: Text('$activeCount'),
              isLabelVisible: activeCount > 0,
              child: const Icon(Icons.list_alt),
            ),
            label: 'Meri Bookings',
          ),
          const BottomNavigationBarItem(
              icon: Icon(Icons.support_agent), label: 'Madad'),
          const BottomNavigationBarItem(
              icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  /// MADAD tab (brief §3-A ka teesra slot — board ke "Wallet"
  /// slot ki asal jagah): Master ko Message, Notifications ka
  /// rasta, SOS ki maloomat, aur Sharait/Privacy ke darwaze.
  /// Sab asal features hain — koi jaali wallet NAHI.
  Widget _madadView() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Card(
          margin: EdgeInsets.zero,
          child: ListTile(
            leading: const Icon(Icons.mail_outline, color: Brand.green),
            title: const Text('Master ko Message',
                style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text(
                'Koi masla, sawal ya shikayat ho to seedha Master (head) ko message bhejein.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _openMessages,
          ),
        ),
        const SizedBox(height: 10),
        // v1.4.26 HEALTH ENGINE: app ki sehat ki jhalak + Repair
        // Log ka rasta — engine khamoshi se khud repair karta
        // hai, ye satar sirf haalat batati hai.
        AppHealthTile(store: store),
        const SizedBox(height: 10),
        Card(
          margin: EdgeInsets.zero,
          child: ListTile(
            leading: const Icon(Icons.notifications, color: Brand.green),
            title: const Text('Notifications',
                style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text(
                'Ride ki khabar aur Master ke elanaat yahan milte hain.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              await Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => NotificationCentreScreen(store: store),
                ),
              );
              await store.markAllNotificationsRead();
            },
          ),
        ),
        const SizedBox(height: 10),
        const Card(
          margin: EdgeInsets.zero,
          color: Color(0xFFFBEAEA),
          child: Padding(
            padding: EdgeInsets.all(14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.emergency, color: Brand.ajrakRed, size: 26),
                SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Emergency (SOS)',
                          style: TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 15)),
                      SizedBox(height: 4),
                      Text(
                        'Ride ke doran koi pareshani ho to ride wali screen par SOS ka button hai — wahan se 1122 par call hoti hai aur Master ke inbox mein alag SOS pehchan ke saath khabar jati hai. Shadeed emergency mein sab se pehle 1122 par call karein.',
                        style: TextStyle(fontSize: 12.5, height: 1.45),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        LegalLinksCard(store: store),
      ],
    );
  }

  // ------------------------------------------------------------------
  // v1.4.28 PASSENGER MENU (malik ka hukm — Yango ki menu screen
  // jaisa andaaz, lekin har cheez Safar ki ASAL sahulat): Profile
  // tab ke andar mukammal menu — upar profile hissa (photo/naam/
  // number) + chaar gol shortcut buttons + neeche saaf list rows।
  // Bottom nav ki tartib NAHI badli; purana Profile body
  // (PassengerProfileBody: maloomat, photo, Gmail, Agent hisa,
  // Sharait, Logout, Account Delete) "Meri Profile aur Settings"
  // se PassengerProfileScreen mein waisa ka waisa maujood hai —
  // koi sahulat gayab NAHI hui। Jo cheez app mein hai hi nahi
  // (promo code, card payment, business account) us ka jhoota
  // item NAHI banaya gaya।
  Widget _menuView() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        // Profile hissa — photo ho to woh, warna naam ke harf
        // wala avatar (maujooda header wala andaaz)।
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Brand.green, Brand.deepGreen],
            ),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Brand.gold, width: 1.6),
          ),
          child: Row(
            children: [
              _menuAvatar(),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      store.passengerName.isEmpty
                          ? 'Assalam O Alaikum'
                          : store.passengerName,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w900),
                    ),
                    Text(
                      store.passengerPhone.isEmpty
                          ? 'Naam/number booking par darj hota hai'
                          : store.passengerPhone,
                      style:
                          const TextStyle(color: Colors.white70, fontSize: 12.5),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        // Shortcut gol buttons — chaar sab se zyada istemal
        // wale darwaze।
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _menuShortcut(
              icon: Icons.history,
              label: tr('my_rides'),
              onTap: () => setState(() => _tab = 1),
            ),
            _menuShortcut(
              icon: Icons.support_agent,
              label: tr('help'),
              onTap: _openMessages,
            ),
            _menuShortcut(
              icon: Icons.place,
              label: 'Mere Pate',
              onTap: _manageSavedPlaces,
            ),
            _menuShortcut(
              icon: Icons.settings,
              label: 'Settings',
              onTap: _openProfileSettings,
            ),
          ],
        ),
        const SizedBox(height: 14),
        _menuRow(
          icon: Icons.language,
          title: tr('language'),
          subtitle: tr('language_sub'),
          onTap: () => showLanguageChooser(
            context,
            current: store.langCode,
            onPick: (c) => store.setLang(c),
          ),
        ),
        _menuRow(
          icon: Icons.history,
          title: tr('my_rides'),
          subtitle: 'Meri maujooda aur purani rides ki history',
          onTap: () => setState(() => _tab = 1),
        ),
        _menuRow(
          icon: Icons.support_agent,
          title: tr('support'),
          subtitle: 'Master ko seedha message bhejein',
          onTap: _openMessages,
        ),
        _menuRow(
          icon: Icons.place,
          title: 'Saved Places',
          subtitle: 'Ghar, Daftar aur meri mehfooz jagahen',
          onTap: _manageSavedPlaces,
        ),
        _menuRow(
          icon: Icons.payments,
          title: 'Payment',
          subtitle: 'Sirf Cash — ride ke baad driver ko ada karein',
          onTap: _showPaymentInfo,
        ),
        _menuRow(
          icon: Icons.swap_horiz,
          title: 'Driver Mode',
          subtitle: 'Driver side par jayein',
          onTap: widget.onSwitchToDriver,
        ),
        _menuRow(
          icon: Icons.emergency,
          title: 'Safety',
          subtitle: 'SOS 1122 aur safety maloomat',
          onTap: _showSafetyInfo,
        ),
        _menuRow(
          icon: Icons.receipt_long,
          title: 'Kiraye Ki List',
          subtitle: 'Har gaari ka per-km rate (public maloomat)',
          onTap: _showRatesList,
        ),
        _menuRow(
          icon: Icons.notifications,
          title: 'Notifications',
          subtitle: 'Ride ki khabar aur Master ke elanaat',
          onTap: () async {
            await Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => NotificationCentreScreen(store: store),
              ),
            );
            await store.markAllNotificationsRead();
          },
        ),
        _menuRow(
          icon: Icons.health_and_safety,
          title: tr('app_health'),
          subtitle: 'App ki sehat ki jaanch aur khud-repair',
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => AppHealthPage(store: store),
            ),
          ),
        ),
        _menuRow(
          icon: Icons.person,
          title: 'Meri Profile aur Settings',
          subtitle: 'Photo, Gmail, logout aur account delete',
          onTap: _openProfileSettings,
        ),
        _menuRow(
          icon: Icons.info_outline,
          title: 'Maloomat / About',
          subtitle: 'App ki tafseel aur version',
          onTap: _showAbout,
        ),
      ],
    );
  }

  /// Menu ke sir-khate ka avatar: passenger ki apni photo
  /// (local file) ho to woh, file na mile to naam ke harf
  /// wala maujooda avatar — jaali photo kabhi NAHI।
  Widget _menuAvatar() {
    final path = store.passengerPhotoLocalPath;
    if (path.isEmpty) return InitialAvatar(name: store.passengerName);
    return ClipOval(
      child: Image.file(
        File(path),
        width: 38,
        height: 38,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) =>
            InitialAvatar(name: store.passengerName),
      ),
    );
  }

  /// Gol shortcut button (menu ke upar wali patti)।
  Widget _menuShortcut({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(40),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFFE7F2EC),
                border: Border.all(color: Brand.gold, width: 1.2),
              ),
              child: Icon(icon, color: Brand.green, size: 25),
            ),
            const SizedBox(height: 6),
            Text(label,
                style:
                    const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }

  /// Menu ki saaf list row (Madad tab wala Card andaaz)।
  Widget _menuRow({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Card(
        margin: EdgeInsets.zero,
        child: ListTile(
          leading: Icon(icon, color: Brand.green),
          title: Text(title,
              style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        ),
      ),
    );
  }

  /// Profile/Settings ki asal screen — purana mukammal
  /// Profile body (PassengerProfileBody) isi mein chalta
  /// hai: Meri Maloomat, profile photo, Gmail/OTP, Agent
  /// hisa, Sharait/Privacy, Logout, Account Delete — sab
  /// kuchh waisa ka waisa।
  void _openProfileSettings() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => PassengerProfileScreen(store: store),
      ),
    );
  }

  /// Payment ki imaandar maloomat — pilot mein sirf Cash
  /// hai; koi card/online jhoota option NAHI banaya gaya।
  Future<void> _showPaymentInfo() async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.payments, color: Brand.green, size: 24),
            SizedBox(width: 8),
            Text('Payment'),
          ],
        ),
        content: const Text(
          'Is waqt Bozdar Safar par sirf CASH chalta hai — ride mukammal hone par kiraya seedha driver ko cash dein.\n\n'
          'Koi card ya online payment abhi NAHI hai. Jab woh sahulat aye gi to app mein khabar milegi.',
          style: TextStyle(fontSize: 13.5, height: 1.45),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Theek Hai'),
          ),
        ],
      ),
    );
  }

  /// Safety maloomat + asal 1122 call ka button (ride wali
  /// screen ke SOS wala hi rawaiya)।
  Future<void> _showSafetyInfo() async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.emergency, color: Brand.ajrakRed, size: 24),
            SizedBox(width: 8),
            Text('Safety — Emergency'),
          ],
        ),
        content: const Text(
          'Shadeed emergency mein sab se pehle 1122 par call karein.\n\n'
          'Ride ke doran ride wali screen par SOS ka button bhi hai — wahan se 1122 par call hoti hai aur Master ke inbox mein alag SOS pehchan ke saath khabar jati hai.\n\n'
          'Ride ki tafseel (driver ka naam, gaari, number plate) apno ko share karna achi hifazati aadat hai — ride wali screen se share ho jati hai.',
          style: TextStyle(fontSize: 13.5, height: 1.45),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Band Karein'),
          ),
          ElevatedButton.icon(
            onPressed: () => launchUrl(Uri.parse('tel:1122')),
            icon: const Icon(Icons.call, size: 17),
            label: const Text('1122 Call Karein'),
            style: ElevatedButton.styleFrom(backgroundColor: Brand.ajrakRed),
          ),
        ],
      ),
    );
  }

  /// Kiraye ki public list — per-km rates (ye wohi rates
  /// hain jin se kiraya banta hai; kisi khaas ride ka
  /// computed fare NAHI hai — fare lock barkarar)।
  Future<void> _showRatesList() async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.receipt_long, color: Brand.green, size: 24),
            SizedBox(width: 8),
            Text('Kiraye Ki List'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (final v in kVehicles)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Row(
                  children: [
                    Icon(_vehicleIcon(v), color: Brand.green, size: 21),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(v,
                          style: const TextStyle(
                              fontSize: 14.5, fontWeight: FontWeight.w800)),
                    ),
                    Text('Rs ${Fares.perKm[v] ?? 0} / km',
                        style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: Brand.greenDark)),
                  ],
                ),
              ),
            const SizedBox(height: 8),
            Text(
              'Kiraya = rate × asal sadak ki doori (km) — koi chhupa charge NAHI. Har ride ka kam se kam kiraya Rs ${Fares.minFareRs} hai. Driver ke pohanchnay ke baad pehle ${Fares.freeWaitingMinutes} minute intezaar muft hai.',
              style: const TextStyle(fontSize: 12.5, color: Colors.black54, height: 1.4),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Theek Hai'),
          ),
        ],
      ),
    );
  }

  /// About — app ka naam, chhoti tafseel, version (pubspec
  /// se bandhe hue constants) aur map attribution।
  Future<void> _showAbout() async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.info_outline, color: Brand.green, size: 24),
            SizedBox(width: 8),
            Text('Bozdar Safar'),
          ],
        ),
        content: const Text(
          'Pakistan ki apni ride app — Car, Taxi, Rickshaw, Bike aur Van, ek hi app mein.\n\n'
          'Version $kAppVersion (build $kAppVersionCode)\n\n'
          '$kOsmAttribution — map ka data OpenStreetMap se ata hai.',
          style: TextStyle(fontSize: 13.5, height: 1.45),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Theek Hai'),
          ),
        ],
      ),
    );
  }

  IconData _vehicleIcon(String v) => v == 'Car'
      ? Icons.directions_car
      : v == 'Bike'
          ? Icons.two_wheeler
          : v == 'Taxi'
              ? Icons.local_taxi
              : v == 'Van'
                  ? Icons.airport_shuttle
                  : Icons.electric_rickshaw;

  /// Gaariyon ki Roman-Urdu taglines — sab price-free hain (owner lock).
  static const Map<String, String> _vehicleTaglines = {
    'Rickshaw': 'Shehar ki sawari, sab ki pasand',
    'Bike': 'Jaib par halki, traffic ke liye behtareen',
    'Car': 'Aaram deh sawari, family ke liye behtareen',
    'Taxi': 'AC taxi, waqt par pohanchne ki zamanat',
    'Van': 'Poori family aur samaan ke liye wasee jagah',
  };

  /// Careem "Ride details" style vehicle row (v1.0.8): icon left, bold
  /// naam + grey Roman-Urdu tagline, radio circle right, selected row
  /// highlighted. Koi price NAHI — owner ka lock (v1.0.7 se barqarar):
  /// booking se pehle kiraya kahin nazar nahi aata; kul kiraya sirf
  /// ride pakki hone ke BAAD dikhta hai.
  Widget _vehicleRow({
    required String vehicle,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFFE7F2EC) : Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? Brand.green : Brand.fieldBorder,
              width: selected ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              // v1.4.5 list styling (brief §3): goal sabz icon chip —
              // selected par bhara sabz + sunehri kinara.
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color:
                      selected ? Brand.green : const Color(0xFFE7F2EC),
                  border: Border.all(
                    color: selected ? Brand.gold : Colors.transparent,
                    width: 1.6,
                  ),
                ),
                child: Icon(_vehicleIcon(vehicle),
                    color: selected ? Colors.white : Brand.green,
                    size: 25),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(vehicle,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(_vehicleTaglines[vehicle] ?? '',
                        style: const TextStyle(
                            fontSize: 12.5, color: Colors.black54)),
                  ],
                ),
              ),
              Container(
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: selected ? Brand.green : const Color(0xFFB9CFC6),
                    width: 2,
                  ),
                ),
                child: selected
                    ? Center(
                        child: Container(
                          width: 11,
                          height: 11,
                          decoration: const BoxDecoration(
                            color: Brand.green,
                            shape: BoxShape.circle,
                          ),
                        ),
                      )
                    : null,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- Booking view: full map + overlay sheet (inDrive style) ---------------

  Widget _bookingView() {
    final size = MediaQuery.of(context).size;
    return Stack(
      children: [
        Positioned.fill(
          child: SafarMapView(
            center: _pickup,
            initialZoom: 13.5,
            tilt: 50,
            pickup: _pickup,
            drop: _drop,
            routePoints: _routePoints,
            zonePoints: [
              for (final z in store.zoneNames)
                if (kZoneCoords[z] != null) kZoneCoords[z]!,
            ],
            interactive: true,
            fitToRoute: true,
            externalStyleControl: true,
            satellite: _satellite,
            onSatelliteChanged: (v) => setState(() => _satellite = v),
            onTapPoint: (p) {
              if (_dropArmed) {
                _placeDrop(p);
              } else {
                _setPickup(p);
              }
            },
            onLongPressPoint: _placeDrop,
            focusPoint: _focusPoint,
            focusSeq: _focusSeq,
          ),
        ),
        // Map quick actions
        Positioned(
          top: 10,
          right: 12,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              FloatingActionButton.small(
                heroTag: 'gps',
                onPressed: _myLocation,
                backgroundColor: Colors.white,
                foregroundColor: Brand.green,
                child: const Icon(Icons.my_location),
              ),
              const SizedBox(height: 4),
              const Text('Meri\nLocation',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
              const SizedBox(height: 10),
              FloatingActionButton.small(
                heroTag: 'droppin',
                // v1.4.28: pin-mode khula ho to yehi button us ka
                // Wapas (cancel) hai; warna drop arm ka purana
                // toggle rawaiya barkarar।
                onPressed: _pinMode
                    ? _exitPinMode
                    : () => setState(() => _dropArmed = !_dropArmed),
                backgroundColor: _dropArmed ? Brand.gold : Colors.white,
                foregroundColor: Brand.green,
                child: Icon(_pinMode ? Icons.close : Icons.add_location_alt),
              ),
              const SizedBox(height: 4),
              const Text('Drop\nPin',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
              const SizedBox(height: 10),
              FloatingActionButton.small(
                heroTag: 'mapstyle',
                onPressed: () => setState(() => _satellite = !_satellite),
                backgroundColor: _satellite ? Brand.gold : Colors.white,
                foregroundColor: Brand.green,
                child: const Icon(Icons.layers),
              ),
              const SizedBox(height: 4),
              const Text('Map\nStyle',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
            ],
          ),
        ),
        // Upar wali chhoti hidayat chip — pin-mode mein us ki
        // jagah bari hidayat patti le leti hai (neeche dekhein)।
        if (!_pinMode)
          Positioned(
            top: 10,
            left: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.92),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Brand.gold),
              ),
              child: const Text(
                'Pickup: map par tap karein\nDrop: lamba dabayein ya Drop Pin button se',
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
              ),
            ),
          ),
        // v1.4.28 PIN MODE ki hidayat patti — poora map khula
        // hai, panel ghayab; map par tap = manzil ka pin,
        // "Wapas" = baghair pin ke wapas (panel phir khul
        // jayega jaisa tha)।
        if (_pinMode)
          Positioned(
            top: 10,
            left: 12,
            right: 64,
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 6, 8),
              decoration: BoxDecoration(
                color: Brand.deepGreen,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.25),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  const Icon(Icons.add_location_alt,
                      color: Brand.gold, size: 20),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text(
                      kPinModeHint,
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w700),
                    ),
                  ),
                  TextButton(
                    onPressed: _exitPinMode,
                    child: const Text('Wapas',
                        style: TextStyle(
                            color: Brand.goldLight,
                            fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
            ),
          ),
        // Neeche wala hissa teen haalaton mein badalta hai
        // (v1.4.28, Yango-style flow):
        //  - pin-mode: kuch NAHI — poora map saaf, sirf upar
        //    wali hidayat patti।
        //  - flow band: Home bar — "Kahan Jana Hai?" + paanch
        //    gaariyon ke quick tiles (map zyada se zyada khula)।
        //  - flow khula: booking sheet — pehle compact (sirf
        //    Pickup/Drop + jagahen), drop pin + asal route ke
        //    baad poori tafseel ke saath bari।
        if (!_pinMode && !_flowOpen) _homeBar(),
        if (!_pinMode && _flowOpen)
          Positioned(
            left: 10,
            right: 10,
            bottom: 10,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(26),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.22),
                    blurRadius: 18,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                    maxHeight:
                        size.height * (_bookingReady ? 0.62 : 0.52)),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
                  child: _bookingForm(),
                ),
              ),
            ),
          ),
      ],
    );
  }

  /// v1.4.28 HOME BAR (Yango-style): full map ke neeche ek
  /// saaf bar — bara "Kahan Jana Hai?" wala khana (dabane par
  /// booking flow khulta hai) aur us ke neeche paanch
  /// gaariyon ke quick tiles (tile = wohi gaari preselect
  /// karke flow khulta hai)। Rang sirf Safar ke (sabz +
  /// sunehra) — flow ka andaaz milta-julta, pehchan apni।
  Widget _homeBar() {
    return Positioned(
      left: 10,
      right: 10,
      bottom: 10,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(26),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.22),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            InkWell(
              onTap: () => _openFlow(),
              borderRadius: BorderRadius.circular(16),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
                decoration: BoxDecoration(
                  color: const Color(0xFFEFF6F1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Brand.fieldBorder),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.search, color: Brand.green, size: 22),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(tr('where_to'),
                          style: TextStyle(
                              fontSize: 16.5,
                              fontWeight: FontWeight.w800,
                              color: Brand.greenDark)),
                    ),
                    const Icon(Icons.place, color: Brand.gold, size: 22),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (var i = 0; i < kVehicles.length; i++) ...[
                  if (i > 0) const SizedBox(width: 6),
                  Expanded(child: _vehicleTile(kVehicles[i])),
                ],
              ],
            ),
            // OSM attribution — ye bar map ke neeche wale
            // kinare ko dhakta hai, is liye map badge ki
            // jagah yahan footer line wohi shart poori
            // karti hai (license: attribution parha ja
            // sakna chahiye)।
            const SizedBox(height: 8),
            const Center(
              child: Text(
                kOsmAttribution,
                style: TextStyle(fontSize: 9.5, color: Colors.black38),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Home bar ki gaari tile — dabane par booking flow usi
  /// gaari ke preselect ke saath khulta hai।
  Widget _vehicleTile(String v) {
    final selected = _vehicle == v;
    return InkWell(
      onTap: () => _openFlow(vehicle: v),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 2),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFE7F2EC) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? Brand.green : Brand.fieldBorder,
            width: selected ? 1.6 : 1,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(_vehicleIcon(v), color: Brand.green, size: 23),
            const SizedBox(height: 4),
            Text(
              v,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                  fontSize: 11, fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }

  /// Jagahon ki list wali saaf row (Yango-style) — mehfooz
  /// jagah ho ya pichhli ride ki manzil, dono ke liye ek hi
  /// andaaz: icon, naam, neeche tafseel।
  Widget _placeRow({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 2),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFFE7F2EC),
              ),
              child: Icon(icon, color: Brand.green, size: 19),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 13.5, fontWeight: FontWeight.w800)),
                  if (subtitle.isNotEmpty)
                    Text(subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 12, color: Colors.black54)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, size: 18, color: Colors.black38),
          ],
        ),
      ),
    );
  }

  Widget _bookingForm() {
    // v1.4.28: pichhli jagahen (recents) ek dafa gin kar
    // rakho — jagahon wali list ki shart aur rows dono ke
    // liye (booking_flow.dart ka khalis hisaab)।
    final recents = recentDropPlaces(store.bookings);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Sheet ka drag handle (Careem style safed sheet, v1.0.8).
        Center(
          child: Container(
            width: 44,
            height: 5,
            decoration: BoxDecoration(
              color: Brand.fieldBorder,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
        ),
        const SizedBox(height: 6),
        // v1.4.28: Wapas wala teer — booking flow se Home bar
        // par wapas (form ki haalat mehfooz rehti hai; saaf
        // karna ho to neeche "Rehne Dein" hai)।
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back, color: Brand.green),
              tooltip: 'Wapas',
              visualDensity: VisualDensity.compact,
              onPressed: () => setState(() => _flowOpen = false),
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Board greeting (brief §3): asal saved naam
                  // se — naam na ho to sirf salaam (koi hardcode
                  // naam NAHI)।
                  Text(
                    store.passengerName.trim().isEmpty
                        ? 'Assalam O Alaikum'
                        : 'Assalam O Alaikum, ${store.passengerName.trim()}',
                    style: const TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w700,
                        color: Brand.green),
                  ),
                  const SizedBox(height: 3),
                  const Text('Kahan jana hai?',
                      style: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w900,
                          color: Brand.greenDark)),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        const Text(
          'Manzil neeche wali list se chunein, field mein likhein, ya map par pin lagayein. Kul kiraya booking pakki hone ke baad samne aayega — kiraya pakka hai, koi mol-bhav nahi.',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 12),
        // Drop / Pickup — Careem style: ek saaf card, dot-line markers,
        // manzil (drop) PEHLE, pickup doosra.
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Brand.fieldBorder),
          ),
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 4),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  const SizedBox(height: 17),
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: Brand.ajrakRed,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                  Container(
                    width: 2,
                    height: 36,
                    color: Brand.fieldBorder,
                  ),
                  Container(
                    width: 12,
                    height: 12,
                    decoration: const BoxDecoration(
                      color: Brand.green,
                      shape: BoxShape.circle,
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  children: [
                    TextField(
                      controller: _dropCtrl,
                      decoration: InputDecoration(
                        labelText: tr('drop_point'),
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                      ),
                      onChanged: (t) => _onPlaceTextChanged('drop', t),
                    ),
                    const Divider(height: 1, color: Brand.fieldBorder),
                    TextField(
                      controller: _pickupCtrl,
                      decoration: InputDecoration(
                        labelText: tr('pickup_point'),
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                      ),
                      onChanged: (t) => _onPlaceTextChanged('pickup', t),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        // v1.4.29 SEARCH SUGGESTIONS: type karte hi asal
        // jagahen (naam + sheher ke saath) — tap = wohi jagah
        // set + camera wahan। Service down ho to saaf
        // paighaam; jaali suggestion kabhi NAHI banti।
        if (_searchBusy ||
            _searchFailed ||
            _suggestions.isNotEmpty ||
            (_searchDone && _suggestions.isEmpty)) ...[
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Brand.fieldBorder),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_searchBusy)
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                        const SizedBox(width: 10),
                        Text(tr('search_busy')),
                      ],
                    ),
                  )
                else if (_searchFailed)
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        const Icon(Icons.cloud_off,
                            size: 18, color: Brand.ajrakRed),
                        const SizedBox(width: 10),
                        Expanded(child: Text(tr('search_failed'))),
                      ],
                    ),
                  )
                else if (_suggestions.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(tr('search_no_results')),
                  )
                else
                  for (final place in _suggestions)
                    ListTile(
                      dense: true,
                      leading: const Icon(Icons.place,
                          color: Brand.green, size: 20),
                      title: Text(place.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 14)),
                      subtitle: Text(place.displayName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 11.5)),
                      onTap: () => _applySearchPlace(_searchField, place),
                    ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 12),
        // v1.4.28: MAP SE PIN button — drop field ke foran
        // neeche, saaf aur bara; dabane par pin-mode khulta
        // hai (panel ghayab, poora map + hidayat patti)। Drop
        // Pin FAB aur map par long-press wale purane raste bhi
        // barkarar hain।
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: _enterPinMode,
            icon: const Icon(Icons.add_location_alt, size: 19),
            label: Text(tr('pin_mode_btn')),
            style: OutlinedButton.styleFrom(
              foregroundColor: Brand.green,
              side: const BorderSide(color: Brand.green, width: 1.4),
              padding: const EdgeInsets.symmetric(vertical: 12),
              textStyle:
                  const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w800),
            ),
          ),
        ),
        // Safar ki doori (v1.2.2) — SIRF maloomat hai, kiraya
        // nahi: route ki SADAK wali doori hi dikhti hai aur
        // wohi kiraaye ki bunyaad hai; route abhi na aya ho to
        // number ki jagah "route maloom kiya ja raha hai" ata
        // hai — seedhi doori ka andaza number kabhi fare ka
        // number ban kar NAHI dikhta (v1.4.25 fare gate)।
        // Kiraya (Rs) booking se pehle kahin NAHI dikhta —
        // lock barkarar (v1.4.28 mein bhi: gaariyon ki list
        // mein computed fare NAHI lagta)।
        if (_drop != null) ...[
          const SizedBox(height: 10),
          Row(
            children: [
              const Icon(Icons.route, size: 16, color: Brand.green),
              const SizedBox(width: 6),
              Text(
                _routeKm != null
                    ? trf('trip_distance',
                        {'km': _routeKm!.toStringAsFixed(1)})
                    : tr('route_finding_p'),
                style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Brand.greenDark),
              ),
            ],
          ),
        ],
        // v1.4.28 JAGAHON KI LIST (Yango-style rows, malik ka
        // naya hukm): sawari ki APNI mehfooz jagahen + pichhli
        // rides ki manzelein — tap = manzil + pin, route khud
        // banta hai. (v1.4.5 mein hati hui "Qareebi Jagahen"
        // aam ilaqa-naamon ki list thi; ye us se mukhtalif hai
        // — ye sawari ki apni jagahen hain.) Address-search/
        // geocoding app mein maujood NAHI hai, is liye typing
        // par jaali suggestions NAHI bante — list + pin hi
        // asal raste hain।
        if (store.savedPlaces.isNotEmpty ||
            store.savedGhar.isNotEmpty ||
            store.savedDaftar.isNotEmpty ||
            recents.isNotEmpty) ...[
          const SizedBox(height: 12),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text('Mehfooz aur Pichhli Jagahen',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
          ),
          const SizedBox(height: 2),
          for (final sp in store.savedPlaces)
            _placeRow(
              icon: sp.name == 'Ghar'
                  ? Icons.home
                  : sp.name == 'Daftar'
                      ? Icons.work
                      : Icons.place,
              title: sp.name,
              subtitle: sp.label,
              onTap: () => _applySavedPlace(sp),
            ),
          // Purane Ghar/Daftar (sirf naam wale record) — alag
          // SavedPlace maujood ho to dohrao NAHI।
          if (store.savedGhar.isNotEmpty &&
              !store.savedPlaces.any((p) => p.name == 'Ghar'))
            _placeRow(
              icon: Icons.home,
              title: 'Ghar',
              subtitle: store.savedGhar,
              onTap: () => _applyPlace(true),
            ),
          if (store.savedDaftar.isNotEmpty &&
              !store.savedPlaces.any((p) => p.name == 'Daftar'))
            _placeRow(
              icon: Icons.work,
              title: 'Daftar',
              subtitle: store.savedDaftar,
              onTap: () => _applyPlace(false),
            ),
          for (final b in recents)
            _placeRow(
              icon: Icons.history,
              title: b.dropLabel,
              subtitle: 'Pichhli ride ki manzil',
              onTap: () => _applyRecentDrop(b),
            ),
        ],
        // ---- STAGE 2 ka darwaza (v1.4.28 progressive
        // disclosure): tafseel sirf drop PIN + asal route par
        // khulti hai; tab tak sawari ko saaf wajah dikhti hai
        // ke aage kya hone wala hai।
        if (!_bookingReady) ...[
          const SizedBox(height: 12),
          const Text(
            'Manzil ka pin lagte hi aur asal route pakka hote hi gaariyan, note aur "Ride Pakki Karein" yahin khul jayenge.',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
        if (_bookingReady) ...[
          const SizedBox(height: 12),
          // Jagah save/set/manage wale controls — pehle ye
          // stage 1 mein bheer karte thay; ab stage 2 mein
          // hain (koi feature ghayab NAHI hua)।
          Row(
            children: [
              const Text('Save jagah: ',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              ActionChip(
                label: const Text('Ghar'),
                onPressed: () => _applyPlace(true),
              ),
              const SizedBox(width: 6),
              ActionChip(
                label: const Text('Daftar'),
                onPressed: () => _applyPlace(false),
              ),
              const Spacer(),
              TextButton.icon(
                onPressed: () => _savePlace(true),
                icon: const Icon(Icons.edit, size: 15),
                label: const Text('Ghar set', style: TextStyle(fontSize: 12)),
              ),
              TextButton.icon(
                onPressed: () => _savePlace(false),
                icon: const Icon(Icons.edit, size: 15),
                label: const Text('Daftar set', style: TextStyle(fontSize: 12)),
              ),
            ],
          ),
          // v1.4.0: maujooda pickup/drop ko kisi bhi naam se
          // mehfooz jagah banana + mehfooz jagahen manage
          // karna।
          Row(
            children: [
              TextButton.icon(
                onPressed: _saveCurrentPlace,
                icon: const Icon(Icons.bookmark_add_outlined, size: 15),
                label: const Text('Ye jagah save karein',
                    style: TextStyle(fontSize: 12)),
              ),
              if (store.savedPlaces.isNotEmpty)
                TextButton.icon(
                  onPressed: _manageSavedPlaces,
                  icon: const Icon(Icons.bookmarks_outlined, size: 15),
                  label: const Text('Jagahen manage',
                      style: TextStyle(fontSize: 12)),
                ),
            ],
          ),
          // v1.4.27 (#23): saaf wazahat — saved places sirf
          // is phone ke local record mein hain, doosre phone
          // par nahi milte (backend sync is ka hissa NAHI
          // hai)।
          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Ye jaghein sirf is phone mein mehfooz hain.',
              style: TextStyle(fontSize: 11.5, color: Colors.black45),
            ),
          ),
          const SizedBox(height: 10),
        TextField(
          controller: _nameCtrl,
          decoration: const InputDecoration(
              labelText: 'Aap ka naam', prefixIcon: Icon(Icons.person)),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _phoneCtrl,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
              labelText: 'Mobile number', prefixIcon: Icon(Icons.phone)),
        ),
        const SizedBox(height: 14),
        const Text('Ride ki Tafseel',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 8),
        ...kVehicles.map((v) => _vehicleRow(
              vehicle: v,
              selected: _vehicle == v,
              onTap: () => setState(() => _vehicle = v),
            )),
        // (v1.4.28: "Safar ki doori" wali line ab upar stage 1
        // mein hai — pin button ke foran neeche — taake doori/
        // route ki haalat manzil chunte hi nazar aye; yahan
        // dohrao hata diya gaya hai।)
        const SizedBox(height: 10),
        TextField(
          controller: _noteCtrl,
          decoration: const InputDecoration(
            labelText: 'Driver ke liye note (gate number, samaan, bacche...)',
            prefixIcon: Icon(Icons.note_alt),
          ),
        ),
        const SizedBox(height: 10),
        // Waiting note — sirf ek halki si line (koi number/price nahi).
        const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.schedule, size: 15, color: Colors.black45),
            SizedBox(width: 6),
            Expanded(
              child: Text(
                'Driver ke pohanchnay ke baad thora intezaar bilkul muft hai — zyada intezaar par munasib waiting charges kul kiraya mein shamil ho jayenge.',
                style: TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        // EK bara full-width button — Careem ke "CHALO!" wali jagah par,
        // Safar ke apne gehre sabz rang mein.
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _confirmBooking,
            style: ElevatedButton.styleFrom(
              backgroundColor: Brand.deepGreen,
              padding: const EdgeInsets.symmetric(vertical: 17),
              textStyle:
                  const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
            ),
            child: Text(tr('book_ride')),
          ),
        ),
        Center(
          child: TextButton(
            onPressed: _clearBookingForm,
            child: const Text('Rehne Dein'),
          ),
        ),
        const SizedBox(height: 4),
        // Monthly Package ka darwaza Home par (brief §3-A: bottom
        // nav ane par bhi Monthly ka entry ghayab NAHI hoga).
        Card(
          margin: EdgeInsets.zero,
          color: const Color(0xFFE7F2EC),
          child: ListTile(
            leading: const Icon(Icons.calendar_month, color: Brand.green),
            title: const Text('Monthly Package',
                style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text(
                'Rozana ek hi raste ka pakka package — school, daftar, dukaan.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => setState(() => _tab = 2),
          ),
        ),
        ], // <- v1.4.28: stage 2 (bookingReady) yahan band hota hai
        // OSM attribution footer — booking sheet map ke
        // neeche wale kinare ko dhakti hai; map badge ki
        // jagah ye line license ki shart poori karti hai।
        const SizedBox(height: 10),
        const Center(
          child: Text(
            kOsmAttribution,
            style: TextStyle(fontSize: 9.5, color: Colors.black38),
          ),
        ),
      ],
    );
  }

  // --- Meri Bookings ---------------------------------------------------------

  /// TRIP SHARE (v1.4.4): ride ki tafseel — driver ka naam, gaari,
  /// number plate, pickup/drop — SYSTEM SHARE SHEET se bhejna
  /// (WhatsApp, SMS, jo app user chune). Do-phone par pehchan ASAL
  /// driver ki jati hai (booking par backend se ayi hui); share
  /// sheet kisi wajah se na khule to purana WhatsApp (wa.me)
  /// tareeqa fallback hai.
  Future<void> _shareRide(Booking b) async {
    final p = store.profile;
    final twoPhone = b.assignedDriverId.isNotEmpty && !b.acceptedHere;
    final dName = twoPhone ? b.driverName : p.name;
    final dVehicle = twoPhone
        ? (b.driverVehicleDetail.isNotEmpty
            ? b.driverVehicleDetail
            : b.vehicle)
        : p.vehicle;
    final dPlate = twoPhone ? b.driverPlate : p.plate;
    final text = 'Bozdar Safar — meri ride ki tafseel:\n'
        'Driver: $dName ($dVehicle${dPlate.isEmpty ? '' : ' · Number plate $dPlate'})\n'
        'Route: ${b.pickupLabel} → ${b.dropLabel}\n'
        'Waqt: ${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)}\n'
        'Main is ride mein safar kar raha/rahi hun.';
    try {
      await Share.share(text, subject: 'Bozdar Safar — meri ride');
      return;
    } catch (_) {
      // Share sheet na khuli — WhatsApp wala purana tareeqa.
    }
    final uri = Uri.parse('https://wa.me/?text=${Uri.encodeComponent(text)}');
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) _snack('Share nahi ho saka.');
  }

  /// Driver ko call — v1.4.2: do-phone par ASAL driver ka number
  /// booking par backend se ata hai (driverPhone); same-device par
  /// woh khaali hota hai to is phone ke profile number par girte
  /// hain (pilot wala purana rawaiya).
  Future<void> _callDriverFor(Booking b) async {
    final phone = (b.driverPhone.isNotEmpty
            ? b.driverPhone
            : store.profile.phone)
        .trim();
    if (phone.isEmpty) {
      _snack('Driver ka number abhi set nahi hai.');
      return;
    }
    final ok = await launchUrl(Uri.parse('tel:$phone'));
    if (!ok && mounted) _snack('Call nahi ho saki.');
  }

  /// Master ko Message screen (v1.2.7) — "Meri Bookings" ke neeche
  /// wale darwaze se khulti hai; booking wali screen/flow bilkul
  /// nahi chheri gayi (display lock).
  Future<void> _openMessages() async {
    await Navigator.of(context).push(
      MaterialPageRoute<bool>(
        builder: (_) => MasterMessagesScreen(store: store, role: 'passenger'),
      ),
    );
    if (mounted) setState(() {});
  }

  Widget _myBookingsView() {
    return Column(
      children: [
        // (v1.4.5: "Meri Profile" wala card yahan se hat gaya —
        // Profile ab bottom nav ka apna tab hai. Master ko
        // Message ka darwaza yahan bhi barkarar hai aur Madad
        // tab mein bhi.)
        // Master ko Message (v1.2.7): masla/shikayat seedha Master
        // (head) ko — hamesha nazar ane wala darwaza, bookings hon
        // ya na hon.
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
          child: Card(
            margin: EdgeInsets.zero,
            child: ListTile(
              leading: const Icon(Icons.mail_outline, color: Brand.green),
              title: const Text('Master ko Message',
                  style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text(
                  'Koi masla ya shikayat ho to seedha Master (head) ko message bhejein.'),
              trailing: const Icon(Icons.chevron_right),
              onTap: _openMessages,
            ),
          ),
        ),
        Expanded(child: _myBookingsList()),
      ],
    );
  }

  Widget _myBookingsList() {
    final list = store.bookings;
    if (list.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Abhi koi booking nahi hai.\nBooking wale hisse se pehli ride pakki karein.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15, color: Colors.black54),
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: list.length,
      itemBuilder: (context, i) {
        final b = list[i];
        final p = store.profile;
        final confirmed = b.status == 'accepted' || b.status == 'arrived';
        // v1.4.0: two-phone dispatch se mili driver ki LIVE jagah —
        // mojood ho to ETA isi se, warna same-device wali jagah se.
        final remote = _remoteDriverPos[b.id];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.route, color: Brand.green),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text('${b.pickupLabel} → ${b.dropLabel}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 15)),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  '${b.vehicle} · ${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)}',
                  style: const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                if (b.note.isNotEmpty)
                  Text('Note: ${b.note}',
                      style: const TextStyle(fontSize: 12)),
                // v1.4.4: cancel / early-complete ki WAJAH record
                // mein saaf nazar aye — yehi woh saboot hai jo
                // Master ko bhi backend par dikhta hai.
                if (b.status == 'cancelled' && b.cancelReason.isNotEmpty)
                  Text('Mansookh ki wajah: ${b.cancelReason}',
                      style: const TextStyle(
                          fontSize: 12, color: Brand.ajrakRed)),
                if (b.status == 'completed' && b.endedEarly)
                  Text(
                      'Beech raaste mein yahin khatam hui${b.endReason.isEmpty ? '' : ' — wajah: ${b.endReason}'}',
                      style: const TextStyle(
                          fontSize: 12, color: Colors.black54)),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Chip(
                      label: Text(kStatusUrdu[b.status] ?? b.status),
                      backgroundColor: confirmed
                          ? const Color(0xFFDFF5E6)
                          : b.status == 'completed'
                              ? const Color(0xFFE8F0FE)
                              : const Color(0xFFF3E9C8),
                      labelStyle: const TextStyle(fontSize: 12),
                    ),
                    const Spacer(),
                    Text(rs(b.total),
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 17)),
                  ],
                ),
                if (b.status == 'completed') ...[
                  Text(
                    'Total kiraya: ${rs(b.total)} · Doori: ${b.distanceKm.toStringAsFixed(1)} km',
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                  // v1.4.24 TAX (SRB): mukammal ride ke hisaab
                  // mein tax ki ALAG line + kul adaigi (tax
                  // samait) — final raqam (completion par pakki)।
                  if (b.hasTax)
                    Text(
                      '${taxLabelFor(b.vehicle)}: ${rs(b.taxAmount)} · Kul adaigi (tax samait): ${rs(b.grandTotal)}',
                      style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Brand.greenDark),
                    ),
                  // SABOOT: is ride ki recording ho to yahan se
                  // dobara suni ja sakti hai (koi delete nahi).
                  if (b.evidenceLocalPath.isNotEmpty ||
                      b.evidenceRemotePath.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    EvidencePlayRow(store: store, booking: b),
                  ],
                  const SizedBox(height: 8),
                  // v1.4.0: mukammal ride ki RASEED (dialog + share).
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () => showReceiptDialog(context, store, b),
                      icon: const Icon(Icons.receipt_long, size: 18),
                      label: const Text('Raseed Dekhein'),
                    ),
                  ),
                  const SizedBox(height: 6),
                  // v1.4.4: is ride ki REPORT / Shikayat — Master
                  // inbox mein ride ke hawale ke saath jati hai.
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () =>
                          showReportDialog(context, store, b, role: 'passenger'),
                      icon: const Icon(Icons.report_outlined, size: 18),
                      label: const Text('Report / Shikayat Karein'),
                      style: OutlinedButton.styleFrom(
                          foregroundColor: Brand.ajrakRed),
                    ),
                  ),
                  const Divider(),
                  // v1.4.0: driver ki rating — 1–5 sitare + comment.
                  RatingRow(store: store, booking: b),
                ],
                if (confirmed) ...[
                  const Divider(),
                  const Text('Driver ki Pehchan',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  // v1.4.2: do-phone par pehchan ASAL driver ki
                  // (booking par backend se ayi hui); same-device
                  // par pehle wala local profile hi dikhta hai.
                  if (b.assignedDriverId.isNotEmpty && !b.acceptedHere)
                    Text(
                        '${b.driverName} · ${b.driverVehicleDetail.isNotEmpty ? b.driverVehicleDetail : b.vehicle}${b.driverPlate.isEmpty ? '' : ' · Plate ${b.driverPlate}'}')
                  else
                    Text(
                        '${p.name} · ${p.vehicle}${p.plate.isEmpty ? '' : ' · Plate ${p.plate}'} · ${p.zone}'),
                  if (store.backendRatingAvg != null)
                    Row(
                      children: [
                        const Icon(Icons.star, size: 15, color: Brand.gold),
                        const SizedBox(width: 4),
                        Text(
                          'Driver rating: ${store.backendRatingAvg!.toStringAsFixed(1)}',
                          style: const TextStyle(
                              fontSize: 12.5, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                  const Text(
                    'Driver CNIC-verified hai aur har booking record mein hai.',
                    style: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                  _DriverEtaLine(
                      store: store,
                      booking: b,
                      remoteLat: remote?.lat,
                      remoteLng: remote?.lng),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _callDriverFor(b),
                          icon: const Icon(Icons.call, size: 18),
                          label: const Text('Madad — Driver ko call karein'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Brand.ajrakRed,
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            textStyle: const TextStyle(
                                fontSize: 13, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () => _shareRide(b),
                      icon: const Icon(Icons.share, size: 18),
                      label: const Text('Ride ghar walon ko WhatsApp karein'),
                    ),
                  ),
                  const SizedBox(height: 6),
                  // v1.4.0: SOS — active ride ke doran hifazat.
                  SosButton(store: store, booking: b, role: 'passenger'),
                  const SizedBox(height: 6),
                  // SABOOT RECORDING (owner 2026-11-08): gambhir
                  // haalat mein active ride par audio saboot —
                  // Master ko khud khabar jati hai; recording
                  // delete nahi hoti.
                  EvidenceRecorderButton(
                    store: store,
                    booking: b,
                    role: 'passenger',
                    recorderName: b.passengerName,
                  ),
                  const SizedBox(height: 6),
                  // v1.4.16 RIDE CHAT: number share kiye baghair
                  // driver se baat — sirf active ride par.
                  RideChatButton(store: store, booking: b, role: 'passenger'),
                ],
                if (b.status == 'pending')
                  const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text(
                      'Booking driver ko bheji gayi hai — Driver Mode mein is ka jawab ayega.',
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ),
                // v1.4.29 CANCEL BUTTON (owner hukm 2026-11-11 —
                // screenshot mein atki booking par koi button
                // NAHI tha): pending ho ya accepted lekin ride
                // abhi SHURU na hui ho, passenger yahin se wajah
                // ke saath mansookh kar sakta hai।
                if (b.status == 'pending' ||
                    ((b.status == 'accepted' || b.status == 'arrived') &&
                        !b.rideStarted)) ...[
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () => _cancelFromList(b),
                      icon: const Icon(Icons.cancel, size: 18),
                      label: Text(tr('cancel_btn')),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Brand.ajrakRed,
                        side: const BorderSide(color: Brand.ajrakRed),
                        padding:
                            const EdgeInsets.symmetric(vertical: 10),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  /// v1.4.29: "Meri Bookings" list se ride mansookh — wohi
  /// maujooda wajah wala flow (wajah select → status cancelled
  /// + wajah record; store.cancelBooking hook se backend par
  /// bhi update hota hai)।
  Future<void> _cancelFromList(Booking b) async {
    // v1.4.29 (owner hukm 2026-11-11 16:29): driver ARRIVED
    // kar chuka ho (intezaar chal raha ho) to wajah COMPULSORY
    // — sheet band karke skip NAHI ho sakta; pending/accepted
    // stage par maujooda aam tareeqa hai।
    final arrivedStage = b.status == 'arrived';
    final reason = await showReasonSheet(
      context,
      title: arrivedStage
          ? tr('cancel_title_arrived')
          : tr('cancel_why_passenger'),
      options: kRideReasonOptions,
      mustGiveReason: arrivedStage,
    );
    if (reason == null || !mounted) return;
    await store.cancelBooking(b, reason: reason);
    if (mounted) {
      _snack(tr('ride_cancelled'));
      setState(() {});
    }
  }

  // --- Monthly package ---------------------------------------------------------

  bool get _monthlyReady =>
      _mPickupCtrl.text.trim().isNotEmpty &&
      _mDropCtrl.text.trim().isNotEmpty;

  int get _monthlyTotal =>
      Fares.monthlyAmount(_mVehicle, _mRouteKm, _mDays);

  /// Monthly form ke pins se asal OSRM road route ginna (v1.4.0):
  /// dono pins lagte hi route ata hai aur _mRouteKm usi road-km par
  /// set ho jata hai — monthly hisaab phir asal sadak wali doori par
  /// banta hai. v1.4.25: seedhi-line (crow-flies) fallback ko ROAD
  /// route NAHI mana jata — pehle woh bhi _mRouteIsRoad=true kar
  /// deta tha aur package andaze ki doori par ban jata tha। Route
  /// ka koi number user ko NAHI dikhta — sirf kul monthly raqam
  /// package pakka hone par dialog mein ati hai.
  Future<void> _refreshMonthlyRoute() async {
    final from = _mPickupPin;
    final to = _mDropPin;
    if (from == null || to == null) return;
    final token = ++_mRouteToken;
    try {
      final r = await RouteService.fetch(
        LatLng(from.latitude, from.longitude),
        LatLng(to.latitude, to.longitude),
      );
      if (!mounted || token != _mRouteToken) return;
      if (r.isStraightFallback) {
        // Asal sadak route NAHI mila — _mRouteIsRoad false hi
        // rahega; package is par NAHI banegi (gate confirm mein)।
        setState(() => _mRouteIsRoad = false);
        return;
      }
      final km = (r.distanceM / 1000);
      if (km <= 0) return;
      setState(() {
        _mRouteKm = km;
        _mRouteIsRoad = true;
      });
    } catch (_) {
      // Route na mila — _mRouteIsRoad false rehta hai (crash nahi;
      // package confirm wala gate sawari ko saaf batayega)।
    }
  }

  /// Monthly field ke text se zone ka pin nikalna — user zone ka
  /// naam likhe (masalan "Clifton") to kZoneCoords se pin mil jata
  /// hai; koi aur text ho to pin saaf ho jata hai.
  LatLng? _zonePinFor(String text) => kZoneCoords[text.trim()];

  void _onMonthlyPickupChanged() {
    final pin = _zonePinFor(_mPickupCtrl.text);
    if (pin != _mPickupPin) _mRouteIsRoad = false;
    _mPickupPin = pin;
    _refreshMonthlyRoute();
  }

  void _onMonthlyDropChanged() {
    final pin = _zonePinFor(_mDropCtrl.text);
    if (pin != _mDropPin) _mRouteIsRoad = false;
    _mDropPin = pin;
    _refreshMonthlyRoute();
  }

  Future<void> _confirmMonthly() async {
    if (!_monthlyReady) {
      _snack('Rozana pickup aur rozana drop dono likhein.');
      return;
    }
    // v1.4.25 MONTHLY FARE GATE (postmortem #5 ka monthly hissa):
    // package sirf tab bane jab dono jagahon ke PINS (pehchane
    // hue ilaqe ke naam se) lage hon AUR un ka ASAL sadak route
    // mil jaye। Pehle pin na honay par package 2.0 km placeholder
    // par ban jata tha — ab saaf wajah batayi jati hai।
    if (_mPickupPin == null || _mDropPin == null) {
      _snack('Pickup aur drop ke liye pehchana hua ilaqa ka naam likhein (jaise Clifton, Saddar, Gulshan) — baghair pakki jagah ke package ki raqam nahi banti.');
      return;
    }
    // Route abhi na aya ho (ya confirm se pehle fields badle
    // gaye hon) to pakka karne se pehle EK dafa asal route ki
    // koshish — bilkul booking flow jaisa usool।
    if (!_mRouteIsRoad) {
      try {
        await _refreshMonthlyRoute()
            .timeout(const Duration(seconds: 8), onTimeout: () {});
      } catch (_) {
        // Route na mila — neeche wala gate package rok dega।
      }
      if (!mounted) return;
    }
    if (!_mRouteIsRoad) {
      _snack('Route abhi nahi mil saka — internet check karke dobara koshish karein. Baghair asal route ke package pakka nahi hoga.');
      return;
    }
    final pkg = MonthlyPackage(
      id: store.newId(),
      passengerName: _nameCtrl.text.trim(),
      // v1.4.25: sawari ka ASAL number bhi package ke saath jata
      // hai (backend row par customer_mobile) — Master/driver
      // rabta isi se hoga। Form ka number ho to wohi, warna
      // store mein mehfooz number।
      passengerPhone: _phoneCtrl.text.trim().isNotEmpty
          ? _phoneCtrl.text.trim()
          : store.passengerPhone,
      pickup: _mPickupCtrl.text.trim(),
      drop: _mDropCtrl.text.trim(),
      vehicle: _mVehicle,
      routeKm: _mRouteKm,
      days: _mDays,
      monthlyAmount: _monthlyTotal,
      createdAt: DateTime.now(),
      // Naya package 'pending' hai — driver abhi pakka NAHI hua;
      // driver assign hoga (Master ya driver-pool se) to haalat
      // 'active' hogi aur sawari ko driver nazar ayega।
      status: 'pending',
    );
    await store.addMonthly(pkg);
    if (!mounted) return;
    // Kul monthly raqam PEHLI dafa yahin nazar aati hai — package pakka
    // hone ke BAAD (owner ka lock, v1.0.7). Form mein koi amount nahi.
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Brand.green, size: 26),
            SizedBox(width: 8),
            Text('Package Pakka Ho Gaya'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('${pkg.pickup} → ${pkg.drop}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text('${pkg.vehicle} · ${pkg.days} din',
                style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Brand.deepGreen,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                children: [
                  const Text('KUL MONTHLY RAQAM',
                      style: TextStyle(
                          color: Brand.goldLight,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.2)),
                  Text(rs(pkg.monthlyAmount),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.w900)),
                ],
              ),
            ),
            const SizedBox(height: 10),
            // v1.4.25: wada aur asal amal ab EK hain — package
            // bante hi driver pakka NAHI hota; ye saaf likha
            // jata hai ke driver ki tayinati baqi hai।
            const Text(
              'Driver abhi pakka nahi hua hai — Master ek driver tay karke package chalu karega. Driver pakka hote hi woh rozana isi jagah aur waqt par ayega — us ki haalat neeche "Mere Monthly Packages" mein nazar ayegi.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: Colors.black54, height: 1.4),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Theek Hai'),
          ),
        ],
      ),
    );
    if (!mounted) return;
    setState(() {});
  }

  /// Package ki haalat ki saaf line (v1.4.25) — wada aur amal
  /// ek: driver pakka ho to us ka naam, na ho to intezaar ki
  /// saaf khabar, cancel ho to wohi likha।
  String _packageStatusLine(MonthlyPackage p) {
    if (p.isCancelled) return 'Ye package cancel ho chuka hai.';
    if (p.hasDriver) {
      return p.driverName.isNotEmpty
          ? 'Driver pakka hai: ${p.driverName} — rozana wohi driver ayega.'
          : 'Driver pakka ho gaya hai — rozana wohi driver ayega.';
    }
    return 'Driver ka intezaar hai — Master driver tay kar raha hai.';
  }

  /// Package cancel ki tasdeeq + amal (v1.4.25)।
  Future<void> _cancelMonthly(MonthlyPackage p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Package Cancel Karein?'),
        content: Text(
            '${p.pickup} → ${p.drop} ka monthly package (${rs(p.monthlyAmount)}) band ho jayega. '
            'Ye amal Master ke record mein bhi nazar ayega.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Rehne Dein'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Brand.ajrakRed),
            child: const Text('Cancel Karein'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await store.cancelMonthly(p);
    if (!mounted) return;
    _snack('Package cancel ho gaya hai.');
    setState(() {});
  }

  void _clearMonthly() {
    setState(() {
      _mPickupCtrl.clear();
      _mDropCtrl.clear();
      _mVehicle = 'Rickshaw';
      _mRouteKm = 2.0;
      _mDays = 26;
      _mPickupPin = null;
      _mDropPin = null;
      _mRouteIsRoad = false;
    });
    _snack('Koi package nahi bana — sab saaf kar diya gaya.');
  }

  Widget _monthlyView() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('Monthly Package',
            style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w900,
                color: Brand.greenDark)),
        const SizedBox(height: 4),
        const Text(
          'Rickshaw / gaari mahine ke liye pakki karein — school, office ya madrassa ke liye. Ek dafa driver pakka ho jaye to rozana wohi driver, wohi jagah, wohi waqt.',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _mPickupCtrl,
          decoration: const InputDecoration(
              labelText: 'Rozana PICKUP jagah',
              prefixIcon: Icon(Icons.home)),
          onChanged: (_) => setState(_onMonthlyPickupChanged),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _mDropCtrl,
          decoration: const InputDecoration(
              labelText: 'Rozana DROP jagah',
              prefixIcon: Icon(Icons.school)),
          onChanged: (_) => setState(_onMonthlyDropChanged),
        ),
        // v1.4.5 (owner hukm 2026-11-08): zone NAAMON ke quick-pick
        // chips yahan se bhi KHATAM — booking screen wali wohi
        // correction. Monthly ki jagahen upar wale khano mein naam
        // likhne se (likha naam pin mein badal jata hai) ya map
        // pins se lagti hain; naamoon ki list screen par NAHI.
        const SizedBox(height: 10),
        const Text('Gaari',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 8),
        ...kVehicles.map((v) => _vehicleRow(
              vehicle: v,
              selected: _mVehicle == v,
              onTap: () => setState(() => _mVehicle = v),
            )),
        const SizedBox(height: 4),
        const Text('Mahine mein kitne din?',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: _dayChips
              .map((d) => ChoiceChip(
                    label: Text('$d din'),
                    selected: _mDays == d,
                    onSelected: (_) => setState(() => _mDays = d),
                  ))
              .toList(),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _confirmMonthly,
                child: const Text('Monthly Package Pakka Karein'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton(
                onPressed: _clearMonthly,
                child: const Text('Rehne Dein'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        const Text('Mere Monthly Packages',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.monthlyPackages.isEmpty)
          const Text('Abhi koi monthly package nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...store.monthlyPackages.map((p) => Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  ListTile(
                    leading:
                        const Icon(Icons.calendar_month, color: Brand.green),
                    title: Text('${p.pickup} → ${p.drop}',
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text(
                        '${p.vehicle} · ${p.days} din · ${fmtDate(p.createdAt)}'),
                    trailing: Text(rs(p.monthlyAmount),
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 15)),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
                    child: Text(
                      _packageStatusLine(p),
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                        color: p.isCancelled
                            ? Brand.ajrakRed
                            : p.hasDriver
                                ? Brand.greenDark
                                : Colors.black54,
                      ),
                    ),
                  ),
                  // v1.4.25: CANCEL button — pehle package band
                  // karne ka koi rasta hi NAHI tha।
                  if (!p.isCancelled)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(8, 0, 8, 6),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          onPressed: () => _cancelMonthly(p),
                          icon: const Icon(Icons.cancel_outlined, size: 18),
                          label: const Text('Package Cancel Karein'),
                          style: TextButton.styleFrom(
                              foregroundColor: Brand.ajrakRed),
                        ),
                      ),
                    ),
                ],
              ),
            )),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// "Driver Dhoonda Ja Raha Hai" — Careem ki "Finding your Captain" style
// screen (v1.0.8). Ye booking ki HALAT wali screen hai: booking darj ho
// chuki hai aur driver ke jawab ka intezaar hai — koi jhooti driver
// assignment nahi dikhayi jati. Pops with 'bookings' ya 'cancelled'.
// ---------------------------------------------------------------------------

/// PASSENGER EMAIL + OTP (v1.4.7, spec §1) — pehli booking se
/// pehle sawari ki Gmail tasdeeq ka safha। Kamyabi par email
/// store + passengers table (backend) dono jagah darj hoti hai
/// aur true wapas ata hai।
class _PassengerEmailPage extends StatefulWidget {
  final AppStore store;
  const _PassengerEmailPage({required this.store});

  @override
  State<_PassengerEmailPage> createState() => _PassengerEmailPageState();
}

class _PassengerEmailPageState extends State<_PassengerEmailPage> {
  late final _emailCtrl =
      TextEditingController(text: widget.store.passengerEmail);

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gmail Tasdeeq — Pehla Qadam')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.mark_email_read, size: 56, color: Brand.green),
          const SizedBox(height: 12),
          const Text(
            'Aap ki ID aap ki Gmail se banti hai',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          const Text(
            'Pehli booking se pehle apni Gmail likhein aur us par aya hua OTP code verify karein — tasdeeq ke baghair ID aage nahi badhti. Logout ke baad dobara login bhi isi Gmail ke OTP se hoga.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13.5, height: 1.5),
          ),
          const SizedBox(height: 18),
          EmailOtpSection(
            emailCtrl: _emailCtrl,
            alreadyVerifiedEmail:
                widget.store.passengerEmailVerified
                    ? widget.store.passengerEmail
                    : '',
            onVerified: (email) async {
              final nav = Navigator.of(context);
              await widget.store.applyPassengerEmailVerified(email);
              unawaited(Backend.syncPassengerSelf(widget.store));
              // v1.4.14: passengers row ki email lag gayi — ab
              // device pehchan Auth pehchan se bandh do
              // (link_passenger_device; row email == JWT email
              // ki shart linkIdentities ke andar poori hoti hai)।
              unawaited(Backend.linkIdentities(widget.store));
              if (mounted) nav.pop(true);
            },
          ),
        ],
      ),
    );
  }
}

class _FindingDriverView extends StatefulWidget {
  final AppStore store;
  final Booking booking;
  const _FindingDriverView({required this.store, required this.booking});

  @override
  State<_FindingDriverView> createState() => _FindingDriverViewState();
}

class _FindingDriverViewState extends State<_FindingDriverView> {
  // v1.4.0 two-phone dispatch (c): is screen par ride row ka poll
  // (~15s) — driver ki LIVE jagah (rides.driver_lat/lng) ETA ke
  // liye, aur backend par badli status ka notification diff.
  Timer? _poll;
  double? _remoteLat;
  double? _remoteLng;

  /// v1.4.9: assign driver ki asal haalat (drivers row ke online +
  /// loc_at se — poll ke saath taaza hoti hai) aur map ke teer ki
  /// simt (remote positions ki lagatar harkat se nikli hui).
  bool? _driverOnlineRemote;
  double _driverBearing = 0;
  bool _ratingPromptShown = false;

  AppStore get store => widget.store;
  Booking get booking => widget.booking;

  @override
  void initState() {
    super.initState();
    _poll = Timer.periodic(
        const Duration(seconds: 15), (_) => unawaited(_pollOnce()));
    unawaited(_pollOnce());
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybePrompt());
  }

  @override
  void dispose() {
    _poll?.cancel();
    super.dispose();
  }

  Future<void> _pollOnce() async {
    // FINAL-PACK D: poll se pehle ki haalat — driver-cancel ki
    // pehchan isi tabdeeli se hoti hai.
    final prevStatus = booking.status;
    final row = await Backend.fetchRideRow(booking.id);
    if (row == null || !mounted) return;
    final lat = (row['driver_lat'] as num?)?.toDouble();
    final lng = (row['driver_lng'] as num?)?.toDouble();
    if (lat != null && lng != null && (lat != _remoteLat || lng != _remoteLng)) {
      // v1.4.9: teer ki simt — pichli jagah se 5m+ harkat par nayi
      // simt; khada ho to aakhri simt hi rehti hai.
      if (_remoteLat != null && _remoteLng != null) {
        final prev = LatLng(_remoteLat!, _remoteLng!);
        final next = LatLng(lat, lng);
        if (const Distance().as(LengthUnit.Meter, prev, next) > 5) {
          _driverBearing = safarBearingBetween(prev, next);
        }
      }
      setState(() {
        _remoteLat = lat;
        _remoteLng = lng;
      });
    }
    // v1.4.9: teer ka rang asal haalat se — driver duty par ho aur
    // us ki location taaza (loc_at < 3 min) ho to HARA, warna
    // KALA-SAFAID. Fetch na ho sake to purani value hi rehti hai.
    final drvId = booking.assignedDriverId;
    if (drvId.isNotEmpty) {
      final f = await Backend.fetchDriverFields(drvId, 'online,loc_at');
      if (f != null && mounted) {
        final locAt = DateTime.tryParse(f['loc_at']?.toString() ?? '');
        final fresh = locAt != null &&
            DateTime.now().toUtc().difference(locAt) <
                const Duration(minutes: 3);
        final val = f['online'] == true && fresh;
        if (val != _driverOnlineRemote) {
          setState(() => _driverOnlineRemote = val);
        }
      }
    }
    final st = row['status'];
    if (st is String && st.isNotEmpty && st != booking.status) {
      await store.observeBookingStatuses('passenger',
          remoteStatus: {booking.id: st});
    }
    // v1.4.2: asal haalat + driver tafseel local booking par —
    // is screen ka title, ETA line aur rating prompt sab isi par
    // chalte hain (do-phone par yehi woh kadri thi jo gayab thi).
    await Backend.applyRemoteRowToBooking(store, booking, row);
    if (mounted) {
      setState(() {});
      _maybePrompt();
    }
    // FINAL-PACK D: is ACTIVE screen par driver-cancel ka bara
    // notice — status pehli dafa 'cancelled' ho aur ride driver
    // ke paas gayi hui ho (accepted/arrived thi ya driver assign
    // tha). Passenger ke apne cancel par ye NAHI ata (woh cancel
    // isi screen se hota hai aur view 'cancelled' result ke saath
    // band ho jata hai — poll us ke baad chalta hi nahi). Notice
    // per ride sirf ek dafa: store ka seen-set dono polls ke
    // darmiyan mushtarka hai.
    if (!mounted || st != 'cancelled' || prevStatus == 'cancelled') {
      return;
    }
    final remoteReason = row['cancel_reason']?.toString() ?? '';
    if (remoteReason.trim().isNotEmpty &&
        booking.cancelReason.trim().isEmpty) {
      booking.cancelReason = remoteReason.trim();
    }
    final hadDriver = prevStatus == 'accepted' ||
        prevStatus == 'arrived' ||
        booking.assignedDriverId.isNotEmpty ||
        (row['driver_id']?.toString().isNotEmpty ?? false);
    if (!hadDriver || store.hasCancelNoticeSeen(booking.id)) return;
    store.markCancelNoticeSeen(booking.id);
    await _showDriverCancelNoticeHere();
  }

  /// Finding screen wala driver-cancel notice: 'Dobara Ride
  /// Mangayein' is screen ko 'rebook:<id>' result ke saath band
  /// karta hai — PassengerSide purani ride se foran nayi ride
  /// bana deta hai (form dobara NAHI bharna parta). 'Band Karein'
  /// sirf notice band karta hai; ride ki cancelled haalat screen
  /// par waisi hi nazar ati rehti hai.
  Future<void> _showDriverCancelNoticeHere() async {
    if (!mounted) return;
    final b = booking;
    final reason = b.cancelReason.trim();
    final rebook = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.cancel, color: Brand.ajrakRed, size: 26),
            SizedBox(width: 8),
            Expanded(child: Text('Driver ne ride band kar di')),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${b.pickupLabel} → ${b.dropLabel}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(
              'Wajah: ${reason.isEmpty ? 'wajah nahi batayi gayi' : reason}',
              style: const TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 6),
            const Text(
              'Pareshan na hon — wohi pickup aur manzil par dobara ride foran mangayi ja sakti hai.',
              style: TextStyle(fontSize: 12.5, color: Colors.black54),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Band Karein'),
          ),
          ElevatedButton.icon(
            onPressed: () => Navigator.pop(ctx, true),
            icon: const Icon(Icons.refresh, size: 17),
            label: const Text('Dobara Ride Mangayein'),
          ),
        ],
      ),
    );
    if (rebook == true && mounted) {
      Navigator.pop(context, 'rebook:${b.id}');
    }
  }

  /// Ride complete nazar aye (local ya backend par) aur rating
  /// abhi na di ho to EK dafa star prompt khud khul jata hai —
  /// passenger chahe to band kar ke Meri Bookings se baad mein
  /// bhi de sakta hai.
  void _maybePrompt() {
    if (!mounted || _ratingPromptShown) return;
    final idx = store.bookings.indexWhere((x) => x.id == booking.id);
    final status = idx >= 0 ? store.bookings[idx].status : booking.status;
    if (status != 'completed') return;
    if (store.ratingFor(booking.id) != null) return;
    _ratingPromptShown = true;
    _showRatingDialog();
    if (mounted) setState(() {});
  }

  Future<void> _showRatingDialog() async {
    var stars = 0;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: const Text('Ride kaisi rahi?'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                  '${booking.pickupLabel} → ${booking.dropLabel}\nDriver ${booking.driverName} ko rating dein:',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 13)),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (var i = 1; i <= 5; i++)
                    IconButton(
                      onPressed: () => setD(() => stars = i),
                      icon: Icon(
                        i <= stars ? Icons.star : Icons.star_border,
                        color: Brand.gold,
                        size: 34,
                      ),
                    ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Baad Mein'),
            ),
            ElevatedButton(
              onPressed: stars <= 0
                  ? null
                  : () async {
                      await store.saveRating(RideRating(
                        bookingId: booking.id,
                        driverId: booking.assignedDriverId.isNotEmpty
                            ? booking.assignedDriverId
                            : store.driverId,
                        driverName: booking.driverName,
                        passengerName: booking.passengerName,
                        stars: stars,
                        comment: '',
                        createdAt: DateTime.now(),
                      ));
                      if (ctx.mounted) Navigator.pop(ctx);
                    },
              child: const Text('Rating Bhejein'),
            ),
          ],
        ),
      ),
    );
  }

  IconData _vehicleIcon(String v) => v == 'Car'
      ? Icons.directions_car
      : v == 'Bike'
          ? Icons.two_wheeler
          : v == 'Taxi'
              ? Icons.local_taxi
              : v == 'Van'
                  ? Icons.airport_shuttle
                  : Icons.electric_rickshaw;

  Future<void> _callDriver(BuildContext context) async {
    // v1.4.2: asal driver ka number booking se (backend), warna
    // same-device pilot ka profile number.
    final phone = (booking.driverPhone.isNotEmpty
            ? booking.driverPhone
            : store.profile.phone)
        .trim();
    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Driver ka number abhi set nahi hai.')),
      );
      return;
    }
    final ok = await launchUrl(Uri.parse('tel:$phone'));
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Call nahi ho saki.')),
      );
    }
  }

  /// APP SE BAHIR RIDE KI WARNING (v1.4.20, malik ka hukm
  /// 2026-11-10 19:46 — anti-leakage): driver ASSIGN ho chuka
  /// ho (ride accepted/arrived) aur sawari cancel karne lage
  /// to confirm se PEHLE ye sakht warning lazmi ati hai.
  /// Plain booking (driver milne se pehle wala cancel) par
  /// ye warning NAHI ati. Returns: true = sawari ne samajh
  /// kar cancel aage barhaya; false = ride jari rakhi.
  Future<bool> _showLeakageWarning(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Ek zaroori baat — pehle parh lein'),
        content: const Text(
          'Agar driver aap ko kahe ke ride cancel karke seedha us ke saath chalein — to cancel ke baad woh safar Bozdar Safar ke record se BAHIR ho jayega. Us safar mein hifazat, kiraye ya kisi bhi masle ki zimmedari Bozdar Safar ki NAHI hogi — woh aap ki apni hogi.\n\nMahfooz safar ke liye ride hamesha app ke andar mukammal karein.',
          style: TextStyle(fontSize: 14, height: 1.5),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Ride Jari Rakhein'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Samajh Gaya — Cancel Karein'),
          ),
        ],
      ),
    );
    return ok == true;
  }

  /// Cancel — v1.4.4 (malik ki khaas shart): wajah LAZMI
  /// poochhi jati hai (mushtarka showReasonSheet — tay-shuda
  /// list + apni baat) aur ride ke record ke saath hamesha ke
  /// liye mehfooz hoti hai (Master ko backend par nazar ati hai).
  /// v1.4.20: driver assign ho chuka ho to wajah se pehle
  /// app-se-bahir wali warning (oopar _showLeakageWarning).
  Future<void> _showCancelSheet(BuildContext context) async {
    final driverAssigned =
        booking.status == 'accepted' || booking.status == 'arrived';
    if (driverAssigned) {
      final proceed = await _showLeakageWarning(context);
      if (!proceed || !context.mounted) return;
    }
    final reason = await showReasonSheet(
      context,
      // v1.4.29: ARRIVED stage par wajah COMPULSORY (sheet
      // non-dismissible) — driver intezaar kar raha ho to
      // baghair wajah cancel NAHI hoga; wajah record par
      // mehfooz aur Master ko nazar ati hai।
      title: booking.status == 'arrived'
          ? tr('cancel_title_arrived')
          : tr('cancel_why_passenger'),
      options: kRideReasonOptions,
      mustGiveReason: booking.status == 'arrived',
    );
    if (reason == null || !context.mounted) return;
    await store.cancelBooking(booking, reason: reason);
    if (context.mounted) Navigator.pop(context, 'cancelled');
  }

  /// Beech raaste mein ride WAHEEN khatam (early complete) —
  /// v1.4.4: sawari yahan utar jaye to wajah ke saath ride
  /// mukammal darj hoti hai; wajah record mein rehti hai aur
  /// Master ko nazar ati hai. Us ke baad rating ka prompt bhi
  /// aam usool se khul jata hai.
  Future<void> _endRideHere(BuildContext context) async {
    final reason = await showReasonSheet(
      context,
      title: 'Ride yahan kyun khatam kar rahe hain?',
      options: kRideReasonOptions,
      submitLabel: 'Ride Yahan Khatam Karein',
    );
    if (reason == null || !context.mounted) return;
    await store.passengerEndRideEarly(booking, reason);
    if (!context.mounted) return;
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Ride yahin khatam ho gayi — wajah darj hai.')),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybePrompt());
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final b = booking;
        final pickup = LatLng(b.pickupLat, b.pickupLng);
        final drop = LatLng(b.dropLat, b.dropLng);
        final searching = b.status == 'pending';
        final title = searching
            ? 'Driver Dhoonda Ja Raha Hai'
            : (kStatusUrdu[b.status] ?? b.status);
        // v1.4.9: assign driver ka BARA teer — jagah pehle remote poll
        // se, warna same-device profile se (ETA line wala hi usool);
        // rang asal haalat se (maloom na ho to ride par = online).
        LatLng? driverPos;
        var driverOnline = false;
        if (b.status == 'accepted' || b.status == 'arrived') {
          if (_remoteLat != null && _remoteLng != null) {
            driverPos = LatLng(_remoteLat!, _remoteLng!);
            driverOnline = _driverOnlineRemote ?? true;
          } else if (store.profile.lastLat != null &&
              store.profile.lastLng != null) {
            driverPos = LatLng(store.profile.lastLat!, store.profile.lastLng!);
            driverOnline = _driverOnlineRemote ?? store.profile.online;
          }
        }
        return Scaffold(
          body: Stack(
            children: [
              Positioned.fill(
                child: SafarRouteMap(
                  pickup: pickup,
                  drop: b.hasDropPin ? drop : null,
                  interactive: true,
                  driverPosition: driverPos,
                  driverBearing: _driverBearing,
                  driverOnline: driverOnline,
                ),
              ),
              // Safed sheet — Careem style, gol upar kinare + drag handle.
              Positioned(
                left: 10,
                right: 10,
                bottom: 10,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(26),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.22),
                        blurRadius: 18,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Center(
                        child: Container(
                          width: 44,
                          height: 5,
                          decoration: BoxDecoration(
                            color: Brand.fieldBorder,
                            borderRadius: BorderRadius.circular(3),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(title,
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              color: Brand.greenDark)),
                      if (searching) ...[
                        const SizedBox(height: 10),
                        const _FindingProgressLine(),
                        const SizedBox(height: 8),
                        const Text(
                          'Booking darj ho gayi hai — driver ke jawab ka intezaar karein.',
                          style:
                              TextStyle(fontSize: 12.5, color: Colors.black54),
                        ),
                        // v1.4.0 two-phone dispatch: booking banate waqt
                        // backend se mili qareeb driver ki ittila — sirf
                        // maloomat, koi price NAHI (fare lock barkarar).
                        if (store.dispatchNote.isNotEmpty) ...[
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              const Icon(Icons.radar,
                                  size: 15, color: Brand.green),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  store.dispatchNote,
                                  style: const TextStyle(
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.w700,
                                      color: Brand.greenDark),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ] else ...[
                        const SizedBox(height: 4),
                        const Text(
                          'Booking ki halat upar likhi hai — tafseel neeche dekhein.',
                          style:
                              TextStyle(fontSize: 12.5, color: Colors.black54),
                        ),
                      ],
                      const SizedBox(height: 14),
                      // Route dots: grey = pickup, green = drop.
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            children: [
                              const SizedBox(height: 3),
                              Container(
                                width: 11,
                                height: 11,
                                decoration: const BoxDecoration(
                                  color: Colors.grey,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              Container(
                                width: 2,
                                height: 26,
                                color: Brand.fieldBorder,
                              ),
                              Container(
                                width: 11,
                                height: 11,
                                decoration: const BoxDecoration(
                                  color: Brand.green,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(b.pickupLabel,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14)),
                                const SizedBox(height: 20),
                                Text(b.dropLabel,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      const Text('Booking ki Tafseel',
                          style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                              color: Colors.black54)),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(_vehicleIcon(b.vehicle),
                              color: Brand.green, size: 26),
                          const SizedBox(width: 10),
                          Text(b.vehicle,
                              style: const TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w800)),
                          const Spacer(),
                          const Text('Total Kiraya: ',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.black54)),
                          Text(rs(b.total),
                              style: const TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w900)),
                        ],
                      ),
                      // v1.4.24 TAX (SRB): chalu ride ki tafseel
                      // mein bhi tax ki alag line + kul adaigi —
                      // waiting abhi chal rahi hai, is liye ye
                      // raqam andaza hai; final completion par
                      // pakki hogi (raseed mein ayegi)।
                      if (b.hasTax) ...[
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            const Icon(Icons.receipt_long,
                                color: Colors.black45, size: 20),
                            const SizedBox(width: 10),
                            Text('${taxLabelFor(b.vehicle)}: ',
                                style: const TextStyle(
                                    fontSize: 13, color: Colors.black54)),
                            Text(rs(b.taxAmount),
                                style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800)),
                            const Spacer(),
                            const Text('Kul adaigi: ',
                                style: TextStyle(
                                    fontSize: 13, color: Colors.black54)),
                            Text(rs(b.grandTotal),
                                style: const TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w900,
                                    color: Brand.greenDark)),
                          ],
                        ),
                      ],
                      const SizedBox(height: 12),
                      // v1.4.2 (brief §5): asal driver ki pehchan —
                      // naam, gaari, plate (backend se; data na ho
                      // to kuch nahi dikhta, jaali tafseel kabhi nahi).
                      if ((b.status == 'accepted' || b.status == 'arrived') &&
                          b.assignedDriverId.isNotEmpty &&
                          !b.acceptedHere) ...[
                        Row(
                          children: [
                            // v1.4.27 (#20): driver ki asal profile
                            // photo (driver_card se aya path, bucket
                            // 'driver-docs') signed-URL se render;
                            // path na ho ya URL na mile to pehle
                            // wala initials avatar hi rehta hai।
                            if (b.driverPhotoPath.isNotEmpty)
                              RemotePhotoAvatar(
                                bucket: 'driver-docs',
                                path: b.driverPhotoPath,
                                name: b.driverName,
                                radius: 20,
                              )
                            else
                              CircleAvatar(
                                radius: 20,
                                backgroundColor: Brand.green,
                                child: Text(
                                  b.driverName.isNotEmpty
                                      ? b.driverName[0].toUpperCase()
                                      : '?',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 17),
                                ),
                              ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(b.driverName,
                                      style: const TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w900)),
                                  Text(
                                      '${b.driverVehicleDetail.isNotEmpty ? b.driverVehicleDetail : b.vehicle}${b.driverPlate.isEmpty ? '' : ' · ${b.driverPlate}'}',
                                      style: const TextStyle(
                                          fontSize: 12.5,
                                          color: Colors.black54)),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                      ],
                      _DriverEtaLine(
                          store: store,
                          booking: b,
                          remoteLat: _remoteLat,
                          remoteLng: _remoteLng),
                      // v1.4.7 RIDE START CODE (spec §3): driver
                      // ane par sawari use ye code batati hai —
                      // code ke baghair ride shuru nahi hogi।
                      if ((b.status == 'accepted' ||
                              b.status == 'arrived') &&
                          b.startCode > 0 &&
                          !b.rideStarted) ...[
                        Container(
                          width: double.infinity,
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFF6E0),
                            borderRadius: BorderRadius.circular(12),
                            border:
                                Border.all(color: Brand.gold, width: 1.2),
                          ),
                          child: Column(
                            children: [
                              const Text(
                                  'Driver ko ye START CODE batayein',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: Color(0xFFB8860B))),
                              Text('${b.startCode}',
                                  style: const TextStyle(
                                      fontSize: 30,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 8)),
                              const Text(
                                'Driver ye 6-digit code daale ga tab ride shuru hogi.',
                                style: TextStyle(fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                      ],
                      // v1.4.0: driver ki rating assigned-driver card par
                      // (backend ausat dastiyab ho to) — warna kuch nahi.
                      if (store.backendRatingAvg != null &&
                          (b.status == 'accepted' ||
                              b.status == 'arrived' ||
                              b.status == 'completed'))
                        Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Row(
                            children: [
                              const Icon(Icons.star,
                                  size: 15, color: Brand.gold),
                              const SizedBox(width: 4),
                              Text(
                                'Driver rating: ${store.backendRatingAvg!.toStringAsFixed(1)}',
                                style: const TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        ),
                      InkWell(
                        onTap: () => _callDriver(context),
                        borderRadius: BorderRadius.circular(10),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 6),
                          child: Row(
                            children: [
                              Icon(Icons.headset_mic,
                                  color: Brand.ajrakRed, size: 21),
                              SizedBox(width: 10),
                              Text('Madad Chahiye?',
                                  style: TextStyle(
                                      color: Brand.ajrakRed,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 14)),
                              Spacer(),
                              Icon(Icons.call,
                                  color: Brand.ajrakRed, size: 18),
                            ],
                          ),
                        ),
                      ),
                      // v1.4.0: SOS — ride active ho (accepted/arrived)
                      // to hifazat ka button yahin bhi.
                      if (b.status == 'accepted' || b.status == 'arrived') ...[
                        const SizedBox(height: 6),
                        SosButton(
                            store: store, booking: b, role: 'passenger'),
                        const SizedBox(height: 6),
                        // SABOOT RECORDING (owner 2026-11-08):
                        // active ride ki asal screen par bhi wazeh
                        // button — badtamizi waghera mein audio
                        // saboot, Master ko khud khabar ke saath.
                        EvidenceRecorderButton(
                          store: store,
                          booking: b,
                          role: 'passenger',
                          recorderName: b.passengerName,
                        ),
                        const SizedBox(height: 6),
                        // v1.4.16 RIDE CHAT: number share kiye
                        // baghair driver se baat.
                        RideChatButton(
                            store: store, booking: b, role: 'passenger'),
                        // v1.4.4: beech raaste mein yahan utarna ho
                        // to ride WAHEEN khatam — wajah ke saath;
                        // ya ride mansookh — wajah ke saath. Dono
                        // ki wajah record mein hamesha rehti hai.
                        const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () => _endRideHere(context),
                            icon: const Icon(Icons.flag, size: 18),
                            label: const Text('Ride Yahan Khatam Karein'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Brand.deepGreen,
                              padding:
                                  const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                        Center(
                          child: TextButton(
                            onPressed: () => _showCancelSheet(context),
                            style: TextButton.styleFrom(
                              foregroundColor: Brand.ajrakRed,
                            ),
                            child: const Text('Ride Mansookh Karein'),
                          ),
                        ),
                      ],
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () =>
                              Navigator.pop(context, 'bookings'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Brand.deepGreen,
                            padding:
                                const EdgeInsets.symmetric(vertical: 15),
                          ),
                          child: const Text('Meri Bookings Dekhein'),
                        ),
                      ),
                      // v1.4.0: ride complete ho jaye to yahin se
                      // RASEED + RATING.
                      if (b.status == 'completed') ...[
                        const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: () =>
                                showReceiptDialog(context, store, b),
                            icon: const Icon(Icons.receipt_long, size: 18),
                            label: const Text('Raseed Dekhein'),
                          ),
                        ),
                        const SizedBox(height: 8),
                        RatingRow(store: store, booking: b),
                      ],
                      if (searching)
                        Center(
                          child: TextButton(
                            onPressed: () => _showCancelSheet(context),
                            style: TextButton.styleFrom(
                              foregroundColor: Brand.ajrakRed,
                            ),
                            child: const Text('Ride Mansookh Karein'),
                          ),
                        ),
                      // OSM attribution — is screen ki sheet
                      // bhi map ke neeche wale kinare ko
                      // dhakti hai; footer line wohi license
                      // shart poori karti hai।
                      const SizedBox(height: 8),
                      const Center(
                        child: Text(
                          kOsmAttribution,
                          style:
                              TextStyle(fontSize: 9.5, color: Colors.black38),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Searching wali sabz progress line — bharti hui animation.
class _FindingProgressLine extends StatefulWidget {
  const _FindingProgressLine();

  @override
  State<_FindingProgressLine> createState() => _FindingProgressLineState();
}

class _FindingProgressLineState extends State<_FindingProgressLine>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1500),
  )..repeat();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(4),
      child: Container(
        height: 4,
        color: Brand.fieldBorder,
        alignment: Alignment.centerLeft,
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (context, _) => FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: 0.12 + 0.88 * _ctrl.value,
            child: Container(color: Brand.green),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Driver ki doori + aane ka waqt (ETA) — v1.2.4. Sirf ACCEPTED booking
// par dikhta hai (driver tay ho chuka aur aa raha hai); us se pehle
// (pending/searching) kuch nahi — booking se pehle wali "koi maloomat
// nahi" wali lock bilkul barkarar hai.
//
// Doori = driver ki akhri maloom GPS jagah (v1.4.0: pehle backend
// ride row ki driver_lat/lng — two-phone live dispatch; warna
// DriverProfile.lastLat/lng, jo Driver Mode ke refresh/qubool/
// nav-stream se taza hoti hai) se pickup tak ki seedhi doori
// (latlong Distance, 1 decimal km).
// Waqt = pehle OSRM route ka asal duration (RouteService cache/fetch,
// driver → pickup), woh na mile to sheher ki ausat raftaar se andaza
// (neeche wale INTERNAL constants; kabhi display nahi hote):
// Rickshaw 20, Bike 30, Car 25 km/h. Minute hamesha UP round, kam az
// kam 1. Koi jhoota countdown nahi — value sirf position/store ke
// taza hone par badalti hai.
// Driver ki position maloom hi na ho to saaf likha ata hai ke
// location jald nazar aayegi — koi number nahi banaya jata.
// ---------------------------------------------------------------------------

const Map<String, double> _kEtaCitySpeedKmh = {
  'Rickshaw': 20,
  'Bike': 30,
  'Car': 25,
};

class _DriverEtaLine extends StatefulWidget {
  final AppStore store;
  final Booking booking;

  /// v1.4.0 two-phone dispatch: backend ride row (rides.driver_lat/
  /// driver_lng) se mili driver ki LIVE jagah. Mojood ho to ETA isi
  /// se banta hai; warna DriverProfile.lastLat/lastLng wala mojooda
  /// same-device tareeqa — pilot bilkul barkarar.
  final double? remoteLat;
  final double? remoteLng;
  const _DriverEtaLine(
      {required this.store,
      required this.booking,
      this.remoteLat,
      this.remoteLng});

  @override
  State<_DriverEtaLine> createState() => _DriverEtaLineState();
}

class _DriverEtaLineState extends State<_DriverEtaLine> {
  String _sig = '';
  int? _osrmEtaMin;

  Booking get b => widget.booking;
  AppStore get store => widget.store;

  /// Asal driver ki jagah — pehle backend wali live jagah, warna
  /// is phone par maloom akhri jagah.
  (double, double)? _driverPos() {
    final lat = widget.remoteLat ?? store.profile.lastLat;
    final lng = widget.remoteLng ?? store.profile.lastLng;
    if (lat == null || lng == null) return null;
    return (lat, lng);
  }

  /// Driver ki jagah maloom ho aur booking ke paas pickup pin ho to
  /// seedhi doori (km); warna null (= koi number nahi dikhana).
  double? _driverKm() {
    final pos = _driverPos();
    if (pos == null) return null;
    if (b.pickupLat == 0 && b.pickupLng == 0) return null;
    return const Distance().as(LengthUnit.Kilometer,
        LatLng(pos.$1, pos.$2), LatLng(b.pickupLat, b.pickupLng));
  }

  /// Is hisaab ki pehchan — booking, us ki halat, driver ki jagah
  /// (3 decimal tak) aur pickup. In mein se kuch badle to ETA dobara
  /// gina jata hai; warna purani value hi rehti hai (churn nahi).
  String _sigNow() {
    final pos = _driverPos();
    final p = pos == null
        ? 'none'
        : '${pos.$1.toStringAsFixed(3)},${pos.$2.toStringAsFixed(3)}';
    return '${b.id}|${b.status}|$p|'
        '${b.pickupLat.toStringAsFixed(3)},${b.pickupLng.toStringAsFixed(3)}';
  }

  int _speedEtaMin(double km) {
    final speed = _kEtaCitySpeedKmh[b.vehicle] ?? 20;
    final mins = (km / speed * 60).ceil();
    return mins < 1 ? 1 : mins;
  }

  Future<void> _resolve() async {
    final sig = _sig;
    final pos = _driverPos();
    if (pos == null) return;
    if (b.pickupLat == 0 && b.pickupLng == 0) return;
    try {
      final r = await RouteService.fetch(
          LatLng(pos.$1, pos.$2), LatLng(b.pickupLat, b.pickupLng));
      if (!mounted || _sig != sig) return;
      if (!r.isStraightFallback && r.durationS > 0) {
        final mins = (r.durationS / 60).ceil();
        setState(() => _osrmEtaMin = mins < 1 ? 1 : mins);
      }
    } catch (_) {
      // Khamosh — raftaar wala andaza hi rehta hai.
    }
  }

  @override
  void initState() {
    super.initState();
    _sig = _sigNow();
    unawaited(_resolve());
  }

  @override
  void didUpdateWidget(_DriverEtaLine oldWidget) {
    super.didUpdateWidget(oldWidget);
    final now = _sigNow();
    if (now != _sig) {
      _sig = now;
      _osrmEtaMin = null;
      unawaited(_resolve());
    }
  }

  @override
  Widget build(BuildContext context) {
    // Sirf tab jab driver tay ho aur aa raha ho. Arrived par driver
    // pohanch chuka hota hai — wahan halat wali line hi kaafi hai.
    if (b.status != 'accepted') return const SizedBox.shrink();
    final km = _driverKm();
    if (km == null) {
      return const Padding(
        padding: EdgeInsets.only(bottom: 10),
        child: Row(
          children: [
            Icon(Icons.near_me, size: 17, color: Colors.black45),
            SizedBox(width: 6),
            Expanded(
              child: Text('Driver ki location jald nazar aayegi',
                  style: TextStyle(fontSize: 13.5, color: Colors.black54)),
            ),
          ],
        ),
      );
    }
    final eta = _osrmEtaMin ?? _speedEtaMin(km);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          const Icon(Icons.near_me, size: 17, color: Brand.green),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              'Driver ${km.toStringAsFixed(1)} km door hai · '
              'Takreeban $eta minute mein pahunchega',
              style: const TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w800,
                  color: Brand.greenDark),
            ),
          ),
        ],
      ),
    );
  }
}
