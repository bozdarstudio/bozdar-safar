import 'dart:async';
import 'package:flutter/material.dart';
import 'agent_section.dart';
import 'backend.dart';
import 'otp.dart';
import 'store.dart';
import 'theme.dart';

// ===========================================================================
// v1.4.4 — LEGAL + SAFETY: Sharait (Terms) + Privacy Policy
//
// Malik ka hukm (2026-11-08): app ke andar saari qanooni sharait
// lazmi hain taaki baad mein koi phans na sakay. Saara mutan seedhi
// saada Roman Urdu mein hai taaki har sawari/driver ko samajh aye.
//
//  - [TermsPage] / [PrivacyPage]: parhne wale pages — Driver
//    Profile se bhi khulte hain, sawari ki Profile se bhi, aur
//    registration ke aakhri qadam se bhi ("Sharait dobara parhein").
//  - [TermsGateScreen]: pehli dafa app khulne par lazmi — baghair
//    "Mein ne parh liya, qabool hai" dabaye app aage NAHI barhti;
//    qubooliyat ka waqt mehfooz ho jata hai (store.termsAcceptedAtMs;
//    driver ki apni qubooliyat registration mein alag se
//    drivers.terms_accepted_at mein bhi jati hai — migration v134).
// ===========================================================================

class LegalSection {
  final String title;
  final List<String> lines;
  const LegalSection(this.title, this.lines);
}

const List<LegalSection> kTermsSawari = [
  LegalSection('Sawari (Passenger) ki Sharait', [
    'Bozdar Safar sirf ek technology platform hai — ye aap ko qareebi tasdeeq-shuda driver se jorta hai. Gaari aur safar ki asal zimmedari driver ki hai.',
    'Kiraya hamesha CASH mein seedha driver ko ada hota hai. App ke andar koi paisa nahi rukta aur na hi koi advance liya jata hai.',
    'Ride pakki hone se PEHLE aap ko kiraya nahi dikhaya jata — kul kiraya booking pakki hote hi nazar ata hai, aur wohi tay-shuda kiraya hai (koi mol-bhav nahi).',
    'Apna qeemti samaan (mobile, paisa, zewar, documents) aap ki apni zimmedari hai. Gaari mein reh jane wali cheez ki ittela foran Master ko message karke dein — hum driver se rabta karke poori koshish karenge, lekin samaan ki zimmedari company par nahi hoti.',
    'Driver ke pohanchnay ke baad pehle chand minute intezaar muft hai; us se zyada intezaar par munasib waiting charges kul kiraye mein shamil ho jate hain (hisaab booking par saaf likha hota hai).',
  ]),
  LegalSection('Ride Cancel karne ki Policy', [
    'Aap ride kabhi bhi cancel kar sakte hain — cancel par app aap se WAJAH poochhegi. Ye wajah ride ke record ke saath mehfooz rehti hai taaki koi galat-fehmi ya jhooti shikayat ho to asal baat sab ke saamne ho.',
    'Agar aap beech raaste mein rukwa kar ride waheen khatam (complete) kar dein, to bhi app wajah poochhegi — aur woh wajah bhi record mein mehfooz rahegi.',
    'Driver ke pohanchnay se pehle cancel karna bilkul muft hai. Driver pohanch jaye aur dair tak intezaar karna pare to waiting charges lag sakte hain.',
    'Baar baar bila-wajah cancel karne par Master aap se rabta kar sakta hai, aur ghalat istemal par app ka istemal roka ja sakta hai.',
    'Ride ke doran koi masla ho to SOS button dabayein — woh aap ko 1122 se jorta hai aur Master ko bhi khabar bhejta hai.',
  ]),
];

const List<LegalSection> kTermsDriver = [
  LegalSection('Driver ki Sharait', [
    'Aap ki gaari ka INSURANCE aur REGISTRATION (kaghaz) har waqt VALID rakhna AAP KI APNI zimmedari hai. Kaghaz khatam ya jaali hon to ID band ho sakti hai aur kisi nuqsan ki zimmedari bhi aap par hogi.',
    'Traffic ke tamam qanoon ki pabandi lazmi hai — speed, signal, seat belt/helmet aur sawari ki hifazat sab se pehle hai.',
    'Khuda na khasta HADSA ho jaye to SAB SE PEHLE 1122 par call karke madad bulayein, phir foran Master ko message karke ittila dein.',
    'Bozdar Safar sirf ek TECHNOLOGY PLATFORM hai — driver company ka MULAZIM NAHI hai. Har driver apni gaari, apne waqt aur apni kamai ka khud zimmedar hai.',
    'Ride qubool karne ke baad sawari ko waqt par lena, aaram se aur hifazat se manzil tak pohanchana aap ki zimmedari hai. Sawari se badtameezi, zyada kiraya mangna ya tay-shuda kiraye se inkaar sakht mana hai.',
    'Rozana duty se pehle LIVE SELFIE lazmi hai. Account sirf EK hi device par chalega — device badalna ho to pehle Master ko message karke batayein, warna ID khud-ba-khud chand ghante block ho jati hai.',
    'Ek CNIC par sirf EK driver account banta hai. Mobile number badalne par ID 12 ghante ke liye khud-ba-khud block ho jati hai.',
  ]),
  LegalSection('Service Fee aur Hisaab', [
    'Har mukammal ride par 10% SERVICE FEE banti hai. Ye fee aap ke hisaab (Wallet — "Dena Hai") mein jama hoti rehti hai; koi paisa app ke andar nahi rukta.',
    'Hisaab HAFTAWAR hota hai — aap hafta poora hone par kul baqi raqam Raast (0312 2635002) par bhej kar app mein apni payment darj karte hain. Master tasdeeq kare to hisaab saaf ho jata hai. Aap ki sirf darj ki hui payment se hisaab saaf NAHI hota — Master ki tasdeeq lazmi hai.',
    'Baqi fee tay-shuda HAD tak pahunch jaye to ID khud-ba-khud BLOCK ho jati hai — na online, na nayi ride. Block SIRF tab khulta hai jab POORI baqi raqam ka hisaab saaf ho jaye — juzwi (aadhi) payment se block NAHI khulta.',
    'Apni kamai, baqi fee aur tamam rides ka poora record aap ki app aur Master ke paas mehfooz rehta hai — kisi jhagray ki surat mein yehi record saboot hota hai.',
  ]),
];

const List<LegalSection> kPrivacySections = [
  LegalSection('Hum kya data jama karte hain — aur kyun', [
    'Sawari ka naam aur mobile number — sirf ride ki pehchan aur rabte ke liye.',
    'Driver ka naam, mobile, CNIC, gaari ki tafseel aur documents ki tasaveer — sirf Tasdeeq (verification) ke liye, taaki sawari ko mehfooz aur asal driver mile.',
    'Ride ki tafseel (kahan se kahan, waqt, kiraya) aur driver ki duty ke doran ki location — sirf ride chalane, hisaab rakhne aur hifazat ke liye.',
    'Driver ki rozana live selfie — sirf ye pakka karne ke liye ke account asal driver hi chala raha hai.',
  ]),
  LegalSection('Ride ke records — mehfooz archive', [
    'Har ride ka record (waqt, jagahen, kiraya, cancel ya beech raaste mein khatam karne ki wajah, ratings) SAFETY ke liye mehfooz archive mein ek muddat — 3 SAAL — tak rehta hai.',
    'Isi liye ACCOUNT DELETE karne se sirf aap ka PROFILE (naam, number, photo) delete hota hai — ride ke records delete NAHI hote. Agar kal koi jhooti shikayat ya jhagra ho to yehi record asal baat saaf karta hai — ye aap ki aur driver, dono ki hifazat hai.',
  ]),
  LegalSection('Aap ka data kisko dikhta hai', [
    'Aap ka data sirf MASTER (Bozdar Safar ke malik) ko dikhta hai — wahi Tasdeeq, hisaab aur shikayat ke liye use dekhta hai.',
    'Aap ka data kisi teesre shakhs ya company ko NAHI becha jata aur na hi kisi advertisement ke liye istemal hota hai.',
    'Qanoon ki taraf se lazmi talab ho (masalan police ki tehqeeqat) to record mutaliqa idare ko diya ja sakta hai.',
    'Apna profile delete karne ka ikhtiyar aap ke paas hamesha hai — Profile mein "Account Delete Karein" se. Us ke baad naam/number dobara darj kiye baghair nayi booking nahi ho sakti.',
  ]),
];

Widget _sectionsView(List<LegalSection> sections) {
  return ListView(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
    children: [
      for (final s in sections) ...[
        Text(s.title,
            style: const TextStyle(
                fontSize: 16.5,
                fontWeight: FontWeight.w900,
                color: Brand.greenDark)),
        const SizedBox(height: 8),
        for (final line in s.lines) ...[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.only(top: 7),
                child: Icon(Icons.circle, size: 6, color: Brand.green),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(line,
                    style: const TextStyle(fontSize: 13.5, height: 1.45)),
              ),
            ],
          ),
          const SizedBox(height: 8),
        ],
        const SizedBox(height: 14),
      ],
    ],
  );
}

/// Sharait (Terms) ka page — Sawari aur Driver dono ke hisse.
class TermsPage extends StatelessWidget {
  const TermsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sharait (Terms)')),
      body: _sectionsView([...kTermsSawari, ...kTermsDriver]),
    );
  }
}

/// Privacy Policy ka page.
class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Privacy Policy')),
      body: _sectionsView(kPrivacySections),
    );
  }
}

/// Pehli dafa app khulne par LAZMI wala darwaza: Sharait parh kar
/// "Mein ne parh liya, qabool hai" dabaye baghair aage nahi barha
/// ja sakta. Qabool karne ka waqt store mein mehfooz ho jata hai.
class TermsGateScreen extends StatelessWidget {
  final AppStore store;
  const TermsGateScreen({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 18, 16, 4),
              child: Text('Bozdar Safar ki Sharait',
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: Brand.greenDark)),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Text(
                'App istemal karne se pehle ye sharait parh lein. Neeche wala button dabane se ye darj ho jayega ke aap ne sharait parh li hain aur aap ko qabool hain.',
                style: TextStyle(fontSize: 13, color: Colors.black54),
              ),
            ),
            Expanded(
                child: _sectionsView([...kTermsSawari, ...kTermsDriver])),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => store.acceptTerms(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Brand.deepGreen,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    textStyle: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w900),
                  ),
                  child: const Text('Mein ne parh liya, qabool hai'),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: TextButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const PrivacyPage()),
                ),
                child: const Text('Privacy Policy bhi parhein'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Profile pages mein lagne wali mushtarka patti: Sharait +
/// Privacy ke darwaze aur (agar darj ho) qubooliyat ka waqt.
class LegalLinksCard extends StatelessWidget {
  final AppStore store;

  /// Driver ki apni qubooliyat ka waqt (registration wali) —
  /// driver Profile se ata hai; sawari ke liye null.
  final int? driverAcceptedAtMs;
  const LegalLinksCard({super.key, required this.store, this.driverAcceptedAtMs});

  @override
  Widget build(BuildContext context) {
    final acceptedMs =
        driverAcceptedAtMs ?? store.termsAcceptedAtMs;
    return Card(
      child: Column(
        children: [
          ListTile(
            leading: const Icon(Icons.description, color: Brand.green),
            title: const Text('Sharait (Terms)',
                style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text('Sawari aur Driver ki tamam sharait.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const TermsPage()),
            ),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.privacy_tip, color: Brand.green),
            title: const Text('Privacy Policy',
                style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle:
                const Text('Aap ka data kaise mehfooz rehta hai — saaf alfaaz mein.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const PrivacyPage()),
            ),
          ),
          if (acceptedMs > 0) ...[
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 9, 16, 11),
              child: Row(
                children: [
                  const Icon(Icons.verified, size: 16, color: Brand.green),
                  const SizedBox(width: 7),
                  Expanded(
                    child: Text(
                      'Sharait qabool ki gayi: ${fmtDate(DateTime.fromMillisecondsSinceEpoch(acceptedMs))} ${fmtTime(DateTime.fromMillisecondsSinceEpoch(acceptedMs))}',
                      style: const TextStyle(
                          fontSize: 12.5, color: Colors.black54),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// Sawari ki Profile screen (v1.4.4) — naam/number ki haalat,
/// Sharait/Privacy ke darwaze, aur ACCOUNT DELETE (profile saaf;
/// ride ke records Privacy Policy ke mutabiq mehfooz rahte hain).
/// v1.4.5 (B4): Profile ka asal body — alag screen mein bhi aur
/// passenger bottom-nav ke Profile tab mein bhi yehi chalta hai.
/// [onAfterDelete]: account delete ke baad kya ho (screen par
/// pop; tab mein kuch nahi — list wahin taaza ho jati hai).
class PassengerProfileBody extends StatelessWidget {
  final AppStore store;
  final VoidCallback? onAfterDelete;
  const PassengerProfileBody(
      {super.key, required this.store, this.onAfterDelete});

  Future<void> _deleteAccount(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Account delete karein?'),
        content: const Text(
          'Aap ka PROFILE delete ho jayega — naam, mobile number aur mehfooz jagahen is phone se saaf ho jayengi.\n\n'
          'Ek baat saaf sun lein: aap ki purani RIDES ke records delete NAHI honge — woh Privacy Policy ke mutabiq safety ke liye mehfooz archive mein rehte hain, taaki kisi jhagray ya jhooti shikayat ki surat mein asal record maujood ho.\n\n'
          'Delete ke baad nayi booking ke liye naam/number dobara darj karna hoga.',
          style: TextStyle(fontSize: 13.5, height: 1.45),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Rehne Dein'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Brand.ajrakRed),
            child: const Text('Haan, Delete Karein'),
          ),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    // Pehle Master ko khabar (naam/number abhi mehfooz hai),
    // phir profile saaf — message queued bhi rahe to agli sync
    // par chala jayega.
    final name = store.passengerName.trim();
    final phone = store.passengerPhone.trim();
    await store.addMasterMessage(MasterMessage(
      id: store.newId(),
      senderKey: store.deviceId,
      senderRole: 'passenger',
      senderName: name,
      senderMobile: phone,
      senderZone: '',
      category: 'Deegar',
      body: 'ACCOUNT DELETE: Sawari ${name.isEmpty ? '(naam darj nahi tha)' : name}'
          '${phone.isEmpty ? '' : ' ($phone)'} ne app se apna profile delete kar diya hai. '
          'Privacy Policy ke mutabiq us ki rides ke records mehfooz archive mein rahenge; '
          'profile (naam/number) is phone se saaf ho gaya hai.',
      createdAt: DateTime.now(),
    ));
    await store.deletePassengerProfile();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Aap ka profile delete ho gaya hai. Shukriya!')),
    );
    onAfterDelete?.call();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          return ListView(
            padding: const EdgeInsets.all(14),
            children: [
              // Board style sir-khata (brief §6): goal sabz avatar
              // (naam ka pehla harf — passenger ki photo ka koi
              // feature hai hi nahi, jaali photo NAHI), naam +
              // mobile. Verified pill passenger par NAHI lagti
              // (us ke liye koi tasdeeq system hai hi nahi).
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Brand.green, Brand.deepGreen],
                  ),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Brand.gold, width: 1.6),
                ),
                child: Row(
                  children: [
                    InitialAvatar(name: store.passengerName),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            store.passengerName.isEmpty
                                ? 'Assalam O Alaikum'
                                : store.passengerName,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w900),
                          ),
                          Text(
                            store.passengerPhone.isEmpty
                                ? 'Naam/number booking par darj hota hai'
                                : store.passengerPhone,
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 12.5),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.person, color: Brand.green),
                          SizedBox(width: 9),
                          Text('Meri Maloomat',
                              style: TextStyle(
                                  fontWeight: FontWeight.w900, fontSize: 15)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      _row('Naam',
                          store.passengerName.isEmpty ? '—' : store.passengerName),
                      _row('Mobile',
                          store.passengerPhone.isEmpty ? '—' : store.passengerPhone),
                      const SizedBox(height: 4),
                      const Text(
                        'Naam aur number booking ke waqt darj hote hain — yahan sirf un ki haalat dikhti hai.',
                        style: TextStyle(fontSize: 12, color: Colors.black54),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              // v1.4.7: Gmail + OTP card (spec §1) + no-show
              // warnings ki haalat (spec §5) + Logout।
              _PassengerEmailCard(store: store),
              const SizedBox(height: 10),
              // AGENT HISA (v1.4.6): is mobile ka ACTIVE agent ho
              // to "Mera Agent Hisa" card yahin khulta hai — na ho
              // to widget khud ghayab rehta hai (SizedBox.shrink).
              AgentSection(store: store),
              const SizedBox(height: 10),
              LegalLinksCard(store: store),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.delete_forever,
                      color: Brand.ajrakRed),
                  title: const Text('Account Delete Karein',
                      style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: Brand.ajrakRed)),
                  subtitle: const Text(
                      'Profile (naam/number) delete ho jayega — rides ke records safety ke liye mehfooz rahenge.'),
                  onTap: () => _deleteAccount(context),
                ),
              ),
            ],
          );
        },
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            child: Text(label,
                style: const TextStyle(
                    fontWeight: FontWeight.w700, color: Colors.black54)),
          ),
          Expanded(
            child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}

/// Sawari ka Gmail/OTP card (v1.4.7, spec §1/§5) — email verify
/// ki haalat, no-show warnings ki ginti, aur Logout (dobara
/// booking par OTP lazmi)।
class _PassengerEmailCard extends StatefulWidget {
  final AppStore store;
  const _PassengerEmailCard({required this.store});

  @override
  State<_PassengerEmailCard> createState() => _PassengerEmailCardState();
}

class _PassengerEmailCardState extends State<_PassengerEmailCard> {
  late final _emailCtrl =
      TextEditingController(text: widget.store.passengerEmail);

  AppStore get store => widget.store;

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.mark_email_read, color: Brand.green),
                SizedBox(width: 9),
                Text('Gmail aur Meri Haalat',
                    style:
                        TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
              ],
            ),
            const SizedBox(height: 8),
            if (store.passengerEmailVerified)
              Row(
                children: [
                  const Icon(Icons.verified, color: Brand.green, size: 18),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Gmail verify hai: ${store.passengerEmail}',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              )
            else
              EmailOtpSection(
                emailCtrl: _emailCtrl,
                onVerified: (email) async {
                  await store.applyPassengerEmailVerified(email);
                  unawaited(Backend.syncPassengerSelf(store));
                  if (mounted) setState(() {});
                },
              ),
            if (store.passengerWarnCount > 0) ...[
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: store.passengerNoShowBlocked
                      ? const Color(0xFFFDECEA)
                      : const Color(0xFFFFF6E0),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  store.passengerNoShowBlocked
                      ? 'No-show warnings: ${store.passengerWarnCount}/3 — aap ki booking BAND hai. Master se rabta karein: 0332 9467211'
                      : 'No-show warnings: ${store.passengerWarnCount}/3 — ride mangwa kar zaroor ayen; 3 warnings par booking band ho jayegi.',
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: store.passengerNoShowBlocked
                          ? Brand.ajrakRed
                          : const Color(0xFF8D6E00)),
                ),
              ),
            ],
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  await store.passengerLogout();
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text(
                          'Logout ho gaya — agli booking se pehle Email OTP dobara lazmi hoga.')));
                  setState(() {});
                },
                icon: const Icon(Icons.logout, size: 17),
                label: const Text('Logout'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Alag screen wala roop — Profile tab ke ilawa jahan se bhi
/// khule (purane darwaze), body wohi [PassengerProfileBody] hai.
class PassengerProfileScreen extends StatelessWidget {
  final AppStore store;
  const PassengerProfileScreen({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Meri Profile')),
      body: PassengerProfileBody(
        store: store,
        onAfterDelete: () => Navigator.of(context).pop(),
      ),
    );
  }
}
