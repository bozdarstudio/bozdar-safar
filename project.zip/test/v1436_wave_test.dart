// v1.4.36 WAVE tests — (A) MAP full zoom-out: widget par wazeh
// min zoom + dono styles mein low-zoom world layers (earth /
// water_world, maxzoom 6) — sheher ki satah bilkul na badle;
// (B) POOL card: rating/rides ke fields sirf asal data par
// bharte hain (default 0 = card par line NAHI banti)।
import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:safar/day_style.dart';
import 'package:safar/lang.dart';
import 'package:safar/night_style.dart';
import 'package:safar/store.dart';

Booking _bk({double rating = 0, int rides = 0}) => Booking(
      id: 'r1',
      passengerName: 'Ahmed',
      passengerPhone: '03001234567',
      passengerRatingAvg: rating,
      passengerRidesCount: rides,
      pickupLabel: 'Clifton',
      dropLabel: 'Saddar',
      pickupLat: 24.81,
      pickupLng: 67.03,
      dropLat: 24.86,
      dropLng: 67.0,
      hasDropPin: true,
      vehicle: 'Rickshaw',
      distanceKm: 4.2,
      fare: 210,
      note: '',
      status: 'pending',
      createdAt: DateTime(2026, 11, 12, 10, 30),
    );

void main() {
  group('A. Map — full zoom-out (duniya ki satah)', () {
    test('widget par min zoom 0.5 wazeh set hai', () {
      final src = File('lib/safar_map.dart').readAsStringSync();
      expect(src.contains('MinMaxZoomPreference(0.5, null)'), isTrue,
          reason: 'zoom-out duniya ki satah tak pakka hona chahiye');
    });

    for (final entry in {
      'day': kDayStyleJson,
      'night': kNightStyleJson,
    }.entries) {
      test('${entry.key} style: world layers maxzoom 6 ke saath', () {
        final j = jsonDecode(entry.value) as Map<String, dynamic>;
        final layers = (j['layers'] as List).cast<Map<String, dynamic>>();
        // 95 asal + 2 naye world layers + v1.4.42 (M1) ka
        // 3D buildings layer (safar-buildings-3d) = 98
        expect(layers.length, 98);
        expect(layers.first['id'], 'background');
        // Zameen wala layer background ke foran baad — sirf
        // duniya ki satah (maxzoom 6); sheher (z>=6) par ghayab।
        final earth = layers[1];
        expect(earth['id'], 'safar_earth_world');
        expect(earth['source-layer'], 'earth');
        expect(earth['maxzoom'], 6);
        // Samandar wala mazboot layer water_shadow ke baad —
        // woh bhi sirf low zoom par।
        final ids = layers.map((l) => l['id']).toList();
        final wIdx = ids.indexOf('safar_water_world');
        expect(wIdx, greaterThan(ids.indexOf('water_shadow')));
        final water = layers[wIdx];
        expect(water['source-layer'], 'water');
        expect(water['maxzoom'], 6);
        // Source ki apni zoom range z0 se shuru hoti hai —
        // duniya ki tiles asal mein maujood hain।
        final src = (j['sources'] as Map)['protomaps'] as Map;
        expect(src['minzoom'], 0);
      });
    }
  });

  group('B. Pool card — rating/rides sirf asal data par', () {
    test('default: rating/rides 0 — koi jaali line nahi banti', () {
      final b = _bk();
      expect(b.passengerRatingAvg, 0);
      expect(b.passengerRidesCount, 0);
    });

    test('asal data mile to fields wohi rakhte hain', () {
      final b = _bk(rating: 4.8, rides: 23);
      expect(b.passengerRatingAvg, 4.8);
      expect(b.passengerRidesCount, 23);
    });

    test('pool_rides_count dono zubaano mein hal hota hai', () {
      Lang.current = 'ur';
      expect(trf('pool_rides_count', {'p1': '23'}), 'kul 23 rides');
      Lang.current = 'en';
      expect(trf('pool_rides_count', {'p1': '23'}), '23 rides in total');
      Lang.current = 'ur';
    });
  });
}
