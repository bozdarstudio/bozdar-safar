import 'package:flutter/material.dart';

/// Bozdar Safar brand — deep green + gold, ajrak accents.
class Brand {
  static const deepGreen = Color(0xFF0B3D2E);
  static const green = Color(0xFF0B6B4F);
  static const greenDark = Color(0xFF07301F);
  static const gold = Color(0xFFD4AF37);
  static const goldLight = Color(0xFFF2C94C);
  static const cream = Color(0xFFFFF8E7);
  static const ajrakRed = Color(0xFF9E2A2B);
  static const ink = Color(0xFF1E2A26);

  static ThemeData theme() {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: green,
        primary: green,
        secondary: gold,
        surface: cream,
      ),
      scaffoldBackgroundColor: cream,
      fontFamily: 'Roboto',
    );
    return base.copyWith(
      appBarTheme: const AppBarTheme(
        backgroundColor: deepGreen,
        foregroundColor: cream,
        elevation: 0,
        centerTitle: false,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: green,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: green,
          side: const BorderSide(color: green, width: 1.4),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFB9CFC6)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFB9CFC6)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: green, width: 1.8),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
      chipTheme: base.chipTheme.copyWith(
        backgroundColor: Colors.white,
        selectedColor: goldLight,
        side: const BorderSide(color: Color(0xFFB9CFC6)),
        labelStyle: const TextStyle(fontWeight: FontWeight.w600),
      ),
      cardTheme: CardTheme(
        color: Colors.white,
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: Color(0xFFE3D9B8)),
        ),
      ),
    );
  }
}

/// Sindhi ajrak-style border strip: repeating diamonds in red/green/gold.
class AjrakStrip extends StatelessWidget {
  final double height;
  const AjrakStrip({super.key, this.height = 14});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(painter: _AjrakPainter()),
    );
  }
}

class _AjrakPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = Brand.ajrakRed;
    canvas.drawRect(Offset.zero & size, bg);
    final cell = size.height; // square cells
    final colors = [Brand.gold, Brand.green, Brand.cream, Brand.green];
    for (double x = 0; x < size.width + cell; x += cell) {
      for (int row = 0; row < 1; row++) {
        final cx = x + cell / 2;
        final cy = size.height / 2;
        final p = Paint()
          ..color = colors[((x / cell).round() + row) % colors.length];
        final path = Path()
          ..moveTo(cx, cy - cell * 0.34)
          ..lineTo(cx + cell * 0.34, cy)
          ..lineTo(cx, cy + cell * 0.34)
          ..lineTo(cx - cell * 0.34, cy)
          ..close();
        canvas.drawPath(path, p);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Gold wordmark header used at the top of both sides.
class BrandHeader extends StatelessWidget {
  final String sideLabel;
  const BrandHeader({super.key, required this.sideLabel});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Brand.deepGreen,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 2),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Brand.gold, width: 2),
                    color: Brand.green,
                  ),
                  child: const Icon(Icons.local_taxi,
                      color: Brand.goldLight, size: 24),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'SAFAR',
                        style: TextStyle(
                          color: Brand.gold,
                          fontSize: 21,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                        ),
                      ),
                      Text(
                        'Your ride, your people.',
                        style: TextStyle(
                          color: Brand.cream,
                          fontSize: 12,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text(
              sideLabel,
              style: const TextStyle(
                color: Brand.goldLight,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.6,
              ),
            ),
          ),
          const AjrakStrip(height: 12),
        ],
      ),
    );
  }
}

String rs(int v) => 'Rs ${v.toString()}';

String fmtDate(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';

String fmtTime(DateTime d) {
  final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
  final ap = d.hour >= 12 ? 'PM' : 'AM';
  return '$h:${d.minute.toString().padLeft(2, '0')} $ap';
}
