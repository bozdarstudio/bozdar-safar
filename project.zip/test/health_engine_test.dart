// v1.4.26 — HEALTH ENGINE (self-repair) ke tests: mehfooz
// records ki saakht jaanch (inspectPdStoredData), engine ki
// jaanch/repair logic nakli raston (fake hooks) ke saath, aur
// asal AppStore par kharab data ki load + repair.
import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:safar/backend.dart';
import 'package:safar/health_engine.dart';
import 'package:safar/store.dart';

/// Nakli hooks — har test apni zaroorat ke hisse badal sakta
/// hai; default sab kuch sehatmand hai.
HealthHooks _hooks({
  bool backendOk = true,
  BackendSessionState? session,
  bool refreshOk = false,
  int lastFetchOkMs = -1, // -1 = abhi ka waqt (taaza)
  bool footprint = false,
  bool syncOk = true,
  PdStoreIntegrityReport? integrity,
  List<PdStoreIntegrityReport>? integritySeq,
  int repairCount = 0,
  int pruneCount = 0,
  List<({int rides, int packages, int messages, int ratings})>?
      outboxSeq,
  void Function()? onRetryOutbox,
  void Function()? onSync,
}) {
  var integrityCalls = 0;
  var outboxCalls = 0;
  return HealthHooks(
    probeBackend: () async => backendOk,
    sessionState: () async =>
        session ??
        const BackendSessionState(
            hasSession: true, valid: true, canRefresh: true),
    refreshSession: () async => refreshOk,
    lastFetchOkMs: () => lastFetchOkMs < 0
        ? DateTime.now().millisecondsSinceEpoch
        : lastFetchOkMs,
    accountFootprint: () => footprint,
    syncNow: () async {
      onSync?.call();
      return syncOk;
    },
    inspectLocalData: () async {
      if (integritySeq != null && integritySeq.isNotEmpty) {
        final i = integrityCalls < integritySeq.length
            ? integrityCalls
            : integritySeq.length - 1;
        integrityCalls++;
        return integritySeq[i];
      }
      return integrity ??
          const PdStoreIntegrityReport(present: true, badSections: []);
    },
    repairLocalData: () async => repairCount,
    pruneRouteCache: () async => pruneCount,
    outboxCounts: () async {
      const zero = (rides: 0, packages: 0, messages: 0, ratings: 0);
      if (outboxSeq == null || outboxSeq.isEmpty) return zero;
      final i = outboxCalls < outboxSeq.length
          ? outboxCalls
          : outboxSeq.length - 1;
      outboxCalls++;
      return outboxSeq[i];
    },
    retryOutbox: () async {
      onRetryOutbox?.call();
    },
  );
}

HealthCheckResult _check(HealthReport r, HealthCheckKind kind) =>
    r.checks.firstWhere((c) => c.kind == kind);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    HealthEngine.retryDelay = Duration.zero;
    SharedPreferences.setMockInitialValues({});
  });

  group('inspectPdStoredData — mehfooz records ki jaanch', () {
    test('khaali (koi key nahi) = present false, allOk', () {
      final r = inspectPdStoredData({});
      expect(r.present, isFalse);
      expect(r.allOk, isTrue);
    });

    test('durust data = allOk', () {
      final r = inspectPdStoredData({
        'bookings': jsonEncode([
          {'id': 'b1', 'status': 'pending'}
        ]),
        'monthly': jsonEncode([
          {'id': 'p1'}
        ]),
        'txns': jsonEncode([
          {'note': 'fee'}
        ]),
        'profile': jsonEncode({'name': 'Rashid'}),
        'master_messages': '[]',
        'notifications': '[]',
        'ratings': '[]',
        'push_attempts_v1': '[]',
      });
      expect(r.present, isTrue);
      expect(r.allOk, isTrue);
    });

    test('kharab JSON bookings mein = badSections mein bookings', () {
      final r = inspectPdStoredData({'bookings': 'ye-json-nahi-hai'});
      expect(r.badSections, contains('bookings'));
      expect(r.allOk, isFalse);
    });

    test('profile List ho to kharab', () {
      final r = inspectPdStoredData({'profile': '[1,2,3]'});
      expect(r.badSections, contains('profile'));
    });

    test('bookings ki satar baghair id ke = kharab', () {
      final r = inspectPdStoredData({
        'bookings': jsonEncode([
          {'status': 'pending'}
        ]),
      });
      expect(r.badSections, contains('bookings'));
    });

    test('bookings Map (List nahi) ho to kharab', () {
      final r = inspectPdStoredData({'bookings': '{"id":"b1"}'});
      expect(r.badSections, contains('bookings'));
    });

    test('push_attempts_v1 kharab ho to bhi pakra jata hai', () {
      final r = inspectPdStoredData({'push_attempts_v1': '###'});
      expect(r.badSections, contains('push_attempts_v1'));
    });
  });

  group('RepairLogEntry', () {
    test('JSON round-trip', () {
      final e = RepairLogEntry(
        at: DateTime(2026, 11, 11, 9, 30),
        problem: 'masla',
        action: 'amal',
        success: true,
      );
      final back = RepairLogEntry.fromJson(e.toJson());
      expect(back.at, e.at);
      expect(back.problem, 'masla');
      expect(back.action, 'amal');
      expect(back.success, isTrue);
    });
  });

  group('HealthEngine — jaanch aur khud-repair', () {
    test('sab sehatmand = allOk, koi repair nahi', () async {
      final engine = HealthEngine(_hooks());
      final report = await engine.runNow();
      expect(report.allOk, isTrue);
      expect(report.repairs, isEmpty);
      expect(report.needsUserAction, isFalse);
      expect(report.serverIssueNote, isNull);
    });

    test('backend band = backend check fail + server note', () async {
      final engine = HealthEngine(_hooks(backendOk: false));
      final report = await engine.runNow();
      expect(_check(report, HealthCheckKind.backend).ok, isFalse);
      expect(report.serverIssueNote, isNotNull);
      expect(report.allOk, isFalse);
    });

    test('session purana + refresh kamyab = khud theek', () async {
      final engine = HealthEngine(_hooks(
        session: const BackendSessionState(
            hasSession: true, valid: false, canRefresh: true),
        refreshOk: true,
      ));
      final report = await engine.runNow();
      final c = _check(report, HealthCheckKind.session);
      expect(c.ok, isTrue);
      expect(c.repaired, isTrue);
      expect(engine.repairLog.length, 1);
      expect(engine.repairLog.first.success, isTrue);
    });

    test('session mara hua (refresh nakam) = user ka amal lazmi', () async {
      final engine = HealthEngine(_hooks(
        session: const BackendSessionState(
            hasSession: true, valid: false, canRefresh: true),
        refreshOk: false,
      ));
      final report = await engine.runNow();
      final c = _check(report, HealthCheckKind.session);
      expect(c.ok, isFalse);
      expect(c.needsUserAction, isTrue);
      expect(report.needsUserAction, isTrue);
    });

    test('koi session nahi + account nishan nahi = aam haalat, ok', () async {
      final engine = HealthEngine(_hooks(
        session: const BackendSessionState(
            hasSession: false, valid: false, canRefresh: false),
        footprint: false,
      ));
      final report = await engine.runNow();
      expect(_check(report, HealthCheckKind.session).ok, isTrue);
    });

    test('koi session nahi + account nishan hai = user ka amal lazmi',
        () async {
      final engine = HealthEngine(_hooks(
        session: const BackendSessionState(
            hasSession: false, valid: false, canRefresh: false),
        footprint: true,
      ));
      final report = await engine.runNow();
      final c = _check(report, HealthCheckKind.session);
      expect(c.ok, isFalse);
      expect(c.needsUserAction, isTrue);
    });

    test('sync purani + pull kamyab = khud taaza', () async {
      final engine = HealthEngine(_hooks(
        lastFetchOkMs:
            DateTime.now().millisecondsSinceEpoch - 60 * 60 * 1000,
        syncOk: true,
      ));
      final report = await engine.runNow();
      final c = _check(report, HealthCheckKind.sync);
      expect(c.ok, isTrue);
      expect(c.repaired, isTrue);
    });

    test('sync purani + pull nakam = fail, agli jaanch ka intezaar', () async {
      var syncCalls = 0;
      final engine = HealthEngine(_hooks(
        lastFetchOkMs:
            DateTime.now().millisecondsSinceEpoch - 60 * 60 * 1000,
        syncOk: false,
        onSync: () => syncCalls++,
      ));
      final report = await engine.runNow();
      expect(_check(report, HealthCheckKind.sync).ok, isFalse);
      // Backoff ke saath sirf EK dobara koshish — hammer NAHI.
      expect(syncCalls, 2);
    });

    test('kharab local record + repair kamyab = khud theek', () async {
      final engine = HealthEngine(_hooks(
        integritySeq: const [
          PdStoreIntegrityReport(present: true, badSections: ['bookings']),
          PdStoreIntegrityReport(present: true, badSections: []),
        ],
        repairCount: 1,
      ));
      final report = await engine.runNow();
      final c = _check(report, HealthCheckKind.localData);
      expect(c.ok, isTrue);
      expect(c.repaired, isTrue);
    });

    test('kharab local record + repair nakam = fail rehta hai', () async {
      final engine = HealthEngine(_hooks(
        integrity: const PdStoreIntegrityReport(
            present: true, badSections: ['bookings']),
        repairCount: 0,
      ));
      final report = await engine.runNow();
      expect(_check(report, HealthCheckKind.localData).ok, isFalse);
    });

    test('route cache safai log mein darj hoti hai', () async {
      final engine = HealthEngine(_hooks(pruneCount: 2));
      await engine.runNow();
      expect(
        engine.repairLog.any((e) => e.problem.contains('Route cache')),
        isTrue,
      );
    });

    test('outbox atka hua + retry se saaf = khud theek', () async {
      const three = (rides: 2, packages: 1, messages: 0, ratings: 0);
      const zero = (rides: 0, packages: 0, messages: 0, ratings: 0);
      final engine = HealthEngine(_hooks(outboxSeq: [three, zero]));
      final report = await engine.runNow();
      final c = _check(report, HealthCheckKind.outbox);
      expect(c.ok, isTrue);
      expect(c.repaired, isTrue);
    });

    test('outbox retry ke baad bhi atka rahe = fail, data mehfooz wali tafseel',
        () async {
      const three = (rides: 3, packages: 0, messages: 0, ratings: 0);
      final engine = HealthEngine(_hooks(outboxSeq: [three]));
      final report = await engine.runNow();
      final c = _check(report, HealthCheckKind.outbox);
      expect(c.ok, isFalse);
      expect(c.detail, contains('mehfooz'));
    });

    test('outbox atka hua lekin backend band = retry NAHI hoti', () async {
      const three = (rides: 3, packages: 0, messages: 0, ratings: 0);
      var retries = 0;
      final engine = HealthEngine(_hooks(
        backendOk: false,
        outboxSeq: [three],
        onRetryOutbox: () => retries++,
      ));
      final report = await engine.runNow();
      expect(_check(report, HealthCheckKind.outbox).ok, isFalse);
      expect(retries, 0);
    });

    test('runNow ek waqt mein ek hi jaanch chalata hai', () async {
      final engine = HealthEngine(_hooks());
      final f1 = engine.runNow();
      final f2 = engine.runNow();
      expect(identical(f1, f2), isTrue);
      await f1;
    });
  });

  group('AppStore — kharab data ki load + repair (asal store)', () {
    test('kharab bookings JSON par load nahi rukti, repair copy badal deti hai',
        () async {
      final pkg = MonthlyPackage(
        id: 'p1',
        passengerName: 'Ahmed',
        passengerPhone: '03001234567',
        pickup: 'Clifton',
        drop: 'Saddar',
        vehicle: 'Rickshaw',
        routeKm: 3.0,
        days: 26,
        monthlyAmount: 39000,
        createdAt: DateTime(2026, 11, 11),
      );
      SharedPreferences.setMockInitialValues({
        'bookings': 'kharab-json-###',
        'monthly': jsonEncode([pkg.toJson()]),
      });
      final store = AppStore();
      await store.load();
      expect(store.bookings, isEmpty);
      expect(store.corruptedStoreKeys, contains('bookings'));
      // Durust hisa kharab wale ki wajah se nahi gaya.
      expect(store.monthlyPackages.length, 1);

      final repaired = await store.repairLocalStores();
      expect(repaired, 1);
      expect(store.corruptedStoreKeys, isEmpty);
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('bookings');
      expect(raw, isNotNull);
      expect(jsonDecode(raw!), isList);
    });

    test('kharab profile par bhi load chalti hai aur nishan lagta hai',
        () async {
      SharedPreferences.setMockInitialValues({
        'profile': '"sirf-ek-string"',
      });
      final store = AppStore();
      await store.load();
      expect(store.corruptedStoreKeys, contains('profile'));
      final repaired = await store.repairLocalStores();
      expect(repaired, 1);
      final prefs = await SharedPreferences.getInstance();
      expect(jsonDecode(prefs.getString('profile')!), isMap);
    });

    test('durust data par koi nishan nahi lagta', () async {
      SharedPreferences.setMockInitialValues({
        'bookings': '[]',
        'profile': jsonEncode({'name': 'Test'}),
      });
      final store = AppStore();
      await store.load();
      expect(store.corruptedStoreKeys, isEmpty);
      expect(await store.repairLocalStores(), 0);
    });
  });
}
