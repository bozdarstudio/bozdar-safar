import 'package:flutter/material.dart';

/// Bozdar Safar brand — deep green + gold, ajrak accents.
class Brand {
  static const deepGreen = Color(0xFF0B3D2E);
  static const green = Color(0xFF0B6B4F);
  static const greenDark = Color(0xFF07301F);
  static const gold = Color(0xFFD4AF37);
  static const goldLight = Color(0xFFF2C94C);

  /// Board wala ubhra sabz (DESIGN WAVE — brief §Global): splash
  /// gradient ka ubhra hissa, "Bozdar" wordmark line aur glow ke liye.
  static const brightGreen = Color(0xFF0E9F5A);
  static const cream = Color(0xFFFFF8E7);
  static const ajrakRed = Color(0xFF9E2A2B);
  static const ink = Color(0xFF1E2A26);

  /// inDrive-style clean light background for content areas.
  static const lightBg = Color(0xFFF5F6F5);
  static const fieldBorder = Color(0xFFD8DCD8);

  static ThemeData theme() {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: green,
        primary: green,
        secondary: gold,
        surface: Colors.white,
      ),
      scaffoldBackgroundColor: lightBg,
      fontFamily: 'Roboto',
    );
    return base.copyWith(
      appBarTheme: const AppBarTheme(
        backgroundColor: deepGreen,
        foregroundColor: cream,
        elevation: 0,
        centerTitle: false,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: green,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: green,
          side: const BorderSide(color: green, width: 1.4),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: fieldBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: fieldBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: green, width: 1.8),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      ),
      chipTheme: base.chipTheme.copyWith(
        backgroundColor: Colors.white,
        selectedColor: goldLight,
        side: const BorderSide(color: Color(0xFFB9CFC6)),
        labelStyle: const TextStyle(fontWeight: FontWeight.w600),
      ),
      cardTheme: CardTheme(
        color: Colors.white,
        elevation: 1.5,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: Color(0xFFE6E8E6)),
        ),
      ),
    );
  }

  /// v1.4.30 RAAT (Night) wala theme — DisplayPrefs ki EK
  /// pasand se poori app gehre Safar rangon mein badal jati
  /// hai (map bhi usi pasand se Dark Matter ho jata hai)।
  /// Brand ke pakke hisse (gehra sabz header, sunehri patri)
  /// dono themes mein wohi rehte hain — pehchan nahi badalti।
  static ThemeData darkTheme() {
    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: green,
        brightness: Brightness.dark,
        primary: brightGreen,
        secondary: gold,
        surface: const Color(0xFF16211C),
      ),
      scaffoldBackgroundColor: const Color(0xFF0E1512),
      fontFamily: 'Roboto',
    );
    return base.copyWith(
      appBarTheme: const AppBarTheme(
        backgroundColor: deepGreen,
        foregroundColor: cream,
        elevation: 0,
        centerTitle: false,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: green,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: goldLight,
          side: const BorderSide(color: brightGreen, width: 1.4),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF1B2620),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFF33443B)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFF33443B)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: brightGreen, width: 1.8),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      ),
      chipTheme: base.chipTheme.copyWith(
        backgroundColor: const Color(0xFF1B2620),
        selectedColor: goldLight,
        side: const BorderSide(color: Color(0xFF3D5A4C)),
        labelStyle: const TextStyle(fontWeight: FontWeight.w600),
      ),
      cardTheme: CardTheme(
        color: const Color(0xFF16211C),
        elevation: 1.5,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: Color(0xFF26362D)),
        ),
      ),
    );
  }
}

/// Sindhi ajrak-style border strip: repeating diamonds in red/green/gold.
class AjrakStrip extends StatelessWidget {
  final double height;
  const AjrakStrip({super.key, this.height = 14});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(painter: _AjrakPainter()),
    );
  }
}

class _AjrakPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = Brand.ajrakRed;
    canvas.drawRect(Offset.zero & size, bg);
    final cell = size.height; // square cells
    final colors = [Brand.gold, Brand.green, Brand.cream, Brand.green];
    for (double x = 0; x < size.width + cell; x += cell) {
      for (int row = 0; row < 1; row++) {
        final cx = x + cell / 2;
        final cy = size.height / 2;
        final p = Paint()
          ..color = colors[((x / cell).round() + row) % colors.length];
        final path = Path()
          ..moveTo(cx, cy - cell * 0.34)
          ..lineTo(cx + cell * 0.34, cy)
          ..lineTo(cx, cy + cell * 0.34)
          ..lineTo(cx - cell * 0.34, cy)
          ..close();
        canvas.drawPath(path, p);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// BOZDAR SAFAR ka wordmark (owner ka wordmark lock, 2026-11-08):
/// "Safar" BADA, us ke bilkul neeche GREEN mein "Bozdar", aur saath
/// gold "App" tag — poora brand: BOZDAR SAFAR APP. Har header/logo
/// wali jagah yehi ek shakal lagegi. Asal Text widgets hain (tasveer
/// nahi) taaki har screen size par saaf rahein. Gehri sabz
/// pas-e-manzar ke liye hai — halki bg par istemal se pehle dark
/// variant sochna hoga.
class BrandWordmark extends StatelessWidget {
  final double safarSize;
  const BrandWordmark({super.key, this.safarSize = 30});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              'Safar',
              style: TextStyle(
                color: Colors.white,
                fontSize: safarSize,
                fontWeight: FontWeight.w900,
                height: 1.0,
                letterSpacing: 0.4,
              ),
            ),
            const SizedBox(width: 7),
            Padding(
              padding: const EdgeInsets.only(bottom: 3),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(
                  color: Brand.gold,
                  borderRadius: BorderRadius.circular(7),
                ),
                child: Text(
                  'App',
                  style: TextStyle(
                    color: Brand.greenDark,
                    fontSize: safarSize * 0.42,
                    fontWeight: FontWeight.w900,
                    height: 1.0,
                  ),
                ),
              ),
            ),
          ],
        ),
        Text(
          'Bozdar',
          style: TextStyle(
            color: Brand.brightGreen,
            fontSize: safarSize * 0.52,
            fontWeight: FontWeight.w800,
            height: 1.15,
            letterSpacing: 1.6,
          ),
        ),
      ],
    );
  }
}

/// Naam ke pehle harf wala goal sabz avatar (DESIGN WAVE brief
/// §3/§6) — header ke dayein kinare; tap par Profile khulta hai.
/// Asal photo passenger ke liye hai hi nahi — jaali photo NAHI,
/// sirf asal naam ka pehla harf; naam na ho to person icon.
class InitialAvatar extends StatelessWidget {
  final String name;
  final VoidCallback? onTap;
  const InitialAvatar({super.key, required this.name, this.onTap});

  @override
  Widget build(BuildContext context) {
    final t = name.trim();
    return InkWell(
      onTap: onTap,
      customBorder: const CircleBorder(),
      child: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Brand.brightGreen,
          border: Border.all(color: Brand.gold, width: 1.6),
        ),
        alignment: Alignment.center,
        child: t.isEmpty
            ? const Icon(Icons.person, color: Colors.white, size: 21)
            : Text(
                t.characters.first.toUpperCase(),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                ),
              ),
      ),
    );
  }
}

/// Gold wordmark header used at the top of both sides.
/// v1.4.5 (B5): [actions] header ke ANDAR dayein taraf lagte hain —
/// ghanti (NotificationBell) + avatar wahin, brief §3 ke mutabiq.
class BrandHeader extends StatelessWidget {
  final String sideLabel;
  final List<Widget> actions;
  const BrandHeader(
      {super.key, required this.sideLabel, this.actions = const []});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Brand.deepGreen,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 2),
            child: Row(
              children: [
                // Naya SAFAR logo (v1.4.0 — malik ka hukm 2026-11-07:
                // sabz shield "S" nishan, taaj + pankh + SAFAR wordmark).
                Image.asset(
                  'assets/safar-header.png',
                  height: 38,
                  alignment: Alignment.centerLeft,
                ),
                const SizedBox(width: 12),
                // Wordmark lock (2026-11-08): Safar bada, neeche
                // GREEN mein Bozdar, saath App — BOZDAR SAFAR APP
                // har header par saaf lafzon mein bhi nazar aye
                // (poster art ke ilawa bhi).
                const BrandWordmark(safarSize: 21),
                const Spacer(),
                ...actions,
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text(
              sideLabel,
              style: const TextStyle(
                color: Brand.goldLight,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.6,
              ),
            ),
          ),
          const AjrakStrip(height: 12),
        ],
      ),
    );
  }
}

/// Malik ki apni mode artwork (brand board se) — har side ke BrandHeader +
/// ModeToggleButton ke foran neeche full-width banner card. Driver side par
/// rickshaw driver (gents) wali, passenger side par passenger (ladki + phone)
/// wali tasveer. Har side sirf apni render karti hai.
class ModeBanner extends StatelessWidget {
  final String asset;
  const ModeBanner({super.key, required this.asset});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Image.asset(
          asset,
          width: double.infinity,
          height: 170,
          fit: BoxFit.cover,
          alignment: Alignment.topCenter,
        ),
      ),
    );
  }
}

/// A / B wala gol-chokor badge — v1.4.29 (DRIVER-FLOW-SPEC
/// 2026-11-11): cardon/sheeton/fields mein pickup = A, manzil
/// = B ki pehchan, bilkul map wale pins jaisi. Apna widget
/// hai, kisi doosri app ka asset/design NAHI.
/// v1.4.42: widget theme.dart mein aya taake passenger panel
/// bhi yehi badge istemal kare (pehle sirf driver.dart mein
/// tha); [color] diya jaye to badge usi rang ka banta hai —
/// passenger panel mein A sabz (pickup) aur B gehra laal
/// (manzil) hai, driver cardon par default kaala hi rehta
/// hai (map pins jaisa)।
Widget safarAbBadge(String letter, {double size = 26, Color? color}) {
  return Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      color: color ?? const Color(0xFF141414),
      borderRadius: BorderRadius.circular(size * 0.28),
      border: Border.all(color: Colors.white, width: 1.6),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.25),
          blurRadius: 3,
          offset: const Offset(0, 1),
        ),
      ],
    ),
    alignment: Alignment.center,
    child: Text(
      letter,
      style: TextStyle(
        color: Colors.white,
        fontSize: size * 0.52,
        fontWeight: FontWeight.w900,
      ),
    ),
  );
}

String rs(int v) => 'Rs ${v.toString()}';

String fmtDate(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';

String fmtTime(DateTime d) {
  final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
  final ap = d.hour >= 12 ? 'PM' : 'AM';
  return '$h:${d.minute.toString().padLeft(2, '0')} $ap';
}
