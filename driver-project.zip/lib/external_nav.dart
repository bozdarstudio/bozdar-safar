import 'package:url_launcher/url_launcher.dart';

/// v1.4.82+105 — MAJBURI navigation (Boz ka navigation usool,
/// 2026-11-24): hamara apna map hamesha DEFAULT aur permanent hai —
/// pickup ho ya drop, driver apne map par hi chalega. Ye function
/// sirf us waqt istemal hota hai jab driver khud "bahari navigation
/// app" wala button dabaye (majburi/backup):
///   1. Waze — agar driver ke phone mein Waze hai to manzil usi
///      mein khulegi (us ke paas Karachi ka asal live traffic hai).
///   2. Google Maps — Waze na ho to ye backup hai.
///   3. geo: — aakhri surat, phone ka apna chooser.
/// Koi bhi rasta na khule to false wapas aata hai; app band nahi
/// hoti aur driver apne map par hi rehta hai.
Future<bool> openExternalNavigation(double lat, double lng) async {
  final waze = Uri.parse('waze://?ll=$lat,$lng&navigate=yes');
  try {
    if (await canLaunchUrl(waze)) {
      if (await launchUrl(waze, mode: LaunchMode.externalApplication)) {
        return true;
      }
    }
  } catch (_) {}
  final gmaps = Uri.parse(
      'https://www.google.com/maps/dir/?api=1&destination=$lat,$lng');
  try {
    if (await launchUrl(gmaps, mode: LaunchMode.externalApplication)) {
      return true;
    }
  } catch (_) {}
  try {
    return await launchUrl(
      Uri.parse('geo:$lat,$lng?q=$lat,$lng'),
      mode: LaunchMode.externalApplication,
    );
  } catch (_) {
    return false;
  }
}
