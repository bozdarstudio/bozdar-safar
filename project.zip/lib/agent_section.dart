import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'backend.dart';
import 'lang.dart';
import 'otp.dart';
import 'store.dart';
import 'theme.dart';

/// Agent ka khaas LINK (v1.4.7, spec §6) — GitHub Pages par
/// rakhi agent.html wali shakal: link khule to app download ka
/// button + "Register" jo app ko code ke saath kholta hai
/// (bozdarsafar://register?agent=CODE, deep link)।
String agentLinkFor(String code) =>
    'https://bozdarstudio.github.io/bozdar-safar/agent.html?code=$code';

/// "MERA AGENT HISA" (v1.4.6 — Agent System, AGENT-SYSTEM-SPEC §2)
///
/// Profile (DONO modes — passenger Profile tab aur driver Profile)
/// mein lagne wala hisa. Logged-in mobile (passenger = apna mobile
/// login, driver = driver record ka mobile) backend `agents`
/// table mein kisi ACTIVE agent se match kare to hi ye card
/// khulta hai — match na ho to hisa BILKUL nazar nahi ata
/// (SizedBox.shrink). Agent sirf Master se banta hai; yahan koi
/// agent NAHI banta.
///
/// Card mein sirf ye hai (spec ki sakht had — is se zyada NAHI):
///  (a) Agent ki apni profile: photo lagana/badlana + naam/sheher.
///  (b) Us ke drivers ki list: sirf naam, gaari, active/tasdeeq
///      status, kul (mukammal) rides ki tadaad.
///  (c) Apna kul record: kul drivers, kul rides.
/// v1.4.7 (spec §6): (a2) agent ka khaas LINK (copy/WhatsApp)।
/// v1.4.40 (owner ka hukm 2026-11-12): agent ko KOI payment /
/// bonus / commission NAHI — is liye fare/fee ke stats aur
/// refer-bonus ka poora hisaab agent-facing screen se HATA
/// diya gaya hai। Agent sirf drivers register kar sakta hai
/// aur apne drivers ki haalat dekh sakta hai — is se zyada
/// koi access NAHI, paisay ka koi zikr NAHI।
class AgentSection extends StatefulWidget {
  final AppStore store;
  const AgentSection({super.key, required this.store});

  @override
  State<AgentSection> createState() => _AgentSectionState();
}

class _AgentSectionState extends State<AgentSection> {
  final ImagePicker _picker = ImagePicker();
  bool _loading = true;
  bool _photoBusy = false;
  AgentInfo? _agent;
  List<AgentDriverTally> _drivers = const [];
  String _localPhoto = '';

  // --- v1.4.14: AGENT EMAIL DARWAZA (faisla D-1) ------------------
  // Agent ke liye bhi Gmail + OTP LAZMI hai: email verify hue
  // baghair agent ka hisa (drivers ki list, record, photo,
  // link) NAHI khulta — data load hi nahi hota। Verify shuda
  // email is phone par agent ke code ke saath mehfooz rehti hai
  // (SharedPreferences: agent_email_<code> /
  // agent_email_verified_ms_<code>)। Server-side record Phase 0b
  // (2026-11-09) se live hai: agents.email column + link_agent
  // RPC — verify kamyab hote hi Backend.linkAgentIdentity se
  // server par email + identity_links ka 'agent' record banta
  // hai; local record us ka phone-side saboot rehta hai।
  final _agentEmailCtrl = TextEditingController();
  bool _emailGateOpen = false;
  String _agentVerifiedEmail = '';

  // --- v1.4.53: AGENT PASSWORD (malik ka hukm 2026-11-15) -----
  // Gmail OTP ke saath DOOSRA rasta: agent apna password KHUD
  // lagata hai — Supabase Auth ka built-in password, USI Auth
  // user par jo OTP verify se banta hai (Backend.
  // updateAuthPassword)। Password lag jane ka phone-side
  // record: SharedPreferences agent_pw_set_<code>।
  //  - Session mehfooz ho (darwaza khula) to kuch NAHI
  //    poochha jata — purani haalat bilkul waisi hi।
  //  - Darwaza band ho (naya phone / session khatm) to gate
  //    card par Gmail code ke saath "Password se dakhil hon"
  //    bhi maujood hai; password bhool jaye to Gmail code hi
  //    recovery hai।
  //  - Gmail code se TAZA verify ke baad (aur is build par
  //    pehli dafa khulne par) password lagane ki peshkash ati
  //    hai — "Abhi nahi" se is dafa skip ho jati hai, lekin
  //    password lagne tak har taza dakhlay par phir ayegi।
  final _pwEmailCtrl = TextEditingController();
  final _pwLoginCtrl = TextEditingController();
  final _pwNewCtrl = TextEditingController();
  final _pwConfirmCtrl = TextEditingController();
  bool _pwBusy = false;
  bool _pwSetBusy = false;
  bool _showSetPassword = false;
  static bool _pwPromptShownThisRun = false;

  AppStore get store => widget.store;

  @override
  void dispose() {
    _agentEmailCtrl.dispose();
    _pwEmailCtrl.dispose();
    _pwLoginCtrl.dispose();
    _pwNewCtrl.dispose();
    _pwConfirmCtrl.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    // Dono pehchanen check hoti hain (same-device par aksar ek
    // hi number driver bhi hota hai aur passenger bhi).
    AgentInfo? found;
    for (final m in {store.passengerPhone, store.profile.phone}) {
      if (m.trim().isEmpty) continue;
      found = await AgentApi.fetchAgentForMobile(m);
      if (found != null) break;
    }
    if (!mounted) return;
    if (found == null) {
      setState(() {
        _agent = null;
        _loading = false;
      });
      return;
    }
    // v1.4.14 D-1: email darwaza — is agent code ke liye is
    // phone par email verify pehle se ho chuki hai ya nahi।
    var gateOpen = false;
    var verifiedEmail = '';
    try {
      final prefs = await SharedPreferences.getInstance();
      verifiedEmail = prefs.getString('agent_email_${found.code}') ?? '';
      final ms = prefs.getInt('agent_email_verified_ms_${found.code}') ?? 0;
      gateOpen = ms > 0 && verifiedEmail.isNotEmpty;
    } catch (_) {
      gateOpen = false;
    }
    if (!mounted) return;
    final foundEmail = found.email;
    setState(() {
      _agent = found;
      _emailGateOpen = gateOpen;
      _agentVerifiedEmail = verifiedEmail;
      if (verifiedEmail.isNotEmpty) _agentEmailCtrl.text = verifiedEmail;
      // v1.4.53: record wali email khaali khano mein pehle se
      // bhar dein — agent ko apni sahi email khud yaad karke
      // likhni na pade (badal phir bhi sakta hai)।
      if (foundEmail.isNotEmpty) {
        if (_agentEmailCtrl.text.trim().isEmpty) {
          _agentEmailCtrl.text = foundEmail;
        }
        if (_pwEmailCtrl.text.trim().isEmpty) {
          _pwEmailCtrl.text = foundEmail;
        }
      }
      _loading = false;
    });
    // Email band ho to agent ka DATA load hi nahi hota (access
    // band — D-1); darwaza khulte hi _loadAgentData chalega।
    // Darwaza pehle se khula ho to server-side pehchan (link_agent)
    // ki khamosh retry bhi yahin — verify ke waqt fail hua ho to
    // yahan pakra jata hai।
    if (gateOpen) {
      await Backend.linkAgentIdentity(found.id);
      await _loadAgentData(found);
      // v1.4.53: darwaza pehle se khula tha (session mehfooz)
      // — password abhi tak na laga ho to is run mein EK dafa
      // password lagane ki peshkash (is build par pehli dafa
      // anay wale purane agents ke liye bhi)। "Abhi nahi" ke
      // baad is run mein dobara nahi ayegi; agli taza entry
      // par phir ayegi — password lagne tak।
      if (!_pwPromptShownThisRun && mounted) {
        var pwSet = false;
        try {
          final prefs = await SharedPreferences.getInstance();
          pwSet = prefs.getBool('agent_pw_set_${found.code}') ?? false;
        } catch (_) {
          pwSet = false;
        }
        if (!pwSet && mounted) {
          _pwPromptShownThisRun = true;
          setState(() => _showSetPassword = true);
        }
      }
    }
  }

  /// Agent ka asal data (drivers, photo) — SIRF email
  /// darwaza khulne ke baad load hota hai।
  Future<void> _loadAgentData(AgentInfo found) async {
    final drivers = await AgentApi.fetchAgentDrivers(found.code);
    String local = '';
    try {
      final prefs = await SharedPreferences.getInstance();
      local = prefs.getString('agent_photo_local_${found.code}') ?? '';
      if (local.isNotEmpty && !await File(local).exists()) local = '';
    } catch (_) {
      local = '';
    }
    if (!mounted) return;
    setState(() {
      _drivers = drivers;
      _localPhoto = local;
    });
  }

  /// Email OTP verify kamyab — record mehfooz + darwaza khula।
  /// v1.4.53: [viaPassword] = dakhla password se hua hai (us
  /// surat mein password pehle se maujood hai — lagane ki
  /// peshkash NAHI ati, sirf record pakka hota hai)।
  Future<void> _onAgentEmailVerified(String email,
      {bool viaPassword = false}) async {
    final a = _agent;
    if (a == null) return;
    var pwSet = viaPassword;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('agent_email_${a.code}', email);
      await prefs.setInt('agent_email_verified_ms_${a.code}',
          DateTime.now().millisecondsSinceEpoch);
      if (viaPassword) {
        await prefs.setBool('agent_pw_set_${a.code}', true);
      } else {
        pwSet = prefs.getBool('agent_pw_set_${a.code}') ?? false;
      }
    } catch (_) {
      // Record na likha jaye to bhi is session ke liye darwaza
      // khul jata hai; agli dafa phir verify karna hoga।
    }
    if (!mounted) return;
    setState(() {
      _emailGateOpen = true;
      _agentVerifiedEmail = email;
      // v1.4.53: Gmail code se TAZA dakhla aur password abhi
      // tak nahi laga — password lagane ki peshkash (har taza
      // dakhlay par ayegi, jab tak password lag na jaye)।
      _showSetPassword = !pwSet;
      if (!pwSet) _pwPromptShownThisRun = true;
    });
    // Phase 0b: server par bhi pehchan bandhna (link_agent RPC —
    // agents.email + identity_links 'agent' record)। Khamosh
    // best-effort: fail ho to agent ka rasta nahi rukta; agli
    // dafa data load par phir koshish hoti hai।
    await Backend.linkAgentIdentity(a.id);
    await _loadAgentData(a);
  }

  /// v1.4.53: gate card par "Password se dakhil hon" — email +
  /// password sign-in। Kamyabi ki doosri shart: sign-in wali
  /// email IS agent ki ho — record par email darj ho to wohi
  /// honi chahiye, aur link_agent RPC bhi wohi parkhta hai
  /// (row ki email kisi aur ki ho to link nahi banta)। Match
  /// na ho to bani hui session saaf karke wapas band darwaza
  /// — kisi aur ki pehchan is hisay ko NAHI khol sakti।
  Future<void> _loginWithPassword() async {
    final a = _agent;
    if (a == null || _pwBusy) return;
    final email = _pwEmailCtrl.text.trim().toLowerCase();
    final pw = _pwLoginCtrl.text;
    if (email.isEmpty || !email.contains('@') || pw.isEmpty) {
      _snack(tr('agent_pw_login_fail'));
      return;
    }
    setState(() => _pwBusy = true);
    final ok = await Backend.signInWithPassword(email, pw);
    if (!mounted) return;
    if (!ok) {
      setState(() => _pwBusy = false);
      _snack(tr('agent_pw_login_fail'));
      return;
    }
    var linked = false;
    if (a.email.isEmpty || a.email == email) {
      linked = await Backend.linkAgentIdentity(a.id);
    }
    if (!mounted) return;
    setState(() => _pwBusy = false);
    if (!linked) {
      await Backend.clearSession();
      _snack(tr('agent_pw_login_mismatch'));
      return;
    }
    _pwLoginCtrl.clear();
    await _onAgentEmailVerified(email, viaPassword: true);
  }

  /// v1.4.53: naya password lagana (session pehle se bana hua
  /// hai — OTP verify ya mehfooz session se)। Kamyabi par
  /// phone-side record agent_pw_set_<code> pakka ho jata hai
  /// aur peshkash band ho jati hai।
  Future<void> _savePassword() async {
    final a = _agent;
    if (a == null || _pwSetBusy) return;
    final p1 = _pwNewCtrl.text;
    final p2 = _pwConfirmCtrl.text;
    if (p1.length < 6) {
      _snack(tr('agent_pw_short'));
      return;
    }
    if (p1 != p2) {
      _snack(tr('agent_pw_mismatch'));
      return;
    }
    setState(() => _pwSetBusy = true);
    final ok = await Backend.updateAuthPassword(p1);
    if (!mounted) return;
    setState(() => _pwSetBusy = false);
    if (!ok) {
      _snack(tr('agent_pw_fail'));
      return;
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('agent_pw_set_${a.code}', true);
    } catch (_) {
      // Record na lage to agli taza entry par peshkash phir
      // ayegi — password server par lag chuka hai, dobara
      // lagana bhi nuqsan nahi।
    }
    _pwNewCtrl.clear();
    _pwConfirmCtrl.clear();
    if (!mounted) return;
    setState(() => _showSetPassword = false);
    _snack(tr('agent_pw_done'));
  }

  /// v1.4.53: "Abhi nahi" — peshkash is dafa ke liye band;
  /// record nahi badalta, is liye agli taza entry par phir
  /// ayegi (password lagne tak)।
  void _skipPassword() {
    if (!mounted) return;
    setState(() => _showSetPassword = false);
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  /// Apni profile photo lagana/badlana: pehle source (camera /
  /// gallery), phir upload (driver-docs: agents/<code>/profile
  /// .jpg) — kamyabi par is phone par LOCAL file hi dikhti hai
  /// (bucket v132 se private hai; Master signed URL se dekhta
  /// hai).
  Future<void> _changePhoto() async {
    final agent = _agent;
    if (agent == null || _photoBusy) return;
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera),
              title: Text(tr('agent_pick_camera')),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: Text(tr('agent_pick_gallery')),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (src == null || !mounted) return;
    XFile? img;
    try {
      img = await _picker.pickImage(source: src, imageQuality: 85);
    } catch (_) {
      _snack(tr('agent_snack_photo_fail'));
      return;
    }
    if (img == null) {
      _snack(tr('agent_snack_photo_none'));
      return;
    }
    setState(() => _photoBusy = true);
    final path = await AgentApi.uploadAgentPhoto(agent, File(img.path));
    if (!mounted) return;
    setState(() => _photoBusy = false);
    if (path == null) {
      _snack(tr('agent_snack_upload_fail'));
      return;
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('agent_photo_local_${agent.code}', img.path);
    } catch (_) {
      // Local nishan na lage to bhi upload ho chuka hai.
    }
    if (!mounted) return;
    setState(() => _localPhoto = img!.path);
    _snack(tr('agent_snack_photo_done'));
  }

  static String _docLabel(String s) => switch (s) {
        'verified' => tr('agent_doc_done'),
        'rejected' => tr('agent_doc_rejected'),
        _ => tr('agent_doc_pending'),
      };

  @override
  Widget build(BuildContext context) {
    // Load ho raha ho ya is mobile ka koi agent hi na ho — hisa
    // bilkul nazar nahi ata (spec: match na ho to ghayab).
    if (_loading || _agent == null) return const SizedBox.shrink();
    // v1.4.14 D-1: email darwaza band ho to sirf band card —
    // agent ka koi data (drivers/record/link) nazar NAHI
    // ata aur load bhi nahi hua hota।
    if (!_emailGateOpen) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.badge, color: Brand.green),
                  const SizedBox(width: 9),
                  Text(tr('agent_title'),
                      style: const TextStyle(
                          fontWeight: FontWeight.w900, fontSize: 15)),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                tr('agent_gate_text'),
                style: const TextStyle(fontSize: 13, height: 1.5),
              ),
              const SizedBox(height: 10),
              EmailOtpSection(
                emailCtrl: _agentEmailCtrl,
                alreadyVerifiedEmail: _agentVerifiedEmail,
                onVerified: _onAgentEmailVerified,
              ),
              // v1.4.53: doosra rasta — password se dakhla
              // (password pehle laga ho tab hi chalega; bhool
              // jane par upar wala Gmail code hi recovery hai)।
              const Divider(height: 26),
              Text(tr('agent_pw_login_title'),
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 13.5)),
              const SizedBox(height: 6),
              Text(
                tr('agent_pw_login_text'),
                style: const TextStyle(fontSize: 12.5, height: 1.5),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _pwEmailCtrl,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: tr('agent_pw_email_label'),
                  prefixIcon: const Icon(Icons.email_outlined),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _pwLoginCtrl,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: tr('agent_pw_label'),
                  prefixIcon: const Icon(Icons.lock_outline),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  icon: _pwBusy
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.login, size: 18),
                  label: Text(tr('agent_pw_login_btn')),
                  onPressed: _pwBusy ? null : _loginWithPassword,
                ),
              ),
            ],
          ),
        ),
      );
    }
    final a = _agent!;
    final totalRides = _drivers.fold<int>(0, (s, d) => s + d.rides);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.badge, color: Brand.green),
                const SizedBox(width: 9),
                Text(tr('agent_title'),
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 15)),
              ],
            ),
            // v1.4.53: password lagane ki peshkash — taza verify
            // ke baad ya is build par pehli dafa khulne par,
            // jab tak password lag na jaye।
            if (_showSetPassword) ...[
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFE8F5E9),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Brand.green),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tr('agent_pw_set_title'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 13.5)),
                    const SizedBox(height: 4),
                    Text(
                      tr('agent_pw_set_text'),
                      style: const TextStyle(fontSize: 12.5, height: 1.5),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _pwNewCtrl,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: tr('agent_pw_new_label'),
                        prefixIcon: const Icon(Icons.lock_outline),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _pwConfirmCtrl,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: tr('agent_pw_confirm_label'),
                        prefixIcon: const Icon(Icons.vpn_key_outlined),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton(
                            onPressed: _pwSetBusy ? null : _savePassword,
                            child: _pwSetBusy
                                ? const SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white))
                                : Text(tr('agent_pw_save_btn')),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: _pwSetBusy ? null : _skipPassword,
                            child: Text(tr('agent_pw_skip_btn')),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 12),
            // (a) Agent ki apni profile
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Brand.green,
                  backgroundImage:
                      _localPhoto.isNotEmpty ? FileImage(File(_localPhoto)) : null,
                  child: _localPhoto.isNotEmpty
                      ? null
                      : Text(
                          a.name.isNotEmpty ? a.name[0].toUpperCase() : '?',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.bold),
                        ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(a.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 15.5)),
                      Text(
                        trf('agent_city_code', {
                          'city': a.city.isEmpty ? '—' : a.city,
                          'code': a.code
                        }),
                        style: const TextStyle(
                            color: Colors.black54, fontSize: 12.5),
                      ),
                      const SizedBox(height: 2),
                      Text(tr('agent_badge'),
                          style: const TextStyle(
                              color: Brand.green,
                              fontSize: 12,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                icon: _photoBusy
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.photo_camera, size: 18),
                label: Text(_localPhoto.isEmpty && a.photoPath.isEmpty
                    ? tr('agent_photo_add')
                    : tr('agent_photo_change')),
                onPressed: _photoBusy ? null : _changePhoto,
              ),
            ),
            const SizedBox(height: 10),
            // (a2) v1.4.7 AGENT LINK (spec §6): yehi link driver
            // ko bhejna hai — link khule to app milegi aur code
            // khud bhara milega (registration dobara nahi rukti)।
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF6E0),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Brand.gold),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('agent_link_title'),
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 13)),
                  const SizedBox(height: 4),
                  Text(agentLinkFor(a.code),
                      style: const TextStyle(
                          fontSize: 12, color: Brand.greenDark)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.copy, size: 16),
                          label: Text(tr('agent_copy')),
                          onPressed: () async {
                            await Clipboard.setData(
                                ClipboardData(text: agentLinkFor(a.code)));
                            _snack(tr('agent_snack_link_copied'));
                          },
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.share, size: 16),
                          label: const Text('WhatsApp'),
                          onPressed: () async {
                            final text = trf('agent_share_text', {
                              'code': a.code,
                              'link': agentLinkFor(a.code)
                            });
                            final uri = Uri.parse(
                                'https://wa.me/?text=${Uri.encodeComponent(text)}');
                            final ok = await launchUrl(uri,
                                mode: LaunchMode.externalApplication);
                            if (!ok) {
                              _snack(tr('agent_snack_wa_fail'));
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const Divider(height: 22),
            // (c) Kul record — sirf ginti (drivers + rides)।
            // v1.4.40: fare/fee ke stats HATA diye gaye (owner
            // ka hukm: agent ko paisay ka koi hisaab NAHI)।
            Text(tr('agent_total_title'),
                style: const TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 13.5)),
            const SizedBox(height: 8),
            Row(
              children: [
                _stat('Drivers', '${_drivers.length}'),
                _stat('Rides', '$totalRides'),
              ],
            ),
            const SizedBox(height: 8),
            // v1.4.40: agent ki had ki saada wazahat (bonus /
            // commission wali purani line ki jagah)।
            Text(
              tr('agent_scope_note'),
              style: const TextStyle(fontSize: 12.5, color: Colors.black54),
            ),
            // (b) Us ke drivers ki list
            if (_drivers.isNotEmpty) ...[
              const Divider(height: 22),
              Text(tr('agent_drivers_title'),
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 13.5)),
              const SizedBox(height: 6),
              for (final d in _drivers) _driverRow(d),
            ] else ...[
              const SizedBox(height: 10),
              Text(
                tr('agent_no_drivers'),
                style: const TextStyle(fontSize: 12.5, color: Colors.black54),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value,
              style:
                  const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
          Text(label,
              style: const TextStyle(color: Colors.black54, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _driverRow(AgentDriverTally d) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(d.active ? Icons.check_circle : Icons.pending_actions,
              size: 19, color: d.active ? Brand.green : Brand.gold),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  d.name.isEmpty ? tr('agent_name_missing') : d.name,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 13.5),
                ),
                Text(
                  [
                    if (d.vehicle.isNotEmpty) d.vehicle,
                    if (d.plate.isNotEmpty) d.plate,
                  ].join(' · '),
                  style:
                      const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                Text(
                  d.active
                      ? tr('agent_id_active')
                      : trf('agent_doc_status', {
                          'c': _docLabel(d.cnicStatus),
                          'g': _docLabel(d.gaariStatus),
                          'l': _docLabel(d.licenceStatus)
                        }),
                  style:
                      const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                Text(
                  trf('agent_driver_rides', {'n': '${d.rides}'}),
                  style: const TextStyle(fontSize: 12.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
