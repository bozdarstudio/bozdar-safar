import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'store.dart';
import 'theme.dart' show rs;

/// SAFAR backend sync (v1.1.0) — Supabase REST, sirf dart:io HttpClient.
///
/// Usool:
/// - Local store hamesha asal sach hai; backend us ka AAINA (mirror) hai
///   taaki Master app mein sab kuch nazar aye.
/// - Har network kaam best-effort hai: offline/error par bilkul khamosh —
///   UI kabhi nahi rukti, koi error kabhi nahi dikhta, app crash nahi hota.
/// - Settings ka rukh sirf EK taraf hai: Master (backend) → app. Is app
///   mein settings ka koi editor nahi; server na mile to akhri cached
///   values, woh bhi na hon to built-in defaults chalte hain.
/// - Column/table naam backend-schema.sql ke ain mutabiq hain.
class Backend {
  static const String _base =
      'https://ndcnqotfqpgkgsngewug.supabase.co/rest/v1';
  // Publishable (client) key — apps mein embed karna mehfooz hai;
  // secret key kabhi app mein nahi jati.
  static const String _key =
      'sb_publishable_3TWtf4zT6xJzuyb0fsMuWQ_Fjkyk3LE';
  static const Duration _timeout = Duration(seconds: 8);

  static AppStore? _store;
  static bool _started = false;

  /// App start par EK dafa — main.dart se. Store ke sync hook ko jodta
  /// hai aur pehla sync (device entry, settings, zones, driver status)
  /// background mein chalata hai. Dobara bulane par kuch nahi hota.
  static void start(AppStore store) {
    if (_started) return;
    _started = true;
    _store = store;
    store.syncHook = _onHook;
    unawaited(_startup(store));
  }

  static Future<void> _startup(AppStore store) async {
    // Pehle cached settings (offline ho to bhi Master ki akhri setting
    // chalti rahe), phir fresh pull.
    await _applyCachedSettings();
    await touchDevice(store, 'passenger');
    await _pullSettings();
    await _pullZones(store);
    await refreshDriverStatus(store);
    if (_registered(store)) await _pushDriver(store);
  }

  // --- HTTP helpers (sab khamosh — fail = null/false) ------------------------

  static Future<dynamic> _get(String path) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client.getUrl(Uri.parse('$_base/$path')).timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      final resp = await req.close().timeout(_timeout);
      final body = await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode != 200) return null;
      return jsonDecode(body);
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  /// PK par upsert (insert ya update) — PostgREST merge-duplicates.
  /// Jo columns bheje jate hain sirf wohi likhe jate hain.
  static Future<bool> _upsert(String table, Map<String, dynamic> row) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req =
          await client.postUrl(Uri.parse('$_base/$table')).timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      req.headers.set('Prefer', 'resolution=merge-duplicates,return=minimal');
      req.write(jsonEncode(row));
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      return resp.statusCode >= 200 && resp.statusCode < 300;
    } catch (_) {
      return false;
    } finally {
      client?.close();
    }
  }

  // --- Devices ---------------------------------------------------------------

  /// Har app khulne par + mode badalne par: is phone ki entry taza.
  /// first_seen sirf pehli insert par banta hai (server default).
  static Future<void> touchDevice(AppStore store, String mode) async {
    if (store.deviceId.isEmpty) return;
    await _upsert('devices', {
      'device_id': store.deviceId,
      'last_seen': DateTime.now().toUtc().toIso8601String(),
      'last_mode': mode,
      'role': mode,
      'app_version': kAppVersion,
    });
  }

  // --- Settings (Master → app, ek rukh) --------------------------------------

  static Future<void> _applyCachedSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('srv_settings_json');
      if (raw == null) return;
      final j = jsonDecode(raw);
      if (j is Map<String, dynamic>) _applySettings(j);
    } catch (_) {
      // Cache kharab ho to defaults hi sahi.
    }
  }

  static Future<void> _pullSettings() async {
    final data = await _get('settings?select=*&id=eq.1');
    if (data is! List || data.isEmpty) return;
    final row = data.first;
    if (row is! Map<String, dynamic>) return;
    _applySettings(row);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('srv_settings_json', jsonEncode(row));
    } catch (_) {
      // Cache na likha jaye to koi baat nahi — values lag chuki hain.
    }
  }

  static void _applySettings(Map<String, dynamic> s) {
    Map<String, int>? intMap(dynamic v) {
      if (v is! Map) return null;
      final out = <String, int>{};
      v.forEach((k, val) {
        final n = val is num ? val.toInt() : int.tryParse('$val');
        if (n != null) out['$k'] = n;
      });
      return out;
    }

    Fares.applyServerSettings(
      feePercent: (s['fee_percent'] as num?)?.toDouble(),
      rates: intMap(s['rate_per_km']),
      waiting: intMap(s['waiting_per_min']),
      freeWaitingMin: (s['free_waiting_min'] as num?)?.toInt(),
      deposit: (s['joining_deposit'] as num?)?.toInt(),
    );
  }

  // --- Zones -----------------------------------------------------------------

  /// Server par band (open=false) zone passenger ki list se nikal jata
  /// hai. Server khaali mile to local [kZones] hi rehte hain.
  static Future<void> _pullZones(AppStore store) async {
    final data = await _get('zones?select=name,open');
    if (data is! List || data.isEmpty) return;
    final openByName = <String, bool>{};
    for (final r in data) {
      if (r is Map && r['name'] is String) {
        openByName[r['name'] as String] = r['open'] == true;
      }
    }
    if (openByName.isEmpty) return;
    final visible = <String>[
      ...kZones.where((z) => openByName[z] != false),
      // Master ne naya zone joda ho to woh bhi (agar khula hai).
      ...openByName.keys
          .where((z) => !kZones.contains(z) && openByName[z] == true),
    ];
    store.applyServerZones(visible);
  }

  // --- Driver ----------------------------------------------------------------

  /// Registration tabhi mana jata hai jab profile mein naam + mobile
  /// dono mojood hon (Profile Save se ate hain).
  static bool _registered(AppStore store) =>
      store.driverId.isNotEmpty &&
      store.profile.name.trim().isNotEmpty &&
      store.profile.phone.trim().isNotEmpty;

  /// Driver row ka pura mirror — registration (status pending: active
  /// hamesha akhri maloom Master value hi bhejte hain taaki Master ki
  /// ACTIVE tasdeeq is upsert se mit na jaye), online/offline,
  /// wallet balance, documents ki haalat.
  static Future<void> _pushDriver(AppStore store) async {
    if (!_registered(store)) return;
    final p = store.profile;
    await _upsert('drivers', {
      'id': store.driverId,
      'name': p.name,
      'mobile': p.phone,
      'vehicle': p.vehicle,
      'plate': p.plate,
      'zone': p.zone,
      'active': p.masterActive,
      'online': p.online,
      'on_ride': store.bookings
          .any((b) => b.status == 'accepted' || b.status == 'arrived'),
      'cnic_status': p.cnicStatus,
      'licence_status': p.licenceStatus == 'none'
          ? 'none'
          : (p.licenceVerified ? 'verified' : 'pending'),
      'gaari_status': p.vehiclePapers,
      'wallet_balance': p.walletBalance,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  /// Master ne driver ko ACTIVE kiya hai ya nahi — app khulne par aur
  /// Profile ki refresh dabane par pull hota hai.
  static Future<void> refreshDriverStatus(AppStore store) async {
    if (store.driverId.isEmpty) return;
    final data = await _get(
        'drivers?select=active&id=eq.${Uri.encodeComponent(store.driverId)}');
    if (data is! List || data.isEmpty) return;
    final row = data.first;
    if (row is Map) {
      store.setMasterActive(row['active'] == true);
    }
  }

  // --- Store hooks → backend rows ---------------------------------------------

  static void _onHook(String kind, Object? payload) {
    final store = _store;
    if (store == null) return;
    switch (kind) {
      case 'booking':
        if (payload is Booking) unawaited(_pushRide(store, payload));
        break;
      case 'package':
        if (payload is MonthlyPackage) unawaited(_pushPackage(store, payload));
        break;
      case 'txn':
        if (payload is WalletTxn) unawaited(_pushLedger(store, payload));
        break;
      case 'profile':
        unawaited(_pushDriver(store));
        break;
      case 'selfie':
        if (payload is String) unawaited(_pushSelfie(store, payload));
        break;
    }
  }

  static Future<void> _pushRide(AppStore store, Booking b) async {
    await _upsert('rides', {
      'id': b.id,
      // Booking sirf passenger banata hai; driver tab jodta hai jab
      // is phone ke driver ne use qubool kiya ho.
      'driver_id':
          (b.status == 'pending' || b.status == 'cancelled')
              ? ''
              : store.driverId,
      'passenger_name': b.passengerName,
      'passenger_mobile': b.passengerPhone,
      'pickup': b.pickupLabel,
      'drop_off': b.dropLabel,
      'vehicle': b.vehicle,
      'km': b.distanceKm,
      'waiting_minutes': b.waitingMinutes,
      'fare': b.fare,
      'waiting_charges': b.waitingCharge,
      'fee': b.status == 'completed'
          ? Fares.serviceFee(b.fare + b.waitingCharge)
          : 0,
      'status': b.status,
      'date': b.createdAt.toUtc().toIso8601String(),
    });
  }

  static Future<void> _pushPackage(AppStore store, MonthlyPackage p) async {
    await _upsert('packages', {
      'id': p.id,
      'driver_id': '',
      'customer_name': p.passengerName,
      'customer_mobile': '',
      'pickup': p.pickup,
      'drop_off': p.drop,
      'vehicle': p.vehicle,
      'km': p.routeKm,
      'days': p.days,
      'amount': p.monthlyAmount,
      'fee': Fares.serviceFee(p.monthlyAmount),
      'date': p.createdAt.toUtc().toIso8601String(),
    });
  }

  static Future<void> _pushLedger(AppStore store, WalletTxn t) async {
    // Schema ke ledger mein balance ka column NAHI hai — is liye
    // balance-after note ke aakhir mein likha jata hai. Deposit
    // positive, service-charges ki katauti negative jati hai taaki
    // Master mein kul hisaab seedha jumla ho sake.
    await _upsert('ledger', {
      'id': t.id,
      'ts': t.date.toUtc().toIso8601String(),
      'type': t.type,
      'driver_id': store.driverId,
      'amount': t.type == 'fee' ? -t.amount : t.amount,
      'note': '${t.note} · Balance: ${rs(store.profile.walletBalance)}',
    });
  }

  /// driver_selfies schema mein tasveer ka column hai hi nahi — sirf
  /// (driver_id, date, done) ki CHECK row hai, wohi darj hoti hai.
  /// Asal selfie photo phone par hi rehti hai (profile.selfiePath).
  static Future<void> _pushSelfie(AppStore store, String date) async {
    if (store.driverId.isEmpty || date.isEmpty) return;
    await _upsert('driver_selfies', {
      'driver_id': store.driverId,
      'date': date,
      'done': true,
    });
  }
}
