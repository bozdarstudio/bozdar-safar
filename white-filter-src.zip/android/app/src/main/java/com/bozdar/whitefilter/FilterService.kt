package com.bozdar.whitefilter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.SegmentationMask
import com.google.mlkit.vision.segmentation.Segmenter
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Foreground service that:
 *  1. Holds the MediaProjection granted by the user.
 *  2. Mirrors the screen into an ImageReader at reduced resolution (~480px wide).
 *  3. Runs ML Kit selfie/person segmentation on throttled frames (~10 fps,
 *     frames dropped while busy).
 *  4. Shows a full-screen, touch-transparent overlay that paints solid white
 *     over every detected person, head to toe.
 */
class FilterService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var segmenter: Segmenter? = null
    private var overlayView: OverlayView? = null
    private var windowManager: WindowManager? = null

    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null
    private var mlExecutor: ExecutorService? = null

    @Volatile
    private var busy = false

    @Volatile
    private var lastFrameNs = 0L

    // Reused pixel buffer for mask conversion (recreated only if size changes).
    private var pixelBuffer: IntArray? = null

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            // System/user revoked the projection — shut everything down.
            stopFiltering()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopFiltering()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                if (isRunning) return START_STICKY
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                if (data == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startFiltering(resultCode, data)
                return START_STICKY
            }
            else -> {
                stopSelf()
                return START_NOT_STICKY
            }
        }
    }

    private fun startFiltering(resultCode: Int, data: Intent) {
        // Foreground first (Android 14 requires the mediaProjection type to be
        // declared and passed here before the projection is used).
        startForegroundWithNotification()

        backgroundThread = HandlerThread("WhiteFilterCapture").apply { start() }
        backgroundHandler = Handler(backgroundThread!!.looper)
        mlExecutor = Executors.newSingleThreadExecutor()

        try {
            val projectionManager =
                getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = projectionManager.getMediaProjection(resultCode, data)
            mediaProjection = projection
            // A callback must be registered before createVirtualDisplay (Android 14).
            projection.registerCallback(projectionCallback, backgroundHandler)

            // Capture at reduced resolution to save battery: max ~480px wide.
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager = getSystemService(WindowManager::class.java)
            @Suppress("DEPRECATION")
            windowManager!!.defaultDisplay.getRealMetrics(metrics)
            val fullWidth = metrics.widthPixels
            val fullHeight = metrics.heightPixels
            val scale = if (fullWidth > MAX_CAPTURE_WIDTH) {
                MAX_CAPTURE_WIDTH.toFloat() / fullWidth.toFloat()
            } else {
                1f
            }
            var capWidth = (fullWidth * scale).toInt()
            var capHeight = (fullHeight * scale).toInt()
            if (capWidth % 2 == 1) capWidth -= 1
            if (capHeight % 2 == 1) capHeight -= 1
            if (capWidth <= 0 || capHeight <= 0) {
                stopFiltering()
                return
            }

            val reader = ImageReader.newInstance(
                capWidth, capHeight, PixelFormat.RGBA_8888, 2
            )
            imageReader = reader
            reader.setOnImageAvailableListener({ r -> handleReaderImage(r) }, backgroundHandler)

            val displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            virtualDisplay = projection.createVirtualDisplay(
                "WhiteFilter",
                capWidth,
                capHeight,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface,
                null,
                backgroundHandler
            )

            val options = SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.STREAM_MODE)
                .build()
            segmenter = Segmentation.getClient(options)

            createOverlay()
            isRunning = true
        } catch (e: Exception) {
            stopFiltering()
        }
    }

    private fun createOverlay() {
        val wm = windowManager ?: getSystemService(WindowManager::class.java).also {
            windowManager = it
        }
        val view = OverlayView(this)
        overlayView = view
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        wm.addView(view, params)
    }

    private fun handleReaderImage(reader: ImageReader) {
        var image: Image? = null
        try {
            image = reader.acquireLatestImage() ?: return
            val now = System.nanoTime()
            if (busy || now - lastFrameNs < FRAME_INTERVAL_NS) {
                return
            }
            val seg = segmenter ?: return
            val bitmap = imageToBitmap(image) ?: return
            busy = true
            lastFrameNs = now
            try {
                val inputImage = InputImage.fromBitmap(bitmap, 0)
                seg.process(inputImage)
                    .addOnSuccessListener(mlExecutor!!) { mask -> onMaskReady(mask) }
                    .addOnCompleteListener(mlExecutor!!) {
                        busy = false
                        if (!bitmap.isRecycled) bitmap.recycle()
                    }
            } catch (e: Exception) {
                busy = false
                if (!bitmap.isRecycled) bitmap.recycle()
            }
        } catch (e: Exception) {
            // Reader may be closed during shutdown — ignore.
        } finally {
            try {
                image?.close()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    /** Convert an RGBA_8888 Image to a Bitmap, cropping row-stride padding. */
    private fun imageToBitmap(image: Image): Bitmap? {
        val planes = image.planes
        if (planes == null || planes.isEmpty()) return null
        val plane = planes[0]
        val pixelStride = plane.pixelStride
        if (pixelStride <= 0) return null
        val rowStride = plane.rowStride
        val width = image.width
        val height = image.height
        val rowPadding = rowStride - pixelStride * width
        if (rowPadding < 0) return null
        val paddedWidth = width + rowPadding / pixelStride
        val buffer = plane.buffer
        buffer.rewind()
        val full = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(buffer)
        if (paddedWidth == width) return full
        val cropped = Bitmap.createBitmap(full, 0, 0, width, height)
        full.recycle()
        return cropped
    }

    /**
     * ML Kit selfie segmentation mask: the buffer holds one float per pixel
     * (row-major), the foreground (person) confidence in [0.0, 1.0].
     * Pixels above the threshold become solid white; the rest stay transparent.
     */
    private fun onMaskReady(mask: SegmentationMask) {
        val w = mask.width
        val h = mask.height
        if (w <= 0 || h <= 0) return
        val total = w * h
        var pixels = pixelBuffer
        if (pixels == null || pixels.size != total) {
            pixels = IntArray(total)
            pixelBuffer = pixels
        }
        val buffer = mask.buffer
        buffer.rewind()
        val available = buffer.remaining() / 4
        val count = if (available < total) available else total
        var i = 0
        while (i < count) {
            val confidence = buffer.getFloat()
            pixels[i] = if (confidence > MASK_THRESHOLD) WHITE else TRANSPARENT
            i++
        }
        while (i < total) {
            pixels[i] = TRANSPARENT
            i++
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, w, 0, 0, w, h)
        overlayView?.updateMask(bmp)
    }

    private fun startForegroundWithNotification() {
        val channelId = "white_filter_running"
        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            channelId,
            "White Filter",
            NotificationManager.IMPORTANCE_LOW
        )
        notificationManager.createNotificationChannel(channel)

        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FilterService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("White Filter chalu hai")
            .setContentText("Log safed nazar aayenge")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    android.R.drawable.ic_menu_close_clear_cancel,
                    "Band karein",
                    stopIntent
                ).build()
            )
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun stopFiltering() {
        isRunning = false
        try {
            overlayView?.let { view ->
                try {
                    windowManager?.removeView(view)
                } catch (e: Exception) {
                    // view not attached
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        overlayView = null

        try {
            virtualDisplay?.release()
        } catch (e: Exception) {
            // ignore
        }
        virtualDisplay = null

        try {
            imageReader?.close()
        } catch (e: Exception) {
            // ignore
        }
        imageReader = null

        try {
            segmenter?.close()
        } catch (e: Exception) {
            // ignore
        }
        segmenter = null

        try {
            mediaProjection?.unregisterCallback(projectionCallback)
        } catch (e: Exception) {
            // ignore
        }
        try {
            mediaProjection?.stop()
        } catch (e: Exception) {
            // ignore
        }
        mediaProjection = null

        mlExecutor?.shutdown()
        mlExecutor = null

        backgroundThread?.quitSafely()
        backgroundThread = null
        backgroundHandler = null

        pixelBuffer = null

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (isRunning || mediaProjection != null || imageReader != null) {
            stopFiltering()
        }
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.bozdar.whitefilter.action.START"
        const val ACTION_STOP = "com.bozdar.whitefilter.action.STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        @Volatile
        var isRunning: Boolean = false

        private const val NOTIFICATION_ID = 42
        private const val MAX_CAPTURE_WIDTH = 480
        private const val FRAME_INTERVAL_NS = 100_000_000L // ~10 fps
        private const val MASK_THRESHOLD = 0.5f
        private const val WHITE = -1 // 0xFFFFFFFF
        private const val TRANSPARENT = 0 // 0x00000000
    }
}
