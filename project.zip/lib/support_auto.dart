import 'lang.dart';
import 'store.dart';

/// SUPPORT AUTO-JAWAB (v1.4.7, spec §4 — malik ke tayyar jumle)।
///
/// Teen layers wala support: (1) APP ke ye khud-kar tayyar jawab —
/// koi AI nahi, koi credit nahi; (2) jahan driver/sawari phans
/// jaye wahan assistant khud Master ki taraf se baat karke masla
/// hal karta hai (owner ki saaf ijazat 2026-11-08 23:25); (3)
/// Master khud। Ye engine sirf PEHLI layer hai।
///
/// HUDOOD (malik ka lock): app koi PERSONAL detail NAHI batati —
/// na kisi ka number, na CNIC, na kisi aur ki maloomat। Apne
/// documents ki haalat jaisi APNI maloomat jaiz hai। Koi
/// ulti-seedhi baat nahi। Badtameezi par pehle WARNING — block ka
/// faisla Master ke paas rehta hai।
///
/// Har auto jawab `messages` table mein sender_role='auto' ke
/// saath jata hai taaki Master ko bhi nazar aye ke app ne kya
/// jawab diya — koi baat Master se chhupi nahi rehti।
class SupportAuto {
  /// Har support thread ka PEHLA khud-kar message (malik ka final
  /// jumla, 2026-11-08 23:24)। v1.4.34 (P-2): jumla ab tr() se ata
  /// hai — Urdu pasand par lafz-ba-lafz wohi malik wala jumla,
  /// English pasand par usi ka tarjuma।
  static String get greeting => tr('sup_greeting');

  /// Pehle message par tasalli wala jawab।
  static String get ack => tr('sup_ack');

  /// Badtameezi par warning (malik ka final jumla)।
  static String get warningLine => tr('sup_warning');

  static const String _senderName = 'Bozdar Safar (Auto)';

  /// Badtameezi ki pehchan — Roman Urdu + Urdu script ke aam
  /// alfaz। Ye sirf WARNING ke liye hai; block Master karta hai।
  static const List<String> _abuseWords = [
    'gali', 'bakwas', 'bewakoof', 'bewaqoof', 'ullu', 'gadha',
    'kutta', 'kamina', 'harami', 'lanat', 'sharam karo', 'chor ho',
    'fraud hai', 'dhokha', 'بکواس', 'گالی', 'حرامی', 'کمینہ',
  ];

  static bool _hasAbuse(String body) {
    final b = body.toLowerCase();
    return _abuseWords.any((w) => b.contains(w));
  }

  static bool _hit(String body, List<String> words) {
    final b = body.toLowerCase();
    return words.any((w) => b.contains(w));
  }

  /// Ek auto jawab thread mein darj karna — MasterMessage ki
  /// aam shakal mein (hook se backend push khud ho jata hai)।
  static Future<void> _post(
    AppStore store,
    MasterMessage userMsg,
    String body, {
    DateTime? at,
    String category = 'Auto Jawab',
  }) async {
    await store.addMasterMessage(MasterMessage(
      id: store.newId(),
      senderKey: userMsg.senderKey,
      senderRole: 'auto',
      senderName: _senderName,
      senderMobile: userMsg.senderMobile,
      senderZone: userMsg.senderZone,
      category: category,
      body: body,
      isRead: true,
      createdAt: at ?? DateTime.now(),
    ));
  }

  static String _statusUrdu(String s) => switch (s) {
        'verified' => tr('sup_st_verified'),
        'rejected' => tr('sup_st_rejected'),
        'pending' => tr('sup_st_pending'),
        _ => tr('sup_st_unknown'),
      };

  /// Driver ke apne documents ki haalat wala tayyar jawab —
  /// reject par WAJAH ke saath (spec §4)। Ye driver ki APNI
  /// maloomat hai, kisi aur ki nahi — hudood ke andar hai।
  static String _docStatusAnswer(AppStore store) {
    final p = store.profile;
    final buf = StringBuffer('${tr('sup_doc_header')}\n');
    buf.writeln('• CNIC: ${_statusUrdu(p.masterCnicStatus)}');
    if (p.masterCnicStatus == 'rejected' && p.masterCnicReason.isNotEmpty) {
      buf.writeln('${tr('sup_doc_reason')}${p.masterCnicReason}');
    }
    buf.writeln('• ${tr('sup_doc_gaari')}: ${_statusUrdu(p.masterGaariStatus)}');
    if (p.masterGaariStatus == 'rejected' && p.masterGaariReason.isNotEmpty) {
      buf.writeln('${tr('sup_doc_reason')}${p.masterGaariReason}');
    }
    buf.writeln('• ${tr('sup_doc_licence')}: ${_statusUrdu(p.masterLicenceStatus)}');
    if (p.masterLicenceStatus == 'rejected' &&
        p.masterLicenceReason.isNotEmpty) {
      buf.writeln('${tr('sup_doc_reason')}${p.masterLicenceReason}');
    }
    // v1.4.19 SAKHT GATE: teeno naye lazmi kagaz bhi jawab mein —
    // reject par wajah + woh rehnumai bhi jo kagaz poora karne
    // ka rasta dikhati hai (malik ka hukm 2026-11-10 ~18:12)।
    buf.writeln(
        '• Fitness Certificate: ${_statusUrdu(p.masterFitnessStatus)}');
    if (p.masterFitnessStatus == 'rejected' &&
        p.masterFitnessReason.isNotEmpty) {
      buf.writeln('${tr('sup_doc_reason')}${p.masterFitnessReason}');
    }
    if (p.masterFitnessStatus != 'verified') {
      buf.writeln('  ${tr('rehnumai_fitness')}');
    }
    buf.writeln(
        '• ${tr('sup_doc_insurance')}: ${_statusUrdu(p.masterInsuranceStatus)}');
    if (p.masterInsuranceStatus == 'rejected' &&
        p.masterInsuranceReason.isNotEmpty) {
      buf.writeln('${tr('sup_doc_reason')}${p.masterInsuranceReason}');
    }
    if (p.masterInsuranceStatus != 'verified') {
      buf.writeln('  ${tr('rehnumai_insurance')}');
    }
    buf.writeln(
        '• Police Character Certificate: ${_statusUrdu(p.masterCharacterStatus)}');
    if (p.masterCharacterStatus == 'rejected' &&
        p.masterCharacterReason.isNotEmpty) {
      buf.writeln('${tr('sup_doc_reason')}${p.masterCharacterReason}');
    }
    if (p.masterCharacterStatus != 'verified') {
      buf.writeln('  ${tr('rehnumai_character')}');
    }
    buf.write(tr('sup_doc_footer'));
    return buf.toString();
  }

  /// Aam sawalon ke tayyar jawab — pehchan body ke alfaz se।
  /// Jawab na mile to null (us surat mein sirf greeting/ack jata
  /// hai aur baat Master/assistant par rehti hai)।
  static String? _faqAnswer(AppStore store, MasterMessage m) {
    final b = m.body;
    final isDriver = m.senderRole == 'driver';

    if (_hit(b, ['sos', 'madad karo', 'emergency', 'accident', 'hadsa'])) {
      // v1.4.25 (postmortem #7): pehle yahan jhoota dawa tha ke
      // "Master ko alert FORAN bhej diya gaya" — asal mein koi
      // fori alert nahi jata; ye message Master ke INBOX mein
      // jata hai aur woh app kholne par dekhta hai. Ab wohi
      // likha hai jo asal hai, aur asal emergency ka pehla
      // qadam (1122) sab se pehle bataya jata hai।
      return tr('sup_faq_emergency');
    }
    if (_hit(b, ['rate', 'kiraya', 'rent', 'per km', 'charge kya', 'ریٹ', 'کرایہ'])) {
      return trf('sup_faq_rates', {
        'bike': '${Fares.perKm['Bike']}',
        'rickshaw': '${Fares.perKm['Rickshaw']}',
        'car': '${Fares.perKm['Car']}',
        'taxi': '${Fares.perKm['Taxi']}',
        'van': '${Fares.perKm['Van']}',
        'free_min': '${Fares.freeWaitingMinutes}',
        'w_bike': '${Fares.waitingPerMin['Bike']}',
        'w_rickshaw': '${Fares.waitingPerMin['Rickshaw']}',
        'w_car': '${Fares.waitingPerMin['Car']}',
        'w_taxi': '${Fares.waitingPerMin['Taxi']}',
        'w_van': '${Fares.waitingPerMin['Van']}',
        'min_fare': '${Fares.minFareRs}',
      });
    }
    if (_hit(b, ['fee', 'commission', 'tax', 'percent', 'katoti', 'فی', 'کمیشن'])) {
      return isDriver
          ? trf('sup_faq_fee_driver', {
              'fee': Fares.feePercent.toStringAsFixed(0),
              'deposit': '${Fares.joiningDeposit}',
            })
          : trf('sup_faq_fee_passenger', {
              'min_fare': '${Fares.minFareRs}',
              'free_min': '${Fares.freeWaitingMinutes}',
            });
    }
    if (_hit(b, ['password', 'bhool gaya', 'bhool gaye', 'login nahi', 'پاس ورڈ'])) {
      return tr('sup_faq_password');
    }
    if (_hit(b, ['deposit', 'jama', 'ڈپازٹ'])) {
      return trf('sup_faq_deposit', {
        'deposit': '${Fares.joiningDeposit}',
        'fee': Fares.feePercent.toStringAsFixed(0),
      });
    }
    if (_hit(b, ['tasdeeq', 'document', 'kagaz', 'kaghaz', 'reject', 'status kya', 'تصدیق', 'کاغذ'])) {
      if (isDriver) return _docStatusAnswer(store);
      return tr('sup_faq_docs_passenger');
    }
    if (_hit(b, ['registration', 'register', 'id bane', 'id banani', 'driver banna', 'رجسٹریشن'])) {
      return tr('sup_faq_registration');
    }
    if (_hit(b, ['shikayat', 'complaint', 'شکایت']) ||
        m.category == 'Driver ki shikayat' ||
        m.category == 'Sawari ki shikayat') {
      return tr('sup_faq_complaint');
    }
    if (_hit(b, ['email', 'gmail', 'otp', 'code nahi aya', 'ای میل'])) {
      return tr('sup_faq_email');
    }
    if (isDriver &&
        _hit(b, ['gaari change', 'gari change', 'gaari badal', 'gari badal', 'plate change'])) {
      return tr('sup_faq_vehicle_change');
    }
    return null;
  }

  /// User ka message jane ke baad engine chalti hai — tartib:
  /// (1) pehli dafa ho to GREETING (us message se ek second pehle
  /// ki muddat par, taaki thread mein sab se pehle dikhe),
  /// (2) pehle message par ACK tasalli,
  /// (3) badtameezi par WARNING,
  /// (4) aam sawal ho to FAQ ka tayyar jawab।
  /// Engine kabhi exception nahi phenkti — support baat is par
  /// kabhi nahi rukti।
  static Future<void> onUserMessage(AppStore store, MasterMessage m) async {
    try {
      final key = m.senderKey;
      final threadMine = store.masterMessages
          .where((x) =>
              x.senderKey == key &&
              (x.senderRole == 'driver' || x.senderRole == 'passenger'))
          .length;
      final isFirst = threadMine <= 1;

      if (!store.supportGreetedKeys.contains(key)) {
        // Set pehle badlo — _post ke addMasterMessage ka _persist
        // isay bhi mehfooz kar dega (alag save ki zaroorat nahi)।
        store.supportGreetedKeys.add(key);
        await _post(store, m, greeting,
            at: m.createdAt.subtract(const Duration(seconds: 1)));
      }
      if (isFirst) {
        await _post(store, m, ack);
      }
      if (_hasAbuse(m.body)) {
        store.supportWarnCount += 1;
        await _post(
          store,
          m,
          store.supportWarnCount > 1
              ? trf('sup_warning_repeat', {'n': '${store.supportWarnCount}'})
              : warningLine,
          category: 'Auto Warning',
        );
        return; // Badtameezi wale message par FAQ jawab nahi jata।
      }
      final faq = _faqAnswer(store, m);
      if (faq != null) {
        await _post(store, m, faq);
      }
    } catch (_) {
      // Auto jawab na bane to bhi asal message Master tak gaya
      // hai — engine khamoshi se peeche hat jati hai।
    }
  }
}
