// v1.4.80 / v1.4.65 LIVE DARK MAP (malik ka hukm
// 2026-11-24 — reference video wala gehra live map):
// dono apps ka streets map ab HAR waqt yehi gehra map
// hai — Din/Raat ki pasand se map NAHI badalta (pasand
// ab sirf app ke theme ke liye hai; safar_map.dart ka
// _styleFor dekhein)। Shakal mashhoor driver apps ke
// dark map jaisi: gehra pas-manzar, roshan sadkein,
// saaf naam — aur bilkul LIVE asal tiles, koi static
// tasveer NAHI।
//
// Basemap: Esri World Dark Gray Base RASTER tiles
// (server.arcgisonline.com — wohi muft, bina-API-key
// wala khandaan jo is app ka satellite style pehle se
// istemal karta hai; har tile ek tasveer hai, kamzor
// net par bhi hisso mein foran load hoti hai — v1.4.59
// wala usool barkarar)।
// CARTO RASTER tiles istemal NAHI hue — jaanch mein
// un par "API KEY REQUIRED" ka watermark aya (parent
// ki 2026-11-16 wali jaanch 2026-11-24 ko dobara
// tasdeeq hui)। CARTO VECTOR (Dark Matter GL style)
// bhi NAHI — v1.4.59 ka tajurba: kamzor mobile net
// par vector data pohanchta hi nahi tha, map khaali
// reh jata tha।
// NAAM (jagah + sadak): din/raat styles wali wohi
// LABELS-ONLY CARTO vector overlay (source "carto") —
// halka saaf text (#f4f4ee) + gehra halo, gehre map
// par crystal-saaf। Geometry/fill vector se NAHI —
// sadkein Esri raster se hi ati hain (tez load)।
// App ke apne overlays (route, markers, A/B pin naam,
// demand heat) code se bante hain aur in ke UPAR
// rehte hain।
const String kLiveDarkStyleJson = r'''{
  "version": 8,
  "name": "Safar Live Dark",
  "metadata": {},
  "sources": {
    "esri-dark": {
      "type": "raster",
      "tiles": [
        "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}"
      ],
      "tileSize": 256,
      "maxzoom": 18,
      "attribution": "Esri, © OpenStreetMap contributors, © CARTO"
    },
    "carto": {
      "type": "vector",
      "tiles": [
        "https://tiles.basemaps.cartocdn.com/v/20261026-01/vectortiles/carto.streets/v2/{z}/{x}/{y}.mvt"
      ],
      "minzoom": 0,
      "maxzoom": 15,
      "attribution": "© OpenStreetMap contributors © CARTO"
    }
  },
  "sprite": "https://tiles.basemaps.cartocdn.com/v/20261026-01/gl/dark-matter-gl-style/sprite",
  "glyphs": "https://tiles.basemaps.cartocdn.com/v/20261026-01/fonts/{fontstack}/{range}.pbf",
  "layers": [
    {
      "id": "safar-bg",
      "type": "background",
      "paint": {
        "background-color": "#17191d"
      }
    },
    {
      "id": "esri-dark",
      "type": "raster",
      "source": "esri-dark"
    },
    {
      "id": "place_hamlet",
      "type": "symbol",
      "source": "carto",
      "source-layer": "places",
      "minzoom": 12,
      "maxzoom": 16,
      "layout": {
        "text-field": [
          "step",
          [
            "zoom"
          ],
          [
            "coalesce",
            [
              "get",
              "name:en"
            ],
            [
              "case",
              [
                "has",
                "name3"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ],
                " ",
                [
                  "get",
                  "name3"
                ]
              ],
              [
                "has",
                "name2"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ]
              ],
              [
                "get",
                "name"
              ]
            ]
          ],
          14,
          [
            "case",
            [
              "has",
              "name3"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ],
              " ",
              [
                "get",
                "name3"
              ]
            ],
            [
              "has",
              "name2"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ]
            ],
            [
              "get",
              "name"
            ]
          ]
        ],
        "text-font": [
          "Montserrat Medium",
          "Open Sans Regular",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              13,
              9.6
            ],
            [
              14,
              12.0
            ],
            [
              16,
              13.2
            ]
          ]
        },
        "text-anchor": "center",
        "text-max-width": 10,
        "text-keep-upright": true,
        "text-offset": [
          0.2,
          0.2
        ],
        "text-transform": {
          "stops": [
            [
              12,
              "none"
            ],
            [
              14,
              "uppercase"
            ]
          ]
        },
        "symbol-sort-key": [
          "-",
          [
            "*",
            [
              "coalesce",
              [
                "get",
                "min_zoom"
              ],
              20
            ],
            100
          ],
          [
            "coalesce",
            [
              "get",
              "population_rank"
            ],
            0
          ]
        ]
      },
      "paint": {
        "text-color": "#f4f4ee",
        "text-halo-color": "rgba(5,10,18,0.9)",
        "text-halo-width": 2
      },
      "filter": [
        "any",
        [
          "all",
          [
            "all",
            [
              "==",
              [
                "get",
                "kind"
              ],
              "neighbourhood"
            ],
            [
              "==",
              [
                "get",
                "kind_detail"
              ],
              "neighbourhood"
            ]
          ],
          [
            ">=",
            [
              "zoom"
            ],
            14
          ]
        ],
        [
          "all",
          [
            "==",
            [
              "get",
              "kind"
            ],
            "locality"
          ],
          [
            "==",
            [
              "get",
              "kind_detail"
            ],
            "hamlet"
          ]
        ]
      ]
    },
    {
      "id": "place_suburbs",
      "type": "symbol",
      "source": "carto",
      "source-layer": "places",
      "minzoom": 12,
      "maxzoom": 16,
      "layout": {
        "text-field": [
          "step",
          [
            "zoom"
          ],
          [
            "coalesce",
            [
              "get",
              "name:en"
            ],
            [
              "case",
              [
                "has",
                "name3"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ],
                " ",
                [
                  "get",
                  "name3"
                ]
              ],
              [
                "has",
                "name2"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ]
              ],
              [
                "get",
                "name"
              ]
            ]
          ],
          13,
          [
            "case",
            [
              "has",
              "name3"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ],
              " ",
              [
                "get",
                "name3"
              ]
            ],
            [
              "has",
              "name2"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ]
            ],
            [
              "get",
              "name"
            ]
          ]
        ],
        "text-font": [
          "Montserrat Medium",
          "Open Sans Regular",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              12,
              10.8
            ],
            [
              13,
              12.0
            ],
            [
              14,
              13.2
            ],
            [
              15,
              14.4
            ],
            [
              16,
              15.6
            ]
          ]
        },
        "text-anchor": "center",
        "text-max-width": 10,
        "text-keep-upright": true,
        "text-offset": [
          0.2,
          0.2
        ],
        "text-transform": {
          "stops": [
            [
              8,
              "none"
            ],
            [
              12,
              "uppercase"
            ]
          ]
        },
        "symbol-sort-key": [
          "-",
          [
            "*",
            [
              "coalesce",
              [
                "get",
                "min_zoom"
              ],
              20
            ],
            100
          ],
          [
            "coalesce",
            [
              "get",
              "population_rank"
            ],
            0
          ]
        ]
      },
      "paint": {
        "text-color": "#f4f4ee",
        "text-halo-color": "rgba(5,10,18,0.9)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "==",
          [
            "get",
            "kind"
          ],
          "neighbourhood"
        ],
        [
          "==",
          [
            "get",
            "kind_detail"
          ],
          "suburb"
        ]
      ]
    },
    {
      "id": "place_villages",
      "type": "symbol",
      "source": "carto",
      "source-layer": "places",
      "minzoom": 10,
      "maxzoom": 16,
      "layout": {
        "text-field": [
          "step",
          [
            "zoom"
          ],
          [
            "coalesce",
            [
              "get",
              "name:en"
            ],
            [
              "case",
              [
                "has",
                "name3"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ],
                " ",
                [
                  "get",
                  "name3"
                ]
              ],
              [
                "has",
                "name2"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ]
              ],
              [
                "get",
                "name"
              ]
            ]
          ],
          13,
          [
            "case",
            [
              "has",
              "name3"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ],
              " ",
              [
                "get",
                "name3"
              ]
            ],
            [
              "has",
              "name2"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ]
            ],
            [
              "get",
              "name"
            ]
          ]
        ],
        "text-font": [
          "Montserrat SemiBold",
          "Open Sans Bold",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              10,
              10.8
            ],
            [
              12,
              12.0
            ],
            [
              13,
              13.2
            ],
            [
              14,
              14.4
            ],
            [
              16,
              15.6
            ]
          ]
        },
        "text-anchor": "center",
        "text-max-width": 10,
        "text-keep-upright": true,
        "text-offset": [
          0.2,
          0.2
        ],
        "text-transform": "none",
        "symbol-sort-key": [
          "-",
          [
            "*",
            [
              "coalesce",
              [
                "get",
                "min_zoom"
              ],
              20
            ],
            100
          ],
          [
            "coalesce",
            [
              "get",
              "population_rank"
            ],
            0
          ]
        ]
      },
      "paint": {
        "text-color": "#f4f4ee",
        "text-halo-color": "rgba(5,10,18,0.9)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "==",
          [
            "get",
            "kind"
          ],
          "locality"
        ],
        [
          "==",
          [
            "get",
            "kind_detail"
          ],
          "village"
        ]
      ]
    },
    {
      "id": "place_town",
      "type": "symbol",
      "source": "carto",
      "source-layer": "places",
      "minzoom": 10,
      "maxzoom": 14,
      "layout": {
        "text-field": [
          "step",
          [
            "zoom"
          ],
          [
            "coalesce",
            [
              "get",
              "name:en"
            ],
            [
              "case",
              [
                "has",
                "name3"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ],
                " ",
                [
                  "get",
                  "name3"
                ]
              ],
              [
                "has",
                "name2"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ]
              ],
              [
                "get",
                "name"
              ]
            ]
          ],
          13,
          [
            "case",
            [
              "has",
              "name3"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ],
              " ",
              [
                "get",
                "name3"
              ]
            ],
            [
              "has",
              "name2"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ]
            ],
            [
              "get",
              "name"
            ]
          ]
        ],
        "text-font": [
          "Montserrat SemiBold",
          "Open Sans Bold",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              8,
              12.0
            ],
            [
              9,
              12.0
            ],
            [
              10,
              13.2
            ],
            [
              13,
              16.8
            ],
            [
              14,
              18.0
            ]
          ]
        },
        "text-anchor": "center",
        "text-max-width": 10,
        "text-keep-upright": true,
        "text-offset": [
          0.2,
          0.2
        ],
        "text-transform": "none",
        "symbol-sort-key": [
          "-",
          [
            "*",
            [
              "coalesce",
              [
                "get",
                "min_zoom"
              ],
              20
            ],
            100
          ],
          [
            "coalesce",
            [
              "get",
              "population_rank"
            ],
            0
          ]
        ]
      },
      "paint": {
        "text-color": "#f4f4ee",
        "text-halo-color": "rgba(5,10,18,0.9)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "==",
          [
            "get",
            "kind"
          ],
          "locality"
        ],
        [
          "==",
          [
            "get",
            "kind_detail"
          ],
          "town"
        ]
      ]
    },
    {
      "id": "place_city_r6",
      "type": "symbol",
      "source": "carto",
      "source-layer": "places",
      "minzoom": 10,
      "maxzoom": 15,
      "layout": {
        "text-field": [
          "step",
          [
            "zoom"
          ],
          [
            "coalesce",
            [
              "get",
              "name:en"
            ],
            [
              "case",
              [
                "has",
                "name3"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ],
                " ",
                [
                  "get",
                  "name3"
                ]
              ],
              [
                "has",
                "name2"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ]
              ],
              [
                "get",
                "name"
              ]
            ]
          ],
          13,
          [
            "case",
            [
              "has",
              "name3"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ],
              " ",
              [
                "get",
                "name3"
              ]
            ],
            [
              "has",
              "name2"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ]
            ],
            [
              "get",
              "name"
            ]
          ]
        ],
        "text-font": [
          "Montserrat SemiBold",
          "Open Sans Bold",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              8,
              14.4
            ],
            [
              9,
              15.6
            ],
            [
              10,
              16.8
            ],
            [
              13,
              20.4
            ],
            [
              14,
              24.0
            ]
          ]
        },
        "text-anchor": "center",
        "text-max-width": 10,
        "text-keep-upright": true,
        "text-offset": [
          0.2,
          0.2
        ],
        "text-transform": "uppercase",
        "symbol-sort-key": [
          "-",
          [
            "*",
            [
              "coalesce",
              [
                "get",
                "min_zoom"
              ],
              20
            ],
            100
          ],
          [
            "coalesce",
            [
              "get",
              "population_rank"
            ],
            0
          ]
        ]
      },
      "paint": {
        "text-color": "#f4f4ee",
        "text-halo-color": "rgba(5,10,18,0.9)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "all",
          [
            "==",
            [
              "get",
              "kind"
            ],
            "locality"
          ],
          [
            "==",
            [
              "get",
              "kind_detail"
            ],
            "city"
          ]
        ],
        [
          ">=",
          [
            "coalesce",
            [
              "get",
              "min_zoom"
            ],
            0
          ],
          7
        ]
      ]
    },
    {
      "id": "place_city_r5",
      "type": "symbol",
      "source": "carto",
      "source-layer": "places",
      "minzoom": 10,
      "maxzoom": 15,
      "layout": {
        "text-field": [
          "step",
          [
            "zoom"
          ],
          [
            "coalesce",
            [
              "get",
              "name:en"
            ],
            [
              "case",
              [
                "has",
                "name3"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ],
                " ",
                [
                  "get",
                  "name3"
                ]
              ],
              [
                "has",
                "name2"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ]
              ],
              [
                "get",
                "name"
              ]
            ]
          ],
          13,
          [
            "case",
            [
              "has",
              "name3"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ],
              " ",
              [
                "get",
                "name3"
              ]
            ],
            [
              "has",
              "name2"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ]
            ],
            [
              "get",
              "name"
            ]
          ]
        ],
        "text-font": [
          "Montserrat SemiBold",
          "Open Sans Bold",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              8,
              16.8
            ],
            [
              10,
              19.2
            ],
            [
              13,
              22.8
            ],
            [
              14,
              26.4
            ]
          ]
        },
        "text-anchor": "center",
        "text-max-width": 10,
        "text-keep-upright": true,
        "text-offset": [
          0.2,
          0.2
        ],
        "text-transform": "uppercase",
        "symbol-sort-key": [
          "-",
          [
            "*",
            [
              "coalesce",
              [
                "get",
                "min_zoom"
              ],
              20
            ],
            100
          ],
          [
            "coalesce",
            [
              "get",
              "population_rank"
            ],
            0
          ]
        ]
      },
      "paint": {
        "text-color": "#f4f4ee",
        "text-halo-color": "rgba(5,10,18,0.9)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "all",
          [
            "==",
            [
              "get",
              "kind"
            ],
            "locality"
          ],
          [
            "==",
            [
              "get",
              "kind_detail"
            ],
            "city"
          ]
        ],
        [
          "<=",
          [
            "coalesce",
            [
              "get",
              "min_zoom"
            ],
            0
          ],
          6
        ]
      ]
    },
    {
      "id": "roadname_minor",
      "type": "symbol",
      "source": "carto",
      "source-layer": "roads",
      "minzoom": 16,
      "layout": {
        "symbol-placement": "line",
        "text-font": [
          "Montserrat Medium",
          "Open Sans Regular",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": 13.5,
        "text-field": [
          "case",
          [
            "has",
            "name3"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ],
            " ",
            [
              "get",
              "name3"
            ]
          ],
          [
            "has",
            "name2"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ]
          ],
          [
            "get",
            "name"
          ]
        ],
        "symbol-avoid-edges": false,
        "symbol-spacing": 200,
        "text-pitch-alignment": "auto",
        "text-rotation-alignment": "auto",
        "text-justify": "center"
      },
      "paint": {
        "text-color": "#f4f4ee",
        "text-halo-color": "rgba(5,10,18,0.9)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "has",
          "name"
        ],
        [
          "any",
          [
            "all",
            [
              "!",
              [
                "in",
                [
                  "get",
                  "kind"
                ],
                [
                  "literal",
                  [
                    "path",
                    "highway",
                    "major_road"
                  ]
                ]
              ]
            ],
            [
              "in",
              [
                "get",
                "kind_detail"
              ],
              [
                "literal",
                [
                  "residential",
                  "unclassified",
                  "living_street",
                  "road",
                  "alley",
                  "driveway",
                  "parking_aisle"
                ]
              ]
            ]
          ],
          [
            "==",
            [
              "get",
              "kind_detail"
            ],
            "service"
          ]
        ]
      ]
    },
    {
      "id": "roadname_sec",
      "type": "symbol",
      "source": "carto",
      "source-layer": "roads",
      "minzoom": 15,
      "layout": {
        "symbol-placement": "line",
        "text-font": [
          "Montserrat Medium",
          "Open Sans Regular",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              15,
              13.5
            ],
            [
              16,
              16.5
            ],
            [
              18,
              18.0
            ]
          ]
        },
        "text-field": [
          "case",
          [
            "has",
            "name3"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ],
            " ",
            [
              "get",
              "name3"
            ]
          ],
          [
            "has",
            "name2"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ]
          ],
          [
            "get",
            "name"
          ]
        ],
        "symbol-avoid-edges": false,
        "symbol-spacing": 200,
        "text-pitch-alignment": "auto",
        "text-rotation-alignment": "auto",
        "text-justify": "center"
      },
      "paint": {
        "text-color": "#f4f4ee",
        "text-halo-color": "rgba(5,10,18,0.9)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "has",
          "name"
        ],
        [
          "any",
          [
            "in",
            [
              "get",
              "kind_detail"
            ],
            [
              "literal",
              [
                "secondary",
                "tertiary",
                "secondary_link",
                "tertiary_link"
              ]
            ]
          ],
          [
            "all",
            [
              "all",
              [
                "in",
                [
                  "get",
                  "kind"
                ],
                [
                  "literal",
                  [
                    "highway",
                    "major_road"
                  ]
                ]
              ],
              [
                "!",
                [
                  "in",
                  [
                    "get",
                    "kind_detail"
                  ],
                  [
                    "literal",
                    [
                      "motorway",
                      "motorway_link",
                      "trunk",
                      "trunk_link",
                      "primary",
                      "primary_link",
                      "secondary",
                      "secondary_link",
                      "tertiary",
                      "tertiary_link"
                    ]
                  ]
                ]
              ]
            ],
            [
              "==",
              [
                "get",
                "kind"
              ],
              "major_road"
            ],
            [
              ">=",
              [
                "coalesce",
                [
                  "get",
                  "min_zoom"
                ],
                0
              ],
              9
            ]
          ]
        ]
      ]
    },
    {
      "id": "roadname_pri",
      "type": "symbol",
      "source": "carto",
      "source-layer": "roads",
      "minzoom": 14,
      "layout": {
        "symbol-placement": "line",
        "text-font": [
          "Montserrat Medium",
          "Open Sans Regular",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              14,
              15.0
            ],
            [
              15,
              15.0
            ],
            [
              16,
              16.5
            ],
            [
              18,
              18.0
            ]
          ]
        },
        "text-field": [
          "case",
          [
            "has",
            "name3"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ],
            " ",
            [
              "get",
              "name3"
            ]
          ],
          [
            "has",
            "name2"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ]
          ],
          [
            "get",
            "name"
          ]
        ],
        "symbol-avoid-edges": false,
        "symbol-spacing": {
          "stops": [
            [
              6,
              200
            ],
            [
              16,
              250
            ]
          ]
        },
        "text-pitch-alignment": "auto",
        "text-rotation-alignment": "auto",
        "text-justify": "center",
        "text-letter-spacing": {
          "stops": [
            [
              14,
              0
            ],
            [
              16,
              0.2
            ]
          ]
        }
      },
      "paint": {
        "text-color": "#f4f4ee",
        "text-halo-color": "rgba(5,10,18,0.9)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "has",
          "name"
        ],
        [
          "in",
          [
            "get",
            "kind_detail"
          ],
          [
            "literal",
            [
              "primary",
              "primary_link"
            ]
          ]
        ]
      ]
    },
    {
      "id": "roadname_major",
      "type": "symbol",
      "source": "carto",
      "source-layer": "roads",
      "minzoom": 14,
      "layout": {
        "symbol-placement": "line",
        "text-font": [
          "Montserrat Medium",
          "Open Sans Regular",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              14,
              15.0
            ],
            [
              15,
              15.0
            ],
            [
              16,
              16.5
            ],
            [
              18,
              18.0
            ]
          ]
        },
        "text-field": [
          "case",
          [
            "has",
            "name3"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ],
            " ",
            [
              "get",
              "name3"
            ]
          ],
          [
            "has",
            "name2"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ]
          ],
          [
            "get",
            "name"
          ]
        ],
        "symbol-avoid-edges": false,
        "symbol-spacing": {
          "stops": [
            [
              6,
              200
            ],
            [
              16,
              250
            ]
          ]
        },
        "text-pitch-alignment": "auto",
        "text-rotation-alignment": "auto",
        "text-justify": "center",
        "text-letter-spacing": {
          "stops": [
            [
              13,
              0
            ],
            [
              16,
              0.2
            ]
          ]
        }
      },
      "paint": {
        "text-color": "#f4f4ee",
        "text-halo-color": "rgba(5,10,18,0.9)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "has",
          "name"
        ],
        [
          "in",
          [
            "get",
            "kind_detail"
          ],
          [
            "literal",
            [
              "motorway",
              "trunk",
              "motorway_link",
              "trunk_link"
            ]
          ]
        ]
      ]
    }
  ]
}''';
