import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'backend.dart';
import 'duty_service.dart';
import 'store.dart';

/// v1.4.17 — FCM PUSH (Stage 1: app-side integration).
///
/// Usool (poora defensive — maujooda app ki tarah):
/// - Firebase initialize NA ho sakay (config na mile, service
///   band ho) to app BILKUL aam tareeqe se chalti hai — koi
///   crash, koi rukawat nahi. Duty-service wala foreground
///   ghanti-nizam (duty_service.dart) pehle ki tarah chalta
///   rehta hai; push us ke UPAR ek izafi tez rasta hai, us ki
///   jagah nahi.
/// - Foreground mein push aye to wohi purani local-notification
///   ghanti (DutyNotify — 'safar_alerts' channel) bajti hai;
///   koi naya plugin/channel nahi banaya gaya.
/// - Background/terminated par notification-wale message
///   Android khud tray mein dikhata hai (default channel ki
///   meta-data manifest mein 'safar_alerts' par hai); data-only
///   message par neeche wala background handler wohi ghanti
///   dikhata hai — duty wali ghanti se koi takrao nahi (notification
///   id 'push:' prefix se alag banti hai).
/// - Token devices row par jata hai (Backend.updateDeviceFcmToken);
///   server par fcm_token column abhi na ho to khamosh fail —
///   agli token-refresh/startup par dobara koshish hoti hai.
/// - Push BHEJNA Backend.invokePush se hota hai (Edge Function
///   'send-push'); function abhi deploy nahi hua — call khamoshi
///   se fail hoti hai aur polling wala purana rasta barkarar hai.

/// FCM background handler — top-level + vm:entry-point lazmi
/// (ye function ek ALAG isolate mein chalta hai; is liye Firebase
/// yahan dobara initialize hota hai, woh bhi guarded)।
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  try {
    await Firebase.initializeApp();
  } catch (_) {
    // Firebase is isolate mein na ban sakay to push isi dafa
    // khamosh guzar jaye ga — app/service par koi asar nahi.
    return;
  }
  await PushNotify.showFromMessage(message, fromBackgroundHandler: true);
}

/// Push ko DutyNotify ki ghanti mein badalna — main isolate
/// (foreground) aur background isolate dono yahin se jate hain.
class PushNotify {
  static Future<void> showFromMessage(
    RemoteMessage message, {
    bool fromBackgroundHandler = false,
  }) async {
    try {
      final n = message.notification;
      // Background handler mein notification-wala message
      // Android pehle hi tray mein dikha chuka hota hai — yahan
      // dobara dikhana double ghanti hogi. Wahan sirf data-only
      // message par ghanti bajti hai.
      if (fromBackgroundHandler && n != null) return;
      var title = n?.title ?? message.data['title']?.toString() ?? '';
      var body = n?.body ?? message.data['body']?.toString() ?? '';
      if (title.isEmpty && body.isEmpty) {
        // Sirf data (masalan sirf ride_id) — duty_drivers wala
        // aam elan; koi pehchan wala data na ho to khamosh.
        if (message.data['ride_id'] == null) return;
        title = 'Nayi ride aayi hai';
        body = 'Pool mein nayi ride hai — app khol kar dekhein.';
      }
      final key = message.messageId ??
          message.data['ride_id']?.toString() ??
          '$title|$body';
      await DutyNotify.show(DutyNotify.idFor('push:$key'), title, body);
    } catch (_) {
      // Ghanti na baje to bhi kuch nahi rukta — duty service
      // aur polling apna kaam karte rehte hain.
    }
  }
}

/// Push ki bunyaad — main.dart se store load hone ke BAAD ek
/// dafa (Backend.start ke saath) bulaya jata hai. Har qadam
/// guarded hai; koi bhi nakami app ke aam rawaiye ko NAHI
/// badalti.
class PushService {
  static bool _inited = false;

  static Future<void> init(AppStore store) async {
    if (_inited) return;
    _inited = true;
    try {
      await Firebase.initializeApp();
    } catch (_) {
      // Firebase NAHI bana — baqi sab skip; app purane
      // duty-service/polling nizam par bilkul normal chalegi.
      return;
    }
    try {
      FirebaseMessaging.onBackgroundMessage(
          firebaseMessagingBackgroundHandler);
    } catch (_) {}
    final fm = FirebaseMessaging.instance;
    // Android 13+ POST_NOTIFICATIONS — maujooda permission
    // rawaiye ke saath: ek dafa maanga jata hai, jawab jo bhi
    // ho app aage barhti hai (zabardasti nahi; duty flow wala
    // ensureNotificationPermission apni jagah barkarar hai)।
    try {
      await fm.requestPermission();
    } catch (_) {}
    // Foreground push → wohi purani ghanti (DutyNotify)।
    FirebaseMessaging.onMessage.listen((message) {
      unawaited(PushNotify.showFromMessage(message));
    });
    // Token → backend devices row (guarded upsert; column na
    // ho to khamosh)।
    try {
      final token = await fm.getToken();
      if (token != null && token.isNotEmpty) {
        await Backend.updateDeviceFcmToken(store.deviceId, token);
      }
    } catch (_) {}
    // Token badle (app dobara install / Firebase ki rotation)
    // to naya token bhi usi rasta se mehfooz ho jaye।
    try {
      fm.onTokenRefresh.listen((token) {
        if (token.isEmpty) return;
        unawaited(Backend.updateDeviceFcmToken(store.deviceId, token));
      });
    } catch (_) {}
  }
}
