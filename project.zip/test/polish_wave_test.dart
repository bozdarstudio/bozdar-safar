// v1.4.27 — POLISH WAVE ke tests: pool sarhadein (#16 — vehicle/
// zone/doori ka khalis hisaab), route cache expiry (#23) aur
// notification-tap ride signal (#23)।
import 'package:flutter_test/flutter_test.dart';
import 'package:safar/pool_filter.dart';
import 'package:safar/route_service.dart';
import 'package:safar/store.dart';

Booking _ride({
  String vehicle = 'Rickshaw',
  double pickupLat = 24.8700, // Karachi markaz ke qareeb
  double pickupLng = 67.0100,
}) =>
    Booking(
      id: 'r1',
      passengerName: 'Sawari',
      passengerPhone: '03000000000',
      pickupLabel: 'A',
      dropLabel: 'B',
      pickupLat: pickupLat,
      pickupLng: pickupLng,
      dropLat: 0,
      dropLng: 0,
      hasDropPin: true,
      vehicle: vehicle,
      distanceKm: 3,
      fare: 150,
      note: '',
      status: 'pending',
      createdAt: DateTime(2026, 11, 11),
    );

void main() {
  group('poolVehicleMatches — gaari ki sarhad', () {
    test('ek jaisi gaari match hai (case/space farq nahi)', () {
      expect(poolVehicleMatches('Rickshaw', 'Rickshaw'), isTrue);
      expect(poolVehicleMatches(' rickshaw ', 'RICKSHAW'), isTrue);
      expect(poolVehicleMatches('Van', 'Van'), isTrue);
    });
    test('alag gaari match NAHI — Bike wala Van nahi le sakta', () {
      expect(poolVehicleMatches('Van', 'Bike'), isFalse);
      expect(poolVehicleMatches('Car', 'Rickshaw'), isFalse);
    });
    test('khaali taraf par faisla nahi (true)', () {
      expect(poolVehicleMatches('Van', ''), isTrue);
      expect(poolVehicleMatches('', 'Bike'), isTrue);
    });
  });

  group('poolRideCity / poolZoneMatches — sheher ki sarhad', () {
    test('Karachi ke nuqte se Karachi nikalta hai', () {
      expect(poolRideCity(24.8700, 67.0100), 'Karachi');
    });
    test('Lahore ke nuqte se Lahore nikalta hai', () {
      expect(poolRideCity(31.5500, 74.3400), 'Lahore');
    });
    test('pin na ho (0,0) to sheher ka faisla nahi', () {
      expect(poolRideCity(0, 0), isNull);
      expect(poolZoneMatches(0, 0, 'Karachi'), isNull);
    });
    test('apna sheher true, doosra sheher false', () {
      expect(poolZoneMatches(24.8700, 67.0100, 'Karachi'), isTrue);
      expect(poolZoneMatches(31.5500, 74.3400, 'Karachi'), isFalse);
    });
    test('driver ka sheher khaali ya Doosra Sheher ho to faisla nahi', () {
      expect(poolZoneMatches(24.8700, 67.0100, ''), isNull);
      expect(poolZoneMatches(24.8700, 67.0100, 'Doosra Sheher'), isNull);
    });
  });

  group('poolRideVisible — list ki sarhadein', () {
    test('apni gaari + apna sheher + 2 km andar = dikhti hai', () {
      expect(
        poolRideVisible(_ride(),
            driverVehicle: 'Rickshaw', driverZone: 'Karachi', distanceKm: 1.5),
        isTrue,
      );
    });
    test('doosri gaari ki ride NAHI dikhti', () {
      expect(
        poolRideVisible(_ride(vehicle: 'Van'),
            driverVehicle: 'Bike', driverZone: 'Karachi', distanceKm: 1.0),
        isFalse,
      );
    });
    test('doosre sheher ki ride NAHI dikhti', () {
      expect(
        poolRideVisible(_ride(pickupLat: 31.5500, pickupLng: 74.3400),
            driverVehicle: 'Rickshaw', driverZone: 'Karachi', distanceKm: 1.0),
        isFalse,
      );
    });
    test('doori gin sake aur 2 km se zyada ho to NAHI dikhti', () {
      expect(
        poolRideVisible(_ride(),
            driverVehicle: 'Rickshaw', driverZone: 'Karachi', distanceKm: 2.5),
        isFalse,
      );
    });
    test('doori NA gin sake to ride list mein rehti hai (claim rukta hai)', () {
      expect(
        poolRideVisible(_ride(),
            driverVehicle: 'Rickshaw', driverZone: 'Karachi', distanceKm: null),
        isTrue,
      );
    });
  });

  group('poolClaimBlockReason — claim ki rukawat', () {
    test('sab durust ho to rukawat NAHI (null)', () {
      expect(
        poolClaimBlockReason(_ride(),
            driverVehicle: 'Rickshaw', driverZone: 'Karachi', distanceKm: 1.0),
        isNull,
      );
    });
    test('vehicle mismatch par saaf wajah', () {
      final r = poolClaimBlockReason(_ride(vehicle: 'Van'),
          driverVehicle: 'Bike', driverZone: 'Karachi', distanceKm: 1.0);
      expect(r, isNotNull);
      expect(r, contains('Van'));
      expect(r, contains('Bike'));
    });
    test('doosra sheher claim par rukta hai', () {
      final r = poolClaimBlockReason(
          _ride(pickupLat: 31.5500, pickupLng: 74.3400),
          driverVehicle: 'Rickshaw',
          driverZone: 'Karachi',
          distanceKm: 1.0);
      expect(r, isNotNull);
      expect(r, contains('Lahore'));
    });
    test('doori maloom na ho to claim NAHI hota (fail-open khatam)', () {
      final r = poolClaimBlockReason(_ride(),
          driverVehicle: 'Rickshaw', driverZone: 'Karachi', distanceKm: null);
      expect(r, isNotNull);
      expect(r, contains('Location'));
    });
    test('2 km se zyada par claim NAHI hota', () {
      final r = poolClaimBlockReason(_ride(),
          driverVehicle: 'Rickshaw', driverZone: 'Karachi', distanceKm: 3.2);
      expect(r, isNotNull);
    });
    test('driver ki gaari hi darj na ho to claim NAHI hota', () {
      final r = poolClaimBlockReason(_ride(),
          driverVehicle: '', driverZone: 'Karachi', distanceKm: 1.0);
      expect(r, isNotNull);
    });
  });

  group('RouteService.cacheEntryFresh — cache expiry (#23)', () {
    final now = DateTime(2026, 11, 11).millisecondsSinceEpoch;
    test('aaj ki entry taaza hai', () {
      expect(RouteService.cacheEntryFresh(now, now), isTrue);
      expect(
          RouteService.cacheEntryFresh(
              now - const Duration(days: 29).inMilliseconds, now),
          isTrue);
    });
    test('30 din se purani entry expire hai', () {
      expect(
          RouteService.cacheEntryFresh(
              now - const Duration(days: 31).inMilliseconds, now),
          isFalse);
    });
    test('waqt darj na ho (null/0) to expire hai', () {
      expect(RouteService.cacheEntryFresh(null, now), isFalse);
      expect(RouteService.cacheEntryFresh(0, now), isFalse);
    });
  });

  group('RideOpenSignal — notification tap (#23)', () {
    test('request par rideId + seq darj hota hai; consume saaf karta hai',
        () {
      final s = RideOpenSignal();
      s.request('ride-9');
      expect(s.rideId, 'ride-9');
      expect(s.seq, 1);
      expect(s.consume(), 'ride-9');
      expect(s.rideId, isNull);
      s.request('');
      expect(s.seq, 1); // khaali id par kuch nahi hota
    });
  });
}
