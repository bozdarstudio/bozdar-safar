import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:safar/main.dart';

void main() {
  testWidgets('Bozdar Safar app khulta hai', (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const BozdarSafarApp());
    await tester.pump();
    expect(find.text('BOZDAR SAFAR'), findsWidgets);
  });
}
