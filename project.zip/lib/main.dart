import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'lang.dart';
import 'store.dart';
import 'theme.dart';
import 'display_prefs.dart';
import 'backend.dart';
import 'health_engine.dart';
import 'duty_service.dart';
import 'push_service.dart';
import 'legal.dart';
import 'passenger.dart';
import 'driver.dart';
import 'voice.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // v1.4.5: duty service + local notifications ki bunyaad —
  // nakami par bhi app aage barhta hai (andar sab try/catch hai).
  await DutyService.init();
  // v1.4.18: UPDATE GATE ka asal version code PackageInfo se —
  // haath ke constant par ab bharosa nahi (jhoota-banner bug).
  await UpdatePolicy.loadCurrentVersion();
  // v1.4.30: DISPLAY pasand (Din/Raat/Auto) — pehle frame se
  // pehle load, taake app mehfooz pasand par hi khule।
  await DisplayPrefs.load();
  // v1.4.57 (Part 13): driver ke apne nishan ki pasand
  // (Teer/Gaari) bhi pehle frame se pehle load।
  await MarkerPrefs.load();
  runApp(const BozdarSafarApp());
}

class BozdarSafarApp extends StatefulWidget {
  const BozdarSafarApp({super.key});

  @override
  State<BozdarSafarApp> createState() => _BozdarSafarAppState();
}

class _BozdarSafarAppState extends State<BozdarSafarApp>
    with WidgetsBindingObserver {
  final AppStore store = AppStore();

  /// AGENT DEEP LINK (v1.4.7, spec §6): bozdarsafar://register
  /// ?agent=CODE — MainActivity wala MethodChannel (koi nayi pub
  /// dependency NAHI)। Cold start par getInitialLink, garam app
  /// par 'onLink' call। Code store.pendingAgentCode mein jata
  /// hai — registration wizard use pehle se bhara dikhata hai।
  static const MethodChannel _deepLinkChannel =
      MethodChannel('bozdar_safar/deeplink');

  void _handleDeepLink(String? url) {
    if (url == null || url.isEmpty) return;
    try {
      final uri = Uri.parse(url);
      if (uri.scheme != 'bozdarsafar') return;
      if (uri.host != 'register') return;
      final code = uri.queryParameters['agent'] ?? '';
      if (code.isNotEmpty) {
        unawaited(store.setPendingAgentCode(code));
      }
    } catch (_) {
      // Kharab link — khamoshi se nazar-andaz (app kabhi link
      // par nahi rukti)।
    }
  }

  Future<void> _initDeepLinks() async {
    _deepLinkChannel.setMethodCallHandler((call) async {
      if (call.method == 'onLink') {
        _handleDeepLink(call.arguments as String?);
      }
      return null;
    });
    try {
      final initial =
          await _deepLinkChannel.invokeMethod<String>('getInitialLink');
      _handleDeepLink(initial);
    } catch (_) {
      // Channel na mile (purana build) to kuch nahi hota।
    }
  }

  /// Opening display sirf cold start par EK dafa — malik ka hukm
  /// (2026-11-08 ~12:17): app khulte hi pehle BOARD wala display /
  /// intro chalega, phir proper app khulegi. v1.4.4 se asal 15s
  /// INTRO VIDEO (malik ki manzoor-shuda, ❤️ 2026-11-08) bundle
  /// mein hai (assets/intro-15s.mp4) — [IntroGate] use chalata
  /// hai; BoardSplash us ke peeche fallback/poster chehra rehta
  /// hai aur video kisi wajah se na chale to app BOARD wale
  /// purane rawaiye (2.8s display) par hi aage barhti hai — app
  /// intro par KABHI nahi rukti.
  bool _introDone = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // UPDATE GATE (v1.4.8): settings pull store ko notify karta
    // hai — usi par roz-wali notification ki jaanch bhi chalti
    // hai (recommended band par din mein sirf EK dafa)।
    store.addListener(_maybeNotifyUpdate);
    // Load ke baad ek dafa khamosh update check + backend sync —
    // dono fire-and-forget, intro se bilkul alag.
    store.load().then((_) {
      store.checkForUpdate();
      Backend.start(store);
      // v1.4.26 HEALTH ENGINE: khud-jaanch + self-repair —
      // khamosh usool, app is par kabhi nahi rukti; user ko
      // khabar sirf "App ki Haalat" (Madad tab) se milti hai।
      final health = PdHealth.engineFor(store);
      unawaited(health.loadLog());
      health.start();
      // v1.4.17 FCM: push ki bunyaad — poori guarded; Firebase
      // na ban sakay to app purane nizam par normal chalti hai.
      unawaited(PushService.init(store));
      unawaited(_initDeepLinks());
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    store.removeListener(_maybeNotifyUpdate);
    // v1.4.26: health engine ke timers bhi band — koi pending
    // timer/kaam app ke saath latka NAHI rehta.
    PdHealth.maybeEngine?.stop();
    super.dispose();
  }

  /// App wapas samne aye to UPDATE GATE ki dobara jaanch —
  /// settings taaza pull hoti hain aur gate foran badal sakta
  /// hai (malik ka rule: recheck on resume)।
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(Backend.refreshSettings());
      _maybeNotifyUpdate();
      // v1.4.26: sehat ki jaanch purani ho to dobara — engine
      // khud hadd rakhta hai (har resume par NAHI)।
      PdHealth.maybeEngine?.onResume();
    }
  }

  bool _updateNotifyBusy = false;

  /// Recommended band (UpdatePolicy.level == 1) par roz EK dafa
  /// local notification — wohi malik wala jumla. Mandatory band
  /// par notification ki zaroorat nahi — screen hi band hai;
  /// aam haalat mein bilkul khamosh।
  Future<void> _maybeNotifyUpdate() async {
    // v1.4.35 UPDATE KI AWAAZ (malik ka hukm 2026-11-12): asal
    // update-check level 1 ya 2 bataye to din mein EK dafa awaaz
    // mein elan — dono sides par (ye HomeShell dono ki mushtarika
    // hai). UpdateVoice khud saari shartein (level, roz-ek-dafa,
    // session) sambhalta hai; awaaz na bane to khamoshi.
    unawaited(UpdateVoice.checkOnceDaily());
    if (_updateNotifyBusy) return;
    if (UpdatePolicy.level != 1) return;
    _updateNotifyBusy = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final now = DateTime.now();
      final today =
          '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
      if (prefs.getString('update_notify_date') == today) return;
      await prefs.setString('update_notify_date', today);
      await DutyNotify.show(
        DutyNotify.idFor('app_update_recommended'),
        'Boz Safar',
        tr('main_update_jumla'),
      );
    } catch (_) {
      // Notification na jaye to bhi app aam chalti hai — banner
      // har waqt maujood hai।
    } finally {
      _updateNotifyBusy = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    // v1.4.30: EK display pasand — MaterialApp ka themeMode
    // isi se chalta hai; map apna style bhi isi pasand se
    // chunta hai (safar_map.dart)।
    return ValueListenableBuilder<DisplayMode>(
      valueListenable: DisplayPrefs.notifier,
      builder: (context, displayMode, _) => MaterialApp(
      title: 'Safar',
      debugShowCheckedModeBanner: false,
      theme: Brand.theme(),
      darkTheme: Brand.darkTheme(),
      themeMode: DisplayPrefs.themeMode,
      home: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          if (!_introDone) {
            return IntroGate(
              key: const ValueKey('intro'),
              onDone: () {
                if (mounted) setState(() => _introDone = true);
              },
            );
          }
          if (!store.loaded) {
            return const BoardSplash(key: ValueKey('loading'));
          }
          // UPDATE GATE (v1.4.8 — malik ke rules 2026-11-09):
          // mandatory hadd se neeche wali app ke liye blocking
          // screen — intro ke BAAD, har screen se PEHLE. Koi
          // rasta aage nahi; sirf Update button (permanent link)।
          if (UpdatePolicy.level == 2) {
            return UpdateGateScreen(
              key: const ValueKey('update-gate'),
              url: UpdatePolicy.updateUrl,
            );
          }
          // v1.4.4 LEGAL: pehli dafa Sharait ki qubooliyat lazmi —
          // baghair qabool kiye proper app (koi mode) nahi khulta.
          if (store.termsAcceptedAtMs == 0) {
            return TermsGateScreen(
                key: const ValueKey('terms'), store: store);
          }
          return ModeShell(key: const ValueKey('shell'), store: store);
        },
      ),
      ),
    );
  }
}

/// INTRO VIDEO ka darwaza (v1.4.4 — malik ki final/manzoor video):
/// app khulte hi assets/intro-15s.mp4 (16s, apni asal awaaz ke
/// saath — welcome line + anthem bed file mein pehle se mix hai)
/// chalti hai, phir proper app khulti hai.
///  - Pehli open (din ki): poora intro.
///  - Usi din ki dobara opens: video 10s se shuru (chhota sting) —
///    SKIP ka button dono surat mein har waqt nazar ata hai.
///  - BoardSplash peeche poster/fallback ke tor par rehta hai;
///    video load/play fail ho jaye to wohi board 2.8s dikh kar
///    app aage barh jati hai. 20s ka watchdog bhi hai — app intro
///    par kisi surat NAHI rukti.
class IntroGate extends StatefulWidget {
  final VoidCallback onDone;
  const IntroGate({super.key, required this.onDone});

  @override
  State<IntroGate> createState() => _IntroGateState();
}

class _IntroGateState extends State<IntroGate> {
  VideoPlayerController? _ctrl;
  bool _videoReady = false;
  bool _finished = false;
  Timer? _watchdog;
  Timer? _fallbackTimer;

  @override
  void initState() {
    super.initState();
    _watchdog = Timer(const Duration(seconds: 20), _finish);
    unawaited(_init());
  }

  Future<void> _init() async {
    try {
      // Din ki pehli open hai ya dobara wali — tareekh phone par
      // mehfooz rehti hai; dobara wali par sting (10s se shuru).
      var sameDay = false;
      try {
        final prefs = await SharedPreferences.getInstance();
        final now = DateTime.now();
        final today =
            '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
        sameDay = prefs.getString('intro_last_day') == today;
        await prefs.setString('intro_last_day', today);
      } catch (_) {
        // Prefs na milein to poora intro hi sahi.
      }
      final c = VideoPlayerController.asset('assets/intro-15s.mp4');
      _ctrl = c;
      await c.initialize().timeout(const Duration(seconds: 6));
      if (!mounted || _finished) {
        c.dispose();
        return;
      }
      c.addListener(_onTick);
      if (sameDay) {
        try {
          await c.seekTo(const Duration(seconds: 10));
        } catch (_) {
          // Seek na ho sakay to shuru se hi sahi — Skip mojood hai.
        }
      }
      await c.play();
      if (mounted && !_finished) setState(() => _videoReady = true);
    } catch (_) {
      // Video na chale to purana board wala rawaiya — 2.8s board
      // display, phir app. Crash/hang bilkul nahi.
      _fallbackTimer =
          Timer(const Duration(milliseconds: 2800), _finish);
    }
  }

  void _onTick() {
    final c = _ctrl;
    if (c == null || _finished) return;
    final v = c.value;
    if (v.hasError) {
      _fallbackTimer =
          Timer(const Duration(milliseconds: 1200), _finish);
      return;
    }
    final dur = v.duration.inMilliseconds;
    if (v.isCompleted ||
        (dur > 0 && v.position.inMilliseconds >= dur - 250)) {
      _finish();
    }
  }

  void _finish() {
    if (_finished) return;
    _finished = true;
    _watchdog?.cancel();
    _fallbackTimer?.cancel();
    widget.onDone();
  }

  @override
  void dispose() {
    _watchdog?.cancel();
    _fallbackTimer?.cancel();
    _ctrl?.removeListener(_onTick);
    _ctrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = _ctrl;
    return Stack(
      children: [
        const Positioned.fill(child: BoardSplash()),
        if (_videoReady && c != null)
          Positioned.fill(
            child: ColoredBox(
              color: Colors.black,
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: c.value.size.width,
                  height: c.value.size.height,
                  child: VideoPlayer(c),
                ),
              ),
            ),
          ),
        if (_videoReady)
          Positioned(
            right: 14,
            bottom: 26,
            child: ElevatedButton.icon(
              onPressed: _finish,
              icon: const Icon(Icons.skip_next, size: 19),
              label: const Text('Skip'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black.withOpacity(0.55),
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                  side: const BorderSide(color: Colors.white54),
                ),
                textStyle: const TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w800),
              ),
            ),
          ),
      ],
    );
  }
}

/// BOARD SPLASH — app ka opening display.
/// v1.4.53 (malik ka hukm 2026-11-15): ab ye malik ki apni
/// design sheet wali POORI-SCREEN tasveer hai
/// (assets/branding/splash-boz.webp — sheet ke bayein phone ki
/// screen: sabz pin + car nishan, bara "Boz Safar" naam,
/// "Ride • Travel • Earn", Karachi skyline — Mazar-e-Quaid,
/// rickshaw + bike + van, aur neeche bani hui loading patti
/// "Loading..." ke saath — sab kuch tasveer ke andar hi hai)।
/// Is liye widgeton wala purana bandobast (gehra sabz
/// gradient + pin emblem + halo logo + tagline "Your Ride,
/// Our Priority" + asal loading widget + skyline patti) HATA
/// diya gaya hai — tasveer khud mukammal display hai।
/// Splash ka waqt aur raasta (loading ke baad ka flow,
/// IntroGate, 15s intro video) bilkul purana hi hai — sirf
/// chehra badla hai। Yehi tasveer intro video ke peeche
/// poster/fallback ke tor par bhi rehti hai (purani jagah
/// par hi)।
class BoardSplash extends StatelessWidget {
  const BoardSplash({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Brand.greenDark,
      body: SizedBox.expand(
        child: Image.asset(
          'assets/branding/splash-boz.webp',
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}

/// ONE app, TWO fully separated sides. One tap replaces the whole
/// display; the other side never renders. Mode badalne ka SIRF EK
/// tareeqa hai (v1.0.8 — malik ka hukm): har side ke BrandHeader ke
/// foran neeche ek hi wazeh toggle button [ModeToggleButton], jis par
/// us mode ka naam likha hota hai jis mein jana hai ("Driver Mode" /
/// "Passenger Mode"). Kyunke ek waqt mein sirf ek side render hoti
/// hai, screen par hamesha ek hi mode button hota hai. Pehli dafa app
/// Passenger mode mein khulti hai.
class ModeShell extends StatefulWidget {
  final AppStore store;
  const ModeShell({super.key, required this.store});

  @override
  State<ModeShell> createState() => _ModeShellState();
}

class _ModeShellState extends State<ModeShell> {
  bool driverMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Brand.deepGreen,
      body: SafeArea(
        bottom: false,
        child: driverMode
            ? DriverSide(
                store: widget.store,
                onSwitchToPassenger: () {
                  setState(() => driverMode = false);
                  // Backend `devices` entry mein akhri mode taza.
                  unawaited(Backend.touchDevice(widget.store, 'passenger'));
                },
              )
            : PassengerSide(
                store: widget.store,
                onSwitchToDriver: () {
                  setState(() => driverMode = true);
                  unawaited(Backend.touchDevice(widget.store, 'driver'));
                },
              ),
      ),
    );
  }
}

/// THE single mode toggle (v1.0.8 — malik ka hukm: mode badalne ka
/// sirf yehi ek button hoga). Har side ke BrandHeader ke foran neeche
/// wazeh tor par lagta hai. Is par us mode ka naam likha hota hai jis
/// mein ye le jayega: Passenger mode mein "Driver Mode" (gaari/driver
/// icon ke saath), Driver mode mein "Passenger Mode" (sawari icon ke
/// saath). Ek tap = side badal gayi.
class ModeToggleButton extends StatelessWidget {
  final bool toDriver;
  final VoidCallback onTap;
  const ModeToggleButton(
      {super.key, required this.toDriver, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(
            toDriver
                ? Icons.drive_eta
                : Icons.airline_seat_recline_normal,
            size: 22),
        label: Text(toDriver ? 'Driver Mode' : 'Passenger Mode'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Brand.gold,
          foregroundColor: Brand.greenDark,
          padding: const EdgeInsets.symmetric(vertical: 13),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
        ),
      ),
    );
  }
}

/// Nayi update ka slim gold banner — dono sides ke home ke upar dikhta
/// hai. "Update karein" download link kholta hai; × dabane se sirf is
/// session ke liye chhup jata hai.
///
/// v1.4.8 UPDATE GATE: recommended band (UpdatePolicy.level == 1)
/// par ye banner MUSTAQIL hai — malik wala jumla, UpdatePolicy ke
/// link ke saath, aur × wala button NAHI (band nahi hota). Aam
/// (GitHub check wali) update par purana rawaiya barkarar hai.
class UpdateBanner extends StatelessWidget {
  final AppStore store;
  const UpdateBanner({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final policyBand = UpdatePolicy.level == 1;
    return Container(
      width: double.infinity,
      color: Brand.gold,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(
        children: [
          const Icon(Icons.system_update, size: 18, color: Brand.greenDark),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              policyBand
                  ? tr('main_update_jumla')
                  : tr('main_update_available'),
              style: const TextStyle(
                  color: Brand.greenDark,
                  fontSize: 13,
                  fontWeight: FontWeight.w800),
            ),
          ),
          TextButton(
            onPressed: () => launchUrl(
              Uri.parse(
                  policyBand ? UpdatePolicy.updateUrl : kUpdateDownloadUrl),
              mode: LaunchMode.externalApplication,
            ),
            style: TextButton.styleFrom(
              backgroundColor: Brand.greenDark,
              foregroundColor: Brand.cream,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              minimumSize: Size.zero,
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: Text(tr('main_update_btn'),
                style: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w800)),
          ),
          if (!policyBand) ...[
            const SizedBox(width: 4),
            IconButton(
              onPressed: store.dismissUpdate,
              icon: const Icon(Icons.close, size: 18, color: Brand.greenDark),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
              tooltip: tr('main_update_close_tip'),
            ),
          ],
        ],
      ),
    );
  }
}

/// UPDATE GATE — BLOCKING SCREEN (v1.4.8, malik ka rule
/// 2026-11-09 00:13): jab Master kisi update ko LAZMI (mandatory)
/// kar de aur ye app us hadd se neeche ho, to app khulte hi (intro
/// ke baad) SIRF ye screen ati hai — update kiye baghair app aage
/// NAHI khulti. Koi skip, koi back, koi doosra button nahi — sirf
/// «Update Karein», jo seedha permanent link kholta hai. Wapas
/// ane (resume) par settings dobara check hoti hain — update ho
/// jaye to ye screen khud hat jati hai.
class UpdateGateScreen extends StatelessWidget {
  final String url;
  const UpdateGateScreen({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Brand.greenDark,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.system_update_alt,
                  size: 84, color: Brand.gold),
              const SizedBox(height: 24),
              Text(
                tr('main_update_jumla'),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 21,
                  fontWeight: FontWeight.w900,
                  height: 1.35,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                tr('main_update_gate_body'),
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 14),
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: () => launchUrl(
                  Uri.parse(url),
                  mode: LaunchMode.externalApplication,
                ),
                icon: const Icon(Icons.download, size: 22),
                label: Text(tr('main_update_btn')),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Brand.gold,
                  foregroundColor: Brand.greenDark,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  textStyle: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w900),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
