// v1.4.25 — FINAL WAVE (fare gate / backend tasdeeq / monthly
// package asal) ke model-level tests: MonthlyPackage ke naye
// asal fields (passengerPhone / driverId / driverName), status
// ka matlab, purani JSON se compatibility, aur package fee ka
// wohi 10% hisaab jo backend row par driver se bandhta hai।
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:safar/store.dart';
import 'package:safar/lang.dart';
import 'package:safar/pool_filter.dart';

MonthlyPackage _pkg({
  String status = 'pending',
  String driverId = '',
  String driverName = '',
  String passengerPhone = '03001234567',
  int monthlyAmount = 39000,
}) =>
    MonthlyPackage(
      id: 'pkg-1',
      passengerName: 'Ahmed',
      passengerPhone: passengerPhone,
      pickup: 'Clifton',
      drop: 'Saddar',
      vehicle: 'Rickshaw',
      routeKm: 3.0,
      days: 26,
      monthlyAmount: monthlyAmount,
      createdAt: DateTime(2026, 11, 11),
      status: status,
      driverId: driverId,
      driverName: driverName,
    );

void main() {
  group('MonthlyPackage — asal fields (v1.4.25)', () {
    test('naya package pending hota hai, driver khaali', () {
      final p = _pkg();
      expect(p.status, 'pending');
      expect(p.hasDriver, isFalse);
      expect(p.isCancelled, isFalse);
    });

    test('JSON round-trip: saare naye fields mehfooz rehte hain', () {
      final p = _pkg(
          status: 'active', driverId: 'drv-9', driverName: 'Bilal');
      final back = MonthlyPackage.fromJson(p.toJson());
      expect(back.passengerPhone, '03001234567');
      expect(back.status, 'active');
      expect(back.driverId, 'drv-9');
      expect(back.driverName, 'Bilal');
      expect(back.hasDriver, isTrue);
    });

    test('purani JSON (v1.4.24 se pehle) toot-ti nahi — phone/driver khaali', () {
      final back = MonthlyPackage.fromJson({
        'id': 'old-1',
        'passengerName': 'Purana',
        'pickup': 'Clifton',
        'drop': 'Saddar',
        'vehicle': 'Rickshaw',
        'routeKm': 2.0,
        'days': 26,
        'monthlyAmount': 26000,
        'createdAt': '2026-11-01T00:00:00.000',
        'status': 'active',
      });
      expect(back.passengerPhone, '');
      expect(back.driverId, '');
      expect(back.driverName, '');
      expect(back.status, 'active');
    });

    test('cancelled ki pehchan saaf hai', () {
      expect(_pkg(status: 'cancelled').isCancelled, isTrue);
      expect(_pkg(status: 'active').isCancelled, isFalse);
    });
  });

  group('Package fee — driver se bandhi 10% (v1.4.25)', () {
    test('monthly amount par fee wohi serviceFee hai jo row par jati hai', () {
      // Rs 39,000 ke package par fee Rs 3,900 (10%) — yehi
      // rakam _pushPackage row ke 'fee' mein likhta hai aur
      // driver_id lagte hi usi driver ki ho jati hai।
      expect(Fares.serviceFee(39000), 3900);
      expect(Fares.serviceFee(26000), 2600);
    });
  });

  group('applyRemotePackageState — driver assign ki taaza haalat', () {
    setUp(() {
      TestWidgetsFlutterBinding.ensureInitialized();
      SharedPreferences.setMockInitialValues({});
    });

    test('driver lagne par local record update hota hai', () async {
      final store = AppStore();
      store.monthlyPackages.add(_pkg());
      final changed = store.applyRemotePackageState('pkg-1',
          driverId: 'drv-9', driverName: 'Bilal', status: 'active');
      expect(changed, isTrue);
      final p = store.monthlyPackages.first;
      expect(p.driverId, 'drv-9');
      expect(p.driverName, 'Bilal');
      expect(p.status, 'active');
      expect(p.hasDriver, isTrue);
    });

    test('ajnabi id par kuch nahi badalta', () {
      final store = AppStore();
      store.monthlyPackages.add(_pkg());
      expect(
          store.applyRemotePackageState('doosra', driverId: 'x'), isFalse);
      expect(store.monthlyPackages.first.driverId, '');
    });
  });

  group('Version — v1.4.29+52', () {
    test('constants pubspec se milte hain', () {
      expect(kAppVersion, '1.4.29');
      expect(kAppVersionCode, 52);
    });
  });

  group('v1.4.29 — Pending booking: expiry + ek-pending usool', () {
    Booking mk({
      required String id,
      String status = 'pending',
      String phone = '03001234567',
      bool acceptedHere = false,
      DateTime? at,
    }) =>
        Booking(
          id: id,
          passengerName: 'Ahmed',
          passengerPhone: phone,
          pickupLabel: 'Pickup',
          dropLabel: 'Drop',
          pickupLat: 24.86,
          pickupLng: 67.0,
          dropLat: 24.88,
          dropLng: 67.02,
          hasDropPin: true,
          vehicle: 'Rickshaw',
          distanceKm: 3,
          fare: 150,
          note: '',
          status: status,
          createdAt: at ?? DateTime.now(),
          acceptedHere: acceptedHere,
        );

    test('10 minute se purani apni pending expire hoti hai', () {
      final now = DateTime.now();
      final old = mk(id: 'b1', at: now.subtract(const Duration(minutes: 11)));
      final fresh = mk(id: 'b2', at: now.subtract(const Duration(minutes: 5)));
      expect(
          AppStore.pendingExpired(old, now, myPhone: '03001234567'), isTrue);
      expect(AppStore.pendingExpired(fresh, now, myPhone: '03001234567'),
          isFalse);
    });

    test('doosre ki booking / driver-accepted expire NAHI hoti', () {
      final now = DateTime.now();
      final other = mk(
          id: 'b3',
          phone: '03219999999',
          at: now.subtract(const Duration(minutes: 30)));
      final acc = mk(
          id: 'b4',
          acceptedHere: true,
          at: now.subtract(const Duration(minutes: 30)));
      expect(
          AppStore.pendingExpired(other, now, myPhone: '03001234567'), isFalse);
      expect(AppStore.pendingExpired(acc, now, myPhone: '03001234567'),
          isFalse);
    });

    test('TASHHEESH: nayi booking par purani khud cancel NAHI '
        'hoti (parallel bookings jaiz)', () {
      // Owner ki wazahat 2026-11-11 16:20 — purana auto-cancel
      // wala rule RAD hai; store ke source mein us ka koi
      // nishan NAHI hona chahiye।
      final storeSrc = File('lib/store.dart').readAsStringSync();
      expect(storeSrc.contains('Doosri booking ki wajah se mansookh'),
          isFalse);
      expect(storeSrc.contains('stalePendingsFor'), isFalse);
      // Accepted booking expire bhi NAHI hoti — pendingExpired
      // sirf 'pending' status par true deta hai।
      final now = DateTime.now();
      final acc = mk(
          id: 'acc1',
          status: 'accepted',
          at: now.subtract(const Duration(minutes: 30)));
      expect(AppStore.pendingExpired(acc, now, myPhone: '03001234567'),
          isFalse);
    });
  });

  group('v1.4.29 — 5-minute rule: driver no-show barkarar, '
      'passenger free-cancel RAD', () {
    test('driver no-show ka gate 5 minute (muft intezaar) hai', () {
      final storeSrc = File('lib/store.dart').readAsStringSync();
      expect(storeSrc.contains('mins < Fares.freeWaitingMinutes'),
          isTrue);
    });

    test('TASHHEESH #7: passenger-side bila-jurm cancel NAHI hai', () {
      // Owner hukm 2026-11-11 16:26 — passenger ghar baithe
      // fake ride + "driver nahi aya" cancel ka loophole band;
      // woh code wave se HI hata diya gaya hai।
      final storeSrc = File('lib/store.dart').readAsStringSync();
      final passengerSrc =
          File('lib/passenger.dart').readAsStringSync();
      expect(storeSrc.contains('driverNotArrivedUnlocked'), isFalse);
      expect(passengerSrc.contains('_cancelDriverNotArrived'), isFalse);
      expect(passengerSrc.contains('driver_not_arrived_btn'), isFalse);
    });
  });

  group('v1.4.29 — Arrived stage par wajah COMPULSORY', () {
    test('reason sheet ka mustGiveReason mode maujood hai '
        '(non-dismissible)', () {
      final n = File('lib/notifications.dart').readAsStringSync();
      expect(n.contains('mustGiveReason'), isTrue);
      expect(n.contains('isDismissible: !mustGiveReason'), isTrue);
      expect(n.contains('enableDrag: !mustGiveReason'), isTrue);
    });

    test('passenger ke dono cancel raste arrived par sakht hain', () {
      final p = File('lib/passenger.dart').readAsStringSync();
      expect('mustGiveReason: arrivedStage'.allMatches(p).length,
          greaterThanOrEqualTo(1));
      expect(
          "mustGiveReason: booking.status == 'arrived'"
              .allMatches(p)
              .length,
          greaterThanOrEqualTo(1));
      // Wajah record: cancelBooking wajah mehfooz karta hai
      // (Master ko backend cancel_reason mein nazar ati hai)।
      final s = File('lib/store.dart').readAsStringSync();
      expect(s.contains('b.cancelReason = reason.trim()'), isTrue);
    });
  });

  group('v1.4.29 — Minimum fare Rs 150 + do zubaanein', () {
    test('chhoti ride par fare kam se kam Rs 150', () {
      expect(Fares.fareFor('Rickshaw', 1.0), 150);
      expect(Fares.fareFor('Bike', 2.0), 150);
      expect(Fares.fareFor('Rickshaw', 3.0), 150);
    });
    test('lambi ride par fare waisa hi (min fare lagu nahi)', () {
      expect(Fares.fareFor('Car', 10.0), 700);
      expect(Fares.fareFor('Rickshaw', 10.0), 500);
    });
    test('zubaan: default ur; en map alag; trf placeholders bharta hai', () {
      Lang.current = 'ur';
      expect(tr('collect_cash'), 'Naqad Wasooli');
      Lang.current = 'en';
      expect(tr('collect_cash'), 'Collect Cash');
      expect(trf('passenger_will_pay', {'amt': 'Rs 312'}),
          'The passenger will pay Rs 312');
      Lang.current = 'ur';
      expect(trf('passenger_will_pay', {'amt': 'Rs 312'}),
          'Sawari Rs 312 degi');
    });
  });
  group('v1.4.29 — Driver radius FINAL RULE (#11)', () {
    Booking mkRide() => Booking(
          id: 'r1',
          passengerName: 'Ahmed',
          passengerPhone: '03001234567',
          pickupLabel: 'Pickup',
          dropLabel: 'Drop',
          pickupLat: 24.8700,
          pickupLng: 67.0100,
          dropLat: 24.88,
          dropLng: 67.02,
          hasDropPin: true,
          vehicle: 'Rickshaw',
          distanceKm: 3,
          fare: 150,
          note: '',
          status: 'pending',
          createdAt: DateTime.now(),
        );

    test('default radius 2 km hai (registration pre-selected)', () {
      expect(DriverProfile().radiusKm, 2.0);
      expect(kRadiusOptionsKm, [2, 3, 4, 5]);
    });

    test('profile JSON roundtrip + 2–5 clamp', () {
      final p = DriverProfile()..radiusKm = 4.0;
      final loaded = DriverProfile()..loadJson(p.toJson());
      expect(loaded.radiusKm, 4.0);
      final big = DriverProfile()..loadJson({'radiusKm': 9});
      expect(big.radiusKm, 5.0);
      final small = DriverProfile()..loadJson({'radiusKm': 1});
      expect(small.radiusKm, 2.0);
    });

    test('pool: driver ka apna radius faisla karta hai', () {
      final b = mkRide();
      // 4 km door ki ride: 5 km wale ko dikhe, 2 km wale ko NAHI
      expect(
          poolRideVisible(b,
              driverVehicle: 'Rickshaw',
              driverZone: 'Karachi',
              distanceKm: 4,
              radiusKm: 5),
          isTrue);
      expect(
          poolRideVisible(b,
              driverVehicle: 'Rickshaw',
              driverZone: 'Karachi',
              distanceKm: 4,
              radiusKm: 2),
          isFalse);
      // 6 km: 5 km wale ko bhi NAHI (max 5)
      expect(
          poolRideVisible(b,
              driverVehicle: 'Rickshaw',
              driverZone: 'Karachi',
              distanceKm: 6,
              radiusKm: 5),
          isFalse);
      // default (baghair radiusKm) = purana 2 km rawaiya
      expect(
          poolRideVisible(b,
              driverVehicle: 'Rickshaw',
              driverZone: 'Karachi',
              distanceKm: 2.5),
          isFalse);
      // claim gate bhi isi radius se
      expect(
          poolClaimBlockReason(b,
              driverVehicle: 'Rickshaw',
              driverZone: 'Karachi',
              distanceKm: 4,
              radiusKm: 5),
          isNull);
      expect(
          poolClaimBlockReason(b,
              driverVehicle: 'Rickshaw',
              driverZone: 'Karachi',
              distanceKm: 4,
              radiusKm: 2),
          contains('2 km'));
    });

    test('source pins: backend + wizard + settings + duty', () {
      final backend = File('lib/backend.dart').readAsStringSync();
      expect(backend.contains("row['radius_km'] = p.radiusKm"), isTrue);
      expect(backend.contains("'radius_km',"), isTrue);
      final reg = File('lib/registration.dart').readAsStringSync();
      expect(reg.contains('_radiusKm'), isTrue);
      expect(reg.contains('guidance_radius_ur.mp3'), isTrue);
      expect(reg.contains('guidance_radius_en.mp3'), isTrue);
      expect(reg.contains('Aap apna kilometer yahan se set kar sakte hain'),
          isTrue);
      expect(reg.contains('v.radiusKm = _radiusKm'), isTrue);
      final driver = File('lib/driver.dart').readAsStringSync();
      expect(driver.contains("tr('radius_title')"), isTrue);
      expect(driver.contains('radiusKm: store.profile.radiusKm'), isTrue);
      final duty = File('lib/duty_service.dart').readAsStringSync();
      expect(duty.contains('_radiusKm'), isTrue);
      final lang = File('lib/lang.dart').readAsStringSync();
      expect(lang.contains('Pickup Ka Daira (Radius)'), isTrue);
      expect(lang.contains('Pickup Radius'), isTrue);
    });

    test('radius guidance clips bundle mein maujood hain', () {
      expect(File('assets/guidance/guidance_radius_ur.mp3').existsSync(),
          isTrue);
      expect(File('assets/guidance/guidance_radius_en.mp3').existsSync(),
          isTrue);
    });
  });

}
