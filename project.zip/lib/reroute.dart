import 'package:latlong2/latlong.dart';

import 'route_service.dart';
import 'store.dart';

/// =====================================================================
/// v1.4.45 AUTO RE-ROUTE ENGINE (malik ka hukm 2026-11-13)
///
/// Usool (locked):
///  * Route ka hisaab HAR jagah wohi ek [RouteService.fetch]
///    hai — booking fare, driver preview aur ye engine koi
///    alag copy NAHI chalate।
///  * Booking par tay-shuda KIRAYA kabhi NAHI badalta — engine
///    sirf NUMAYA/navigation route badalta hai, fare booking
///    object mein mehfooz rehta hai aur yahan use hath hi
///    nahi lagta।
///  * Route options sirf DRIVER ke liye hain; sawari ko koi
///    choice NAHI milti (us ke map par sirf line taaza hoti
///    hai — SafarRouteMap ka khamosh tick)।
///  * Aakhri faisla DRIVER ka hai: woh naye raste ko wapas
///    (revert) kar de to 5 minute tak engine dobara NAHI
///    badalta ([revertHold])।
///
/// Engine khalis hisaab hai (koi UI/timer nahi) — timer aur
/// UI DriverNavView / SafarRouteMap chalate hain, faisla
/// yahan se ata hai।
/// =====================================================================
class ReRouteEngine {
  /// Har kitni der mein dobara jaanch (spec: 1 minute)।
  static const Duration tickEvery = Duration(seconds: 60);

  /// Report is doori ke andar ho to route "pareshan" mana
  /// jata hai (spec: ~300 m)।
  static const double troubleRadiusM = 300;

  /// Revert ke baad itni der engine khud NAHI badalta।
  static const Duration revertHold = Duration(minutes: 5);

  /// Is route par koi taaza report hai? Sirf AAGE wala hissa
  /// gina jata hai — peeche guzri hui jagah ki report par
  /// rasta NAHI badalta। [progressAlongM] driver ki route
  /// par mojooda position hai (meters, route ke shuru se);
  /// preview mein 0 (poora route aage hai)।
  /// Mile to woh report wapas, warna null।
  static RoadReport? troubleOn(
    RouteResult route,
    List<RoadReport> reports, {
    double progressAlongM = 0,
  }) {
    for (final r in reports) {
      final p = LatLng(r.lat, r.lng);
      if (route.track.minDistanceTo(p) > troubleRadiusM) continue;
      final along = route.track.progressAt(p).alongM;
      if (along < progressAlongM - 30) continue; // peeche reh gayi
      return r;
    }
    return null;
  }

  /// Current route ab bhi fresh candidates mein "numayanda"
  /// hai ya nahi: current ke aage wale points sample karke
  /// dekha jata hai ke zyada-tar (≥ 70%) kisi EK candidate
  /// ki line ke 150 m ke andar hain ya nahi। Na hon to
  /// matlab woh rasta ab aam intikhab mein raha hi nahi
  /// (band/jaam ki wajah se OSRM use de hi nahi raha)।
  static bool stillOffered(
    RouteResult current,
    List<RouteResult> candidates, {
    double progressAlongM = 0,
  }) {
    if (candidates.isEmpty || current.points.length < 2) return false;
    final track = current.track;
    final samples = <LatLng>[];
    for (var i = 0; i < current.points.length; i++) {
      if (track.cumM[i] >= progressAlongM) samples.add(current.points[i]);
    }
    if (samples.isEmpty) return true;
    var bestFrac = 0.0;
    for (final c in candidates) {
      var inside = 0;
      for (final s in samples) {
        if (c.track.minDistanceTo(s) <= 150) inside++;
      }
      final frac = inside / samples.length;
      if (frac > bestFrac) bestFrac = frac;
    }
    return bestFrac >= 0.7;
  }

  /// Do routes ek hi line hain ya nahi — manzil ek, kul
  /// doori taqreeban barabar, aur darmiyani hissa doosri
  /// line ke paas। Origin aage-peeche hone se pehla point
  /// badal sakta hai, is liye sakht endpoint shart NAHI।
  static bool sameLine(RouteResult a, RouteResult b) {
    if (a.points.isEmpty || b.points.isEmpty) return false;
    final dLast = const Distance()
        .as(LengthUnit.Meter, a.points.last, b.points.last);
    if (dLast > 60) return false;
    final dDiff = (a.distanceM - b.distanceM).abs();
    if (dDiff > a.distanceM * 0.05 + 50) return false;
    final mid = a.points[a.points.length ~/ 2];
    return b.track.minDistanceTo(mid) <= 120;
  }

  /// ASAL FAISLA: route badalna hai to naya route, warna
  /// null।
  ///
  /// Shartein:
  ///  1. Current route par taaza report (trouble) ho, YA
  ///     current route ab fresh candidates mein numayanda
  ///     na raha ho; AUR
  ///  2. Koi candidate aisa ho jo current se mukhtalif ho
  ///     aur us par koi report NA ho।
  /// Candidates ki tartib [RouteService.fetch] wali hi hai
  /// ([fresh] pehle = owner-rule default pick, phir us ke
  /// alternatives) — is liye pehla saaf candidate hi
  /// "sab se behtar dastiyab" hai।
  ///
  /// Khaas surat: masla sirf "numayanda na raha" ho aur
  /// saare candidates par bhi report ho — tab majboori mein
  /// default pick ([fresh]) hi wapas hota hai (purana rasta
  /// to raha hi nahi)। Report wale masle mein saare raste
  /// pareshan hon to switch NAHI hota — driver ko kisi
  /// pareshan raste par zabardasti NAHI bheja jata।
  static RouteResult? decide({
    required RouteResult current,
    required RouteResult fresh,
    required List<RoadReport> reports,
    double progressAlongM = 0,
  }) {
    final candidates = [fresh, ...fresh.alternatives];
    final trouble =
        troubleOn(current, reports, progressAlongM: progressAlongM);
    final offered =
        stillOffered(current, candidates, progressAlongM: progressAlongM);
    if (trouble == null && offered) return null;
    for (final c in candidates) {
      if (sameLine(current, c)) continue;
      if (troubleOn(c, reports) == null) return c;
    }
    if (trouble == null && !offered) {
      for (final c in candidates) {
        if (!sameLine(current, c)) return c;
      }
    }
    return null;
  }
}
