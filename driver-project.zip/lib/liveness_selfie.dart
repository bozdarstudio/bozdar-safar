import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

import 'lang.dart';
import 'permissions.dart';
import 'theme.dart';
import 'voice.dart';

/// =====================================================================
/// LIVE SELFIE — ASAL LIVENESS NIZAM (v1.4.79, malik ka hukm
/// 2026-11-24): sirf photo kheenchna kaafi NAHI — app driver ko
/// hidayat deti hai ke chehra LEFT ya RIGHT ghumaye (tartib har
/// dafa RANDOM), on-device ML Kit face detection asal head-pose
/// naapti hai, aur jab tamam harkatein durust ho jayen tab hi
/// aakhir mein seedha chehra wali tasveer banti hai। Wohi tasveer
/// phir caller ke purane rastay par jati hai (rozana selfie:
/// bucket 'selfies' <driver_id>/<date>.jpg; demand selfie:
/// versioned path + driver_selfies record) — backend contract
/// mein koi tabdeeli NAHI।
///
/// VISUAL FEEDBACK (malik ki wazahat 2026-11-24):
/// - Camera preview par chehre ke gird GOLD (sunahra) DAYRA —
///   driver ko chehra usi dayre ke andar rakhna hai; chehra
///   dayre se bahar ho to hidayat milti hai।
/// - Har marhala durust honay par woh marhala GREEN ho jata hai
///   (dayra + marhale ka nishan sabz) — saaf nazar ata hai ke
///   "sahi ho gaya"; phir agli hidayat।
/// - Intezaar = GOLD, durust = GREEN, nakami = wajah ke saath
///   saaf paighaam (waqt khatm / chehra nazar nahi aya)।
///
/// HEAD-POSE KE ISHARAY (Google ML Kit ki official tareef —
/// Face.getHeadEulerAngleY): headEulerAngleY IMAGE ke hisaab
/// se hai; POSITIVE matlab chehra image ke RIGHT side ki taraf
/// ghuma hai। Front camera ke RAW frame mein driver apna LEFT
/// ghumaye to us ka chehra image ke right ki taraf jata hai —
/// is liye is file mein:
///   driver ka LEFT  => headEulerAngleY >= +threshold
///   driver ka RIGHT => headEulerAngleY <= -threshold
/// Preview screen par mirror jaisa nazar ata hai, lekin ye
/// hisaab RAW frame par hai, mirror se NAHI badalta। Agar kisi
/// device par asal test mein ishaara ulta nikle to SIRF
/// [kYawSign] ko -1 karna hai — baqi tamam logic wohi rahega।
const double kYawSign = 1.0;

/// Ek harkat manzoor honay ke liye kam az kam itna ghumao।
const double kTurnThresholdDeg = 25;

/// Doosra marhala bhi wohi ruh ho to gehra ghumao (do angles)।
const double kTurnDeepThresholdDeg = 35;

/// Seedha/center ginnay ke liye is se kam ghumao chalega।
const double kCenterThresholdDeg = 12;

/// Har hidayat (harkat) ka waqt — is mein na ho to koshish nakam।
const int kStepTimeoutSec = 10;

/// Chehra dhoondhne (dayre mein lane) ka kul waqt।
const int kFindTimeoutSec = 20;

/// Shart lagatar itne processed frames par puri ho tab manzoor
/// (shor/noise se ek frame ki ghalti na chale)।
const int kHoldFrames = 3;

/// Liveness flow ka nateeja — callers (selfie_gate.dart ki
/// demand selfie, driver.dart ki rozana duty selfie) apni
/// purani ginti/usool isi par chalate hain:
/// - success: tamam harkatein durust; [photoPath] par aakhri
///   seedhi tasveer hai — caller ka purana upload rasta chalega।
/// - failed: harkat waqt par na hui / chehra nazar na aya —
///   GHALAT KOSHISH gini jati hai (caller ki maujooda ginti:
///   3 ghalat par block wala usool)।
/// - cancelled: driver ne khud band kiya ya camera ki ijazat
///   na mili — ginti NAHI (purana cancel wala rawaiya)।
/// - error: camera/detector hi na chala — ginti NAHI, gate
///   band rehta hai, dobara koshish ka rasta khula (purana
///   check-error wala rawaiya)।
enum LivenessOutcome { success, failed, cancelled, error }

class LivenessResult {
  final LivenessOutcome outcome;

  /// success par: aakhri seedhi tasveer ka local path।
  final String? photoPath;

  /// failed par: wajah ki lang key (lv_fail_*) — caller apne
  /// retry/block paighaam ke saath jod kar dikhata hai।
  final String? noteKey;

  const LivenessResult._(this.outcome, {this.photoPath, this.noteKey});

  const LivenessResult.success(String path)
      : this._(LivenessOutcome.success, photoPath: path);

  const LivenessResult.failed(String key)
      : this._(LivenessOutcome.failed, noteKey: key);

  const LivenessResult.cancelled() : this._(LivenessOutcome.cancelled);

  const LivenessResult.error() : this._(LivenessOutcome.error);
}

/// Liveness flow kholna — page band honay par nateeja; page
/// baghair nateeje ke band ho (system back waghera) to woh
/// CANCELLED hi gina jata hai (purana rawaiya)।
Future<LivenessResult> runLivenessSelfie(BuildContext context) async {
  final r = await Navigator.of(context).push<LivenessResult>(
    MaterialPageRoute(
      builder: (_) => const LivenessSelfiePage(),
      fullscreenDialog: true,
    ),
  );
  return r ?? const LivenessResult.cancelled();
}

/// Ek harkat wali hidayat: ruh (left/right) + kitna ghumao।
class _Challenge {
  final bool left;
  final double threshold;
  bool done = false;
  _Challenge(this.left, this.threshold);
}

enum _Phase { finding, challenge, recenter, capture, finishing }

class LivenessSelfiePage extends StatefulWidget {
  const LivenessSelfiePage({super.key});

  @override
  State<LivenessSelfiePage> createState() => _LivenessSelfiePageState();
}

class _LivenessSelfiePageState extends State<LivenessSelfiePage>
    with WidgetsBindingObserver {
  static const Map<DeviceOrientation, int> _orientations = {
    DeviceOrientation.portraitUp: 0,
    DeviceOrientation.landscapeLeft: 90,
    DeviceOrientation.portraitDown: 180,
    DeviceOrientation.landscapeRight: 270,
  };

  CameraController? _controller;
  CameraDescription? _cameraDesc;
  FaceDetector? _detector;
  Timer? _ticker;

  bool _starting = true;

  /// Shuruaat ki nakami: 'permission' | 'camera' | null (theek)।
  String? _startError;
  bool _permForever = false;
  bool _finished = false;
  bool _camReady = false;
  bool _processing = false;
  int _detectorErrors = 0;

  _Phase _phase = _Phase.finding;
  List<_Challenge> _challenges = [];
  int _challengeIdx = 0;
  int _hold = 0;
  DateTime? _deadline;
  int _phaseTimeoutSec = kFindTimeoutSec;

  // Aakhri processed frame ki haalat (UI feedback ke liye)।
  bool _facePresent = false;
  bool _inCircle = false;
  double? _yaw; // driver ke hisaab se: + = LEFT ghuma hai
  bool _wrongWay = false;
  bool _stepFlash = false; // marhala durust — dayra GREEN
  InputImageRotation? _lastRotation;

  @override
  void initState() {
    super.initState();
    _challenges = _makeSequence();
    WidgetsBinding.instance.addObserver(this);
    _ticker = Timer.periodic(
        const Duration(milliseconds: 250), (_) => _onTick());
    unawaited(_start());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker?.cancel();
    unawaited(_teardown());
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_finished) return;
    if (state == AppLifecycleState.inactive) {
      // Camera band — warna doosri apps/system ke saath takrao।
      unawaited(_releaseCamera());
    } else if (state == AppLifecycleState.resumed) {
      if (!_camReady && _startError == null) {
        // Wapas ane par camera dobara + maujooda marhale ka
        // waqt taaza (pas-e-manzar mein guzra waqt driver ke
        // khilaf NAHI ginna)।
        _armDeadline(_phaseTimeoutSec);
        unawaited(_initCamera());
      }
    }
  }

  /// RANDOM tartib: 2 harkatein — har ruh alag sikke ki tarah
  /// random; doosri bhi wohi ruh aye to woh GEHRI (doosra
  /// angle) hogi। Darmiyan mein seedha hona lazmi hai (neeche
  /// recenter wala marhala), is liye wohi ruh dobara bhi asal
  /// harkat maangti hai।
  List<_Challenge> _makeSequence() {
    final rnd = math.Random();
    final firstLeft = rnd.nextBool();
    final secondLeft = rnd.nextBool();
    return [
      _Challenge(firstLeft, kTurnThresholdDeg),
      _Challenge(
        secondLeft,
        secondLeft == firstLeft
            ? kTurnDeepThresholdDeg
            : kTurnThresholdDeg,
      ),
    ];
  }

  // -----------------------------------------------------------------
  // Shuruaat: ijazat → detector → camera
  // -----------------------------------------------------------------

  Future<void> _start() async {
    // Camera ki ijazat — maujooda AppPerms (+101 wala nizam)
    // hi canonical hai; yahan sirf haalat dekh kar darkhwast।
    var snap = await AppPerms.load();
    if (!snap.camGranted) {
      await AppPerms.requestCamera();
      snap = await AppPerms.load();
    }
    if (!mounted) return;
    if (!snap.camGranted) {
      setState(() {
        _starting = false;
        _startError = 'permission';
        _permForever = snap.camDeniedForever;
      });
      return;
    }
    try {
      _detector = FaceDetector(
        options: FaceDetectorOptions(
          enableTracking: true,
          // Head-pose (euler angles) ke liye accurate mode hi
          // bharosemand hai — ML Kit ki apni hidayat bhi yahi।
          performanceMode: FaceDetectorMode.accurate,
          minFaceSize: 0.15,
        ),
      );
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _starting = false;
        _startError = 'camera';
      });
      return;
    }
    await _initCamera();
    if (!mounted || _startError != null) return;
    setState(() => _starting = false);
    _enterFinding();
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) throw StateError('no camera');
      final front = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );
      _cameraDesc = front;
      final controller = CameraController(
        front,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.yuv420,
      );
      _controller = controller;
      await controller.initialize();
      try {
        await controller.setFlashMode(FlashMode.off);
      } catch (_) {}
      if (_finished) {
        await _releaseCamera();
        return;
      }
      await controller.startImageStream(_onFrame);
      _camReady = true;
      if (mounted) setState(() {});
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _starting = false;
        _startError = 'camera';
      });
    }
  }

  Future<void> _releaseCamera() async {
    _camReady = false;
    final c = _controller;
    _controller = null;
    if (c != null) {
      try {
        await c.stopImageStream();
      } catch (_) {}
      try {
        await c.dispose();
      } catch (_) {}
    }
  }

  Future<void> _teardown() async {
    await _releaseCamera();
    final d = _detector;
    _detector = null;
    if (d != null) {
      try {
        await d.close();
      } catch (_) {}
    }
    unawaited(Voice.stop());
  }

  // -----------------------------------------------------------------
  // Marhale (phases) aur waqt
  // -----------------------------------------------------------------

  void _armDeadline(int seconds) {
    _phaseTimeoutSec = seconds;
    _deadline = DateTime.now().add(Duration(seconds: seconds));
  }

  void _enterFinding() {
    _phase = _Phase.finding;
    _hold = 0;
    _armDeadline(kFindTimeoutSec);
    unawaited(Voice.speak(tr('lv_find')));
    if (mounted) setState(() {});
  }

  void _enterChallenge() {
    _phase = _Phase.challenge;
    _hold = 0;
    _wrongWay = false;
    _armDeadline(kStepTimeoutSec);
    final ch = _challenges[_challengeIdx];
    unawaited(Voice.speak(tr(ch.left ? 'lv_left' : 'lv_right')));
    if (mounted) setState(() {});
  }

  /// Harkat ke baad seedha hona — agli hidayat se pehle bhi
  /// aur aakhri photo se pehle bhi (yehi marhala do jagah)।
  void _enterRecenter({required bool last}) {
    _phase = last ? _Phase.capture : _Phase.recenter;
    _hold = 0;
    _wrongWay = false;
    _armDeadline(kStepTimeoutSec);
    unawaited(Voice.speak(tr('lv_center')));
    if (mounted) setState(() {});
  }

  void _onTick() {
    if (_finished || !mounted) return;
    final dl = _deadline;
    if (dl != null && DateTime.now().isAfter(dl)) {
      // Waqt khatam — koshish nakam (caller ki ginti chalegi)।
      _finish(LivenessResult.failed(
          _phase == _Phase.finding ? 'lv_fail_no_face' : 'lv_fail_timeout'));
      return;
    }
    setState(() {}); // countdown taaza
  }

  int get _secondsLeft {
    final dl = _deadline;
    if (dl == null) return 0;
    final s = dl.difference(DateTime.now()).inSeconds;
    return s < 0 ? 0 : s + 1;
  }

  // -----------------------------------------------------------------
  // Frame processing — ML Kit head-pose
  // -----------------------------------------------------------------

  void _onFrame(CameraImage image) {
    if (_processing || _finished || _detector == null) return;
    _processing = true;
    _process(image).whenComplete(() => _processing = false);
  }

  Future<void> _process(CameraImage image) async {
    final input = _toInputImage(image);
    if (input == null) return;
    List<Face> faces;
    try {
      faces = await _detector!.processImage(input);
      _detectorErrors = 0;
    } catch (_) {
      // Detector ki musalsal nakami = jaanch hi nahi ho rahi —
      // ERROR wala rawaiya: ginti NAHI, gate band, dobara
      // koshish ka rasta khula।
      _detectorErrors++;
      if (_detectorErrors >= 6 && !_finished) {
        _finish(const LivenessResult.error());
      }
      return;
    }
    if (_finished || !mounted) return;

    if (faces.isEmpty) {
      _facePresent = false;
      _inCircle = false;
      _yaw = null;
      _hold = 0;
      _wrongWay = false;
      setState(() {});
      return;
    }
    // Sab se bara chehra hi asal driver hai।
    faces.sort((a, b) {
      final aa = a.boundingBox.width * a.boundingBox.height;
      final bb = b.boundingBox.width * b.boundingBox.height;
      return bb.compareTo(aa);
    });
    final face = faces.first;
    final rawYaw = face.headEulerAngleY;
    if (rawYaw == null) return;
    final yaw = rawYaw * kYawSign; // + = driver ka LEFT

    // Dayre ki jaanch — UPRIGHT image ke hisaab se (rotation
    // ke baad wali soorat); dayra center mein hai is liye
    // darmiyan se faasla mirror se nahi badalta।
    final rot = _lastRotation;
    final swap = rot == InputImageRotation.rotation90deg ||
        rot == InputImageRotation.rotation270deg;
    final upW = (swap ? image.height : image.width).toDouble();
    final upH = (swap ? image.width : image.height).toDouble();
    final cx = face.boundingBox.center.dx / upW;
    final cy = face.boundingBox.center.dy / upH;
    final wRatio = face.boundingBox.width / upW;
    final inCircle = (cx - 0.5).abs() <= 0.15 &&
        (cy - 0.5).abs() <= 0.17 &&
        wRatio >= 0.30 &&
        wRatio <= 0.85;

    _facePresent = true;
    _inCircle = inCircle;
    _yaw = yaw;
    _advance(yaw, inCircle);
    if (mounted) setState(() {});
  }

  /// Maujooda marhale ki shart naapna aur aage barhna।
  void _advance(double yaw, bool inCircle) {
    switch (_phase) {
      case _Phase.finding:
        if (inCircle && yaw.abs() <= kCenterThresholdDeg) {
          if (++_hold >= kHoldFrames) {
            _challengeIdx = 0;
            _enterChallenge();
          }
        } else {
          _hold = 0;
        }
        break;
      case _Phase.challenge:
        final ch = _challenges[_challengeIdx];
        final correct =
            ch.left ? yaw >= ch.threshold : yaw <= -ch.threshold;
        final opposite =
            ch.left ? yaw <= -ch.threshold : yaw >= ch.threshold;
        _wrongWay = opposite;
        if (correct) {
          if (++_hold >= kHoldFrames) {
            ch.done = true;
            _stepFlash = true;
            unawaited(Voice.speak(tr('lv_step_done')));
            if (mounted) setState(() {});
            Future.delayed(const Duration(milliseconds: 900), () {
              if (_finished || !mounted) return;
              _stepFlash = false;
              if (_challengeIdx + 1 < _challenges.length) {
                _enterRecenter(last: false);
              } else {
                _enterRecenter(last: true);
              }
            });
            _phase = _Phase.finishing; // flash ke doran rukawat
            _deadline = null;
          }
        } else {
          _hold = 0;
        }
        break;
      case _Phase.recenter:
        if (yaw.abs() <= kCenterThresholdDeg) {
          if (++_hold >= kHoldFrames) {
            _challengeIdx++;
            _enterChallenge();
          }
        } else {
          _hold = 0;
        }
        break;
      case _Phase.capture:
        if (inCircle && yaw.abs() <= kCenterThresholdDeg) {
          if (++_hold >= kHoldFrames) {
            _phase = _Phase.finishing;
            _deadline = null;
            unawaited(_capture());
          }
        } else {
          _hold = 0;
        }
        break;
      case _Phase.finishing:
        break;
    }
  }

  /// Aakhri seedhi tasveer — caller ke purane upload rastay
  /// ke liye local file path। Stream band karke photo lena
  /// (CameraX par stream ke saath takePicture nahi chalta)।
  Future<void> _capture() async {
    final c = _controller;
    if (c == null) {
      _finish(const LivenessResult.error());
      return;
    }
    try {
      try {
        await c.stopImageStream();
      } catch (_) {}
      await Future<void>.delayed(const Duration(milliseconds: 150));
      final shot = await c.takePicture();
      _finish(LivenessResult.success(shot.path));
    } catch (_) {
      _finish(const LivenessResult.error());
    }
  }

  void _finish(LivenessResult r) {
    if (_finished) return;
    _finished = true;
    _ticker?.cancel();
    if (mounted) Navigator.of(context).pop(r);
  }

  // -----------------------------------------------------------------
  // CameraImage → InputImage (Android: YUV_420_888 → NV21)
  // -----------------------------------------------------------------

  InputImage? _toInputImage(CameraImage image) {
    if (!Platform.isAndroid) return null;
    final camera = _cameraDesc;
    final controller = _controller;
    if (camera == null || controller == null) return null;
    var compensation =
        _orientations[controller.value.deviceOrientation];
    if (compensation == null) return null;
    if (camera.lensDirection == CameraLensDirection.front) {
      compensation = (camera.sensorOrientation + compensation) % 360;
    } else {
      compensation =
          (camera.sensorOrientation - compensation + 360) % 360;
    }
    final rotation = InputImageRotationValue.fromRawValue(compensation);
    if (rotation == null) return null;
    _lastRotation = rotation;
    return InputImage.fromBytes(
      bytes: _convertYUV420ToNV21(image),
      metadata: InputImageMetadata(
        size: Size(image.width.toDouble(), image.height.toDouble()),
        rotation: rotation,
        format: InputImageFormat.nv21,
        bytesPerRow: image.width,
      ),
    );
  }

  /// YUV_420_888 → NV21 (ML Kit Android ke liye durust format)।
  /// Har plane apne rowStride/pixelStride ke saath parha jata
  /// hai — warna tasveer tedhi aur pose ghalat ata hai।
  Uint8List _convertYUV420ToNV21(CameraImage image) {
    final width = image.width;
    final height = image.height;
    final yPlane = image.planes[0];
    final uPlane = image.planes[1];
    final vPlane = image.planes[2];
    final ySize = width * height;
    final nv21 = Uint8List(ySize + width * height ~/ 2);
    var offset = 0;
    for (var row = 0; row < height; row++) {
      nv21.setRange(
          offset, offset + width, yPlane.bytes, row * yPlane.bytesPerRow);
      offset += width;
    }
    final uvHeight = height ~/ 2;
    final uvWidth = width ~/ 2;
    final uPixelStride = uPlane.bytesPerPixel ?? 1;
    final vPixelStride = vPlane.bytesPerPixel ?? 1;
    var uvOffset = ySize;
    for (var row = 0; row < uvHeight; row++) {
      for (var col = 0; col < uvWidth; col++) {
        final uIndex =
            row * uPlane.bytesPerRow + col * uPixelStride;
        final vIndex =
            row * vPlane.bytesPerRow + col * vPixelStride;
        nv21[uvOffset++] = vPlane.bytes[vIndex]; // V pehle (NV21)
        nv21[uvOffset++] = uPlane.bytes[uIndex]; // phir U
      }
    }
    return nv21;
  }

  // -----------------------------------------------------------------
  // UI — gold dayra, green tasdeeq, saaf hidayat
  // -----------------------------------------------------------------

  /// Dayre ka rang: durust haalat/flash par GREEN, warna GOLD।
  Color get _circleColor {
    if (_stepFlash) return Brand.brightGreen;
    switch (_phase) {
      case _Phase.finding:
        return _inCircle ? Brand.brightGreen : Brand.gold;
      case _Phase.challenge:
        {
          final ch = _challenges[_challengeIdx];
          final yaw = _yaw;
          final correct = yaw != null &&
              (ch.left ? yaw >= ch.threshold : yaw <= -ch.threshold);
          return correct ? Brand.brightGreen : Brand.gold;
        }
      case _Phase.recenter:
      case _Phase.capture:
        {
          final yaw = _yaw;
          final centered =
              yaw != null && yaw.abs() <= kCenterThresholdDeg;
          return (centered && _inCircle)
              ? Brand.brightGreen
              : Brand.gold;
        }
      case _Phase.finishing:
        return Brand.brightGreen;
    }
  }

  String get _instructionKey {
    switch (_phase) {
      case _Phase.finding:
        return 'lv_find';
      case _Phase.challenge:
        return _challenges[_challengeIdx].left ? 'lv_left' : 'lv_right';
      case _Phase.recenter:
      case _Phase.capture:
        return 'lv_center';
      case _Phase.finishing:
        return 'lv_step_done';
    }
  }

  String? get _hintKey {
    if (_phase == _Phase.finishing) return null;
    if (!_facePresent) return 'lv_no_face';
    if (_phase == _Phase.challenge && _wrongWay) return 'lv_wrong_way';
    if ((_phase == _Phase.finding || _phase == _Phase.capture) &&
        !_inCircle) {
      return 'lv_hint_circle';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(tr('lv_title')),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.close),
            onPressed: () =>
                _finish(const LivenessResult.cancelled()),
          ),
        ],
      ),
      body: _starting
          ? const Center(
              child: CircularProgressIndicator(color: Brand.gold))
          : _startError != null
              ? _errorView()
              : _liveView(),
    );
  }

  Widget _errorView() {
    final isPerm = _startError == 'permission';
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            isPerm ? Icons.no_photography : Icons.camera_alt,
            size: 64,
            color: Brand.gold,
          ),
          const SizedBox(height: 16),
          Text(
            tr(isPerm ? 'lv_perm_title' : 'sf_note_camera_fail'),
            textAlign: TextAlign.center,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 19,
                fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 10),
          Text(
            tr(isPerm ? 'lv_perm_body' : 'lv_camera_body'),
            textAlign: TextAlign.center,
            style: const TextStyle(
                color: Colors.white70, fontSize: 14, height: 1.5),
          ),
          const SizedBox(height: 22),
          if (isPerm)
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  if (_permForever) {
                    await AppPerms.openSettings();
                  } else {
                    await AppPerms.requestCamera();
                  }
                  final snap = await AppPerms.load();
                  if (!mounted) return;
                  if (snap.camGranted) {
                    // Ijazat mil gayi — flow dobara shuru।
                    setState(() {
                      _startError = null;
                      _starting = true;
                    });
                    unawaited(_start());
                  } else {
                    setState(() => _permForever =
                        snap.camDeniedForever || _permForever);
                  }
                },
                child: Text(
                    tr(_permForever ? 'lv_perm_settings' : 'lv_perm_btn')),
              ),
            ),
          const SizedBox(height: 10),
          OutlinedButton(
            onPressed: () => _finish(isPerm
                ? const LivenessResult.cancelled()
                : const LivenessResult.error()),
            child: Text(tr('lv_back_btn'),
                style: const TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _liveView() {
    final size = MediaQuery.of(context).size;
    final circleD = math.min(size.width * 0.78, size.height * 0.46);
    final hint = _hintKey;
    return Stack(
      children: [
        Positioned.fill(child: _preview()),
        // GOLD/GREEN dayra — chehre ki rehnumai।
        Align(
          alignment: const Alignment(0, -0.28),
          child: Container(
            width: circleD,
            height: circleD,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: _circleColor, width: 5),
              color: _circleColor.withOpacity(0.08),
            ),
            child: _stepFlash
                ? const Icon(Icons.check_circle,
                    color: Brand.brightGreen, size: 84)
                : null,
          ),
        ),
        // Upar: marhalon ke nishan (gold = baqi, green = ho gaya)।
        Positioned(
          top: 10,
          left: 12,
          right: 12,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _stepChip(tr('lv_step_circle'), _phase != _Phase.finding,
                  active: _phase == _Phase.finding),
              _chipArrow(),
              for (var i = 0; i < _challenges.length; i++) ...[
                _stepChip(
                  _challenges[i].left ? 'LEFT' : 'RIGHT',
                  _challenges[i].done,
                  active:
                      _phase == _Phase.challenge && _challengeIdx == i,
                ),
                _chipArrow(),
              ],
              _stepChip(tr('lv_step_photo'), false,
                  active: _phase == _Phase.capture ||
                      _phase == _Phase.finishing),
            ],
          ),
        ),
        // Neeche: hidayat + countdown + wajah + band button।
        Positioned(
          left: 16,
          right: 16,
          bottom: 18,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (_phase == _Phase.challenge)
                Icon(
                  _challenges[_challengeIdx].left
                      ? Icons.arrow_circle_left
                      : Icons.arrow_circle_right,
                  color: _circleColor,
                  size: 54,
                ),
              const SizedBox(height: 6),
              Text(
                tr(_instructionKey),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  height: 1.25,
                ),
              ),
              const SizedBox(height: 8),
              if (hint != null)
                Text(
                  tr(hint),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: Brand.goldLight,
                      fontSize: 15,
                      fontWeight: FontWeight.w700),
                ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.timer, color: Colors.white70, size: 18),
                  const SizedBox(width: 6),
                  Text(
                    trf('lv_seconds', {'sec': '$_secondsLeft'}),
                    style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 15,
                        fontWeight: FontWeight.w700),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: _phaseTimeoutSec == 0
                      ? 0
                      : _secondsLeft / _phaseTimeoutSec,
                  minHeight: 5,
                  backgroundColor: Colors.white24,
                  color: Brand.gold,
                ),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () =>
                    _finish(const LivenessResult.cancelled()),
                child: Text(tr('lv_back_btn'),
                    style: const TextStyle(
                        color: Colors.white70, fontSize: 15)),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _preview() {
    final c = _controller;
    if (c == null || !c.value.isInitialized) {
      return const Center(
          child: CircularProgressIndicator(color: Brand.gold));
    }
    final size = MediaQuery.of(context).size;
    var scale = size.aspectRatio * c.value.aspectRatio;
    if (scale < 1) scale = 1 / scale;
    return ClipRect(
      child: Transform.scale(
        scale: scale,
        child: Center(child: CameraPreview(c)),
      ),
    );
  }

  Widget _stepChip(String label, bool done, {bool active = false}) {
    final color =
        done ? Brand.brightGreen : (active ? Brand.gold : Colors.white38);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.55),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color, width: 1.6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (done)
            const Icon(Icons.check, size: 14, color: Brand.brightGreen),
          if (done) const SizedBox(width: 3),
          Text(
            label,
            style: TextStyle(
                color: color, fontSize: 12, fontWeight: FontWeight.w800),
          ),
        ],
      ),
    );
  }

  Widget _chipArrow() => const Padding(
        padding: EdgeInsets.symmetric(horizontal: 3),
        child: Icon(Icons.arrow_forward, size: 13, color: Colors.white38),
      );
}
