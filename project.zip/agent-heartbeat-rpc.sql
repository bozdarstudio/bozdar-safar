-- =====================================================================
-- Boz Safar — v1.4.55 · AGENT HEARTBEAT RPC (agent_heartbeat)
--
-- Agent ki app (P+D) foreground mein hotay hue har 60 second
-- apni mojoodgi darj karti hai: agents.last_seen_at = now(),
-- aur location ki ijazat ho to agents.last_lat / last_lng bhi
-- (Master app mein agent ka "online hai / aakhri location"
-- wala nizam isi par chalta hai)।
--
-- Shartein (public.agents par is column-set ki seedhi UPDATE
-- sirf Master/owner ke paas hai — agent ke apne Auth user ko
-- table par koi UPDATE grant NAHI, is liye ye SECURITY
-- DEFINER RPC hi asal rasta hai; link_agent (Phase 0b) wala
-- hi pehchan-bandhne ka usool yahan bhi hai):
--   * Sirf AUTHENTICATED session (auth.role() = 'authenticated')।
--   * Agent code (p_code) se row milti hai; archived agent ka
--     heartbeat NAHI lagta (woh pehchan mein hai hi nahi)।
--   * Caller ki pehchan agent se bandhi honi chahiye — DO mein
--     se EK saboot lazmi:
--       (1) JWT ki email == agents.email (link_agent se darj
--           verify-shuda email), YA
--       (2) identity_links mein is Auth user ki kind='agent'
--           row jis ka subject_id is agent ki id ho
--           (link_agent RPC wahi record banata hai)।
--     Dono na hon to false — kisi AUR agent ki row kabhi
--     update NAHI hoti।
--   * Lat/lng JORI ki surat mein hi badalte hain (dono diye
--     hon to); warna purani location mehfooz rehti hai —
--     sirf last_seen_at taaza hota hai। GPS band ho ya ijazat
--     na ho to app null bhejti hai aur yehi rawaiya hai।
--
-- ADDITIVE ONLY: sirf naya function banta hai — koi table /
-- policy / data pehle se change NAHI hota। Idempotent
-- (CREATE OR REPLACE)।
-- Lazmi columns (parent pehle deploy kar raha hai):
--   agents.last_lat double precision, agents.last_lng double
--   precision, agents.last_seen_at timestamptz, agents.archived
--   boolean (v1.4.53 se live)।
--
-- Rollback: drop function
--   public.agent_heartbeat(text, double precision, double precision);
-- =====================================================================

create or replace function public.agent_heartbeat(
  p_code text,
  p_lat double precision,
  p_lng double precision
)
returns boolean
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_email text := lower(coalesce(auth.jwt() ->> 'email', ''));
  v_agent public.agents%rowtype;
begin
  -- Tasdeeq ki shartein — ek bhi fail ho to KUCH nahi hota।
  if auth.role() <> 'authenticated' or v_uid is null then
    return false;
  end if;

  select * into v_agent
    from public.agents
   where code = upper(btrim(coalesce(p_code, '')))
   limit 1;
  if not found then
    return false;
  end if;
  if coalesce(v_agent.archived, false) then
    return false;  -- archived agent mojood hi nahi mana jata
  end if;

  -- Pehchan ka bandh: JWT email == agent ki email, YA
  -- identity_links ki 'agent' row is Auth user ke liye।
  if not (
    (v_email <> '' and lower(coalesce(v_agent.email, '')) = v_email)
    or exists (
      select 1 from public.identity_links il
       where il.kind = 'agent'
         and il.auth_user_id = v_uid
         and il.subject_id = v_agent.id
    )
  ) then
    return false;
  end if;

  update public.agents
     set last_seen_at = now(),
         last_lat = case
                      when p_lat is not null and p_lng is not null
                      then p_lat else last_lat end,
         last_lng = case
                      when p_lat is not null and p_lng is not null
                      then p_lng else last_lng end
   where id = v_agent.id;
  return true;
end $$;

revoke execute on function
  public.agent_heartbeat(text, double precision, double precision)
  from public;
grant execute on function
  public.agent_heartbeat(text, double precision, double precision)
  to authenticated;
