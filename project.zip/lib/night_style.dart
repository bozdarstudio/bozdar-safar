// v1.4.59 (malik ki shikayat 2026-11-16): RAAT wala map bhi
// ab CARTO VECTOR (Dark Matter) NAHI raha — din wali hi
// wajah (kamzor net par vector data na pohanchna, khaali
// map)। Basemap wohi OpenStreetMap RASTER tiles hain,
// sirf raster paint se GEHRA kiya hua roop: brightness
// kam, saturation kam — sadkein raat mein bhi saaf parhi
// jati hain, rang feeke NAHI hote।
// CARTO RASTER istemal NAHI hua ("API KEY REQUIRED"
// watermark — parent ki jaanch)। CARTO se sirf FONTS
// (glyphs) barkarar hain — app ke apne label layers
// (A/B pin naam, teer/gaari ke maqam-naam) unhi se
// bante hain। Din/Raat/Auto ka intikhab DisplayPrefs
// pehle ki tarah karta hai — woh is file ko (raat) ya
// day_style.dart ko (din) chunta hai।
// App ke overlay sources/layers (route, markers, labels)
// safar_map.dart mein code se bante hain — is JSON mein
// sirf BASEMAP hai।
const String kNightStyleJson = r'''{
  "version": 8,
  "name": "Safar Night",
  "metadata": {},
  "sources": {
    "osm": {
      "type": "raster",
      "tiles": ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
      "tileSize": 256,
      "attribution": "© OpenStreetMap contributors"
    }
  },
  "sprite": "https://tiles.basemaps.cartocdn.com/v/20261026-01/gl/dark-matter-gl-style/sprite",
  "glyphs": "https://tiles.basemaps.cartocdn.com/v/20261026-01/fonts/{fontstack}/{range}.pbf",
  "layers": [
    {
      "id": "safar-bg",
      "type": "background",
      "paint": {"background-color": "#0d1520"}
    },
    {
      "id": "osm",
      "type": "raster",
      "source": "osm",
      "paint": {
        "raster-brightness-max": 0.42,
        "raster-brightness-min": 0.02,
        "raster-saturation": -0.45,
        "raster-contrast": 0.08
      }
    }
  ]
}''';
