import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'store.dart';
import 'theme.dart';
import 'main.dart' show SwitchModeButton, UpdateBanner;

const LatLng kKarachiCenter = LatLng(24.9056, 67.0563); // Liaquatabad

const Map<String, String> kStatusUrdu = {
  'pending': 'Driver ke jawab ka intezaar',
  'accepted': 'Driver ne qubool kar li',
  'arrived': 'Driver pohanch gaya hai',
  'completed': 'Ride mukammal',
  'cancelled': 'Mansookh',
  'noshow': 'Sawari nahi aayi (No-show)',
};

class PassengerSide extends StatefulWidget {
  final AppStore store;
  final VoidCallback onSwitchToDriver;
  const PassengerSide(
      {super.key, required this.store, required this.onSwitchToDriver});

  @override
  State<PassengerSide> createState() => _PassengerSideState();
}

class _PassengerSideState extends State<PassengerSide> {
  int _tab = 0; // 0 Booking | 1 Meri Bookings | 2 Monthly

  // Booking form
  final MapController _mapController = MapController();
  final GlobalKey _mapKey = GlobalKey();
  LatLng _pickup = kKarachiCenter;
  LatLng? _drop;
  bool _draggingPin = false;
  bool _dropArmed = false;
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _pickupCtrl = TextEditingController();
  final _dropCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  String _vehicle = 'Rickshaw';
  double _distanceKm = 2.0;

  // Monthly form
  final _mPickupCtrl = TextEditingController();
  final _mDropCtrl = TextEditingController();
  String _mVehicle = 'Rickshaw';
  double _mRouteKm = 2.0;
  int _mDays = 26;

  // NOTE (v1.0.5): km chip selectors HATA diye gaye hain — doori hamesha
  // AUTO hisaab (pickup pin se drop pin) se aati hai; passenger ko koi
  // km field, per-km rate ya formula kabhi nazar nahi aata.
  static const List<int> _dayChips = [20, 24, 26, 30];

  AppStore get store => widget.store;

  @override
  void initState() {
    super.initState();
    _nameCtrl.text = store.passengerName;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _pickupCtrl.dispose();
    _dropCtrl.dispose();
    _noteCtrl.dispose();
    _mPickupCtrl.dispose();
    _mDropCtrl.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  bool get _fareReady =>
      _pickupCtrl.text.trim().isNotEmpty && _dropCtrl.text.trim().isNotEmpty;

  /// Doori hamesha AUTO hisaab se: drop pin lagte hi pickup se drop tak
  /// ki doori. Drop pin na ho to andar ka default istemal hota hai —
  /// passenger se doori kabhi poochhi nahi jati.
  double get _autoKm {
    if (_drop == null) return _distanceKm;
    final d = const Distance().as(LengthUnit.Kilometer, _pickup, _drop!);
    final r = (d * 10).round() / 10;
    return r < 0.5 ? 0.5 : r;
  }

  int get _totalFare => Fares.fareFor(_vehicle, _autoKm);

  LatLng _globalToLatLng(Offset global) {
    final box = _mapKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null) return _pickup;
    final local = box.globalToLocal(global);
    return _mapController.camera
        .pointToLatLng(math.Point(local.dx, local.dy));
  }

  Future<void> _myLocation() async {
    try {
      final service = await Geolocator.isLocationServiceEnabled();
      if (!service) {
        if (mounted) _snack('Location service band hai — pehle on karein.');
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        if (mounted) _snack('Location ki ijazat nahi mili.');
        return;
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      if (!mounted) return;
      final ll = LatLng(pos.latitude, pos.longitude);
      setState(() {
        _pickup = ll;
        if (_pickupCtrl.text.trim().isEmpty) {
          _pickupCtrl.text = 'Meri Location';
        }
      });
      _mapController.move(ll, 15);
    } catch (_) {
      if (mounted) _snack('Location nahi mil saki — pin ghaseet kar lagayein.');
    }
  }

  void _placeDrop(LatLng point) {
    setState(() {
      _drop = point;
      _dropArmed = false;
    });
  }

  Future<void> _confirmBooking() async {
    if (_nameCtrl.text.trim().isEmpty) {
      _snack('Apna naam likhein.');
      return;
    }
    if (!_fareReady) {
      _snack('Pickup aur drop dono jagah likhein.');
      return;
    }
    store.passengerName = _nameCtrl.text.trim();
    final b = Booking(
      id: store.newId(),
      passengerName: _nameCtrl.text.trim(),
      passengerPhone: _phoneCtrl.text.trim(),
      pickupLabel: _pickupCtrl.text.trim(),
      dropLabel: _dropCtrl.text.trim(),
      pickupLat: _pickup.latitude,
      pickupLng: _pickup.longitude,
      dropLat: _drop?.latitude ?? 0,
      dropLng: _drop?.longitude ?? 0,
      hasDropPin: _drop != null,
      vehicle: _vehicle,
      distanceKm: _autoKm,
      fare: _totalFare,
      note: _noteCtrl.text.trim(),
      status: 'pending',
      createdAt: DateTime.now(),
      driverName: store.profile.name,
    );
    await store.addBooking(b);
    if (!mounted) return;
    _snack('Booking pakki ho gayi — driver ko bhej di gayi hai.');
    setState(() => _tab = 1);
  }

  void _clearBookingForm() {
    setState(() {
      _pickupCtrl.clear();
      _dropCtrl.clear();
      _noteCtrl.clear();
      _drop = null;
      _dropArmed = false;
      _distanceKm = 2.0;
      _vehicle = 'Rickshaw';
    });
    _snack('Koi booking nahi bani — sab saaf kar diya gaya.');
  }

  Future<void> _savePlace(bool isGhar) async {
    final current = isGhar ? store.savedGhar : store.savedDaftar;
    final ctrl = TextEditingController(text: current);
    final label = isGhar ? 'Ghar' : 'Daftar';
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('$label ki jagah save karein'),
        content: TextField(
          controller: ctrl,
          decoration: InputDecoration(labelText: '$label ka pata / jagah'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Rehne Dein')),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: const Text('Save Karein')),
        ],
      ),
    );
    if (result != null) {
      if (isGhar) {
        store.savedGhar = result;
      } else {
        store.savedDaftar = result;
      }
      await store.save();
      if (mounted) _snack('$label save ho gaya.');
    }
  }

  void _applyPlace(bool isGhar) {
    final v = isGhar ? store.savedGhar : store.savedDaftar;
    if (v.isEmpty) {
      _savePlace(isGhar);
    } else {
      setState(() => _dropCtrl.text = v);
    }
  }

  // -------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const BrandHeader(sideLabel: 'PASSENGER APP'),
          if (store.updateAvailable && !store.updateDismissed)
            UpdateBanner(store: store),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
            child: SwitchModeButton(
                toDriver: true, onTap: widget.onSwitchToDriver),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Row(
              children: [
                _tabBtn(0, Icons.map, 'Booking'),
                const SizedBox(width: 8),
                _tabBtn(1, Icons.list_alt, 'Meri Bookings'),
                const SizedBox(width: 8),
                _tabBtn(2, Icons.calendar_month, 'Monthly'),
              ],
            ),
          ),
          Expanded(
            child: _tab == 0
                ? _bookingView()
                : _tab == 1
                    ? _myBookingsView()
                    : _monthlyView(),
          ),
        ],
      ),
    );
  }

  Widget _tabBtn(int idx, IconData icon, String label) {
    final selected = _tab == idx;
    return Expanded(
      child: OutlinedButton.icon(
        onPressed: () => setState(() => _tab = idx),
        icon: Icon(icon, size: 18),
        label: Text(label),
        style: OutlinedButton.styleFrom(
          backgroundColor: selected ? Brand.goldLight : Colors.white,
          foregroundColor: Brand.greenDark,
          side: BorderSide(
              color: selected ? Brand.gold : const Color(0xFFB9CFC6),
              width: selected ? 1.8 : 1.2),
          padding: const EdgeInsets.symmetric(vertical: 10),
          textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
    );
  }

  IconData _vehicleIcon(String v) => v == 'Car'
      ? Icons.directions_car
      : v == 'Bike'
          ? Icons.two_wheeler
          : Icons.electric_rickshaw;

  /// inDrive-style vehicle card: gaari ka naam + KUL kiraya bara aur
  /// bold. Per-km rate kabhi nahi dikhta — sirf total.
  Widget _vehicleFareCard({
    required String vehicle,
    required int fare,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFFE7F2EC) : Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? Brand.green : Brand.fieldBorder,
              width: selected ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              Icon(_vehicleIcon(vehicle), color: Brand.green, size: 26),
              const SizedBox(width: 12),
              Expanded(
                child: Text(vehicle,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800)),
              ),
              Text(rs(fare),
                  style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w900,
                      color: Brand.greenDark)),
            ],
          ),
        ),
      ),
    );
  }

  // --- Booking view: full map + overlay sheet (inDrive style) ---------------

  Widget _bookingView() {
    final size = MediaQuery.of(context).size;
    return Stack(
      children: [
        Positioned.fill(
          child: FlutterMap(
            key: _mapKey,
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _pickup,
              initialZoom: 13,
              interactionOptions: InteractionOptions(
                flags: _draggingPin
                    ? InteractiveFlag.none
                    : InteractiveFlag.all,
              ),
              onTap: (_, point) {
                if (_dropArmed) _placeDrop(point);
              },
              onLongPress: (_, point) => _placeDrop(point),
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.bozdar.safar',
              ),
              CircleLayer(
                circles: [
                  CircleMarker(
                    point: _pickup,
                    radius: 2000,
                    useRadiusInMeter: true,
                    color: Brand.green.withOpacity(0.10),
                    borderColor: Brand.green,
                    borderStrokeWidth: 2,
                  ),
                ],
              ),
              if (_drop != null)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: [_pickup, _drop!],
                      strokeWidth: 4,
                      color: Brand.gold,
                    ),
                  ],
                ),
              MarkerLayer(
                markers: [
                  Marker(
                    point: _pickup,
                    width: 58,
                    height: 58,
                    child: Listener(
                      onPointerDown: (_) =>
                          setState(() => _draggingPin = true),
                      onPointerMove: (e) {
                        if (_draggingPin) {
                          setState(
                              () => _pickup = _globalToLatLng(e.position));
                        }
                      },
                      onPointerUp: (_) =>
                          setState(() => _draggingPin = false),
                      onPointerCancel: (_) =>
                          setState(() => _draggingPin = false),
                      child: const Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.location_on,
                              color: Brand.ajrakRed, size: 40),
                          Text('P',
                              style: TextStyle(
                                  fontSize: 10, fontWeight: FontWeight.w900)),
                        ],
                      ),
                    ),
                  ),
                  if (_drop != null)
                    Marker(
                      point: _drop!,
                      width: 58,
                      height: 58,
                      child: const Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.location_on,
                              color: Brand.green, size: 40),
                          Text('D',
                              style: TextStyle(
                                  fontSize: 10, fontWeight: FontWeight.w900)),
                        ],
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
        // Map quick actions
        Positioned(
          top: 10,
          right: 12,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              FloatingActionButton.small(
                heroTag: 'gps',
                onPressed: _myLocation,
                backgroundColor: Colors.white,
                foregroundColor: Brand.green,
                child: const Icon(Icons.my_location),
              ),
              const SizedBox(height: 4),
              const Text('Meri\nLocation',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
              const SizedBox(height: 10),
              FloatingActionButton.small(
                heroTag: 'droppin',
                onPressed: () => setState(() => _dropArmed = !_dropArmed),
                backgroundColor: _dropArmed ? Brand.gold : Colors.white,
                foregroundColor: Brand.green,
                child: const Icon(Icons.add_location_alt),
              ),
              const SizedBox(height: 4),
              const Text('Drop\nPin',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
            ],
          ),
        ),
        Positioned(
          top: 10,
          left: 12,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.92),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Brand.gold),
            ),
            child: const Text(
              'Pickup pin ghaseet kar lagayein\nDrop pin: map par lamba dabayein ya Drop Pin button',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
            ),
          ),
        ),
        // Booking sheet overlaid on the map
        Positioned(
          left: 10,
          right: 10,
          bottom: 10,
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: size.height * 0.52),
            child: Card(
              elevation: 8,
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
                child: _bookingForm(),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _bookingForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text('Ride Book Karein',
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: Brand.greenDark)),
        const SizedBox(height: 4),
        const Text(
          'Pickup aur drop likhein — kul kiraya khud samne aa jayega. Kiraya pehle se pakka hai, koi mol-bhav nahi.',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _nameCtrl,
          decoration: const InputDecoration(
              labelText: 'Aap ka naam', prefixIcon: Icon(Icons.person)),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _phoneCtrl,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
              labelText: 'Mobile number', prefixIcon: Icon(Icons.phone)),
        ),
        const SizedBox(height: 10),
        // Pickup / Drop — inDrive style: ek saaf card, dot-line markers.
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Brand.fieldBorder),
          ),
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 4),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  const SizedBox(height: 17),
                  Container(
                    width: 12,
                    height: 12,
                    decoration: const BoxDecoration(
                      color: Brand.green,
                      shape: BoxShape.circle,
                    ),
                  ),
                  Container(
                    width: 2,
                    height: 36,
                    color: Brand.fieldBorder,
                  ),
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: Brand.ajrakRed,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  children: [
                    TextField(
                      controller: _pickupCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Pickup jagah',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                    const Divider(height: 1, color: Brand.fieldBorder),
                    TextField(
                      controller: _dropCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Drop jagah (manzil)',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            const Text('Save jagah: ',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            ActionChip(
              label: const Text('Ghar'),
              onPressed: () => _applyPlace(true),
            ),
            const SizedBox(width: 6),
            ActionChip(
              label: const Text('Daftar'),
              onPressed: () => _applyPlace(false),
            ),
            const Spacer(),
            TextButton.icon(
              onPressed: () => _savePlace(true),
              icon: const Icon(Icons.edit, size: 15),
              label: const Text('Ghar set', style: TextStyle(fontSize: 12)),
            ),
            TextButton.icon(
              onPressed: () => _savePlace(false),
              icon: const Icon(Icons.edit, size: 15),
              label: const Text('Daftar set', style: TextStyle(fontSize: 12)),
            ),
          ],
        ),
        const SizedBox(height: 6),
        const Text('Gaari chunein',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 8),
        ...kVehicles.map((v) => _vehicleFareCard(
              vehicle: v,
              fare: Fares.fareFor(v, _autoKm),
              selected: _vehicle == v,
              onTap: () => setState(() => _vehicle = v),
            )),
        if (_drop != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 2),
            child: Text(
              'Doori auto hisaab se: ${_autoKm.toStringAsFixed(1)} km — kul kiraya neeche pakka nazar aa raha hai.',
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ),
        const SizedBox(height: 6),
        TextField(
          controller: _noteCtrl,
          decoration: const InputDecoration(
            labelText: 'Driver ke liye note (gate number, samaan, bacche...)',
            prefixIcon: Icon(Icons.note_alt),
          ),
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Brand.cream,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Brand.gold),
          ),
          child: const Text(
            'Waiting rule: Driver ke pohanchnay ke baad thora intezaar bilkul muft hai. Zyada intezaar par munasib waiting charges kul kiraya mein shamil ho jayenge.',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          ),
        ),
        const SizedBox(height: 10),
        if (_fareReady) ...[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Brand.deepGreen,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                const Text('KUL KIRAYA',
                    style: TextStyle(
                        color: Brand.goldLight,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.2)),
                Text(rs(_totalFare),
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.w900)),
                Text(
                  '$_vehicle · Kiraya pehle se pakka hai',
                  style:
                      const TextStyle(color: Brand.cream, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ],
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _confirmBooking,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  textStyle: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w900),
                ),
                child: const Text('Ride Pakki Karein'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton(
                onPressed: _clearBookingForm,
                child: const Text('Rehne Dein'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // --- Meri Bookings ---------------------------------------------------------

  Future<void> _shareRide(Booking b) async {
    final p = store.profile;
    final text = 'Safar ride share:\n'
        'Driver: ${p.name} (${p.vehicle}${p.plate.isEmpty ? '' : ' · ${p.plate}'})\n'
        'Route: ${b.pickupLabel} → ${b.dropLabel}\n'
        'Kul kiraya: ${rs(b.total)}\n'
        'Waqt: ${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)}';
    final uri = Uri.parse('https://wa.me/?text=${Uri.encodeComponent(text)}');
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) _snack('WhatsApp nahi khul saka.');
  }

  Future<void> _callDriver() async {
    final phone = store.profile.phone.trim();
    if (phone.isEmpty) {
      _snack('Driver ka number abhi set nahi hai.');
      return;
    }
    final ok = await launchUrl(Uri.parse('tel:$phone'));
    if (!ok && mounted) _snack('Call nahi ho saki.');
  }

  Widget _myBookingsView() {
    final list = store.bookings;
    if (list.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Abhi koi booking nahi hai.\nBooking wale hisse se pehli ride pakki karein.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15, color: Colors.black54),
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: list.length,
      itemBuilder: (context, i) {
        final b = list[i];
        final p = store.profile;
        final confirmed = b.status == 'accepted' || b.status == 'arrived';
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.route, color: Brand.green),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text('${b.pickupLabel} → ${b.dropLabel}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 15)),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  '${b.vehicle} · ${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)}',
                  style: const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                if (b.note.isNotEmpty)
                  Text('Note: ${b.note}',
                      style: const TextStyle(fontSize: 12)),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Chip(
                      label: Text(kStatusUrdu[b.status] ?? b.status),
                      backgroundColor: confirmed
                          ? const Color(0xFFDFF5E6)
                          : b.status == 'completed'
                              ? const Color(0xFFE8F0FE)
                              : const Color(0xFFF3E9C8),
                      labelStyle: const TextStyle(fontSize: 12),
                    ),
                    const Spacer(),
                    Text(rs(b.total),
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 17)),
                  ],
                ),
                if (b.status == 'completed' && b.waitingCharge > 0)
                  Text(
                    'Kiraya ${rs(b.fare)} + waiting ${rs(b.waitingCharge)} = ${rs(b.total)}',
                    style: const TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                if (confirmed) ...[
                  const Divider(),
                  const Text('Driver ki Pehchan',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text(
                      '${p.name} · ${p.vehicle}${p.plate.isEmpty ? '' : ' · Plate ${p.plate}'} · ${p.zone}'),
                  const Text(
                    'Driver CNIC-verified hai aur har booking record mein hai.',
                    style: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _callDriver,
                          icon: const Icon(Icons.call, size: 18),
                          label: const Text('Madad — Driver ko call karein'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Brand.ajrakRed,
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            textStyle: const TextStyle(
                                fontSize: 13, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () => _shareRide(b),
                      icon: const Icon(Icons.share, size: 18),
                      label: const Text('Ride ghar walon ko WhatsApp karein'),
                    ),
                  ),
                ],
                if (b.status == 'pending')
                  const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text(
                      'Booking driver ko bheji gayi hai — Driver Mode mein is ka jawab ayega.',
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  // --- Monthly package ---------------------------------------------------------

  bool get _monthlyReady =>
      _mPickupCtrl.text.trim().isNotEmpty &&
      _mDropCtrl.text.trim().isNotEmpty;

  int get _monthlyTotal =>
      Fares.monthlyAmount(_mVehicle, _mRouteKm, _mDays);

  Future<void> _confirmMonthly() async {
    if (!_monthlyReady) {
      _snack('Rozana pickup aur rozana drop dono likhein.');
      return;
    }
    await store.addMonthly(MonthlyPackage(
      id: store.newId(),
      passengerName: _nameCtrl.text.trim(),
      pickup: _mPickupCtrl.text.trim(),
      drop: _mDropCtrl.text.trim(),
      vehicle: _mVehicle,
      routeKm: _mRouteKm,
      days: _mDays,
      monthlyAmount: _monthlyTotal,
      createdAt: DateTime.now(),
    ));
    if (!mounted) return;
    _snack('Monthly package pakka ho gaya.');
    setState(() {});
  }

  void _clearMonthly() {
    setState(() {
      _mPickupCtrl.clear();
      _mDropCtrl.clear();
      _mVehicle = 'Rickshaw';
      _mRouteKm = 2.0;
      _mDays = 26;
    });
    _snack('Koi package nahi bana — sab saaf kar diya gaya.');
  }

  Widget _monthlyView() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('Monthly Package',
            style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w900,
                color: Brand.greenDark)),
        const SizedBox(height: 4),
        const Text(
          'Rickshaw / gaari mahine ke liye pakki karein — school, office ya madrassa ke liye rozana wohi pehchana driver, wohi jagah, wohi waqt.',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _mPickupCtrl,
          decoration: const InputDecoration(
              labelText: 'Rozana PICKUP jagah',
              prefixIcon: Icon(Icons.home)),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _mDropCtrl,
          decoration: const InputDecoration(
              labelText: 'Rozana DROP jagah',
              prefixIcon: Icon(Icons.school)),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 10),
        const Text('Gaari',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 8),
        ...kVehicles.map((v) => _vehicleFareCard(
              vehicle: v,
              fare: Fares.monthlyAmount(v, _mRouteKm, _mDays),
              selected: _mVehicle == v,
              onTap: () => setState(() => _mVehicle = v),
            )),
        const SizedBox(height: 4),
        const Text('Mahine mein kitne din?',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: _dayChips
              .map((d) => ChoiceChip(
                    label: Text('$d din'),
                    selected: _mDays == d,
                    onSelected: (_) => setState(() => _mDays = d),
                  ))
              .toList(),
        ),
        const SizedBox(height: 12),
        if (_monthlyReady) ...[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Brand.deepGreen,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                const Text('KUL MONTHLY RAQAM',
                    style: TextStyle(
                        color: Brand.goldLight,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.2)),
                Text(rs(_monthlyTotal),
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                        fontWeight: FontWeight.w900)),
                Text(
                  '${_mPickupCtrl.text.trim()} → ${_mDropCtrl.text.trim()} · $_mDays din · Raqam pehle se pakki hai',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Brand.cream, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ],
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _confirmMonthly,
                child: const Text('Monthly Package Pakka Karein'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton(
                onPressed: _clearMonthly,
                child: const Text('Rehne Dein'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        const Text('Mere Monthly Packages',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.monthlyPackages.isEmpty)
          const Text('Abhi koi monthly package nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...store.monthlyPackages.map((p) => Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: const Icon(Icons.calendar_month, color: Brand.green),
                title: Text('${p.pickup} → ${p.drop}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(
                    '${p.vehicle} · ${p.days} din · ${fmtDate(p.createdAt)}'),
                trailing: Text(rs(p.monthlyAmount),
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 15)),
              ),
            )),
      ],
    );
  }
}
