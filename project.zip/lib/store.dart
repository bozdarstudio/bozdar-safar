import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Fare rules — INTERNAL only. Per-km rates are never shown to passengers;
/// the passenger only ever sees the TOTAL fare.
///
/// Neeche wali default values wohi hain jo hamesha se theen. v1.1.0 se
/// ye values runtime par SIRF Master (backend settings) se refresh ho
/// sakti hain — [applyServerSettings] sirf backend sync bulata hai.
/// Is app ke andar in ka koi editor NAHI hai aur passenger ko ye kabhi
/// nazar nahi aateen; hisaab ke usool (formulas) bilkul waisay hi hain.
class Fares {
  static Map<String, int> perKm = {
    'Rickshaw': 50,
    'Bike': 40,
    'Car': 120,
  };
  static Map<String, int> waitingPerMin = {
    'Rickshaw': 5,
    'Bike': 4,
    'Car': 10,
  };
  static int freeWaitingMinutes = 5;
  static int joiningDeposit = 500;

  /// Service charges % — SIRF internal hissaab. Ye fee sirf Master app
  /// mein set hoti hai aur backend settings se is app tak puhanchti hai —
  /// passenger ko kabhi nazar nahi aati aur is app mein kahin se badli
  /// bhi nahi ja sakti. Driver ke apne wallet hisaab mein katauti
  /// "Service charges (5%)" ke tor par sirf usi ko dikhti hai.
  static double feePercent = 5.0;

  /// Backend settings (Master) se values lagana — sirf wohi fields
  /// badalte hain jo server ne bheje hon aur durust hon. Formulas ko
  /// haath nahi lagta.
  static void applyServerSettings({
    double? feePercent,
    Map<String, int>? rates,
    Map<String, int>? waiting,
    int? freeWaitingMin,
    int? deposit,
  }) {
    if (feePercent != null && feePercent > 0) {
      Fares.feePercent = feePercent;
    }
    if (rates != null) {
      for (final v in kVehicles) {
        final r = rates[v];
        if (r != null && r > 0) perKm[v] = r;
      }
    }
    if (waiting != null) {
      for (final v in kVehicles) {
        final w = waiting[v];
        if (w != null && w > 0) waitingPerMin[v] = w;
      }
    }
    if (freeWaitingMin != null && freeWaitingMin >= 0) {
      freeWaitingMinutes = freeWaitingMin;
    }
    if (deposit != null && deposit >= 0) {
      joiningDeposit = deposit;
    }
  }

  static int fareFor(String vehicle, double km) =>
      ((perKm[vehicle] ?? 50) * km).round();

  /// Waiting charge: first [freeWaitingMinutes] minutes free, then per-minute.
  static int waitingCharge(String vehicle, int elapsedMinutes) {
    final billable = elapsedMinutes - freeWaitingMinutes;
    if (billable <= 0) return 0;
    return billable * (waitingPerMin[vehicle] ?? 5);
  }

  static int monthlyAmount(String vehicle, double routeKm, int days) =>
      ((perKm[vehicle] ?? 50) * routeKm * days).round();

  static int serviceFee(int farePlusWaiting) =>
      (farePlusWaiting * feePercent / 100).round();
}

const List<String> kVehicles = ['Rickshaw', 'Bike', 'Car'];

/// Driver ko sirf itne km ke andar maujood pickups wali rides milti
/// hain — is se door ki sawari us driver ko dikhti hi nahi (booking
/// kahin aur khatm nahi hoti; doosra qareeb driver use le sakta hai).
/// INTERNAL: ye koi setting nahi hai — app mein kahin is ka editor ya
/// display nahi hai; sirf driver-facing maloomati jumlon mein "2 km ke
/// andar ki rides" ke tor par lafz aa sakta hai.
const double kDriverPickupRadiusKm = 2.0;

/// Is build ka version (pubspec ki versionName se milta julta rakhein).
const String kAppVersion = '1.2.9';

// ---------------------------------------------------------------------------
// Driver password (v1.2.5 — malik ka hukm)
//
// Har driver apna password KHUD lagata hai, aur ek password sirf EK hi
// driver ka ho sakta hai. Asal password kabhi save ya send NAHI hota —
// sirf us ka FINGERPRINT (neeche wala hash) phone par aur backend
// `drivers.pwd_fp` mein rehta hai. Fingerprint jaan boojh kar driver
// se WABASTA NAHI hai: wohi password = wohi fingerprint, har phone
// par — isi liye backend se pooch kar pata chal jata hai ke ye
// password pehle se kisi AUR driver ke paas to nahi. Pepper app ke
// code ki mustaqil value hai (secret nahi — maqsad sirf ye hai ke
// aam rainbow-table se fingerprint wapas password na ban jaye).
// ---------------------------------------------------------------------------

const String _kPwdPepper = 'safar-driver-pwd::v1::bozdar-safar';

/// Password ka deterministic fingerprint: (password + pepper) par
/// SHA-256 ke 10,000 rounds. Wohi password hamesha wohi fingerprint
/// deta hai — uniqueness check isi par chalta hai.
String passwordFingerprint(String password) {
  List<int> bytes = utf8.encode('$password|$_kPwdPepper');
  for (var i = 0; i < 10000; i++) {
    bytes = sha256.convert(bytes).bytes;
  }
  return bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
}

/// Nayi update hamesha isi link se milti hai — release asset ka naam
/// kabhi nahi badalta, sirf us ke andar ki file nayi ho jati hai.
const String kUpdateDownloadUrl =
    'https://github.com/bozdarstudio/bozdar-safar/releases/download/v1.0.0/BozdarSafar-v1.0.0.apk';

/// Percent saaf likhna: 5 -> "5%", 7.5 -> "7.5%", 7.25 -> "7.25%".
String fmtPct(double p) {
  var s = p.toStringAsFixed(2);
  if (s.contains('.')) {
    s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }
  return '$s%';
}

/// "1.0.4" > "1.0.3" type muqabla — har hisa number ke tor par.
bool versionIsNewer(String remote, String local) {
  List<int> parts(String v) =>
      v.split('.').map((e) => int.tryParse(e) ?? 0).toList();
  final r = parts(remote);
  final l = parts(local);
  for (var i = 0; i < 3; i++) {
    final rv = i < r.length ? r[i] : 0;
    final lv = i < l.length ? l[i] : 0;
    if (rv != lv) return rv > lv;
  }
  return false;
}

// Zones = Pakistan ke SHEHER (owner ka hukm 2026-11-07: Karachi ke
// ilaqe khatm, app poore Pakistan mein chalegi). Master sirf in ki
// KHULA/BAND haalat control karta hai; naya sheher code se jodna hota
// hai taake us ke map coordinates bhi maujood hon.
const List<String> kZones = [
  'Karachi',
  'Hyderabad',
  'Sukkur',
  'Larkana',
  'Nawabshah',
  'Mirpurkhas',
  'Lahore',
  'Faisalabad',
  'Rawalpindi',
  'Islamabad',
  'Multan',
  'Gujranwala',
  'Sialkot',
  'Bahawalpur',
  'Sargodha',
  'Peshawar',
  'Mardan',
  'Abbottabad',
  'Quetta',
  'Gwadar',
  'Doosra Sheher',
];

/// Har sheher ka SOOBA — passenger ki "Qareebi Jagahen" list mein
/// sheher ke neeche yahi nazar ata hai (pehle har zone ke neeche
/// 'Karachi' likha rehta tha). Sheher kZones mein ho aur yahan na
/// ho to subtitle 'Pakistan' ajata hai.
const Map<String, String> kZoneProvince = {
  'Karachi': 'Sindh',
  'Hyderabad': 'Sindh',
  'Sukkur': 'Sindh',
  'Larkana': 'Sindh',
  'Nawabshah': 'Sindh',
  'Mirpurkhas': 'Sindh',
  'Lahore': 'Punjab',
  'Faisalabad': 'Punjab',
  'Rawalpindi': 'Punjab',
  'Islamabad': 'Islamabad Capital Territory',
  'Multan': 'Punjab',
  'Gujranwala': 'Punjab',
  'Sialkot': 'Punjab',
  'Bahawalpur': 'Punjab',
  'Sargodha': 'Punjab',
  'Peshawar': 'Khyber Pakhtunkhwa',
  'Mardan': 'Khyber Pakhtunkhwa',
  'Abbottabad': 'Khyber Pakhtunkhwa',
  'Quetta': 'Balochistan',
  'Gwadar': 'Balochistan',
  'Doosra Sheher': 'Pakistan',
};

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------

class Booking {
  String id;
  String passengerName;
  String passengerPhone;
  String pickupLabel;
  String dropLabel;
  double pickupLat;
  double pickupLng;
  double dropLat;
  double dropLng;
  bool hasDropPin;
  String vehicle;
  double distanceKm;
  int fare; // distance fare only; waiting is separate
  String note;
  String status; // pending | accepted | arrived | completed | cancelled | noshow
  DateTime createdAt;
  DateTime? arrivedAt;
  DateTime? completedAt;
  int waitingMinutes;
  int waitingCharge;
  String driverName;

  Booking({
    required this.id,
    required this.passengerName,
    required this.passengerPhone,
    required this.pickupLabel,
    required this.dropLabel,
    required this.pickupLat,
    required this.pickupLng,
    required this.dropLat,
    required this.dropLng,
    required this.hasDropPin,
    required this.vehicle,
    required this.distanceKm,
    required this.fare,
    required this.note,
    required this.status,
    required this.createdAt,
    this.arrivedAt,
    this.completedAt,
    this.waitingMinutes = 0,
    this.waitingCharge = 0,
    this.driverName = 'Rashid Bozdar',
  });

  int get total => fare + waitingCharge;

  Map<String, dynamic> toJson() => {
        'id': id,
        'passengerName': passengerName,
        'passengerPhone': passengerPhone,
        'pickupLabel': pickupLabel,
        'dropLabel': dropLabel,
        'pickupLat': pickupLat,
        'pickupLng': pickupLng,
        'dropLat': dropLat,
        'dropLng': dropLng,
        'hasDropPin': hasDropPin,
        'vehicle': vehicle,
        'distanceKm': distanceKm,
        'fare': fare,
        'note': note,
        'status': status,
        'createdAt': createdAt.toIso8601String(),
        'arrivedAt': arrivedAt?.toIso8601String(),
        'completedAt': completedAt?.toIso8601String(),
        'waitingMinutes': waitingMinutes,
        'waitingCharge': waitingCharge,
        'driverName': driverName,
      };

  factory Booking.fromJson(Map<String, dynamic> j) => Booking(
        id: j['id'] as String,
        passengerName: j['passengerName'] as String? ?? '',
        passengerPhone: j['passengerPhone'] as String? ?? '',
        pickupLabel: j['pickupLabel'] as String? ?? '',
        dropLabel: j['dropLabel'] as String? ?? '',
        pickupLat: (j['pickupLat'] as num?)?.toDouble() ?? 0,
        pickupLng: (j['pickupLng'] as num?)?.toDouble() ?? 0,
        dropLat: (j['dropLat'] as num?)?.toDouble() ?? 0,
        dropLng: (j['dropLng'] as num?)?.toDouble() ?? 0,
        hasDropPin: j['hasDropPin'] as bool? ?? false,
        vehicle: j['vehicle'] as String? ?? 'Rickshaw',
        distanceKm: (j['distanceKm'] as num?)?.toDouble() ?? 0,
        fare: (j['fare'] as num?)?.toInt() ?? 0,
        note: j['note'] as String? ?? '',
        status: j['status'] as String? ?? 'pending',
        createdAt:
            DateTime.tryParse(j['createdAt'] as String? ?? '') ?? DateTime.now(),
        arrivedAt: DateTime.tryParse(j['arrivedAt'] as String? ?? ''),
        completedAt: DateTime.tryParse(j['completedAt'] as String? ?? ''),
        waitingMinutes: (j['waitingMinutes'] as num?)?.toInt() ?? 0,
        waitingCharge: (j['waitingCharge'] as num?)?.toInt() ?? 0,
        driverName: j['driverName'] as String? ?? 'Rashid Bozdar',
      );
}

class MonthlyPackage {
  String id;
  String passengerName;
  String pickup;
  String drop;
  String vehicle;
  double routeKm;
  int days;
  int monthlyAmount;
  DateTime createdAt;
  String status; // active

  MonthlyPackage({
    required this.id,
    required this.passengerName,
    required this.pickup,
    required this.drop,
    required this.vehicle,
    required this.routeKm,
    required this.days,
    required this.monthlyAmount,
    required this.createdAt,
    this.status = 'active',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'passengerName': passengerName,
        'pickup': pickup,
        'drop': drop,
        'vehicle': vehicle,
        'routeKm': routeKm,
        'days': days,
        'monthlyAmount': monthlyAmount,
        'createdAt': createdAt.toIso8601String(),
        'status': status,
      };

  factory MonthlyPackage.fromJson(Map<String, dynamic> j) => MonthlyPackage(
        id: j['id'] as String,
        passengerName: j['passengerName'] as String? ?? '',
        pickup: j['pickup'] as String? ?? '',
        drop: j['drop'] as String? ?? '',
        vehicle: j['vehicle'] as String? ?? 'Rickshaw',
        routeKm: (j['routeKm'] as num?)?.toDouble() ?? 0,
        days: (j['days'] as num?)?.toInt() ?? 26,
        monthlyAmount: (j['monthlyAmount'] as num?)?.toInt() ?? 0,
        createdAt:
            DateTime.tryParse(j['createdAt'] as String? ?? '') ?? DateTime.now(),
        status: j['status'] as String? ?? 'active',
      );
}

class WalletTxn {
  String id;
  String type; // deposit | fee
  int amount; // deposit: +amount stored positive; fee: fee amount positive
  String method; // Cash | Raast | '' (fee)
  DateTime date;
  String note;

  WalletTxn({
    required this.id,
    required this.type,
    required this.amount,
    required this.method,
    required this.date,
    required this.note,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'amount': amount,
        'method': method,
        'date': date.toIso8601String(),
        'note': note,
      };

  factory WalletTxn.fromJson(Map<String, dynamic> j) => WalletTxn(
        id: j['id'] as String,
        type: j['type'] as String? ?? 'deposit',
        amount: (j['amount'] as num?)?.toInt() ?? 0,
        method: j['method'] as String? ?? '',
        date: DateTime.tryParse(j['date'] as String? ?? '') ?? DateTime.now(),
        note: j['note'] as String? ?? '',
      );
}

/// Master ko bheje jane wale message ki categories (v1.2.7).
const List<String> kMessageCategories = [
  'Ride ka masla',
  'Payment ya Wallet',
  'Driver ki shikayat',
  'Sawari ki shikayat',
  'App mein kharabi',
  'Deegar',
];

/// Master Messaging (v1.2.7 — malik ka hukm): sawari ya driver app se
/// seedha Master (head) ko message bhej sakta hai — masla, shikayat ya
/// koi bhi baat. Message pehle PHONE par mehfooz hota hai, phir backend
/// `messages` table mein jata hai jahan se Master app parhta hai.
/// [sent] = backend tak puhancha ya abhi phone par queued hai (offline
/// par agli sync/app khulne par khud dobara koshish hoti hai);
/// [isRead] = Master ne parh liya (Master app se pull hota hai).
class MasterMessage {
  String id;
  String senderKey; // driver: driverId | passenger: deviceId
  String senderRole; // 'driver' | 'passenger'
  String senderName;
  String senderMobile;
  String senderZone;
  String category;
  String body;
  bool isRead;
  bool sent;
  DateTime createdAt;

  MasterMessage({
    required this.id,
    required this.senderKey,
    required this.senderRole,
    required this.senderName,
    required this.senderMobile,
    required this.senderZone,
    required this.category,
    required this.body,
    required this.createdAt,
    this.isRead = false,
    this.sent = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'senderKey': senderKey,
        'senderRole': senderRole,
        'senderName': senderName,
        'senderMobile': senderMobile,
        'senderZone': senderZone,
        'category': category,
        'body': body,
        'isRead': isRead,
        'sent': sent,
        'createdAt': createdAt.toIso8601String(),
      };

  factory MasterMessage.fromJson(Map<String, dynamic> j) => MasterMessage(
        id: j['id'] as String,
        senderKey: j['senderKey'] as String? ?? '',
        senderRole: j['senderRole'] as String? ?? '',
        senderName: j['senderName'] as String? ?? '',
        senderMobile: j['senderMobile'] as String? ?? '',
        senderZone: j['senderZone'] as String? ?? '',
        category: j['category'] as String? ?? '',
        body: j['body'] as String? ?? '',
        isRead: j['isRead'] as bool? ?? false,
        sent: j['sent'] as bool? ?? false,
        createdAt:
            DateTime.tryParse(j['createdAt'] as String? ?? '') ?? DateTime.now(),
      );
}

class DriverProfile {
  String name = 'Rashid Bozdar';
  String phone = '';
  String vehicle = 'Rickshaw';
  String plate = '';
  String zone = 'Karachi';
  bool online = false;
  // HOTFIX v1.2.9: ye teenon ab SIRF local legacy record hain.
  // Backend ke cnic_status / licence_status / gaari_status columns
  // MASTER-OWNED hain — _pushDriver ab inhein NAHI bhejta, aur
  // driver khud apni tasdeeq kahin se set NAHI kar sakta (Profile ke
  // self-attestation ChoiceChips hata diye gaye hain). Asal Master
  // verdict master*Status fields mein pull hota hai.
  String cnicStatus = 'pending'; // legacy local — backend nahi jata
  String licenceStatus = 'none'; // has | none  (none = "Licence nahi hai") — registration DATA (wizard se)
  bool licenceVerified = false; // legacy local — backend nahi jata
  String vehiclePapers = 'pending'; // legacy local — backend nahi jata
  String selfieDate = ''; // yyyy-mm-dd
  String selfiePath = '';
  bool depositDone = false;
  int walletBalance = 0;
  int totalDeposited = 0;

  /// Master (backend) ne is driver ko ACTIVE kiya hai ya nahi — ye
  /// value SIRF backend se ati hai (drivers.active); app ke andar se
  /// kabhi set nahi hoti. Default false = pending.
  bool masterActive = false;

  /// Driver ki akhri maloom GPS jagah (v1.2.4) — Driver Mode mein
  /// position refresh / ride qubool / navigation stream se taza hoti
  /// rehti hai. Passenger isi se "driver kitni door hai, kitni dair
  /// mein ayega" ginata hai, aur backend `drivers` table ke lat/lng
  /// columns mein bhi yehi mirror jata hai (Master map par asal
  /// jagah isi se nazar ati hai). null = abhi tak position mili hi
  /// nahi — us surat mein passenger ko koi jhoota number NAHI dikhta.
  double? lastLat;
  double? lastLng;

  /// Driver ke apne password ka FINGERPRINT (v1.2.5) — asal password
  /// kabhi kahin save nahi hota. Khaali = abhi password set nahi hua;
  /// pehli duty-on par set karna lazmi hai.
  String pwdFp = '';

  /// Ghalat password ki koshishon ka hisaab (v1.2.5): 5 ghalat par
  /// [pwdLockUntilMs] tak duty unlock band. Dono persisted hain taaki
  /// app band karke lockout se bacha na ja sake.
  int pwdFailCount = 0;
  int pwdLockUntilMs = 0; // epoch ms; 0 = koi lock nahi

  bool get pwdLocked =>
      pwdLockUntilMs > DateTime.now().millisecondsSinceEpoch;

  /// Kis tareekh (yyyy-mm-dd) ki selfie backend par upload ho chuki
  /// hai — dobara upload rokne aur nakami par agli sync mein retry
  /// ke liye.
  String selfieUploadedDate = '';

  // --- Registration wizard (v1.2.6 — Yango-style qadam-ba-qadam form) ------
  //
  // Ye fields registration wizard bharata hai. Tasaveer ke LOCAL
  // paths yahan darj hain; backend par number/tafseel wale columns
  // aur documents ki STATUS jati hai — aur v1.2.8 se tasaveer khud
  // bhi bucket 'driver-docs' mein jati hain (docUploaded dekhein),
  // taaki Master Tasdeeq mein har cheez check kar sake.

  /// CNIC number (XXXXX-XXXXXXX-X) — backend `drivers.cnic_number`.
  String cnicNumber = '';
  String cnicFrontPath = ''; // CNIC samne wali tasveer (phone par)
  String cnicBackPath = ''; // CNIC peeche wali tasveer (phone par)

  /// Gaari ki tafseel — backend `drivers.vehicle_brand/model/year/color`.
  String vehicleBrand = ''; // e.g. Sazgar, Yamaha, Suzuki
  String vehicleModel = '';
  int vehicleYear = 0; // 0 = abhi nahi likha
  String vehicleColor = '';
  String vehiclePhotoPath = ''; // gaari ki tasveer (phone par)
  String vehicleRegPath = ''; // gaari ke kaghaz (registration) ki tasveer

  /// Driving licence — OPTIONAL hai (malik ka lock): na ho to
  /// [licenceStatus] 'none' rehta hai aur ye khaali rehte hain.
  /// Backend `drivers.licence_number`.
  String licenceNumber = '';
  String licencePhotoPath = ''; // licence ki tasveer (phone par)

  /// Registration wali LIVE selfie (camera se) — ye profile photo hai;
  /// rozana duty selfie ([selfiePath]) se ALAG hai. Phone par rehti hai.
  String profilePhotoPath = '';

  /// Registration wizard mukammal ho gaya hai ya nahi. Purane (v1.2.5
  /// se pehle ke) profiles mein ye key JSON mein nahi hoti — wahan
  /// naam + mobile maujood hona hi purani registration mana jata hai
  /// (loadJson mein derivation dekhein).
  /// ⚠️ HOTFIX v1.2.9: ye flag AKELA registration ka saboot NAHI
  /// raha — legacy derivation (sirf naam+mobile) ki wajah se baghair
  /// kisi document photo ke profiles bhi "done" lagte thay, wizard
  /// kabhi khulta hi nahi tha aur photos kabhi upload nahi hoteen.
  /// Asal mukammal hone ki shart [registrationComplete] hai.
  bool registrationDone = false;

  /// Registration ASAL mein mukammal (HOTFIX v1.2.9 — RC2):
  /// wizard ka flag + CNIC number + tamaam LAZMI document tasaveer
  /// phone par maujood hon. Licence ki photo ikhtiyari hai (licence
  /// hi ikhtiyari hai). Wizard ke tamam prompt/gate isay istemal
  /// karte hain — taaki purana (legacy) driver jis ke paas photos
  /// nahi hain woh wizard mein jaye (pehle se bhara hua milega, sirf
  /// baqi cheezein jama karni hongi).
  bool get registrationComplete =>
      registrationDone &&
      cnicNumber.trim().isNotEmpty &&
      cnicFrontPath.isNotEmpty &&
      cnicBackPath.isNotEmpty &&
      vehiclePhotoPath.isNotEmpty &&
      vehicleRegPath.isNotEmpty &&
      profilePhotoPath.isNotEmpty;

  // --- Registration documents ki backend upload (v1.2.8 — TASDEEQ) --------
  //
  // Tasdeeq ke liye registration ki document tasaveer backend Storage
  // bucket 'driver-docs' mein jati hain taaki Master har cheez ASAL
  // tasveer mein check kar sake. Ye map har kind (cnic_front, cnic_back,
  // vehicle, vehicle_reg, licence, profile) ke liye woh LOCAL path
  // rakhta hai jo aakhri dafa kamyabi se upload hua tha: kind ghayab
  // ho ya mojooda local path is se alag ho (photo dobara li gayi) to
  // dobara upload lazmi hai. Sirf phone par rehta hai — backend par
  // asal object path drivers ke *_path columns mein jata hai.
  Map<String, String> docUploaded = {};

  // --- Master ki tasdeeq ki haalat (backend se pull, sirf display) -------
  //
  // Ye teenon SIRF backend `drivers` row se ate hain (refreshDriverStatus)
  // aur Profile mein "Master ki Tasdeeq" ke tor par dikhte hain —
  // in mein 'verified' | 'pending' | 'rejected' | 'none' kuch bhi aa
  // sakta hai. Local gate/toggles (cnicStatus waghera) in se KABHI
  // nahi badalte; driver ki apni duty ka taala sirf masterActive hai.
  String masterCnicStatus = '';
  String masterGaariStatus = '';
  String masterLicenceStatus = '';

  bool get selfieToday {
    if (selfieDate.isEmpty) return false;
    final now = DateTime.now();
    final today =
        '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    return selfieDate == today;
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'phone': phone,
        'vehicle': vehicle,
        'plate': plate,
        'zone': zone,
        'online': online,
        'cnicStatus': cnicStatus,
        'licenceStatus': licenceStatus,
        'licenceVerified': licenceVerified,
        'vehiclePapers': vehiclePapers,
        'selfieDate': selfieDate,
        'selfiePath': selfiePath,
        'depositDone': depositDone,
        'walletBalance': walletBalance,
        'totalDeposited': totalDeposited,
        'masterActive': masterActive,
        'lastLat': lastLat,
        'lastLng': lastLng,
        'pwdFp': pwdFp,
        'pwdFailCount': pwdFailCount,
        'pwdLockUntilMs': pwdLockUntilMs,
        'selfieUploadedDate': selfieUploadedDate,
        'cnicNumber': cnicNumber,
        'cnicFrontPath': cnicFrontPath,
        'cnicBackPath': cnicBackPath,
        'vehicleBrand': vehicleBrand,
        'vehicleModel': vehicleModel,
        'vehicleYear': vehicleYear,
        'vehicleColor': vehicleColor,
        'vehiclePhotoPath': vehiclePhotoPath,
        'vehicleRegPath': vehicleRegPath,
        'licenceNumber': licenceNumber,
        'licencePhotoPath': licencePhotoPath,
        'profilePhotoPath': profilePhotoPath,
        'registrationDone': registrationDone,
        'docUploaded': docUploaded,
        'masterCnicStatus': masterCnicStatus,
        'masterGaariStatus': masterGaariStatus,
        'masterLicenceStatus': masterLicenceStatus,
      };

  void loadJson(Map<String, dynamic> j) {
    name = j['name'] as String? ?? name;
    phone = j['phone'] as String? ?? '';
    vehicle = j['vehicle'] as String? ?? 'Rickshaw';
    plate = j['plate'] as String? ?? '';
    zone = j['zone'] as String? ?? 'Karachi';
    online = j['online'] as bool? ?? false;
    cnicStatus = j['cnicStatus'] as String? ?? 'pending';
    licenceStatus = j['licenceStatus'] as String? ?? 'none';
    licenceVerified = j['licenceVerified'] as bool? ?? false;
    vehiclePapers = j['vehiclePapers'] as String? ?? 'pending';
    selfieDate = j['selfieDate'] as String? ?? '';
    selfiePath = j['selfiePath'] as String? ?? '';
    depositDone = j['depositDone'] as bool? ?? false;
    walletBalance = (j['walletBalance'] as num?)?.toInt() ?? 0;
    totalDeposited = (j['totalDeposited'] as num?)?.toInt() ?? 0;
    masterActive = j['masterActive'] as bool? ?? false;
    lastLat = (j['lastLat'] as num?)?.toDouble();
    lastLng = (j['lastLng'] as num?)?.toDouble();
    pwdFp = j['pwdFp'] as String? ?? '';
    pwdFailCount = (j['pwdFailCount'] as num?)?.toInt() ?? 0;
    pwdLockUntilMs = (j['pwdLockUntilMs'] as num?)?.toInt() ?? 0;
    selfieUploadedDate = j['selfieUploadedDate'] as String? ?? '';
    cnicNumber = j['cnicNumber'] as String? ?? '';
    cnicFrontPath = j['cnicFrontPath'] as String? ?? '';
    cnicBackPath = j['cnicBackPath'] as String? ?? '';
    vehicleBrand = j['vehicleBrand'] as String? ?? '';
    vehicleModel = j['vehicleModel'] as String? ?? '';
    vehicleYear = (j['vehicleYear'] as num?)?.toInt() ?? 0;
    vehicleColor = j['vehicleColor'] as String? ?? '';
    vehiclePhotoPath = j['vehiclePhotoPath'] as String? ?? '';
    vehicleRegPath = j['vehicleRegPath'] as String? ?? '';
    licenceNumber = j['licenceNumber'] as String? ?? '';
    licencePhotoPath = j['licencePhotoPath'] as String? ?? '';
    profilePhotoPath = j['profilePhotoPath'] as String? ?? '';
    // Purani JSON (v1.2.5 se pehle) mein 'registrationDone' key nahi
    // hoti — wahan naam + mobile maujood hona hi registration tha
    // (backend._registered ki purani tareef), wohi yahan mana gaya.
    registrationDone = j['registrationDone'] as bool? ??
        (name.trim().isNotEmpty && phone.trim().isNotEmpty);
    // v1.2.8: purani JSON mein ye keys nahi hotin — khaali defaults.
    final du = j['docUploaded'];
    docUploaded = du is Map
        ? du.map((k, v) => MapEntry(k.toString(), v?.toString() ?? ''))
        : {};
    masterCnicStatus = j['masterCnicStatus'] as String? ?? '';
    masterGaariStatus = j['masterGaariStatus'] as String? ?? '';
    masterLicenceStatus = j['masterLicenceStatus'] as String? ?? '';
  }
}

// ---------------------------------------------------------------------------
// Store — one on-device store shared by BOTH sides (same device), exactly like
// the web app: a booking made on the Passenger side appears on the Driver side.
// ---------------------------------------------------------------------------

class AppStore extends ChangeNotifier {
  final DriverProfile profile = DriverProfile();
  List<Booking> bookings = [];
  List<MonthlyPackage> monthlyPackages = [];
  List<WalletTxn> txns = [];
  String savedGhar = '';
  String savedDaftar = '';
  String passengerName = '';
  String passengerPhone = '';

  /// Master ko bheje gaye messages (v1.2.7) — is phone se bheje gaye
  /// saare (driver + passenger dono roles), sab se naya sab se pehle.
  List<MasterMessage> masterMessages = [];
  bool loaded = false;

  /// Duty unlock (v1.2.5): password is app SESSION mein ek dafa durust
  /// likha gaya hai ya nahi. SIRF memory mein rehta hai — persisted
  /// NAHI hota, app band ho to dobara password lazmi hai.
  bool dutyUnlocked = false;

  // --- Backend (v1.1.0) ------------------------------------------------------

  /// Is phone ki mustaqil pehchan — pehli dafa banti hai, phir hamesha
  /// wohi rehti hai. Backend `devices` table ki key hai.
  String deviceId = '';

  /// Is phone ke driver ki backend pehchan (drivers table ki key) —
  /// pehli dafa banti hai, phir hamesha wohi rehti hai.
  String driverId = '';

  /// Passenger ko nazar ane wale zones — default local [kZones];
  /// backend `zones` table se band ilaqe is list se nikal jate hain
  /// (server na mile to local list hi chalti hai).
  List<String> zoneNames = List<String>.of(kZones);

  /// Backend sync hook — backend.dart app start par set karta hai.
  /// Har store action isay khamoshi se bulata hai; hook null ho ya
  /// fail ho jaye, local kaam par koi asar nahi padta. Kinds:
  /// 'booking' (Booking), 'package' (MonthlyPackage), 'txn' (WalletTxn),
  /// 'profile' (null — driver row mirror), 'selfie' (String yyyy-mm-dd),
  /// 'message' (MasterMessage — Master inbox push).
  void Function(String kind, Object? payload)? syncHook;

  void _hook(String kind, Object? payload) {
    try {
      syncHook?.call(kind, payload);
    } catch (_) {
      // Sync kabhi local flow ko nahi rok sakta.
    }
  }

  /// Backend se aye hue zones lagana (khali list = koi tabdeeli nahi).
  void applyServerZones(List<String> visible) {
    if (visible.isEmpty) return;
    zoneNames = visible;
    notifyListeners();
  }

  /// Master ne driver ko active kiya ya nahi — backend pull se ata hai.
  void setMasterActive(bool v) {
    profile.masterActive = v;
    unawaited(_persist());
    notifyListeners();
  }

  /// Driver ki taaza GPS jagah darj karna (v1.2.4) — Driver Mode ke
  /// position refresh, ride qubool aur navigation stream se bulta
  /// hai. Bilkul waisi hi purani value dobara aye to kuch nahi hota.
  /// Persist + notify ke saath 'profile' hook bhi chalta hai, taaki
  /// backend `drivers` row ke lat/lng bhi taza ho jayein.
  void setDriverPosition(double lat, double lng) {
    if (profile.lastLat == lat && profile.lastLng == lng) return;
    profile.lastLat = lat;
    profile.lastLng = lng;
    unawaited(_persist());
    notifyListeners();
    _hook('profile', null);
  }

  /// Update notice: checkForUpdate nayi version dekh le to true;
  /// dismissUpdate sirf is session ke liye banner chhupata hai.
  bool updateAvailable = false;
  bool updateDismissed = false;

  int _seq = 0;
  String newId() =>
      '${DateTime.now().millisecondsSinceEpoch}-${_seq++}';

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final b = prefs.getString('bookings');
    if (b != null) {
      bookings = (jsonDecode(b) as List)
          .map((e) => Booking.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    final m = prefs.getString('monthly');
    if (m != null) {
      monthlyPackages = (jsonDecode(m) as List)
          .map((e) => MonthlyPackage.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    final t = prefs.getString('txns');
    if (t != null) {
      txns = (jsonDecode(t) as List)
          .map((e) => WalletTxn.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    final p = prefs.getString('profile');
    if (p != null) {
      profile.loadJson(jsonDecode(p) as Map<String, dynamic>);
    }
    savedGhar = prefs.getString('place_ghar') ?? '';
    savedDaftar = prefs.getString('place_daftar') ?? '';
    passengerName = prefs.getString('passenger_name') ?? '';
    passengerPhone = prefs.getString('passenger_phone') ?? '';
    final mm = prefs.getString('master_messages');
    if (mm != null) {
      try {
        masterMessages = (jsonDecode(mm) as List)
            .map((e) => MasterMessage.fromJson(e as Map<String, dynamic>))
            .toList();
      } catch (_) {
        // Kharab cache — messages ki list taaza shuru.
        masterMessages = [];
      }
    }
    deviceId = prefs.getString('device_id') ?? '';
    driverId = prefs.getString('driver_id') ?? '';
    if (deviceId.isEmpty || driverId.isEmpty) {
      final rnd = Random();
      String gen(String prefix) =>
          '$prefix-${DateTime.now().millisecondsSinceEpoch}-${rnd.nextInt(0x7fffffff).toRadixString(16)}';
      if (deviceId.isEmpty) deviceId = gen('dev');
      if (driverId.isEmpty) driverId = gen('drv');
      loaded = true;
      await _persist();
    }
    loaded = true;
    notifyListeners();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        'bookings', jsonEncode(bookings.map((e) => e.toJson()).toList()));
    await prefs.setString('monthly',
        jsonEncode(monthlyPackages.map((e) => e.toJson()).toList()));
    await prefs.setString(
        'txns', jsonEncode(txns.map((e) => e.toJson()).toList()));
    await prefs.setString('profile', jsonEncode(profile.toJson()));
    await prefs.setString('place_ghar', savedGhar);
    await prefs.setString('place_daftar', savedDaftar);
    await prefs.setString('passenger_name', passengerName);
    await prefs.setString('passenger_phone', passengerPhone);
    await prefs.setString('master_messages',
        jsonEncode(masterMessages.map((e) => e.toJson()).toList()));
    await prefs.setString('device_id', deviceId);
    await prefs.setString('driver_id', driverId);
  }

  Future<void> save() async {
    await _persist();
    notifyListeners();
    // Driver row ka backend mirror (online toggle, profile edits,
    // wallet balance waghera sab is mein shamil hain).
    _hook('profile', null);
  }

  // --- Update notice ---------------------------------------------------------

  void dismissUpdate() {
    updateDismissed = true;
    notifyListeners();
  }

  /// App shuru hone par EK dafa, khamoshi se: GitHub release mein nayi
  /// version hai to banner ka flag on. Offline/error par bilkul khamosh —
  /// na error dikhta hai, na UI rukti hai.
  Future<void> checkForUpdate() async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = const Duration(seconds: 6);
      final req = await client
          .getUrl(Uri.parse(
              'https://api.github.com/repos/bozdarstudio/bozdar-safar/releases/tags/v1.0.0'))
          .timeout(const Duration(seconds: 6));
      req.headers.set(HttpHeaders.acceptHeader, 'application/vnd.github+json');
      final resp = await req.close().timeout(const Duration(seconds: 6));
      if (resp.statusCode != 200) return;
      final body =
          await resp.transform(utf8.decoder).join().timeout(
                const Duration(seconds: 6),
              );
      String? remote;
      final m = RegExp(r'Version:\s*(\d+\.\d+\.\d+)').firstMatch(body);
      if (m != null) {
        remote = m.group(1);
      } else {
        final j = jsonDecode(body) as Map<String, dynamic>;
        final tag = (j['tag_name'] as String? ?? '').replaceFirst('v', '');
        if (RegExp(r'^\d+\.\d+\.\d+$').hasMatch(tag)) remote = tag;
      }
      if (remote != null && versionIsNewer(remote, kAppVersion)) {
        updateAvailable = true;
        notifyListeners();
      }
    } catch (_) {
      // Khamosh — offline par kuch nahi hota.
    } finally {
      client?.close();
    }
  }

  // --- Passenger actions ----------------------------------------------------

  Future<void> addBooking(Booking b) async {
    bookings.insert(0, b);
    await save();
    _hook('booking', b);
  }

  Future<void> addMonthly(MonthlyPackage p) async {
    monthlyPackages.insert(0, p);
    await save();
    _hook('package', p);
  }

  // --- Master messages (v1.2.7) ----------------------------------------------

  /// Master ko naya message: pehle phone par mehfooz (aur sawari ka
  /// naam/mobile agli dafa ke liye yaad), phir 'message' hook se
  /// backend push. Offline ho to message queued rehta hai — backend
  /// sync agli app-khulne/sync par dobara koshish karta hai.
  Future<void> addMasterMessage(MasterMessage m) async {
    masterMessages.insert(0, m);
    if (m.senderRole == 'passenger') {
      if (m.senderName.trim().isNotEmpty) passengerName = m.senderName.trim();
      if (m.senderMobile.trim().isNotEmpty) {
        passengerPhone = m.senderMobile.trim();
      }
    }
    await _persist();
    notifyListeners();
    _hook('message', m);
  }

  /// Backend push kamyab — message ko "bheja gaya" darj karna (sirf
  /// persist + notify; dobara hook NAHI, warna fizool pushes honge).
  Future<void> markMessageSent(String id) async {
    final m = _messageById(id);
    if (m == null || m.sent) return;
    m.sent = true;
    await _persist();
    notifyListeners();
  }

  /// Master ne message parh liya ya nahi — backend pull se ati hai.
  Future<void> applyMessageRead(String id, bool read) async {
    final m = _messageById(id);
    if (m == null || m.isRead == read) return;
    m.isRead = read;
    await _persist();
    notifyListeners();
  }

  MasterMessage? _messageById(String id) {
    for (final m in masterMessages) {
      if (m.id == id) return m;
    }
    return null;
  }

  // --- Driver actions -------------------------------------------------------

  /// Returns null on success, or the Urdu reason the ride cannot be accepted.
  String? acceptBlockReason() {
    if (!profile.depositDone) {
      return 'Pehle Rs ${Fares.joiningDeposit} ka joining deposit darj karein — baghair deposit ride qubool nahi ho sakti.';
    }
    if (!profile.selfieToday) {
      return 'Aaj ki live selfie baqi hai — pehle selfie lein, phir ride qubool karein.';
    }
    return null;
  }

  Future<void> acceptBooking(Booking b) async {
    b.status = 'accepted';
    b.driverName = profile.name;
    await save();
    _hook('booking', b);
  }

  Future<void> markArrived(Booking b) async {
    b.status = 'arrived';
    b.arrivedAt = DateTime.now();
    await save();
    _hook('booking', b);
  }

  int liveWaitingMinutes(Booking b) {
    if (b.arrivedAt == null) return 0;
    return DateTime.now().difference(b.arrivedAt!).inMinutes;
  }

  int liveWaitingCharge(Booking b) {
    if (b.arrivedAt == null) return 0;
    return Fares.waitingCharge(b.vehicle, liveWaitingMinutes(b));
  }

  /// Completes the ride. Returns null on success, or the blocking reason.
  /// Wallet NEVER goes negative: if the service fee would take it below
  /// zero the completion is refused and nothing is recorded.
  Future<String?> completeBooking(Booking b) async {
    final mins = liveWaitingMinutes(b);
    final wCharge = Fares.waitingCharge(b.vehicle, mins);
    final fee = Fares.serviceFee(b.fare + wCharge);
    if (profile.walletBalance - fee < 0) {
      return 'Balance khatam — pehle deposit karein';
    }
    b.waitingMinutes = mins;
    b.waitingCharge = wCharge;
    b.status = 'completed';
    b.completedAt = DateTime.now();
    profile.walletBalance -= fee;
    final feeTxn = WalletTxn(
      id: newId(),
      type: 'fee',
      amount: fee,
      method: '',
      date: DateTime.now(),
      note:
          'Service charges ${fmtPct(Fares.feePercent)} — ride ${b.pickupLabel} → ${b.dropLabel} (kiraya + waiting)',
    );
    txns.insert(0, feeTxn);
    await save();
    _hook('booking', b);
    _hook('txn', feeTxn);
    return null;
  }

  /// No-show: allowed once total waiting reaches 10 minutes. Waiting charges
  /// are recorded on the booking.
  Future<String?> markNoShow(Booking b) async {
    final mins = liveWaitingMinutes(b);
    if (mins < 10) {
      return 'No-show ke liye kul 10 minute intezaar lazmi hai — abhi $mins minute hue hain.';
    }
    b.waitingMinutes = mins;
    b.waitingCharge = Fares.waitingCharge(b.vehicle, mins);
    b.status = 'noshow';
    b.completedAt = DateTime.now();
    await save();
    _hook('booking', b);
    return null;
  }

  Future<void> cancelBooking(Booking b) async {
    b.status = 'cancelled';
    await save();
    _hook('booking', b);
  }

  Future<void> addDeposit(int amount, String method) async {
    profile.walletBalance += amount;
    profile.totalDeposited += amount;
    if (profile.totalDeposited >= Fares.joiningDeposit) {
      profile.depositDone = true;
    }
    final depTxn = WalletTxn(
      id: newId(),
      type: 'deposit',
      amount: amount,
      method: method,
      date: DateTime.now(),
      note: 'Deposit — $method',
    );
    txns.insert(0, depTxn);
    await save();
    _hook('txn', depTxn);
  }

  Future<void> setSelfie(String path) async {
    final now = DateTime.now();
    profile.selfiePath = path;
    profile.selfieDate =
        '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    await save();
    _hook('selfie', profile.selfieDate);
  }

  /// Backend ne kis tareekh ki selfie tasveer upload kar li — sirf
  /// persist + notify ('profile' hook NAHI, warna fizool pushes
  /// chalte rahenge; drivers row par is ka koi asar nahi).
  Future<void> markSelfieUploaded(String date) async {
    if (profile.selfieUploadedDate == date) return;
    profile.selfieUploadedDate = date;
    await _persist();
    notifyListeners();
  }

  /// Ek registration document ki tasveer backend par upload ho gayi
  /// (v1.2.8) — [kind] ke liye wohi [localPath] darj ho jata hai jo
  /// upload hua tha. Sirf persist + notify ('profile' hook NAHI,
  /// warna fizool pushes chalte rahenge; drivers row par is ka path
  /// backend khud agle _pushDriver mein likh deta hai).
  Future<void> markDocUploaded(String kind, String localPath) async {
    if (profile.docUploaded[kind] == localPath) return;
    profile.docUploaded[kind] = localPath;
    await _persist();
    notifyListeners();
  }

  /// Master ki tasdeeq ki haalat backend se pull (v1.2.8) — sirf
  /// Profile ke display ke liye mehfooz hoti hai; koi gate, koi
  /// local toggle is se nahi badalta. 'rejected' bhi waisa hi
  /// mehfooz hota hai aur Profile mein saaf nazar ata hai.
  Future<void> applyMasterDocStatuses({
    required String cnic,
    required String gaari,
    required String licence,
  }) async {
    if (profile.masterCnicStatus == cnic &&
        profile.masterGaariStatus == gaari &&
        profile.masterLicenceStatus == licence) {
      return;
    }
    profile.masterCnicStatus = cnic;
    profile.masterGaariStatus = gaari;
    profile.masterLicenceStatus = licence;
    await _persist();
    notifyListeners();
  }
}
