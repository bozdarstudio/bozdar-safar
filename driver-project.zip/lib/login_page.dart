import 'dart:async';
import 'package:flutter/material.dart';
import 'backend.dart';
import 'lang.dart';
import 'otp.dart';
import 'store.dart';
import 'theme.dart';

/// DRIVER LOGIN (v1.4.47 — malik ka hukm 2026-11-22): maujooda
/// account walon ke liye saaf, numaya login darwaza — khaas
/// taur par naye phone par, jahan pehle banda majbooran
/// registration form mein phans jata tha (malik khud phansa
/// tha)।
///
/// LOGIN REPAIR 2 (2026-11-22): Master ke seedha banaye hue
/// records (drivers table mein maujood, email/identity link
/// abhi NAHI — maslan pehla asal driver Muhammad Shahzad)
/// Gmail login ke baad bhi NAHI milte the: banda registration
/// form mein ja girta tha aur wahan CNIC duplicate check use
/// rok deta tha। Ab tartib ye hai — session se PEHLE koi
/// drivers-table talash NAHI hoti (woh RLS se band hai);
/// saari talash Gmail OTP verify ke BAAD, session ke saath:
///  (a) email / identity_links se bandha hua record
///      (Backend.recoverDriverRowByEmail — purana rasta),
///  (b) shuru mein likha hua mobile number mehfooz rakha
///      jata hai; verify ke baad SECURITY DEFINER RPC
///      `find_driver_for_login` se us number ka record,
///  (c) phir bhi na mile to ISI screen par Master mein darj
///      mobile number / CNIC likhne ka khana — RPC se mile
///      to wohi purana record apnaya jata hai
///      (store.adoptRecoveredDriver), NAYI registration
///      NAHI banti।
/// Har talash khaali jaye tab hi registration ka rasta
/// pesh hota hai (waqai naye driver ke liye)।
class DriverLoginPage extends StatefulWidget {
  final AppStore store;

  const DriverLoginPage({super.key, required this.store});

  @override
  State<DriverLoginPage> createState() => _DriverLoginPageState();
}

class _DriverLoginPageState extends State<DriverLoginPage> {
  // 0 = mobile rasta, 1 = Gmail rasta।
  int _mode = 0;

  final _mobileCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _manualMobileCtrl = TextEditingController();
  final _manualCnicCtrl = TextEditingController();

  bool _busy = false;
  String? _error;
  bool _showRegister = false;

  // Mobile raste ka pehla qadam: number mehfooz — OTP Gmail
  // par jayega, lekin verify ke baad record ISI number se
  // RPC ke zariye dhoondha jayega (qadam b)।
  bool _mobileDone = false;
  String _rememberedMobile = '';

  // OTP verify ho chuki Gmail — (c) wale khane ki talash aur
  // adopt isi pehchan ke saath hote hain।
  String _verifiedEmail = '';

  // (c) wala khana: (a) aur (b) khaali jayein to dikhta hai।
  bool _showManual = false;

  @override
  void dispose() {
    _mobileCtrl.dispose();
    _emailCtrl.dispose();
    _manualMobileCtrl.dispose();
    _manualCnicCtrl.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  // --- Mobile raste ka pehla qadam --------------------------------------------

  /// Number sirf MEHFOOZ hota hai — yahan koi server talash
  /// NAHI hoti (session abhi hai hi nahi, aur table parhai
  /// RLS se band hai)। Asal talash OTP verify ke baad RPC
  /// se hogi।
  void _rememberMobile() {
    final digits = _mobileCtrl.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.length < 10) {
      setState(() => _error = tr('login_mobile_short'));
      return;
    }
    setState(() {
      _rememberedMobile = digits;
      _mobileDone = true;
      _error = null;
      _showRegister = false;
    });
  }

  // --- OTP verify ke baad ki talash (a) → (b) → (c) ----------------------------

  Future<void> _afterVerified(String email) async {
    setState(() {
      _busy = true;
      _error = null;
      _showRegister = false;
      _verifiedEmail = email;
    });
    // (a) email / identity_links se bandha hua record।
    var row = await Backend.recoverDriverRowByEmail(email);
    // (b) mehfooz mobile number par RPC talash (Master ke
    // seedha banaye hue records ke liye asal rasta)।
    if (row == null && _rememberedMobile.isNotEmpty) {
      row = await Backend.findDriverViaRpc(mobile: _rememberedMobile);
    }
    if (!mounted) return;
    if (row != null) {
      await _adopt(row, email);
      return;
    }
    // (c) haath se number/CNIC likhne ka khana — number
    // pehle se bhara milega taake banda sirf CNIC jod sake।
    setState(() {
      _busy = false;
      _showManual = true;
      if (_manualMobileCtrl.text.trim().isEmpty &&
          _rememberedMobile.isNotEmpty) {
        _manualMobileCtrl.text = _rememberedMobile;
      }
    });
  }

  Future<void> _manualLookup() async {
    if (_verifiedEmail.isEmpty) return;
    final m = _manualMobileCtrl.text.replaceAll(RegExp(r'[^0-9]'), '');
    final c = _manualCnicCtrl.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (m.isEmpty && c.isEmpty) {
      setState(() => _error = tr('login_manual_empty'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
      _showRegister = false;
    });
    final row = await Backend.findDriverViaRpc(
        mobile: m.isEmpty ? null : m, cnic: c.isEmpty ? null : c);
    if (!mounted) return;
    if (row == null) {
      // Har talash khaali — ab hi registration ka rasta
      // pesh hota hai; khana khula rehta hai taake ghalti
      // durust karke dobara koshish ho sake।
      setState(() {
        _busy = false;
        _error = tr('login_not_found_final');
        _showRegister = true;
      });
      return;
    }
    await _adopt(row, _verifiedEmail);
  }

  // --- Apnana (adopt) -----------------------------------------------------------

  Future<void> _adopt(Map<String, dynamic> row, String email) async {
    await widget.store.adoptRecoveredDriver(row, email);
    // OTP tasdeeq isi flow mein abhi hui hai — session flag bhi
    // abhi lagao, warna pehli duty-on par app dobara OTP mangegi
    // (malik ka hukm 2026-11-22: ek dafa login = wahin mehfooz)।
    await widget.store.applyDriverEmailVerified(email);
    // Pehchan bandhna (identity_links) — maujooda mechanism,
    // khamosh best-effort।
    unawaited(Backend.linkIdentities(widget.store));
    if (!mounted) return;
    setState(() => _busy = false);
    _snack(tr('login_success'));
    Navigator.of(context).pop(true);
  }

  // --- UI ---------------------------------------------------------------------

  Widget _modeButton(int mode, IconData icon, String label) {
    final selected = _mode == mode;
    return Expanded(
      child: SizedBox(
        height: 48,
        child: selected
            ? ElevatedButton.icon(
                onPressed: null,
                icon: Icon(icon, size: 19),
                label: Text(label,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              )
            : OutlinedButton.icon(
                onPressed: _busy
                    ? null
                    : () => setState(() {
                          _mode = mode;
                          _error = null;
                          _showRegister = false;
                        }),
                icon: Icon(icon, size: 19),
                label: Text(label,
                    style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('login_heading'))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.login, size: 60, color: Brand.green),
          const SizedBox(height: 10),
          Text(
            tr('login_heading'),
            textAlign: TextAlign.center,
            style:
                const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 6),
          Text(
            tr('login_sub'),
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 13.5,
                height: 1.45,
                color: Theme.of(context).colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              _modeButton(0, Icons.phone_android, tr('login_tab_mobile')),
              const SizedBox(width: 10),
              _modeButton(1, Icons.email, tr('login_tab_gmail')),
            ],
          ),
          const SizedBox(height: 18),
          if (_mode == 0) ..._mobileSection(),
          if (_mode == 1) ..._gmailSection(),
          if (_showManual) ..._manualSection(),
          if (_error != null) ...[
            const SizedBox(height: 14),
            Text(
              _error!,
              style: const TextStyle(
                  color: Colors.red,
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                  height: 1.45),
            ),
          ],
          if (_showRegister) ...[
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () => Navigator.of(context).pop(false),
              icon: const Icon(Icons.app_registration, size: 19),
              label: Text(tr('login_go_register')),
            ),
          ],
          if (_busy) ...[
            const SizedBox(height: 16),
            const Center(child: CircularProgressIndicator()),
          ],
        ],
      ),
    );
  }

  List<Widget> _mobileSection() {
    if (!_mobileDone) {
      return [
        TextField(
          controller: _mobileCtrl,
          keyboardType: TextInputType.phone,
          decoration: InputDecoration(
            labelText: tr('login_mobile_label'),
            hintText: tr('login_mobile_hint'),
            prefixIcon: const Icon(Icons.phone_android),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          height: 50,
          child: ElevatedButton.icon(
            onPressed: _busy ? null : _rememberMobile,
            icon: const Icon(Icons.arrow_forward, size: 19),
            label: Text(tr('login_continue_btn'),
                style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
        ),
      ];
    }
    return [
      Text(
        tr('login_mobile_note'),
        style: const TextStyle(fontSize: 13.5, height: 1.45),
      ),
      Align(
        alignment: Alignment.centerLeft,
        child: TextButton(
          onPressed: _busy
              ? null
              : () => setState(() {
                    _mobileDone = false;
                    _error = null;
                  }),
          child: Text(tr('login_change_number')),
        ),
      ),
      const SizedBox(height: 6),
      // Wohi maujooda EmailOtpSection — Gmail par OTP bhejna
      // aur tasdeeq karna usi ka kaam hai; verify kamyab ho
      // to mehfooz number se record ki talash shuru hoti hai।
      EmailOtpSection(
        emailCtrl: _emailCtrl,
        onVerified: (email) => unawaited(_afterVerified(email)),
      ),
    ];
  }

  List<Widget> _gmailSection() {
    return [
      // Wohi maujooda EmailOtpSection jo registration aur
      // login gates mein chalti hai — code bhejna/verify
      // karna usi ka kaam hai; verify kamyab ho to bandha
      // hua driver record apnaya jata hai, na mile to neeche
      // Master wala number/CNIC likhne ka khana khulta hai।
      EmailOtpSection(
        emailCtrl: _emailCtrl,
        onVerified: (email) => unawaited(_afterVerified(email)),
      ),
    ];
  }

  List<Widget> _manualSection() {
    return [
      const SizedBox(height: 20),
      const Divider(),
      const SizedBox(height: 12),
      Text(
        tr('login_manual_intro'),
        style: const TextStyle(fontSize: 13.5, height: 1.45),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _manualMobileCtrl,
        keyboardType: TextInputType.phone,
        decoration: InputDecoration(
          labelText: tr('login_master_mobile_label'),
          prefixIcon: const Icon(Icons.phone_android),
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _manualCnicCtrl,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: tr('login_cnic_label'),
          hintText: tr('login_cnic_hint'),
          prefixIcon: const Icon(Icons.badge_outlined),
        ),
      ),
      const SizedBox(height: 12),
      SizedBox(
        width: double.infinity,
        height: 50,
        child: ElevatedButton.icon(
          onPressed: _busy ? null : _manualLookup,
          icon: const Icon(Icons.search, size: 19),
          label: Text(tr('login_find_record_btn'),
              style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      ),
    ];
  }
}
