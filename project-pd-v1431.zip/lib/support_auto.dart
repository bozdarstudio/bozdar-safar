import 'store.dart';

/// SUPPORT AUTO-JAWAB (v1.4.7, spec §4 — malik ke tayyar jumle)।
///
/// Teen layers wala support: (1) APP ke ye khud-kar tayyar jawab —
/// koi AI nahi, koi credit nahi; (2) jahan driver/sawari phans
/// jaye wahan assistant khud Master ki taraf se baat karke masla
/// hal karta hai (owner ki saaf ijazat 2026-11-08 23:25); (3)
/// Master khud। Ye engine sirf PEHLI layer hai।
///
/// HUDOOD (malik ka lock): app koi PERSONAL detail NAHI batati —
/// na kisi ka number, na CNIC, na kisi aur ki maloomat। Apne
/// documents ki haalat jaisi APNI maloomat jaiz hai। Koi
/// ulti-seedhi baat nahi। Badtameezi par pehle WARNING — block ka
/// faisla Master ke paas rehta hai।
///
/// Har auto jawab `messages` table mein sender_role='auto' ke
/// saath jata hai taaki Master ko bhi nazar aye ke app ne kya
/// jawab diya — koi baat Master se chhupi nahi rehti।
class SupportAuto {
  /// Har support thread ka PEHLA khud-kar message (malik ka final
  /// jumla, 2026-11-08 23:24)।
  static const String greeting =
      'Assalam-o-Alaikum bhai! Bozdar Safar app mein aap ko khush-aamdeed — welcome. Ji bhai farmaiye, hum aap ki kaise madad kar sakte hain? Aap ki kya problem hai?';

  /// Pehle message par tasalli wala jawab।
  static const String ack =
      'Aap ka message Master tak pahuncha diya gaya hai — aap ko boht jald jawab mil jaye ga.';

  /// Badtameezi par warning (malik ka final jumla)।
  static const String warningLine =
      'Badtameezi na karein, warna aap ki ID block kar di jayegi';

  static const String _senderName = 'Bozdar Safar (Auto)';

  /// Badtameezi ki pehchan — Roman Urdu + Urdu script ke aam
  /// alfaz। Ye sirf WARNING ke liye hai; block Master karta hai।
  static const List<String> _abuseWords = [
    'gali', 'bakwas', 'bewakoof', 'bewaqoof', 'ullu', 'gadha',
    'kutta', 'kamina', 'harami', 'lanat', 'sharam karo', 'chor ho',
    'fraud hai', 'dhokha', 'بکواس', 'گالی', 'حرامی', 'کمینہ',
  ];

  static bool _hasAbuse(String body) {
    final b = body.toLowerCase();
    return _abuseWords.any((w) => b.contains(w));
  }

  static bool _hit(String body, List<String> words) {
    final b = body.toLowerCase();
    return words.any((w) => b.contains(w));
  }

  /// Ek auto jawab thread mein darj karna — MasterMessage ki
  /// aam shakal mein (hook se backend push khud ho jata hai)।
  static Future<void> _post(
    AppStore store,
    MasterMessage userMsg,
    String body, {
    DateTime? at,
    String category = 'Auto Jawab',
  }) async {
    await store.addMasterMessage(MasterMessage(
      id: store.newId(),
      senderKey: userMsg.senderKey,
      senderRole: 'auto',
      senderName: _senderName,
      senderMobile: userMsg.senderMobile,
      senderZone: userMsg.senderZone,
      category: category,
      body: body,
      isRead: true,
      createdAt: at ?? DateTime.now(),
    ));
  }

  static String _statusUrdu(String s) => switch (s) {
        'verified' => 'Tasdeeq ho gayi hai',
        'rejected' => 'Reject ho gaya hai',
        'pending' => 'Intezaar mein hai (Master check kar raha hai)',
        _ => 'Abhi maloom nahi',
      };

  /// Driver ke apne documents ki haalat wala tayyar jawab —
  /// reject par WAJAH ke saath (spec §4)। Ye driver ki APNI
  /// maloomat hai, kisi aur ki nahi — hudood ke andar hai।
  static String _docStatusAnswer(AppStore store) {
    final p = store.profile;
    final buf = StringBuffer('Aap ke documents ki mojooda haalat ye hai:\n');
    buf.writeln('• CNIC: ${_statusUrdu(p.masterCnicStatus)}');
    if (p.masterCnicStatus == 'rejected' && p.masterCnicReason.isNotEmpty) {
      buf.writeln('  Wajah: ${p.masterCnicReason}');
    }
    buf.writeln('• Gaari ke kaghaz: ${_statusUrdu(p.masterGaariStatus)}');
    if (p.masterGaariStatus == 'rejected' && p.masterGaariReason.isNotEmpty) {
      buf.writeln('  Wajah: ${p.masterGaariReason}');
    }
    buf.writeln('• Licence: ${_statusUrdu(p.masterLicenceStatus)}');
    if (p.masterLicenceStatus == 'rejected' &&
        p.masterLicenceReason.isNotEmpty) {
      buf.writeln('  Wajah: ${p.masterLicenceReason}');
    }
    // v1.4.19 SAKHT GATE: teeno naye lazmi kagaz bhi jawab mein —
    // reject par wajah + woh rehnumai bhi jo kagaz poora karne
    // ka rasta dikhati hai (malik ka hukm 2026-11-10 ~18:12)।
    buf.writeln(
        '• Fitness Certificate: ${_statusUrdu(p.masterFitnessStatus)}');
    if (p.masterFitnessStatus == 'rejected' &&
        p.masterFitnessReason.isNotEmpty) {
      buf.writeln('  Wajah: ${p.masterFitnessReason}');
    }
    if (p.masterFitnessStatus != 'verified') {
      buf.writeln('  $kFitnessRehnumai');
    }
    buf.writeln(
        '• Gaari ki Insurance: ${_statusUrdu(p.masterInsuranceStatus)}');
    if (p.masterInsuranceStatus == 'rejected' &&
        p.masterInsuranceReason.isNotEmpty) {
      buf.writeln('  Wajah: ${p.masterInsuranceReason}');
    }
    if (p.masterInsuranceStatus != 'verified') {
      buf.writeln('  $kInsuranceRehnumai');
    }
    buf.writeln(
        '• Police Character Certificate: ${_statusUrdu(p.masterCharacterStatus)}');
    if (p.masterCharacterStatus == 'rejected' &&
        p.masterCharacterReason.isNotEmpty) {
      buf.writeln('  Wajah: ${p.masterCharacterReason}');
    }
    if (p.masterCharacterStatus != 'verified') {
      buf.writeln('  $kCharacterRehnumai');
    }
    buf.write(
        'Jo document reject hua ho, us ki saaf aur sahi photo Profile ke "Mere Kagaz" hisse se dobara bhej dein — Master dobara check karke jawab de dega।');
    return buf.toString();
  }

  /// Aam sawalon ke tayyar jawab — pehchan body ke alfaz se।
  /// Jawab na mile to null (us surat mein sirf greeting/ack jata
  /// hai aur baat Master/assistant par rehti hai)।
  static String? _faqAnswer(AppStore store, MasterMessage m) {
    final b = m.body;
    final isDriver = m.senderRole == 'driver';

    if (_hit(b, ['sos', 'madad karo', 'emergency', 'accident', 'hadsa'])) {
      // v1.4.25 (postmortem #7): pehle yahan jhoota dawa tha ke
      // "Master ko alert FORAN bhej diya gaya" — asal mein koi
      // fori alert nahi jata; ye message Master ke INBOX mein
      // jata hai aur woh app kholne par dekhta hai. Ab wohi
      // likha hai jo asal hai, aur asal emergency ka pehla
      // qadam (1122) sab se pehle bataya jata hai।
      return 'Allah khair kare — sab se pehle shadeed emergency mein 1122 par call karein. Aap ka ye message Master ke inbox mein ja raha hai: woh jab app kholenge to yahin aap ko jawab denge (ye fori phone-alert wala nizaam abhi nahi hai). Aap mehfooz jagah par rahein.';
    }
    if (_hit(b, ['rate', 'kiraya', 'rent', 'per km', 'charge kya', 'ریٹ', 'کرایہ'])) {
      return 'Bozdar Safar ke rates (har rate asal sadak ke har kilometre par): Bike Rs ${Fares.perKm['Bike']}/km, Rickshaw Rs ${Fares.perKm['Rickshaw']}/km, Car Rs ${Fares.perKm['Car']}/km, Taxi Rs ${Fares.perKm['Taxi']}/km, Van Rs ${Fares.perKm['Van']}/km. Waiting: pehle ${Fares.freeWaitingMinutes} minute bilkul FREE, us ke baad har minute Bike Rs ${Fares.waitingPerMin['Bike']}, Rickshaw Rs ${Fares.waitingPerMin['Rickshaw']}, Car Rs ${Fares.waitingPerMin['Car']}, Taxi Rs ${Fares.waitingPerMin['Taxi']}, Van Rs ${Fares.waitingPerMin['Van']}. Koi chhupa charge NAHI hai — kiraya = rate × asal sadak kilometre, aur har ride ka kam se kam kiraya Rs ${Fares.minFareRs} hai (chhoti ride par bhi).';
    }
    if (_hit(b, ['fee', 'commission', 'tax', 'percent', 'katoti', 'فی', 'کمیشن'])) {
      return isDriver
          ? 'Driver bhai, service fee sirf ${Fares.feePercent.toStringAsFixed(0)}% hai — har mukammal ride ki kamai ka ${Fares.feePercent.toStringAsFixed(0)}%. App bilkul FREE hai — koi joining charge NAHI. Fee aap ko alag se bhejni NAHI padti: woh aap ke Rs ${Fares.joiningDeposit} Amanat Deposit mein se khud kat jati hai. Deposit aap apne Easypaisa ya JazzCash account se Raast 0312 2635002 par bhejte hain — wasool honay par Master darj kar deta hai. Balance khatam ho to dobara top-up karna aap ki marzi hai, koi zabardasti NAHI.'
          : 'Bozdar Safar mein sawari se koi extra charge nahi liya jata — aap sirf apna kiraya (rate × asal sadak kilometre, kam se kam Rs ${Fares.minFareRs}) aur waiting (pehle ${Fares.freeWaitingMinutes} minute free) dete hain.';
    }
    if (_hit(b, ['password', 'bhool gaya', 'bhool gaye', 'login nahi', 'پاس ورڈ'])) {
      return 'Agar aap apna password bhool gaye hain to ghabrayein nahi. Master pehle aap ki pehchan ki tasdeeq karega (aap ka registered number aur naam), phir aap ko ek AARZI (temporary) password milega — pehli login par aap ko apna naya password lazmi lagana hoga. Ek zaroori baat: asal password kahin save NAHI hota, is liye purana password kisi ko maloom nahi ho sakta — ye aap ki hifazat ke liye hai.';
    }
    if (_hit(b, ['deposit', 'jama', 'ڈپازٹ'])) {
      return 'Deposit aap ki apni AMANAT hai — sirf Rs ${Fares.joiningDeposit}. Jama karne ke liye apne Easypaisa ya JazzCash account se Raast ke zariye 0312 2635002 par bhejein; wasool honay par Master darj kar dega. Har mukammal ride ki ${Fares.feePercent.toStringAsFixed(0)}% service fee isi deposit balance se khud kat ti hai — fee alag se bhejni NAHI padti, aur hafte ke aakhir mein bhejne wala purana nizaam khatam ho gaya hai. Ye raqam fees ke ilawa kisi kaam mein istemal NAHI hoti; balance khatam ho to dobara top-up karna aap ki marzi hai, koi zabardasti NAHI — aur kaam chhorne par aap ki baqi amanat aap ko wapas milti hai.';
    }
    if (_hit(b, ['tasdeeq', 'document', 'kagaz', 'kaghaz', 'reject', 'status kya', 'تصدیق', 'کاغذ'])) {
      if (isDriver) return _docStatusAnswer(store);
      return 'Aap ki baat Master tak pahuncha di gayi hai — Master check karke aap ko yahin jawab de dega.';
    }
    if (_hit(b, ['registration', 'register', 'id bane', 'id banani', 'driver banna', 'رجسٹریشن'])) {
      return 'Driver ID banane ke qadam: (1) Mobile number, (2) Naam + CNIC number aur CNIC ki dono photos, (3) Gmail aur us par aya hua OTP code, (4) Apna password, (5) Gaari ki tafseel — chaaron taraf ki photos, number plate saaf nazar aye, aur gaari ke kaghaz, (6) Live selfie, (7) Apna sheher. Phir Master aap ke kagaz check karke ID Active karta hai. Licence OPTIONAL hai — na ho to bhi ID ban sakti hai.';
    }
    if (_hit(b, ['shikayat', 'complaint', 'شکایت']) ||
        m.category == 'Driver ki shikayat' ||
        m.category == 'Sawari ki shikayat') {
      return 'Aap ki shikayat darj kar li gayi hai aur Master tak pahuncha di gayi hai — Master jald check karke aap ko yahin jawab dega. Shikayat ka record mehfooz rehta hai.';
    }
    if (_hit(b, ['email', 'gmail', 'otp', 'code nahi aya', 'ای میل'])) {
      return 'Email OTP ke liye: (1) Apni sahi Gmail likhein — code usi par jata hai, (2) Spam/Promotions folder bhi check karein, (3) Code chand minute mein ata hai — purana code dobara istemal nahi hota, naya code mangwayein. Email hi galat ho to Master pehchan ki tasdeeq ke baad use theek kar dega — yahin message kar dein.';
    }
    if (isDriver &&
        _hit(b, ['gaari change', 'gari change', 'gaari badal', 'gari badal', 'plate change'])) {
      return 'Gaari change karne ke liye Profile mein "Gaari Change Karein" par jayein — nayi gaari ki poori tafseel, chaaron taraf ki photos, kaghaz aur live selfie dobara lazmi hai. Master tasdeeq kare to aap ki wohi ID nayi gaari par update ho jayegi — nayi ID NAHI bane gi.';
    }
    return null;
  }

  /// User ka message jane ke baad engine chalti hai — tartib:
  /// (1) pehli dafa ho to GREETING (us message se ek second pehle
  /// ki muddat par, taaki thread mein sab se pehle dikhe),
  /// (2) pehle message par ACK tasalli,
  /// (3) badtameezi par WARNING,
  /// (4) aam sawal ho to FAQ ka tayyar jawab।
  /// Engine kabhi exception nahi phenkti — support baat is par
  /// kabhi nahi rukti।
  static Future<void> onUserMessage(AppStore store, MasterMessage m) async {
    try {
      final key = m.senderKey;
      final threadMine = store.masterMessages
          .where((x) =>
              x.senderKey == key &&
              (x.senderRole == 'driver' || x.senderRole == 'passenger'))
          .length;
      final isFirst = threadMine <= 1;

      if (!store.supportGreetedKeys.contains(key)) {
        // Set pehle badlo — _post ke addMasterMessage ka _persist
        // isay bhi mehfooz kar dega (alag save ki zaroorat nahi)।
        store.supportGreetedKeys.add(key);
        await _post(store, m, greeting,
            at: m.createdAt.subtract(const Duration(seconds: 1)));
      }
      if (isFirst) {
        await _post(store, m, ack);
      }
      if (_hasAbuse(m.body)) {
        store.supportWarnCount += 1;
        await _post(
          store,
          m,
          store.supportWarnCount > 1
              ? '$warningLine. (Ye warning number ${store.supportWarnCount} hai — block ka faisla Master ke paas hai.)'
              : warningLine,
          category: 'Auto Warning',
        );
        return; // Badtameezi wale message par FAQ jawab nahi jata।
      }
      final faq = _faqAnswer(store, m);
      if (faq != null) {
        await _post(store, m, faq);
      }
    } catch (_) {
      // Auto jawab na bane to bhi asal message Master tak gaya
      // hai — engine khamoshi se peeche hat jati hai।
    }
  }
}
