import 'dart:async';
import 'package:flutter/material.dart';
import 'store.dart';
import 'theme.dart';
import 'backend.dart';
import 'support_auto.dart';

/// Madad — Master se CHAT (v1.2.7 se; LIVE CHAT owner 2026-11-08):
/// sawari ho ya driver, koi masla ya shikayat ho to is screen se
/// seedha Master (head) se baat hoti hai — SUPPORT KA EK HI
/// DARWAZA yahi hai, koi alag support/team NAHI hai.
///
/// Chat ASAL thread hai: mere bheje hue messages AUR Master ke
/// jawab (backend messages table ki sender_role='master' rows —
/// sender_key meri apni key par; PROTOCOL Master app ke saath
/// mushtarka hai) ek hi thread mein waqt ki tartib se ate hain,
/// Master ki baat alag rang/side par. Khuli chat har ~9 second
/// khud refresh hoti hai (Backend.syncMessages → fetchMyThread)
/// taaki Master ka jawab khud aa jaye. Message pehle phone par
/// mehfooz hota hai, phir backend se Master app tak puhancta
/// hai — offline ho to queued rehta hai aur internet ate hi khud
/// chala jata hai.
class MasterMessagesScreen extends StatefulWidget {
  final AppStore store;

  /// 'driver' | 'passenger' — kis mode se khuli hai.
  final String role;
  const MasterMessagesScreen(
      {super.key, required this.store, required this.role});

  @override
  State<MasterMessagesScreen> createState() => _MasterMessagesScreenState();
}

class _MasterMessagesScreenState extends State<MasterMessagesScreen> {
  final _nameCtrl = TextEditingController();
  final _mobileCtrl = TextEditingController();
  final _bodyCtrl = TextEditingController();
  String _category = kMessageCategories.first;
  bool _sending = false;

  /// LIVE CHAT auto-refresh — chat khuli ho to har ~9s Master ke
  /// naye jawab pull hote hain; dispose par lazmi band.
  Timer? _chatTimer;

  AppStore get store => widget.store;
  bool get _isDriver => widget.role == 'driver';

  /// Is role ki pehchan — backend `messages.sender_key`:
  /// driver = driverId, sawari = deviceId.
  String get _senderKey => _isDriver ? store.driverId : store.deviceId;

  /// Is role ka zone (driver ka profile zone; sawari ka zone maloom
  /// nahi hota — khaali rehta hai, jhooti value nahi jati).
  String get _zone => _isDriver ? store.profile.zone : '';

  @override
  void initState() {
    super.initState();
    if (_isDriver) {
      _nameCtrl.text = store.profile.name;
      _mobileCtrl.text = store.profile.phone;
    } else {
      // Sawari: pehle se yaad naam/mobile; na ho to aakhri booking
      // wali maloomat se bhar dete hain (fields phir bhi badle ja
      // sakte hain).
      var name = store.passengerName;
      var mobile = store.passengerPhone;
      if ((name.isEmpty || mobile.isEmpty) && store.bookings.isNotEmpty) {
        final b = store.bookings.first;
        if (name.isEmpty) name = b.passengerName;
        if (mobile.isEmpty) mobile = b.passengerPhone;
      }
      _nameCtrl.text = name;
      _mobileCtrl.text = mobile;
    }
    // Khulte hi: queued messages ki dobara koshish + poora
    // thread pull (apne + Master ke jawab), phir is key ke jawab
    // "parhe hue" — unread badge saaf.
    unawaited(_refreshThread(markSeen: true));
    // LIVE CHAT: har ~9 second khud refresh — Master ka jawab
    // chat khuli ho to khud aa jata hai; chat khuli hai matlab
    // jawab parha hua hi mana jata hai (badge nahi banta).
    _chatTimer = Timer.periodic(const Duration(seconds: 9), (_) {
      unawaited(_refreshThread(markSeen: true));
    });
  }

  /// Thread taaza karna — syncMessages ke andar fetchMyThread
  /// Master ke jawab bhi le ata hai. Har nakami khamosh (chat
  /// local list par chalti rehti hai).
  Future<void> _refreshThread({bool markSeen = false}) async {
    await Backend.syncMessages(store);
    if (markSeen) await store.markMasterRepliesSeen(_senderKey);
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _chatTimer?.cancel();
    _nameCtrl.dispose();
    _mobileCtrl.dispose();
    _bodyCtrl.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _send() async {
    final name = _nameCtrl.text.trim();
    final mobile = _mobileCtrl.text.trim();
    final body = _bodyCtrl.text.trim();
    if (name.isEmpty) {
      _snack('Apna naam likhein.');
      return;
    }
    if (mobile.isEmpty) {
      _snack('Apna mobile number likhein.');
      return;
    }
    if (body.isEmpty) {
      _snack('Message likhein — kya masla hai?');
      return;
    }
    setState(() => _sending = true);
    final m = MasterMessage(
      id: store.newId(),
      senderKey: _senderKey,
      senderRole: widget.role,
      senderName: name,
      senderMobile: mobile,
      senderZone: _zone,
      category: _category,
      body: body,
      createdAt: DateTime.now(),
    );
    // Store mein daalte hi 'message' hook backend push shuru kar deta
    // hai (best-effort); offline ho to queued rehta hai.
    await store.addMasterMessage(m);
    // v1.4.7 SUPPORT AUTO-JAWAB (spec §4): greeting (thread par sirf
    // pehli dafa) + tasalli + aam sawalon ke tayyar jawab + badtameezi
    // par warning — sab sender_role='auto' ke saath thread mein bhi
    // jate hain aur Master ko bhi nazar ate hain. Engine khud
    // exception-proof hai.
    await SupportAuto.onUserMessage(store, m);
    if (!mounted) return;
    setState(() {
      _sending = false;
      _bodyCtrl.clear();
    });
    _snack('Aap ka message Master tak bhej diya gaya hai');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Madad — Master se Chat'),
        actions: [
          IconButton(
            tooltip: 'Chat refresh karein',
            icon: const Icon(Icons.refresh),
            onPressed: () => unawaited(_refreshThread(markSeen: true)),
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          // ASAL THREAD: meri key ki saari rows — mere messages
          // (driver/passenger role) + Master ke jawab (master
          // role) — waqt ki tartib mein (purana upar, naya neeche).
          final thread = store.masterMessages
              .where((m) => m.senderKey == _senderKey)
              .toList()
            ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
          return ListView(
            padding: const EdgeInsets.all(14),
            children: [
              const Text(
                'Koi masla, shikayat ya baat ho — yahan likhein, baat seedha Master se hogi aur Master ka jawab bhi yahin chat mein ayega.',
                style: TextStyle(fontSize: 13, color: Colors.black54),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _category,
                decoration: const InputDecoration(labelText: 'Masle ki qisam'),
                items: kMessageCategories
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) =>
                    setState(() => _category = v ?? _category),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _nameCtrl,
                decoration: const InputDecoration(labelText: 'Aap ka naam'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _mobileCtrl,
                keyboardType: TextInputType.phone,
                decoration:
                    const InputDecoration(labelText: 'Mobile number'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _bodyCtrl,
                minLines: 4,
                maxLines: 7,
                decoration: const InputDecoration(
                  labelText: 'Message',
                  hintText: 'Apna masla tafseel se likhein…',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _sending ? null : _send,
                  icon: const Icon(Icons.send),
                  label:
                      Text(_sending ? 'Bhej raha hai…' : 'Message Bhejein'),
                ),
              ),
              const SizedBox(height: 20),
              const Text('Master se Chat',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              if (thread.isEmpty)
                const Text(
                  'Abhi koi baat nahi hui — pehla message upar se bhejein, Master ka jawab yahin ayega.',
                  style: TextStyle(color: Colors.black54),
                )
              else
                ...thread.map(_chatBubble),
            ],
          );
        },
      ),
    );
  }

  /// Thread ka ek bubble: Master ka jawab BAYEIN taraf sunehri/
  /// cream rang mein 'Master' label ke saath; mera apna message
  /// DAYEIN taraf sabz mein, neeche us ki haalat (bheja gaya /
  /// Master ne parh liya / abhi queued hai).
  Widget _chatBubble(MasterMessage m) {
    final isMaster = m.senderRole == 'master';
    final time = '${fmtDate(m.createdAt)} ${fmtTime(m.createdAt)}';
    if (m.senderRole == 'auto') {
      // v1.4.7: app ka khud-kar tayyar jawab — Master wale bubble
      // se alag halka neela/grey rang, 'Bozdar Safar (Auto)' label
      // ke saath taaki user ko saaf pata ho ye khud-kar jawab hai.
      return Align(
        alignment: Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10, right: 46),
          padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
          decoration: BoxDecoration(
            color: const Color(0xFFEDF2F7),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(14),
              topRight: Radius.circular(14),
              bottomRight: Radius.circular(14),
              bottomLeft: Radius.circular(3),
            ),
            border: Border.all(color: const Color(0xFFB0BEC5), width: 1.0),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.smart_toy_outlined,
                      size: 14, color: Color(0xFF546E7A)),
                  SizedBox(width: 4),
                  Text('Bozdar Safar (Auto)',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFF546E7A))),
                ],
              ),
              const SizedBox(height: 3),
              Text(m.body, style: const TextStyle(fontSize: 14)),
              const SizedBox(height: 4),
              Text(time,
                  style:
                      const TextStyle(color: Colors.black45, fontSize: 10.5)),
            ],
          ),
        ),
      );
    }
    if (isMaster) {
      return Align(
        alignment: Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10, right: 46),
          padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF6E0),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(14),
              topRight: Radius.circular(14),
              bottomRight: Radius.circular(14),
              bottomLeft: Radius.circular(3),
            ),
            border: Border.all(color: Brand.gold, width: 1.1),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.verified, size: 14, color: Color(0xFFB8860B)),
                  SizedBox(width: 4),
                  Text('Master',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFFB8860B))),
                ],
              ),
              const SizedBox(height: 3),
              Text(m.body, style: const TextStyle(fontSize: 14)),
              const SizedBox(height: 4),
              Text(time,
                  style:
                      const TextStyle(color: Colors.black45, fontSize: 10.5)),
            ],
          ),
        ),
      );
    }
    final (statusText, statusColor) = !m.sent
        ? ('Abhi bheja nahi gaya — internet ate hi chala jayega',
            Brand.ajrakRed)
        : m.isRead
            ? ('Master ne parh liya', Brand.green)
            : ('Bheja gaya', const Color(0xFFB8860B));
    return Align(
      alignment: Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10, left: 46),
        padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
        decoration: const BoxDecoration(
          color: Color(0xFFE7F2EC),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(14),
            topRight: Radius.circular(14),
            bottomLeft: Radius.circular(14),
            bottomRight: Radius.circular(3),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (m.category.isNotEmpty)
              Text(m.category,
                  style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
            const SizedBox(height: 2),
            Text(m.body, style: const TextStyle(fontSize: 14)),
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(time,
                    style: const TextStyle(
                        color: Colors.black45, fontSize: 10.5)),
                const SizedBox(width: 6),
                Icon(
                  m.isRead
                      ? Icons.done_all
                      : m.sent
                          ? Icons.done
                          : Icons.schedule,
                  size: 13,
                  color: statusColor,
                ),
                const SizedBox(width: 3),
                Text(statusText,
                    style: TextStyle(
                        color: statusColor,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
