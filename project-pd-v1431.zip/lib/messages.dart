import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'store.dart';
import 'theme.dart';
import 'backend.dart';
import 'support_auto.dart';

/// Madad — Master se CHAT (v1.2.7 se; LIVE CHAT owner 2026-11-08):
/// sawari ho ya driver, koi masla ya shikayat ho to is screen se
/// seedha Master (head) se baat hoti hai — SUPPORT KA EK HI
/// DARWAZA yahi hai, koi alag support/team NAHI hai.
///
/// Chat ASAL thread hai: mere bheje hue messages AUR Master ke
/// jawab (backend messages table ki sender_role='master' rows —
/// sender_key meri apni key par; PROTOCOL Master app ke saath
/// mushtarka hai) ek hi thread mein waqt ki tartib se ate hain,
/// Master ki baat alag rang/side par. DRIVER mode mein photo
/// attach bhi hai (amendment 2026-11-10): hadd ke baad driver
/// apni photo yahin se Master ko bhej kar lagwata hai —
/// messages.photo_path (migration v143 §4)। Khuli chat har ~9 second
/// khud refresh hoti hai (Backend.syncMessages → fetchMyThread)
/// taaki Master ka jawab khud aa jaye. Message pehle phone par
/// mehfooz hota hai, phir backend se Master app tak puhancta
/// hai — offline ho to queued rehta hai aur internet ate hi khud
/// chala jata hai.
class MasterMessagesScreen extends StatefulWidget {
  final AppStore store;

  /// 'driver' | 'passenger' — kis mode se khuli hai.
  final String role;
  const MasterMessagesScreen(
      {super.key, required this.store, required this.role});

  @override
  State<MasterMessagesScreen> createState() => _MasterMessagesScreenState();
}

class _MasterMessagesScreenState extends State<MasterMessagesScreen> {
  final _nameCtrl = TextEditingController();
  final _mobileCtrl = TextEditingController();
  final _bodyCtrl = TextEditingController();
  String _category = kMessageCategories.first;
  bool _sending = false;

  /// SUPPORT PHOTO (amendment 2026-11-10): sirf DRIVER mode
  /// mein — hadd ke baad driver apni photo Master ko yahin se
  /// bhej kar lagwata hai (malik ka hukm 23:40)।
  final ImagePicker _picker = ImagePicker();
  bool _sendingPhoto = false;

  /// LIVE CHAT auto-refresh — chat khuli ho to har ~9s Master ke
  /// naye jawab pull hote hain; dispose par lazmi band.
  Timer? _chatTimer;

  AppStore get store => widget.store;
  bool get _isDriver => widget.role == 'driver';

  /// Is role ki pehchan — backend `messages.sender_key`:
  /// driver = driverId, sawari = deviceId.
  String get _senderKey => _isDriver ? store.driverId : store.deviceId;

  /// Is role ka zone (driver ka profile zone; sawari ka zone maloom
  /// nahi hota — khaali rehta hai, jhooti value nahi jati).
  String get _zone => _isDriver ? store.profile.zone : '';

  @override
  void initState() {
    super.initState();
    if (_isDriver) {
      _nameCtrl.text = store.profile.name;
      _mobileCtrl.text = store.profile.phone;
    } else {
      // Sawari: pehle se yaad naam/mobile; na ho to aakhri booking
      // wali maloomat se bhar dete hain (fields phir bhi badle ja
      // sakte hain).
      var name = store.passengerName;
      var mobile = store.passengerPhone;
      if ((name.isEmpty || mobile.isEmpty) && store.bookings.isNotEmpty) {
        final b = store.bookings.first;
        if (name.isEmpty) name = b.passengerName;
        if (mobile.isEmpty) mobile = b.passengerPhone;
      }
      _nameCtrl.text = name;
      _mobileCtrl.text = mobile;
    }
    // Khulte hi: queued messages ki dobara koshish + poora
    // thread pull (apne + Master ke jawab), phir is key ke jawab
    // "parhe hue" — unread badge saaf.
    unawaited(_refreshThread(markSeen: true));
    // LIVE CHAT: har ~9 second khud refresh — Master ka jawab
    // chat khuli ho to khud aa jata hai; chat khuli hai matlab
    // jawab parha hua hi mana jata hai (badge nahi banta).
    _chatTimer = Timer.periodic(const Duration(seconds: 9), (_) {
      unawaited(_refreshThread(markSeen: true));
    });
  }

  /// Thread taaza karna — syncMessages ke andar fetchMyThread
  /// Master ke jawab bhi le ata hai. Har nakami khamosh (chat
  /// local list par chalti rehti hai).
  Future<void> _refreshThread({bool markSeen = false}) async {
    await Backend.syncMessages(store);
    if (markSeen) await store.markMasterRepliesSeen(_senderKey);
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _chatTimer?.cancel();
    _nameCtrl.dispose();
    _mobileCtrl.dispose();
    _bodyCtrl.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _send() async {
    final name = _nameCtrl.text.trim();
    final mobile = _mobileCtrl.text.trim();
    final body = _bodyCtrl.text.trim();
    if (name.isEmpty) {
      _snack('Apna naam likhein.');
      return;
    }
    if (mobile.isEmpty) {
      _snack('Apna mobile number likhein.');
      return;
    }
    if (body.isEmpty) {
      _snack('Message likhein — kya masla hai?');
      return;
    }
    setState(() => _sending = true);
    final m = MasterMessage(
      id: store.newId(),
      senderKey: _senderKey,
      senderRole: widget.role,
      senderName: name,
      senderMobile: mobile,
      senderZone: _zone,
      category: _category,
      body: body,
      createdAt: DateTime.now(),
    );
    // Store mein daalte hi 'message' hook backend push shuru kar deta
    // hai (best-effort); offline ho to queued rehta hai.
    await store.addMasterMessage(m);
    // v1.4.7 SUPPORT AUTO-JAWAB (spec §4): greeting (thread par sirf
    // pehli dafa) + tasalli + aam sawalon ke tayyar jawab + badtameezi
    // par warning — sab sender_role='auto' ke saath thread mein bhi
    // jate hain aur Master ko bhi nazar ate hain. Engine khud
    // exception-proof hai.
    await SupportAuto.onUserMessage(store, m);
    if (!mounted) return;
    setState(() {
      _sending = false;
      _bodyCtrl.clear();
    });
    _snack('Aap ka message Master tak bhej diya gaya hai');
  }

  /// Master ko PHOTO bhejna — SIRF DRIVER (amendment
  /// 2026-11-10): pehle Camera/Gallery ki sheet, phir upload
  /// (driver-docs/<driver_id>/support_<waqt>.jpg), upload
  /// kamyab ho tab hi photo_path ke saath message jata hai —
  /// nakami par message NAHI jata aur saaf snack ata hai
  /// (aadhi sahulat dikha kar dhoka nahi)। Message ke saath
  /// body box mein likha text caption ban jata hai; khaali ho
  /// to tay-shuda darkhwast wala jumla jata hai taake Master
  /// ko wajah saaf samajh aye।
  Future<void> _sendPhoto() async {
    if (!_isDriver || _sendingPhoto || _sending) return;
    final name = _nameCtrl.text.trim();
    final mobile = _mobileCtrl.text.trim();
    if (name.isEmpty) {
      _snack('Apna naam likhein.');
      return;
    }
    if (mobile.isEmpty) {
      _snack('Apna mobile number likhein.');
      return;
    }
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Brand.green),
              title: const Text('Camera se tasveer lein'),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Brand.green),
              title: const Text('Gallery se chunein'),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (src == null || !mounted) return;
    setState(() => _sendingPhoto = true);
    try {
      final img = await _picker.pickImage(source: src, imageQuality: 85);
      if (img == null) {
        _snack(
            'Tasveer nahi li gayi — camera band ho gaya ya permission nahi mili. Dobara koshish karein.');
        return;
      }
      final objectPath = await Backend.uploadSupportPhoto(store, img.path);
      if (!mounted) return;
      if (objectPath == null) {
        _snack(
            'Photo nahi bhij saki — internet check karke dobara koshish karein.');
        return;
      }
      final caption = _bodyCtrl.text.trim();
      final m = MasterMessage(
        id: store.newId(),
        senderKey: _senderKey,
        senderRole: widget.role,
        senderName: name,
        senderMobile: mobile,
        senderZone: _zone,
        category: _category,
        body: caption.isNotEmpty
            ? caption
            : 'Photo bheji gayi hai — malik se darkhwast hai ke ye photo meri profile par laga dein.',
        photoPath: objectPath,
        photoLocalPath: img.path,
        createdAt: DateTime.now(),
      );
      await store.addMasterMessage(m);
      await SupportAuto.onUserMessage(store, m);
      if (!mounted) return;
      setState(() => _bodyCtrl.clear());
      _snack('Aap ki photo Master tak bhej di gayi hai');
    } catch (_) {
      _snack('Tasveer nahi li ja saki.');
    } finally {
      if (mounted) setState(() => _sendingPhoto = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Madad — Master se Chat'),
        actions: [
          IconButton(
            tooltip: 'Chat refresh karein',
            icon: const Icon(Icons.refresh),
            onPressed: () => unawaited(_refreshThread(markSeen: true)),
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          // ASAL THREAD: meri key ki saari rows — mere messages
          // (driver/passenger role) + Master ke jawab (master
          // role) — waqt ki tartib mein (purana upar, naya neeche).
          final thread = store.masterMessages
              .where((m) => m.senderKey == _senderKey)
              .toList()
            ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
          return ListView(
            padding: const EdgeInsets.all(14),
            children: [
              const Text(
                'Koi masla, shikayat ya baat ho — yahan likhein, baat seedha Master se hogi aur Master ka jawab bhi yahin chat mein ayega.',
                style: TextStyle(fontSize: 13, color: Colors.black54),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _category,
                decoration: const InputDecoration(labelText: 'Masle ki qisam'),
                items: kMessageCategories
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) =>
                    setState(() => _category = v ?? _category),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _nameCtrl,
                decoration: const InputDecoration(labelText: 'Aap ka naam'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _mobileCtrl,
                keyboardType: TextInputType.phone,
                decoration:
                    const InputDecoration(labelText: 'Mobile number'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _bodyCtrl,
                minLines: 4,
                maxLines: 7,
                decoration: const InputDecoration(
                  labelText: 'Message',
                  hintText: 'Apna masla tafseel se likhein…',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _sending ? null : _send,
                  icon: const Icon(Icons.send),
                  label:
                      Text(_sending ? 'Bhej raha hai…' : 'Message Bhejein'),
                ),
              ),
              // SUPPORT PHOTO — SIRF DRIVER mode mein (sahulat
              // sirf driver ki hai; sawari ko ye button nahi)।
              if (_isDriver) ...[
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _sendingPhoto ? null : _sendPhoto,
                    icon: _sendingPhoto
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.photo_camera, size: 19),
                    label: Text(_sendingPhoto
                        ? 'Photo bhej raha hai…'
                        : 'Master ko Photo Bhejein'),
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Profile photo badalne ki hadd poori ho jaye to nayi photo yahan se Master ko bhej dein — malik Master app se aap ki photo laga dega.',
                  style: TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ],
              const SizedBox(height: 20),
              const Text('Master se Chat',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              if (thread.isEmpty)
                const Text(
                  'Abhi koi baat nahi hui — pehla message upar se bhejein, Master ka jawab yahin ayega.',
                  style: TextStyle(color: Colors.black54),
                )
              else
                ...thread.map(_chatBubble),
            ],
          );
        },
      ),
    );
  }

  /// Apne bheje hue photo-message ki chhoti thumbnail: is
  /// phone par chuni hui LOCAL file ho to wohi tasveer; sirf
  /// backend record ho (cache saaf / thread dobara pull) to
  /// jaali tasveer ki jagah saaf photo-wala nishan — bucket
  /// private hai aur P+D mein signed-URL wala rasta maujood
  /// nahi (profile photo card wala wohi usool; Master asal
  /// photo bucket se khud dekhta hai)।
  Widget _photoThumb(MasterMessage m) {
    final local =
        m.photoLocalPath.isNotEmpty ? File(m.photoLocalPath) : null;
    final hasLocal = local != null && local.existsSync();
    if (!hasLocal) {
      return Container(
        width: 148,
        height: 104,
        decoration: BoxDecoration(
          color: const Color(0xFFDCE9E1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: const Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.image, size: 30, color: Brand.green),
            SizedBox(height: 4),
            Text('Photo bheji gayi',
                style: TextStyle(fontSize: 11.5, color: Brand.greenDark)),
          ],
        ),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: Image.file(
        local,
        width: 148,
        height: 148,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          width: 148,
          height: 104,
          color: const Color(0xFFDCE9E1),
          child: const Icon(Icons.broken_image_outlined,
              size: 28, color: Brand.green),
        ),
      ),
    );
  }

  /// Thread ka ek bubble: Master ka jawab BAYEIN taraf sunehri/
  /// cream rang mein 'Master' label ke saath; mera apna message
  /// DAYEIN taraf sabz mein, neeche us ki haalat (bheja gaya /
  /// Master ne parh liya / abhi queued hai).
  Widget _chatBubble(MasterMessage m) {
    final isMaster = m.senderRole == 'master';
    final time = '${fmtDate(m.createdAt)} ${fmtTime(m.createdAt)}';
    if (m.senderRole == 'auto') {
      // v1.4.7: app ka khud-kar tayyar jawab — Master wale bubble
      // se alag halka neela/grey rang, 'Bozdar Safar (Auto)' label
      // ke saath taaki user ko saaf pata ho ye khud-kar jawab hai.
      return Align(
        alignment: Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10, right: 46),
          padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
          decoration: BoxDecoration(
            color: const Color(0xFFEDF2F7),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(14),
              topRight: Radius.circular(14),
              bottomRight: Radius.circular(14),
              bottomLeft: Radius.circular(3),
            ),
            border: Border.all(color: const Color(0xFFB0BEC5), width: 1.0),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.smart_toy_outlined,
                      size: 14, color: Color(0xFF546E7A)),
                  SizedBox(width: 4),
                  Text('Bozdar Safar (Auto)',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFF546E7A))),
                ],
              ),
              const SizedBox(height: 3),
              Text(m.body, style: const TextStyle(fontSize: 14)),
              const SizedBox(height: 4),
              Text(time,
                  style:
                      const TextStyle(color: Colors.black45, fontSize: 10.5)),
            ],
          ),
        ),
      );
    }
    if (isMaster) {
      return Align(
        alignment: Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10, right: 46),
          padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF6E0),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(14),
              topRight: Radius.circular(14),
              bottomRight: Radius.circular(14),
              bottomLeft: Radius.circular(3),
            ),
            border: Border.all(color: Brand.gold, width: 1.1),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.verified, size: 14, color: Color(0xFFB8860B)),
                  SizedBox(width: 4),
                  Text('Master',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFFB8860B))),
                ],
              ),
              const SizedBox(height: 3),
              Text(m.body, style: const TextStyle(fontSize: 14)),
              const SizedBox(height: 4),
              Text(time,
                  style:
                      const TextStyle(color: Colors.black45, fontSize: 10.5)),
            ],
          ),
        ),
      );
    }
    final (statusText, statusColor) = !m.sent
        ? ('Abhi bheja nahi gaya — internet ate hi chala jayega',
            Brand.ajrakRed)
        : m.isRead
            ? ('Master ne parh liya', Brand.green)
            : ('Bheja gaya', const Color(0xFFB8860B));
    return Align(
      alignment: Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10, left: 46),
        padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
        decoration: const BoxDecoration(
          color: Color(0xFFE7F2EC),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(14),
            topRight: Radius.circular(14),
            bottomLeft: Radius.circular(14),
            bottomRight: Radius.circular(3),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (m.category.isNotEmpty)
              Text(m.category,
                  style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
            if (m.photoPath.isNotEmpty || m.photoLocalPath.isNotEmpty) ...[
              const SizedBox(height: 4),
              _photoThumb(m),
            ],
            const SizedBox(height: 2),
            Text(m.body, style: const TextStyle(fontSize: 14)),
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(time,
                    style: const TextStyle(
                        color: Colors.black45, fontSize: 10.5)),
                const SizedBox(width: 6),
                Icon(
                  m.isRead
                      ? Icons.done_all
                      : m.sent
                          ? Icons.done
                          : Icons.schedule,
                  size: 13,
                  color: statusColor,
                ),
                const SizedBox(width: 3),
                Text(statusText,
                    style: TextStyle(
                        color: statusColor,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
