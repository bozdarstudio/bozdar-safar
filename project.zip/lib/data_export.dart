import 'store.dart';
import 'theme.dart';

/// =====================================================================
/// MERA DATA — EXPORT (v1.4.35, audit C-2)
///
/// Har user (driver / passenger) apna poora record — jo kuch is
/// app mein asal mein mehfooz hai — ek saaf parhi ja sakne wali
/// text file ki shakal mein share sheet se bhej sakta hai.
///
/// ⭐ ASAL-JAANKARI LOCK: sirf wohi data jo asal mein store mein
/// maujood hai; jo hisa khaali ho wahan imaandari se "Koi record
/// nahi" likha jata hai — koi banawati entry NAHI banti.
/// Builder functions PURE hain (store + waqt lete hain) — test
/// yahin hote hain.
/// =====================================================================

String _rideLine(Booking b) {
  final when = fmtDate(b.completedAt ?? b.createdAt);
  final km = b.distanceKm == b.distanceKm.roundToDouble()
      ? b.distanceKm.toInt().toString()
      : b.distanceKm.toStringAsFixed(1);
  return '• $when — ${b.pickupLabel} → ${b.dropLabel} '
      '(${b.vehicle}, $km km) — Haalat: ${b.status} — '
      'Kiraya: Rs ${b.total}'
      '${b.taxAmount > 0 ? ' + Tax Rs ${b.taxAmount}' : ''}';
}

String _ridesSection(List<Booking> bookings) {
  final buf = StringBuffer();
  if (bookings.isEmpty) {
    buf.writeln('Koi record nahi — abhi koi ride darj nahi hai.');
    return buf.toString();
  }
  final sorted = [...bookings]
    ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  for (final b in sorted) {
    buf.writeln(_rideLine(b));
  }
  return buf.toString();
}

/// DRIVER ka data: profile + rides history + fee/Amanat record.
String buildDriverDataExport(AppStore store, {required DateTime now}) {
  final p = store.profile;
  final buf = StringBuffer();
  buf.writeln('BOZDAR SAFAR — MERA DATA (Driver)');
  buf.writeln('Tayyar: ${fmtDate(now)} ${fmtTime(now)}');
  buf.writeln('');
  buf.writeln('— PROFILE —');
  buf.writeln('Naam: ${p.name}');
  buf.writeln('Mobile: ${p.phone.isEmpty ? 'Koi record nahi' : p.phone}');
  buf.writeln('Gaari: ${p.vehicle}');
  buf.writeln(
      'Number plate: ${p.plate.isEmpty ? 'Koi record nahi' : p.plate}');
  buf.writeln('Sheher (Zone): ${p.zone.isEmpty ? 'Koi record nahi' : p.zone}');
  buf.writeln('Radius: ${p.radiusKm.toStringAsFixed(0)} km');
  buf.writeln('');
  buf.writeln('— RIDES HISTORY —');
  buf.write(_ridesSection(store.bookings));
  buf.writeln('');
  buf.writeln('— FEE / AMANAT RECORD —');
  buf.writeln('Kul jama (Amanat Deposit): Rs ${p.totalDeposited}');
  buf.writeln('Bani hui fees (fee due): Rs ${p.feeDue}');
  buf.writeln('Amanat balance: Rs ${store.amanatBalance}');
  if (store.txns.isEmpty) {
    buf.writeln('Koi record nahi — abhi koi fee/deposit entry nahi hai.');
  } else {
    final sorted = [...store.txns]
      ..sort((a, b) => b.date.compareTo(a.date));
    for (final t in sorted) {
      buf.writeln('• ${fmtDate(t.date)} — '
          '${t.type == 'deposit' ? 'Deposit jama' : 'Fee'}: Rs ${t.amount}'
          '${t.method.isNotEmpty ? ' (${t.method})' : ''}'
          '${t.note.isNotEmpty ? ' — ${t.note}' : ''}');
    }
  }
  return buf.toString();
}

/// PASSENGER ka data: profile + rides history + sahulat haalat.
String buildPassengerDataExport(AppStore store, {required DateTime now}) {
  final buf = StringBuffer();
  buf.writeln('BOZDAR SAFAR — MERA DATA (Passenger)');
  buf.writeln('Tayyar: ${fmtDate(now)} ${fmtTime(now)}');
  buf.writeln('');
  buf.writeln('— PROFILE —');
  buf.writeln(
      'Naam: ${store.passengerName.isEmpty ? 'Koi record nahi' : store.passengerName}');
  buf.writeln(
      'Mobile: ${store.passengerPhone.isEmpty ? 'Koi record nahi' : store.passengerPhone}');
  buf.writeln(
      'Gmail: ${store.passengerEmail.isEmpty ? 'Koi record nahi' : store.passengerEmail}');
  buf.writeln('');
  buf.writeln('— RIDES HISTORY —');
  buf.write(_ridesSection(store.bookings));
  buf.writeln('');
  buf.writeln('— SAHULAT HAALAT —');
  buf.writeln(
      'Lagataar mukammal rides (streak): ${store.sahulatStreak} / ${store.sahulatTargetRides}');
  buf.writeln('Muft rides baqi: ${store.sahulatFreeLeft}');
  buf.writeln(
      'Pehli-ride riayat istemal hui: ${store.sahulatFirstUsed ? 'Haan' : 'Nahi'}');
  buf.writeln('');
  buf.writeln('— MEHFOOZ JAGHEIN —');
  if (store.savedPlaces.isEmpty) {
    buf.writeln('Koi record nahi — koi jagah save nahi hai.');
  } else {
    for (final pl in store.savedPlaces) {
      buf.writeln('• ${pl.name} — ${pl.label}');
    }
  }
  return buf.toString();
}
