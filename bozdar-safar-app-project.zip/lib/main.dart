import 'package:flutter/material.dart';
import 'store.dart';
import 'theme.dart';
import 'passenger.dart';
import 'driver.dart';

void main() {
  runApp(const BozdarSafarApp());
}

class BozdarSafarApp extends StatefulWidget {
  const BozdarSafarApp({super.key});

  @override
  State<BozdarSafarApp> createState() => _BozdarSafarAppState();
}

class _BozdarSafarAppState extends State<BozdarSafarApp> {
  final AppStore store = AppStore();

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bozdar Safar',
      debugShowCheckedModeBanner: false,
      theme: Brand.theme(),
      home: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          if (!store.loaded) {
            return const Scaffold(
              backgroundColor: Brand.deepGreen,
              body: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.local_taxi, color: Brand.gold, size: 56),
                    SizedBox(height: 14),
                    Text(
                      'BOZDAR SAFAR',
                      style: TextStyle(
                        color: Brand.gold,
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.4,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Your ride, your people.',
                      style: TextStyle(color: Brand.cream, fontSize: 13),
                    ),
                  ],
                ),
              ),
            );
          }
          return ModeShell(store: store);
        },
      ),
    );
  }
}

/// ONE app, TWO fully separated sides. Exactly ONE switch button exists on
/// each side — never a two-option toggle:
///  - Passenger side: one button "Driver Mode mein jayein"
///  - Driver side:    one button "Passenger Mode mein jayein"
/// One tap replaces the whole display; the other side never renders.
class ModeShell extends StatefulWidget {
  final AppStore store;
  const ModeShell({super.key, required this.store});

  @override
  State<ModeShell> createState() => _ModeShellState();
}

class _ModeShellState extends State<ModeShell> {
  bool driverMode = false;

  @override
  Widget build(BuildContext context) {
    if (driverMode) {
      return DriverSide(
        store: widget.store,
        onSwitchToPassenger: () => setState(() => driverMode = false),
      );
    }
    return PassengerSide(
      store: widget.store,
      onSwitchToDriver: () => setState(() => driverMode = true),
    );
  }
}

/// The single mode-switch button. [toDriver] decides its label/direction.
class SwitchModeButton extends StatelessWidget {
  final bool toDriver;
  final VoidCallback onTap;
  const SwitchModeButton(
      {super.key, required this.toDriver, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(toDriver ? Icons.drive_eta : Icons.person, size: 20),
        label: Text(toDriver
            ? 'Driver Mode mein jayein'
            : 'Passenger Mode mein jayein'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Brand.gold,
          foregroundColor: Brand.greenDark,
          padding: const EdgeInsets.symmetric(vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }
}
