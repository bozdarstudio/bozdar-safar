// v1.4.30 — SAHULAT wave ke model tests: 20 lagataar complete
// rides -> 3 muft rides (3 km / Rs 200 tak), muft ride par fee 0
// + driver ko 90% Amanat credit, pehli ride par Rs 50 tak riayat
// (fee se), aur apni cancel par ginti ZERO se restart।
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:safar/store.dart';

int _seq = 0;

Booking _mk({bool freeRide = false, double km = 5, int fare = 350}) {
  _seq++;
  return Booking(
    id: 'sah-$_seq',
    passengerName: 'Test Sawari',
    passengerPhone: '03000000000',
    pickupLabel: 'A',
    dropLabel: 'B',
    pickupLat: 24.86,
    pickupLng: 67.0,
    dropLat: 24.87,
    dropLng: 67.01,
    hasDropPin: true,
    vehicle: 'Rickshaw',
    distanceKm: km,
    fare: fare,
    note: '',
    status: 'pending',
    createdAt: DateTime.now(),
    freeRide: freeRide,
  );
}

Future<Booking> _booked(AppStore store,
    {bool freeRide = false, double km = 5, int fare = 350}) async {
  final b = _mk(freeRide: freeRide, km: km, fare: fare);
  await store.addBooking(b);
  return b;
}

Future<void> _complete(AppStore store, Booking b) async {
  b.assignedDriverId = 'd1';
  b.driverName = 'Test Driver';
  b.status = 'accepted';
  await store.completeBooking(b);
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  group('Sahulat — Booking fields', () {
    test('JSON round-trip: naye fields mehfooz rehte hain', () {
      final b = _mk(km: 2, fare: 200)
        ..freeRide = true
        ..firstRidePromo = true
        ..promoDiscountRs = 35
        ..freeCreditRs = 180;
      final back = Booking.fromJson(b.toJson());
      expect(back.freeRide, isTrue);
      expect(back.firstRidePromo, isTrue);
      expect(back.promoDiscountRs, 35);
      expect(back.freeCreditRs, 180);
    });

    test('passengerPays: muft ride 0, riayat wali par discount kat-ta hai', () {
      final free = _mk(km: 2, fare: 200)..freeRide = true;
      expect(free.passengerPays, 0);
      final promo = _mk(fare: 350)
        ..firstRidePromo = true
        ..promoDiscountRs = 35;
      expect(promo.passengerPays, promo.grandTotal - 35);
    });

    test('freeRideEligibleFor: 3 km aur Rs 200 ki hadd', () {
      final store = AppStore();
      expect(store.freeRideEligibleFor(3.0, 200), isFalse); // haq hi nahi
      store.sahulatFreeLeft = 3;
      expect(store.freeRideEligibleFor(3.0, 200), isTrue);
      expect(store.freeRideEligibleFor(2.0, 150), isTrue);
      expect(store.freeRideEligibleFor(3.1, 150), isFalse);
      expect(store.freeRideEligibleFor(2.0, 201), isFalse);
    });
  });

  group('Sahulat — streak aur muft haq', () {
    test('20 lagataar complete rides par 3 muft rides milti hain', () async {
      final store = AppStore();
      store.passengerPhone = '03000000000';
      for (var i = 0; i < 20; i++) {
        await _complete(store, await _booked(store));
      }
      expect(store.sahulatFreeLeft, 3);
      expect(store.sahulatStreak, 0);
    });

    test('apni cancel par ginti ZERO se restart hoti hai', () async {
      final store = AppStore();
      store.passengerPhone = '03000000000';
      for (var i = 0; i < 5; i++) {
        await _complete(store, await _booked(store));
      }
      expect(store.sahulatStreak, 5);
      final pending = await _booked(store);
      await store.cancelBooking(pending);
      expect(store.sahulatStreak, 0);
    });

    test('muft ride complete: fee 0, driver ko 90% credit, haq kam', () async {
      final store = AppStore();
      store.passengerPhone = '03000000000';
      for (var i = 0; i < 20; i++) {
        await _complete(store, await _booked(store));
      }
      expect(store.sahulatFreeLeft, 3);
      final free = await _booked(store, freeRide: true, km: 2, fare: 200);
      await _complete(store, free);
      expect(free.effectiveFeeRs, 0);
      expect(free.freeCreditRs, 180);
      expect(store.sahulatFreeLeft, 2);
    });

    test('pehli ride: riayat fee se kat-ti hai, driver ko poora paisa', () async {
      final store = AppStore();
      store.passengerPhone = '03000000000';
      final first = await _booked(store, fare: 350);
      expect(first.firstRidePromo, isTrue);
      await _complete(store, first);
      // fee 35 (10%) — riayat min(50, 35) = 35 -> promoDiscount 35, fee 0
      expect(first.promoDiscountRs, 35);
      expect(first.effectiveFeeRs, 0);
      expect(first.passengerPays, first.grandTotal - 35);
      final second = await _booked(store, fare: 350);
      expect(second.firstRidePromo, isFalse);
    });
  });
}
