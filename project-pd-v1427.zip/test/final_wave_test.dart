// v1.4.25 — FINAL WAVE (fare gate / backend tasdeeq / monthly
// package asal) ke model-level tests: MonthlyPackage ke naye
// asal fields (passengerPhone / driverId / driverName), status
// ka matlab, purani JSON se compatibility, aur package fee ka
// wohi 10% hisaab jo backend row par driver se bandhta hai।
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:safar/store.dart';

MonthlyPackage _pkg({
  String status = 'pending',
  String driverId = '',
  String driverName = '',
  String passengerPhone = '03001234567',
  int monthlyAmount = 39000,
}) =>
    MonthlyPackage(
      id: 'pkg-1',
      passengerName: 'Ahmed',
      passengerPhone: passengerPhone,
      pickup: 'Clifton',
      drop: 'Saddar',
      vehicle: 'Rickshaw',
      routeKm: 3.0,
      days: 26,
      monthlyAmount: monthlyAmount,
      createdAt: DateTime(2026, 11, 11),
      status: status,
      driverId: driverId,
      driverName: driverName,
    );

void main() {
  group('MonthlyPackage — asal fields (v1.4.25)', () {
    test('naya package pending hota hai, driver khaali', () {
      final p = _pkg();
      expect(p.status, 'pending');
      expect(p.hasDriver, isFalse);
      expect(p.isCancelled, isFalse);
    });

    test('JSON round-trip: saare naye fields mehfooz rehte hain', () {
      final p = _pkg(
          status: 'active', driverId: 'drv-9', driverName: 'Bilal');
      final back = MonthlyPackage.fromJson(p.toJson());
      expect(back.passengerPhone, '03001234567');
      expect(back.status, 'active');
      expect(back.driverId, 'drv-9');
      expect(back.driverName, 'Bilal');
      expect(back.hasDriver, isTrue);
    });

    test('purani JSON (v1.4.24 se pehle) toot-ti nahi — phone/driver khaali', () {
      final back = MonthlyPackage.fromJson({
        'id': 'old-1',
        'passengerName': 'Purana',
        'pickup': 'Clifton',
        'drop': 'Saddar',
        'vehicle': 'Rickshaw',
        'routeKm': 2.0,
        'days': 26,
        'monthlyAmount': 26000,
        'createdAt': '2026-11-01T00:00:00.000',
        'status': 'active',
      });
      expect(back.passengerPhone, '');
      expect(back.driverId, '');
      expect(back.driverName, '');
      expect(back.status, 'active');
    });

    test('cancelled ki pehchan saaf hai', () {
      expect(_pkg(status: 'cancelled').isCancelled, isTrue);
      expect(_pkg(status: 'active').isCancelled, isFalse);
    });
  });

  group('Package fee — driver se bandhi 10% (v1.4.25)', () {
    test('monthly amount par fee wohi serviceFee hai jo row par jati hai', () {
      // Rs 39,000 ke package par fee Rs 3,900 (10%) — yehi
      // rakam _pushPackage row ke 'fee' mein likhta hai aur
      // driver_id lagte hi usi driver ki ho jati hai।
      expect(Fares.serviceFee(39000), 3900);
      expect(Fares.serviceFee(26000), 2600);
    });
  });

  group('applyRemotePackageState — driver assign ki taaza haalat', () {
    setUp(() {
      TestWidgetsFlutterBinding.ensureInitialized();
      SharedPreferences.setMockInitialValues({});
    });

    test('driver lagne par local record update hota hai', () async {
      final store = AppStore();
      store.monthlyPackages.add(_pkg());
      final changed = store.applyRemotePackageState('pkg-1',
          driverId: 'drv-9', driverName: 'Bilal', status: 'active');
      expect(changed, isTrue);
      final p = store.monthlyPackages.first;
      expect(p.driverId, 'drv-9');
      expect(p.driverName, 'Bilal');
      expect(p.status, 'active');
      expect(p.hasDriver, isTrue);
    });

    test('ajnabi id par kuch nahi badalta', () {
      final store = AppStore();
      store.monthlyPackages.add(_pkg());
      expect(
          store.applyRemotePackageState('doosra', driverId: 'x'), isFalse);
      expect(store.monthlyPackages.first.driverId, '');
    });
  });

  group('Version — v1.4.27+50', () {
    test('constants pubspec se milte hain', () {
      expect(kAppVersion, '1.4.27');
      expect(kAppVersionCode, 50);
    });
  });
}
