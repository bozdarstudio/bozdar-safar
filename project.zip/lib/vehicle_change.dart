import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'backend.dart';
import 'guide_audio.dart';
import 'store.dart';
import 'theme.dart';

/// GAARI CHANGE (v1.4.7, spec §7) — ek hi CNIC / ek hi ID par
/// driver apni gaari khud app se badal sakta hai; NAYI ID NAHI
/// banti।
///
/// Usool (malik ke faisle 2026-11-08 23:43–23:51):
/// - Change = POORA amal dobara: nayi gaari ki tafseel, chaaron
///   taraf ki photos + andar ki tasveer, kaghaz, aur LIVE selfie
///   — sab lazmi, bilkul pehli registration ki tarah।
/// - Kam az kam ek side par number plate lazmi — na ho to wohi
///   rukawat + awaaz wali hidayat (guidance_plate)।
/// - Ek gaari = ek ID: plate doosri ID par ho to darkhwast
///   wahin rukti hai; wazahat Master ko bhej sakta hai (band
///   gali nahi)।
/// - Faisla Master ka: Tasdeeq/approve par wohi ID nayi gaari
///   par update ho jati hai; purani gaari history mein mehfooz
///   rehti hai (store.applyV137DriverFields)।
class VehicleChangePage extends StatefulWidget {
  final AppStore store;
  const VehicleChangePage({super.key, required this.store});

  @override
  State<VehicleChangePage> createState() => _VehicleChangePageState();
}

class _VehicleChangePageState extends State<VehicleChangePage> {
  final ImagePicker _picker = ImagePicker();
  bool _busy = false;
  String? _error;

  AppStore get store => widget.store;
  DriverProfile get p => store.profile;

  late String _vehicle = p.vehicle;
  late final _brandCtrl = TextEditingController(text: p.vehicleBrand);
  late final _modelCtrl = TextEditingController(text: p.vehicleModel);
  late final _colorCtrl = TextEditingController(text: p.vehicleColor);
  late final _plateCtrl = TextEditingController(text: p.plate);
  late int? _year = p.vehicleYear > 0 ? p.vehicleYear : null;
  String _front = '';
  String _back = '';
  String _left = '';
  String _right = '';
  String _interior = '';
  String _reg = '';
  String _selfie = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      unawaited(GuideAudio.play('guidance/guidance_vehicle_change.mp3'));
    });
  }

  @override
  void dispose() {
    _brandCtrl.dispose();
    _modelCtrl.dispose();
    _colorCtrl.dispose();
    _plateCtrl.dispose();
    super.dispose();
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _pick(void Function(String) apply,
      {bool cameraOnly = false}) async {
    ImageSource? src = cameraOnly ? ImageSource.camera : null;
    if (!cameraOnly) {
      src = await showModalBottomSheet<ImageSource>(
        context: context,
        builder: (ctx) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt, color: Brand.green),
                title: const Text('Camera se tasveer lein'),
                onTap: () => Navigator.pop(ctx, ImageSource.camera),
              ),
              ListTile(
                leading: const Icon(Icons.photo_library, color: Brand.green),
                title: const Text('Gallery se chunein'),
                onTap: () => Navigator.pop(ctx, ImageSource.gallery),
              ),
            ],
          ),
        ),
      );
    }
    if (src == null || !mounted) return;
    try {
      final img = await _picker.pickImage(source: src, imageQuality: 85);
      if (img != null && mounted) setState(() => apply(img.path));
    } catch (_) {
      _snack('Tasveer nahi li ja saki.');
    }
  }

  static String _normPlate(String s) =>
      s.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

  bool _fail(String msg) {
    setState(() => _error = msg);
    return false;
  }

  Future<bool> _validate() async {
    setState(() => _error = null);
    if (_brandCtrl.text.trim().isEmpty) {
      return _fail('Gaari ki company/brand likhein.');
    }
    if (_modelCtrl.text.trim().isEmpty) {
      return _fail('Gaari ka model likhein.');
    }
    if (_year == null) return _fail('Gaari ka saal (year) chunein.');
    if (_colorCtrl.text.trim().isEmpty) {
      return _fail('Gaari ka rang likhein.');
    }
    // PLATE RULE (wizard wala hi): plate na ho to rukawat + awaaz।
    if (_plateCtrl.text.trim().isEmpty) {
      unawaited(GuideAudio.play('guidance/guidance_plate.mp3'));
      return _fail(
          'Bhai, pehle apni gaari par number likhwayen — number plate lagwayen — us ke baad hi gaari change aage badhegi, warna nahi badhegi.');
    }
    if (_front.isEmpty) {
      return _fail('Gaari ki SAMNE wali tasveer lazmi hai — plate saaf nazar aye.');
    }
    if (_back.isEmpty) return _fail('Gaari ki PEECHE wali tasveer lazmi hai.');
    if (_left.isEmpty) return _fail('Gaari ki BAYEIN taraf ki tasveer lazmi hai.');
    if (_right.isEmpty) {
      return _fail('Gaari ki DAYEIN taraf ki tasveer lazmi hai.');
    }
    if (_interior.isEmpty) {
      return _fail('Gaari ke ANDAR ki tasveer lazmi hai (meter/seat).');
    }
    if (_reg.isEmpty) {
      return _fail('Gaari ke kaghaz (registration) ki tasveer lazmi hai.');
    }
    if (_selfie.isEmpty) {
      return _fail('Live selfie lazmi hai — camera se abhi lein.');
    }
    // EK GAARI = EK ID: plate doosri ID par ho (aur is driver ki
    // apni mojooda plate se alag ho) to wazahat wala rasta।
    final plateNorm = _normPlate(_plateCtrl.text);
    if (plateNorm.length >= 4 && plateNorm != _normPlate(p.plate)) {
      setState(() => _busy = true);
      final owners = await Backend.fetchPlateOwners();
      if (!mounted) return false;
      setState(() => _busy = false);
      if (owners != null) {
        for (final o in owners) {
          final oid = o['id']?.toString() ?? '';
          if (oid.isEmpty || oid == store.driverId) continue;
          if (_normPlate(o['plate']?.toString() ?? '') == plateNorm) {
            final sent = await _showTransferDialog(plateNorm);
            if (!mounted) return false;
            if (sent) {
              return _fail(
                  'Aap ki wazahat Master ko bhej di gayi hai — ye gaari abhi doosri ID par darj hai, is liye change yahin ruke ga. Master faisla kare to gaari aap ki ID par lag jayegi.');
            }
            return _fail(
                'Ye gaari (plate $plateNorm) pehle se ek aur driver ki ID par darj hai — ek gaari sirf ek hi ID par ho sakti hai. Apni gaari ka asal number plate darj karein aur documents complete karein, ya wazahat Master ko bhejein.');
          }
        }
      }
    }
    return true;
  }

  Future<bool> _showTransferDialog(String plateNorm) async {
    final ctrl = TextEditingController();
    final sent = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Ye gaari doosri ID par hai'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Plate $plateNorm pehle se ek aur driver ki ID par darj hai.\n\nAgar ye gaari asal mein AAP ki hai, to neeche saari tafseel likhein. Master wazahat dekh kar faisla karega; manzoori par gaari purani ID se hat kar aap ki ID par lag jayegi.',
                style: const TextStyle(fontSize: 13.5, height: 1.45),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: ctrl,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Apni wazahat — saari tafseel',
                  border: OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Rehne Dein'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Master ko Wazahat Bhejein'),
          ),
        ],
      ),
    );
    final tafseel = ctrl.text.trim();
    ctrl.dispose();
    if (sent != true) return false;
    await store.addMasterMessage(MasterMessage(
      id: store.newId(),
      senderKey: store.driverId,
      senderRole: 'driver',
      senderName: p.name,
      senderMobile: p.phone,
      senderZone: p.zone,
      category: 'Gaari Transfer',
      body: 'GAARI TRANSFER WAZAHAT (Gaari Change)\n'
          'Plate: ${_plateCtrl.text.trim()} (normalized: $plateNorm)\n'
          'Gaari: $_vehicle · ${_brandCtrl.text.trim()} ${_modelCtrl.text.trim()}\n'
          'Masla: gaari change ke doran ye gaari doosri driver ID par darj mili — change wahin ruk gaya hai.\n'
          'Driver ki wazahat: ${tafseel.isEmpty ? '(tafseel nahi likhi)' : tafseel}',
      createdAt: DateTime.now(),
    ));
    return true;
  }

  Future<void> _submit() async {
    if (_busy) return;
    if (!await _validate()) return;
    if (!mounted) return;
    setState(() => _busy = true);
    final change = <String, dynamic>{
      'vehicle': _vehicle,
      'plate': _plateCtrl.text.trim(),
      'brand': _brandCtrl.text.trim(),
      'model': _modelCtrl.text.trim(),
      'year': _year ?? 0,
      'color': _colorCtrl.text.trim(),
      'photo_front_local': _front,
      'photo_back_local': _back,
      'photo_left_local': _left,
      'photo_right_local': _right,
      'photo_interior_local': _interior,
      'reg_local': _reg,
      'selfie_local': _selfie,
      'requested_at': DateTime.now().toIso8601String(),
    };
    final pushed = await Backend.submitVehicleChange(store, change);
    await store.submitVehicleChangeLocal(change);
    if (!mounted) return;
    setState(() => _busy = false);
    _snack(pushed
        ? 'Gaari change ki darkhwast Master ko bhej di gayi hai — Tasdeeq ke baad aap ki yehi ID nayi gaari par update ho jayegi.'
        : 'Darkhwast is phone par mehfooz hai — connection theek honay par Profile se dobara bhej dein (Master tak abhi nahi gayi).');
    if (pushed) Navigator.of(context).pop(true);
  }

  Widget _slot(String label, String path, void Function(String) apply,
      {bool cameraOnly = false}) {
    final has = path.isNotEmpty && File(path).existsSync();
    return InkWell(
      onTap: () => _pick(apply, cameraOnly: cameraOnly),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        height: 104,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: path.isNotEmpty ? Brand.green : Brand.fieldBorder,
              width: 1.6),
          color: Brand.lightBg,
        ),
        child: has
            ? ClipRRect(
                borderRadius: BorderRadius.circular(11),
                child: Image.file(File(path),
                    width: double.infinity, height: 104, fit: BoxFit.cover),
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.photo_camera,
                      color: Brand.green, size: 26),
                  const SizedBox(height: 6),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    child: Text(label,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontSize: 12, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final years = <int>[
      for (var y = DateTime.now().year + 1; y >= 1990; y--) y
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Gaari Change Karein')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Nayi gaari ki POORI tafseel dein — bilkul pehli registration ki tarah: tafseel, chaaron taraf ki photos, kaghaz aur live selfie. Master ki tasdeeq ke baad aap ki WOHI ID nayi gaari par update ho jayegi — nayi ID nahi bane gi, aur purani gaari aap ke record (history) mein mehfooz rahegi.',
            style: TextStyle(fontSize: 13.5, height: 1.5),
          ),
          const SizedBox(height: 16),
          const Text('Gaari ki qisam',
              style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: kVehicles
                .map((v) => ChoiceChip(
                      label: Text(v),
                      selected: _vehicle == v,
                      onSelected: (_) => setState(() => _vehicle = v),
                    ))
                .toList(),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _brandCtrl,
            decoration: const InputDecoration(
                labelText: 'Company / Brand', prefixIcon: Icon(Icons.factory)),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _modelCtrl,
            decoration: const InputDecoration(
                labelText: 'Model', prefixIcon: Icon(Icons.directions_car)),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            value: _year,
            isExpanded: true,
            decoration: const InputDecoration(
                labelText: 'Saal (Year)',
                prefixIcon: Icon(Icons.calendar_month)),
            items: years
                .map((y) => DropdownMenuItem(value: y, child: Text('$y')))
                .toList(),
            onChanged: (v) => setState(() => _year = v),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _colorCtrl,
            decoration: const InputDecoration(
                labelText: 'Rang (Color)', prefixIcon: Icon(Icons.palette)),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _plateCtrl,
            decoration: const InputDecoration(
                labelText: 'Number plate',
                hintText: 'Samne ya peeche — kam az kam ek taraf lazmi',
                prefixIcon: Icon(Icons.pin)),
          ),
          const SizedBox(height: 16),
          const Text('Gaari ki tasaveer — chaaron taraf + andar',
              style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: _slot('Samne (plate saaf)', _front, (v) => _front = v)),
              const SizedBox(width: 10),
              Expanded(child: _slot('Peeche', _back, (v) => _back = v)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _slot('Bayein taraf', _left, (v) => _left = v)),
              const SizedBox(width: 10),
              Expanded(child: _slot('Dayein taraf', _right, (v) => _right = v)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _slot('Andar (meter/seat)', _interior, (v) => _interior = v)),
              const SizedBox(width: 10),
              Expanded(child: _slot('Kaghaz (Registration)', _reg, (v) => _reg = v)),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Live Selfie (lazmi)',
              style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          _slot('Live selfie — camera se', _selfie, (v) => _selfie = v,
              cameraOnly: true),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!,
                style: const TextStyle(
                    color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
          ],
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _busy ? null : _submit,
              icon: _busy
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.swap_horiz),
              label: Text(
                  _busy ? 'Ho raha hai…' : 'Darkhwast Master ko Bhejein'),
              style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14)),
            ),
          ),
        ],
      ),
    );
  }
}
