// v1.4.35 WAVE tests — (1) update ki AWAAZ wala elan (pure logic),
// (2) i18n D-1/P-1 naye keys ka namuna, (3) D-4 Raast single
// source, (5) P-2 saved places merge, (6) C-2 Mera Data export।
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:safar/data_export.dart';
import 'package:safar/lang.dart';
import 'package:safar/store.dart';
import 'package:safar/voice.dart';

Booking _bk(String id, {String status = 'completed', int fare = 210}) =>
    Booking(
      id: id,
      passengerName: 'Ahmed',
      passengerPhone: '03001234567',
      pickupLabel: 'Clifton',
      dropLabel: 'Saddar',
      pickupLat: 24.81,
      pickupLng: 67.03,
      dropLat: 24.86,
      dropLng: 67.0,
      hasDropPin: true,
      vehicle: 'Rickshaw',
      distanceKm: 4.2,
      fare: fare,
      note: '',
      status: status,
      createdAt: DateTime(2026, 11, 10, 10, 30),
      completedAt: DateTime(2026, 11, 10, 11, 0),
    );

SavedPlace _pl(String id, String name, String label) => SavedPlace(
      id: id,
      name: name,
      label: label,
      lat: 24.86,
      lng: 67.0,
      hasPin: true,
    );

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('v1.4.35 (1) — Update awaaz: shouldSpeakUpdateToday', () {
    const today = '2026-11-12';
    test('level 0 (koi update nahi) — kabhi NAHI bolna', () {
      expect(
          shouldSpeakUpdateToday(
              level: 0,
              sessionDone: false,
              lastSpokenDay: null,
              today: today),
          isFalse);
    });
    test('level 1, taaza din — bolna hai', () {
      expect(
          shouldSpeakUpdateToday(
              level: 1,
              sessionDone: false,
              lastSpokenDay: null,
              today: today),
          isTrue);
    });
    test('level 2 (mandatory) — bolna hai', () {
      expect(
          shouldSpeakUpdateToday(
              level: 2,
              sessionDone: false,
              lastSpokenDay: '2026-11-11',
              today: today),
          isTrue);
    });
    test('aaj pehle bol chuka — dobara NAHI', () {
      expect(
          shouldSpeakUpdateToday(
              level: 1,
              sessionDone: false,
              lastSpokenDay: today,
              today: today),
          isFalse);
    });
    test('is session mein bol chuka — dobara NAHI', () {
      expect(
          shouldSpeakUpdateToday(
              level: 2,
              sessionDone: true,
              lastSpokenDay: null,
              today: today),
          isFalse);
    });
    test('kal bola tha — aaj phir bol sakta hai', () {
      expect(
          shouldSpeakUpdateToday(
              level: 1,
              sessionDone: false,
              lastSpokenDay: '2026-11-11',
              today: today),
          isTrue);
    });
  });

  group('v1.4.35 (1) — Update awaaz: jumle', () {
    test('level 1 Urdu = malik ka tay-shuda elan', () {
      expect(updateVoiceText(1, english: false),
          'Bhai, Safar app ka naya update aa gaya hai — update kar lein.');
    });
    test('level 2 Urdu = malik wala sakht jumla', () {
      expect(updateVoiceText(2, english: false),
          'Bhai, app update karein — tabhi aap ko achi wali rides milengi');
    });
    test('English jumle Urdu se alag aur khaali nahi', () {
      expect(updateVoiceText(1, english: true), isNotEmpty);
      expect(updateVoiceText(2, english: true), isNotEmpty);
      expect(updateVoiceText(1, english: true),
          isNot(updateVoiceText(1, english: false)));
    });
  });

  group('v1.4.35 (3) — D-4 Raast single source', () {
    test('constant ki value wohi purani hai', () {
      expect(kFeeRaastNumber, '0312 2635002');
    });
    test('FAQ jawab ab constant se number leta hai', () {
      final s = trf('sup_faq_deposit', {
        'deposit': '500',
        'fee': '10',
        'raast': kFeeRaastNumber,
      });
      expect(s.contains('0312 2635002'), isTrue);
      expect(s.contains('{raast}'), isFalse,
          reason: 'placeholder render mein nahi rehna chahiye');
    });
  });

  group('v1.4.35 (2) — i18n naye keys (namuna)', () {
    test('driver/passenger naye jumle dono zubaano mein hain', () {
      Lang.current = 'ur';
      final urDrv = tr('drv_band_sadak_report_karein');
      final urPsg = tr('psg_ride_mukammal');
      Lang.current = 'en';
      final enDrv = tr('drv_band_sadak_report_karein');
      final enPsg = tr('psg_ride_mukammal');
      Lang.current = 'ur';
      expect(urDrv, 'Band Sadak? Report Karein');
      expect(enDrv, 'Blocked Road? Report It');
      expect(urPsg, 'Ride mukammal');
      expect(enPsg, 'Ride complete');
      expect(enDrv, isNot('drv_band_sadak_report_karein'));
    });
  });

  group('v1.4.35 (5) — P-2 saved places merge (union)', () {
    test('dono taraf ki jaghein mehfooz — koi ghayab nahi', () {
      final merged = mergeSavedPlaces(
        [_pl('a', 'Ghar', 'North Karachi')],
        [_pl('b', 'Daftar', 'Saddar')],
      );
      expect(merged.map((p) => p.id), ['a', 'b']);
    });
    test('ek hi id — local (taaza) jeetti hai', () {
      final merged = mergeSavedPlaces(
        [_pl('a', 'Ghar', 'NAYA pata')],
        [_pl('a', 'Ghar', 'purana pata')],
      );
      expect(merged.length, 1);
      expect(merged.single.label, 'NAYA pata');
    });
    test('khaali local — server wali hi asal hain (naya phone)', () {
      final merged = mergeSavedPlaces([], [_pl('x', 'Ghar', 'Saddar')]);
      expect(merged.single.id, 'x');
    });
    test('dono khaali — khaali', () {
      expect(mergeSavedPlaces([], []), isEmpty);
    });
  });

  group('v1.4.35 (6) — C-2 Mera Data export', () {
    setUp(() {
      SharedPreferences.setMockInitialValues({});
    });
    test('driver: khaali record par imaandar "Koi record nahi"', () {
      final store = AppStore();
      final out =
          buildDriverDataExport(store, now: DateTime(2026, 11, 12));
      expect(out.contains('MERA DATA (Driver)'), isTrue);
      expect(out.contains('RIDES HISTORY'), isTrue);
      expect(out.contains('Koi record nahi'), isTrue);
      expect(out.contains('Amanat balance'), isTrue);
    });
    test('driver: asal ride + txn export mein nazar ate hain', () {
      final store = AppStore();
      store.bookings.add(_bk('r1'));
      store.txns.add(WalletTxn(
        id: 't1',
        type: 'fee',
        amount: 21,
        method: '',
        date: DateTime(2026, 11, 10),
        note: '',
      ));
      final out =
          buildDriverDataExport(store, now: DateTime(2026, 11, 12));
      expect(out.contains('Clifton → Saddar'), isTrue);
      expect(out.contains('Rs 210'), isTrue);
      expect(out.contains('Fee: Rs 21'), isTrue);
    });
    test('passenger: sahulat haalat asal numbers ke saath', () {
      final store = AppStore();
      store.passengerName = 'Fatima';
      store.sahulatStreak = 7;
      store.sahulatFreeLeft = 2;
      final out =
          buildPassengerDataExport(store, now: DateTime(2026, 11, 12));
      expect(out.contains('Fatima'), isTrue);
      expect(out.contains('streak): 7 / 20'), isTrue);
      expect(out.contains('Muft rides baqi: 2'), isTrue);
      expect(out.contains('Koi record nahi'), isTrue); // rides khaali
    });
  });
}
