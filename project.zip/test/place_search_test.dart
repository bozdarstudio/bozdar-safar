// v1.4.29 — ASAL JAGAH SEARCH (geocoding) ke unit tests:
// Nominatim JSON ki parsing, label (naam + sheher) ki tarkeeb
// aur request URI (countrycodes=pk) ki jaanch। Live network
// test NAHI hai — parsing/URI wohi hissa hai jo app chalati hai।
import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart' as ll2;
import 'package:safar/place_search.dart';

void main() {
  group('PlaceSearch — Nominatim parsing', () {
    test('"Mazar" ki misaal: Mazar-e-Quaid Karachi saaf label ke saath', () {
      // Asal Nominatim jawaab ki shakal (mukhtasar)।
      const body = '''
[
  {
    "name": "Mazar-e-Quaid",
    "display_name": "Mazar-e-Quaid, Shahrah-e-Quaideen, Karachi, Sindh, Pakistan",
    "lat": "24.8754",
    "lon": "67.0409",
    "address": {"city": "Karachi", "state": "Sindh", "country": "Pakistan"}
  },
  {
    "name": "Mazar-e-Quaid",
    "display_name": "Mazar-e-Quaid, Hyderabad, Sindh, Pakistan",
    "lat": "25.3960",
    "lon": "68.3779",
    "address": {"city": "Hyderabad", "state": "Sindh", "country": "Pakistan"}
  }
]
''';
      final results = PlaceSearch.parseResults(body);
      expect(results.length, 2);
      // Sheher label mein hai — do sheheron ki ek-naam jagah
      // alag pehchani jati hai (owner ki shart)।
      expect(results[0].label, 'Mazar-e-Quaid, Karachi');
      expect(results[1].label, 'Mazar-e-Quaid, Hyderabad');
      expect(results[0].point.latitude, closeTo(24.8754, 0.0001));
      expect(results[0].point.longitude, closeTo(67.0409, 0.0001));
    });

    test('sheher na mile to sooba label mein ata hai', () {
      final r = PlaceResult.fromNominatimJson({
        'name': 'Cholistan Fort',
        'display_name': 'Cholistan Fort, Punjab, Pakistan',
        'lat': '28.7679',
        'lon': '71.3340',
        'address': {'state': 'Punjab'},
      });
      expect(r.label, 'Cholistan Fort, Punjab');
    });

    test('khaali/ghalat jawaab par results khaali (jaali kuch NAHI)', () {
      expect(PlaceSearch.parseResults('[]'), isEmpty);
      expect(PlaceSearch.parseResults('{"error":"x"}'), isEmpty);
    });
  });

  group('PlaceSearch — request URI', () {
    test('countrycodes=pk lazmi; bias viewbox bounded=0 ke saath', () {
      final uri = PlaceSearch.buildUri('Mazar',
          near: const ll2.LatLng(24.86, 67.0));
      expect(uri.host, 'nominatim.openstreetmap.org');
      expect(uri.queryParameters['countrycodes'], 'pk');
      expect(uri.queryParameters['q'], 'Mazar');
      expect(uri.queryParameters['bounded'], '0');
      expect(uri.queryParameters.containsKey('viewbox'), isTrue);
    });

    test('3 harf se kam par network call hi NAHI hoti', () async {
      expect(await PlaceSearch.search('ab'), isEmpty);
    });
  });
}
