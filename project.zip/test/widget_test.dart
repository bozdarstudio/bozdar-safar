// v1.4.25 — asal app ka SMOKE test (purana template test hamesha
// fail hota tha: woh 'BOZDAR SAFAR' naam ka text dhoondta tha jo
// app ki kisi screen par hai hi nahi)। Ye test asal
// BozdarSafarApp ko kholta hai aur wohi check karta hai jo asal
// pehle frames mein hota hai: intro gate + board splash nazar
// ata hai, aur video na chalne par fallback rawaiye se app
// intro se aage barh jati hai (intro par rukti NAHI)।
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:safar/main.dart';

void main() {
  testWidgets('Bozdar Safar app khulta hai — intro smoke',
      (WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const BozdarSafarApp());
    await tester.pump();

    // Pehla frame: asal app shell — MaterialApp ke andar
    // IntroGate, us ke peeche BoardSplash (poster/fallback)।
    expect(find.byType(MaterialApp), findsOneWidget);
    expect(find.byType(IntroGate), findsOneWidget);
    expect(find.byType(BoardSplash), findsWidgets);

    // Test mahol mein video player nahi chalta — IntroGate ka
    // apna fallback (ya initialize timeout) use intro khatam
    // karke app ko aage bhejta hai; watchdog ki hadd ke andar
    // hi ye ho jata hai. Waqt aage barha kar wohi asal rawaiya
    // parkha jata hai।
    await tester.pump(const Duration(seconds: 10));
    await tester.pump();
    expect(find.byType(IntroGate), findsNothing);
  });
}
