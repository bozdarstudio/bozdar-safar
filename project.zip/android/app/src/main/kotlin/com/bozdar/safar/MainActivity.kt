package com.bozdar.safar

import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.util.Locale

// AGENT DEEP LINK (v1.4.7, spec §6): bozdarsafar://register?agent=CODE
// — koi nayi Flutter dependency NAHI; sirf ye MethodChannel hai.
// Cold start ka link stash ho jata hai (Dart getInitialLink se le
// leta hai); garam app par naya intent foran 'onLink' se Dart ko
// jata hai (channel abhi ready na ho to stash hi kaam ata hai —
// Dart agle getInitialLink par utha leta hai).
class MainActivity : FlutterActivity() {

    private var channel: MethodChannel? = null
    private var pendingLink: String? = null

    // AWAAZ (v1.4.35 — malik ka hukm 2026-11-12): device ka apna
    // TextToSpeech — koi pub package NAHI, deeplink wale wohi
    // MethodChannel pattern par alag channel. Dart side:
    // lib/voice.dart (Voice.speak / Voice.stop / UpdateVoice)।
    // Urdu locale (ur-PK) pehle try hota hai; phone par Urdu awaaz
    // na ho to default locale — text maujooda app zubaan mein
    // hai, is liye parha jata hai. Engine tayyar honay se pehle
    // aya jumla mehfooz rehta hai aur tayyar hotay hi bolta hai।
    private val ttsChannel = "bozdar_safar/tts"
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeak: Pair<String, Boolean>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingLink = intent?.dataString ?: pendingLink
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val link = intent.dataString ?: return
        pendingLink = link
        channel?.invokeMethod("onLink", link)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        channel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            "bozdar_safar/deeplink"
        )
        channel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "getInitialLink" -> {
                    result.success(pendingLink)
                    pendingLink = null
                }
                else -> result.notImplemented()
            }
        }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, ttsChannel)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "speak" -> speakText(
                        call.argument("text"),
                        call.argument<Boolean>("queue") == true,
                        result
                    )
                    "stop" -> {
                        tts?.stop()
                        pendingSpeak = null
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    // -----------------------------------------------------------------
    // AWAAZ (TTS) - neeche ke function (v1.4.35)
    // -----------------------------------------------------------------

    private fun ensureTts() {
        if (tts != null) return
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts
                if (engine != null) {
                    // Urdu (Pakistan) pehle; na mile to sirf Urdu;
                    // woh bhi na ho to phone ki default awaaz -
                    // Roman Urdu text har surat parha jayega.
                    val urPk = engine.setLanguage(Locale("ur", "PK"))
                    if (urPk == TextToSpeech.LANG_MISSING_DATA ||
                        urPk == TextToSpeech.LANG_NOT_SUPPORTED
                    ) {
                        val ur = engine.setLanguage(Locale("ur"))
                        if (ur == TextToSpeech.LANG_MISSING_DATA ||
                            ur == TextToSpeech.LANG_NOT_SUPPORTED
                        ) {
                            engine.setLanguage(Locale.getDefault())
                        }
                    }
                }
                ttsReady = true
                val pending = pendingSpeak
                pendingSpeak = null
                if (pending != null) {
                    doSpeak(pending.first, pending.second)
                }
            }
        }
    }

    private fun doSpeak(text: String, queue: Boolean) {
        val engine = tts ?: return
        val mode = if (queue) {
            TextToSpeech.QUEUE_ADD
        } else {
            TextToSpeech.QUEUE_FLUSH
        }
        engine.speak(text, mode, null, "safar-voice")
    }

    private fun speakText(
        text: String?,
        queue: Boolean,
        result: MethodChannel.Result
    ) {
        val t = text?.trim().orEmpty()
        if (t.isEmpty()) {
            result.success(false)
            return
        }
        ensureTts()
        if (ttsReady) {
            doSpeak(t, queue)
        } else {
            // Engine abhi tayyar ho raha hai - jumla mehfooz;
            // tayyar hotay hi bolega (ensureTts ka callback).
            // Hadd: ek hi pending slot - queue wali darkhwast
            // purane pending ko nahi hatati, nayi flush wali
            // us ki jagah le leti hai.
            if (pendingSpeak == null || !queue) {
                pendingSpeak = Pair(t, queue)
            }
        }
        result.success(true)
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}
