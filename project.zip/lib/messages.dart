import 'package:flutter/material.dart';
import 'store.dart';
import 'theme.dart';
import 'backend.dart';

/// Master ko Message (v1.2.7 — malik ka hukm): sawari ho ya driver,
/// koi masla ya shikayat ho to is screen se seedha Master (head) ko
/// message jata hai. Message pehle phone par mehfooz hota hai, phir
/// backend se Master app tak puhancta hai — offline ho to queued
/// rehta hai aur internet ate hi khud chala jata hai.
///
/// Neeche apne bheje hue messages ki list bhi hai: har ek ke saath
/// us ki haalat — "Bheja gaya" ya "Master ne parh liya".
class MasterMessagesScreen extends StatefulWidget {
  final AppStore store;

  /// 'driver' | 'passenger' — kis mode se khuli hai.
  final String role;
  const MasterMessagesScreen(
      {super.key, required this.store, required this.role});

  @override
  State<MasterMessagesScreen> createState() => _MasterMessagesScreenState();
}

class _MasterMessagesScreenState extends State<MasterMessagesScreen> {
  final _nameCtrl = TextEditingController();
  final _mobileCtrl = TextEditingController();
  final _bodyCtrl = TextEditingController();
  String _category = kMessageCategories.first;
  bool _sending = false;

  AppStore get store => widget.store;
  bool get _isDriver => widget.role == 'driver';

  /// Is role ki pehchan — backend `messages.sender_key`:
  /// driver = driverId, sawari = deviceId.
  String get _senderKey => _isDriver ? store.driverId : store.deviceId;

  /// Is role ka zone (driver ka profile zone; sawari ka zone maloom
  /// nahi hota — khaali rehta hai, jhooti value nahi jati).
  String get _zone => _isDriver ? store.profile.zone : '';

  @override
  void initState() {
    super.initState();
    if (_isDriver) {
      _nameCtrl.text = store.profile.name;
      _mobileCtrl.text = store.profile.phone;
    } else {
      // Sawari: pehle se yaad naam/mobile; na ho to aakhri booking
      // wali maloomat se bhar dete hain (fields phir bhi badle ja
      // sakte hain).
      var name = store.passengerName;
      var mobile = store.passengerPhone;
      if ((name.isEmpty || mobile.isEmpty) && store.bookings.isNotEmpty) {
        final b = store.bookings.first;
        if (name.isEmpty) name = b.passengerName;
        if (mobile.isEmpty) mobile = b.passengerPhone;
      }
      _nameCtrl.text = name;
      _mobileCtrl.text = mobile;
    }
    // Khulte hi: queued messages ki dobara koshish + read-haalat pull.
    Backend.syncMessages(store);
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _mobileCtrl.dispose();
    _bodyCtrl.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _send() async {
    final name = _nameCtrl.text.trim();
    final mobile = _mobileCtrl.text.trim();
    final body = _bodyCtrl.text.trim();
    if (name.isEmpty) {
      _snack('Apna naam likhein.');
      return;
    }
    if (mobile.isEmpty) {
      _snack('Apna mobile number likhein.');
      return;
    }
    if (body.isEmpty) {
      _snack('Message likhein — kya masla hai?');
      return;
    }
    setState(() => _sending = true);
    final m = MasterMessage(
      id: store.newId(),
      senderKey: _senderKey,
      senderRole: widget.role,
      senderName: name,
      senderMobile: mobile,
      senderZone: _zone,
      category: _category,
      body: body,
      createdAt: DateTime.now(),
    );
    // Store mein daalte hi 'message' hook backend push shuru kar deta
    // hai (best-effort); offline ho to queued rehta hai.
    await store.addMasterMessage(m);
    if (!mounted) return;
    setState(() {
      _sending = false;
      _bodyCtrl.clear();
    });
    _snack('Aap ka message Master tak bhej diya gaya hai');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Master ko Message'),
        actions: [
          IconButton(
            tooltip: 'Haalat refresh karein',
            icon: const Icon(Icons.refresh),
            onPressed: () async {
              await Backend.syncMessages(store);
              if (mounted) setState(() {});
            },
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final mine = store.masterMessages
              .where((m) => m.senderKey == _senderKey)
              .toList();
          return ListView(
            padding: const EdgeInsets.all(14),
            children: [
              const Text(
                'Koi masla, shikayat ya baat ho — yahan likhein, message seedha Master (head) ke paas jayega.',
                style: TextStyle(fontSize: 13, color: Colors.black54),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _category,
                decoration: const InputDecoration(labelText: 'Masle ki qisam'),
                items: kMessageCategories
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) =>
                    setState(() => _category = v ?? _category),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _nameCtrl,
                decoration: const InputDecoration(labelText: 'Aap ka naam'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _mobileCtrl,
                keyboardType: TextInputType.phone,
                decoration:
                    const InputDecoration(labelText: 'Mobile number'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _bodyCtrl,
                minLines: 4,
                maxLines: 7,
                decoration: const InputDecoration(
                  labelText: 'Message',
                  hintText: 'Apna masla tafseel se likhein…',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _sending ? null : _send,
                  icon: const Icon(Icons.send),
                  label:
                      Text(_sending ? 'Bhej raha hai…' : 'Message Bhejein'),
                ),
              ),
              const SizedBox(height: 20),
              const Text('Mere bheje hue messages',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              if (mine.isEmpty)
                const Text(
                  'Abhi koi message nahi bheja.',
                  style: TextStyle(color: Colors.black54),
                )
              else
                ...mine.map(_messageTile),
            ],
          );
        },
      ),
    );
  }

  Widget _messageTile(MasterMessage m) {
    final (statusText, statusColor) = !m.sent
        ? ('Abhi bheja nahi gaya — internet ate hi chala jayega',
            Brand.ajrakRed)
        : m.isRead
            ? ('Master ne parh liya', Brand.green)
            : ('Bheja gaya', const Color(0xFFB8860B));
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Chip(
                  label: Text(m.category),
                  labelStyle: const TextStyle(fontSize: 11),
                  visualDensity: VisualDensity.compact,
                ),
                const Spacer(),
                Text(
                  '${fmtDate(m.createdAt)} ${fmtTime(m.createdAt)}',
                  style: const TextStyle(color: Colors.black45, fontSize: 11),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(m.body, style: const TextStyle(fontSize: 14)),
            const SizedBox(height: 6),
            Row(
              children: [
                Icon(
                  m.isRead
                      ? Icons.done_all
                      : m.sent
                          ? Icons.done
                          : Icons.schedule,
                  size: 15,
                  color: statusColor,
                ),
                const SizedBox(width: 5),
                Text(
                  statusText,
                  style: TextStyle(
                      color: statusColor,
                      fontSize: 12,
                      fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
