import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'store.dart';
import 'theme.dart';

// ===========================================================================
// v1.4.0 — Kami Fix Wave ke mushtarka UI hisse:
//  - Notification bell (dono modes) + Notification Centre screen
//  - Foreground banner: naya event ate hi saamne wali screen par snackbar
//  - SOS button (active ride — passenger + driver dono)
//  - Ride ki RASEED (receipt) dialog + share
//  - Rating wale sitare (passenger, completed ride par)
// Ye sab is liye EK file mein hain taaki passenger.dart aur
// driver.dart dono baghair duplicate code ke wohi cheezein istemal
// kar sakein. Fare/display ke tamam locks in par bhi laagu hain:
// yahan koi per-km rate kabhi render NAHI hota — sirf jo kul raqam
// booking ke record mein pehle se hai (fare + waiting = total).
// ===========================================================================

/// Notification bell — AppBar-style rows mein lagta hai (BrandHeader
/// ke neeche wale toggle ke saath wali patti mein). Na-parhe events
/// par laal badge. Tap = Notification Centre; khulte hi saare
/// "parha hua" ho jate hain.
class NotificationBell extends StatelessWidget {
  final AppStore store;
  const NotificationBell({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final unread = store.unreadNotifications;
        return IconButton(
          tooltip: 'Notifications',
          onPressed: () async {
            await Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => NotificationCentreScreen(store: store),
              ),
            );
            await store.markAllNotificationsRead();
          },
          icon: Badge(
            label: Text('$unread'),
            isLabelVisible: unread > 0,
            child: const Icon(Icons.notifications, color: Brand.greenDark),
          ),
        );
      },
    );
  }
}

/// Notification Centre — saari entries (nayi upar), Master ke
/// elanaat bhi yahin. Khaali ho to saaf paigham.
class NotificationCentreScreen extends StatelessWidget {
  final AppStore store;
  const NotificationCentreScreen({super.key, required this.store});

  IconData _iconFor(String kind) => kind == 'announcement'
      ? Icons.campaign
      : kind == 'deposit'
          ? Icons.account_balance_wallet
          : Icons.directions_car;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final list = store.notifications;
          if (list.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Abhi koi notification nahi hai.\nRide ki khabar aur Safar ke elanaat yahan ayenge.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 14, color: Colors.black54),
                ),
              ),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: list.length,
            itemBuilder: (context, i) {
              final n = list[i];
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                color: n.read ? null : const Color(0xFFFFF6DA),
                child: ListTile(
                  leading: Icon(_iconFor(n.kind), color: Brand.green),
                  title: Text(n.title,
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text(
                      '${n.body}\n${fmtDate(n.createdAt)} ${fmtTime(n.createdAt)}'),
                  isThreeLine: n.body.isNotEmpty,
                ),
              );
            },
          );
        },
      ),
    );
  }
}

/// Foreground banner ka listener — jo screen saamne ho, naya
/// notification event ate hi us par ek snackbar dikhata hai
/// (ride accepted / driver pohanch gaya / elaan waghera). Dono
/// sides (PassengerSide/DriverSide) apni state mein is mixin ko
/// shamil karti hain; dispose par subscription band ho jati hai.
mixin NotificationBannerMixin<T extends StatefulWidget> on State<T> {
  StreamSubscription<AppNotification>? _notifSub;

  /// initState mein super ke baad bulayein — [store] us side ka
  /// mushtarka store hai.
  void listenNotificationBanners(AppStore store) {
    _notifSub = store.notificationEvents.stream.listen((n) {
      if (!mounted) return;
      final messenger = ScaffoldMessenger.maybeOf(context);
      if (messenger == null) return;
      messenger.showSnackBar(
        SnackBar(
          content: Text(
            n.body.isEmpty ? n.title : '${n.title} — ${n.body}',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          duration: const Duration(seconds: 4),
        ),
      );
    });
  }

  void cancelNotificationBanners() {
    _notifSub?.cancel();
    _notifSub = null;
  }
}

// ---------------------------------------------------------------------------
// SOS — active ride ke doran hifazat ka button (passenger + driver)
// ---------------------------------------------------------------------------

/// Laal SOS button. Tap → tasdeeq wala dialog → teen amal:
///  1) 1122 par call (Emergency / Rescue — tel:1122)
///  2) Master ko khabar — mojooda Master-messages raste se ek
///     SOS message Master inbox mein jata hai jis mein ride ki
///     tafseel (driver/sawari ke naam, gaari, jagah) hoti hai
///     (v1.4.4 — malik ki khaas safety shart).
///  3) "Ghar walon ko bhejo" — ride ki live tafseel (kaun, gaari,
///     plate, pickup → drop, waqt) WhatsApp par share — bilkul
///     passenger ke mojooda share-my-ride jaisa tareeqa (wa.me link).
class SosButton extends StatelessWidget {
  final AppStore store;
  final Booking booking;

  /// 'passenger' ho to share text mein driver ki pehchan jati hai;
  /// 'driver' ho to sawari ki maloomat.
  final String role;
  const SosButton({
    super.key,
    required this.store,
    required this.booking,
    required this.role,
  });

  Future<void> _confirm(BuildContext context) async {
    final b = booking;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.sos, color: Brand.ajrakRed, size: 28),
            SizedBox(width: 8),
            Text('SOS — Madad'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Khuda na khasta koi pareshani ho to foran madad lein:',
              style: TextStyle(fontSize: 13.5),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () async {
                  Navigator.pop(ctx);
                  final ok = await launchUrl(Uri.parse('tel:1122'));
                  if (!ok && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Call nahi ho saki.')),
                    );
                  }
                },
                icon: const Icon(Icons.emergency, size: 19),
                label: const Text('1122 par call karein (Emergency)'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Brand.ajrakRed,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                ),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () async {
                  Navigator.pop(ctx);
                  await store.addMasterMessage(MasterMessage(
                    id: store.newId(),
                    senderKey:
                        role == 'driver' ? store.driverId : store.deviceId,
                    senderRole: role,
                    senderName: role == 'driver'
                        ? store.profile.name
                        : b.passengerName,
                    senderMobile: role == 'driver'
                        ? store.profile.phone
                        : b.passengerPhone,
                    senderZone: store.profile.zone,
                    category: 'Ride ka masla',
                    body: 'SOS — MADAD KI ZAROORAT! '
                        '${role == 'driver' ? 'Driver' : 'Sawari'} ne chalti ride mein SOS dabai hai.\n'
                        'Ride: ${b.pickupLabel} → ${b.dropLabel} (${b.vehicle})\n'
                        'Driver: ${b.driverName}${b.driverPlate.isNotEmpty ? ' · Plate ${b.driverPlate}' : ''}\n'
                        'Sawari: ${b.passengerName}${b.passengerPhone.isNotEmpty ? ' · ${b.passengerPhone}' : ''}\n'
                        'Waqt: ${fmtDate(DateTime.now())} ${fmtTime(DateTime.now())}',
                    createdAt: DateTime.now(),
                  ));
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content:
                              Text('Master ko SOS khabar bhej di gayi hai.')),
                    );
                  }
                },
                icon: const Icon(Icons.support_agent, size: 19),
                label: const Text('Master ko khabar bhejein'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Brand.deepGreen,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                ),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  Navigator.pop(ctx);
                  final text = _shareText();
                  final uri = Uri.parse(
                      'https://wa.me/?text=${Uri.encodeComponent(text)}');
                  final ok = await launchUrl(uri,
                      mode: LaunchMode.externalApplication);
                  if (!ok && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('WhatsApp nahi khul saka.')),
                    );
                  }
                },
                icon: const Icon(Icons.share, size: 18),
                label: const Text('Ride ghar walon ko bhejo (WhatsApp)'),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '${b.pickupLabel} → ${b.dropLabel} · ${b.vehicle}',
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Band Karein'),
          ),
        ],
      ),
    );
  }

  String _shareText() {
    final b = booking;
    final p = store.profile;
    final who = role == 'passenger'
        ? 'Driver: ${b.driverName} (${p.vehicle}${p.plate.isEmpty ? '' : ' · Plate ${p.plate}'})'
        : 'Sawari: ${b.passengerName}${b.passengerPhone.isEmpty ? '' : ' (${b.passengerPhone})'} · Gaari: ${b.vehicle}';
    return 'SOS — Safar ride ki tafseel:\n'
        '$who\n'
        'Route: ${b.pickupLabel} → ${b.dropLabel}\n'
        'Waqt: ${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)}\n'
        'Main is ride mein hun — zaroorat par madad karein.';
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: () => _confirm(context),
        icon: const Icon(Icons.sos, size: 20),
        label: const Text('SOS — Hifazat'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Brand.ajrakRed,
          padding: const EdgeInsets.symmetric(vertical: 11),
          textStyle:
              const TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// RASEED (Receipt) — mukammal ride ki saaf raseed + share
// ---------------------------------------------------------------------------

/// Raseed ka mutan (text) — dialog aur WhatsApp share dono yahi
/// istemal karte hain. Sirf wohi numbers jo booking record mein
/// pehle se hain: base kiraya (fare), waiting charges, kul total —
/// koi per-km rate kabhi NAHI likha jata (fare display lock).
String receiptText(AppStore store, Booking b) {
  final p = store.profile;
  return 'SAFAR — Ride ki Raseed\n'
      'Ride ID: ${b.id}\n'
      'Tareekh: ${fmtDate(b.completedAt ?? b.createdAt)} ${fmtTime(b.completedAt ?? b.createdAt)}\n'
      'Route: ${b.pickupLabel} → ${b.dropLabel}\n'
      'Doori: ${b.distanceKm.toStringAsFixed(1)} km\n'
      'Kiraya: ${rs(b.fare)}\n'
      'Waiting charges: ${rs(b.waitingCharge)}\n'
      'KUL: ${rs(b.total)}\n'
      'Gaari: ${b.vehicle}${p.plate.isEmpty ? '' : ' · Plate ${p.plate}'}\n'
      'Driver: ${b.driverName}\n'
      'Adaigi: Cash';
}

/// Mukammal ride ki RASEED dialog mein dikhana — ride id, tareekh,
/// route, doori, kiraaye ki tafseel (base + waiting), kul, gaari +
/// driver + plate, payment method (Cash), aur Share button
/// (WhatsApp par text — app ke mojooda share wale tareeqe se).
Future<void> showReceiptDialog(
    BuildContext context, AppStore store, Booking b) async {
  final p = store.profile;
  Widget row(String label, String value, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 118,
            child: Text(label,
                style: const TextStyle(fontSize: 13, color: Colors.black54)),
          ),
          Expanded(
            child: Text(value,
                style: TextStyle(
                    fontSize: 13.5,
                    fontWeight: bold ? FontWeight.w900 : FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  await showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      title: const Row(
        children: [
          Icon(Icons.receipt_long, color: Brand.green, size: 26),
          SizedBox(width: 8),
          Text('Ride ki Raseed'),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            row('Ride ID', b.id),
            row('Tareekh',
                '${fmtDate(b.completedAt ?? b.createdAt)} ${fmtTime(b.completedAt ?? b.createdAt)}'),
            row('Route', '${b.pickupLabel} → ${b.dropLabel}'),
            row('Doori', '${b.distanceKm.toStringAsFixed(1)} km'),
            const Divider(),
            row('Kiraya', rs(b.fare)),
            row('Waiting', rs(b.waitingCharge)),
            row('KUL', rs(b.total), bold: true),
            const Divider(),
            row('Gaari',
                '${b.vehicle}${p.plate.isEmpty ? '' : ' · Plate ${p.plate}'}'),
            row('Driver', b.driverName),
            row('Adaigi', 'Cash'),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Band Karein'),
        ),
        ElevatedButton.icon(
          onPressed: () async {
            final uri = Uri.parse(
                'https://wa.me/?text=${Uri.encodeComponent(receiptText(store, b))}');
            final ok =
                await launchUrl(uri, mode: LaunchMode.externalApplication);
            if (!ok && ctx.mounted) {
              ScaffoldMessenger.of(ctx).showSnackBar(
                const SnackBar(content: Text('WhatsApp nahi khul saka.')),
              );
            }
          },
          icon: const Icon(Icons.share, size: 17),
          label: const Text('Share Karein'),
        ),
      ],
    ),
  );
}

// ---------------------------------------------------------------------------
// v1.4.4 — WAJAH wala sheet, Report/Shikayat, Driver ki sawari ko rating
// ---------------------------------------------------------------------------

/// WAJAH poochhne wala mushtarka bottom sheet (v1.4.4 — malik ki
/// khaas shart): tay-shuda wajahen ([options], aam tor par
/// kRideReasonOptions) mein se ek chunna lazmi hai; neeche apni
/// baat likhne ki jagah bhi hai (likhi jaye to wajah ke saath jud
/// kar mehfooz hoti hai). "Jama Karein" par mukammal wajah text
/// wapas ata hai; sheet band karne par null (koi action nahi).
Future<String?> showReasonSheet(
  BuildContext context, {
  required String title,
  required List<String> options,
  String submitLabel = 'Jama Karein (Submit)',
}) async {
  var selected = -1;
  final textCtrl = TextEditingController();
  final result = await showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (sheetCtx) => StatefulBuilder(
      builder: (sheetCtx, setSheetState) => Padding(
        padding: EdgeInsets.fromLTRB(
          18,
          12,
          18,
          22 + MediaQuery.of(sheetCtx).viewInsets.bottom,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 5,
                  decoration: BoxDecoration(
                    color: Brand.fieldBorder,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(title,
                  style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w900,
                      color: Brand.greenDark)),
              const SizedBox(height: 4),
              const Text(
                'Wajah ride ke record ke saath mehfooz rahegi — taaki company ko asal baat pata chale.',
                style: TextStyle(fontSize: 12, color: Colors.black54),
              ),
              const SizedBox(height: 8),
              ...options.asMap().entries.map((e) {
                final isSel = selected == e.key;
                return InkWell(
                  onTap: () => setSheetState(() => selected = e.key),
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Row(
                      children: [
                        Container(
                          width: 22,
                          height: 22,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color:
                                  isSel ? Brand.green : const Color(0xFFB9CFC6),
                              width: 2,
                            ),
                          ),
                          child: isSel
                              ? Center(
                                  child: Container(
                                    width: 11,
                                    height: 11,
                                    decoration: const BoxDecoration(
                                      color: Brand.green,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                )
                              : null,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(e.value,
                              style: const TextStyle(fontSize: 15)),
                        ),
                      ],
                    ),
                  ),
                );
              }),
              const SizedBox(height: 6),
              TextField(
                controller: textCtrl,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Apni baat (ikhtiyari)',
                  hintText: 'Kuch aur batana ho to yahan likhein…',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: selected < 0
                      ? null
                      : () {
                          final base = options[selected];
                          final extra = textCtrl.text.trim();
                          Navigator.pop(
                            sheetCtx,
                            extra.isEmpty ? base : '$base — $extra',
                          );
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Brand.deepGreen,
                    disabledBackgroundColor: Brand.lightBg,
                    disabledForegroundColor: Colors.black38,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    textStyle: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800),
                  ),
                  child: Text(submitLabel),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
  textCtrl.dispose();
  return result;
}

/// Ek mukammal ride ki REPORT / Shikayat (v1.4.4): category +
/// apni baat → mojooda Master-messages raste se Master inbox
/// mein jata hai, ride ke poore hawale ke saath. Sawari aur
/// driver dono istemal kar sakte hain ([role]).
Future<void> showReportDialog(
  BuildContext context,
  AppStore store,
  Booking b, {
  required String role,
}) async {
  var category = kMessageCategories[2]; // 'Driver ki shikayat'
  if (role == 'driver') category = kMessageCategories[3];
  final textCtrl = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setD) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Report / Shikayat'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('${b.pickupLabel} → ${b.dropLabel}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 13.5)),
              Text(
                '${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)} · ${b.vehicle} · ${rs(b.total)}',
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(
                  labelText: 'Shikayat ki qism',
                  isDense: true,
                ),
                items: kMessageCategories
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) => setD(() => category = v ?? category),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: textCtrl,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Apni baat likhein',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Rehne Dein'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Report Bhejein'),
          ),
        ],
      ),
    ),
  );
  if (ok != true) {
    textCtrl.dispose();
    return;
  }
  final detail = textCtrl.text.trim();
  textCtrl.dispose();
  await store.addMasterMessage(MasterMessage(
    id: store.newId(),
    senderKey: role == 'driver' ? store.driverId : store.deviceId,
    senderRole: role,
    senderName:
        role == 'driver' ? store.profile.name : b.passengerName,
    senderMobile:
        role == 'driver' ? store.profile.phone : b.passengerPhone,
    senderZone: store.profile.zone,
    category: category,
    body: 'RIDE REPORT — Ride ID: ${b.id}\n'
        'Route: ${b.pickupLabel} → ${b.dropLabel} (${b.vehicle})\n'
        'Waqt: ${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)} · Kul kiraya ${rs(b.total)}\n'
        'Driver: ${b.driverName} · Sawari: ${b.passengerName}'
        '${detail.isEmpty ? '' : '\nBaat: $detail'}',
    createdAt: DateTime.now(),
  ));
  if (context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Report Master ko bhej di gayi hai.')),
    );
  }
}

/// Driver ki SAWARI ko rating wali patti (v1.4.4) — mukammal ride
/// par driver 1–5 sitare de sakta hai. Rating ride ke apne record
/// par (Booking.passengerRating) rehti hai aur backend
/// rides.passenger_rating mein Master ko nazar ati hai. Pehle se
/// di ho to wohi sitare bharay nazar ate hain; dobara tap = update.
class PassengerRatingRow extends StatefulWidget {
  final AppStore store;
  final Booking booking;
  const PassengerRatingRow(
      {super.key, required this.store, required this.booking});

  @override
  State<PassengerRatingRow> createState() => _PassengerRatingRowState();
}

class _PassengerRatingRowState extends State<PassengerRatingRow> {
  AppStore get store => widget.store;
  Booking get b => widget.booking;

  @override
  Widget build(BuildContext context) {
    final stars = b.passengerRating;
    return Row(
      children: [
        const Text('Sawari ko rating: ',
            style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
        for (var i = 1; i <= 5; i++)
          InkWell(
            onTap: () async {
              await store.savePassengerRating(b, i);
              if (mounted) setState(() {});
            },
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: const EdgeInsets.all(2),
              child: Icon(
                i <= stars ? Icons.star : Icons.star_border,
                color: Brand.gold,
                size: 24,
              ),
            ),
          ),
        if (stars > 0)
          const Text(' darj hai',
              style: TextStyle(fontSize: 12, color: Colors.black54)),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Rating — passenger ki di gayi 1–5 sitare wali rating
// ---------------------------------------------------------------------------

/// Completed ride par rating wali patti: sitare tap karke chunna,
/// ikhtiyari comment, "Rating Bhejein". Rating pehle se di ho to
/// wohi sitare bharay nazar ate hain aur dobara bhejna usi record
/// ko update karta hai. Sirf passenger ke istemal ke liye.
class RatingRow extends StatefulWidget {
  final AppStore store;
  final Booking booking;
  const RatingRow({super.key, required this.store, required this.booking});

  @override
  State<RatingRow> createState() => _RatingRowState();
}

class _RatingRowState extends State<RatingRow> {
  int _stars = 0;
  bool _saving = false;
  final _commentCtrl = TextEditingController();

  AppStore get store => widget.store;
  Booking get b => widget.booking;

  @override
  void initState() {
    super.initState();
    final r = store.ratingFor(b.id);
    _stars = r?.stars ?? 0;
    _commentCtrl.text = r?.comment ?? '';
  }

  @override
  void dispose() {
    _commentCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_stars <= 0 || _saving) return;
    setState(() => _saving = true);
    await store.saveRating(RideRating(
      bookingId: b.id,
      // v1.4.2: rating ASAL driver ko jati hai — do-phone par woh
      // backend se aya assignedDriverId hai; same-device par wohi
      // is phone ka driverId hota hai.
      driverId: b.assignedDriverId.isNotEmpty
          ? b.assignedDriverId
          : store.driverId,
      driverName: b.driverName,
      passengerName: b.passengerName,
      stars: _stars,
      comment: _commentCtrl.text.trim(),
      createdAt: DateTime.now(),
    ));
    if (!mounted) return;
    setState(() => _saving = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Shukriya! Aap ki rating darj ho gayi.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final already = store.ratingFor(b.id) != null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Driver ko rating dein',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
        const SizedBox(height: 2),
        Row(
          children: [
            for (var i = 1; i <= 5; i++)
              IconButton(
                onPressed: () => setState(() => _stars = i),
                icon: Icon(
                  i <= _stars ? Icons.star : Icons.star_border,
                  color: Brand.gold,
                  size: 30,
                ),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 40, minHeight: 40),
                tooltip: '$i sitare',
              ),
            const Spacer(),
            if (already && !_saving)
              const Text('Rating di hui hai',
                  style: TextStyle(fontSize: 12, color: Colors.black54)),
          ],
        ),
        TextField(
          controller: _commentCtrl,
          decoration: const InputDecoration(
            labelText: 'Comment (ikhtiyari)',
            isDense: true,
          ),
          maxLines: 1,
        ),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: _stars <= 0 || _saving ? null : _save,
            child: Text(_saving
                ? 'Darj ho raha hai…'
                : already
                    ? 'Rating Update Karein'
                    : 'Rating Bhejein'),
          ),
        ),
      ],
    );
  }
}
