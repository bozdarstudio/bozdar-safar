import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'store.dart';
import 'theme.dart' show rs;

/// SAFAR backend sync (v1.1.0) — Supabase REST, sirf dart:io HttpClient.
///
/// Usool:
/// - Local store hamesha asal sach hai; backend us ka AAINA (mirror) hai
///   taaki Master app mein sab kuch nazar aye.
/// - Har network kaam best-effort hai: offline/error par bilkul khamosh —
///   UI kabhi nahi rukti, koi error kabhi nahi dikhta, app crash nahi hota.
/// - Settings ka rukh sirf EK taraf hai: Master (backend) → app. Is app
///   mein settings ka koi editor nahi; server na mile to akhri cached
///   values, woh bhi na hon to built-in defaults chalte hain.
/// - Column/table naam backend-schema.sql ke ain mutabiq hain.
class Backend {
  static const String _base =
      'https://ndcnqotfqpgkgsngewug.supabase.co/rest/v1';
  // Publishable (client) key — apps mein embed karna mehfooz hai;
  // secret key kabhi app mein nahi jati.
  static const String _key =
      'sb_publishable_3TWtf4zT6xJzuyb0fsMuWQ_Fjkyk3LE';
  static const String _storageBase =
      'https://ndcnqotfqpgkgsngewug.supabase.co/storage/v1';
  static const Duration _timeout = Duration(seconds: 8);

  static AppStore? _store;
  static bool _started = false;

  /// App start par EK dafa — main.dart se. Store ke sync hook ko jodta
  /// hai aur pehla sync (device entry, settings, zones, driver status)
  /// background mein chalata hai. Dobara bulane par kuch nahi hota.
  static void start(AppStore store) {
    if (_started) return;
    _started = true;
    _store = store;
    store.syncHook = _onHook;
    unawaited(_startup(store));
  }

  static Future<void> _startup(AppStore store) async {
    // Pehle cached settings (offline ho to bhi Master ki akhri setting
    // chalti rahe), phir fresh pull.
    await _applyCachedSettings();
    await touchDevice(store, 'passenger');
    await _pullSettings();
    await _pullZones(store);
    await refreshDriverStatus(store);
    if (_registered(store)) await _pushDriver(store);
    // Registration documents ki tasaveer (v1.2.8 — TASDEEQ): jo kind
    // abhi upload nahi hua (ya photo badal gayi hai) woh yahan
    // khamoshi se dobara koshish hota hai — Master har document asal
    // tasveer mein check karega, is ke baghair ID active nahi hogi.
    await syncDriverDocs(store);
    // Aaj ki selfie ki TASVEER agar pichli koshish mein upload nahi
    // ho saki thi to yahan khamoshi se dobara koshish (best-effort).
    if (store.profile.selfieToday &&
        store.profile.selfieUploadedDate != store.profile.selfieDate) {
      await _pushSelfie(store, store.profile.selfieDate);
    }
    // Master messages (v1.2.7): queued messages ki dobara koshish +
    // "Master ne parh liya" wali haalat pull.
    await syncMessages(store);
  }

  // --- HTTP helpers (sab khamosh — fail = null/false) ------------------------

  static Future<dynamic> _get(String path) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client.getUrl(Uri.parse('$_base/$path')).timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      final resp = await req.close().timeout(_timeout);
      final body = await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode != 200) return null;
      return jsonDecode(body);
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  /// PK par upsert (insert ya update) — PostgREST merge-duplicates.
  /// Jo columns bheje jate hain sirf wohi likhe jate hain.
  static Future<bool> _upsert(String table, Map<String, dynamic> row) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req =
          await client.postUrl(Uri.parse('$_base/$table')).timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      req.headers.set('Prefer', 'resolution=merge-duplicates,return=minimal');
      req.write(jsonEncode(row));
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      return resp.statusCode >= 200 && resp.statusCode < 300;
    } catch (_) {
      return false;
    } finally {
      client?.close();
    }
  }

  // --- Devices ---------------------------------------------------------------

  /// Har app khulne par + mode badalne par: is phone ki entry taza.
  /// first_seen sirf pehli insert par banta hai (server default).
  static Future<void> touchDevice(AppStore store, String mode) async {
    if (store.deviceId.isEmpty) return;
    await _upsert('devices', {
      'device_id': store.deviceId,
      'last_seen': DateTime.now().toUtc().toIso8601String(),
      'last_mode': mode,
      'role': mode,
      'app_version': kAppVersion,
    });
  }

  // --- Settings (Master → app, ek rukh) --------------------------------------

  static Future<void> _applyCachedSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('srv_settings_json');
      if (raw == null) return;
      final j = jsonDecode(raw);
      if (j is Map<String, dynamic>) _applySettings(j);
    } catch (_) {
      // Cache kharab ho to defaults hi sahi.
    }
  }

  static Future<void> _pullSettings() async {
    final data = await _get('settings?select=*&id=eq.1');
    if (data is! List || data.isEmpty) return;
    final row = data.first;
    if (row is! Map<String, dynamic>) return;
    _applySettings(row);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('srv_settings_json', jsonEncode(row));
    } catch (_) {
      // Cache na likha jaye to koi baat nahi — values lag chuki hain.
    }
  }

  static void _applySettings(Map<String, dynamic> s) {
    Map<String, int>? intMap(dynamic v) {
      if (v is! Map) return null;
      final out = <String, int>{};
      v.forEach((k, val) {
        final n = val is num ? val.toInt() : int.tryParse('$val');
        if (n != null) out['$k'] = n;
      });
      return out;
    }

    Fares.applyServerSettings(
      feePercent: (s['fee_percent'] as num?)?.toDouble(),
      rates: intMap(s['rate_per_km']),
      waiting: intMap(s['waiting_per_min']),
      freeWaitingMin: (s['free_waiting_min'] as num?)?.toInt(),
      deposit: (s['joining_deposit'] as num?)?.toInt(),
    );
  }

  // --- Zones -----------------------------------------------------------------

  /// Server par band (open=false) zone passenger ki list se nikal jata
  /// hai. Server khaali mile to local [kZones] hi rehte hain.
  static Future<void> _pullZones(AppStore store) async {
    final data = await _get('zones?select=name,open');
    if (data is! List || data.isEmpty) return;
    final openByName = <String, bool>{};
    for (final r in data) {
      if (r is Map && r['name'] is String) {
        openByName[r['name'] as String] = r['open'] == true;
      }
    }
    if (openByName.isEmpty) return;
    final visible = <String>[
      ...kZones.where((z) => openByName[z] != false),
      // Master ne naya zone joda ho to woh bhi (agar khula hai).
      ...openByName.keys
          .where((z) => !kZones.contains(z) && openByName[z] == true),
    ];
    store.applyServerZones(visible);
  }

  // --- Driver ----------------------------------------------------------------

  /// Registration tabhi mana jata hai jab profile mein naam + mobile
  /// dono mojood hon (Profile Save se ate hain).
  static bool _registered(AppStore store) =>
      store.driverId.isNotEmpty &&
      store.profile.name.trim().isNotEmpty &&
      store.profile.phone.trim().isNotEmpty;

  /// Driver row ka pura mirror — registration (status pending: active
  /// hamesha akhri maloom Master value hi bhejte hain taaki Master ki
  /// ACTIVE tasdeeq is upsert se mit na jaye), online/offline,
  /// wallet balance, documents ki haalat.
  static Future<void> _pushDriver(AppStore store) async {
    if (!_registered(store)) return;
    final p = store.profile;
    final row = <String, dynamic>{
      'id': store.driverId,
      'name': p.name,
      'mobile': p.phone,
      'vehicle': p.vehicle,
      'plate': p.plate,
      'zone': p.zone,
      'active': p.masterActive,
      'online': p.online,
      'on_ride': store.bookings
          .any((b) => b.status == 'accepted' || b.status == 'arrived'),
      'cnic_status': p.cnicStatus,
      'licence_status': p.licenceStatus == 'none'
          ? 'none'
          : (p.licenceVerified ? 'verified' : 'pending'),
      'gaari_status': p.vehiclePapers,
      'wallet_balance': p.walletBalance,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    };
    // Driver ki akhri GPS jagah — schema ke lat/lng columns pehle se
    // maujood hain (Master map inhi se asal jagah dikhata hai). Sirf
    // tab bhejte hain jab position maloom ho: null bhej kar kisi
    // purani achhi value ko kabhi mitaya nahi jata.
    if (p.lastLat != null && p.lastLng != null) {
      row['lat'] = p.lastLat;
      row['lng'] = p.lastLng;
    }
    // Password ka sirf FINGERPRINT (v1.2.5) — asal password kabhi
    // network par nahi jata. Sirf tab bhejte hain jab set ho.
    if (p.pwdFp.isNotEmpty) {
      row['pwd_fp'] = p.pwdFp;
    }
    // Registration wizard (v1.2.6) ki tafseel — columns migration
    // backend-migration-v126.sql se bante hain. Sirf bhari hui values
    // bhejte hain (khaali bhej kar purani value nahi mitate).
    // (v1.2.8: document tasaveer ab Storage bucket 'driver-docs'
    // mein bhi jati hain — neeche wale *_path columns dekhein.)
    if (p.cnicNumber.isNotEmpty) row['cnic_number'] = p.cnicNumber;
    if (p.licenceNumber.isNotEmpty) {
      row['licence_number'] = p.licenceNumber;
    }
    if (p.vehicleBrand.isNotEmpty) row['vehicle_brand'] = p.vehicleBrand;
    if (p.vehicleModel.isNotEmpty) row['vehicle_model'] = p.vehicleModel;
    if (p.vehicleYear > 0) row['vehicle_year'] = p.vehicleYear;
    if (p.vehicleColor.isNotEmpty) row['vehicle_color'] = p.vehicleColor;
    // Registration documents ke backend object paths (v1.2.8) — sirf
    // us kind ka path jata hai jis ki tasveer asal mein upload ho
    // chuki hai (docUploaded marker maujood hai); path ka pattern
    // tay hai: <driver_id>/<kind>.jpg. Columns migration
    // backend-migration-v128.sql se bante hain.
    String? docPath(String kind) =>
        (p.docUploaded[kind]?.isNotEmpty ?? false)
            ? '${store.driverId}/$kind.jpg'
            : null;
    final cnicFront = docPath('cnic_front');
    if (cnicFront != null) row['cnic_front_path'] = cnicFront;
    final cnicBack = docPath('cnic_back');
    if (cnicBack != null) row['cnic_back_path'] = cnicBack;
    final vehiclePhoto = docPath('vehicle');
    if (vehiclePhoto != null) row['vehicle_photo_path'] = vehiclePhoto;
    final vehicleReg = docPath('vehicle_reg');
    if (vehicleReg != null) row['vehicle_reg_path'] = vehicleReg;
    final licencePhoto = docPath('licence');
    if (licencePhoto != null) row['licence_photo_path'] = licencePhoto;
    final profilePhoto = docPath('profile');
    if (profilePhoto != null) row['profile_photo_path'] = profilePhoto;
    await _upsert('drivers', row);
  }

  /// Password UNIQUENESS check (v1.2.5): is fingerprint ke saath koi
  /// AUR driver backend par pehle se hai ya nahi.
  /// Returns: true = kisi aur ne ye password lagaya hua hai;
  /// false = khaali hai (ya sirf is driver ki apni row hai);
  /// null = backend tak pahuncha hi nahi (offline/error) — us surat
  /// mein check ko "pass" NAHI samjha jata; caller registration ko
  /// rok kar internet ka kehta hai.
  static Future<bool?> passwordFingerprintTaken(
      AppStore store, String fp) async {
    final data = await _get(
        'drivers?select=id&pwd_fp=eq.${Uri.encodeComponent(fp)}');
    if (data is! List) return null;
    for (final r in data) {
      if (r is Map && r['id'] != store.driverId) return true;
    }
    return false;
  }

  /// Master ne driver ko ACTIVE kiya hai ya nahi — app khulne par aur
  /// Profile ki refresh dabane par pull hota hai. Duty ka taala SIRF
  /// yahi [masterActive] hai — app apne aap ko KABHI active nahi
  /// karti; documents upload ho jana activation NAHI hai.
  /// Saath mein Master ki tasdeeq ki haalat (v1.2.8) bhi ati hai —
  /// sirf Profile ke display ke liye ('rejected' samait har value
  /// mehfooz hoti hai; koi local gate is se nahi badalta).
  static Future<void> refreshDriverStatus(AppStore store) async {
    if (store.driverId.isEmpty) return;
    final data = await _get(
        'drivers?select=active,cnic_status,gaari_status,licence_status&id=eq.${Uri.encodeComponent(store.driverId)}');
    if (data is! List || data.isEmpty) return;
    final row = data.first;
    if (row is Map) {
      store.setMasterActive(row['active'] == true);
      String st(String key) => row[key] is String ? row[key] as String : '';
      await store.applyMasterDocStatuses(
        cnic: st('cnic_status'),
        gaari: st('gaari_status'),
        licence: st('licence_status'),
      );
    }
  }

  // --- Store hooks → backend rows ---------------------------------------------

  static void _onHook(String kind, Object? payload) {
    final store = _store;
    if (store == null) return;
    switch (kind) {
      case 'booking':
        if (payload is Booking) unawaited(_pushRide(store, payload));
        break;
      case 'package':
        if (payload is MonthlyPackage) unawaited(_pushPackage(store, payload));
        break;
      case 'txn':
        if (payload is WalletTxn) unawaited(_pushLedger(store, payload));
        break;
      case 'profile':
        unawaited(_pushDriver(store));
        // Registration submit bhi isi hook se ata hai (store.save) —
        // document tasaveer bhi isi ke saath Master tak jati hain.
        unawaited(syncDriverDocs(store));
        break;
      case 'selfie':
        if (payload is String) unawaited(_pushSelfie(store, payload));
        break;
      case 'message':
        if (payload is MasterMessage) {
          unawaited(_pushMessage(store, payload));
        }
        break;
    }
  }

  // --- Master messages (v1.2.7) ------------------------------------------------

  /// Ek message backend `messages` table mein bhejna. Kamyabi par
  /// store mein "sent" darj ho jata hai; nakami par message queued
  /// rehta hai aur [syncMessages] agli dafa dobara koshish karta hai —
  /// UI kabhi nahi rukti, koi error nahi dikhta.
  static Future<void> _pushMessage(AppStore store, MasterMessage m) async {
    final ok = await _upsert('messages', {
      'id': m.id,
      'sender_key': m.senderKey,
      'sender_role': m.senderRole,
      'sender_name': m.senderName,
      'sender_mobile': m.senderMobile,
      'sender_zone': m.senderZone,
      'category': m.category,
      'body': m.body,
      'is_read': m.isRead,
      'created_at': m.createdAt.toUtc().toIso8601String(),
    });
    if (ok) await store.markMessageSent(m.id);
  }

  /// Queued (abhi tak na bheje gaye) messages ki dobara koshish, phir
  /// apne tamam messages ki is_read haalat pull — app start par aur
  /// Master Messages screen khulne par chalti hai. Sab best-effort.
  static Future<void> syncMessages(AppStore store) async {
    for (final m in store.masterMessages.where((m) => !m.sent).toList()) {
      await _pushMessage(store, m);
    }
    final keys = <String>{
      for (final m in store.masterMessages)
        if (m.senderKey.isNotEmpty) m.senderKey,
    };
    for (final key in keys) {
      final data = await _get(
          'messages?select=id,is_read&sender_key=eq.${Uri.encodeComponent(key)}');
      if (data is! List) continue;
      for (final r in data) {
        if (r is Map && r['id'] is String) {
          await store.applyMessageRead(
              r['id'] as String, r['is_read'] == true);
        }
      }
    }
  }

  static Future<void> _pushRide(AppStore store, Booking b) async {
    await _upsert('rides', {
      'id': b.id,
      // Booking sirf passenger banata hai; driver tab jodta hai jab
      // is phone ke driver ne use qubool kiya ho.
      'driver_id':
          (b.status == 'pending' || b.status == 'cancelled')
              ? ''
              : store.driverId,
      'passenger_name': b.passengerName,
      'passenger_mobile': b.passengerPhone,
      'pickup': b.pickupLabel,
      'drop_off': b.dropLabel,
      'vehicle': b.vehicle,
      'km': b.distanceKm,
      'waiting_minutes': b.waitingMinutes,
      'fare': b.fare,
      'waiting_charges': b.waitingCharge,
      'fee': b.status == 'completed'
          ? Fares.serviceFee(b.fare + b.waitingCharge)
          : 0,
      'status': b.status,
      'date': b.createdAt.toUtc().toIso8601String(),
    });
  }

  static Future<void> _pushPackage(AppStore store, MonthlyPackage p) async {
    await _upsert('packages', {
      'id': p.id,
      'driver_id': '',
      'customer_name': p.passengerName,
      'customer_mobile': '',
      'pickup': p.pickup,
      'drop_off': p.drop,
      'vehicle': p.vehicle,
      'km': p.routeKm,
      'days': p.days,
      'amount': p.monthlyAmount,
      'fee': Fares.serviceFee(p.monthlyAmount),
      'date': p.createdAt.toUtc().toIso8601String(),
    });
  }

  static Future<void> _pushLedger(AppStore store, WalletTxn t) async {
    // Schema ke ledger mein balance ka column NAHI hai — is liye
    // balance-after note ke aakhir mein likha jata hai. Deposit
    // positive, service-charges ki katauti negative jati hai taaki
    // Master mein kul hisaab seedha jumla ho sake.
    await _upsert('ledger', {
      'id': t.id,
      'ts': t.date.toUtc().toIso8601String(),
      'type': t.type,
      'driver_id': store.driverId,
      'amount': t.type == 'fee' ? -t.amount : t.amount,
      'note': '${t.note} · Balance: ${rs(store.profile.walletBalance)}',
    });
  }

  /// Rozana selfie (v1.2.5): pehle (driver_id, date, done) wali CHECK
  /// row — wohi jo Master pehle se parhta hai — phir asal TASVEER
  /// Storage bucket 'selfies' mein upload karke us ka path
  /// driver_selfies.image_path mein darj hota hai, taaki Master par
  /// driver ki rozana selfie asal mein bhi nazar aye. Tasveer ka
  /// upload hamesha best-effort hai: nakami par selfieUploadedDate
  /// set NAHI hota, agli sync/startup par khud dobara koshish hoti
  /// hai — duty kabhi is par nahi rukti.
  static Future<void> _pushSelfie(AppStore store, String date) async {
    if (store.driverId.isEmpty || date.isEmpty) return;
    await _upsert('driver_selfies', {
      'driver_id': store.driverId,
      'date': date,
      'done': true,
    });
    final p = store.profile;
    if (p.selfieDate != date || p.selfieUploadedDate == date) return;
    if (p.selfiePath.isEmpty) return;
    final path = await _uploadSelfieImage(store);
    if (path == null) return;
    final recorded = await _upsert('driver_selfies', {
      'driver_id': store.driverId,
      'date': date,
      'done': true,
      'image_path': path,
    });
    // Path darj na ho saka ho to "uploaded" bhi nahi kehte — agli
    // sync par dobara koshish hogi.
    if (recorded) await store.markSelfieUploaded(date);
  }

  /// Selfie ki tasveer Storage bucket 'selfies' mein:
  /// path = selfies/<driver_id>/<yyyy-mm-dd>.jpg (upsert — dobara
  /// upload ho to wohi file taza ho jati hai). Safalta par object
  /// path, nakami par null. Bucket + policies migration
  /// backend-migration-v125.sql se bante hain.
  static Future<String?> _uploadSelfieImage(AppStore store) async {
    HttpClient? client;
    try {
      final file = File(store.profile.selfiePath);
      if (!await file.exists()) return null;
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) return null;
      final objectPath =
          '${store.driverId}/${store.profile.selfieDate}.jpg';
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client
          .postUrl(Uri.parse('$_storageBase/object/selfies/$objectPath'))
          .timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'image/jpeg');
      req.headers.set('x-upsert', 'true');
      req.add(bytes);
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode >= 200 && resp.statusCode < 300) {
        return objectPath;
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  // --- Registration documents → Master Tasdeeq (v1.2.8) -----------------------

  static bool _docsSyncing = false;

  /// Registration ki document tasaveer Storage bucket 'driver-docs'
  /// mein bhejna taaki Master TASDEEQ screen mein har cheez asal
  /// tasveer mein check kar sake — baghair is ke koi ID chupke se
  /// active nahi hoti: driver app documents upload to kar sakti hai,
  /// lekin ACTIVE sirf Master karta hai (drivers.active, jo sirf
  /// [refreshDriverStatus] se pull hota hai).
  ///
  /// Har kind (cnic_front / cnic_back / vehicle / vehicle_reg /
  /// licence — sirf jab photo maujood ho — / profile) tab upload
  /// hota hai jab us ka local path khaali na ho AUR profile ke
  /// docUploaded marker se alag ho (matlab abhi upload nahi hua, ya
  /// photo dobara li gayi hai). Kamyabi par marker set hota hai aur
  /// aakhir mein _pushDriver drivers row par *_path columns likh
  /// deta hai. Sab best-effort: registration aur duty is par KABHI
  /// nahi rukti; nakami wali kind agli sync/startup par dobara
  /// koshish hoti hai.
  static Future<void> syncDriverDocs(AppStore store) async {
    if (_docsSyncing) return;
    if (!_registered(store)) return;
    final p = store.profile;
    final kinds = <String, String>{
      'cnic_front': p.cnicFrontPath,
      'cnic_back': p.cnicBackPath,
      'vehicle': p.vehiclePhotoPath,
      'vehicle_reg': p.vehicleRegPath,
      if (p.licencePhotoPath.isNotEmpty) 'licence': p.licencePhotoPath,
      'profile': p.profilePhotoPath,
    };
    final pending = kinds.entries
        .where((e) => e.value.isNotEmpty && p.docUploaded[e.key] != e.value)
        .toList();
    if (pending.isEmpty) return;
    _docsSyncing = true;
    try {
      var anyUploaded = false;
      for (final e in pending) {
        final objectPath = await _uploadDocImage(store, e.value, e.key);
        if (objectPath != null) {
          await store.markDocUploaded(e.key, e.value);
          anyUploaded = true;
        }
      }
      // Koi path naya bana ho to drivers row par bhi darj ho jaye —
      // Master Tasdeeq isi row se paths parhta hai.
      if (anyUploaded) await _pushDriver(store);
    } finally {
      _docsSyncing = false;
    }
  }

  /// Ek document ki tasveer bucket 'driver-docs' mein:
  /// path = driver-docs/<driver_id>/<kind>.jpg (upsert — dobara
  /// upload ho to wohi file taza ho jati hai). Safalta par object
  /// path, nakami par null. Bucket + policies migration
  /// backend-migration-v128.sql se bante hain. Bilkul
  /// [_uploadSelfieImage] wala andaaz.
  static Future<String?> _uploadDocImage(
      AppStore store, String localPath, String kind) async {
    HttpClient? client;
    try {
      final file = File(localPath);
      if (!await file.exists()) return null;
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) return null;
      final objectPath = '${store.driverId}/$kind.jpg';
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client
          .postUrl(Uri.parse('$_storageBase/object/driver-docs/$objectPath'))
          .timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'image/jpeg');
      req.headers.set('x-upsert', 'true');
      req.add(bytes);
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode >= 200 && resp.statusCode < 300) {
        return objectPath;
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }
}
