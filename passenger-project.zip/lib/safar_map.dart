import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart' as ll;
import 'package:maplibre_gl/maplibre_gl.dart' as ml;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'backend.dart';
import 'display_prefs.dart';
import 'lang.dart';
import 'live_dark_style.dart';
import 'place_search.dart';
import 'reroute.dart';
import 'route_service.dart';
import 'store.dart';
import 'theme.dart';
import 'voice.dart';
import 'booking_flow.dart' show kOsmAttribution;

/// Muft OpenFreeMap "Liberty" style — vector tiles, bina API key.
/// (v1.4.29 se default streets style CARTO Voyager hai — neeche
/// dekhein; Liberty sirf reference ke tor par rakha hai.)
const String kLibertyStyleUrl = 'https://tiles.openfreemap.org/styles/liberty';

/// v1.4.29 MAP SAAF (malik ka hukm 2026-11-11): purana Liberty
/// style feeka tha — galiyan aur naam saaf nazar nahi ate thay.
/// v1.4.59: LIVE map ka streets basemap ab day_style.dart ka
/// inline JSON hai (OpenStreetMap RASTER tiles — kamzor net
/// par bhi sadkein hisso mein load hoti hain; vector CARTO
/// Voyager retire ho gaya, us ka data kamzor net par
/// pohanchta hi nahi tha aur map safed/khaali rehta tha)।
/// Ye URL ab sirf OFFLINE region download (OfflineMaps —
/// mulk ka overview, zoom 5–9) aur reference ke liye hai।
/// Data OpenStreetMap ka hi hai; attribution badge mein
/// © OpenStreetMap contributors © CARTO dono lazmi hain
/// (booking_flow.dart ka kOsmAttribution).
const String kStreetsStyleUrl =
    'https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json';

/// v1.4.30 RAAT wala map style — CARTO Dark Matter: wohi
/// OpenStreetMap data, gehre rangon mein (galiyan/naam saaf
/// rehte hain). DisplayPrefs ki Night pasand par map khud
/// is par ajata hai; Day par Voyager, Auto par phone ki
/// brightness ke mutabiq (DisplayPrefs.isDarkNow)।
/// v1.4.59: LIVE raat map ab night_style.dart ka inline JSON
/// hai (OSM raster tiles ka gehra roop); ye URL sirf
/// reference ke liye rakha hai।
const String kNightStyleUrl =
    'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json';

/// v1.4.32 GEHRA-SAAF RAAT MAP (malik ka hukm 2026-11-11
/// raat — Yango-sample jaisa): Dark Matter ka apna banaya
/// hua roop [kNightStyleJson] (night_style.dart) — gehra
/// neela pas-manzar (#0a1128), MOTI aur ROSHAN sadkein
/// (bari sadkein safed/sunehri), SAFED baray gali-naam
/// gehre halo ke saath. URL wala style feeka parhta tha —
/// is liye ab inline JSON hai; URL sirf reference ke liye
/// rakha hai।
/// v1.4.59: [kNightStyleJson] ka basemap ab OSM RASTER hai
/// (brightness/saturation se gehra kiya hua) — pas-manzar
/// #0d1520; app ke apne safed labels glyphs se upar bante
/// hain, is liye raat mein bhi saaf parhe jate hain।

/// Satellite hybrid style — Esri World Imagery (muft, bina key) + upar
/// jagah/road ke labels wali reference layers. Sirf ONLINE chalta hai;
/// offline mein streets style hi kaam aata hai (uska region cache hai).
const String kSatelliteStyleJson = '''
{
  "version": 8,
  "name": "Safar Satellite",
  "sources": {
    "esri-imagery": {
      "type": "raster",
      "tiles": ["https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"],
      "tileSize": 256,
      "maxzoom": 18,
      "attribution": "Esri World Imagery"
    },
    "esri-roads": {
      "type": "raster",
      "tiles": ["https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}"],
      "tileSize": 256,
      "maxzoom": 18
    },
    "esri-labels": {
      "type": "raster",
      "tiles": ["https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}"],
      "tileSize": 256,
      "maxzoom": 18
    }
  },
  "layers": [
    {"id": "imagery", "type": "raster", "source": "esri-imagery"},
    {"id": "roads-ref", "type": "raster", "source": "esri-roads"},
    {"id": "labels-ref", "type": "raster", "source": "esri-labels"}
  ]
}
''';

/// Pakistan ke shehron (zones) ke markazi coordinates — store.dart ke
/// kZones se match. 'Doosra Sheher' ka pin Karachi par hai (fallback).
const Map<String, ll.LatLng> kZoneCoords = {
  'Karachi': ll.LatLng(24.8608, 67.0011),
  'Hyderabad': ll.LatLng(25.3960, 68.3578),
  'Sukkur': ll.LatLng(27.7132, 68.8482),
  'Larkana': ll.LatLng(27.5569, 68.2100),
  'Nawabshah': ll.LatLng(26.2442, 68.4100),
  'Mirpurkhas': ll.LatLng(25.5276, 69.0159),
  'Lahore': ll.LatLng(31.5497, 74.3436),
  'Faisalabad': ll.LatLng(31.4504, 73.1350),
  'Rawalpindi': ll.LatLng(33.5651, 73.0169),
  'Islamabad': ll.LatLng(33.7294, 73.0931),
  'Multan': ll.LatLng(30.1575, 71.5249),
  'Gujranwala': ll.LatLng(32.1877, 74.1945),
  'Sialkot': ll.LatLng(32.4945, 74.5229),
  'Bahawalpur': ll.LatLng(29.4000, 71.6833),
  'Sargodha': ll.LatLng(32.0836, 72.6711),
  'Peshawar': ll.LatLng(34.0151, 71.5249),
  'Mardan': ll.LatLng(34.1989, 72.0404),
  'Abbottabad': ll.LatLng(34.1688, 73.2215),
  'Quetta': ll.LatLng(30.1798, 66.9750),
  'Gwadar': ll.LatLng(25.1216, 62.3254),
  'Doosra Sheher': ll.LatLng(24.8608, 67.0011),
};

ml.LatLng _m(ll.LatLng p) => ml.LatLng(p.latitude, p.longitude);

ll.LatLng _l(ml.LatLng p) => ll.LatLng(p.latitude, p.longitude);

/// Do points ke darmiyan simt (degrees, 0 = shumaal) — GPS heading na
/// mile to lagatar positions se teer ki simt nikalne ke liye (v1.4.9).
double safarBearingBetween(ll.LatLng a, ll.LatLng b) {
  final lat1 = a.latitude * math.pi / 180;
  final lat2 = b.latitude * math.pi / 180;
  final dLng = (b.longitude - a.longitude) * math.pi / 180;
  final y = math.sin(dLng) * math.cos(lat2);
  final x = math.cos(lat1) * math.sin(lat2) -
      math.sin(lat1) * math.cos(lat2) * math.cos(dLng);
  return (math.atan2(y, x) * 180 / math.pi + 360) % 360;
}

/// Do simton ke darmiyan sab se CHHOTA signed farq (degrees,
/// -180..180] — teer ki rotation ko hamesha chhote raste se
/// ghumane ke liye (v1.4.11).
double safarAngleDelta(double from, double to) {
  var d = (to - from) % 360;
  if (d > 180) d -= 360;
  if (d < -180) d += 360;
  return d;
}

/// Simt ko [from] se [to] ki taraf [t] hissa (0..1) naram andaz
/// mein ghumana — shortest arc par, kabhi jhatke se snap nahi
/// (v1.4.11: teer gali ki simt par aahista aahista jamta hai).
double safarLerpBearing(double from, double to, double t) =>
    (from + safarAngleDelta(from, to) * t) % 360;

/// v1.4.57 (Part 14 + addendum): MOR (turn) ka KHAALI TEER —
/// koi daira, badge ya disc NAHI (bara gol nishan sadak ko
/// dhak deta hai — malik ki tashheesh)। Teer ki shakal ASAL
/// mor ki geometry se banti hai: canvas map ki simton mein
/// [bearingIn] se ate hue aur [bearingOut] ki taraf jate
/// hue ek jhuki hui lakeer hai — halka mor = halka jhuka
/// teer, poora mor = poora ghuma teer, U-turn = wapas
/// mura teer। Neeche PATLI safed casing (contrast ke
/// liye), upar hara teer; size sadak ke hisaab se chhota
/// rakha gaya hai taake aas paas ki sadak nazar ati rahe।
/// Symbol layer 'map' alignment par lagta hai (camera
/// ghume to teer bhi map ke saath ghumta hai)।
Future<Uint8List?> safarTurnArrowPng(
    double bearingIn, double bearingOut) async {
  try {
    const double size = 240;
    const center = Offset(size / 2, size / 2);
    Offset dir(double b) {
      final r = b * math.pi / 180;
      return Offset(math.sin(r), -math.cos(r));
    }

    final tail = center - dir(bearingIn) * 72;
    final head = center + dir(bearingOut) * 72;
    final path = Path()
      ..moveTo(tail.dx, tail.dy)
      ..lineTo(center.dx, center.dy)
      ..lineTo(head.dx, head.dy);
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    // Patli safed casing pehle — sadak par teer saaf uthe।
    canvas.drawPath(
        path,
        Paint()
          ..color = Colors.white
          ..style = PaintingStyle.stroke
          ..strokeWidth = 34
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round);
    canvas.drawPath(
        path,
        Paint()
          ..color = Brand.green
          ..style = PaintingStyle.stroke
          ..strokeWidth = 24
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round);
    // Teer ka sar — head ki simt, hara bhara, patla safed
    // kinara।
    final d = dir(bearingOut);
    final perp = Offset(-d.dy, d.dx);
    final tip = head + d * 30;
    final baseC = head - d * 6;
    final headPath = Path()
      ..moveTo(tip.dx, tip.dy)
      ..lineTo((baseC + perp * 21).dx, (baseC + perp * 21).dy)
      ..lineTo((baseC - perp * 21).dx, (baseC - perp * 21).dy)
      ..close();
    canvas.drawPath(
        headPath,
        Paint()
          ..color = Colors.white
          ..style = PaintingStyle.stroke
          ..strokeWidth = 7
          ..strokeJoin = StrokeJoin.round);
    canvas.drawPath(headPath, Paint()..color = Brand.green);
    final pic = recorder.endRecording();
    final image = await pic.toImage(size.round(), size.round());
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    return data?.buffer.asUint8List();
  } catch (_) {
    return null;
  }
}

/// Offline region: poore Pakistan ka COUNTRY-OVERVIEW vector map
/// pehli dafa khulne par khamoshi se download ho jata hai (sirf
/// zoom 5–9 — mulk ka majmooi naksha; poore mulk ki gali-level
/// offline copy mumkin nahi aur koshish bhi nahi ki jati). Is ke
/// baad kamzor ya band net par bhi mulk ka overview map chalta hai.
/// Sheher ki gali-level tafseel online milti hai; MapLibre ka apna
/// ambient cache dekhe hue hisse bhi offline mehfooz rakhta hai.
class OfflineMaps {
  static bool _started = false;

  static Future<void> ensurePakistan() async {
    if (_started) return;
    _started = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool('ofm_pakistan_v1') == true) return;
      final regions = await ml.getListOfRegions();
      final exists =
          regions.any((r) => r.metadata['name'] == 'safar-pakistan');
      if (!exists) {
        await ml.downloadOfflineRegion(
          ml.OfflineRegionDefinition(
            bounds: ml.LatLngBounds(
              southwest: const ml.LatLng(23.50, 60.90),
              northeast: const ml.LatLng(37.10, 77.90),
            ),
            mapStyleUrl: kStreetsStyleUrl,
            minZoom: 5,
            maxZoom: 9,
          ),
          metadata: const {'name': 'safar-pakistan'},
        );
      }
      await prefs.setBool('ofm_pakistan_v1', true);
    } catch (_) {
      // Best effort — fail ho to agli dafa phir koshish hogi; map online
      // bhi chalta rehta hai aur ambient cache kaam karta hai.
      _started = false;
    }
  }

  /// Purana naam — jo jagah ensureKarachi bulati thi wohi amal ab
  /// Pakistan region par hota hai.
  static Future<void> ensureKarachi() => ensurePakistan();

  /// MAP WAVE (v1.4.20): offline Pakistan region ki TAZA copy —
  /// purana region delete karke wohi hadood/zoom par dobara
  /// download. MapDataRefresh apne 24 ghante wale chakkar se
  /// bulata hai, taaki offline wala naksha bhi purana na rahe
  /// (band/khuli sadkon ki OSM tabdeeliyan is mein bhi ayen).
  /// v1.4.27 (audit N3): jawab ab bool hai — true sirf ASAL
  /// kamyab refresh par; pehle nakami andar nigal li jati thi
  /// aur bulane wala (MapDataRefresh) nakami ko bhi kamyabi
  /// samajh kar apna timestamp aage badha deta tha.
  static Future<bool> refreshPakistanRegion() async {
    try {
      final regions = await ml.getListOfRegions();
      for (final r in regions) {
        if (r.metadata['name'] == 'safar-pakistan') {
          await ml.deleteOfflineRegion(r.id);
        }
      }
      await ml.downloadOfflineRegion(
        ml.OfflineRegionDefinition(
          bounds: ml.LatLngBounds(
            southwest: const ml.LatLng(23.50, 60.90),
            northeast: const ml.LatLng(37.10, 77.90),
          ),
          mapStyleUrl: kStreetsStyleUrl,
          minZoom: 5,
          maxZoom: 9,
        ),
        metadata: const {'name': 'safar-pakistan'},
      );
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('ofm_pakistan_v1', true);
      return true;
    } catch (_) {
      // Best effort: delete ho jaye aur download fail ho to
      // flag gira dein — agli app run par ensurePakistan region
      // khud dobara bana degi. Map is wajah se rukta nahi.
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool('ofm_pakistan_v1', false);
      } catch (_) {}
      return false;
    }
  }
}

/// MAP DATA AUTO-REFRESH (v1.4.20, malik ka hukm 2026-11-10
/// 19:29–19:31): map data har ~24 GHANTE khud tazah ho, taake
/// band/khuli sadkon ki asal tabdeeliyan app mein nazar ayen.
/// Asal mechanism do hisso par hai (koi jaali button nahi):
///  1) AMBIENT CACHE INVALIDATE — MapLibre ka apna asal API
///     (MapLibreMapController.invalidateAmbientCache): online
///     browsing mein cache hui tiles/style/resources "expired"
///     ho jati hain, is liye agli dafa istemal par woh server
///     (OpenFreeMap/OSM) se TAZA utarti hain. Downloaded offline
///     region ambient cache ka hissa NAHI hota — woh is se
///     muta'asir nahi hota, is liye dusra hissa alag hai:
///  2) OFFLINE REGION REFRESH — Pakistan overview region delete
///     karke dobara download (OfflineMaps.refreshPakistanRegion),
///     taaki offline copy bhi 24 ghante se purani na rahe.
/// Aakhri refresh ka waqt SharedPreferences ke
/// 'last_map_refresh_ms' mein mehfooz rehta hai. Check har app
/// run mein sirf EK dafa hota hai — pehle map controller ke
/// bante hi (SafarMapView.onMapCreated se). Net na ho ya koi
/// qadam fail ho to map purane data par chalta rehta hai aur
/// agli run par dobara koshish hoti hai.
class MapDataRefresh {
  static const String prefKey = 'last_map_refresh_ms';
  static const int intervalMs = 24 * 60 * 60 * 1000; // ~24 ghante
  static bool _checkedThisRun = false;

  static Future<void> maybeRefresh(ml.MapLibreMapController c) async {
    if (_checkedThisRun) return;
    _checkedThisRun = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final last = prefs.getInt(prefKey) ?? 0;
      final now = DateTime.now().millisecondsSinceEpoch;
      if (last > 0 && now - last < intervalMs) return;
      await c.invalidateAmbientCache();
      // v1.4.27 (audit N3): timestamp SIRF asal kamyab refresh
      // par aage badhe — region refresh fail ho to waqt wohi
      // purana rahe taaki agli run par dobara koshish ho
      // (pehle nakami par bhi timestamp aage barh jata tha aur
      // naksha 24 ghante tak purana hi rehta tha)।
      final regionOk = await OfflineMaps.refreshPakistanRegion();
      if (!regionOk) {
        _checkedThisRun = false;
        return;
      }
      await prefs.setInt(
          prefKey, DateTime.now().millisecondsSinceEpoch);
    } catch (_) {
      // Is run mein dobara koshish ki ijazat — agli map screen
      // par phir check hoga.
      _checkedThisRun = false;
    }
  }
}

/// v1.4.57 (Part 3): map par dikhne wali EK gaari ka marker —
/// jagah, gaari ki QISAM (kVehicles wali asal value, masalan
/// 'Rickshaw') aur simt (degrees; data na ho to 0 — marker
/// north ki taraf rehta hai)। Har qisam ki apni asal-numa
/// (halo wali) tasveer hai — rickshaw par rickshaw, bike par
/// bike, car par car — marker hamesha gaari ki qisam se
/// milta hai।
class SafarVehicleMarker {
  final ll.LatLng position;
  final String category;
  final double bearing;
  const SafarVehicleMarker({
    required this.position,
    required this.category,
    this.bearing = 0,
  });
}

/// Gaari ki qisam → marker tasveer ka style-naam (assets/
/// markers/ wali halo PNGs; _applyStyle mein register hoti
/// hain)। Na-maloom qisam par car wala marker (sab se aam)।
String safarVehicleImageName(String category) {
  switch (category.trim().toLowerCase()) {
    case 'rickshaw':
      return 'safar-veh-rickshaw';
    case 'bike':
      return 'safar-veh-bike';
    case 'taxi':
      return 'safar-veh-taxi';
    case 'van':
      return 'safar-veh-van';
    case 'car':
    default:
      return 'safar-veh-car';
  }
}

/// Sab jagah istemal hone wala asal LIVE map (MapLibre GL):
/// - Jhuka hua (tilt) 3D-style view, asal galiyan
/// - Streets (v1.4.59 se OSM RASTER basemap — day_style/
///   night_style wale inline JSON) / Satellite hybrid toggle
/// - Pickup par kaala "A" pin, manzil par kaala "B" pin (v1.4.29;
///   v1.4.42 mein pin thode baray), route line moti GEHRI NEELI
///   safed casing ke saath (v1.4.42 — pehle hari thi)
/// - Zone pins (chhote sunehre nuqtay), driver ki position ka nav-arrow:
///   ONLINE (duty par) = hara, OFFLINE = kala-safaid (v1.4.9, malik ki
///   farmaish; v1.4.11 mein chhota — galiyan nahi dhakta)
class SafarMapView extends StatefulWidget {
  /// v1.4.59: center na diya jaye to map Karachi (24.8608,
  /// 67.0011) par zoom 11.5 se khulta hai — DUNIYA/mulk ki
  /// satah wala nazara kabhi NAHI (malik ki shikayat
  /// 2026-11-16: map poori duniya par khul kar ghoomta
  /// rehta tha)।
  final ll.LatLng? center;
  final double initialZoom;
  final double tilt;
  final ll.LatLng? pickup;
  final ll.LatLng? drop;

  /// v1.4.58 NAAM WALE LABELS (malik ka hukm): A pin (pehli
  /// manzil / pickup) aur B pin (doosri manzil / drop) ke
  /// UPAR us jagah ka NAAM likha dikhta hai — caller booking
  /// ka label deta hai (booking pickupLabel/dropLabel)।
  /// Khaali ho to A par "Pickup", B par "Manzil" ata hai।
  /// Na diya jaye to purana rawaiya (fallback labels)।
  final String? pickupLabel;
  final String? dropLabel;
  final List<ll.LatLng>? routePoints;

  /// v1.4.44 ROUTE OPTIONS: booking preview mein OSRM ke baqi
  /// routes ki polylines — halki grey patli lines mein dikhti
  /// hain taake user dekh kar tap se apna route chun sake।
  /// Sirf passenger booking deta hai; baqi har screen par null
  /// (koi extra line nahi banti)।
  final List<List<ll.LatLng>>? altRoutePoints;

  /// v1.4.57 (Part 9): route ke kisi pareshan hisse (Band
  /// Sadak / Shadeed Jaam report wali jagah) ki line — gehri
  /// NEELI route ke UPAR SURKH rang mein dikhti hai taake
  /// driver ko aage ka masla pehle se saaf nazar aye।
  /// Sirf DriverNavView deta hai; baqi jagah null।
  final List<ll.LatLng>? alertPoints;
  final List<ll.LatLng>? zonePoints;

  /// v1.4.65 DEMAND (malik ka hukm 2026-11-24): asal
  /// maujooda ride darkhwaston ke pickup maqamat — map
  /// in par jamni Low→High HEAT banata hai aur neeche
  /// Demand ki patti dikhata hai (reference video wali
  /// shakal)। Sirf driver home deta hai (asal backend
  /// data se); khaali/na diya jaye to NA heat, NA
  /// patti — jaali rang kabhi NAHI।
  final List<ll.LatLng>? demandPoints;
  final ll.LatLng? position;
  final double positionBearing;

  /// Follow camera ki simt (v1.4.11): sirf DRIVER ke nav view se
  /// di jati hai — woh bhi gated (challti haalat mein hi badalti
  /// hai, rukne par aakhri simt par thehri rehti hai). Na di jaye
  /// to follow camera hamesha NORTH-UP (0) rehta hai — passenger
  /// ki tamam screens isi par hain. v1.4.33: user ne do ungliyon
  /// se ghumaya ho to _manualBearing is par bhaari hai (compass
  /// reset tak) — follow phir bhi jagah taza karta rehta hai.
  final double? cameraBearing;

  /// Position wala teer kis haalat mein hai: true = ONLINE (hara teer),
  /// false = OFFLINE (kala-safaid teer). Driver mode mein duty ki
  /// haalat, passenger mode mein assign driver ki haalat (v1.4.9).
  final bool positionOnline;

  /// v1.4.32 PHOTO-PIN: doosre fareeq ki photo wala gol pin —
  /// [photoPinAt] jagah par dikhta hai, [photoPinPng] PhotoPin
  /// se bana hua tayyar PNG hai. Dono hon tab hi pin banta hai;
  /// warna map bilkul pehle jaisa (pin sirf izafa hai)।
  final ll.LatLng? photoPinAt;
  final Uint8List? photoPinPng;

  /// v1.4.57 (Part 14): agle MOR ka khaali teer — [turnMarkerAt]
  /// asal mor wali jagah hai, [turnMarkerPng] usi mor ki
  /// geometry par bana hua teer (safarTurnArrowPng)। Sirf
  /// DriverNavView deta hai; dono hon tab hi marker banta
  /// hai।
  final ll.LatLng? turnMarkerAt;
  final Uint8List? turnMarkerPng;

  /// v1.4.42 LIVE APNI JAGAH (M4 — owner hukm 2026-11-13):
  /// device ki APNI taaza GPS position; caller (page) apne
  /// geolocator stream se deta hai. Map isay alag pehchan —
  /// halo wale neele nuqte — se dikhata hai (A/B pins aur
  /// doosre fareeq ke teer se mukhtalif)। Na di jaye to map
  /// bilkul pehle jaisa।
  final ll.LatLng? myPosition;

  /// v1.4.57 (Part 3 + Part 4): map par dikhne wali gaariyan
  /// (masalan sawari ke aas paas ONLINE drivers — sirf usi
  /// qisam ki jo sawari ne chuni hai)। Har gaari apni qisam
  /// ki asal-numa tasveer se dikhti hai aur simt mile to
  /// usi simt ghoomti hai। Khaali ho to map pehle jaisa।
  final List<SafarVehicleMarker> vehicles;

  /// v1.4.57 (Part 3): [position] wali gaari ki qisam di
  /// jaye to woh teer (nav arrow) ki bajaye APNI QISAM ke
  /// asal-numa marker se dikhti hai (sawari ki tracking par
  /// assign driver — rickshaw hai to rickshaw ka nishan)।
  /// Na di jaye to purana teer wala rawaiya barkarar।
  final String? positionCategory;

  /// v1.4.42 FOLLOW (M4): true ho to banda maujooda camera
  /// center se ~500 m se zyada hat jaye to map KHUD us par
  /// wapas center hota hai — har GPS tick par jump NAHI,
  /// sirf badi harkat par। User haath se pan kare to follow
  /// ruk jata hai; focusSeq wala saaf re-center (page ka
  /// "Meri Location" button) use dobara chala deta hai।
  final bool followMyPosition;
  final bool followPosition;

  /// Follow camera ka zoom — null ho to purana default
  /// (16.5)। v1.4.42 (H2 — owner hukm 2026-11-13 02:33):
  /// DriverNavView gali-level zoom (19.0, mor ke qareeb
  /// 19.5) yahin se deta hai taake driver ko galiyan aur
  /// chhoti sadkein BARI saaf nazar ayen; baqi follow
  /// istemal default par hi rehte hain (passenger ka
  /// overview fit pehle jaisa)।
  final double? followZoom;

  /// v1.4.42 FOLLOW (owner hukm 2026-11-13 02:57 — Uber
  /// navigation wala follow andaaz, apni shakal mein):
  /// follow camera ka nishana asal jagah se itne meter
  /// AAGE (heading ki taraf) rakha jata hai — gaari/teer
  /// screen ke markaz se neeche rehta hai aur AAGE ka
  /// rasta zyada nazar ata hai, peeche kam। 0 = offset
  /// nahi (purana markaz wala follow)।
  final double followForwardOffsetM;

  /// User ne follow ke doran map ko haath se hila diya
  /// (pan ki pehchan lag gayi) to ye callback chalta hai —
  /// caller (DriverNavView) apni Follow haalat OFF kar
  /// deta hai; us ke recenter/Follow button se follow
  /// dobara lock hota hai।
  final VoidCallback? onFollowPaused;
  final bool interactive;

  /// v1.4.59 SHEHER WALA LOCK (malik ki shikayat 2026-11-16):
  /// sirf HOME + BOOKING wale maps dete hain — do-ungli
  /// ghumao (rotate) aur jhukao (tilt) ke gestures BAND,
  /// aur zoom kam se kam 10 (map duniya ki satah par kabhi
  /// NAHI jata)। Ride/nav wale maps par default false —
  /// un ka rawaiya pehle jaisa (heading-up follow waghera)।
  final bool cityLock;

  /// v1.4.59 PEHLA-FIX ZOOM: sirf HOME wale maps dete hain —
  /// pehla GPS fix ([myPosition] ki pehli asal value) ane
  /// par camera EK dafa us jagah par zoom 16 par jata hai
  /// (bhashart ye ke user ne tab tak map ko haath se pan
  /// na kiya ho)। Default false — baqi screens pehle jaisi।
  final bool firstFixZoom;
  final bool fitToRoute;

  /// v1.4.57 (Part 6): ye key badle to map route + pickup +
  /// drop + position (gaari) SAB ko ek frame mein fit karta
  /// hai — sawari ki screen par ride qubool hone aur ride
  /// shuru hone par caller nayi key deta hai; sawari ko khud
  /// zoom NAHI karna padta।
  final String fitKey;
  final ll.LatLng? focusPoint;
  final int focusSeq;
  final bool externalStyleControl;
  final bool satellite;
  final ValueChanged<bool>? onSatelliteChanged;
  final void Function(ll.LatLng)? onTapPoint;
  final void Function(ll.LatLng)? onLongPressPoint;
  final void Function(ll.LatLng)? onCameraTarget;
  final VoidCallback? onCameraIdle;

  const SafarMapView({
    super.key,
    this.center,
    this.initialZoom = 13,
    this.tilt = 50,
    this.pickup,
    this.drop,
    this.pickupLabel,
    this.dropLabel,
    this.routePoints,
    this.altRoutePoints,
    this.alertPoints,
    this.zonePoints,
    this.demandPoints,
    this.position,
    this.positionBearing = 0,
    this.cameraBearing,
    this.positionOnline = true,
    this.photoPinAt,
    this.photoPinPng,
    this.turnMarkerAt,
    this.turnMarkerPng,
    this.myPosition,
    this.vehicles = const [],
    this.positionCategory,
    this.followMyPosition = false,
    this.followPosition = false,
    this.followZoom,
    this.followForwardOffsetM = 0,
    this.onFollowPaused,
    this.interactive = true,
    this.cityLock = false,
    this.firstFixZoom = false,
    this.fitToRoute = false,
    this.fitKey = '',
    this.focusPoint,
    this.focusSeq = 0,
    this.externalStyleControl = false,
    // v1.4.43 (owner hukm 2026-11-13): SATELLITE DEFAULT tha —
    // v1.4.65 (malik ka hukm 2026-11-24, reference video) se
    // pehla nazara ab LIVE DARK streets map hai; satellite
    // Map Style button se ab bhi milta hai।
    this.satellite = false,
    this.onSatelliteChanged,
    this.onTapPoint,
    this.onLongPressPoint,
    this.onCameraTarget,
    this.onCameraIdle,
  });

  @override
  State<SafarMapView> createState() => _SafarMapViewState();
}

class _SafarMapViewState extends State<SafarMapView> {
  ml.MapLibreMapController? _c;
  bool _styleReady = false;

  /// v1.4.32: photo-pin ki tasveer is style mein register ho
  /// chuki hai ya nahi (har nayi style par dobara register
  /// hoti hai; PNG baad mein aye to didUpdateWidget se)।
  bool _photoImgReady = false;
  bool _satelliteInternal = false;
  String _routeSig = '';
  ll.LatLng? _lastFollowed;

  /// v1.4.57 (Part 6): aakhri fitKey jis par frame fit hua।
  String _lastFitKey = '';

  // --- v1.4.57 (Part 5) POSITION SMOOTHING -------------------
  // Malik ki shikayat: teer (driver marker) ek jagah atak kar
  // phir BADI CHHALANG lagata tha — GPS fix aur backend poll
  // (3–15 s) ke darmiyani faasle seedha teleport hote thay।
  // Ab asal fix [widget.position] mein ata hai, lekin map par
  // DIKHNE wali jagah [_dispPos] hai: naya fix ane par woh
  // purani jagah se nayi jagah tak ~1 s mein chhote chhote
  // qadmon (50 ms tick) se KHUD chal kar jati hai — teer
  // gaari ke saath qadam-qadam chalta hai, chhalang NAHI।
  // Camera bhi follow mein isi dikhne wali jagah ke peeche
  // chalta hai। Bohat door ka fix (> 250 m — GPS dobara milna
  // / asal teleport) foran lag jata hai, animation NAHI।
  ll.LatLng? _dispPos;
  double? _dispBearing;
  Timer? _posAnimTimer;
  ll.LatLng? _animFrom;
  ll.LatLng? _animTo;
  double _animFromB = 0;
  double _animToB = 0;
  DateTime? _animStartAt;
  static const Duration _kPosAnimDur = Duration(milliseconds: 1000);

  ll.LatLng? get _displayPos => _dispPos ?? widget.position;
  double get _displayBearing => _dispBearing ?? widget.positionBearing;

  // --- v1.4.58 MARKER NAAM LABELS ----------------------------
  // Malik ka hukm: har aham nishan ke UPAR us JAGAH KA NAAM
  // likha aye — A/B pins par booking wale naam (widget se
  // ate hain), aur CHALTE hue nishan (driver ka teer/gaari —
  // driver ki apni screen par bhi, sawari ke map par bhi)
  // ke upar US MAQAM ka naam jahan woh is waqt khada hai।
  // Maqam ka naam reverse geocoding (Nominatim) se ata hai;
  // THROTTLE: sirf tab dobara puchha jata hai jab banda
  // aakhri label wali jagah se 200 m se zyada hat jaye।
  // Naam na mile to label NAHI banta — jaali matan kabhi
  // NAHI (aur "Driver" jaisa koi aam lafz bhi NAHI)।
  String? _posPlaceLabel;
  ll.LatLng? _posLabelAt;
  bool _posLabelBusy = false;

  /// Label ka chhota roop: saaf karke ~20 haroof tak;
  /// lamba ho to aakhir mein "…"। [fallback] diya ho to
  /// khaali par wohi (pins ke liye); na ho to khaali hi।
  static String _shortLabel(String? raw, {String fallback = ''}) {
    var s = (raw ?? '').trim().replaceAll(RegExp(r'\s+'), ' ');
    if (s.isEmpty) s = fallback;
    if (s.length > 20) s = '${s.substring(0, 20).trimRight()}…';
    return s;
  }

  /// Chalte nishan ke maqam-naam ki taaza jaanch — throttle
  /// 200 m (upar dekhein)। Jawaab aye to data dobara bhejo
  /// taake label marker ke saath chipka rahe।
  void _maybeGeocodePosition() {
    final pos = widget.position;
    if (pos == null || _posLabelBusy) return;
    final at = _posLabelAt;
    if (at != null &&
        const ll.Distance().as(ll.LengthUnit.Meter, at, pos) <= 200) {
      return;
    }
    _posLabelBusy = true;
    final target = pos;
    unawaited(() async {
      String? name;
      try {
        name = await PlaceSearch.reverseName(target);
      } catch (_) {
        name = null;
      }
      _posLabelBusy = false;
      if (!mounted) return;
      // Jawaab jis jagah ke liye tha wohi label ki jagah hai —
      // naam mile ya na mile, 200 m ke andar dobara NAHI
      // puchhte (faltu network bhi nahi, thakaan bhi nahi)।
      _posLabelAt = target;
      final short = name == null ? null : _shortLabel(name);
      if (short != _posPlaceLabel) {
        _posPlaceLabel = short;
        _pushData();
      }
    }());
  }

  /// Naya asal fix aya — dikhne wali jagah ko wahan tak
  /// smooth le jao (ya pehli dafa / door ho to foran lagao)।
  void _animatePosTo(ll.LatLng target, double bearing) {
    final cur = _dispPos;
    if (cur == null) {
      _dispPos = target;
      _dispBearing = bearing;
      return;
    }
    final d = const ll.Distance().as(ll.LengthUnit.Meter, cur, target);
    if (d < 0.3) {
      _dispPos = target;
      _dispBearing = bearing;
      _posAnimTimer?.cancel();
      _posAnimTimer = null;
      return;
    }
    if (d > 250) {
      _posAnimTimer?.cancel();
      _posAnimTimer = null;
      _dispPos = target;
      _dispBearing = bearing;
      return;
    }
    _animFrom = cur;
    _animTo = target;
    _animFromB = _dispBearing ?? bearing;
    _animToB = bearing;
    _animStartAt = DateTime.now();
    _posAnimTimer?.cancel();
    _posAnimTimer =
        Timer.periodic(const Duration(milliseconds: 50), (_) {
      if (!mounted) return;
      final start = _animStartAt;
      final from = _animFrom;
      final to = _animTo;
      if (start == null || from == null || to == null) return;
      var t = DateTime.now().difference(start).inMilliseconds /
          _kPosAnimDur.inMilliseconds;
      if (t >= 1) {
        t = 1;
        _posAnimTimer?.cancel();
        _posAnimTimer = null;
      }
      _dispPos = ll.LatLng(
        from.latitude + (to.latitude - from.latitude) * t,
        from.longitude + (to.longitude - from.longitude) * t,
      );
      _dispBearing = safarLerpBearing(_animFromB, _animToB, t);
      _pushData();
      _followIfNeeded();
    });
  }

  /// v1.4.42 (M4): apni-jagah follow ki haalat — user ke
  /// haath ke pan par true (follow ruka hua); page ka saaf
  /// re-center (focusSeq) ane par false (follow dobara)।
  bool _followPaused = false;

  /// v1.4.42 FOLLOW: position-follow (driver nav) ki
  /// haalat — user ke haath ke pan par true; caller ke
  /// follow dobara ON karne (followPosition false→true)
  /// par saaf hota hai aur camera foran lock ho jata hai।
  bool _followPosPaused = false;

  /// Aakhri dafa CODE ne camera kab ghumaya — onControllerNotify
  /// mein is se farq hota hai ke camera ki harkat code ki hai
  /// ya user ke haath ki (pan ki pehchan isi par hai)।
  DateTime? _lastCodeMoveAt;
  ll.LatLng? _lastCamTarget;

  /// v1.4.33 (owner hukm 2026-11-12 00:35): user ne do ungliyon se
  /// map khud ghumaya ho to us ki disha yahan mehfooz rehti hai —
  /// follow/recenter usay wapas seedha (0) NAHI karta; compass
  /// dabane par (bearing ~0) ye saaf ho jata hai aur heading-up /
  /// north-up wapas aa jata hai.
  double? _manualBearing;

  /// Aakhri dafa code ne camera ko kis bearing par bheja tha —
  /// onCameraIdle par isi se pehchan hoti hai ke ghumao user ka
  /// tha ya code ka.
  double _lastCommandedBearing = 0;

  /// Camera ke liye disha: pehle user ki ghumai hui (manual),
  /// phir caller ki heading (driver nav), warna north-up (0).
  double _bearingForCamera() =>
      _manualBearing ?? widget.cameraBearing ?? 0;

  /// Camera animation ka ek hi rasta (disha wali jagah par):
  /// commanded bearing note kar lo taake onCameraIdle par user
  /// ki ghumai hui disha pehchani ja sake.
  void _animateCamera(ml.CameraPosition pos) {
    _lastCommandedBearing = pos.bearing;
    _lastCodeMoveAt = DateTime.now();
    final c = _c;
    if (c != null) {
      _guard(c.animateCamera(ml.CameraUpdate.newCameraPosition(pos)));
    }
  }

  /// Camera rukne par: agar disha aakhri commanded disha se 3°
  /// se zyada hat kar hai to ye user ki manual ghumai hai —
  /// mehfooz kar lo. Disha ~0 ho to manual saaf (compass reset).
  void _onCameraIdleInternal() {
    final b = _c?.cameraPosition?.bearing;
    if (b != null) {
      var d = (b - _lastCommandedBearing) % 360;
      if (d > 180) d -= 360;
      if (d < -180) d += 360;
      if (d.abs() > 3) {
        // ~0 (ya ~360) = compass se seedha — manual saaf.
        _manualBearing = (b < 2 || b > 358) ? null : b;
      }
    }
    widget.onCameraIdle?.call();
  }

  /// v1.4.30: 3D pasand (default 2D/normal) — SharedPreferences
  /// mein mehfooz; ON par camera pitched (60°) aur imaaratein
  /// (zoom 15+ par pehle se mojood buildings layer) numaya
  /// nazar ati hain. Disha phir bhi north-up hi rehti hai।
  bool _threeD = false;

  bool get _sat =>
      widget.externalStyleControl ? widget.satellite : _satelliteInternal;

  @override
  void initState() {
    super.initState();
    _satelliteInternal = widget.satellite;
    OfflineMaps.ensurePakistan();
    _load3d();
    // Display pasand (Din/Raat/Auto) badle to map ka style
    // bhi usi waqt badle — EK button, poori app + map।
    DisplayPrefs.notifier.addListener(_onDisplayChanged);
  }

  void _onDisplayChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _load3d() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final v = prefs.getBool('map_3d_v1') ?? false;
      if (mounted && v != _threeD) setState(() => _threeD = v);
    } catch (_) {}
  }

  Future<void> _set3d(bool v) async {
    setState(() => _threeD = v);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('map_3d_v1', v);
    } catch (_) {}
    final c = _c;
    if (c != null && _styleReady) {
      final pos = c.cameraPosition;
      if (pos != null) {
        _animateCamera(ml.CameraPosition(
          target: pos.target,
          zoom: pos.zoom,
          bearing: _bearingForCamera(),
          tilt: v ? 60 : widget.tilt,
        ));
      }
    }
  }

  /// Map ka style — satellite ON ho to satellite; warna
  /// Display pasand (Din/Raat/Auto) ke EK hi hisaab se
  /// (v1.4.66 — malik ka TAZA hukm 2026-11-24: "Rangeen
  /// karo, pura black-and-white NAHI chahiye"): DIN mein
  /// RANGEEN OSM map (paani neela, park hara), RAAT mein
  /// LIVE DARK (Esri Dark Gray + CARTO naam)। Dono
  /// styles live_dark_style.dart mein hain; hisaab
  /// DisplayPrefs ka wohi resolver hai jo poori app ka
  /// theme chalata hai — map aur theme kabhi alag NAHI
  /// hote (v1.4.60 wala usool)।
  String _styleFor(BuildContext context) {
    if (_sat) return kSatelliteStyleJson;
    return DisplayPrefs.isDarkNow(context)
        ? kLiveDarkStyleJson
        : kRangeenStyleJson;
  }

  Future<void> _guard(Future<void> f) async {
    try {
      await f;
    } catch (_) {}
  }

  /// _guard ki bool wali shakal — jahan kamyabi/naakami se
  /// agla qadam tay hota hai (masalan buildings layer ka
  /// source channa: pehle ek, fail ho to doosra).
  Future<bool> _guardOk(Future<void> f) async {
    try {
      await f;
      return true;
    } catch (_) {
      return false;
    }
  }

  Map<String, dynamic> _fc(List<Map<String, dynamic>> features) =>
      {'type': 'FeatureCollection', 'features': features};

  Map<String, dynamic> _pointFeature(ll.LatLng p,
          {Map<String, dynamic>? props}) =>
      {
        'type': 'Feature',
        'geometry': {
          'type': 'Point',
          'coordinates': [p.longitude, p.latitude]
        },
        'properties': props ?? {},
      };

  Future<void> _applyStyle() async {
    final c = _c;
    if (c == null) return;
    _styleReady = false;
    _photoImgReady = false;
    // Marker tasveerein style ke andar register karein
    for (final entry in {
      'safar-pin': 'assets/map-pin-green.png',
      'safar-arrow': 'assets/map-arrow-down.png',
      'safar-nav-on': 'assets/map-nav-green.png',
      'safar-nav-off': 'assets/map-nav-grey.png',
      // v1.4.29: A (pickup) / B (drop) wale kaale gol-chokor pins
      // — owner ke example screenshots wali shakal (DRIVER-FLOW-
      // SPEC 2026-11-11); apni banayi hui PNG hain, kisi company
      // ka asset NAHI.
      'safar-pin-a': 'assets/map-pin-a.png',
      'safar-pin-b': 'assets/map-pin-b.png',
      // v1.4.57 (Part 3): asal-numa HALO wale gaari markers —
      // har qisam ki apni tasveer (upar se dikhti asal gaari,
      // safed halo + naram saaya taake satellite par bhi saaf
      // parhi jaye)।
      // v1.4.57 (Part 11): DRIVER ke APNE maqam ka naya TEER —
      // hara teer, safed kinara, simt ki taraf ghumta hua
      // (malik ka hukm: driver side par gaari ki tasveer NAHI,
      // teer hi hoga; sawari side ke gaari markers alag hain)।
      'safar-nav-arrow': 'assets/markers/marker_arrow.png',
      'safar-veh-rickshaw': 'assets/markers/marker_rickshaw.png',
      'safar-veh-bike': 'assets/markers/marker_bike.png',
      'safar-veh-car': 'assets/markers/marker_car.png',
      'safar-veh-taxi': 'assets/markers/marker_taxi.png',
      'safar-veh-van': 'assets/markers/marker_van.png',
    }.entries) {
      await _guard(() async {
        final data = await rootBundle.load(entry.value);
        await c.addImage(entry.key, data.buffer.asUint8List());
      }());
    }
    // Sources
    await _guard(c.addGeoJsonSource('safar-route', _fc([])));
    await _guard(c.addGeoJsonSource('safar-alert', _fc([])));
    await _guard(c.addGeoJsonSource('safar-alt', _fc([])));
    await _guard(c.addGeoJsonSource('safar-points', _fc([])));
    await _guard(c.addGeoJsonSource('safar-pos', _fc([])));
    await _guard(c.addGeoJsonSource('safar-zones', _fc([])));
    await _guard(c.addGeoJsonSource('safar-photo', _fc([])));
    await _guard(c.addGeoJsonSource('safar-mypos', _fc([])));
    await _guard(c.addGeoJsonSource('safar-vehicles', _fc([])));
    await _guard(c.addGeoJsonSource('safar-turn', _fc([])));
    await _guard(c.addGeoJsonSource('safar-demand', _fc([])));
    // v1.4.65 DEMAND HEAT (malik ka hukm 2026-11-24 —
    // reference wali Low→High jamni patti): asal maujooda
    // ride darkhwaston ke pickup maqamat ki garmi — data
    // caller deta hai (driver home: _availableRides);
    // khaali ho to kuch nazar NAHI ata, jaali rang kabhi
    // NAHI। Ye layer sab overlay layers se PEHLE add
    // hoti hai — route/markers hamesha is ke upar rahen।
    await _guard(c.addHeatmapLayer(
      'safar-demand',
      'safar-demand-heat',
      const ml.HeatmapLayerProperties(
        heatmapColor: [
          'interpolate',
          ['linear'],
          ['heatmap-density'],
          0,
          'rgba(37, 99, 235, 0)',
          0.15,
          'rgba(37, 99, 235, 0.45)',
          0.35,
          'rgba(124, 58, 237, 0.60)',
          0.55,
          'rgba(168, 85, 247, 0.72)',
          0.75,
          'rgba(217, 70, 239, 0.82)',
          1,
          'rgba(244, 114, 182, 0.92)',
        ],
        heatmapRadius: [
          'interpolate',
          ['linear'],
          ['zoom'],
          10,
          22,
          13,
          38,
          16,
          62,
        ],
        heatmapIntensity: [
          'interpolate',
          ['linear'],
          ['zoom'],
          10,
          0.65,
          16,
          1.1,
        ],
        heatmapOpacity: 0.82,
      ),
    ));
    await _ensurePhotoImage();
    await _ensureTurnImage();
    // 3D imaaratein — sirf streets style par (satellite par nahi).
    // Vector data mein render_height jahan maujood hai wahan
    // imaaratein uthi hui nazar aati hain (zoom 15+).
    // v1.4.42: asal layer ab Day/Night style JSON ke ANDAR
    // hai (day_style.dart/night_style.dart ki 'safar-
    // buildings-3d'); ye runtime koshish sirf backup hai।
    // (v1.4.29 wala comment source id 'carto' batata tha —
    // woh ghalat tha; inline styles ka source 'protomaps'
    // hai, source-layer 'buildings'।)
    if (!_sat) {
      const props = ml.FillExtrusionLayerProperties(
        fillExtrusionColor: '#CFC4B0',
        fillExtrusionOpacity: 0.9,
        fillExtrusionHeight: [
          'coalesce',
          ['to-number', ['get', 'render_height']],
          8
        ],
        fillExtrusionBase: [
          'coalesce',
          ['to-number', ['get', 'render_min_height']],
          0
        ],
      );
      // v1.4.42 DURUSTI: inline Day/Night styles ka asal
      // source id 'protomaps' hai aur source-layer
      // 'buildings' — purana pehla andaza ('carto'/'building')
      // is liye hamesha fail hota tha aur 3D imaaratein asal
      // mein banti hi NAHI theen (style JSON mein ab yehi
      // layer pehle se hai; ye runtime koshish sirf us surat
      // ka sahara hai jab JSON wali layer kisi wajah se na
      // ho — id ek hi hai, dohra nahi banta)।
      final okCarto = await _guardOk(c.addFillExtrusionLayer(
        'protomaps',
        'safar-buildings-3d',
        props,
        sourceLayer: 'buildings',
        minzoom: 15,
      ));
      if (!okCarto) {
        await _guard(c.addFillExtrusionLayer(
          'openmaptiles',
          'safar-buildings-3d',
          props,
          sourceLayer: 'building',
          minzoom: 15,
        ));
      }
    }
    // v1.4.44 ROUTE OPTIONS: baqi routes ki halki grey patli
    // line — MAIN route se NEECHE rahe is liye us se pehle
    // add hoti hai (gehri neeli line hamesha upar, saaf)।
    // v1.4.57 (Part 9): ab DASHED hai — "dusra rasta" wali
    // peshkash maujooda raste se alag saaf pehchani jaye।
    await _guard(c.addLineLayer(
      'safar-alt',
      'safar-alt-line',
      const ml.LineLayerProperties(
        lineColor: '#9AA0A6',
        lineWidth: 3.5,
        lineOpacity: 0.9,
        lineCap: 'butt',
        lineJoin: 'round',
        lineDasharray: [2, 2],
      ),
    ));
    // Route line — pehle safed kinara (casing), phir MOTI
    // hari line (#0B6E2E)।
    // v1.4.66 (malik ka hukm 2026-11-24): route line AUR
    // MOTI — 8.5 → 13 (dedh guna se zyada), casing
    // 12.5 → 18 taake safed kinari har taraf ~2.5 px saaf
    // dikhe aur line chaudi road par apni jagah se alag
    // numayan rahe — ek nazar mein pata chale ke apni
    // road/line konsi hai।
    await _guard(c.addLineLayer(
      'safar-route',
      'safar-route-casing',
      const ml.LineLayerProperties(
        lineColor: '#FFFFFF',
        lineWidth: 18,
        lineOpacity: 0.95,
        lineCap: 'round',
        lineJoin: 'round',
      ),
    ));
    await _guard(c.addLineLayer(
      'safar-route',
      'safar-route-line',
      const ml.LineLayerProperties(
        lineColor: '#0B6E2E',
        lineWidth: 13,
        lineOpacity: 1,
        lineCap: 'round',
        lineJoin: 'round',
      ),
    ));
    // v1.4.57 (Part 9): PARESHAN HISSA — route ka woh tukda
    // jahan Band Sadak / Shadeed Jaam ki taaza report hai,
    // neeli line ke UPAR gehri SURKH line se dikhta hai
    // (data DriverNavView deta hai — sirf asal report par,
    // koi jaali traffic rang NAHI)।
    await _guard(c.addLineLayer(
      'safar-alert',
      'safar-alert-line',
      const ml.LineLayerProperties(
        lineColor: '#D32F2F',
        // v1.4.66: route line 13 hone par ye bhi 9.5 → 14.5 —
        // pareshan hisse wali surkh line hari line ko PURA
        // dhake (kinaron se hari jhalak na mare)।
        lineWidth: 14.5,
        lineOpacity: 0.95,
        lineCap: 'round',
        lineJoin: 'round',
      ),
    ));
    // Zone pins — chhote sunehre nuqtay
    await _guard(c.addCircleLayer(
      'safar-zones',
      'safar-zone-dots',
      const ml.CircleLayerProperties(
        circleRadius: 5,
        circleColor: '#D4AF37',
        circleStrokeColor: '#FFFFFF',
        circleStrokeWidth: 1.6,
        circleOpacity: 0.95,
      ),
    ));
    // Pickup pin — v1.4.29: kaala gol-chokor "A" pin (owner ke
    // example wali shakal; apni PNG asset)।
    await _guard(c.addSymbolLayer(
      'safar-points',
      'safar-pickup-sym',
      const ml.SymbolLayerProperties(
        iconImage: 'safar-pin-a',
        // v1.4.42: pin thoda bara (0.42 → 0.5) — vivid map
        // par A/B door se saaf parhe jayein।
        iconSize: 0.5,
        iconAnchor: 'bottom',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
      filter: ['==', 'kind', 'pickup'],
    ));
    // Manzil pin — v1.4.29: kaala gol-chokor "B" pin (pehle
    // wala sunehra teer hata diya — A/B usool har jagah ek hai)।
    await _guard(c.addSymbolLayer(
      'safar-points',
      'safar-drop-sym',
      const ml.SymbolLayerProperties(
        iconImage: 'safar-pin-b',
        iconSize: 0.5,
        iconAnchor: 'bottom',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
      filter: ['==', 'kind', 'drop'],
    ));
    // v1.4.58 NAAM LABELS: A/B pins ke UPAR jagah ka naam —
    // GEHRA matan (#111111) + SAFED halo, taake din/raat/
    // satellite har pas-manzar par saaf parha jaye। Pin
    // 300 px × 0.5 ≈ 150 px uncha hai (anchor bottom), is
    // liye matan ~157 px upar: offset em mein hai
    // (11.2 em × textSize 14)। Matan hamesha screen ki
    // taraf seedha (viewport) — jhuke/ghoome map par bhi
    // parhne mein saaf।
    for (final kind in const ['pickup', 'drop']) {
      await _guard(c.addSymbolLayer(
        'safar-points',
        'safar-$kind-label',
        const ml.SymbolLayerProperties(
          textField: ['get', 'label'],
          textFont: [
            'Montserrat SemiBold',
            'Open Sans Bold',
            'Noto Sans Regular',
            'Noto Sans CJK JP Regular'
          ],
          textSize: 14,
          textColor: '#111111',
          textHaloColor: '#FFFFFF',
          textHaloWidth: 2,
          textAnchor: 'bottom',
          textOffset: [0, -11.2],
          textMaxWidth: 30,
          textPitchAlignment: 'viewport',
          textRotationAlignment: 'viewport',
          textAllowOverlap: true,
          textIgnorePlacement: true,
        ),
        filter: ['==', 'kind', kind],
      ));
    }
    // v1.4.42 (M4): APNI live jagah ka marker — halka neela
    // halo + gehra neela nuqta safed kinare ke saath (aam
    // maps wali "aap yahan hain" pehchan)।
    // v1.4.66 (malik ka hukm 2026-11-24): nishan AUR BARA —
    // halo 17 → 25, nuqta 8 → 12 (kinara 2.6 → 3.5), taake
    // chaudi/moti road par apni jagah gum na ho।
    // v1.4.60 (Part C): ye layers ab position wale teer se
    // PEHLE banti hain — driver home par jahan teer aur
    // nuqta EK hi jagah par hain, nuqta+halo teer ke NEECHE
    // rehta hai: EK hi mila hua nishan (neela halo/nuqta +
    // upar hara teer), do alag nishan NAHI। Passenger home
    // par teer hota hi nahi — wahan sirf nuqta pehle ki
    // tarah dikhta hai।
    await _guard(c.addCircleLayer(
      'safar-mypos',
      'safar-mypos-halo',
      const ml.CircleLayerProperties(
        circleRadius: 25,
        circleColor: '#1A73E8',
        circleOpacity: 0.22,
      ),
    ));
    await _guard(c.addCircleLayer(
      'safar-mypos',
      'safar-mypos-dot',
      const ml.CircleLayerProperties(
        circleRadius: 12,
        circleColor: '#1A73E8',
        circleOpacity: 1,
        circleStrokeColor: '#FFFFFF',
        circleStrokeWidth: 3.5,
      ),
    ));
    // Driver ki position — nav arrow (v1.4.9; v1.4.11 mein CHHOTA:
    // malik ka hukm ke bara teer galiyan dhakta tha — iconSize
    // 0.45 → 0.25, taake aas paas ki galiyan saaf nazar ayen), simt
    // ke saath ghumta hua।
    // v1.4.60 (Part C — malik ka hukm 2026-11-16): OFFLINE wala
    // KALA-SAFAID/GREY teer (safar-nav-off) KHATAM — woh map par
    // ghum ho jata tha, malik ko apni jagah nazar hi nahi ati
    // thi। Ab dono haalaton (online + offline) mein EK hi HARA
    // teer (safar-nav-arrow) hai — passenger aur
    // driver, har map par apni jagah ka teer HARA hi hoga,
    // taake saaf nazar aye। Duty ki haalat slide switch aur
    // panel se waisi hi pata chalti hai; teer ka kaam sirf
    // jagah + simt dikhana hai।
    await _guard(c.addSymbolLayer(
      'safar-pos',
      'safar-pos-sym-on',
      const ml.SymbolLayerProperties(
        // v1.4.57 (Part 11): ONLINE (duty par) driver ka apna
        // nishan = naya hara TEER (240 px asset)।
        // v1.4.66 (malik ka hukm 2026-11-24): teer BARA —
        // 0.27 (≈65 px) → 0.40 (≈96 px), taake moti/chaudi
        // road par teer apni line par saaf dikhe, gum na ho।
        iconImage: 'safar-nav-arrow',
        iconSize: 0.40,
        iconAnchor: 'center',
        iconRotate: ['get', 'bearing'],
        iconRotationAlignment: 'map',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
      filter: ['==', 'state', 'online'],
    ));
    await _guard(c.addSymbolLayer(
      'safar-pos',
      'safar-pos-sym-off',
      const ml.SymbolLayerProperties(
        // v1.4.60: offline bhi WAHI hara teer (grey khatam)।
        // v1.4.66: size online wala hi — 0.40 (≈96 px)।
        iconImage: 'safar-nav-arrow',
        iconSize: 0.40,
        iconAnchor: 'center',
        iconRotate: ['get', 'bearing'],
        iconRotationAlignment: 'map',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
      filter: ['==', 'state', 'offline'],
    ));
    // v1.4.58: TEER ke upar MAQAM ka naam (reverse geocoding
    // se; 'label' khaali ho to ye layer kuch NAHI dikhati)।
    // Teer ~96 px uncha (anchor center; v1.4.66 mein bara
    // hua) — matan ~49 px upar (3.8 em × 13)।
    await _guard(c.addSymbolLayer(
      'safar-pos',
      'safar-pos-label',
      const ml.SymbolLayerProperties(
        textField: ['get', 'label'],
        textFont: [
          'Montserrat SemiBold',
          'Open Sans Bold',
          'Noto Sans Regular',
          'Noto Sans CJK JP Regular'
        ],
        textSize: 13,
        textColor: '#111111',
        textHaloColor: '#FFFFFF',
        textHaloWidth: 2,
        textAnchor: 'bottom',
        textOffset: [0, -3.8],
        textMaxWidth: 30,
        textPitchAlignment: 'viewport',
        textRotationAlignment: 'viewport',
        textAllowOverlap: true,
        textIgnorePlacement: true,
      ),
      filter: ['!=', 'label', ''],
    ));
    // v1.4.57 (Part 3): GAARI MARKERS — har qisam ki apni
    // layer (filter 'cat' property par), simt 'bearing'
    // property se ghoomti hui। Tasveerein 532 px unchi hain;
    // iconSize 0.30 par numaya unchai A/B pins (300 px ×
    // 0.5) ke barabar rehti hai — ride wale zooms (15–17)
    // par gaari saaf aur galiyan bhi nazar ati hain।
    // Part 13 ADDENDUM: rickshaw ki nayi photoreal SAZGAR
    // tasveer 1600 px unchi hai — us ki layer ka size
    // 0.10 (1600 × 0.10 ≈ wahi ~160 px numaya unchai)।
    for (final cat in const ['rickshaw', 'bike', 'car', 'taxi', 'van']) {
      await _guard(c.addSymbolLayer(
        'safar-vehicles',
        'safar-veh-sym-$cat',
        ml.SymbolLayerProperties(
          iconImage: safarVehicleImageName(cat),
          iconSize: cat == 'rickshaw' ? 0.10 : 0.30,
          iconAnchor: 'center',
          iconRotate: ['get', 'bearing'],
          iconRotationAlignment: 'map',
          iconAllowOverlap: true,
          iconIgnorePlacement: true,
        ),
        filter: ['==', 'cat', cat],
      ));
    }
    // v1.4.58: GAARI marker ke upar MAQAM ka naam — sirf
    // us feature par jis ka 'label' khaali NAHI (yani sirf
    // [position] wali gaari: sawari ke map par assign driver,
    // driver ke map par us ki apni gaari-pasand wala nishan)।
    // Aas paas ki aam gaariyon ka label hamesha khaali hai —
    // un par kuch NAHI likha ata। Unchai ke hisaab se do
    // layers: aam gaariyan 532 px × 0.30 ≈ 160 px unchi
    // (matan ~86 px upar = 6.6 em × 13), rickshaw
    // 800 px × 0.10 ≈ 80 px (matan ~47 px upar = 3.6 em)।
    await _guard(c.addSymbolLayer(
      'safar-vehicles',
      'safar-veh-label',
      const ml.SymbolLayerProperties(
        textField: ['get', 'label'],
        textFont: [
          'Montserrat SemiBold',
          'Open Sans Bold',
          'Noto Sans Regular',
          'Noto Sans CJK JP Regular'
        ],
        textSize: 13,
        textColor: '#111111',
        textHaloColor: '#FFFFFF',
        textHaloWidth: 2,
        textAnchor: 'bottom',
        textOffset: [0, -6.6],
        textMaxWidth: 30,
        textPitchAlignment: 'viewport',
        textRotationAlignment: 'viewport',
        textAllowOverlap: true,
        textIgnorePlacement: true,
      ),
      filter: [
        'all',
        ['!=', 'label', ''],
        ['!=', 'cat', 'rickshaw']
      ],
    ));
    await _guard(c.addSymbolLayer(
      'safar-vehicles',
      'safar-veh-label-rickshaw',
      const ml.SymbolLayerProperties(
        textField: ['get', 'label'],
        textFont: [
          'Montserrat SemiBold',
          'Open Sans Bold',
          'Noto Sans Regular',
          'Noto Sans CJK JP Regular'
        ],
        textSize: 13,
        textColor: '#111111',
        textHaloColor: '#FFFFFF',
        textHaloWidth: 2,
        textAnchor: 'bottom',
        textOffset: [0, -3.6],
        textMaxWidth: 30,
        textPitchAlignment: 'viewport',
        textRotationAlignment: 'viewport',
        textAllowOverlap: true,
        textIgnorePlacement: true,
      ),
      filter: [
        'all',
        ['!=', 'label', ''],
        ['==', 'cat', 'rickshaw']
      ],
    ));
    // v1.4.32 PHOTO-PIN layer — doosre fareeq ki photo us ki
    // jagah par (Master map wale photo markers wala hi size:
    // 192x212 px ki tasveer iconSize 0.5 par)।
    await _guard(c.addSymbolLayer(
      'safar-photo',
      'safar-photo-sym',
      const ml.SymbolLayerProperties(
        iconImage: 'safar-photo',
        iconSize: 0.5,
        iconAnchor: 'bottom',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
    ));
    // v1.4.57 (Part 14): MOR ka KHAALI TEER — koi daira/
    // badge NAHI; tasveer usi mor ki geometry par bani
    // hoti hai (safarTurnArrowPng), is liye rotation 'map'
    // par 0 — teer map ke saath ghumta hai, screen par
    // chipka NAHI rehta। Size chhota (240 px × 0.22 ≈
    // 53 px) taake sadak aas paas nazar ati rahe।
    await _guard(c.addSymbolLayer(
      'safar-turn',
      'safar-turn-sym',
      const ml.SymbolLayerProperties(
        iconImage: 'safar-turn',
        iconSize: 0.22,
        iconAnchor: 'center',
        iconRotationAlignment: 'map',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
    ));
    _styleReady = true;
    _routeSig = '';
    _pushData();
    // v1.4.58: style bante hi agar position pehle se maujood
    // hai to us ke maqam-naam ki jaanch bhi shuru kar do।
    _maybeGeocodePosition();
    _maybeFit(initial: true);
    _followIfNeeded(force: true);
    // v1.4.42 (M4): style bante hi apni live jagah se 500 m+
    // door hon to wahi center (app khulne par map pichhli
    // ride ke ilaqe par NAHI rehta)।
    _followMyPosIfNeeded();
    // v1.4.59: fix style se pehle aa chuka ho to pehla-fix
    // zoom ab lagao (home maps)।
    _maybeFirstFixZoom();
    // v1.4.30: 3D pasand mehfooz thi to style bante hi camera
    // pitched kar do (disha north-up hi rehti hai)।
    if (_threeD) {
      final pos = c.cameraPosition;
      if (pos != null) {
        _animateCamera(ml.CameraPosition(
          target: pos.target,
          zoom: pos.zoom,
          bearing: _bearingForCamera(),
          tilt: 60,
        ));
      }
    }
  }

  String _sigOf(List<ll.LatLng>? pts) {
    if (pts == null || pts.length < 2) return '';
    final a = pts.first, b = pts.last;
    return '${pts.length}|${a.latitude.toStringAsFixed(4)},${a.longitude.toStringAsFixed(4)}'
        '|${b.latitude.toStringAsFixed(4)},${b.longitude.toStringAsFixed(4)}';
  }

  /// v1.4.32: photo-pin PNG ko style mein 'safar-photo' ke
  /// naam se register karna — style bante waqt bhi aur PNG
  /// baad mein ane par bhi (didUpdateWidget se)।
  Future<void> _ensurePhotoImage() async {
    final c = _c;
    final png = widget.photoPinPng;
    if (c == null || png == null || _photoImgReady) return;
    final ok = await _guardOk(c.addImage('safar-photo', png));
    if (ok) _photoImgReady = true;
  }

  /// v1.4.57 (Part 14): mor-teer ki tasveer style mein
  /// register karna — naya mor ane par DriverNavView naya
  /// PNG deta hai; addImage usi naam par purani tasveer
  /// badal deta hai, is liye flag sirf style ki zindagi
  /// ke liye hai (har style par _applyStyle dobara
  /// register karta hai — flag wahan reset hota hai,
  /// lekin PNG tab tak wohi ho to dobara register ki
  /// zaroorat ke liye didUpdateWidget bhi bulata hai)।
  Future<void> _ensureTurnImage() async {
    final c = _c;
    final png = widget.turnMarkerPng;
    if (c == null || png == null) return;
    await _guardOk(c.addImage('safar-turn', png));
  }

  void _pushData() {
    final c = _c;
    if (c == null || !_styleReady) return;
    final pts = widget.routePoints;
    _guard(c.setGeoJsonSource(
        'safar-route',
        _fc([
          if (pts != null && pts.length > 1)
            {
              'type': 'Feature',
              'geometry': {
                'type': 'LineString',
                'coordinates':
                    pts.map((p) => [p.longitude, p.latitude]).toList()
              },
              'properties': {},
            }
        ])));
    _guard(c.setGeoJsonSource(
        'safar-alt',
        _fc([
          for (final line
              in widget.altRoutePoints ?? const <List<ll.LatLng>>[])
            if (line.length > 1)
              {
                'type': 'Feature',
                'geometry': {
                  'type': 'LineString',
                  'coordinates':
                      line.map((p) => [p.longitude, p.latitude]).toList()
                },
                'properties': {},
              }
        ])));
    // v1.4.57 (Part 9): pareshan (surkh) hisse ka data।
    final alert = widget.alertPoints;
    _guard(c.setGeoJsonSource(
        'safar-alert',
        _fc([
          if (alert != null && alert.length > 1)
            {
              'type': 'Feature',
              'geometry': {
                'type': 'LineString',
                'coordinates':
                    alert.map((p) => [p.longitude, p.latitude]).toList()
              },
              'properties': {},
            }
        ])));
    _guard(c.setGeoJsonSource(
        'safar-points',
        _fc([
          // v1.4.58: har pin ke saath us jagah ka NAAM bhi
          // (label layer upar likhti hai) — A = booking ka
          // pickup naam (khaali ho to "Pickup"), B = booking
          // ka drop naam (khaali ho to "Manzil")।
          if (widget.pickup != null)
            _pointFeature(widget.pickup!, props: {
              'kind': 'pickup',
              'label': _shortLabel(widget.pickupLabel, fallback: 'Pickup'),
            }),
          if (widget.drop != null)
            _pointFeature(widget.drop!, props: {
              'kind': 'drop',
              'label': _shortLabel(widget.dropLabel, fallback: 'Manzil'),
            }),
        ])));
    _guard(c.setGeoJsonSource(
        'safar-pos',
        _fc([
          // v1.4.57 (Part 3): position ki qisam di gayi ho to
          // woh gaari neeche 'safar-vehicles' mein apni qisam
          // ke marker se jati hai — teer yahan NAHI banta
          // (dohra nishan na ho)।
          // v1.4.57 (Part 5): jagah [_displayPos] hai — smooth
          // animation wali (asal fix widget.position mein hai)।
          if (widget.position != null &&
              (widget.positionCategory == null ||
                  widget.positionCategory!.isEmpty))
            _pointFeature(_displayPos!, props: {
              'bearing': _displayBearing,
              'state': widget.positionOnline ? 'online' : 'offline',
              // v1.4.58: maqam ka naam — mila ho tab hi;
              // warna khaali (label layer khaali par nahi
              // banti)। Jagah DIKHNE wali (smooth) hai, is
              // liye label bhi teer ke saath glide karta hai।
              'label': _posPlaceLabel ?? '',
            }),
        ])));
    _guard(c.setGeoJsonSource(
        'safar-vehicles',
        _fc([
          // v1.4.58: aas paas ki aam gaariyon par label NAHI
          // (label hamesha khaali) — sirf [position] wali
          // (assign / apni) gaari par us ke maqam ka naam।
          for (final v in widget.vehicles)
            _pointFeature(v.position, props: {
              'cat': v.category.trim().toLowerCase(),
              'bearing': v.bearing,
              'label': '',
            }),
          if (widget.position != null &&
              widget.positionCategory != null &&
              widget.positionCategory!.isNotEmpty)
            _pointFeature(_displayPos!, props: {
              'cat': widget.positionCategory!.trim().toLowerCase(),
              'bearing': _displayBearing,
              'label': _posPlaceLabel ?? '',
            }),
        ])));
    _guard(c.setGeoJsonSource(
        'safar-zones',
        _fc([
          for (final z in widget.zonePoints ?? <ll.LatLng>[]) _pointFeature(z),
        ])));
    _guard(c.setGeoJsonSource(
        'safar-photo',
        _fc([
          if (widget.photoPinAt != null && widget.photoPinPng != null)
            _pointFeature(widget.photoPinAt!),
        ])));
    // v1.4.57 (Part 14): mor-teer ka maqam (tasveer
    // _ensureTurnImage se register hoti hai)।
    _guard(c.setGeoJsonSource(
        'safar-turn',
        _fc([
          if (widget.turnMarkerAt != null && widget.turnMarkerPng != null)
            _pointFeature(widget.turnMarkerAt!),
        ])));
    _guard(c.setGeoJsonSource(
        'safar-mypos',
        _fc([
          // v1.4.60 (Part C — malik ka hukm: driver ke map par
          // bhi apni jagah passenger wali hi pehchan ho):
          // neela nuqta AB hamesha banta hai jahan myPosition
          // ho — v1.4.57 wali "ek hi jagah par nuqta daba do"
          // shart KHATAM। Driver home par nuqta+halo hare
          // teer ke NEECHE ek mila hua nishan banata hai
          // (layers ka order _applyStyle mein badal diya
          // gaya hai); sawari ki tracking par dono jagah
          // alag hain, nuqta waisa hi rehta hai।
          if (widget.myPosition != null)
            _pointFeature(widget.myPosition!),
        ])));
    // v1.4.65: demand heat ka data — caller ke diye hue
    // asal pickup maqamat (khaali = koi heat NAHI)।
    _guard(c.setGeoJsonSource(
        'safar-demand',
        _fc([
          for (final p in widget.demandPoints ?? const <ll.LatLng>[])
            _pointFeature(p),
        ])));
  }

  void _fitPoints(List<ll.LatLng> pts) {
    final c = _c;
    if (c == null || pts.isEmpty) return;
    var minLat = pts.first.latitude, maxLat = minLat;
    var minLng = pts.first.longitude, maxLng = minLng;
    for (final p in pts) {
      minLat = math.min(minLat, p.latitude);
      maxLat = math.max(maxLat, p.latitude);
      minLng = math.min(minLng, p.longitude);
      maxLng = math.max(maxLng, p.longitude);
    }
    final center = ll.LatLng((minLat + maxLat) / 2, (minLng + maxLng) / 2);
    final span = math.max((maxLat - minLat).abs(), (maxLng - minLng).abs());
    final zoom = span <= 0.0005
        ? 15.5
        : (math.log(360 / (span * 1.5)) / math.ln2).clamp(11.0, 16.0);
    _animateCamera(ml.CameraPosition(
      target: _m(center),
      zoom: zoom,
      bearing: _bearingForCamera(),
      tilt: widget.tilt,
    ));
  }

  void _maybeFit({bool initial = false}) {
    if (!widget.fitToRoute) return;
    final pts = widget.routePoints;
    if (pts == null || pts.length < 2) return;
    // v1.4.57 (Part 6): fitKey badli (ride qubool / ride
    // shuru) to POORI kahani ek frame mein — route + pickup
    // + drop + gaari (position) sab shamil karke dobara fit।
    if (widget.fitKey.isNotEmpty && widget.fitKey != _lastFitKey) {
      _lastFitKey = widget.fitKey;
      _routeSig = _sigOf(pts);
      _fitPoints([
        ...pts,
        if (widget.pickup != null) widget.pickup!,
        if (widget.drop != null) widget.drop!,
        if (_displayPos != null) _displayPos!,
      ]);
      return;
    }
    final sig = _sigOf(pts);
    if (!initial && sig == _routeSig) return;
    _routeSig = sig;
    _fitPoints(pts);
  }

  void _followIfNeeded({bool force = false}) {
    final c = _c;
    // v1.4.57 (Part 5): camera DIKHNE wali (smooth) jagah ke
    // peeche chalta hai — teer aur camera ek saath glide
    // karte hain, chhalang dono mein NAHI।
    final pos = _displayPos;
    if (c == null || !_styleReady || pos == null || !widget.followPosition) {
      return;
    }
    // v1.4.42 FOLLOW: user ke haath ke pan ke baad follow
    // ruka rehta hai — dobara lock sirf caller ke recenter
    // (followPosition false→true) se hota hai।
    if (_followPosPaused) return;
    if (!force && _lastFollowed != null) {
      final d = const ll.Distance().as(ll.LengthUnit.Meter, _lastFollowed!, pos);
      // v1.4.10: pehle 4 m se kam harkat par camera rukta tha —
      // ab sirf 0.5 m se kam (khade GPS ki mamoli jitter) par
      // rukta hai; har asal harkat par camera saath chalta hai.
      if (d < 0.5) return;
    }
    _lastFollowed = pos;
    // v1.4.42 FOLLOW (aage ka rasta pehle): caller ne
    // forward offset diya ho to camera ka nishana asal
    // jagah se utne meter AAGE (maujooda simt ki taraf) —
    // teer screen ke markaz se neeche, aage ki sadak
    // zyada nazar ati hai। Har GPS fix par yehi hisaab
    // dobara lagta hai, is liye pan hamesha smooth rehta
    // hai (animateCamera ka apna transition)।
    var camTarget = pos;
    if (widget.followForwardOffsetM > 0) {
      camTarget = const ll.Distance()
          .offset(pos, widget.followForwardOffsetM, _bearingForCamera());
    }
    _animateCamera(ml.CameraPosition(
      target: _m(camTarget),
      // v1.4.42 (H2): caller followZoom de to wohi (driver
      // nav = gali-level 19.0/19.5); warna purana 16.5।
      zoom: widget.followZoom ?? 16.5,
      tilt: 55,
      // v1.4.11: heading-up SIRF wahan jahan caller cameraBearing
      // de (driver ka nav view, apni gating ke saath); warna
      // camera hamesha north-up (0) — passenger side hamesha 0.
      // v1.4.33: user ne do ungliyon se ghumaya ho to us ki
      // disha (_manualBearing) pehle — follow sirf jagah
      // (target) taza karta hai, angle user ka rehta hai.
      bearing: _bearingForCamera(),
    ));
  }

  /// v1.4.59: pehla-fix zoom ho chuka hai ya nahi (sirf
  /// firstFixZoom wale home maps par; ek dafa hi hota hai)।
  bool _firstFixDone = false;

  /// v1.4.59 PEHLA-FIX ZOOM: pehla GPS fix ane par camera
  /// EK dafa us jagah par zoom 16 par — taake home map
  /// khulte hi banda apni gali ki satah par ho, sheher/
  /// duniya ki satah par NAHI। User pehle hi haath se pan
  /// kar chuka ho (_followPaused) to hath NAHI lagta।
  /// Style tayyar hone se pehle fix aye to _applyStyle ke
  /// aakhir mein dobara jaanch hoti hai।
  void _maybeFirstFixZoom() {
    if (!widget.firstFixZoom || _firstFixDone || _followPaused) return;
    final c = _c;
    final pos = widget.myPosition;
    if (c == null || !_styleReady || pos == null) return;
    _firstFixDone = true;
    final cur = c.cameraPosition;
    _animateCamera(ml.CameraPosition(
      target: _m(pos),
      zoom: 16,
      bearing: _bearingForCamera(),
      tilt: cur?.tilt ?? widget.tilt,
    ));
  }

  /// v1.4.42 (M4) APNI-JAGAH FOLLOW: camera ka maujooda
  /// center live position se ~500 m se zyada door ho jaye
  /// tab hi re-center — chhoti harkaton par camera khamosh
  /// rehta hai (har GPS tick par jump NAHI)। Follow user ke
  /// pan par ruka hota hai (_followPaused)।
  void _followMyPosIfNeeded() {
    final c = _c;
    final pos = widget.myPosition;
    if (c == null ||
        !_styleReady ||
        pos == null ||
        !widget.followMyPosition ||
        _followPaused) {
      return;
    }
    final target = c.cameraPosition?.target;
    if (target == null) return;
    final d = const ll.Distance()
        .as(ll.LengthUnit.Meter, _l(target), pos);
    if (d < 500) return;
    final cur = c.cameraPosition;
    _animateCamera(ml.CameraPosition(
      target: _m(pos),
      zoom: cur?.zoom ?? widget.initialZoom,
      bearing: _bearingForCamera(),
      tilt: cur?.tilt ?? widget.tilt,
    ));
  }

  @override
  void didUpdateWidget(SafarMapView old) {
    super.didUpdateWidget(old);
    // v1.4.57 (Part 5): naya asal fix — dikhne wali jagah ko
    // smooth animation se wahan le jao (pehli dafa/door par
    // foran)। Position khatam ho to animation bhi saaf।
    if (widget.position != old.position) {
      if (widget.position == null) {
        _posAnimTimer?.cancel();
        _posAnimTimer = null;
        _dispPos = null;
        _dispBearing = null;
        // v1.4.58: position khatam — maqam-label bhi saaf।
        _posPlaceLabel = null;
        _posLabelAt = null;
      } else {
        _animatePosTo(widget.position!, widget.positionBearing);
      }
    } else if (widget.positionBearing != old.positionBearing &&
        _posAnimTimer == null) {
      // Sirf simt badli (jagah wahi) — dikhne wali simt bhi
      // taaza (khade GPS par ye aam hota hai)।
      _dispBearing = widget.positionBearing;
    }
    // v1.4.32: photo-pin PNG style banne ke BAAD aya ho to
    // pehle tasveer register karo, phir data dobara bhejo।
    if (widget.photoPinPng != null &&
        !identical(widget.photoPinPng, old.photoPinPng)) {
      unawaited(_ensurePhotoImage().then((_) => _pushData()));
    }
    // v1.4.57 (Part 14): naya mor-teer PNG (naya mor) —
    // style mein dobara register, phir data taaza।
    if (widget.turnMarkerPng != null &&
        !identical(widget.turnMarkerPng, old.turnMarkerPng)) {
      unawaited(_ensureTurnImage().then((_) => _pushData()));
    }
    // v1.4.59: pehla-fix zoom ki jaanch focusSeq wale
    // re-center se PEHLE — sawari ke one-shot center par
    // focusSeq ka zoom 17 aakhir mein bhaari rehta hai;
    // sirf stream wala pehla fix aye to yehi zoom 16
    // lagta hai।
    if (widget.myPosition != old.myPosition) _maybeFirstFixZoom();
    if (widget.focusSeq != old.focusSeq && widget.focusPoint != null) {
      // v1.4.42: saaf re-center (Meri Location button) =
      // follow dobara ON।
      _followPaused = false;
      _animateCamera(ml.CameraPosition(
        target: _m(widget.focusPoint!),
        // v1.4.42 (HOME ZOOM — owner hukm 2026-11-13 02:45):
        // kisi EK jagah par focus (live location / chuni hui
        // jagah) ab street-level 17 par ata hai — pehle 15.5
        // par "bohat upar se" nazar ata tha। Route ka poora
        // fit is se alag hai (sirf asal route par _fitPoints)।
        zoom: 17,
        bearing: _bearingForCamera(),
        tilt: 55,
      ));
    }
    // v1.4.58: chalte nishan ke maqam-naam ki jaanch
    // (200 m throttle andar hai) — phir data bhejo।
    _maybeGeocodePosition();
    _pushData();
    _maybeFit();
    // v1.4.42 FOLLOW: follow dobara ON hua (recenter /
    // Follow button) — pan-wala pause saaf aur camera
    // foran wapas lock।
    if (widget.followPosition && !old.followPosition) {
      _followPosPaused = false;
      _followIfNeeded(force: true);
    }
    _followIfNeeded();
    if (widget.myPosition != old.myPosition) _followMyPosIfNeeded();
  }

  /// maplibre_gl 0.22 ke MapLibreMap widget par onCameraMove callback
  /// nahi hai; us ki jagah controller (ChangeNotifier) camera ki har
  /// harkat par notify karta hai aur cameraPosition taaza ho jata hai —
  /// wohi maloomat yahan se onCameraTarget tak pohanchti hai.
  void _onControllerNotify() {
    final t = _c?.cameraPosition?.target;
    if (t != null) {
      final lt = _l(t);
      // v1.4.42 (M4) PAN KI PEHCHAN: camera ka nishana 40 m
      // se zyada hata aur aakhri code-wali harkat ko 2 s se
      // zyada ho gaye hon to ye user ka haath hai — apni-
      // jagah follow rok do (page ka Meri Location button /
      // focusSeq use dobara chala dega)।
      final prev = _lastCamTarget;
      if (prev != null) {
        final moved =
            const ll.Distance().as(ll.LengthUnit.Meter, prev, lt);
        final lastCode = _lastCodeMoveAt;
        final codeAgo = lastCode == null
            ? const Duration(days: 1)
            : DateTime.now().difference(lastCode);
        if (moved > 40 && codeAgo.inMilliseconds > 2000) {
          // Apni-jagah follow (passenger home) ka pause।
          if (widget.followMyPosition && !_followPaused) {
            _followPaused = true;
          }
          // v1.4.42 FOLLOW: nav follow ka pause — user ne
          // map ungli se hila diya to camera lock toot gaya;
          // caller ko khabar (us ki Follow pill OFF ho
          // jayegi), recenter se dobara lock hoga।
          if (widget.followPosition && !_followPosPaused) {
            _followPosPaused = true;
            widget.onFollowPaused?.call();
          }
        }
      }
      _lastCamTarget = lt;
      widget.onCameraTarget?.call(lt);
    }
  }

  @override
  void dispose() {
    _posAnimTimer?.cancel();
    _c?.removeListener(_onControllerNotify);
    DisplayPrefs.notifier.removeListener(_onDisplayChanged);
    super.dispose();
  }

  void _toggleStyle() {
    final next = !_sat;
    if (widget.externalStyleControl) {
      widget.onSatelliteChanged?.call(next);
    } else {
      setState(() => _satelliteInternal = next);
      widget.onSatelliteChanged?.call(next);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        ml.MapLibreMap(
          styleString: _styleFor(context),
          initialCameraPosition: ml.CameraPosition(
            // v1.4.59: center na diya ho to Karachi par
            // sheher wali satah (zoom 11.5) — duniya wala
            // nazara kabhi NAHI।
            target: _m(widget.center ?? const ll.LatLng(24.8608, 67.0011)),
            zoom: widget.center == null ? 11.5 : widget.initialZoom,
            tilt: widget.tilt,
          ),
          trackCameraPosition: true,
          // v1.4.36 FULL ZOOM-OUT (owner hukm 2026-11-12): user
          // map ko poora zoom-out karke DUNIYA ki satah (zoom
          // ~0.5) tak ja sake — pehle koi min zoom set hi nahi
          // tha, natija plugin/native ke default par tha aur
          // duniya wali satah pakki nahi milti thi. Ab min zoom
          // 0.5 wazeh taur par set hai; max zoom par koi pabandi
          // nahi (null = unbounded, pehle jaisa). Yehi ek widget
          // saari screens (normal / 3D / satellite) par chalta
          // hai, is liye teeno modes cover hain. Sheher ke andar
          // ke zoom (11–18) par is ka koi asar nahi.
          // v1.4.59 ISTISNA: cityLock wale HOME + BOOKING maps
          // par min zoom 10 hai — malik ki shikayat (2026-11-16)
          // ke baad home map duniya ki satah par NAHI jata;
          // ride/nav maps par purana 0.5 wala rawaiya barkarar।
          minMaxZoomPreference: widget.cityLock
              ? const ml.MinMaxZoomPreference(10, 18)
              : const ml.MinMaxZoomPreference(0.5, 18),
          compassEnabled: widget.interactive,
          scrollGesturesEnabled: widget.interactive,
          // v1.4.33 DO-UNGLI GHUMAO (owner hukm 2026-11-12 00:35):
          // driver + passenger, har interactive map par do
          // ungliyon se ghumana khula hai — 2026-11-11 17:12 wala
          // "seedha nazara" (rotation band) lock is hukm se
          // khatam. Ghumai hui disha _manualBearing mein mehfooz
          // rehti hai; compass dabane par wapas north-up /
          // heading-up. Sirf driver ke nav view (jahan caller
          // cameraBearing deta hai) mein heading-up us ka apna
          // tay-shuda amal hai — manual ghumao usay compass
          // reset tak rok deta hai.
          // v1.4.59 ISTISNA: cityLock wale HOME + BOOKING maps
          // par ghumao/jhukao ke gestures BAND hain (malik ki
          // shikayat: home map ghoom/jhuk kar behka rehta tha) —
          // pan + pinch-zoom khule rehte hain।
          rotateGesturesEnabled: widget.interactive && !widget.cityLock,
          tiltGesturesEnabled: widget.interactive && !widget.cityLock,
          zoomGesturesEnabled: widget.interactive,
          onMapCreated: (c) {
            _c = c;
            c.addListener(_onControllerNotify);
            // MAP WAVE (v1.4.20): 24 ghante wala map-data
            // refresh check — har app run mein sirf pehle
            // controller par ek dafa (MapDataRefresh khud
            // guard rakhta hai). Background amal hai; map
            // ki loading is par nahi rukti.
            MapDataRefresh.maybeRefresh(c);
          },
          onStyleLoadedCallback: _applyStyle,
          onMapClick: (point, coords) =>
              widget.onTapPoint?.call(_l(coords)),
          onMapLongClick: (point, coords) =>
              widget.onLongPressPoint?.call(_l(coords)),
          onCameraIdle: _onCameraIdleInternal,
        ),
        // OSM ATTRIBUTION (v1.4.28 — license shart): map ka
        // data OpenStreetMap contributors ka hai (OpenFreeMap
        // "Liberty" style); attribution har map par lazmi aur
        // parha ja sakne wala hona chahiye. Native attribution
        // button style ke metadata par munhasir hota hai, is
        // liye ye apna badge pakka rasta hai — SafarMapView
        // app ka WAHID MapLibreMap hai, is liye ye badge
        // passenger + driver + route/picker, har map par
        // khud pohanchta hai. IgnorePointer: map ke taps
        // (pin lagana) is se kabhi NAHI rukte।
        Positioned(
          left: 8,
          bottom: 8,
          child: IgnorePointer(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 6, vertical: 2.5),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.78),
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Text(
                kOsmAttribution,
                style: TextStyle(fontSize: 9.5, color: Colors.black87),
              ),
            ),
          ),
        ),
        // v1.4.65 DEMAND PATTI (Low → High): sirf tab jab
        // asal demand data ho (driver home) — reference
        // video wali shakal, neeche darmiyan mein jamni
        // gradient patti। Sirf numaya hai; map ke taps is
        // se kabhi NAHI rukte (IgnorePointer)।
        if (widget.demandPoints != null && widget.demandPoints!.isNotEmpty)
          Positioned(
            left: 0,
            right: 0,
            bottom: 10,
            child: IgnorePointer(
              child: Center(
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.55),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('Low',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(width: 6),
                      Container(
                        width: 110,
                        height: 8,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          gradient: const LinearGradient(
                            colors: [
                              Color(0xFF2563EB),
                              Color(0xFF7C3AED),
                              Color(0xFFA855F7),
                              Color(0xFFD946EF),
                              Color(0xFFF472B6),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Text('High',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ),
            ),
          ),
        // v1.4.30 SIDE CONTROLS (dayein taraf ke gol buttons):
        // Display (Din/Raat/Auto — EK button, poori app + map),
        // 3D on/off, aur Streets/Satellite. External-control
        // wale map (booking view) par parent ke apne controls
        // dayein hain, is liye wahan yehi buttons BAYEIN taraf
        // compact shakal mein ate hain।
        // v1.4.42 (H1R — owner hukm 2026-11-13 02:40): Display
        // wala button ab likhai wala pill NAHI — chhota GOL
        // ICON button hai (chaand/sooraj ki nishani, bina
        // likhai) — function wohi (Din/Raat/Auto cycle)।
        if (!widget.externalStyleControl)
          Positioned(
            top: 8,
            right: 8,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const DisplayModeIconButton(),
                const SizedBox(height: 6),
                _controlChip(
                  icon: Icons.view_in_ar,
                  label: tr('map_3d'),
                  active: _threeD,
                  onTap: () => _set3d(!_threeD),
                ),
                const SizedBox(height: 6),
                _controlChip(
                  icon: Icons.layers,
                  label: _sat ? 'Streets' : 'Satellite',
                  active: _sat,
                  onTap: _toggleStyle,
                ),
              ],
            ),
          )
        else
          Positioned(
            top: 8,
            left: 8,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const DisplayModeIconButton(),
                const SizedBox(height: 6),
                _controlChip(
                  icon: Icons.view_in_ar,
                  label: tr('map_3d'),
                  active: _threeD,
                  onTap: () => _set3d(!_threeD),
                ),
              ],
            ),
          ),
      ],
    );
  }

  /// Side controls ka ek gol button (Display button wali
  /// shakal): gehri sabz patti, sunehra kinara; active ho to
  /// sunehra bhara hua।
  Widget _controlChip({
    required IconData icon,
    required String label,
    required bool active,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: active
                ? Brand.gold.withOpacity(0.95)
                : Brand.deepGreen.withOpacity(0.92),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Brand.gold, width: 1),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon,
                  color: active ? Brand.greenDark : Brand.goldLight,
                  size: 15),
              const SizedBox(width: 5),
              Text(label,
                  style: TextStyle(
                      color: active ? Brand.greenDark : Colors.white,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Pickup → drop ka tayyar route map: OSRM se asal sadak ka route khud
/// le aata hai (cache ke saath); net na ho to cache ya seedhi line.
/// Passenger ki booking tafseel aur driver ki nayi booking card mein
/// istemal hota hai.
class SafarRouteMap extends StatefulWidget {
  final ll.LatLng pickup;
  final ll.LatLng? drop;

  /// v1.4.58: A/B pins ke upar likhe ane wale jagah-naam —
  /// caller booking ke pickupLabel/dropLabel deta hai
  /// (SafarMapView tak seedha jate hain)।
  final String? pickupLabel;
  final String? dropLabel;
  final bool interactive;
  final double tilt;

  /// Assign driver ki jagah (passenger tracking screen, v1.4.9) —
  /// di jaye to driver ka BARA teer bhi map par dikhta hai: online
  /// ho to hara, offline ho to kala-safaid. Na di jaye to map bilkul
  /// pehle jaisa (sirf pickup/drop/route).
  final ll.LatLng? driverPosition;
  final double driverBearing;
  final bool driverOnline;

  /// v1.4.32: assign driver ki photo-pin ka tayyar PNG
  /// (PhotoPin se) — driver ki jagah par photo-pin dikhta
  /// hai; null ho to sirf teer hi rehta hai।
  final Uint8List? driverPhotoPng;

  /// v1.4.42 (M4): is device ki APNI live jagah — di jaye to
  /// route map par neela nuqta (apni pehchan) bhi dikhta hai
  /// (sirf marker; follow is chhote map par NAHI — yahan
  /// fit-to-route hi usool hai)।
  final ll.LatLng? myPosition;

  /// v1.4.45 AUTO RE-ROUTE: store diya jaye to ye map har
  /// 1 minute road reports ke hisaab se apni route line
  /// KHAMOSHI se taaza karta hai (ReRouteEngine) — driver ke
  /// booking preview par bhi yehi chalta hai aur sawari ke
  /// tracking map par bhi; sawari ko koi route-choice NAHI
  /// milti, sirf line badalti hai। Store na ho to map
  /// bilkul pehle jaisa (ek dafa fetch, koi timer nahi)।
  final AppStore? store;

  /// v1.4.57 (Part 4): aas paas ki ONLINE gaariyan (sawari
  /// ke driver-dhoondhne wale marhale par — sirf chuni hui
  /// qisam ki)। Khaali ho to map pehle jaisa।
  final List<SafarVehicleMarker> vehicles;

  /// v1.4.57 (Part 3): assign driver ki gaari ki qisam —
  /// di jaye to driver ka nishan teer ki bajaye us ki apni
  /// qisam ke asal-numa marker se dikhta hai।
  final String? driverCategory;

  /// v1.4.57 (Part 2 — malik ka hukm): map kis style se
  /// KHULE — true = satellite, false = halki street (vector)
  /// style। Default purana rawaiya (satellite); sawari ki
  /// booking/ride screens false deti hain — style switcher
  /// se user baad mein khud badal sakta hai।
  final bool satellite;

  /// v1.4.57 (Part 6): SafarMapView ki fitKey — ride qubool
  /// / ride shuru par badalti hai taake poora manzar (route
  /// + gaari + A + B) ek frame mein fit ho jaye।
  final String fitKey;

  const SafarRouteMap({
    super.key,
    required this.pickup,
    this.drop,
    this.pickupLabel,
    this.dropLabel,
    this.interactive = true,
    this.tilt = 45,
    this.driverPosition,
    this.driverBearing = 0,
    this.driverOnline = true,
    this.driverPhotoPng,
    this.myPosition,
    this.store,
    this.vehicles = const [],
    this.driverCategory,
    // v1.4.65: pehla nazara LIVE DARK streets (malik ka
    // hukm 2026-11-24) — satellite ab default NAHI।
    this.satellite = false,
    this.fitKey = '',
  });

  @override
  State<SafarRouteMap> createState() => _SafarRouteMapState();
}

class _SafarRouteMapState extends State<SafarRouteMap> {
  RouteResult? _route;
  int _token = 0;

  // v1.4.45: khamosh re-route tick ka timer (sirf store
  // mile tab) — har 1 minute reports ke hisaab se line
  // ki dobara jaanch।
  Timer? _rrTimer;
  bool _rrBusy = false;

  @override
  void initState() {
    super.initState();
    _load();
    final st = widget.store;
    if (st != null) {
      unawaited(Backend.syncRoadReports(st));
      _rrTimer = Timer.periodic(ReRouteEngine.tickEvery, (_) {
        unawaited(_rrTick());
      });
    }
  }

  @override
  void dispose() {
    _rrTimer?.cancel();
    super.dispose();
  }

  @override
  void didUpdateWidget(SafarRouteMap old) {
    super.didUpdateWidget(old);
    if (old.pickup != widget.pickup || old.drop != widget.drop) _load();
  }

  Future<void> _load() async {
    final drop = widget.drop;
    if (drop == null) {
      setState(() => _route = null);
      return;
    }
    final token = ++_token;
    final r = await RouteService.fetch(widget.pickup, drop);
    if (mounted && token == _token) setState(() => _route = r);
  }

  /// v1.4.45 khamosh re-route: maujooda line par report
  /// (band/jaam) ho ya woh line ab dastiyab hi na rahi ho
  /// to behtar line par shift — BINA kisi elan/choice ke
  /// (preview aur sawari tracking ke liye yehi usool hai;
  /// awaaz wala elan sirf DriverNavView mein hota hai)।
  /// Fare ko hath NAHI lagta — ye sirf numaya line hai,
  /// booking ka kiraya booking object mein mehfooz hai।
  Future<void> _rrTick() async {
    final store = widget.store;
    final drop = widget.drop;
    final cur = _route;
    if (store == null || drop == null || cur == null || _rrBusy) return;
    if (cur.isStraightFallback) return;
    _rrBusy = true;
    try {
      await Backend.syncRoadReports(store);
      final fresh =
          await RouteService.fetch(widget.pickup, drop, forceNetwork: true);
      if (!mounted || _route != cur || fresh.isStraightFallback) return;
      final next = ReRouteEngine.decide(
        current: cur,
        fresh: fresh,
        reports: store.roadReports,
      );
      if (next != null) setState(() => _route = next);
    } catch (_) {
      // Jaanch na ho paye to purani line hi rehti hai।
    } finally {
      _rrBusy = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final drop = widget.drop;
    final center = drop != null
        ? ll.LatLng((widget.pickup.latitude + drop.latitude) / 2,
            (widget.pickup.longitude + drop.longitude) / 2)
        : widget.pickup;
    return SafarMapView(
      center: center,
      initialZoom: 13,
      tilt: widget.tilt,
      pickup: widget.pickup,
      drop: drop,
      pickupLabel: widget.pickupLabel,
      dropLabel: widget.dropLabel,
      routePoints:
          _route?.points ?? (drop != null ? [widget.pickup, drop] : null),
      position: widget.driverPosition,
      positionBearing: widget.driverBearing,
      positionOnline: widget.driverOnline,
      photoPinAt: widget.driverPosition,
      photoPinPng: widget.driverPhotoPng,
      myPosition: widget.myPosition,
      vehicles: widget.vehicles,
      positionCategory: widget.driverCategory,
      satellite: widget.satellite,
      interactive: widget.interactive,
      fitToRoute: true,
      fitKey: widget.fitKey,
    );
  }
}

/// Driver ke liye Google-style guidance: chal rahi ride par asal route,
/// agle mor ki Roman Urdu hidayat wala banner, route par aage barhta
/// hara arrow (sirf asal GPS position par — ijazat/position na ho
/// to na arrow, na banner; kuch jhooti nahi dikhta), aur follow camera.
/// v1.4.11: teer ki simt gali-simt smoothed bearing (baseline +
/// route-segment tarjeeh) aur camera heading-up sirf chalti
/// haalat mein — tafseel _DriverNavViewState ke andar.
class DriverNavView extends StatefulWidget {
  final Booking booking;

  /// Har taaza GPS position par pukar — driver side is se store ki
  /// driver-position taza rakhta hai, taaki passenger ko driver ki
  /// doori/ETA mil sake. Optional hai; na diya jaye to nav bilkul
  /// pehle ki tarah apne andar hi rehta hai.
  final ValueChanged<ll.LatLng>? onPosition;

  /// Driver ki duty haalat — teer ka rang isi se banta hai (v1.4.9):
  /// online = hara, offline = kala-safaid.
  final bool driverOnline;

  /// v1.4.32: sawari ki photo-pin ka tayyar PNG (PhotoPin se) —
  /// pickup ki taraf jate hue sawari ki photo pickup wale
  /// maqam par dikhti hai; ride shuru (arrived) hone ke baad
  /// pin gayab (sawari saath bethi hai)।
  final Uint8List? passengerPhotoPng;

  /// v1.4.45 AUTO RE-ROUTE + ROAD REPORTS: store diya jaye
  /// to 1-minute wala re-route engine (ReRouteEngine) aur
  /// 'Band Sadak' / 'Shadeed Jaam' report wale button
  /// chalte hain। Store na ho to nav bilkul pehle jaisa।
  final AppStore? store;
  const DriverNavView(
      {super.key,
      required this.booking,
      this.onPosition,
      this.driverOnline = true,
      this.passengerPhotoPng,
      this.store});

  @override
  State<DriverNavView> createState() => _DriverNavViewState();
}

class _DriverNavViewState extends State<DriverNavView> {
  StreamSubscription<Position>? _sub;
  ll.LatLng? _pos;

  // --- v1.4.11: GALI-SIMT TEER (malik ke hukm 2026-11-09) --------
  // Teer ki simt aakhri do fixes se NAHI banti, balkay ~12 m
  // PEETHE ke baseline se banti hai — taake teer GPS ke shor ki
  // bajaye asal GALI ki simt dikhaye aur driver confuse na ho.
  // Ruki hui haalat (speed < 1 m/s) mein simt JAMA rehti hai —
  // teer khada ho kar kabhi nahi ghumta. Har badlav shortest-arc
  // lerp se aahista ata hai, snap kabhi nahi. Route maujood ho aur
  // position route se <= 25 m ke andar ho to sab se qareebi route
  // segment ki simt ko tarjeeh milti hai — teer tay shuda gali
  // par chipka rehta hai.
  static const double _kBearingBaselineM = 12;
  static const double _kHoldMoveM = 3;
  static const double _kHoldSpeedMps = 1.0;
  static const double _kCameraSpeedMps = 1.5;
  static const double _kRouteNearM = 25;
  static const double _kBearingLerp = 0.35;

  /// Haal ki positions ki trail (purani → nayi) — baseline anchor
  /// isi se nikalta hai.
  final List<({ll.LatLng p, DateTime t})> _trail = [];

  /// Teer ki NUMAYA (smoothed) simt — build isi ko istemal karta
  /// hai. _hasBearing false ho to abhi koi pakki simt nahi bani.
  double _displayBearing = 0;
  bool _hasBearing = false;

  /// Follow camera ki simt (heading-up): sirf jab driver asal
  /// mein chal raha ho (speed > 1.5 m/s) tab _displayBearing se
  /// taaza hoti hai; rukte hi aakhri value par JAMA rehti hai —
  /// camera kabhi khud north ki taraf wapas nahi ghumta.
  double _camBearing = 0;

  /// [pos] se ~[_kBearingBaselineM] meter peeche ka trail point
  /// (trail chhota ho to sab se purana point) aur us ki asal doori.
  ({ll.LatLng anchor, double dist}) _trailAnchor(ll.LatLng pos) {
    var acc = 0.0;
    var prev = pos;
    for (var i = _trail.length - 1; i >= 0; i--) {
      final p = _trail[i].p;
      final seg = const ll.Distance().as(ll.LengthUnit.Meter, p, prev);
      if (seg > 0 && acc + seg >= _kBearingBaselineM) {
        final frac = (_kBearingBaselineM - acc) / seg;
        return (
          anchor: ll.LatLng(
            prev.latitude + (p.latitude - prev.latitude) * frac,
            prev.longitude + (p.longitude - prev.longitude) * frac,
          ),
          dist: _kBearingBaselineM,
        );
      }
      acc += seg;
      prev = p;
    }
    return (anchor: prev, dist: acc);
  }

  /// Speed ka andaza: GPS ki apni speed mile to wohi; warna
  /// pichhle ~2.5+ second ki trail harkat se hisaab.
  double _speedEstimate(Position p, ll.LatLng pos, DateTime now) {
    if (p.speed >= 0) return p.speed;
    for (var i = _trail.length - 1; i >= 0; i--) {
      final e = _trail[i];
      final dt = now.difference(e.t).inMilliseconds / 1000.0;
      if (dt >= 2.5) {
        return const ll.Distance().as(ll.LengthUnit.Meter, e.p, pos) / dt;
      }
    }
    return 0;
  }

  RouteResult? _route;
  ll.LatLng? _routeOrigin;
  int _fetchToken = 0;
  bool _follow = true;
  bool _noGps = false;

  // v1.4.44 ROUTE OPTIONS — DRIVER (owner hukm 2026-11-13
  // 04:19): ride/navigation ke DORAN bhi driver rasta badal
  // sakta hai। Banner ya route line par tap → us ki LIVE
  // jagah se manzil tak ke alternatives grey lines mein;
  // kisi grey line par tap → navigation (line + steps +
  // rehnumai) usi route par shift। Booking par tay-shuda
  // KIRAYA is se bilkul NAHI badalta — route switch sirf
  // navigation ke liye hai, fare booking object mein mehfooz
  // hai aur yahan use hath hi nahi lagta।
  bool _optionsOpen = false;
  bool _optionsLoading = false;
  List<RouteResult> _navOptions = const [];
  ll.LatLng? _optionsOrigin;

  // --- v1.4.45 AUTO RE-ROUTE (1-minute engine) ----------------
  // Timer har 60s: reports taaza (Backend.syncRoadReports) +
  // taaza route (RouteService.fetch — wohi mushtarka helper)
  // + ReRouteEngine ka faisla। Switch ho to awaaz (Voice) +
  // banner; driver 'Purana rasta' dabaye to revert aur
  // 5 minute ki khamoshi (us ki marzi aakhri hai)।
  Timer? _rerouteTimer;
  bool _rerouteBusy = false;
  RouteResult? _preRerouteRoute;
  DateTime? _rerouteHoldUntil;
  bool _rerouteNotice = false;

  // --- v1.4.57 (Part 9) JAAM/BAND SADAK WARNING --------------
  // Route ke aage kisi driver ki taaza report (Band Sadak /
  // Shadeed Jaam) ho to pehle WARNING banti hai: pareshan
  // hissa map par SURKH, upar banner, aur saaf dusra rasta
  // (dashed line) pesh hota hai — route KHUD NAHI badalta;
  // 'Dusra Rasta Lein' / 'Yahi Rasta' ka faisla driver ka
  // hai (locked route rule)। Live traffic feed app ke paas
  // NAHI hai — khabar SIRF drivers ki apni reports se ati
  // hai, aur jaam ki "der" ka koi jaali andaza NAHI dikhta;
  // banner mein sirf report, doori aur dusre raste ka OSRM
  // waqt ata hai।
  RoadReport? _jamReport;
  RouteResult? _jamOffer;
  String _jamDismissedId = '';

  // --- v1.4.57 (Part 14) AGLE MOR KA TEER ------------------
  // Banner jis mor ki countdown deta hai, map par usi mor
  // ki jagah KHAALI teer pehle se laga hota hai — shakal
  // route ki asal geometry se banti hai (safarTurnArrowPng)।
  // [_turnKey] = route + step ki pehchan; badle to naya
  // PNG banta hai, warna purana hi rehta hai।
  Uint8List? _turnPng;
  String _turnKey = '';
  String _reportThanks = '';
  // Driver ne khud route chuna hai — auto-refetch (120 m wala)
  // use NAHI badlega; sirf line se > 100 m door nikalne par
  // aam re-route wapas shuru hota hai।
  bool _manualRoute = false;

  ll.LatLng get _target => widget.booking.status == 'arrived'
      ? ll.LatLng(widget.booking.dropLat, widget.booking.dropLng)
      : ll.LatLng(widget.booking.pickupLat, widget.booking.pickupLng);

  String get _targetLabel => widget.booking.status == 'arrived'
      ? 'Drop: ${widget.booking.dropLabel}'
      : 'Pickup: ${widget.booking.pickupLabel}';

  String get _targetKey =>
      '${widget.booking.status}|${_target.latitude.toStringAsFixed(4)},${_target.longitude.toStringAsFixed(4)}';
  String _lastTargetKey = '';

  @override
  void initState() {
    super.initState();
    _lastTargetKey = _targetKey;
    _initLocation();
    // v1.4.45: store mile to re-route engine ka 1-minute
    // timer + reports ki pehli sync।
    final st = widget.store;
    if (st != null) {
      unawaited(Backend.syncRoadReports(st));
      _rerouteTimer = Timer.periodic(ReRouteEngine.tickEvery, (_) {
        unawaited(_rerouteTick());
      });
    }
    // v1.4.57 (Part 13): apne nishan ki pasand (Teer/Gaari)
    // badle to nav map foran nayi shakal le।
    MarkerPrefs.notifier.addListener(_onMarkerPrefChanged);
  }

  void _onMarkerPrefChanged() {
    if (mounted) setState(() {});
  }

  /// v1.4.57 (Part 13): driver ki pasand 'Gaari' ho to us ki
  /// APNI qisam (positionCategory ke liye); 'Teer' ho to null
  /// (map purana teer wala nishan deta hai)। Store na ho ya
  /// qisam khaali ho to bhi teer hi rahega।
  String? _ownMarkerCategory() {
    if (MarkerPrefs.notifier.value != MarkerStyle.vehicle) {
      return null;
    }
    final v = widget.store?.profile.vehicle.trim() ?? '';
    return v.isEmpty ? null : v;
  }

  @override
  void didUpdateWidget(DriverNavView old) {
    super.didUpdateWidget(old);
    if (_targetKey != _lastTargetKey) {
      _lastTargetKey = _targetKey;
      _route = null;
      _routeOrigin = null;
      _manualRoute = false;
      _optionsOpen = false;
      _navOptions = const [];
      // v1.4.45: naya hadaf — purana re-route elan/revert
      // is ride-hisse par lagu nahi rehta।
      _rerouteNotice = false;
      _preRerouteRoute = null;
      // v1.4.57 (Part 9): naye hisse par purani warning bhi
      // saaf — har hadaf ki apni taaza jaanch hogi।
      _jamReport = null;
      _jamOffer = null;
      _jamDismissedId = '';
      final p = _pos;
      if (p != null) _fetchRoute(p, force: true);
    }
  }

  @override
  void dispose() {
    MarkerPrefs.notifier.removeListener(_onMarkerPrefChanged);
    _rerouteTimer?.cancel();
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _initLocation() async {
    try {
      final service = await Geolocator.isLocationServiceEnabled();
      if (!service) {
        if (mounted) setState(() => _noGps = true);
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        if (mounted) setState(() => _noGps = true);
        return;
      }
      final last = await Geolocator.getLastKnownPosition();
      if (last != null && mounted) _onPos(last);
      // v1.4.10 (malik ka hukm 2026-11-09): distanceFilter 0 —
      // har GPS fix par naya maqam mile, taake qadam-qadam ki
      // harkat bhi map par saath saath nazar aye.
      _sub = Geolocator.getPositionStream(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 0),
      ).listen(_onPos, onError: (_) {});
    } catch (_) {
      if (mounted) setState(() => _noGps = true);
    }
  }

  void _onPos(Position p) {
    if (!mounted) return;
    final pos = ll.LatLng(p.latitude, p.longitude);
    widget.onPosition?.call(pos);
    final now = DateTime.now();
    _trail.add((p: pos, t: now));
    while (_trail.length > 120) {
      _trail.removeAt(0);
    }
    while (_trail.length > 2 &&
        now.difference(_trail.first.t) > const Duration(seconds: 45)) {
      _trail.removeAt(0);
    }
    final speed = _speedEstimate(p, pos, now);
    final anch = _trailAnchor(pos);
    // Route segment ki simt — sirf tab jab position route ki line
    // se <= 25 m ke andar ho; door ho to woh simt ghlt hogi, is
    // liye wahan movement baseline hi chalega.
    double? routeBearing;
    final route = _route;
    if (route != null) {
      final prog = route.track.progressAt(pos);
      final dRoute =
          const ll.Distance().as(ll.LengthUnit.Meter, pos, prog.snapped);
      if (dRoute <= _kRouteNearM) routeBearing = prog.bearingDeg;
    }
    // Candidate simt: speed < 1 m/s ho to KOI candidate nahi —
    // simt jama rehti hai (khade GPS ki jitter teer ko kabhi
    // nahi ghumati). Chalti haalat mein route segment ko tarjeeh,
    // warna ~12 m baseline; baseline < 3 m ho to bhi hold.
    double? candidate;
    if (speed >= _kHoldSpeedMps) {
      candidate = routeBearing ??
          (anch.dist >= _kHoldMoveM
              ? safarBearingBetween(anch.anchor, pos)
              : null);
    }
    setState(() {
      _pos = pos;
      if (candidate != null) {
        _displayBearing = _hasBearing
            ? safarLerpBearing(_displayBearing, candidate, _kBearingLerp)
            : candidate;
        _hasBearing = true;
      }
      // Heading-up camera: sirf asal drive ki raftaar (> 1.5 m/s)
      // par taaza hoti hai; rukne par aakhri simt hi rehti hai.
      if (speed > _kCameraSpeedMps && _hasBearing) {
        _camBearing = _displayBearing;
      }
    });
    final origin = _routeOrigin;
    if (_manualRoute && _route != null) {
      // v1.4.44: driver ka KHUD chuna hua route auto-refetch
      // se nahi badalta — sirf tab jab woh us line se bohat
      // door (> 100 m) nikal jaye (rasta chhor diya ho) to
      // aam re-route wapas shuru hota hai।
      final prog = _route!.track.progressAt(pos);
      final off =
          const ll.Distance().as(ll.LengthUnit.Meter, pos, prog.snapped);
      if (off > 100) {
        _manualRoute = false;
        _fetchRoute(pos, force: true);
      }
    } else if (_route == null ||
        origin == null ||
        const ll.Distance().as(ll.LengthUnit.Meter, origin, pos) > 120) {
      _fetchRoute(pos, force: _route != null);
    }
  }

  Future<void> _fetchRoute(ll.LatLng from, {required bool force}) async {
    final token = ++_fetchToken;
    final target = _target;
    final r = await RouteService.fetch(from, target, forceNetwork: force);
    if (!mounted || token != _fetchToken) return;
    setState(() {
      _route = r;
      _routeOrigin = from;
    });
  }

  // --- v1.4.44 ROUTE OPTIONS (driver) -----------------------------

  /// Do routes "wahi" hain ya nahi — endpoints + kul doori ki
  /// taqreebi pehchan (grey lines mein maujooda route dohra
  /// na dikhe is liye)।
  bool _sameRouteLine(RouteResult a, RouteResult b) {
    if (a.points.isEmpty || b.points.isEmpty) return false;
    final dFirst = const ll.Distance()
        .as(ll.LengthUnit.Meter, a.points.first, b.points.first);
    final dLast = const ll.Distance()
        .as(ll.LengthUnit.Meter, a.points.last, b.points.last);
    final dDiff = (a.distanceM - b.distanceM).abs();
    return dFirst < 60 && dLast < 60 && dDiff < a.distanceM * 0.03 + 30;
  }

  /// Options kholna: driver ki MAUJOODA live jagah se manzil
  /// tak NAYA OSRM hisaab (forceNetwork — booking wale purane
  /// alternatives par inhisaar nahi)। Asal route na mile
  /// (seedhi-line fallback) to options nahi khulte — jaali
  /// line kabhi nahi।
  Future<void> _openRouteOptions() async {
    final pos = _pos;
    if (pos == null || _optionsLoading) return;
    setState(() => _optionsLoading = true);
    final r = await RouteService.fetch(pos, _target, forceNetwork: true);
    if (!mounted) return;
    setState(() {
      _optionsLoading = false;
      if (r.isStraightFallback) {
        _optionsOpen = false;
        _navOptions = const [];
      } else {
        _navOptions = [r, ...r.alternatives];
        _optionsOrigin = pos;
        _optionsOpen = true;
      }
    });
  }

  void _toggleRouteOptions() {
    if (_optionsOpen) {
      setState(() {
        _optionsOpen = false;
        _navOptions = const [];
      });
    } else {
      _openRouteOptions();
    }
  }

  /// Driver ne grey line chuni — navigation isi route par
  /// shift (line/steps/banner sab build mein _route se bante
  /// hain)। Fare ko hath NAHI lagta।
  void _chooseNavRoute(RouteResult r) {
    setState(() {
      _route = r;
      _routeOrigin = _optionsOrigin ?? _pos;
      _manualRoute = true;
      _optionsOpen = false;
      _navOptions = const [];
    });
  }

  // --- v1.4.45 AUTO RE-ROUTE ENGINE (1-minute tick) -----------

  /// Har 60s wali jaanch: reports taaza karo, wohi
  /// RouteService.fetch se taaza route lo, ReRouteEngine se
  /// faisla lo। Switch banta ho to navigation naye route
  /// par + awaaz + banner। Driver options khol kar khud
  /// chun raha ho, elan pehle se khula ho, ya revert ke
  /// 5-minute hold mein ho — tick khamosh rehta hai।
  Future<void> _rerouteTick() async {
    final store = widget.store;
    final pos = _pos;
    final cur = _route;
    if (store == null || pos == null || cur == null || _rerouteBusy) {
      return;
    }
    if (_optionsOpen || _rerouteNotice) return;
    final hold = _rerouteHoldUntil;
    if (hold != null && DateTime.now().isBefore(hold)) return;
    _rerouteBusy = true;
    try {
      await Backend.syncRoadReports(store);
      // v1.4.57 (Part 9): khadi warning ki taaza jaanch —
      // driver maslay wali jagah se guzar gaya ho to warning
      // khud saaf; abhi wahin hai to warning khadi rehti hai
      // (faisla driver ka hai, dobara hisaab NAHI)।
      final standingJam = _jamReport;
      if (standingJam != null) {
        final still = ReRouteEngine.troubleOn(cur, store.roadReports,
            progressAlongM: cur.track.progressAt(pos).alongM);
        if (still?.id == standingJam.id) return;
        if (mounted) {
          setState(() {
            _jamReport = null;
            _jamOffer = null;
          });
        }
      }
      final fresh =
          await RouteService.fetch(pos, _target, forceNetwork: true);
      // Is doran route khud badal gaya ho (refetch/manual)
      // to purana faisla lagu NAHI — agli tick taaza sochegi।
      if (!mounted || _route != cur || fresh.isStraightFallback) return;
      final progress = cur.track.progressAt(pos);
      // v1.4.57 (Part 9): REPORT wala masla ho to route KHUD
      // NAHI badlega — pehle WARNING + dusre raste ki
      // peshkash; faisla driver ka (locked route rule)।
      // Driver ne is report par 'Yahi Rasta' chun liya ho to
      // engine dobara NAHI poochhega/badlega।
      final trouble = ReRouteEngine.troubleOn(cur, store.roadReports,
          progressAlongM: progress.alongM);
      if (trouble != null && trouble.id == _jamDismissedId) return;
      final next = ReRouteEngine.decide(
        current: cur,
        fresh: fresh,
        reports: store.roadReports,
        progressAlongM: progress.alongM,
      );
      if (trouble != null) {
        if (mounted) {
          setState(() {
            _jamReport = trouble;
            _jamOffer = next;
          });
          unawaited(Voice.speak(trouble.kind == RoadReport.kindJam
              ? 'Aage jaam hai'
              : 'Aage sadak band hai'));
        }
        return;
      }
      if (next == null) return;
      setState(() {
        _preRerouteRoute = cur;
        _route = next;
        _routeOrigin = pos;
        _manualRoute = false;
        _rerouteNotice = true;
      });
      // Awaaz wala elan — wohi jumla jo banner par likha hai।
      unawaited(Voice.speak('Rasta badal diya gaya hai — is raste se jayein'));
    } catch (_) {
      // Jaanch na ho paye to maujooda rasta hi chalta rehta hai।
    } finally {
      _rerouteBusy = false;
    }
  }

  /// Driver ne naya rasta rad kar diya — purana rasta wapas,
  /// aur 5 minute tak engine dobara NAHI badlega (driver ki
  /// marzi aakhri hai)। Purana route _manualRoute bhi ho
  /// jata hai taake aam auto-refetch bhi use na chhede
  /// (line se > 100 m wala maujooda usool barkarar)।
  void _revertReroute() {
    final prev = _preRerouteRoute;
    setState(() {
      if (prev != null) {
        _route = prev;
        _manualRoute = true;
      }
      _rerouteNotice = false;
      _preRerouteRoute = null;
      _rerouteHoldUntil =
          DateTime.now().add(ReRouteEngine.revertHold);
    });
  }

  /// Driver ne naya rasta qabool kar liya — banner band,
  /// naya route hi ab navigation hai।
  void _acceptReroute() {
    setState(() {
      _rerouteNotice = false;
      _preRerouteRoute = null;
    });
  }

  /// v1.4.57 (Part 9): warning par 'Dusra Rasta Lein' —
  /// pesh kiya gaya saaf rasta navigation ban jata hai
  /// (kiraya booking mein mehfooz hai, use hath NAHI lagta)।
  void _acceptJamOffer() {
    final offer = _jamOffer;
    final pos = _pos;
    if (offer == null || pos == null) return;
    setState(() {
      _route = offer;
      _routeOrigin = pos;
      _manualRoute = false;
      _jamReport = null;
      _jamOffer = null;
    });
    unawaited(Voice.speak('Dusra rasta le liya hai'));
  }

  /// v1.4.57 (Part 9): warning par 'Yahi Rasta' — driver ki
  /// marzi aakhri: is report par engine dobara NAHI
  /// poochhega, aur 5 minute ki aam khamoshi bhi lag jati
  /// hai। Surkh hissa map par rehta hai (khabar chhupti
  /// NAHI, sirf banner band hota hai)।
  void _keepJamRoute() {
    final r = _jamReport;
    setState(() {
      if (r != null) _jamDismissedId = r.id;
      _jamReport = null;
      _jamOffer = null;
      _rerouteHoldUntil =
          DateTime.now().add(ReRouteEngine.revertHold);
    });
  }

  /// v1.4.57 (Part 14): banner ka CHHOTA matn (Part 10) —
  /// step ki OSRM qisam + modifier se; gali ka naam
  /// bannerSub mein alag ata hai। Pul wale mor par malik
  /// ke lafz: 'Pul par chadhna hai'।
  String _shortTurnText(RouteStep s) {
    final t = s.type;
    final m = s.modifier;
    switch (t) {
      case 'on ramp':
        return 'Pul par chadhna hai';
      case 'off ramp':
        return 'Pul se utrein';
      case 'merge':
        return 'Traffic mein milein';
      case 'roundabout':
      case 'rotary':
      case 'roundabout turn':
        return s.exitNo > 0
            ? 'Gol chowrangi · nikasi ${s.exitNo}'
            : 'Gol chowrangi';
      case 'fork':
        return m.contains('left')
            ? 'Baayein rakhein'
            : m.contains('right')
                ? 'Daayein rakhein'
                : 'Seedha rakhein';
      case 'end of road':
        return m.contains('left')
            ? 'Baayein murein'
            : m.contains('right')
                ? 'Daayein murein'
                : 'Seedha chalein';
      case 'turn':
        switch (m) {
          case 'left':
            return 'Baayein murein';
          case 'right':
            return 'Daayein murein';
          case 'slight left':
            return 'Halki baayein';
          case 'slight right':
            return 'Halki daayein';
          case 'sharp left':
            return 'Tez baayein murein';
          case 'sharp right':
            return 'Tez daayein murein';
          case 'uturn':
            return 'U-turn lein';
          default:
            return 'Seedha chalein';
        }
      case 'depart':
        return 'Chalna shuru';
      default:
        // Qisam na mile (purana cache) to asal instruction
        // ka pehla hissa — sadak wale hisse ke baghair।
        final ins = s.instruction.split(' — ').first.trim();
        return ins.isEmpty ? 'Seedha chalein' : ins;
    }
  }

  /// v1.4.57 (Part 14): diye gaye step ke mor ka teer PNG
  /// banana — mor se ~18 m pehle aur ~18 m baad ki route
  /// simtein teer ki shakal tay karti hain (pul wale split
  /// par teer ROUTE wali branch ki simt hi leta hai —
  /// geometry route ki apni hai)।
  Future<void> _genTurnPng(RouteResult route, RouteStep step) async {
    final key = _turnKey;
    ll.LatLng pointAt(double m) {
      final t = route.track;
      if (t.points.isEmpty) return step.at;
      for (var i = 1; i < t.cumM.length; i++) {
        if (t.cumM[i] >= m) {
          final seg = t.cumM[i] - t.cumM[i - 1];
          final f = seg == 0 ? 0.0 : (m - t.cumM[i - 1]) / seg;
          final a = t.points[i - 1];
          final b = t.points[i];
          return ll.LatLng(
            a.latitude + (b.latitude - a.latitude) * f,
            a.longitude + (b.longitude - a.longitude) * f,
          );
        }
      }
      return t.points.last;
    }

    final along = step.alongM;
    final p0 = pointAt(math.max(0, along - 18));
    final p1 = pointAt(along);
    final p2 = pointAt(math.min(route.track.totalM, along + 18));
    final png = await safarTurnArrowPng(
      route.track.bearingBetween(p0, p1),
      route.track.bearingBetween(p1, p2),
    );
    if (mounted && png != null && _turnKey == key) {
      setState(() => _turnPng = png);
    }
  }

  /// Kisi route-maqam (alongM) par gali/sadak ka naam —
  /// steps ke road field se; na mile to null (jaali naam
  /// kabhi NAHI)।
  String? _roadNameAt(RouteResult route, double alongM) {
    if (!route.hasSteps) return null;
    String? name;
    for (final s in route.steps) {
      if (s.alongM <= alongM + 5) {
        if (s.road.trim().isNotEmpty) name = s.road.trim();
      } else {
        break;
      }
    }
    return name;
  }

  /// Driver ki sadak-report apni mojooda jagah par —
  /// store.addRoadReport se local + backend (messages
  /// table) dono jagah jati hai; doosre drivers ko sync
  /// par milti hai। Report ke foran baad apni jaanch bhi
  /// — band rasta apne hi route par ho to engine abhi
  /// rasta badal dega।
  Future<void> _reportRoad(String kind) async {
    final store = widget.store;
    final pos = _pos;
    if (store == null || pos == null) return;
    await store.addRoadReport(kind, pos.latitude, pos.longitude);
    if (!mounted) return;
    setState(() => _reportThanks = kind == RoadReport.kindClosed
        ? 'Band Sadak ki report bhej di gayi hai — shukriya'
        : 'Shadeed Jaam ki report bhej di gayi hai — shukriya');
    unawaited(_rerouteTick());
  }

  /// Map ke liye grey lines: khule options mein se maujooda
  /// (neeli) line ke ilawa sab।
  List<List<ll.LatLng>>? _greyNavLines() {
    if (!_optionsOpen || _navOptions.isEmpty) return null;
    final cur = _route;
    return [
      for (final o in _navOptions)
        if (cur == null || !_sameRouteLine(o, cur)) o.points,
    ];
  }

  /// Nav map par tap: options khule hon to qareebi grey line
  /// (≤ 40 m) select; band hon to MAUJOODA line par tap se
  /// options khul jate hain। Is ke ilawa tap kuch nahi karta
  /// (nav mein pin lagana hai hi nahi)।
  void _onNavMapTap(ll.LatLng p) {
    if (_optionsOpen) {
      RouteResult? best;
      var bestD = double.infinity;
      for (final o in _navOptions) {
        final cur = _route;
        if (cur != null && _sameRouteLine(o, cur)) continue;
        final d = o.track.minDistanceTo(p);
        if (d < bestD) {
          bestD = d;
          best = o;
        }
      }
      if (best != null && bestD <= 40) _chooseNavRoute(best);
      return;
    }
    final route = _route;
    if (route != null && route.track.minDistanceTo(p) <= 40) {
      _openRouteOptions();
    }
  }

  /// v1.4.29: driver is waqt jis route-hisse par hai, us ka
  /// gali/sadak ka naam (steps ke road field se); na mile to
  /// agle hisse ka naam; bilkul na mile to null (chip gayab)।
  String? _currentRoad(RouteResult? route,
      ({ll.LatLng snapped, double alongM, double bearingDeg})? progress) {
    if (route == null || progress == null || !route.hasSteps) {
      return null;
    }
    String? current;
    for (final s in route.steps) {
      if (s.alongM <= progress.alongM + 5) {
        if (s.road.trim().isNotEmpty) current = s.road.trim();
      } else {
        if (current != null) return current;
        if (s.road.trim().isNotEmpty) return s.road.trim();
        break;
      }
    }
    return current;
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final target = _target;
    final route = _route;
    final pos = _pos;
    final progress =
        (route != null && pos != null) ? route.track.progressAt(pos) : null;
    final arrowPoint = progress?.snapped ?? pos;
    // v1.4.11: teer ki simt hamesha smoothed _displayBearing —
    // route-segment tarjeeh, ~12 m baseline aur hold/lerp ka
    // saara hisaab _onPos mein ho chuka hota hai.
    final arrowBearing = _displayBearing;

    // v1.4.57 (Part 9): maujooda route ke AAGE taaza report
    // (Band Sadak / Shadeed Jaam) — pareshan hisse ki line
    // SURKH (map ko alertPoints mein jati hai) aur warning
    // banner ki chhoti tafseel (gali · doori · dusra rasta)।
    List<ll.LatLng>? jamSegment;
    String? jamMeta;
    final navStore = widget.store;
    if (route != null && progress != null && navStore != null) {
      final jamAhead = ReRouteEngine.troubleOn(
          route, navStore.roadReports,
          progressAlongM: progress.alongM);
      if (jamAhead != null) {
        final at = route.track
            .progressAt(ll.LatLng(jamAhead.lat, jamAhead.lng))
            .alongM;
        final seg = <ll.LatLng>[];
        for (var i = 0; i < route.points.length; i++) {
          final c = route.track.cumM[i];
          if (c >= at - 150 && c <= at + 250) seg.add(route.points[i]);
        }
        if (seg.length > 1) jamSegment = seg;
        final roadName = _roadNameAt(route, at);
        jamMeta = [
          if (roadName != null) roadName,
          '${fmtDist(math.max(0.0, at - progress.alongM))} aage',
          if (_jamOffer != null)
            'Dusra rasta ~${(_jamOffer!.durationS / 60).ceil()} min',
        ].join(' · ');
      }
    }

    // v1.4.57 (Part 14): banner wala hi agla mor — map par
    // us ki jagah teer pehle se lagana hai। Mor badle to
    // us ki geometry ka naya teer PNG banta hai।
    RouteStep? nextTurn;
    if (route != null && progress != null && route.hasSteps) {
      for (final s in route.steps) {
        if (!s.isArrive && s.alongM > progress.alongM + 10) {
          nextTurn = s;
          break;
        }
      }
    }
    if (nextTurn != null && route != null) {
      final key =
          '${identityHashCode(route)}:${nextTurn.alongM.round()}';
      if (key != _turnKey) {
        _turnKey = key;
        unawaited(_genTurnPng(route, nextTurn));
      }
    }

    // Guidance banner ka hisaab
    String? bannerMain;
    String? bannerSub;
    if (pos != null && route != null && progress != null) {
      final remaining = math.max(0.0, route.track.totalM - progress.alongM);
      bannerSub = '$_targetLabel · ${fmtDist(remaining)} ${tr('remaining')}';
      if (remaining <= 25) {
        bannerMain = widget.booking.status == 'arrived'
            ? tr('arrived_destination')
            : tr('arrived_pickup');
      } else if (route.hasSteps) {
        RouteStep? next;
        for (final s in route.steps) {
          if (!s.isArrive && s.alongM > progress.alongM + 10) {
            next = s;
            break;
          }
        }
        final arriveStep = route.steps.where((s) => s.isArrive).firstOrNull;
        if (next != null) {
          final d = next.alongM - progress.alongM;
          // v1.4.57 (Part 14 — malik ka sakht hukm): banner
          // hamesha COUNTDOWN wali saaf shakal mein —
          // "200 m — Baayein murein"; bilkul qareeb (< 40 m)
          // par "Ab ..."। Matn CHHOTA (Part 10) step ki
          // qisam se banta hai (_shortTurnText); gali ka
          // naam bannerSub mein ata hai (neeche)।
          final short = _shortTurnText(next);
          bannerMain = d < 40
              ? 'Ab ${short[0].toLowerCase()}${short.substring(1)}'
              : '${fmtDist(d)} — $short';
          // v1.4.30 (owner hukm 2026-11-11 17:12): AGLI GALI
          // ka naam PEHLE se banner mein — OSRM steps ke road
          // field se; naam na mile to kuch nahi jodte (jaali
          // naam kabhi nahi)।
          if (next.road.trim().isNotEmpty) {
            bannerSub = '$bannerSub · ${tr('next_road')}: ${next.road.trim()}';
          }
          // v1.4.57 (Part 14 Addendum 2): pul par chadhne
          // wala mor ho to neeche wali branch ki wazahat
          // bhi pehle se — chhote lafzon mein।
          if (next.type == 'on ramp') {
            bannerSub = '$bannerSub · Neeche wali road nahi leni';
          }
        } else if (arriveStep != null) {
          final d = math.max(0.0, arriveStep.alongM - progress.alongM);
          bannerMain = '${fmtDist(d)} baad manzil hai';
        } else {
          bannerMain = 'Manzil ${fmtDist(remaining)} door hai';
        }
      } else {
        bannerMain = 'Manzil ${fmtDist(remaining)} door hai';
        bannerSub = '$_targetLabel · seedha rasta (offline)';
      }
    }

    final linePoints = route?.points ??
        (pos != null
            ? [pos, target]
            : [
                ll.LatLng(b.pickupLat, b.pickupLng),
                if (b.hasDropPin) ll.LatLng(b.dropLat, b.dropLng),
              ]);

    // v1.4.42 (H2 — owner hukm 2026-11-13 02:33; zoom owner
    // hukm 2026-11-13 03:10 par aur barhaya gaya): GALI-LEVEL
    // NAV ZOOM — driver door se galiyon ka hisaab nahi laga
    // sakta, is liye follow camera street-level 19.0 par
    // rehta hai (heading-up follow ke saath); agla mor
    // 150 m se qareeb ajaye to zoom aur qareeb — 19.5।
    // Passenger ka poora-route overview is se bilkul
    // alag hai aur pehle jaisa hi hai।
    var navZoom = 19.0;
    if (route != null && progress != null && route.hasSteps) {
      for (final s in route.steps) {
        if (!s.isArrive && s.alongM > progress.alongM + 10) {
          if (s.alongM - progress.alongM < 150) navZoom = 19.5;
          break;
        }
      }
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: SizedBox(
            height: 300,
            child: Stack(
              children: [
                Positioned.fill(
                  child: SafarMapView(
                    center: pos ?? target,
                    initialZoom: 14,
                    tilt: 55,
                    // v1.4.29 A/B USOOL: pickup ki taraf ja rahe
                    // hon to target "A" pin hai; ride shuru hone
                    // (arrived) ke baad manzil "B" pin hai —
                    // bilkul spec ki tartib।
                    pickup: b.status == 'arrived' ? null : target,
                    drop: b.status == 'arrived' ? target : null,
                    // v1.4.58: jo pin is marhale mein dikhta
                    // hai us ke upar booking wala jagah-naam —
                    // pehle pickup (pehli manzil), arrived ke
                    // baad drop (doosri manzil)।
                    pickupLabel: b.status == 'arrived' ? null : b.pickupLabel,
                    dropLabel: b.status == 'arrived' ? b.dropLabel : null,
                    routePoints: linePoints.length > 1 ? linePoints : null,
                    // v1.4.44: driver route options ki grey lines
                    // (sirf options khule hon tab)।
                    // v1.4.57 (Part 9): jaam warning khadi ho to
                    // pesh kiya gaya dusra rasta DASHED line mein
                    // dikhta hai (options wali grey line ki jagah)।
                    altRoutePoints: _jamOffer != null
                        ? [_jamOffer!.points]
                        : _greyNavLines(),
                    // v1.4.57 (Part 9): pareshan hisse ki SURKH
                    // line (report wali jagah)।
                    alertPoints: jamSegment,
                    onTapPoint: _onNavMapTap,
                    position: arrowPoint,
                    positionBearing: arrowBearing,
                    // v1.4.57 (Part 13): apna nishan — driver ki
                    // pasand (Teer/Gaari)।
                    positionCategory: _ownMarkerCategory(),
                    // v1.4.32 PHOTO-PIN: pickup marhale mein
                    // sawari ki photo us ke intezaar wale maqam
                    // par; arrived ke baad pin NAHI (sawari
                    // gaari mein hai)।
                    photoPinAt:
                        b.status == 'arrived' ? null : target,
                    photoPinPng: widget.passengerPhotoPng,
                    // v1.4.57 (Part 14): agle mor ka khaali
                    // teer — banner wale step ki asal jagah
                    // par, pehle se (pohanchne par NAHI)।
                    turnMarkerAt: nextTurn?.at,
                    turnMarkerPng: nextTurn != null ? _turnPng : null,
                    // v1.4.11: heading-up camera SIRF is nav view
                    // mein — _camBearing _onPos mein speed-gated
                    // hai (rukne par jama rehta hai).
                    cameraBearing: _camBearing,
                    positionOnline: widget.driverOnline,
                    followPosition: _follow,
                    // v1.4.42 (H2): gali-level follow zoom
                    // (19.0; mor qareeb ho to 19.5)।
                    followZoom: navZoom,
                    // v1.4.42 FOLLOW: camera ka nishana
                    // gaari se 70 m AAGE — teer markaz se
                    // neeche rehta hai, aage ka rasta zyada
                    // nazar ata hai; har fix par smooth pan
                    // (animateCamera), jump nahi।
                    followForwardOffsetM: 70,
                    // User map ko haath se hila de to
                    // follow toot jata hai — pill bhi sach
                    // bolegi (OFF); usi pill ko dabane se
                    // follow dobara lock ho jata hai।
                    onFollowPaused: () {
                      if (mounted && _follow) {
                        setState(() => _follow = false);
                      }
                    },
                    interactive: true,
                    fitToRoute: pos == null,
                  ),
                ),
                if (bannerMain != null)
                  Positioned(
                    top: 8,
                    left: 8,
                    right: 64,
                    // v1.4.44: banner par tap = route options
                    // kholna/band karna (driver ka hukm)।
                    child: GestureDetector(
                      onTap: _toggleRouteOptions,
                      child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: Brand.deepGreen.withOpacity(0.96),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Brand.gold, width: 1),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.navigation,
                              color: Brand.goldLight, size: 26),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(bannerMain,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 15.5,
                                        fontWeight: FontWeight.w800)),
                                if (bannerSub != null)
                                  Text(bannerSub,
                                      style: const TextStyle(
                                          color: Brand.goldLight,
                                          fontSize: 12)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    ),
                  ),
                // v1.4.44: options khule hon to hidayat patti —
                // driver ko pata chale ke grey line par tap
                // karna hai; banner dobara dabane se band।
                if (_optionsOpen)
                  Positioned(
                    top: 88,
                    left: 8,
                    child: Container(
                      constraints: const BoxConstraints(maxWidth: 300),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.78),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text(
                          'Doosra rasta chunne ke liye grey line par tap karein',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w700)),
                    ),
                  ),
                // v1.4.45: AUTO RE-ROUTE ka elan — engine ne
                // rasta badal diya hai; driver chahe to
                // 'Purana rasta' se wapas ja sakta hai (us ki
                // marzi aakhri), warna 'Theek hai' se naya
                // rasta pakka। Awaaz isi jumle se hoti hai।
                if (_rerouteNotice)
                  Positioned(
                    top: 88,
                    left: 8,
                    right: 8,
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(12, 8, 6, 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF6E0),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Brand.gold, width: 1.4),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.alt_route,
                              color: Brand.ajrakRed, size: 24),
                          const SizedBox(width: 8),
                          const Expanded(
                            child: Text(
                                'Rasta badal diya gaya hai — is raste se jayein',
                                style: TextStyle(
                                    color: Brand.greenDark,
                                    fontSize: 13.5,
                                    fontWeight: FontWeight.w800)),
                          ),
                          TextButton(
                            onPressed: _revertReroute,
                            child: const Text('Purana rasta',
                                style: TextStyle(
                                    color: Brand.ajrakRed,
                                    fontWeight: FontWeight.w800)),
                          ),
                          TextButton(
                            onPressed: _acceptReroute,
                            child: const Text('Theek hai',
                                style: TextStyle(
                                    color: Brand.green,
                                    fontWeight: FontWeight.w800)),
                          ),
                        ],
                      ),
                    ),
                  ),
                // v1.4.57 (Part 9): JAAM / BAND SADAK WARNING —
                // route ke aage kisi driver ki taaza report hai;
                // pareshan hissa map par SURKH hai, dusra rasta
                // (ho to) DASHED line mein pesh hai। Faisla
                // driver ka: 'Dusra Rasta Lein' ya 'Yahi Rasta'।
                // Matn CHHOTA rakha hai (Part 10 ka usool)।
                if (_jamReport != null)
                  Positioned(
                    top: 88,
                    left: 8,
                    right: 8,
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(12, 8, 6, 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFDECEA),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: const Color(0xFFD32F2F), width: 1.4),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.warning_amber_rounded,
                              color: Color(0xFFD32F2F), size: 24),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                    _jamReport!.kind ==
                                            RoadReport.kindJam
                                        ? 'Aage jaam hai'
                                        : 'Aage sadak band hai',
                                    style: const TextStyle(
                                        color: Color(0xFFB71C1C),
                                        fontSize: 14,
                                        fontWeight: FontWeight.w800)),
                                if (jamMeta != null)
                                  Text(jamMeta,
                                      style: const TextStyle(
                                          color: Colors.black87,
                                          fontSize: 11.5,
                                          fontWeight: FontWeight.w600)),
                              ],
                            ),
                          ),
                          if (_jamOffer != null)
                            TextButton(
                              onPressed: _acceptJamOffer,
                              child: const Text('Dusra Rasta Lein',
                                  style: TextStyle(
                                      color: Brand.green,
                                      fontWeight: FontWeight.w800)),
                            ),
                          TextButton(
                            onPressed: _keepJamRoute,
                            child: Text(
                                _jamOffer != null
                                    ? 'Yahi Rasta'
                                    : 'Theek hai',
                                style: const TextStyle(
                                    color: Color(0xFFB71C1C),
                                    fontWeight: FontWeight.w800)),
                          ),
                        ],
                      ),
                    ),
                  ),
                // v1.4.29 (spec NAV VIEW): maujooda gali ka naam
                // chip mein — route ke steps se (driver jis hisse
                // par hai, usi ka road name); naam na mile to chip
                // gayab। Speed-limit badge NAHI lagaya — OSRM se
                // speed-limit data nahi milta, jaali adad dikhana
                // mana hai (notes mein darj)।
                if (_currentRoad(route, progress) != null)
                  Positioned(
                    bottom: 8,
                    left: 8,
                    child: Container(
                      constraints: const BoxConstraints(maxWidth: 210),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.72),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.signpost,
                              size: 14, color: Colors.white70),
                          const SizedBox(width: 5),
                          Flexible(
                            child: Text(_currentRoad(route, progress)!,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700)),
                          ),
                        ],
                      ),
                    ),
                  ),
                Positioned(
                  bottom: 8,
                  right: 8,
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () => setState(() => _follow = !_follow),
                      borderRadius: BorderRadius.circular(20),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: _follow
                              ? Brand.green
                              : Colors.white.withOpacity(0.92),
                          borderRadius: BorderRadius.circular(20),
                          border:
                              Border.all(color: Brand.greenDark, width: 0.6),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.my_location,
                                size: 15,
                                color: _follow
                                    ? Colors.white
                                    : Brand.greenDark),
                            const SizedBox(width: 5),
                            Text(_follow ? 'Follow ON' : 'Follow OFF',
                                style: TextStyle(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w700,
                                    color: _follow
                                        ? Colors.white
                                        : Brand.greenDark)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        // v1.4.29 INFO PATTI (spec NAV VIEW): baqi doori ·
        // baqi waqt · pahunchne ka time + neeche progress line।
        // Waqt route ke kul duration ko baqi hisse ke tanasub
        // se andaza lagata hai (asal route data se — jaali
        // adad nahi)।
        if (route != null && progress != null && pos != null) ...[
          const SizedBox(height: 8),
          Builder(builder: (_) {
            final total = route.track.totalM;
            final remainM = math.max(0.0, total - progress.alongM);
            final frac = total > 0
                ? (progress.alongM / total).clamp(0.0, 1.0).toDouble()
                : 0.0;
            final remainS = route.durationS > 0 && total > 0
                ? route.durationS * (remainM / total)
                : 0.0;
            final eta = DateTime.now()
                .add(Duration(seconds: remainS.round()));
            String two(int v) => v.toString().padLeft(2, '0');
            return Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Brand.green.withOpacity(0.35)),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.route,
                              size: 16, color: Brand.greenDark),
                          const SizedBox(width: 5),
                          Text(fmtDist(remainM),
                              style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14.5,
                                  color: Brand.ink)),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.schedule,
                              size: 16, color: Brand.greenDark),
                          const SizedBox(width: 5),
                          Text(
                              remainS >= 60
                                  ? '~${(remainS / 60).ceil()} min'
                                  : '< 1 min',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14.5,
                                  color: Brand.ink)),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.flag,
                              size: 16, color: Brand.greenDark),
                          const SizedBox(width: 5),
                          Text('${two(eta.hour)}:${two(eta.minute)}',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14.5,
                                  color: Brand.ink)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: frac,
                      minHeight: 5,
                      color: const Color(0xFF00C853),
                      backgroundColor: const Color(0xFFE3EFE7),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
        // v1.4.29: "Open another navigation app" row — driver
        // chahe to bahari maps app mein maujooda hadaf khole
        // (geo intent; na khule to Google Maps ka web rasta)।
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () async {
                final t = _target;
                try {
                  await launchUrl(
                    Uri.parse(
                        'geo:${t.latitude},${t.longitude}?q=${t.latitude},${t.longitude}'),
                    mode: LaunchMode.externalApplication,
                  );
                } catch (_) {
                  try {
                    await launchUrl(
                      Uri.parse(
                          'https://www.google.com/maps/dir/?api=1&destination=${t.latitude},${t.longitude}'),
                      mode: LaunchMode.externalApplication,
                    );
                  } catch (_) {}
                }
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.black12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.open_in_new,
                        size: 17, color: Brand.greenDark),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(tr('open_other_nav'),
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 13.5,
                              color: Brand.ink)),
                    ),
                    const Icon(Icons.chevron_right,
                        size: 18, color: Colors.black38),
                  ],
                ),
              ),
            ),
          ),
        ),
        // v1.4.45 ROAD REPORT: driver apni mojooda jagah ki
        // report deta hai — yehi khabar doosre drivers ke
        // engine ko bhi milti hai (aur un ki reports is ko)।
        // Location na mile to button band (jaali jagah par
        // report NAHI jati)।
        if (widget.store != null) ...[
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _pos == null
                      ? null
                      : () => _reportRoad(RoadReport.kindClosed),
                  icon: const Icon(Icons.block, size: 17),
                  label: const Text('Band Sadak'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _pos == null
                      ? null
                      : () => _reportRoad(RoadReport.kindJam),
                  icon: const Icon(Icons.traffic, size: 17),
                  label: const Text('Shadeed Jaam'),
                ),
              ),
            ],
          ),
          if (_reportThanks.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(_reportThanks,
                  style: const TextStyle(
                      fontSize: 12,
                      color: Brand.greenDark,
                      fontWeight: FontWeight.w700)),
            ),
        ],
        if (_noGps)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              tr('gps_needed'),
              style: const TextStyle(fontSize: 12, color: Colors.black87),
            ),
          )
        else if (pos == null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              tr('location_waiting'),
              style: const TextStyle(fontSize: 12, color: Colors.black87),
            ),
          ),
      ],
    );
  }
}
