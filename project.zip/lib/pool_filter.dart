import 'package:latlong2/latlong.dart' as ll2;

import 'safar_map.dart' show kZoneCoords;
import 'store.dart' show Booking, kDriverPickupRadiusKm;

/// POOL SARHADEIN (v1.4.27 — postmortem #16, audit ki "doosra
/// sheher khulne se pehle lazmi" wali shart):
///
/// `pool_rides` RPC pending rides to deta hai lekin us ke jawab
/// mein na zone/city ka column hai na server par vehicle ka
/// filter — is liye sarhadein yahan CLIENT par lagti hain (RPC
/// jo asal fields deta hai — vehicle + pickup coordinates —
/// unhi se). Claim par server ka `claim_ride` race-guard pehle
/// se hai; ye filter us ke UPAR ki hifazat hai: ghalat vehicle
/// ya doosre sheher ki ride claim tak pohanchti hi nahi.
///
/// Usool:
///  (a) VEHICLE: ride ki gaari driver ki gaari se match kare —
///      mismatch wali ride list mein NAHI dikhti aur claim bhi
///      NAHI hoti (Bike wala Van ki ride nahi le sakta)।
///  (b) SHEHER/ZONE: ride ke pickup coordinates se sab se
///      qareebi maloom sheher (kZoneCoords) nikala jata hai;
///      woh driver ke registered sheher se alag ho to ride
///      chhupati hai aur claim rukti hai. Pickup pin na ho ya
///      driver ka sheher khaali/'Doosra Sheher' ho to sheher
///      ka faisla NAHI ho sakta (null) — list mein ride rehti
///      hai, claim par bhi is wajah se NAHI roka jata (doori
///      wali shart wahan alag se sakht hai)।
///  (c) DOORI: doori gin sake to sirf 2 km (kDriverPickupRadiusKm)
///      ke andar wali ride dikhti hai. Doori NA gin sake
///      (location off / pin nahi) to ride list mein reh sakti
///      hai — LEKIN claim NAHI ho sakti: claim par saaf rukawat
///      ati hai (purana fail-open claim khatam)।

/// Vehicle naam ki safai — 'Rickshaw' / ' rickshaw ' / 'RICKSHAW'
/// ek hi samjhe jayein।
String poolVehicleKey(String v) => v.trim().toLowerCase();

/// Ride ki gaari driver ki gaari hai ya nahi. Koi ek taraf
/// khaali ho to faisla NAHI (true) — list se is wajah se ride
/// nahi chhupati; claim par khaali driver-vehicle alag se
/// rukawat banta hai (neeche poolClaimBlockReason dekho)।
bool poolVehicleMatches(String rideVehicle, String driverVehicle) {
  final r = poolVehicleKey(rideVehicle);
  final d = poolVehicleKey(driverVehicle);
  if (r.isEmpty || d.isEmpty) return true;
  return r == d;
}

/// Pickup point ke sab se qareebi maloom sheher ka naam
/// (kZoneCoords ke markazi nuqton se)। Coordinates na hon
/// (0,0) to null — sheher ka faisla mumkin nahi।
String? poolRideCity(double pickupLat, double pickupLng) {
  if (pickupLat == 0 && pickupLng == 0) return null;
  final p = ll2.LatLng(pickupLat, pickupLng);
  String? best;
  var bestKm = double.infinity;
  for (final e in kZoneCoords.entries) {
    if (e.key == 'Doosra Sheher') continue;
    final d = const ll2.Distance()
        .as(ll2.LengthUnit.Kilometer, p, e.value);
    if (d < bestKm) {
      bestKm = d;
      best = e.key;
    }
  }
  return best;
}

/// Sheher ki sarhad: true = ride driver ke sheher ki hai,
/// false = pakka doosra sheher, null = faisla NAHI ho sakta
/// (pin nahi / driver ka sheher khaali ya 'Doosra Sheher')।
bool? poolZoneMatches(double pickupLat, double pickupLng, String driverZone) {
  final z = driverZone.trim();
  if (z.isEmpty || z == 'Doosra Sheher') return null;
  final city = poolRideCity(pickupLat, pickupLng);
  if (city == null) return null;
  return city == z;
}

/// Pool LIST mein ride dikhe ya nahi — teeno sarhadon ka jod:
/// vehicle mismatch = chhupao; sheher pakka doosra = chhupao;
/// doori gin sake aur 2 km se zyada = chhupao। Doori na gin
/// sake to ride dikhti hai (claim wahan rukta hai)।
bool poolRideVisible(
  Booking b, {
  required String driverVehicle,
  required String driverZone,
  required double? distanceKm,
  // v1.4.29 FINAL RADIUS RULE: har driver ka apna radius
  // (2–5 km, default 2) — purana fixed-2km yahan se badla।
  double radiusKm = kDriverPickupRadiusKm,
}) {
  if (!poolVehicleMatches(b.vehicle, driverVehicle)) return false;
  if (poolZoneMatches(b.pickupLat, b.pickupLng, driverZone) == false) {
    return false;
  }
  if (distanceKm != null && distanceKm > radiusKm) {
    return false;
  }
  return true;
}

/// CLAIM ki rukawat — null matlab claim aage barh sakta hai
/// (baqi gates alag hain)। Wajah saaf Roman Urdu mein, driver
/// ko dialog mein dikhti hai। Tartib: vehicle, sheher, doori।
String? poolClaimBlockReason(
  Booking b, {
  required String driverVehicle,
  required String driverZone,
  required double? distanceKm,
  // v1.4.29 FINAL RADIUS RULE: driver ka apna radius (2–5 km)।
  double radiusKm = kDriverPickupRadiusKm,
}) {
  final dv = driverVehicle.trim();
  if (dv.isEmpty) {
    return 'Aap ke profile mein gaari darj nahi hai — pehle apni gaari ki tafseel mukammal karein, phir ride lein.';
  }
  if (!poolVehicleMatches(b.vehicle, dv)) {
    return 'Ye ride ${b.vehicle} ki hai — aap ki gaari $dv hai, is liye ye ride aap nahi le sakte.';
  }
  if (poolZoneMatches(b.pickupLat, b.pickupLng, driverZone) == false) {
    final city = poolRideCity(b.pickupLat, b.pickupLng);
    return 'Ye ride ${city ?? 'doosre sheher'} ki hai — aap ka sheher ${driverZone.trim()} hai, is liye ye ride aap nahi le sakte.';
  }
  if (distanceKm == null) {
    return 'Aap ki location maloom nahi ho rahi — ride ki doori ki tasdeeq ke baghair ride qubool nahi ho sakti. Location on kar ke dobara koshish karein.';
  }
  if (distanceKm > radiusKm) {
    return 'Ye ride aap se ${distanceKm.toStringAsFixed(1)} km door hai — sirf ${radiusKm.toStringAsFixed(0)} km ke andar ki rides qubool ho sakti hain.';
  }
  return null;
}
