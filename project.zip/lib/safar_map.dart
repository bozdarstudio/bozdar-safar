import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart' as ll;
import 'package:maplibre_gl/maplibre_gl.dart' as ml;
import 'package:shared_preferences/shared_preferences.dart';
import 'route_service.dart';
import 'store.dart';
import 'theme.dart';

/// Muft OpenFreeMap "Liberty" style — vector tiles, bina API key.
/// Isi style mein Karachi ki asal galiyan/imaaratein hain aur zoom 15+
/// par imaaraton ki 3D (extruded) shakal bhi is style ke apne building
/// data se aati hai; neeche Safar ki apni extrusion layer bhi hai.
const String kLibertyStyleUrl = 'https://tiles.openfreemap.org/styles/liberty';

/// Satellite hybrid style — Esri World Imagery (muft, bina key) + upar
/// jagah/road ke labels wali reference layers. Sirf ONLINE chalta hai;
/// offline mein streets style hi kaam aata hai (uska region cache hai).
const String kSatelliteStyleJson = '''
{
  "version": 8,
  "name": "Safar Satellite",
  "sources": {
    "esri-imagery": {
      "type": "raster",
      "tiles": ["https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"],
      "tileSize": 256,
      "attribution": "Esri World Imagery"
    },
    "esri-roads": {
      "type": "raster",
      "tiles": ["https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}"],
      "tileSize": 256
    },
    "esri-labels": {
      "type": "raster",
      "tiles": ["https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}"],
      "tileSize": 256
    }
  },
  "layers": [
    {"id": "imagery", "type": "raster", "source": "esri-imagery"},
    {"id": "roads-ref", "type": "raster", "source": "esri-roads"},
    {"id": "labels-ref", "type": "raster", "source": "esri-labels"}
  ]
}
''';

/// Karachi ke zones ki asal coordinates (store.dart ke kZones se match).
const Map<String, ll.LatLng> kZoneCoords = {
  'Liaquatabad': ll.LatLng(24.9056, 67.0474),
  'Saddar': ll.LatLng(24.8608, 67.0104),
  'Clifton': ll.LatLng(24.8138, 67.0153),
  'Gulshan-e-Iqbal': ll.LatLng(24.9200, 67.0950),
  'Nazimabad': ll.LatLng(24.9167, 67.0367),
  'Korangi': ll.LatLng(24.8350, 67.1210),
  'Malir': ll.LatLng(24.8934, 67.2097),
  'Gulistan-e-Johar': ll.LatLng(24.9207, 67.1340),
  'North Karachi': ll.LatLng(24.9450, 67.0650),
  'Surjani Town': ll.LatLng(24.9680, 67.0068),
  'DHA': ll.LatLng(24.7950, 67.0570),
  'PECHS': ll.LatLng(24.8670, 67.0570),
  'Bahadurabad': ll.LatLng(24.8822, 67.0697),
  'Federal B Area': ll.LatLng(24.9270, 67.0560),
  'Doosra Ilaqa': ll.LatLng(24.8800, 67.0500),
};

ml.LatLng _m(ll.LatLng p) => ml.LatLng(p.latitude, p.longitude);

ll.LatLng _l(ml.LatLng p) => ll.LatLng(p.latitude, p.longitude);

/// Offline region: Karachi ka vector map pehli dafa khulne par khamoshi
/// se download ho jata hai (zoom 10–14, OpenFreeMap ki offline had —
/// 3,000 tiles / 50 MB — ke andar; takreeban 500-600 tiles, ~15–30 MB).
/// Is ke baad kamzor ya band net par bhi pura Karachi map chalta hai.
/// Is ke ilawa MapLibre ka apna ambient cache dekhe hue hisse bhi
/// offline mehfooz rakhta hai.
class OfflineMaps {
  static bool _started = false;

  static Future<void> ensureKarachi() async {
    if (_started) return;
    _started = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool('ofm_karachi_v1') == true) return;
      final regions = await ml.getListOfRegions();
      final exists =
          regions.any((r) => r.metadata['name'] == 'safar-karachi');
      if (!exists) {
        await ml.downloadOfflineRegion(
          ml.OfflineRegionDefinition(
            bounds: ml.LatLngBounds(
              southwest: const ml.LatLng(24.74, 66.90),
              northeast: const ml.LatLng(25.06, 67.45),
            ),
            mapStyleUrl: kLibertyStyleUrl,
            minZoom: 10,
            maxZoom: 14,
          ),
          metadata: const {'name': 'safar-karachi'},
        );
      }
      await prefs.setBool('ofm_karachi_v1', true);
    } catch (_) {
      // Best effort — fail ho to agli dafa phir koshish hogi; map online
      // bhi chalta rehta hai aur ambient cache kaam karta hai.
      _started = false;
    }
  }
}

/// Sab jagah istemal hone wala asal LIVE map (MapLibre GL):
/// - Jhuka hua (tilt) 3D-style view, asal vector galiyan
/// - Streets (Liberty) / Satellite hybrid style toggle
/// - Pickup pin (sabz), manzil par BARA sunehra TEER, route line (gehri sabz)
/// - Zone pins (chhote sunehre nuqtay), driver ki position ka sunehra nav-arrow
class SafarMapView extends StatefulWidget {
  final ll.LatLng center;
  final double initialZoom;
  final double tilt;
  final ll.LatLng? pickup;
  final ll.LatLng? drop;
  final List<ll.LatLng>? routePoints;
  final List<ll.LatLng>? zonePoints;
  final ll.LatLng? position;
  final double positionBearing;
  final bool followPosition;
  final bool interactive;
  final bool fitToRoute;
  final ll.LatLng? focusPoint;
  final int focusSeq;
  final bool externalStyleControl;
  final bool satellite;
  final ValueChanged<bool>? onSatelliteChanged;
  final void Function(ll.LatLng)? onTapPoint;
  final void Function(ll.LatLng)? onLongPressPoint;
  final void Function(ll.LatLng)? onCameraTarget;
  final VoidCallback? onCameraIdle;

  const SafarMapView({
    super.key,
    required this.center,
    this.initialZoom = 13,
    this.tilt = 50,
    this.pickup,
    this.drop,
    this.routePoints,
    this.zonePoints,
    this.position,
    this.positionBearing = 0,
    this.followPosition = false,
    this.interactive = true,
    this.fitToRoute = false,
    this.focusPoint,
    this.focusSeq = 0,
    this.externalStyleControl = false,
    this.satellite = false,
    this.onSatelliteChanged,
    this.onTapPoint,
    this.onLongPressPoint,
    this.onCameraTarget,
    this.onCameraIdle,
  });

  @override
  State<SafarMapView> createState() => _SafarMapViewState();
}

class _SafarMapViewState extends State<SafarMapView> {
  ml.MapLibreMapController? _c;
  bool _styleReady = false;
  bool _satelliteInternal = false;
  String _routeSig = '';
  ll.LatLng? _lastFollowed;

  bool get _sat =>
      widget.externalStyleControl ? widget.satellite : _satelliteInternal;

  @override
  void initState() {
    super.initState();
    _satelliteInternal = widget.satellite;
    OfflineMaps.ensureKarachi();
  }

  String get _style => _sat ? kSatelliteStyleJson : kLibertyStyleUrl;

  Future<void> _guard(Future<void> f) async {
    try {
      await f;
    } catch (_) {}
  }

  Map<String, dynamic> _fc(List<Map<String, dynamic>> features) =>
      {'type': 'FeatureCollection', 'features': features};

  Map<String, dynamic> _pointFeature(ll.LatLng p,
          {Map<String, dynamic>? props}) =>
      {
        'type': 'Feature',
        'geometry': {
          'type': 'Point',
          'coordinates': [p.longitude, p.latitude]
        },
        'properties': props ?? {},
      };

  Future<void> _applyStyle() async {
    final c = _c;
    if (c == null) return;
    _styleReady = false;
    // Marker tasveerein style ke andar register karein
    for (final entry in {
      'safar-pin': 'assets/map-pin-green.png',
      'safar-arrow': 'assets/map-arrow-down.png',
      'safar-nav': 'assets/map-nav-arrow.png',
    }.entries) {
      await _guard(() async {
        final data = await rootBundle.load(entry.value);
        await c.addImage(entry.key, data.buffer.asUint8List());
      }());
    }
    // Sources
    await _guard(c.addGeoJsonSource('safar-route', _fc([])));
    await _guard(c.addGeoJsonSource('safar-points', _fc([])));
    await _guard(c.addGeoJsonSource('safar-pos', _fc([])));
    await _guard(c.addGeoJsonSource('safar-zones', _fc([])));
    // 3D imaaratein — sirf streets style par (satellite par nahi).
    // Liberty ke vector data mein render_height jahan maujood hai wahan
    // imaaratein uthi hui nazar aati hain (zoom 15+).
    if (!_sat) {
      await _guard(c.addFillExtrusionLayer(
        'openmaptiles',
        'safar-buildings-3d',
        const ml.FillExtrusionLayerProperties(
          fillExtrusionColor: '#CFC4B0',
          fillExtrusionOpacity: 0.9,
          fillExtrusionHeight: [
            'coalesce',
            ['to-number', ['get', 'render_height']],
            8
          ],
          fillExtrusionBase: [
            'coalesce',
            ['to-number', ['get', 'render_min_height']],
            0
          ],
        ),
        sourceLayer: 'building',
        minzoom: 15,
      ));
    }
    // Route line — pehle safed kinara, phir gehri sabz line
    await _guard(c.addLineLayer(
      'safar-route',
      'safar-route-casing',
      const ml.LineLayerProperties(
        lineColor: '#FFFFFF',
        lineWidth: 9,
        lineOpacity: 0.9,
        lineCap: 'round',
        lineJoin: 'round',
      ),
    ));
    await _guard(c.addLineLayer(
      'safar-route',
      'safar-route-line',
      const ml.LineLayerProperties(
        lineColor: '#0B6B4F',
        lineWidth: 5.5,
        lineOpacity: 1,
        lineCap: 'round',
        lineJoin: 'round',
      ),
    ));
    // Zone pins — chhote sunehre nuqtay
    await _guard(c.addCircleLayer(
      'safar-zones',
      'safar-zone-dots',
      const ml.CircleLayerProperties(
        circleRadius: 5,
        circleColor: '#D4AF37',
        circleStrokeColor: '#FFFFFF',
        circleStrokeWidth: 1.6,
        circleOpacity: 0.95,
      ),
    ));
    // Pickup pin
    await _guard(c.addSymbolLayer(
      'safar-points',
      'safar-pickup-sym',
      const ml.SymbolLayerProperties(
        iconImage: 'safar-pin',
        iconSize: 0.5,
        iconAnchor: 'bottom',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
      filter: ['==', 'kind', 'pickup'],
    ));
    // Manzil — BARA sunehra teer
    await _guard(c.addSymbolLayer(
      'safar-points',
      'safar-drop-sym',
      const ml.SymbolLayerProperties(
        iconImage: 'safar-arrow',
        iconSize: 0.55,
        iconAnchor: 'bottom',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
      filter: ['==', 'kind', 'drop'],
    ));
    // Driver ki position — sunehra nav arrow, route ki simt mein ghumta hua
    await _guard(c.addSymbolLayer(
      'safar-pos',
      'safar-pos-sym',
      const ml.SymbolLayerProperties(
        iconImage: 'safar-nav',
        iconSize: 0.42,
        iconAnchor: 'center',
        iconRotate: ['get', 'bearing'],
        iconRotationAlignment: 'map',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
    ));
    _styleReady = true;
    _routeSig = '';
    _pushData();
    _maybeFit(initial: true);
    _followIfNeeded(force: true);
  }

  String _sigOf(List<ll.LatLng>? pts) {
    if (pts == null || pts.length < 2) return '';
    final a = pts.first, b = pts.last;
    return '${pts.length}|${a.latitude.toStringAsFixed(4)},${a.longitude.toStringAsFixed(4)}'
        '|${b.latitude.toStringAsFixed(4)},${b.longitude.toStringAsFixed(4)}';
  }

  void _pushData() {
    final c = _c;
    if (c == null || !_styleReady) return;
    final pts = widget.routePoints;
    _guard(c.setGeoJsonSource(
        'safar-route',
        _fc([
          if (pts != null && pts.length > 1)
            {
              'type': 'Feature',
              'geometry': {
                'type': 'LineString',
                'coordinates':
                    pts.map((p) => [p.longitude, p.latitude]).toList()
              },
              'properties': {},
            }
        ])));
    _guard(c.setGeoJsonSource(
        'safar-points',
        _fc([
          if (widget.pickup != null)
            _pointFeature(widget.pickup!, props: {'kind': 'pickup'}),
          if (widget.drop != null)
            _pointFeature(widget.drop!, props: {'kind': 'drop'}),
        ])));
    _guard(c.setGeoJsonSource(
        'safar-pos',
        _fc([
          if (widget.position != null)
            _pointFeature(widget.position!,
                props: {'bearing': widget.positionBearing}),
        ])));
    _guard(c.setGeoJsonSource(
        'safar-zones',
        _fc([
          for (final z in widget.zonePoints ?? <ll.LatLng>[]) _pointFeature(z),
        ])));
  }

  void _fitPoints(List<ll.LatLng> pts) {
    final c = _c;
    if (c == null || pts.isEmpty) return;
    var minLat = pts.first.latitude, maxLat = minLat;
    var minLng = pts.first.longitude, maxLng = minLng;
    for (final p in pts) {
      minLat = math.min(minLat, p.latitude);
      maxLat = math.max(maxLat, p.latitude);
      minLng = math.min(minLng, p.longitude);
      maxLng = math.max(maxLng, p.longitude);
    }
    final center = ll.LatLng((minLat + maxLat) / 2, (minLng + maxLng) / 2);
    final span = math.max((maxLat - minLat).abs(), (maxLng - minLng).abs());
    final zoom = span <= 0.0005
        ? 15.5
        : (math.log(360 / (span * 1.5)) / math.ln2).clamp(11.0, 16.0);
    _guard(c.animateCamera(ml.CameraUpdate.newCameraPosition(
      ml.CameraPosition(target: _m(center), zoom: zoom, tilt: widget.tilt),
    )));
  }

  void _maybeFit({bool initial = false}) {
    if (!widget.fitToRoute) return;
    final pts = widget.routePoints;
    if (pts == null || pts.length < 2) return;
    final sig = _sigOf(pts);
    if (!initial && sig == _routeSig) return;
    _routeSig = sig;
    _fitPoints(pts);
  }

  void _followIfNeeded({bool force = false}) {
    final c = _c;
    final pos = widget.position;
    if (c == null || !_styleReady || pos == null || !widget.followPosition) {
      return;
    }
    if (!force && _lastFollowed != null) {
      final d = const ll.Distance().as(ll.LengthUnit.Meter, _lastFollowed!, pos);
      if (d < 4) return;
    }
    _lastFollowed = pos;
    _guard(c.animateCamera(ml.CameraUpdate.newCameraPosition(
      ml.CameraPosition(
        target: _m(pos),
        zoom: 16.5,
        tilt: 55,
        bearing: widget.positionBearing,
      ),
    )));
  }

  @override
  void didUpdateWidget(SafarMapView old) {
    super.didUpdateWidget(old);
    if (widget.focusSeq != old.focusSeq && widget.focusPoint != null) {
      final c = _c;
      if (c != null) {
        _guard(c.animateCamera(ml.CameraUpdate.newCameraPosition(
          ml.CameraPosition(
              target: _m(widget.focusPoint!), zoom: 15.5, tilt: 55),
        )));
      }
    }
    _pushData();
    _maybeFit();
    _followIfNeeded();
  }

  void _toggleStyle() {
    final next = !_sat;
    if (widget.externalStyleControl) {
      widget.onSatelliteChanged?.call(next);
    } else {
      setState(() => _satelliteInternal = next);
      widget.onSatelliteChanged?.call(next);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        ml.MapLibreMap(
          styleString: _style,
          initialCameraPosition: ml.CameraPosition(
            target: _m(widget.center),
            zoom: widget.initialZoom,
            tilt: widget.tilt,
          ),
          trackCameraPosition: true,
          compassEnabled: widget.interactive,
          scrollGesturesEnabled: widget.interactive,
          rotateGesturesEnabled: widget.interactive,
          tiltGesturesEnabled: widget.interactive,
          zoomGesturesEnabled: widget.interactive,
          onMapCreated: (c) => _c = c,
          onStyleLoadedCallback: _applyStyle,
          onMapClick: (point, coords) =>
              widget.onTapPoint?.call(_l(coords)),
          onMapLongClick: (point, coords) =>
              widget.onLongPressPoint?.call(_l(coords)),
          onCameraMove: (pos) =>
              widget.onCameraTarget?.call(_l(pos.target)),
          onCameraIdle: () => widget.onCameraIdle?.call(),
        ),
        if (!widget.externalStyleControl)
          Positioned(
            top: 8,
            right: 8,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: _toggleStyle,
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Brand.deepGreen.withOpacity(0.92),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Brand.gold, width: 1),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.layers, color: Brand.goldLight, size: 15),
                      const SizedBox(width: 5),
                      Text(_sat ? 'Streets' : 'Satellite',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 11.5,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

/// Pickup → drop ka tayyar route map: OSRM se asal sadak ka route khud
/// le aata hai (cache ke saath); net na ho to cache ya seedhi line.
/// Passenger ki booking tafseel aur driver ki nayi booking card mein
/// istemal hota hai.
class SafarRouteMap extends StatefulWidget {
  final ll.LatLng pickup;
  final ll.LatLng? drop;
  final bool interactive;
  final double tilt;

  const SafarRouteMap({
    super.key,
    required this.pickup,
    this.drop,
    this.interactive = true,
    this.tilt = 45,
  });

  @override
  State<SafarRouteMap> createState() => _SafarRouteMapState();
}

class _SafarRouteMapState extends State<SafarRouteMap> {
  RouteResult? _route;
  int _token = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(SafarRouteMap old) {
    super.didUpdateWidget(old);
    if (old.pickup != widget.pickup || old.drop != widget.drop) _load();
  }

  Future<void> _load() async {
    final drop = widget.drop;
    if (drop == null) {
      setState(() => _route = null);
      return;
    }
    final token = ++_token;
    final r = await RouteService.fetch(widget.pickup, drop);
    if (mounted && token == _token) setState(() => _route = r);
  }

  @override
  Widget build(BuildContext context) {
    final drop = widget.drop;
    final center = drop != null
        ? ll.LatLng((widget.pickup.latitude + drop.latitude) / 2,
            (widget.pickup.longitude + drop.longitude) / 2)
        : widget.pickup;
    return SafarMapView(
      center: center,
      initialZoom: 13,
      tilt: widget.tilt,
      pickup: widget.pickup,
      drop: drop,
      routePoints:
          _route?.points ?? (drop != null ? [widget.pickup, drop] : null),
      interactive: widget.interactive,
      fitToRoute: true,
    );
  }
}

/// Driver ke liye Google-style guidance: chal rahi ride par asal route,
/// agle mor ki Roman Urdu hidayat wala banner, route par aage barhta
/// sunehra arrow (sirf asal GPS position par — ijazat/position na ho to
/// na arrow, na banner; kuch jhooti nahi dikhta), aur follow camera.
class DriverNavView extends StatefulWidget {
  final Booking booking;
  const DriverNavView({super.key, required this.booking});

  @override
  State<DriverNavView> createState() => _DriverNavViewState();
}

class _DriverNavViewState extends State<DriverNavView> {
  StreamSubscription<Position>? _sub;
  ll.LatLng? _pos;
  double _heading = 0;
  RouteResult? _route;
  ll.LatLng? _routeOrigin;
  int _fetchToken = 0;
  bool _follow = true;
  bool _noGps = false;

  ll.LatLng get _target => widget.booking.status == 'arrived'
      ? ll.LatLng(widget.booking.dropLat, widget.booking.dropLng)
      : ll.LatLng(widget.booking.pickupLat, widget.booking.pickupLng);

  String get _targetLabel => widget.booking.status == 'arrived'
      ? 'Drop: ${widget.booking.dropLabel}'
      : 'Pickup: ${widget.booking.pickupLabel}';

  String get _targetKey =>
      '${widget.booking.status}|${_target.latitude.toStringAsFixed(4)},${_target.longitude.toStringAsFixed(4)}';
  String _lastTargetKey = '';

  @override
  void initState() {
    super.initState();
    _lastTargetKey = _targetKey;
    _initLocation();
  }

  @override
  void didUpdateWidget(DriverNavView old) {
    super.didUpdateWidget(old);
    if (_targetKey != _lastTargetKey) {
      _lastTargetKey = _targetKey;
      _route = null;
      _routeOrigin = null;
      final p = _pos;
      if (p != null) _fetchRoute(p, force: true);
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _initLocation() async {
    try {
      final service = await Geolocator.isLocationServiceEnabled();
      if (!service) {
        if (mounted) setState(() => _noGps = true);
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        if (mounted) setState(() => _noGps = true);
        return;
      }
      final last = await Geolocator.getLastKnownPosition();
      if (last != null && mounted) _onPos(last);
      _sub = Geolocator.getPositionStream(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 8),
      ).listen(_onPos, onError: (_) {});
    } catch (_) {
      if (mounted) setState(() => _noGps = true);
    }
  }

  void _onPos(Position p) {
    if (!mounted) return;
    final pos = ll.LatLng(p.latitude, p.longitude);
    setState(() {
      _pos = pos;
      if (p.heading >= 0) _heading = p.heading;
    });
    final origin = _routeOrigin;
    if (_route == null ||
        origin == null ||
        const ll.Distance().as(ll.LengthUnit.Meter, origin, pos) > 120) {
      _fetchRoute(pos, force: _route != null);
    }
  }

  Future<void> _fetchRoute(ll.LatLng from, {required bool force}) async {
    final token = ++_fetchToken;
    final target = _target;
    final r = await RouteService.fetch(from, target, forceNetwork: force);
    if (!mounted || token != _fetchToken) return;
    setState(() {
      _route = r;
      _routeOrigin = from;
    });
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final target = _target;
    final route = _route;
    final pos = _pos;
    final progress =
        (route != null && pos != null) ? route.track.progressAt(pos) : null;
    final arrowPoint = progress?.snapped ?? pos;
    final arrowBearing = progress?.bearingDeg ?? _heading;

    // Guidance banner ka hisaab
    String? bannerMain;
    String? bannerSub;
    if (pos != null && route != null && progress != null) {
      final remaining = math.max(0.0, route.track.totalM - progress.alongM);
      bannerSub = '$_targetLabel · baqi ${fmtDist(remaining)}';
      if (remaining <= 25) {
        bannerMain = widget.booking.status == 'arrived'
            ? 'Manzil par pohanch gaye'
            : 'Pickup par pohanch gaye';
      } else if (route.hasSteps) {
        RouteStep? next;
        for (final s in route.steps) {
          if (!s.isArrive && s.alongM > progress.alongM + 10) {
            next = s;
            break;
          }
        }
        final arriveStep = route.steps.where((s) => s.isArrive).firstOrNull;
        if (next != null) {
          final d = next.alongM - progress.alongM;
          bannerMain = d < 40
              ? 'Ab ${next.instruction[0].toLowerCase()}${next.instruction.substring(1)}'
              : '${fmtDist(d)} baad ${next.instruction[0].toLowerCase()}${next.instruction.substring(1)}';
        } else if (arriveStep != null) {
          final d = math.max(0.0, arriveStep.alongM - progress.alongM);
          bannerMain = '${fmtDist(d)} baad manzil hai';
        } else {
          bannerMain = 'Manzil ${fmtDist(remaining)} door hai';
        }
      } else {
        bannerMain = 'Manzil ${fmtDist(remaining)} door hai';
        bannerSub = '$_targetLabel · seedha rasta (offline)';
      }
    }

    final linePoints = route?.points ??
        (pos != null
            ? [pos, target]
            : [
                ll.LatLng(b.pickupLat, b.pickupLng),
                if (b.hasDropPin) ll.LatLng(b.dropLat, b.dropLng),
              ]);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: SizedBox(
            height: 300,
            child: Stack(
              children: [
                Positioned.fill(
                  child: SafarMapView(
                    center: pos ?? target,
                    initialZoom: 14,
                    tilt: 55,
                    drop: target,
                    routePoints: linePoints.length > 1 ? linePoints : null,
                    position: arrowPoint,
                    positionBearing: arrowBearing,
                    followPosition: _follow,
                    interactive: true,
                    fitToRoute: pos == null,
                  ),
                ),
                if (bannerMain != null)
                  Positioned(
                    top: 8,
                    left: 8,
                    right: 64,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: Brand.deepGreen.withOpacity(0.96),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Brand.gold, width: 1),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.navigation,
                              color: Brand.goldLight, size: 26),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(bannerMain,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 15.5,
                                        fontWeight: FontWeight.w800)),
                                if (bannerSub != null)
                                  Text(bannerSub,
                                      style: const TextStyle(
                                          color: Brand.goldLight,
                                          fontSize: 12)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                Positioned(
                  bottom: 8,
                  right: 8,
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () => setState(() => _follow = !_follow),
                      borderRadius: BorderRadius.circular(20),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: _follow
                              ? Brand.green
                              : Colors.white.withOpacity(0.92),
                          borderRadius: BorderRadius.circular(20),
                          border:
                              Border.all(color: Brand.greenDark, width: 0.6),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.my_location,
                                size: 15,
                                color: _follow
                                    ? Colors.white
                                    : Brand.greenDark),
                            const SizedBox(width: 5),
                            Text(_follow ? 'Follow ON' : 'Follow OFF',
                                style: TextStyle(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w700,
                                    color: _follow
                                        ? Colors.white
                                        : Brand.greenDark)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        if (_noGps)
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text(
              'Guidance ke liye location on karein aur ijazat dein — baghair asal position ke na arrow dikhega, na banner.',
              style: TextStyle(fontSize: 12, color: Colors.black54),
            ),
          )
        else if (pos == null)
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text(
              'Location ka intezaar ho raha hai… position milte hi guidance shuru ho jayegi.',
              style: TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ),
      ],
    );
  }
}
