import 'dart:async';
import 'package:flutter/material.dart';
import 'agent_section.dart';
import 'backend.dart';
import 'otp.dart';
import 'profile_photo.dart';
import 'store.dart';
import 'theme.dart';

// ===========================================================================
// v1.4.4 — LEGAL + SAFETY: Sharait (Terms) + Privacy Policy
//
// Malik ka hukm (2026-11-08): app ke andar saari qanooni sharait
// lazmi hain taaki baad mein koi phans na sakay. Saara mutan seedhi
// saada Roman Urdu mein hai taaki har sawari/driver ko samajh aye.
//
//  - [TermsPage] / [PrivacyPage]: parhne wale pages — Driver
//    Profile se bhi khulte hain, sawari ki Profile se bhi, aur
//    registration ke aakhri qadam se bhi ("Sharait dobara parhein").
//  - [TermsGateScreen]: pehli dafa app khulne par lazmi — baghair
//    "Mein ne parh liya, qabool hai" dabaye app aage NAHI barhti;
//    qubooliyat ka waqt mehfooz ho jata hai (store.termsAcceptedAtMs;
//    driver ki apni qubooliyat registration mein alag se
//    drivers.terms_accepted_at mein bhi jati hai — migration v134).
// ===========================================================================

class LegalSection {
  final String title;
  final List<String> lines;
  const LegalSection(this.title, this.lines);
}

const List<LegalSection> kTermsSawari = [
  LegalSection('Sawari (Passenger) ki Sharait', [
    'Bozdar Safar sirf ek technology platform hai — ye aap ko qareebi tasdeeq-shuda driver se jorta hai. Gaari aur safar ki asal zimmedari driver ki hai.',
    'Kiraya hamesha CASH mein seedha driver ko ada hota hai. App ke andar koi paisa nahi rukta aur na hi koi advance liya jata hai.',
    'Ride pakki hone se PEHLE aap ko kiraya nahi dikhaya jata — kul kiraya booking pakki hote hi nazar ata hai, aur wohi tay-shuda kiraya hai (koi mol-bhav nahi).',
    'Apna qeemti samaan (mobile, paisa, zewar, documents) aap ki apni zimmedari hai. Gaari mein reh jane wali cheez ki ittela foran Master ko message karke dein — hum driver se rabta karke poori koshish karenge, lekin samaan ki zimmedari company par nahi hoti.',
    'Driver ke pohanchnay ke baad pehle chand minute intezaar muft hai; us se zyada intezaar par munasib waiting charges kul kiraye mein shamil ho jate hain (hisaab booking par saaf likha hota hai).',
  ]),
  LegalSection('Ride Cancel karne ki Policy', [
    'Aap ride kabhi bhi cancel kar sakte hain — cancel par app aap se WAJAH poochhegi. Ye wajah ride ke record ke saath mehfooz rehti hai taaki koi galat-fehmi ya jhooti shikayat ho to asal baat sab ke saamne ho.',
    'Agar aap beech raaste mein rukwa kar ride waheen khatam (complete) kar dein, to bhi app wajah poochhegi — aur woh wajah bhi record mein mehfooz rahegi.',
    'Driver ke pohanchnay se pehle cancel karna bilkul muft hai. Driver pohanch jaye aur dair tak intezaar karna pare to waiting charges lag sakte hain.',
    'Baar baar bila-wajah cancel karne par Master aap se rabta kar sakta hai, aur ghalat istemal par app ka istemal roka ja sakta hai.',
    'Ride ke doran koi masla ho to SOS button dabayein — woh aap ko 1122 se jorta hai aur Master ko bhi khabar bhejta hai.',
    'APP SE BAHIR SAFAR (v1.4.20): Agar driver aap ko kahe ke ride cancel karke seedha us ke saath chalein, to cancel ke baad woh safar Bozdar Safar ke record se BAHIR ho jayega — us safar mein hifazat, kiraye ya kisi bhi masle ki zimmedari Bozdar Safar ki NAHI hogi, woh aap ki apni hogi. Mahfooz safar ke liye ride hamesha app ke andar mukammal karein.',
  ]),
];

const List<LegalSection> kTermsDriver = [
  LegalSection('Driver ki Sharait', [
    'Aap ki gaari ka INSURANCE aur REGISTRATION (kaghaz) har waqt VALID rakhna AAP KI APNI zimmedari hai. Kaghaz khatam ya jaali hon to ID band ho sakti hai aur kisi nuqsan ki zimmedari bhi aap par hogi.',
    'Traffic ke tamam qanoon ki pabandi lazmi hai — speed, signal, seat belt/helmet aur sawari ki hifazat sab se pehle hai.',
    'Khuda na khasta HADSA ho jaye to SAB SE PEHLE 1122 par call karke madad bulayein, phir foran Master ko message karke ittila dein.',
    'Bozdar Safar sirf ek TECHNOLOGY PLATFORM hai — driver company ka MULAZIM NAHI hai. Har driver apni gaari, apne waqt aur apni kamai ka khud zimmedar hai.',
    'Ride qubool karne ke baad sawari ko waqt par lena, aaram se aur hifazat se manzil tak pohanchana aap ki zimmedari hai. Sawari se badtameezi, zyada kiraya mangna ya tay-shuda kiraye se inkaar sakht mana hai.',
    'Rozana duty se pehle LIVE SELFIE lazmi hai. Account sirf EK hi device par chalega — device badalna ho to pehle Master ko message karke batayein, warna ID khud-ba-khud chand ghante block ho jati hai.',
    'Ek CNIC par sirf EK driver account banta hai. Mobile number badalne par ID 12 ghante ke liye khud-ba-khud block ho jati hai.',
    'APP SE BAHIR RIDE SAKHT MANA HAI (v1.4.20): Sawari ko ride cancel karwa kar app se BAHIR le jana sakht mana hai. Aisa karne par ID BLOCK kar di jayegi.',
  ]),
  LegalSection('Service Fee aur Hisaab', [
    'Har mukammal ride par 10% SERVICE FEE banti hai. Ye fee driver ke AMANAT DEPOSIT balance se khud-ba-khud kat jati hai (neeche wali Amanat Deposit ki shartein parhein) — alag se koi fee talab NAHI ki jati.',
    'Hisaab system ke record mein rehta hai — har ride ki fee backend mein khud darj hoti hai. Jama aur wasool ki ginti SIRF Master ke record se hoti hai; driver khud app mein koi jama ya payment darj NAHI kar sakta.',
    'Apni kamai, deposit jama, kati hui fees, baqi balance aur tamam rides ka poora record aap ki app (Wallet) aur Master ke paas mehfooz rehta hai — kisi jhagray ki surat mein yehi record saboot hota hai.',
  ]),
  // AMANAT DEPOSIT (v1.4.21 — malik ka faisla 2026-11-10 20:05):
  // owner ki shartein SAAF-SAAF, usi ke matlab par — ye raqam
  // sirf driver ki AMANAT hai; sirf fees kategi; fees ke ilawa
  // ek rupee bhi idhar udhar NAHI ho sakta; baqi har waqt
  // driver ki apni hai aur chhorne par poori wapas milegi।
  LegalSection('Amanat Deposit — Aap ki Raqam, Sirf Aap ki Amanat', [
    'Duty shuru karne se pehle har driver Rs 500 ka AMANAT DEPOSIT jama karta hai — apne Easypaisa ya JazzCash account se Raast ke zariye (0312 2635002) par. Ye driver ka apna account hai — us ke account ya number se company ka koi talluk NAHI hai aur woh number kahin darj NAHI hota. Jama ki entry SIRF Master karta hai, aur sirf tab jab raqam asal mein wasool ho jaye; driver khud app mein koi jama darj NAHI kar sakta.',
    'Ye raqam sirf aur sirf DRIVER ki apni AMANAT hai — ye Bozdar Safar ki KAMAI NAHI hai aur na hi company ki milkiyat hai.',
    'Is amanat mein se SIRF driver ki apni mukammal rides ki 10% service fees kategi — har ride ki fee us ride ke record ke saath khud hisaab ho jati hai.',
    'Fees ke ilawa Bozdar Safar driver ki is raqam se EK RUPEE bhi idhar udhar NAHI kar sakta. Is raqam par hamara koi aur lena dena NAHI hai — na koi aur katauti, na koi aur charge.',
    'Baqi raqam har waqt driver ki apni hai — jaise woh apni raqam nikaal sakta hai; kaam chhorne par us ki baqi poori raqam usay WAPAS milegi.',
    'Poora hisaab — kitna jama hua, kitni fees kati, kitna baqi hai — app mein har waqt driver ko saaf nazar ayega (Wallet — "Mera Deposit (Amanat)"), aur wohi hisaab Master ke paas bhi mehfooz rahega.',
    'Deposit balance khatam (zero ya us se kam) ho jaye to online honay aur nayi ride qubool karne ke liye pehle Rs 500 ka top-up lazmi hai — wasool honay par Master ke darj karte hi balance barh jata hai.',
  ]),
];

const List<LegalSection> kPrivacySections = [
  LegalSection('Hum kya data jama karte hain — aur kyun', [
    'Sawari ka naam aur mobile number — sirf ride ki pehchan aur rabte ke liye.',
    'Driver ka naam, mobile, CNIC, gaari ki tafseel aur documents ki tasaveer — sirf Tasdeeq (verification) ke liye, taaki sawari ko mehfooz aur asal driver mile.',
    'Ride ki tafseel (kahan se kahan, waqt, kiraya) aur driver ki duty ke doran ki location — sirf ride chalane, hisaab rakhne aur hifazat ke liye.',
    'Driver ki rozana live selfie — sirf ye pakka karne ke liye ke account asal driver hi chala raha hai.',
  ]),
  LegalSection('Ride ke records — mehfooz archive', [
    'Har ride ka record (waqt, jagahen, kiraya, cancel ya beech raaste mein khatam karne ki wajah, ratings) SAFETY ke liye mehfooz archive mein ek muddat — 3 SAAL — tak rehta hai.',
    'Isi liye ACCOUNT DELETE karne se aap ki PEHCHAN (naam, number, email aur login) phone aur server — dono se khatam ho jati hai, lekin ride ke HISAAB wale records (waqt, kiraya, jagahen) baghair naam/number ke mehfooz rehte hain. Agar kal koi jhooti shikayat ya jhagra ho to yehi record asal baat saaf karta hai — ye aap ki aur driver, dono ki hifazat hai.',
  ]),
  LegalSection('Aap ka data kisko dikhta hai', [
    'Aap ka data sirf MASTER (Bozdar Safar ke malik) ko dikhta hai — wahi Tasdeeq, hisaab aur shikayat ke liye use dekhta hai.',
    'Aap ka data kisi teesre shakhs ya company ko NAHI becha jata aur na hi kisi advertisement ke liye istemal hota hai.',
    'Qanoon ki taraf se lazmi talab ho (masalan police ki tehqeeqat) to record mutaliqa idare ko diya ja sakta hai.',
    'Apna account delete karne ka ikhtiyar aap ke paas hamesha hai — Profile mein "Account Delete Karein" se. Delete se pehle aap ki Gmail par OTP code bhej kar dobara tasdeeq hoti hai — tasdeeq ke baghair account delete NAHI hota. Delete ke baad naam/number dobara darj kiye baghair nayi booking nahi ho sakti.',
  ]),
];

Widget _sectionsView(List<LegalSection> sections) {
  return ListView(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
    children: [
      for (final s in sections) ...[
        Text(s.title,
            style: const TextStyle(
                fontSize: 16.5,
                fontWeight: FontWeight.w900,
                color: Brand.greenDark)),
        const SizedBox(height: 8),
        for (final line in s.lines) ...[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.only(top: 7),
                child: Icon(Icons.circle, size: 6, color: Brand.green),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(line,
                    style: const TextStyle(fontSize: 13.5, height: 1.45)),
              ),
            ],
          ),
          const SizedBox(height: 8),
        ],
        const SizedBox(height: 14),
      ],
    ],
  );
}

/// Sharait (Terms) ka page. 20:40 TARMIM (malik ka hukm
/// 2026-11-10): har cheez apni jagah — default mein SIRF
/// Sawari ki sharait; Driver ki sharait (Service Fee, Amanat
/// Deposit, top-up) sirf driver wale hisse se khulti hain
/// ([showDriverTerms] = true — driver registration aur driver
/// Profile se). Sawari ki screens par deposit/fees/top-up ka
/// koi zikr NAHI ata.
class TermsPage extends StatelessWidget {
  final bool showDriverTerms;
  const TermsPage({super.key, this.showDriverTerms = false});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sharait (Terms)')),
      body: _sectionsView(
          showDriverTerms ? [...kTermsSawari, ...kTermsDriver] : kTermsSawari),
    );
  }
}

/// Privacy Policy ka page.
class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Privacy Policy')),
      body: _sectionsView(kPrivacySections),
    );
  }
}

/// Pehli dafa app khulne par LAZMI wala darwaza: Sharait parh kar
/// "Mein ne parh liya, qabool hai" dabaye baghair aage nahi barha
/// ja sakta. Qabool karne ka waqt store mein mehfooz ho jata hai.
class TermsGateScreen extends StatelessWidget {
  final AppStore store;
  const TermsGateScreen({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 18, 16, 4),
              child: Text('Bozdar Safar ki Sharait',
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: Brand.greenDark)),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Text(
                'App istemal karne se pehle ye sharait parh lein. Neeche wala button dabane se ye darj ho jayega ke aap ne sharait parh li hain aur aap ko qabool hain.',
                style: TextStyle(fontSize: 13, color: Colors.black54),
              ),
            ),
            // 20:40 TARMIM: ye darwaza har user (sawari samait)
            // ke saamne ata hai — is liye yahan SIRF Sawari ki
            // sharait. Driver ki sharait (fees/deposit/top-up)
            // driver registration mein alag di aur qabool
            // karwayi jati hain.
            Expanded(child: _sectionsView(kTermsSawari)),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => store.acceptTerms(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Brand.deepGreen,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    textStyle: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w900),
                  ),
                  child: const Text('Mein ne parh liya, qabool hai'),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: TextButton(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const PrivacyPage()),
                ),
                child: const Text('Privacy Policy bhi parhein'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Profile pages mein lagne wali mushtarka patti: Sharait +
/// Privacy ke darwaze aur (agar darj ho) qubooliyat ka waqt.
class LegalLinksCard extends StatelessWidget {
  final AppStore store;

  /// Driver ki apni qubooliyat ka waqt (registration wali) —
  /// driver Profile se ata hai; sawari ke liye null.
  final int? driverAcceptedAtMs;

  /// 20:40 TARMIM: true sirf driver wale hisse (driver Profile)
  /// se — tab Sharait mein Driver ki sharait (fees/deposit/
  /// top-up) bhi khulti hain. Sawari ki Profile se false —
  /// wahan sirf Sawari ki sharait.
  final bool showDriverTerms;
  const LegalLinksCard(
      {super.key,
      required this.store,
      this.driverAcceptedAtMs,
      this.showDriverTerms = false});

  @override
  Widget build(BuildContext context) {
    final acceptedMs =
        driverAcceptedAtMs ?? store.termsAcceptedAtMs;
    return Card(
      child: Column(
        children: [
          ListTile(
            leading: const Icon(Icons.description, color: Brand.green),
            title: const Text('Sharait (Terms)',
                style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(showDriverTerms
                ? 'Sawari aur Driver ki tamam sharait.'
                : 'Sawari ki sharait.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                  builder: (_) => TermsPage(showDriverTerms: showDriverTerms)),
            ),
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.privacy_tip, color: Brand.green),
            title: const Text('Privacy Policy',
                style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle:
                const Text('Aap ka data kaise mehfooz rehta hai — saaf alfaaz mein.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const PrivacyPage()),
            ),
          ),
          if (acceptedMs > 0) ...[
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 9, 16, 11),
              child: Row(
                children: [
                  const Icon(Icons.verified, size: 16, color: Brand.green),
                  const SizedBox(width: 7),
                  Expanded(
                    child: Text(
                      'Sharait qabool ki gayi: ${fmtDate(DateTime.fromMillisecondsSinceEpoch(acceptedMs))} ${fmtTime(DateTime.fromMillisecondsSinceEpoch(acceptedMs))}',
                      style: const TextStyle(
                          fontSize: 12.5, color: Colors.black54),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// Sawari ki Profile screen (v1.4.4) — naam/number ki haalat,
/// Sharait/Privacy ke darwaze, aur ACCOUNT DELETE (profile saaf;
/// ride ke records Privacy Policy ke mutabiq mehfooz rahte hain).
/// v1.4.5 (B4): Profile ka asal body — alag screen mein bhi aur
/// passenger bottom-nav ke Profile tab mein bhi yehi chalta hai.
/// [onAfterDelete]: account delete ke baad kya ho (screen par
/// pop; tab mein kuch nahi — list wahin taaza ho jati hai).
class PassengerProfileBody extends StatelessWidget {
  final AppStore store;
  final VoidCallback? onAfterDelete;
  const PassengerProfileBody(
      {super.key, required this.store, this.onAfterDelete});

  /// ACCOUNT DELETE ka poora flow (v1.4.16 — asal mukammal
  /// deletion):
  ///   0) Gmail pehle se verify shuda hona lazmi hai — warna
  ///      pehle isi Profile ki Email wali card se verify karwaya
  ///      jata hai (baghair pehchan ki tasdeeq ke koi account
  ///      delete nahi kar sakta)।
  ///   1) Tasdeeqi dialog (asal behavior ki wazahat)।
  ///   2) OTP se DOBARA tasdeeq — OtpGatePage (maujooda pattern):
  ///      code usi verify-shuda Gmail par jata hai।
  ///   3) Server RPC `delete_my_account` — pehchan server par
  ///      anonymize + identity link khatam. RPC fail ho to
  ///      flow YAHEEN ruk jata hai: saaf error, local data ko
  ///      haath NAHI lagta — deletion kabhi adhura nahi rehta।
  ///   4) Master ko khabar (purani behhavior — naam/number
  ///      local se, taaki Master ko pata ho kis ne delete kiya)।
  ///   5) Local wipe (deletePassengerProfile) — sab se aakhir।
  Future<void> _deleteAccount(BuildContext context) async {
    final email = store.passengerEmail.trim().toLowerCase();
    if (email.isEmpty || !store.passengerEmailVerified) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: const Text('Pehle Gmail verify karein'),
          content: const Text(
            'Account delete karne se pehle pehchan ki tasdeeq lazmi hai — is ke liye aap ki Gmail is Profile par pehle se verify shuda honi chahiye.\n\n'
            'Isi screen par upar Email wali card mein apni Gmail par code mangwa kar verify kar lein, phir dobara "Account Delete Karein" dabayein.',
            style: TextStyle(fontSize: 13.5, height: 1.45),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Theek Hai'),
            ),
          ],
        ),
      );
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Account delete karein?'),
        content: const Text(
          'Aap ka ACCOUNT delete ho jayega:\n'
          '• Is phone se naam, mobile number, email aur mehfooz jagahen saaf ho jayengi.\n'
          '• Server par bhi aap ki pehchan (naam/number/email) khatam kar di jayegi aur aap ka login band ho jayega.\n\n'
          'Ek baat saaf sun lein: purani RIDES ka HISAAB (waqt, jagahen, kiraya) delete NAHI hota — woh safety ke record ke tor par mehfooz rehta hai, lekin us par aap ka naam/number NAHI rehta (pehchan khatam kar di jati hai), taaki kisi jhagray ya jhooti shikayat ki surat mein asal hisaab maujood ho.\n\n'
          'Aage badhne par aap ki Gmail par OTP code ayega — dobara tasdeeq ke baghair delete NAHI hoga.',
          style: TextStyle(fontSize: 13.5, height: 1.45),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Rehne Dein'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Brand.ajrakRed),
            child: const Text('Aage — OTP Tasdeeq'),
          ),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    // Qadam 2: OTP se dobara tasdeeq (maujooda OtpGate pattern)।
    final verified = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => OtpGatePage(
          email: email,
          title: 'Account Delete — Tasdeeq',
        ),
      ),
    );
    if (verified != true || !context.mounted) return;
    // Qadam 3: server par asal deletion (RPC)। Fail = rukawat,
    // saaf error — local data bilkul nahi chhoota jata।
    final done = await Backend.deletePassengerAccountRemote(email);
    if (!context.mounted) return;
    if (!done) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              'Server par account delete nahi ho saka — internet check karke dobara koshish karein. Aap ka account abhi mehfooz hai, kuch delete NAHI hua.'),
        ),
      );
      return;
    }
    // Qadam 4: Master ko khabar (naam/number local se — RPC ke
    // baad, wipe se pehle; message queued bhi rahe to agli sync
    // par chala jayega)।
    final name = store.passengerName.trim();
    final phone = store.passengerPhone.trim();
    await store.addMasterMessage(MasterMessage(
      id: store.newId(),
      senderKey: store.deviceId,
      senderRole: 'passenger',
      senderName: name,
      senderMobile: phone,
      senderZone: '',
      category: 'Deegar',
      body: 'ACCOUNT DELETE: Sawari ${name.isEmpty ? '(naam darj nahi tha)' : name}'
          '${phone.isEmpty ? '' : ' ($phone)'} ne OTP tasdeeq ke baad apna account delete kar diya hai. '
          'Server par us ki pehchan (naam/number/email) anonymize ho gayi hai aur login band ho gaya hai; '
          'rides ka hisaab baghair pehchan ke mehfooz archive mein rahega.',
      createdAt: DateTime.now(),
    ));
    // Qadam 5: local wipe — sab se aakhir, sirf server kamyabi par।
    await store.deletePassengerProfile();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Aap ka account delete ho gaya hai. Shukriya!')),
    );
    onAfterDelete?.call();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          return ListView(
            padding: const EdgeInsets.all(14),
            children: [
              // Board style sir-khata (brief §6): goal sabz avatar
              // (naam ka pehla harf — passenger ki photo ka koi
              // feature hai hi nahi, jaali photo NAHI), naam +
              // mobile. Verified pill passenger par NAHI lagti
              // (us ke liye koi tasdeeq system hai hi nahi).
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Brand.green, Brand.deepGreen],
                  ),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Brand.gold, width: 1.6),
                ),
                child: Row(
                  children: [
                    InitialAvatar(name: store.passengerName),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            store.passengerName.isEmpty
                                ? 'Assalam O Alaikum'
                                : store.passengerName,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w900),
                          ),
                          Text(
                            store.passengerPhone.isEmpty
                                ? 'Naam/number booking par darj hota hai'
                                : store.passengerPhone,
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 12.5),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.person, color: Brand.green),
                          SizedBox(width: 9),
                          Text('Meri Maloomat',
                              style: TextStyle(
                                  fontWeight: FontWeight.w900, fontSize: 15)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      _row('Naam',
                          store.passengerName.isEmpty ? '—' : store.passengerName),
                      _row('Mobile',
                          store.passengerPhone.isEmpty ? '—' : store.passengerPhone),
                      const SizedBox(height: 4),
                      const Text(
                        'Naam aur number booking ke waqt darj hote hain — yahan sirf un ki haalat dikhti hai.',
                        style: TextStyle(fontSize: 12, color: Colors.black54),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              // v1.4.22 MERI PHOTO (malik ka hukm 2026-11-10
              // 23:36): sawari bhi apni profile photo laga/badla
              // sakti hai — kul 3 dafa ki hadd, baqi moqay likhe
              // hue, hadd par sada likha notice।
              ProfilePhotoCard(store: store, forDriver: false),
              const SizedBox(height: 10),
              // v1.4.7: Gmail + OTP card (spec §1) + no-show
              // warnings ki haalat (spec §5) + Logout।
              _PassengerEmailCard(store: store),
              const SizedBox(height: 10),
              // AGENT HISA (v1.4.6): is mobile ka ACTIVE agent ho
              // to "Mera Agent Hisa" card yahin khulta hai — na ho
              // to widget khud ghayab rehta hai (SizedBox.shrink).
              AgentSection(store: store),
              const SizedBox(height: 10),
              LegalLinksCard(store: store),
              const SizedBox(height: 10),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.delete_forever,
                      color: Brand.ajrakRed),
                  title: const Text('Account Delete Karein',
                      style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: Brand.ajrakRed)),
                  subtitle: const Text(
                      'Account phone aur server dono se delete ho jayega — rides ka hisaab baghair pehchan ke mehfooz rahega.'),
                  onTap: () => _deleteAccount(context),
                ),
              ),
            ],
          );
        },
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            child: Text(label,
                style: const TextStyle(
                    fontWeight: FontWeight.w700, color: Colors.black54)),
          ),
          Expanded(
            child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}

/// Sawari ka Gmail/OTP card (v1.4.7, spec §1/§5) — email verify
/// ki haalat, no-show warnings ki ginti, aur Logout (dobara
/// booking par OTP lazmi)।
class _PassengerEmailCard extends StatefulWidget {
  final AppStore store;
  const _PassengerEmailCard({required this.store});

  @override
  State<_PassengerEmailCard> createState() => _PassengerEmailCardState();
}

class _PassengerEmailCardState extends State<_PassengerEmailCard> {
  late final _emailCtrl =
      TextEditingController(text: widget.store.passengerEmail);

  AppStore get store => widget.store;

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.mark_email_read, color: Brand.green),
                SizedBox(width: 9),
                Text('Gmail aur Meri Haalat',
                    style:
                        TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
              ],
            ),
            const SizedBox(height: 8),
            if (store.passengerEmailVerified)
              Row(
                children: [
                  const Icon(Icons.verified, color: Brand.green, size: 18),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Gmail verify hai: ${store.passengerEmail}',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              )
            else
              EmailOtpSection(
                emailCtrl: _emailCtrl,
                onVerified: (email) async {
                  await store.applyPassengerEmailVerified(email);
                  unawaited(Backend.syncPassengerSelf(store));
                  // v1.4.14: pehchan bandhna (identity_links)।
                  unawaited(Backend.linkIdentities(store));
                  if (mounted) setState(() {});
                },
              ),
            if (store.passengerWarnCount > 0) ...[
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: store.passengerNoShowBlocked
                      ? const Color(0xFFFDECEA)
                      : const Color(0xFFFFF6E0),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  store.passengerNoShowBlocked
                      ? 'No-show warnings: ${store.passengerWarnCount}/3 — aap ki booking BAND hai. Master se rabta karein: 0332 9467211'
                      : 'No-show warnings: ${store.passengerWarnCount}/3 — ride mangwa kar zaroor ayen; 3 warnings par booking band ho jayegi.',
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: store.passengerNoShowBlocked
                          ? Brand.ajrakRed
                          : const Color(0xFF8D6E00)),
                ),
              ),
            ],
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  await store.passengerLogout();
                  // v1.4.14: Auth session bhi saaf — dobara login
                  // OTP se naya session banayega (plan §8.1.1)।
                  unawaited(Backend.clearSession());
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text(
                          'Logout ho gaya — agli booking se pehle Email OTP dobara lazmi hoga.')));
                  setState(() {});
                },
                icon: const Icon(Icons.logout, size: 17),
                label: const Text('Logout'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Alag screen wala roop — Profile tab ke ilawa jahan se bhi
/// khule (purane darwaze), body wohi [PassengerProfileBody] hai.
class PassengerProfileScreen extends StatelessWidget {
  final AppStore store;
  const PassengerProfileScreen({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Meri Profile')),
      body: PassengerProfileBody(
        store: store,
        onAfterDelete: () => Navigator.of(context).pop(),
      ),
    );
  }
}
