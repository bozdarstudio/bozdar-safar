import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart' as ll2;
import 'store.dart';
import 'theme.dart';
import 'safar_map.dart';
import 'backend.dart';
import 'registration.dart';
import 'messages.dart';
import 'main.dart' show ModeToggleButton, UpdateBanner;
import 'passenger.dart' show kStatusUrdu;

class DriverSide extends StatefulWidget {
  final AppStore store;
  final VoidCallback onSwitchToPassenger;
  const DriverSide(
      {super.key, required this.store, required this.onSwitchToPassenger});

  @override
  State<DriverSide> createState() => _DriverSideState();
}

class _DriverSideState extends State<DriverSide> {
  int _tab = 0; // 0 Home | 1 Bookings | 2 Wallet | 3 Profile
  final ImagePicker _picker = ImagePicker();

  // Driver ki apni mojooda jagah — har ride ki pickup-doori ginne aur
  // 2 km radius filter (kDriverPickupRadiusKm) ke liye. Best-effort hai:
  // ijazat/location na mile to _myPos null rehta hai aur us surat mein
  // filter NAHI lagta (saari rides dikhti hain, doori wali line par
  // "location off hai" likha aata hai) — pilot band nahi hota.
  ll2.LatLng? _myPos;
  bool _locBusy = false;

  /// Registration wizard is app session mein khud khula ya nahi —
  /// dobara dobara khud nahi khulta (Home/Profile par us ka card
  /// button hamesha maujood hai).
  bool _wizardPrompted = false;

  AppStore get store => widget.store;
  DriverProfile get p => store.profile;

  @override
  void initState() {
    super.initState();
    _refreshMyLocation();
    // Registration baqi ho to Driver Mode mein ate hi Yango-style
    // registration form khud khul jata hai (ek dafa, is session mein).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // HOTFIX v1.2.9 (RC2): gate ab registrationComplete par hai —
      // legacy profile (sirf naam+mobile, photos nahi) bhi wizard
      // mein jayega taaki baqi documents jama ho jayen.
      if (mounted && !p.registrationComplete && !_wizardPrompted) {
        _wizardPrompted = true;
        _openRegistration();
      }
    });
  }

  /// Registration wizard (v1.2.6) full-screen kholna — Home aur
  /// Profile dono ke registration card yahin ate hain.
  Future<void> _openRegistration() async {
    await Navigator.of(context).push(
      MaterialPageRoute<bool>(
        builder: (_) => RegistrationWizard(store: store),
      ),
    );
    if (!mounted) return;
    // Wizard naam/mobile/plate badal sakta hai — Profile ke purane
    // controllers un par dobara na likh dein, is liye wapsi par
    // controllers ko profile se taaza kar dete hain.
    _nameCtrl.text = p.name;
    _phoneCtrl.text = p.phone;
    _plateCtrl.text = p.plate;
    setState(() {});
  }

  /// Master ko Message screen (v1.2.7) — Profile se khulti hai.
  Future<void> _openMessages() async {
    await Navigator.of(context).push(
      MaterialPageRoute<bool>(
        builder: (_) => MasterMessagesScreen(store: store, role: 'driver'),
      ),
    );
    if (mounted) setState(() {});
  }

  /// DriverNavView (safar_map.dart) wala hi tareeqa: pehle last known,
  /// phir ek dafa ki taaza position. Koi stream nahi — Bookings tab
  /// khulne par dobara refresh ho jata hai. Har nakami khamosh hai.
  Future<void> _refreshMyLocation() async {
    if (_locBusy) return;
    _locBusy = true;
    try {
      final service = await Geolocator.isLocationServiceEnabled();
      if (!service) return;
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        return;
      }
      final last = await Geolocator.getLastKnownPosition();
      if (last != null && mounted) {
        setState(
            () => _myPos = ll2.LatLng(last.latitude, last.longitude));
        // Store mein bhi darj — passenger ki "driver kitni door hai"
        // wali line aur backend drivers.lat/lng isi se chalte hain.
        store.setDriverPosition(last.latitude, last.longitude);
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      if (mounted) {
        setState(() => _myPos = ll2.LatLng(pos.latitude, pos.longitude));
        store.setDriverPosition(pos.latitude, pos.longitude);
      }
    } catch (_) {
      // Khamosh — position na mile to filter nahi lagta.
    } finally {
      _locBusy = false;
    }
  }

  /// Booking ki pickup tak ki doori (km) driver ki apni jagah se.
  /// null = hisaab nahi ho sakta — ya driver ki position maloom nahi,
  /// ya booking ke paas pickup pin/coords hi nahi (0,0).
  double? _pickupDistanceKm(Booking b) {
    final pos = _myPos;
    if (pos == null) return null;
    if (b.pickupLat == 0 && b.pickupLng == 0) return null;
    return const ll2.Distance().as(ll2.LengthUnit.Kilometer, pos,
        ll2.LatLng(b.pickupLat, b.pickupLng));
  }

  /// 2 km radius filter: doori gin sake aur radius se zyada ho to ride
  /// is driver ko nahi dikhti. Doori na gin sake (location off ya pin
  /// nahi) to ride hamesha dikhti hai — chhupati kabhi nahi.
  bool _inRadius(Booking b) {
    final d = _pickupDistanceKm(b);
    if (d == null) return true;
    return d <= kDriverPickupRadiusKm;
  }

  /// "Sawari kitni door hai" wali line — incoming aur active dono
  /// cards par. Location off ho to wohi saaf likha aata hai; pickup
  /// pin na ho to sirf pickup ka label/ilaqa dikhta hai.
  Widget _pickupDistanceLine(Booking b) {
    final String text;
    if (_myPos == null) {
      text = 'Sawari ki doori: location off hai';
    } else {
      final d = _pickupDistanceKm(b);
      text = d == null
          ? 'Sawari: ${b.pickupLabel}'
          : 'Sawari: ${d.toStringAsFixed(1)} km door';
    }
    return Row(
      children: [
        const Icon(Icons.near_me, size: 17, color: Brand.green),
        const SizedBox(width: 6),
        Expanded(
          child: Text(text,
              style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: Brand.greenDark)),
        ),
      ],
    );
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  /// Duty on/off (v1.2.5 — malik ka hukm). Offline karna hamesha
  /// seedha hai. Online (duty) hone se pehle do darwaze hain:
  ///  1) PASSWORD: set na ho to pehle SET karna lazmi hai (backend
  ///     uniqueness check ke saath — ek password sirf ek driver ka);
  ///     set ho to is session mein ek dafa likhna lazmi hai; 5 ghalat
  ///     koshishon par 10 minute ka lockout.
  ///  2) ROZANA LIVE SELFIE: aaj ki selfie na ho to camera wahi
  ///     khulta hai — selfie ke baghair duty shuru nahi hoti.
  /// Dono pass hon tab hi online hota hai.
  Future<void> _toggleOnline() async {
    if (p.online) {
      p.online = false;
      await store.save();
      if (mounted) setState(() {});
      return;
    }
    // Lockout chalu ho to password ka darwaza hi band hai.
    if (p.pwdFp.isNotEmpty && p.pwdLocked) {
      final mins =
          ((p.pwdLockUntilMs - DateTime.now().millisecondsSinceEpoch) /
                  60000)
              .ceil();
      _snack(
          'Zyada ghalat koshishen — kuch der baad koshish karein (abhi $mins minute baqi hain).');
      return;
    }
    if (p.pwdFp.isEmpty) {
      final ok = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _SetPasswordDialog(store: store),
      );
      if (ok != true || !mounted) return;
      // RC2 follow-through (v1.2.9): naya password isi waqt backend
      // drivers row par bhi darj ho jaye taaki row phone se peeche
      // na reh jaye. Registration mukammal ho chuki ho to ensure
      // row ka bhi dobara jaiza — warna sirf fingerprint ki PATCH;
      // dono best-effort aur khamosh (duty flow nahi rukta).
      if (p.registrationComplete) {
        unawaited(Backend.ensureDriverRow(store));
      } else {
        unawaited(Backend.pushDriverFingerprint(store));
      }
    } else if (!store.dutyUnlocked) {
      final ok = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _AskPasswordDialog(store: store),
      );
      if (!mounted) return;
      if (ok != true) {
        if (p.pwdLocked) {
          _snack('Zyada ghalat koshishen — kuch der baad koshish karein.');
        }
        return;
      }
    }
    if (!p.selfieToday) {
      final take = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Pehle aaj ki selfie'),
          content: const Text(
              'Duty shuru karne se pehle aaj ki LIVE selfie lazmi hai — camera se hi hogi, gallery se nahi.'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Rehne Dein')),
            ElevatedButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Selfie Lein')),
          ],
        ),
      );
      if (take != true || !mounted) return;
      await _takeSelfie();
      if (!mounted) return;
      // Camera band karke wapas a gaya to selfie nahi bani — duty
      // shuru nahi hogi (HOTFIX v1.2.9: ab wajah bhi batayi jati
      // hai — pehle khamoshi se wapas ho jata tha).
      if (!p.selfieToday) {
        _snack(
            'Selfie ke baghair duty shuru nahi ho sakti — pehle aaj ki selfie lein.');
        return;
      }
    }
    p.online = true;
    await store.save();
    if (mounted) setState(() {});
  }

  Future<void> _changePassword() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => _ChangePasswordDialog(store: store),
    );
    if (ok == true && mounted) {
      _snack('Password badal gaya.');
      setState(() {});
    }
  }

  Future<void> _takeSelfie() async {
    try {
      // LIVE selfie — camera ONLY. No gallery option anywhere, by design.
      final XFile? img =
          await _picker.pickImage(source: ImageSource.camera);
      if (img == null) {
        // HOTFIX v1.2.9 (RC3): camera band karne / permission na
        // milne par khamoshi se wapas NAHI — wajah batao, warna
        // driver samajhta hai selfie wala option khulta hi nahi.
        if (mounted) {
          _snack(
              'Selfie nahi li gayi — camera band ho gaya ya permission nahi mili. Dobara koshish karein.');
        }
        return;
      }
      await store.setSelfie(img.path);
      if (mounted) _snack('Aaj ki selfie ho gayi — ab ride qubool ho sakti hai.');
    } catch (_) {
      if (mounted) _snack('Camera nahi khul saka.');
    }
  }

  int _todayNetEarnings() {
    final now = DateTime.now();
    var sum = 0;
    for (final b in store.bookings) {
      final c = b.completedAt;
      if (b.status == 'completed' &&
          c != null &&
          c.year == now.year &&
          c.month == now.month &&
          c.day == now.day) {
        sum += b.total - Fares.serviceFee(b.fare + b.waitingCharge);
      }
    }
    return sum;
  }

  @override
  Widget build(BuildContext context) {
    final incoming = store.bookings
        .where((b) => b.status == 'pending' && _inRadius(b))
        .length;
    return Scaffold(
      body: Column(
        children: [
          const BrandHeader(sideLabel: 'DRIVER APP · KARACHI'),
          if (store.updateAvailable && !store.updateDismissed)
            UpdateBanner(store: store),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
            child: ModeToggleButton(
                toDriver: false, onTap: widget.onSwitchToPassenger),
          ),
          // Malik ki driver mode artwork (brand board — rickshaw driver)
          // header + toggle ke foran neeche.
          const ModeBanner(asset: 'assets/mode-driver.png'),
          Expanded(
            child: _tab == 0
                ? _homeView()
                : _tab == 1
                    ? _bookingsView()
                    : _tab == 2
                        ? _walletView()
                        : _profileView(),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) {
          setState(() => _tab = i);
          // Bookings par aate hi position taaza — doori/filter taaza rahe.
          if (i == 1) _refreshMyLocation();
        },
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Brand.green,
        items: [
          const BottomNavigationBarItem(
              icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
            icon: Badge(
              label: Text('$incoming'),
              isLabelVisible: incoming > 0,
              child: const Icon(Icons.notifications_active),
            ),
            label: 'Bookings',
          ),
          const BottomNavigationBarItem(
              icon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          const BottomNavigationBarItem(
              icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  // --- HOME: big online/offline state ---------------------------------------

  Widget _homeView() {
    final online = p.online;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        // Registration baqi ho to sab se pehle us ka card — Yango-style
        // form yahin se khulta hai (v1.2.6). Gate ab
        // registrationComplete par hai (HOTFIX v1.2.9, RC2).
        if (!p.registrationComplete) ...[
          Card(
            color: Brand.deepGreen,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.app_registration,
                          color: Brand.gold, size: 26),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text('Registration baqi hai',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w900)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Driver banne ke liye registration form mukammal karein — mobile, CNIC, password, gaari aur selfie, qadam ba qadam.',
                    style: TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _openRegistration,
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Brand.gold,
                          foregroundColor: Brand.greenDark),
                      child: const Text('Registration Mukammal Karein'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],
        // BIG state card — inDrive style
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: online ? Brand.green : const Color(0xFF5A5A5A),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Brand.gold, width: 2),
          ),
          child: Column(
            children: [
              Icon(online ? Icons.check_circle : Icons.do_not_disturb_on,
                  color: Colors.white, size: 44),
              const SizedBox(height: 6),
              Text(online ? 'Aap ONLINE hain' : 'Aap OFFLINE hain',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w900)),
              Text(
                online
                    ? 'Ride requests aa sakti hain'
                    : 'Online honay par ride requests ayengi',
                style: const TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _toggleOnline,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: online ? Colors.white : Brand.gold,
                    foregroundColor:
                        online ? Brand.green : Brand.greenDark,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: Text(online ? 'Offline Ho Jayein' : 'Online Ho Jayein',
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        // inDrive D1 language: status ke foran baad aaj ki kamai +
        // wallet balance ki jhalak (top cards), phir profile/gates.
        Row(
          children: [
            Expanded(
              child: _statCard('Aaj ki kamai', rs(_todayNetEarnings()),
                  Icons.trending_up),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _statCard(
                  'Wallet balance', rs(p.walletBalance), Icons.wallet),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: Brand.deepGreen,
                  child: Text(
                    p.name.isNotEmpty ? p.name[0] : 'R',
                    style: const TextStyle(
                        color: Brand.gold,
                        fontSize: 22,
                        fontWeight: FontWeight.w900),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.name,
                          style: const TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w800)),
                      Text(
                          '${p.vehicle}${p.plate.isEmpty ? '' : ' · ${p.plate}'} · ${p.zone}'),
                      Text('Karachi Driver',
                          style: TextStyle(
                              fontSize: 12, color: Colors.grey.shade600)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 6),
        _gateRow(
          icon: Icons.payments,
          label: 'Joining Deposit (Rs ${Fares.joiningDeposit})',
          done: p.depositDone,
          doneText: 'Ho gaya',
          pendingText:
              'Baqi — ${rs(Fares.joiningDeposit - p.totalDeposited)} aur chahiye',
          // 'Wallet' wala alag button hata diya (v1.2.6 faltu-button
          // safai) — Wallet neeche wale tab se hi khulta hai.
          onFix: null,
          fixLabel: '',
        ),
        _gateRow(
          icon: Icons.camera_alt,
          label: 'Aaj ki Live Selfie',
          done: p.selfieToday,
          doneText: 'Ho gayi',
          pendingText: 'Baqi — baghair selfie ride qubool nahi hogi',
          onFix: p.selfieToday ? null : _takeSelfie,
          fixLabel: 'Selfie Lein',
        ),
        _gateRow(
          icon: Icons.badge,
          label: 'CNIC Tasdeeq',
          // HOTFIX v1.2.9 (RC1): tasdeeq ki haalat ab sirf MASTER ke
          // pull shuda verdict se ati hai — local self-attestation
          // (cnicStatus) yahan kabhi istemal nahi hoti.
          done: p.masterCnicStatus == 'verified',
          doneText: 'Master ne Tasdeeq kar di',
          pendingText: p.masterCnicStatus == 'rejected'
              ? 'Reject ho gaya — sahi kagaz dobara dein'
              : 'Tasdeeq baqi hai',
          // Registration baqi ho to ye button registration form mein
          // le jata hai (CNIC wahan jama hota hai). Registration ke
          // baad 'Profile' wala duplicate button nahi — Profile
          // neeche wale tab se khulta hai (v1.2.6 safai).
          onFix: p.registrationComplete ? null : _openRegistration,
          fixLabel: 'Registration',
        ),
        const SizedBox(height: 10),
        if (p.selfiePath.isNotEmpty && p.selfieToday)
          Card(
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(File(p.selfiePath),
                    width: 46, height: 46, fit: BoxFit.cover),
              ),
              title: const Text('Aaj ki selfie'),
              subtitle: Text('Tareekh: ${p.selfieDate}'),
            ),
          ),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text(
              'Usool: Kiraya pehle se pakka hai — koi mol-bhav nahi. Service charges sirf ${fmtPct(Fares.feePercent)} (kiraya + waiting par). Wallet kabhi minus nahi jata. Pehle 5 minute intezaar muft, phir gaari ke hisab se waiting charges.',
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ),
      ],
    );
  }

  Widget _statCard(String label, String value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Icon(icon, color: Brand.gold, size: 26),
            const SizedBox(height: 6),
            Text(value,
                style: const TextStyle(
                    fontSize: 19, fontWeight: FontWeight.w900)),
            Text(label,
                style: const TextStyle(fontSize: 12, color: Colors.black54)),
          ],
        ),
      ),
    );
  }

  Widget _gateRow({
    required IconData icon,
    required String label,
    required bool done,
    required String doneText,
    required String pendingText,
    required VoidCallback? onFix,
    required String fixLabel,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: done ? Brand.green : Brand.ajrakRed),
        title: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(done ? doneText : pendingText),
        // onFix null ho to koi button NAHI — sirf pending ka nishan
        // (faltu navigation buttons v1.2.6 mein hata diye gaye hain;
        // Wallet/Profile neeche wale tabs se hi khulte hain).
        trailing: done
            ? const Icon(Icons.check_circle, color: Brand.green)
            : onFix != null
                ? TextButton(onPressed: onFix, child: Text(fixLabel))
                : const Icon(Icons.pending_actions,
                    color: Brand.ajrakRed),
      ),
    );
  }

  // --- BOOKINGS: large incoming request cards --------------------------------

  Widget _bookingsView() {
    // 2 km RADIUS FILTER yahin lagta hai — list ki satah par. Is se
    // door ki pending rides is driver ki list mein aati hi nahi;
    // booking khud kahin change/delete nahi hoti (doosra qareeb
    // driver use dekh sakta hai). Location maloom na ho to _inRadius
    // sab ko pass kar deta hai.
    final incoming = store.bookings
        .where((b) => b.status == 'pending' && _inRadius(b))
        .toList();
    final active = store.bookings
        .where((b) => b.status == 'accepted' || b.status == 'arrived')
        .toList();
    final past = store.bookings
        .where((b) =>
            b.status == 'completed' ||
            b.status == 'noshow' ||
            b.status == 'cancelled')
        .toList();
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('Aane wali bookings',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        Text(
          _myPos == null
              ? 'Location off hai — saari rides dikh rahi hain'
              : 'Sirf ${kDriverPickupRadiusKm.toStringAsFixed(0)} km ke andar ki rides dikh rahi hain',
          style: const TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 8),
        if (incoming.isEmpty)
          const Text('Abhi koi nayi booking nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...incoming.map(_incomingCard),
        const SizedBox(height: 16),
        const Text('Chal rahi rides',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (active.isEmpty)
          const Text('Koi ride chal nahi rahi.',
              style: TextStyle(color: Colors.black54)),
        ...active.map(_activeCard),
        const SizedBox(height: 16),
        const Text('Purani rides',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (past.isEmpty)
          const Text('Abhi koi purani ride nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...past.map((b) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: const Icon(Icons.history, color: Brand.green),
                title: Text('${b.pickupLabel} → ${b.dropLabel}'),
                subtitle: Text(
                    '${kStatusUrdu[b.status] ?? b.status} · ${fmtDate(b.completedAt ?? b.createdAt)} · ${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm} km'),
                trailing: Text(rs(b.total),
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
            )),
      ],
    );
  }

  Widget _routeLines(Booking b) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          const Icon(Icons.circle, color: Brand.green, size: 14),
          const SizedBox(width: 8),
          Expanded(
              child: Text('Pickup: ${b.pickupLabel}',
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700))),
        ]),
        const Padding(
          padding: EdgeInsets.only(left: 6),
          child: Icon(Icons.more_vert, size: 16, color: Colors.grey),
        ),
        Row(children: [
          const Icon(Icons.location_on, color: Brand.ajrakRed, size: 16),
          const SizedBox(width: 8),
          Expanded(
              child: Text('Drop: ${b.dropLabel}',
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700))),
        ]),
      ],
    );
  }

  Widget _incomingCard(Booking b) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: Brand.gold, width: 2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Chip(
                  label: Text('NAYI BOOKING'),
                  backgroundColor: Brand.goldLight,
                  labelStyle:
                      TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
                ),
                const Spacer(),
                Text(fmtTime(b.createdAt),
                    style: const TextStyle(color: Colors.black54)),
              ],
            ),
            const SizedBox(height: 8),
            Text(b.passengerName,
                style:
                    const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            if (b.passengerPhone.isNotEmpty)
              Text(b.passengerPhone,
                  style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 8),
            // Sawari yahan se kitni door khari hai — driver ki apni
            // mojooda jagah se pickup tak ki doori.
            _pickupDistanceLine(b),
            const SizedBox(height: 10),
            _routeLines(b),
            if (b.note.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('Note: ${b.note}',
                  style: const TextStyle(
                      fontSize: 13, fontStyle: FontStyle.italic)),
            ],
            if (b.hasDropPin) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  height: 180,
                  child: SafarRouteMap(
                    pickup: ll2.LatLng(b.pickupLat, b.pickupLng),
                    drop: ll2.LatLng(b.dropLat, b.dropLng),
                    interactive: false,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                Chip(
                  avatar: const Icon(Icons.route, size: 16),
                  label: Text(
                      '${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm} km · ${b.vehicle}'),
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('KUL KIRAYA',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Colors.black54)),
                    Text(rs(b.fare),
                        style: const TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w900)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _accept(b),
                    style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                    child:
                        const Text('Qubool Karein', style: TextStyle(fontSize: 16)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () async {
                      await store.cancelBooking(b);
                      if (mounted) _snack('Booking rehne di gayi.');
                      setState(() {});
                    },
                    style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                    child:
                        const Text('Rehne Dein', style: TextStyle(fontSize: 16)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _accept(Booking b) async {
    final reason = store.acceptBlockReason();
    if (reason != null) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Ride qubool nahi ho sakti'),
          content: Text(reason),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Theek hai')),
          ],
        ),
      );
      return;
    }
    await store.acceptBooking(b);
    // Qubool karte hi taaza position — passenger ko foran sahi
    // doori/ETA nazar aye (refresh khud store mein bhi darj karta hai).
    unawaited(_refreshMyLocation());
    if (mounted) {
      _snack('Booking qubool ho gayi.');
      setState(() {});
    }
  }

  /// Navigation (DriverNavView) ki GPS stream se ane wali position —
  /// store mein sirf tab darj hoti hai jab driver aakhri darj jagah
  /// se kam az kam ~50 m aage barh gaya ho, taaki har GPS tick par
  /// persist/backend-push na chale. Passenger ki doori/ETA line isi
  /// taaza position se khud taza ho jati hai.
  void _onNavPosition(ll2.LatLng pos) {
    final lat = p.lastLat;
    final lng = p.lastLng;
    if (lat != null && lng != null) {
      final moved = const ll2.Distance().as(ll2.LengthUnit.Meter,
          ll2.LatLng(lat, lng), pos);
      if (moved < 50) return;
    }
    store.setDriverPosition(pos.latitude, pos.longitude);
  }

  Widget _activeCard(Booking b) {
    final arrived = b.status == 'arrived';
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(b.passengerName,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w900)),
                const Spacer(),
                Chip(
                  label: Text(arrived ? 'Pohanch gaye' : 'Qubool shuda'),
                  backgroundColor:
                      arrived ? const Color(0xFFF3E9C8) : const Color(0xFFDFF5E6),
                  labelStyle: const TextStyle(fontSize: 11),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _routeLines(b),
            if (!arrived) ...[
              const SizedBox(height: 8),
              // Pickup tak kitni doori baqi hai — aakhri maloom
              // position se (nav chale to wahin se taaza hoti rehti
              // hai; yahan alag stream nahi chalaya gaya).
              _pickupDistanceLine(b),
            ],
            const SizedBox(height: 8),
            if (b.hasDropPin) ...[
              DriverNavView(booking: b, onPosition: _onNavPosition),
              const SizedBox(height: 10),
            ],
            Text(
                'Kiraya: ${rs(b.fare)} · ${b.vehicle} · ${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm} km'),
            if (!arrived) ...[
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () async {
                    await store.markArrived(b);
                    if (mounted) {
                      _snack(
                          'Waiting timer shuru — pehle ${Fares.freeWaitingMinutes} minute muft hain.');
                      setState(() {});
                    }
                  },
                  icon: const Icon(Icons.location_on),
                  label: const Text('Pohanch Gaya'),
                ),
              ),
            ] else ...[
              const SizedBox(height: 10),
              _LiveWaiting(booking: b, store: store),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => _complete(b),
                  icon: const Icon(Icons.flag),
                  label: const Text('Ride Mukammal Karein'),
                  style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14)),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => _noShow(b),
                  icon: const Icon(Icons.person_off),
                  label: const Text('Sawari Nahi Aayi (No-show)'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _complete(Booking b) async {
    final err = await store.completeBooking(b);
    if (!mounted) return;
    if (err != null) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Ride mukammal nahi ho sakti'),
          content: Text(err),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Theek hai')),
          ],
        ),
      );
    } else {
      _snack(
          'Ride mukammal — kiraya ${rs(b.fare)} + waiting ${rs(b.waitingCharge)}; ${fmtPct(Fares.feePercent)} service charges wallet se kat gaya.');
    }
    setState(() {});
  }

  Future<void> _noShow(Booking b) async {
    final err = await store.markNoShow(b);
    if (!mounted) return;
    _snack(err ??
        'No-show darj ho gaya — waiting charges ${rs(b.waitingCharge)} record mein hain.');
    setState(() {});
  }

  // --- WALLET -----------------------------------------------------------------

  final _depositCtrl = TextEditingController();
  String _depositMethod = 'Cash';

  @override
  void dispose() {
    _depositCtrl.dispose();
    _pwdCtrl.dispose();
    _pwd2Ctrl.dispose();
    super.dispose();
  }

  Widget _walletView() {
    final remaining = Fares.joiningDeposit - p.totalDeposited;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Brand.deepGreen,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Brand.gold, width: 2),
          ),
          child: Column(
            children: [
              const Text('WALLET BALANCE',
                  style: TextStyle(
                      color: Brand.goldLight,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2)),
              Text(rs(p.walletBalance),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.w900)),
              Text(
                p.depositDone
                    ? 'Joining deposit mukammal hai'
                    : 'Joining deposit baqi: ${rs(remaining > 0 ? remaining : 0)} aur chahiye',
                style: const TextStyle(color: Brand.cream, fontSize: 12),
              ),
              const SizedBox(height: 6),
              const Text(
                'Wallet kabhi minus nahi jata — fee sirf balance se kat ti hai.',
                style: TextStyle(color: Colors.white60, fontSize: 11),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        const Text('Deposit Darj Karein',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        TextField(
          controller: _depositCtrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
              labelText: 'Raqam (Rs)', prefixIcon: Icon(Icons.payments)),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            const Text('Tareeqa: ',
                style: TextStyle(fontWeight: FontWeight.w700)),
            ChoiceChip(
              label: const Text('Cash'),
              selected: _depositMethod == 'Cash',
              onSelected: (_) => setState(() => _depositMethod = 'Cash'),
            ),
            ChoiceChip(
              label: const Text('Raast'),
              selected: _depositMethod == 'Raast',
              onSelected: (_) => setState(() => _depositMethod = 'Raast'),
            ),
            ChoiceChip(
              label: const Text('Easypaisa'),
              selected: _depositMethod == 'Easypaisa',
              onSelected: (_) => setState(() => _depositMethod = 'Easypaisa'),
            ),
            ChoiceChip(
              label: const Text('JazzCash'),
              selected: _depositMethod == 'JazzCash',
              onSelected: (_) => setState(() => _depositMethod = 'JazzCash'),
            ),
          ],
        ),
        if (_depositMethod == 'Easypaisa' ||
            _depositMethod == 'JazzCash') ...[
          const SizedBox(height: 8),
          Text(
            'Pehle apne $_depositMethod app se Safar ke official number 0312 2635002 par raqam bhejein, phir yahan darj karein.',
            style: const TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () async {
              final amt = int.tryParse(_depositCtrl.text.trim()) ?? 0;
              if (amt <= 0) {
                _snack('Durust raqam likhein.');
                return;
              }
              await store.addDeposit(amt, _depositMethod);
              _depositCtrl.clear();
              if (mounted) {
                _snack('Deposit ${rs(amt)} darj ho gaya.');
                setState(() {});
              }
            },
            child: const Text('Deposit Jama Karein'),
          ),
        ),
        const SizedBox(height: 20),
        const Text('Monthly Packages',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.monthlyPackages.isEmpty)
          const Text('Abhi koi monthly package nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...store.monthlyPackages.map((mp) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading:
                    const Icon(Icons.calendar_month, color: Brand.green),
                title: Text('${mp.pickup} → ${mp.drop}'),
                subtitle: Text(
                    '${mp.passengerName.isEmpty ? 'Sawari' : mp.passengerName} · ${mp.vehicle} · ${mp.days} din'),
                trailing: Text(rs(mp.monthlyAmount),
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            )),
        const SizedBox(height: 20),
        const Text('Hisab Kitab (Ledger)',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.txns.isEmpty)
          const Text('Abhi koi entry nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...store.txns.map((t) {
          final isDeposit = t.type == 'deposit';
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Icon(
                isDeposit ? Icons.arrow_downward : Icons.percent,
                color: isDeposit ? Brand.green : Brand.ajrakRed,
              ),
              title: Text(isDeposit
                  ? 'Deposit — ${t.method}'
                  : 'Service charges ${fmtPct(Fares.feePercent)}'),
              subtitle: Text('${t.note}\n${fmtDate(t.date)} ${fmtTime(t.date)}'),
              isThreeLine: true,
              trailing: Text(
                isDeposit ? '+ ${rs(t.amount)}' : '− ${rs(t.amount)}',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: isDeposit ? Brand.green : Brand.ajrakRed,
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  // --- PROFILE -----------------------------------------------------------------

  late final TextEditingController _nameCtrl =
      TextEditingController(text: p.name);
  late final TextEditingController _phoneCtrl =
      TextEditingController(text: p.phone);
  late final TextEditingController _plateCtrl =
      TextEditingController(text: p.plate);
  // Registration par password lagane ke fields (sirf tab dikhte hain
  // jab password abhi set na ho) — v1.2.5.
  late final TextEditingController _pwdCtrl = TextEditingController();
  late final TextEditingController _pwd2Ctrl = TextEditingController();

  Widget _profileView() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('Driver Profile',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        // Master tasdeeq ki haalat — backend drivers.active se ati hai.
        // Profile Save = registration (pending); Master ACTIVE kare to
        // ye card badal jata hai. Refresh se foran nayi haalat pull.
        Card(
          color: p.masterActive ? Brand.deepGreen : null,
          child: ListTile(
            leading: Icon(
              p.masterActive ? Icons.verified : Icons.pending_actions,
              color: p.masterActive ? Brand.gold : Brand.ajrakRed,
            ),
            title: Text(
              p.masterActive
                  ? 'Account ACTIVE hai'
                  : 'Account PENDING hai',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                color: p.masterActive ? Colors.white : null,
              ),
            ),
            subtitle: Text(
              p.masterActive
                  ? 'Master ne tasdeeq kar di hai — aap ka account online system mein active hai.'
                  : 'Registration form mukammal karein — Master ki tasdeeq ke baad account active hoga.',
              style: TextStyle(
                color: p.masterActive ? Colors.white70 : null,
              ),
            ),
            trailing: IconButton(
              icon: Icon(Icons.refresh,
                  color: p.masterActive ? Brand.gold : Brand.green),
              tooltip: 'Status refresh karein',
              onPressed: () async {
                await Backend.refreshDriverStatus(store);
                if (mounted) setState(() {});
              },
            ),
          ),
        ),
        const SizedBox(height: 10),
        // Registration (v1.2.6): pehli registration Yango-style wizard
        // se hoti hai — Profile mein us ka darwaza hai, doosri
        // competing form NAHI. Mukammal ho to tafseel yahin se dobara
        // khol kar badli ja sakti hai.
        Card(
          // HOTFIX v1.2.9 (RC2): card ki haalat registrationComplete
          // par — flag laga ho lekin photos baqi hon to card
          // "tasaveer baqi hain" wali soorat mein dikhta hai.
          color: p.registrationComplete ? null : Brand.deepGreen,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.app_registration,
                        color:
                            p.registrationComplete ? Brand.green : Brand.gold),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        p.registrationComplete
                            ? 'Registration mukammal hai'
                            : (p.registrationDone
                                ? 'Registration ki tasaveer baqi hain'
                                : 'Registration baqi hai'),
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                          color: p.registrationComplete ? null : Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  p.registrationComplete
                      ? 'CNIC, gaari, licence aur selfie ki tafseel form mein darj hai.'
                      : (p.registrationDone
                          ? 'Form pehle bhara gaya tha lekin CNIC, gaari aur selfie ki tasaveer baqi hain — form khol kar sirf wohi jama karein, baqi tafseel bhari hui milegi.'
                          : 'Mobile, CNIC, password, gaari aur selfie — qadam ba qadam form bharein.'),
                  style: TextStyle(
                    fontSize: 12,
                    color: p.registrationComplete
                        ? Colors.black54
                        : Colors.white70,
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _openRegistration,
                    style: p.registrationComplete
                        ? null
                        : ElevatedButton.styleFrom(
                            backgroundColor: Brand.gold,
                            foregroundColor: Brand.greenDark),
                    child: Text(p.registrationComplete
                        ? 'Tafseel Dekhein / Badlein'
                        : 'Registration Mukammal Karein'),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        // Master ko Message (v1.2.7): masla/shikayat seedha Master
        // (head) ko — Profile tab se hi darwaza hai.
        Card(
          child: ListTile(
            leading: const Icon(Icons.mail_outline, color: Brand.green),
            title: const Text('Master ko Message Bhejein',
                style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text(
                'Koi masla ya shikayat ho to seedha Master (head) ko message bhejein — jawab ki haalat wahin nazar ayegi.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _openMessages,
          ),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _nameCtrl,
          decoration: const InputDecoration(
              labelText: 'Driver ka naam', prefixIcon: Icon(Icons.person)),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _phoneCtrl,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
              labelText: 'Mobile number (call/WhatsApp ke liye)',
              prefixIcon: Icon(Icons.phone)),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _plateCtrl,
          decoration: const InputDecoration(
              labelText: 'Gaari ka number plate',
              prefixIcon: Icon(Icons.pin)),
        ),
        const SizedBox(height: 10),
        const Text('Gaari', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: kVehicles
              .map((v) => ChoiceChip(
                    label: Text(v),
                    selected: p.vehicle == v,
                    onSelected: (_) => setState(() => p.vehicle = v),
                  ))
              .toList(),
        ),
        const SizedBox(height: 10),
        const Text('Ilaqa (Zone)',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          value: kZones.contains(p.zone) ? p.zone : 'Karachi',
          items: kZones
              .map((z) => DropdownMenuItem(value: z, child: Text(z)))
              .toList(),
          onChanged: (v) => setState(() => p.zone = v ?? p.zone),
          decoration: const InputDecoration(labelText: 'Zone'),
        ),
        const SizedBox(height: 18),
        const Text('Documents ki Tasdeeq',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        // HOTFIX v1.2.9 (RC1): tasdeeq SIRF Master karta hai. Driver
        // ki apni self-attestation wale ChoiceChips (jo khud ko
        // 'verified' kar dete thay) HATA diye gaye hain — har row ab
        // sirf Master ka pull shuda faisla dikhati hai, aur photo
        // baqi ho ya Master ne reject kiya ho to row se seedha
        // registration form khulta hai.
        const Text(
            'CNIC lazmi hai. Licence ikhtiyari hai — na ho to koi baat nahi. Har document ki tasdeeq sirf Master karta hai.',
            style: TextStyle(fontSize: 12, color: Colors.black54)),
        const SizedBox(height: 10),
        _masterDocRow(
          'CNIC',
          p.masterCnicStatus,
          photoMissing: p.cnicFrontPath.isEmpty || p.cnicBackPath.isEmpty,
        ),
        _masterDocRow(
          'Gaari ke kagazat (Registration)',
          p.masterGaariStatus,
          photoMissing: p.vehicleRegPath.isEmpty,
        ),
        const SizedBox(height: 10),
        const Text('Driving Licence',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        // Licence hai/nahi — ye registration DATA hai, tasdeeq nahi;
        // ab sirf wizard mein badalta hai, yahan sirf maloomat.
        Text(
          p.licenceStatus == 'has'
              ? 'Licence hai${p.licenceNumber.isNotEmpty ? ' — ${p.licenceNumber}' : ''} (badalna ho to registration form se)'
              : 'Licence nahi hai — CNIC se kaam chal jayega. (Badalna ho to registration form se.)',
          style: const TextStyle(fontSize: 13, color: Colors.black54),
        ),
        if (p.licenceStatus == 'has') ...[
          const SizedBox(height: 8),
          _masterDocRow(
            'Licence Tasdeeq',
            p.masterLicenceStatus,
            photoMissing: p.licencePhotoPath.isEmpty,
          ),
        ],
        if (p.masterCnicStatus == 'rejected' ||
            p.masterGaariStatus == 'rejected' ||
            p.masterLicenceStatus == 'rejected')
          const Padding(
            padding: EdgeInsets.only(top: 2),
            child: Text(
              'Ek document reject hua hai — sahi kagaz dobara dein ya Master ko message karein.',
              style: TextStyle(
                  fontSize: 12.5,
                  color: Brand.ajrakRed,
                  fontWeight: FontWeight.w600),
            ),
          ),
        const SizedBox(height: 18),
        Card(
          child: ListTile(
            leading: Icon(Icons.camera_alt,
                color: p.selfieToday ? Brand.green : Brand.ajrakRed),
            title: const Text('Rozana Live Selfie'),
            subtitle: Text(p.selfieToday
                ? 'Aaj ki selfie ho gayi (${p.selfieDate})'
                : 'Aaj ki selfie baqi hai — camera se hi hogi, gallery se nahi'),
            // Yahan wala 'Selfie Lein' button hata diya (v1.2.6 safai) —
            // wohi amal Home ke gate row aur duty-on par pehle se
            // hota hai; yahan sirf haalat dikhti hai.
            trailing: p.selfieToday
                ? const Icon(Icons.check_circle, color: Brand.green)
                : const Icon(Icons.pending_actions,
                    color: Brand.ajrakRed),
          ),
        ),
        const SizedBox(height: 14),
        // PASSWORD (v1.2.5 — malik ka hukm): har driver apna password
        // khud lagata hai; ek password sirf EK driver ka hota hai.
        // v1.2.6: registration baqi ho to password WIZARD ke qadam mein
        // lagta hai — yahan wale inline fields sirf un profiles ke
        // liye hain jin ki registration mukammal hai lekin password
        // abhi nahi laga (purane profiles), taaki do competing forms
        // na hon. Registration wale card (upar) se form khulta hai.
        if (p.pwdFp.isEmpty && !p.registrationComplete)
          const Card(
            child: ListTile(
              leading: Icon(Icons.lock_outline, color: Brand.ajrakRed),
              title: Text('Password baqi hai',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(
                  'Password registration form ke qadam mein lagayein — upar wale Registration card se form kholein.'),
            ),
          )
        else if (p.pwdFp.isEmpty) ...[
          const Text('Apna Password Lagayein',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          const Text(
            'Har driver apna password khud lagata hai. Ek password sirf ek hi driver ka hota hai — jo pehle lag jaye, wohi us ka ho jata hai. Duty shuru karne par yahi password manga jayega.',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _pwdCtrl,
            obscureText: true,
            decoration: const InputDecoration(
                labelText: 'Password (kam az kam 6 haroof)',
                prefixIcon: Icon(Icons.lock)),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _pwd2Ctrl,
            obscureText: true,
            decoration: const InputDecoration(
                labelText: 'Password dobara likhein',
                prefixIcon: Icon(Icons.lock_outline)),
          ),
        ] else
          Card(
            child: ListTile(
              leading: const Icon(Icons.lock, color: Brand.green),
              title: const Text('Password set hai',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text(
                  'Duty shuru karne par password manga jata hai — ek password sirf aap ka hai.'),
              trailing: TextButton(
                onPressed: _changePassword,
                child: const Text('Badlein'),
              ),
            ),
          ),
        // NOTE (v1.0.5): "Service Charges %" editor HATA diya gaya hai —
        // fee sirf Master app mein set hoti hai; is app mein woh khamosh
        // internal hissaab hai, koi option nahi.
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () async {
              // Naya password likha ho to PEHLE us ki jaanch hogi —
              // uniqueness fail ho to profile save NAHI hota
              // (registration nahi banti). Check ke liye internet
              // lazmi hai; check skip kabhi nahi hota.
              if (p.pwdFp.isEmpty && _pwdCtrl.text.isNotEmpty) {
                final pw = _pwdCtrl.text;
                if (pw.length < 6) {
                  _snack('Password kam az kam 6 haroof ka ho.');
                  return;
                }
                if (pw != _pwd2Ctrl.text) {
                  _snack('Dono password ek jaise nahi hain.');
                  return;
                }
                final taken = await Backend.passwordFingerprintTaken(
                    store, passwordFingerprint(pw));
                if (!mounted) return;
                if (taken == null) {
                  _snack(
                      'Password ki safety check ke liye internet chahiye — net on karke dobara Save karein.');
                  return;
                }
                if (taken) {
                  _pwdCtrl.clear();
                  _pwd2Ctrl.clear();
                  _snack(
                      'Ye password kisi aur ne lagaya hua hai, aap koi aur password lagayen');
                  return;
                }
                p.pwdFp = passwordFingerprint(pw);
                p.pwdFailCount = 0;
                p.pwdLockUntilMs = 0;
                _pwdCtrl.clear();
                _pwd2Ctrl.clear();
              }
              p.name = _nameCtrl.text.trim().isEmpty
                  ? p.name
                  : _nameCtrl.text.trim();
              p.phone = _phoneCtrl.text.trim();
              p.plate = _plateCtrl.text.trim();
              await store.save();
              if (mounted) {
                _snack('Profile save ho gaya.');
                setState(() {});
              }
            },
            child: const Text('Profile Save Karein'),
          ),
        ),
      ],
    );
  }

  /// Ek document ki row — HOTFIX v1.2.9 (RC1): sirf MASTER ka
  /// faisla dikhta hai (purani self-attestation wali _docRow aur
  /// "Master ki Tasdeeq" wali alag list isi mein zam ho gayi hain —
  /// woh ChoiceChips driver ko khud ko 'verified' karne dete thay,
  /// is liye hata diye gaye). Photo baqi ho ya Master ne reject
  /// kiya ho to row se registration form khulta hai.
  Widget _masterDocRow(String label, String status,
      {required bool photoMissing}) {
    final (text, color, icon) = switch (status) {
      'verified' => ('Master ne Tasdeeq kar di', Brand.green, Icons.verified),
      'rejected' => (
          'Reject ho gaya — sahi kagaz dobara dein',
          Brand.ajrakRed,
          Icons.cancel
        ),
      _ => ('Tasdeeq baqi hai', Brand.ajrakRed, Icons.pending_actions),
    };
    final needsFix = photoMissing || status == 'rejected';
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: color),
        title: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(
          photoMissing && status != 'rejected'
              ? 'Photo abhi baqi hai — tasdeeq ke liye photo lazmi hai'
              : text,
          style: TextStyle(color: color, fontWeight: FontWeight.w600),
        ),
        trailing: needsFix
            ? OutlinedButton(
                onPressed: _openRegistration,
                child: Text(status == 'rejected' ? 'Dobara Dein' : 'Kagaz Dein'),
              )
            : null,
      ),
    );
  }

}

/// Live waiting display for an arrived ride: minutes ticking + current charge.
class _LiveWaiting extends StatefulWidget {
  final Booking booking;
  final AppStore store;
  const _LiveWaiting({required this.booking, required this.store});

  @override
  State<_LiveWaiting> createState() => _LiveWaitingState();
}

class _LiveWaitingState extends State<_LiveWaiting> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final mins = widget.store.liveWaitingMinutes(b);
    final charge = widget.store.liveWaitingCharge(b);
    final freeLeft = Fares.freeWaitingMinutes - mins;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Brand.cream,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Brand.gold),
      ),
      child: Row(
        children: [
          const Icon(Icons.timer, color: Brand.ajrakRed),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Intezaar: $mins minute',
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 15)),
                Text(
                  freeLeft > 0
                      ? 'Abhi $freeLeft minute muft baqi hain'
                      : 'Waiting charges ab tak: ${rs(charge)}',
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
          if (charge > 0)
            Text(rs(charge),
                style:
                    const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Password dialogs (v1.2.5) — set / unlock / change.
// Teeno mein wohi usool: asal password sirf fingerprint banta hai;
// uniqueness backend se check hoti hai; check na ho sake (offline)
// to aage NAHI barhte.
// ---------------------------------------------------------------------------

/// Pehli dafa password SET karna (duty-on par, jab pwdFp khaali ho).
class _SetPasswordDialog extends StatefulWidget {
  final AppStore store;
  const _SetPasswordDialog({required this.store});

  @override
  State<_SetPasswordDialog> createState() => _SetPasswordDialogState();
}

class _SetPasswordDialogState extends State<_SetPasswordDialog> {
  final _c1 = TextEditingController();
  final _c2 = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _c1.dispose();
    _c2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final pw = _c1.text;
    if (pw.length < 6) {
      setState(() => _error = 'Password kam az kam 6 haroof ka ho.');
      return;
    }
    if (pw != _c2.text) {
      setState(() => _error = 'Dono password ek jaise nahi hain.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final fp = passwordFingerprint(pw);
    final taken =
        await Backend.passwordFingerprintTaken(widget.store, fp);
    if (!mounted) return;
    if (taken == null) {
      setState(() {
        _busy = false;
        _error =
            'Password ki safety check ke liye internet chahiye — net on karke dobara koshish karein.';
      });
      return;
    }
    if (taken) {
      _c1.clear();
      _c2.clear();
      setState(() {
        _busy = false;
        _error =
            'Ye password kisi aur ne lagaya hua hai, aap koi aur password lagayen';
      });
      return;
    }
    final p = widget.store.profile;
    p.pwdFp = fp;
    p.pwdFailCount = 0;
    p.pwdLockUntilMs = 0;
    await widget.store.save();
    widget.store.dutyUnlocked = true;
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Apna Password Lagayein'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
              'Duty shuru karne se pehle apna password lagayein. Ek password sirf ek hi driver ka hota hai — jo pehle lag jaye, wohi us ka ho jata hai.'),
          const SizedBox(height: 8),
          // HOTFIX v1.2.9 (RC3): qadam ki tartib pehle se saaf —
          // password pura hue baghair selfie wala qadam nahi ata,
          // aur driver samajhta tha selfie "khulti hi nahi".
          const Text(
            'Pehle apna password lagayein — us ke baad selfie wala qadam ayega.',
            style: TextStyle(
                fontWeight: FontWeight.w700, color: Brand.green),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _c1,
            obscureText: true,
            enabled: !_busy,
            decoration: const InputDecoration(
                labelText: 'Password (kam az kam 6 haroof)'),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _c2,
            obscureText: true,
            enabled: !_busy,
            decoration:
                const InputDecoration(labelText: 'Password dobara likhein'),
          ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!,
                style: const TextStyle(
                    color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(false),
          child: const Text('Rehne Dein'),
        ),
        ElevatedButton(
          onPressed: _busy ? null : _submit,
          child: Text(_busy ? 'Check ho raha hai…' : 'Password Lagayein'),
        ),
      ],
    );
  }
}

/// Duty unlock: set shuda password likhna. 5 ghalat = 10 minute lockout.
class _AskPasswordDialog extends StatefulWidget {
  final AppStore store;
  const _AskPasswordDialog({required this.store});

  @override
  State<_AskPasswordDialog> createState() => _AskPasswordDialogState();
}

class _AskPasswordDialogState extends State<_AskPasswordDialog> {
  final _c = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final p = widget.store.profile;
    if (passwordFingerprint(_c.text) == p.pwdFp) {
      p.pwdFailCount = 0;
      await widget.store.save();
      widget.store.dutyUnlocked = true;
      if (mounted) Navigator.of(context).pop(true);
      return;
    }
    p.pwdFailCount += 1;
    if (p.pwdFailCount >= 5) {
      // Lockout: ginati zero karke 10 minute ka taala — waqt khatm
      // hone par 5 nayi koshishen milengi.
      p.pwdFailCount = 0;
      p.pwdLockUntilMs =
          DateTime.now().millisecondsSinceEpoch + 10 * 60 * 1000;
      await widget.store.save();
      if (mounted) Navigator.of(context).pop(false);
      return;
    }
    await widget.store.save();
    if (!mounted) return;
    _c.clear();
    setState(() => _error =
        'Ghalat password — ${5 - p.pwdFailCount} koshishen baqi hain.');
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Password Likhein'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Duty shuru karne ke liye apna password likhein.'),
          const SizedBox(height: 12),
          TextField(
            controller: _c,
            obscureText: true,
            autofocus: true,
            decoration: const InputDecoration(labelText: 'Password'),
            onSubmitted: (_) => _submit(),
          ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!,
                style: const TextStyle(
                    color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: const Text('Rehne Dein'),
        ),
        ElevatedButton(
          onPressed: _submit,
          child: const Text('Duty Shuru Karein'),
        ),
      ],
    );
  }
}

/// Password badalna: pehle mojooda password ki tasdeeq, phir naya —
/// naye par wohi uniqueness check.
class _ChangePasswordDialog extends StatefulWidget {
  final AppStore store;
  const _ChangePasswordDialog({required this.store});

  @override
  State<_ChangePasswordDialog> createState() =>
      _ChangePasswordDialogState();
}

class _ChangePasswordDialogState extends State<_ChangePasswordDialog> {
  final _cur = TextEditingController();
  final _n1 = TextEditingController();
  final _n2 = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _cur.dispose();
    _n1.dispose();
    _n2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final p = widget.store.profile;
    if (passwordFingerprint(_cur.text) != p.pwdFp) {
      setState(() => _error = 'Mojooda password ghalat hai.');
      return;
    }
    final pw = _n1.text;
    if (pw.length < 6) {
      setState(() => _error = 'Naya password kam az kam 6 haroof ka ho.');
      return;
    }
    if (pw != _n2.text) {
      setState(() => _error = 'Dono naye password ek jaise nahi hain.');
      return;
    }
    final fp = passwordFingerprint(pw);
    if (fp == p.pwdFp) {
      setState(() =>
          _error = 'Ye aap ka mojooda password hi hai — koi aur lagayein.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final taken =
        await Backend.passwordFingerprintTaken(widget.store, fp);
    if (!mounted) return;
    if (taken == null) {
      setState(() {
        _busy = false;
        _error =
            'Password ki safety check ke liye internet chahiye — net on karke dobara koshish karein.';
      });
      return;
    }
    if (taken) {
      _n1.clear();
      _n2.clear();
      setState(() {
        _busy = false;
        _error =
            'Ye password kisi aur ne lagaya hua hai, aap koi aur password lagayen';
      });
      return;
    }
    p.pwdFp = fp;
    p.pwdFailCount = 0;
    p.pwdLockUntilMs = 0;
    await widget.store.save();
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Password Badlein'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _cur,
              obscureText: true,
              enabled: !_busy,
              decoration:
                  const InputDecoration(labelText: 'Mojooda password'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _n1,
              obscureText: true,
              enabled: !_busy,
              decoration: const InputDecoration(
                  labelText: 'Naya password (kam az kam 6 haroof)'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _n2,
              obscureText: true,
              enabled: !_busy,
              decoration: const InputDecoration(
                  labelText: 'Naya password dobara likhein'),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!,
                  style: const TextStyle(
                      color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(false),
          child: const Text('Rehne Dein'),
        ),
        ElevatedButton(
          onPressed: _busy ? null : _submit,
          child: Text(_busy ? 'Check ho raha hai…' : 'Password Badlein'),
        ),
      ],
    );
  }
}

