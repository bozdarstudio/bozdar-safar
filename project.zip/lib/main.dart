import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'store.dart';
import 'theme.dart';
import 'backend.dart';
import 'duty_service.dart';
import 'legal.dart';
import 'passenger.dart';
import 'driver.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // v1.4.5: duty service + local notifications ki bunyaad —
  // nakami par bhi app aage barhta hai (andar sab try/catch hai).
  await DutyService.init();
  runApp(const BozdarSafarApp());
}

class BozdarSafarApp extends StatefulWidget {
  const BozdarSafarApp({super.key});

  @override
  State<BozdarSafarApp> createState() => _BozdarSafarAppState();
}

class _BozdarSafarAppState extends State<BozdarSafarApp> {
  final AppStore store = AppStore();

  /// Opening display sirf cold start par EK dafa — malik ka hukm
  /// (2026-11-08 ~12:17): app khulte hi pehle BOARD wala display /
  /// intro chalega, phir proper app khulegi. v1.4.4 se asal 15s
  /// INTRO VIDEO (malik ki manzoor-shuda, ❤️ 2026-11-08) bundle
  /// mein hai (assets/intro-15s.mp4) — [IntroGate] use chalata
  /// hai; BoardSplash us ke peeche fallback/poster chehra rehta
  /// hai aur video kisi wajah se na chale to app BOARD wale
  /// purane rawaiye (2.8s display) par hi aage barhti hai — app
  /// intro par KABHI nahi rukti.
  bool _introDone = false;

  @override
  void initState() {
    super.initState();
    // Load ke baad ek dafa khamosh update check + backend sync —
    // dono fire-and-forget, intro se bilkul alag.
    store.load().then((_) {
      store.checkForUpdate();
      Backend.start(store);
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Safar',
      debugShowCheckedModeBanner: false,
      theme: Brand.theme(),
      home: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          if (!_introDone) {
            return IntroGate(
              key: const ValueKey('intro'),
              onDone: () {
                if (mounted) setState(() => _introDone = true);
              },
            );
          }
          if (!store.loaded) {
            return const BoardSplash(key: ValueKey('loading'));
          }
          // v1.4.4 LEGAL: pehli dafa Sharait ki qubooliyat lazmi —
          // baghair qabool kiye proper app (koi mode) nahi khulta.
          if (store.termsAcceptedAtMs == 0) {
            return TermsGateScreen(
                key: const ValueKey('terms'), store: store);
          }
          return ModeShell(key: const ValueKey('shell'), store: store);
        },
      ),
    );
  }
}

/// INTRO VIDEO ka darwaza (v1.4.4 — malik ki final/manzoor video):
/// app khulte hi assets/intro-15s.mp4 (16s, apni asal awaaz ke
/// saath — welcome line + anthem bed file mein pehle se mix hai)
/// chalti hai, phir proper app khulti hai.
///  - Pehli open (din ki): poora intro.
///  - Usi din ki dobara opens: video 10s se shuru (chhota sting) —
///    SKIP ka button dono surat mein har waqt nazar ata hai.
///  - BoardSplash peeche poster/fallback ke tor par rehta hai;
///    video load/play fail ho jaye to wohi board 2.8s dikh kar
///    app aage barh jati hai. 20s ka watchdog bhi hai — app intro
///    par kisi surat NAHI rukti.
class IntroGate extends StatefulWidget {
  final VoidCallback onDone;
  const IntroGate({super.key, required this.onDone});

  @override
  State<IntroGate> createState() => _IntroGateState();
}

class _IntroGateState extends State<IntroGate> {
  VideoPlayerController? _ctrl;
  bool _videoReady = false;
  bool _finished = false;
  Timer? _watchdog;
  Timer? _fallbackTimer;

  @override
  void initState() {
    super.initState();
    _watchdog = Timer(const Duration(seconds: 20), _finish);
    unawaited(_init());
  }

  Future<void> _init() async {
    try {
      // Din ki pehli open hai ya dobara wali — tareekh phone par
      // mehfooz rehti hai; dobara wali par sting (10s se shuru).
      var sameDay = false;
      try {
        final prefs = await SharedPreferences.getInstance();
        final now = DateTime.now();
        final today =
            '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
        sameDay = prefs.getString('intro_last_day') == today;
        await prefs.setString('intro_last_day', today);
      } catch (_) {
        // Prefs na milein to poora intro hi sahi.
      }
      final c = VideoPlayerController.asset('assets/intro-15s.mp4');
      _ctrl = c;
      await c.initialize().timeout(const Duration(seconds: 6));
      if (!mounted || _finished) {
        c.dispose();
        return;
      }
      c.addListener(_onTick);
      if (sameDay) {
        try {
          await c.seekTo(const Duration(seconds: 10));
        } catch (_) {
          // Seek na ho sakay to shuru se hi sahi — Skip mojood hai.
        }
      }
      await c.play();
      if (mounted && !_finished) setState(() => _videoReady = true);
    } catch (_) {
      // Video na chale to purana board wala rawaiya — 2.8s board
      // display, phir app. Crash/hang bilkul nahi.
      _fallbackTimer =
          Timer(const Duration(milliseconds: 2800), _finish);
    }
  }

  void _onTick() {
    final c = _ctrl;
    if (c == null || _finished) return;
    final v = c.value;
    if (v.hasError) {
      _fallbackTimer =
          Timer(const Duration(milliseconds: 1200), _finish);
      return;
    }
    final dur = v.duration.inMilliseconds;
    if (v.isCompleted ||
        (dur > 0 && v.position.inMilliseconds >= dur - 250)) {
      _finish();
    }
  }

  void _finish() {
    if (_finished) return;
    _finished = true;
    _watchdog?.cancel();
    _fallbackTimer?.cancel();
    widget.onDone();
  }

  @override
  void dispose() {
    _watchdog?.cancel();
    _fallbackTimer?.cancel();
    _ctrl?.removeListener(_onTick);
    _ctrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = _ctrl;
    return Stack(
      children: [
        const Positioned.fill(child: BoardSplash()),
        if (_videoReady && c != null)
          Positioned.fill(
            child: ColoredBox(
              color: Colors.black,
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: c.value.size.width,
                  height: c.value.size.height,
                  child: VideoPlayer(c),
                ),
              ),
            ),
          ),
        if (_videoReady)
          Positioned(
            right: 14,
            bottom: 26,
            child: ElevatedButton.icon(
              onPressed: _finish,
              icon: const Icon(Icons.skip_next, size: 19),
              label: const Text('Skip'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black.withOpacity(0.55),
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                  side: const BorderSide(color: Colors.white54),
                ),
                textStyle: const TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w800),
              ),
            ),
          ),
      ],
    );
  }
}

/// BOARD SPLASH — app ka opening display (DESIGN WAVE brief §1 +
/// malik ka hukm 2026-11-08 ~12:17: "app open karen, pehle yahi
/// display aayega jo maine sheet ke andar diya hai, uske baad app
/// open hogi proper"). Board ki splash screen ki asal art se bana
/// hai — widgets mein, poori-screen ki tasveer NAHI:
///  - gehra sabz gradient pas-e-manzar;
///  - upar board wala sabz "S" road-pin nishan (design board ke
///    splash frame se crop — assets/safar-mark-green.png) halki
///    safed glow ke saath;
///  - asal Text wordmark: bara "Safar" + sabz pill mein "App";
///  - tagline "Your Ride, Our Priority";
///  - neeche board ki skyline patti (Minar-e-Pakistan, chaand-
///    taara, Mazar-e-Quaid — assets/safar-skyline.png) upar wale
///    kinare par soft fade ke saath;
///  - "Loading..." + behti hui loading patti (asal widget).
/// Ye display purani racing intro ki jagah hai (woh retire ho
/// gayi) aur 15s intro video ke gate ka fallback chehra bhi yahi
/// hoga (brief §2). Assistant ka banaya hua koi alag logo/card
/// NAHI hai — saari art malik ke apne board se hai.
class BoardSplash extends StatelessWidget {
  const BoardSplash({super.key});

  @override
  Widget build(BuildContext context) {
    final skyH = MediaQuery.of(context).size.height * 0.27;
    return Scaffold(
      backgroundColor: Brand.greenDark,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Brand.brightGreen, Brand.green, Brand.greenDark],
            stops: [0.0, 0.45, 1.0],
          ),
        ),
        child: Column(
          children: [
            const Spacer(flex: 3),
            // Sabz S road-pin — board ki apni art, safed glow mein.
            Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.white.withOpacity(0.35),
                    blurRadius: 55,
                    spreadRadius: 8,
                  ),
                ],
              ),
              child: Image.asset(
                'assets/safar-mark-green.png',
                width: 148,
                fit: BoxFit.contain,
              ),
            ),
            const SizedBox(height: 14),
            // Wordmark — board wali composition, asal Text widgets:
            // "Safar" bara safed + baseline ke saath sabz "App" pill.
            Row(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const Text(
                  'Safar',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 54,
                    fontWeight: FontWeight.w900,
                    fontStyle: FontStyle.italic,
                    height: 1.0,
                    shadows: [
                      Shadow(color: Colors.black26, blurRadius: 10),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  margin: const EdgeInsets.only(bottom: 7),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    color: Brand.green,
                    borderRadius: BorderRadius.circular(9),
                    border: Border.all(color: Colors.white70, width: 1),
                  ),
                  child: const Text(
                    'App',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'Your Ride, Our Priority',
              style: TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Spacer(flex: 2),
            // Loading — board ki tarah, lekin asal widget.
            const Text(
              'Loading...',
              style: TextStyle(color: Colors.white70, fontSize: 12.5),
            ),
            const SizedBox(height: 7),
            SizedBox(
              width: 180,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(3),
                child: const LinearProgressIndicator(
                  minHeight: 3,
                  backgroundColor: Colors.white24,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              ),
            ),
            const SizedBox(height: 14),
            // Skyline patti — board ki asal art; upar wala kinara
            // gradient mask se bg mein ghul jata hai (seam nahi).
            SizedBox(
              height: skyH,
              width: double.infinity,
              child: ShaderMask(
                shaderCallback: (rect) => const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Colors.white, Colors.white],
                  stops: [0.0, 0.32, 1.0],
                ).createShader(rect),
                blendMode: BlendMode.dstIn,
                child: Image.asset(
                  'assets/safar-skyline.png',
                  fit: BoxFit.cover,
                  alignment: Alignment.bottomCenter,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ONE app, TWO fully separated sides. One tap replaces the whole
/// display; the other side never renders. Mode badalne ka SIRF EK
/// tareeqa hai (v1.0.8 — malik ka hukm): har side ke BrandHeader ke
/// foran neeche ek hi wazeh toggle button [ModeToggleButton], jis par
/// us mode ka naam likha hota hai jis mein jana hai ("Driver Mode" /
/// "Passenger Mode"). Kyunke ek waqt mein sirf ek side render hoti
/// hai, screen par hamesha ek hi mode button hota hai. Pehli dafa app
/// Passenger mode mein khulti hai.
class ModeShell extends StatefulWidget {
  final AppStore store;
  const ModeShell({super.key, required this.store});

  @override
  State<ModeShell> createState() => _ModeShellState();
}

class _ModeShellState extends State<ModeShell> {
  bool driverMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Brand.deepGreen,
      body: SafeArea(
        bottom: false,
        child: driverMode
            ? DriverSide(
                store: widget.store,
                onSwitchToPassenger: () {
                  setState(() => driverMode = false);
                  // Backend `devices` entry mein akhri mode taza.
                  unawaited(Backend.touchDevice(widget.store, 'passenger'));
                },
              )
            : PassengerSide(
                store: widget.store,
                onSwitchToDriver: () {
                  setState(() => driverMode = true);
                  unawaited(Backend.touchDevice(widget.store, 'driver'));
                },
              ),
      ),
    );
  }
}

/// THE single mode toggle (v1.0.8 — malik ka hukm: mode badalne ka
/// sirf yehi ek button hoga). Har side ke BrandHeader ke foran neeche
/// wazeh tor par lagta hai. Is par us mode ka naam likha hota hai jis
/// mein ye le jayega: Passenger mode mein "Driver Mode" (gaari/driver
/// icon ke saath), Driver mode mein "Passenger Mode" (sawari icon ke
/// saath). Ek tap = side badal gayi.
class ModeToggleButton extends StatelessWidget {
  final bool toDriver;
  final VoidCallback onTap;
  const ModeToggleButton(
      {super.key, required this.toDriver, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(
            toDriver
                ? Icons.drive_eta
                : Icons.airline_seat_recline_normal,
            size: 22),
        label: Text(toDriver ? 'Driver Mode' : 'Passenger Mode'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Brand.gold,
          foregroundColor: Brand.greenDark,
          padding: const EdgeInsets.symmetric(vertical: 13),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
        ),
      ),
    );
  }
}

/// Nayi update ka slim gold banner — dono sides ke home ke upar dikhta
/// hai. "Update karein" download link kholta hai; × dabane se sirf is
/// session ke liye chhup jata hai.
class UpdateBanner extends StatelessWidget {
  final AppStore store;
  const UpdateBanner({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: Brand.gold,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(
        children: [
          const Icon(Icons.system_update, size: 18, color: Brand.greenDark),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              'Safar ki nayi update aa gayi hai',
              style: TextStyle(
                  color: Brand.greenDark,
                  fontSize: 13,
                  fontWeight: FontWeight.w800),
            ),
          ),
          TextButton(
            onPressed: () => launchUrl(
              Uri.parse(kUpdateDownloadUrl),
              mode: LaunchMode.externalApplication,
            ),
            style: TextButton.styleFrom(
              backgroundColor: Brand.greenDark,
              foregroundColor: Brand.cream,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              minimumSize: Size.zero,
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: const Text('Update karein',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(width: 4),
          IconButton(
            onPressed: store.dismissUpdate,
            icon: const Icon(Icons.close, size: 18, color: Brand.greenDark),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
            tooltip: 'Band karein',
          ),
        ],
      ),
    );
  }
}
