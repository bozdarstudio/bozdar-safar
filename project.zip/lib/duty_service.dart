import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:geolocator/geolocator.dart';

import 'backend.dart';
import 'store.dart';
import 'theme.dart' show rs;

/// v1.4.5 — DUTY SERVICE (foreground service + local notifications).
///
/// Masla jo ye hal karta hai (owner audit ki sab se bari kami):
/// pehle app ki saari khabar sirf tab milti thi jab app screen par
/// khuli ho — duty timers aur polls UI ke saath band ho jate thay.
///
/// Nizam:
///  - DRIVER duty ON kare to ek foreground service chalta hai
///    (mustaqil notification: "Bozdar Safar — aap duty par hain").
///    Service har ~15s: (a) driver ki location backend par likhta
///    hai — app band/screen off ho tab bhi; (b) backend Pool se
///    nayi rides dekhta hai — nayi ride (2 km ke andar, jab jagah
///    maloom ho) par AWAAZ wali local notification (ghanti) ati
///    hai; (c) apni chal rahi rides par driver_lat/lng bhi taaza
///    rakhta hai taaki passenger ka ETA nah ruke.
///  - PASSENGER ki ride active ho (pending/accepted/arrived) aur
///    driver duty is phone par NA chal rahi ho, to wohi service
///    passenger mode mein chalta hai: har ~15s ride ki haalat
///    dekhta hai, tabdeeli (driver qubool / pohanch gaya / ride
///    mukammal / cancel) par local notification deta hai. Ride
///    final ho jaye to service khud band ho jata hai.
///  - Duty off / koi active ride na ho → service band. Battery ka
///    kharcha sirf duty/active-ride ke doran hai.
///
/// Koi FCM/Firebase nahi — ye Android ka apna foreground-service
/// tareeqa hai, offline-first usool ke saath (backend na mile to
/// chakkar khamosh skip ho jata hai).

/// Service isolate ka entrypoint — top-level + vm:entry-point lazmi.
@pragma('vm:entry-point')
void _dutyServiceCallback() {
  FlutterForegroundTask.setTaskHandler(_DutyTaskHandler());
}

/// Local notification ki ek hi jagah — main isolate aur service
/// isolate dono yahin se dikhate hain (har isolate apni dafa
/// [DutyNotify.init] bulata hai).
class DutyNotify {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static const String alertsChannel = 'safar_alerts';

  /// Ghanti par TAP (v1.4.27 — postmortem #23): payload
  /// 'ride:<id>' ho to rideOpenSignal par darkhwast — mounted
  /// home screen mutaliqa tab khol deti hai। App band honay
  /// par tap hua ho to plugin launch-details se wohi payload
  /// milta hai aur signal mein reh jata hai (home bante hi
  /// consume ho jata hai)।
  static void _handleTapPayload(String? payload) {
    if (payload == null || !payload.startsWith('ride:')) return;
    rideOpenSignal.request(payload.substring(5));
  }

  static Future<void> init() async {
    if (_ready) return;
    try {
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
      await _plugin.initialize(
        const InitializationSettings(android: android),
        onDidReceiveNotificationResponse: (resp) =>
            _handleTapPayload(resp.payload),
      );
      try {
        final launch = await _plugin.getNotificationAppLaunchDetails();
        if (launch?.didNotificationLaunchApp ?? false) {
          _handleTapPayload(launch?.notificationResponse?.payload);
        }
      } catch (_) {
        // Launch-details na milein to tap wala rasta (upar)
        // barkarar hai — kuch nahi rukta।
      }
      final impl = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      await impl?.createNotificationChannel(const AndroidNotificationChannel(
        alertsChannel,
        'Ride ki khabar',
        description: 'Nayi ride aur ride ki haalat ki ghanti',
        importance: Importance.high,
        playSound: true,
        enableVibration: true,
      ));
      _ready = true;
    } catch (_) {
      // Notification na bane to bhi service/app chalta rahe.
    }
  }

  static Future<void> show(int id, String title, String body,
      {String? payload}) async {
    await init();
    if (!_ready) return;
    try {
      await _plugin.show(
        id,
        title,
        body,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            alertsChannel,
            'Ride ki khabar',
            channelDescription: 'Nayi ride aur ride ki haalat ki ghanti',
            importance: Importance.high,
            priority: Priority.high,
            playSound: true,
            enableVibration: true,
            icon: '@mipmap/ic_launcher',
          ),
        ),
        payload: payload,
      );
    } catch (_) {}
  }

  static int idFor(String key) => key.hashCode & 0x7fffffff;
}

/// Main isolate se service ko chalana/band karna/config dena.
class DutyService {
  static bool _taskInited = false;

  /// App start par ek dafa — main() se.
  static Future<void> init() async {
    await DutyNotify.init();
    if (_taskInited) return;
    _taskInited = true;
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'safar_duty',
        channelName: 'Duty Service',
        channelDescription:
            'Duty ke doran location aur ride ki khabar ke liye chalti service',
        channelImportance: NotificationChannelImportance.LOW,
        priority: NotificationPriority.LOW,
      ),
      iosNotificationOptions: const IOSNotificationOptions(),
      foregroundTaskOptions: ForegroundTaskOptions(
        // v1.4.10: 15 s → 5 s — duty par driver ka maqam takreeban
        // har 5 second mein backend tak jaye (pool/watch ki
        // jaanchh handler ke andar purani 15 s raftaar par hai).
        eventAction: ForegroundTaskEventAction.repeat(5000),
        autoRunOnBoot: false,
        allowWakeLock: true,
        allowWifiLock: false,
      ),
    );
  }

  /// Android 13+ ki notification ijazat — pehli dafa duty/passenger
  /// service shuru karne se pehle manga jata hai. Jawab: mili ya nahi.
  static Future<bool> ensureNotificationPermission() async {
    await DutyNotify.init();
    try {
      var status = await FlutterForegroundTask.checkNotificationPermission();
      if (status == NotificationPermission.granted) return true;
      status = await FlutterForegroundTask.requestNotificationPermission();
      return status == NotificationPermission.granted;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> get isRunning => FlutterForegroundTask.isRunningService;

  /// Service chalu kare (ya chalti ho to config taaza kar de).
  /// [watch]: rideId → {'s': status, 'r': 'pickup → drop'}.
  static Future<void> startOrUpdate({
    required String mode, // 'driver' | 'passenger'
    required String driverId,
    required Map<String, Map<String, String>> watch,
    required String title,
    required String text,
    // v1.4.29 FINAL RADIUS RULE: background pool notification
    // ki range bhi driver ke apne radius (2–5 km) se hogi।
    double radiusKm = kDriverPickupRadiusKm,
  }) async {
    await init();
    final cfg = jsonEncode({
      'mode': mode,
      'driverId': driverId,
      'watch': watch,
      'radiusKm': radiusKm,
    });
    try {
      if (await FlutterForegroundTask.isRunningService) {
        // Config ka mode badalna ho to restart lazmi hai (service
        // ki mustaqil notification bhi usi hisab se badalti hai).
        final current =
            await FlutterForegroundTask.getData<String>(key: 'safar_mode');
        if (current == mode) {
          FlutterForegroundTask.sendDataToTask(cfg);
          return;
        }
        await FlutterForegroundTask.stopService();
      }
      await FlutterForegroundTask.saveData(key: 'safar_cfg', value: cfg);
      await FlutterForegroundTask.saveData(key: 'safar_mode', value: mode);
      await FlutterForegroundTask.startService(
        notificationTitle: title,
        notificationText: text,
        callback: _dutyServiceCallback,
      );
    } catch (_) {
      // Service na chale to app apne purane foreground timers par
      // chalta rehta hai — crash kabhi nahi.
    }
  }

  static Future<void> stop() async {
    try {
      if (await FlutterForegroundTask.isRunningService) {
        await FlutterForegroundTask.stopService();
      }
    } catch (_) {}
  }

  /// Passenger side ke liye tayyar config: is phone ki active
  /// bookings (jo abhi final nahi hui).
  static Map<String, Map<String, String>> watchFromStore(AppStore store) {
    final out = <String, Map<String, String>>{};
    for (final b in store.bookings) {
      if (b.status == 'pending' ||
          b.status == 'accepted' ||
          b.status == 'arrived') {
        out[b.id] = {
          's': b.status,
          'r': '${b.pickupLabel} → ${b.dropLabel}',
        };
      }
    }
    return out;
  }
}

/// Service isolate mein chalne wala handler — AppStore NAHI rakhta,
/// sirf config (mode/driverId/watch) + Backend ke store-free
/// helpers istemal karta hai.
class _DutyTaskHandler extends TaskHandler {
  String _mode = '';
  String _driverId = '';
  double _radiusKm = kDriverPickupRadiusKm;
  Map<String, Map<String, String>> _watch = {};
  Set<String> _knownPool = {};
  bool _poolPrimed = false;

  /// v1.4.10: tick gin le — repeat ab 5 s ka hai (driver location
  /// ki taaza khabar ke liye), lekin pool/watch ki jaanchh apni
  /// purani 15 s raftaar par rakhne ke liye har teesra tick hi
  /// un hisson ko chalata hai.
  int _tick = 0;

  void _applyCfg(String raw) {
    try {
      final m = jsonDecode(raw);
      if (m is! Map) return;
      _mode = m['mode'] as String? ?? _mode;
      _driverId = m['driverId'] as String? ?? _driverId;
      _radiusKm = ((m['radiusKm'] as num?)?.toDouble() ?? _radiusKm)
          .clamp(2.0, 5.0)
          .toDouble();
      final w = m['watch'];
      if (w is Map) {
        final next = <String, Map<String, String>>{};
        w.forEach((k, v) {
          if (k is String && v is Map) {
            next[k] = {
              's': v['s']?.toString() ?? '',
              'r': v['r']?.toString() ?? '',
            };
          }
        });
        _watch = next;
      }
    } catch (_) {}
  }

  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    await DutyNotify.init();
    final raw =
        await FlutterForegroundTask.getData<String>(key: 'safar_cfg');
    if (raw != null) _applyCfg(raw);
  }

  @override
  void onReceiveData(Object data) {
    if (data is String) _applyCfg(data);
  }

  static double _kmBetween(double lat1, double lng1, double lat2, double lng2) {
    const r = 6371.0;
    final dLat = (lat2 - lat1) * math.pi / 180;
    final dLng = (lng2 - lng1) * math.pi / 180;
    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1 * math.pi / 180) *
            math.cos(lat2 * math.pi / 180) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    return 2 * r * math.asin(math.min(1, math.sqrt(a)));
  }

  @override
  Future<void> onRepeatEvent(DateTime timestamp) async {
    _tick++;
    // --- Driver duty ka kaam -------------------------------------
    if (_mode == 'driver' && _driverId.isNotEmpty) {
      double? lat, lng;
      try {
        final pos = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(
            // v1.4.10: medium → high — sab se saaf maqam.
            accuracy: LocationAccuracy.high,
            timeLimit: Duration(seconds: 10),
          ),
        );
        lat = pos.latitude;
        lng = pos.longitude;
      } catch (_) {
        // GPS na mile to is chakkar mein sirf pool/watch hoga.
      }
      if (lat != null && lng != null) {
        await Backend.servicePushDriverLocation(_driverId, lat, lng);
        final actives = await Backend.fetchDriverActiveRideIds(_driverId);
        for (final id in actives) {
          await Backend.servicePushRidePosition(id, lat, lng);
        }
      }
      // Nayi rides — pehla chakkar sirf snapshot (purani khadi
      // rides par ghanti nahi), us ke baad har NAYI ride par
      // ghanti. 2 km filter wohi lock: jagah + pickup pin dono
      // hon tab hi; warna ride dikhayi jati hai (chhupana nahi).
      // v1.4.10: pool ki jaanchh purani 15 s raftaar par hi hai
      // (har teesra tick) — 5 s wala tick sirf location ke liye.
      if (_tick % 3 == 1) {
        try {
          final pool = await Backend.fetchPendingPoolRides();
        final ids = pool.map((b) => b.id).toSet();
        if (!_poolPrimed) {
          _knownPool = ids;
          _poolPrimed = true;
        } else {
          for (final b in pool) {
            if (_knownPool.contains(b.id)) continue;
            var inRange = true;
            if (lat != null &&
                lng != null &&
                (b.pickupLat != 0 || b.pickupLng != 0)) {
              inRange =
                  _kmBetween(lat, lng, b.pickupLat, b.pickupLng) <=
                      _radiusKm;
            }
            if (inRange) {
              await DutyNotify.show(
                DutyNotify.idFor('pool:${b.id}'),
                'Nayi ride aayi hai',
                '${b.pickupLabel} → ${b.dropLabel} · ${b.vehicle} · ${rs(b.fare)}',
                payload: 'ride:${b.id}',
              );
            }
          }
          _knownPool = ids;
          }
        } catch (_) {}
      }
    }

    // --- Watched rides (passenger mode + driver mode dono) -------
    // v1.4.10: watch ki jaanchh bhi purani 15 s raftaar par (har
    // teesra tick) — bartao bilkul waisa hi, sirf location taaza.
    if (_tick % 3 == 1 && _watch.isNotEmpty) {
      final done = <String>[];
      for (final e in _watch.entries.toList()) {
        final row = await Backend.fetchRideRow(e.key);
        if (row == null) continue;
        final st = row['status'];
        if (st is! String || st.isEmpty || st == e.value['s']) continue;
        _watch[e.key] = {'s': st, 'r': e.value['r'] ?? ''};
        String? title;
        // Notification body — aam haalat mein sirf route; cancel
        // par (neeche) wajah wali body banti hai.
        var body = e.value['r'] ?? '';
        switch (st) {
          case 'accepted':
            title = 'Driver ne ride qubool kar li';
            break;
          case 'arrived':
            title = 'Driver pohanch gaya hai';
            break;
          case 'completed':
            title = 'Ride mukammal ho gayi';
            break;
          case 'cancelled':
            title = 'Ride cancel ho gayi';
            // FINAL-PACK D (passenger watch): body mein cancel ki
            // WAJAH lazmi — backend row ka cancel_reason column
            // (fetchRideRow woh pull karta hai). Wajah khaali ho
            // to saaf likha ata hai; route doosri line mein rehta
            // hai. Driver-mode watch par purani route wali body
            // hi rehti hai (wahan cancel aksar driver ka apna
            // hota hai — "driver ne band kar di" wahan ghalat
            // hota).
            if (_mode == 'passenger') {
              final reason =
                  (row['cancel_reason']?.toString() ?? '').trim();
              body =
                  'Driver ne ride band kar di — wajah: ${reason.isEmpty ? 'wajah nahi batayi gayi' : reason}';
              final route = e.value['r'] ?? '';
              if (route.isNotEmpty) body = '$body\n$route';
            }
            break;
          case 'noshow':
            title = 'Ride band ho gayi';
            break;
        }
        if (title != null) {
          await DutyNotify.show(
            DutyNotify.idFor('watch:${e.key}:$st'),
            title,
            body,
            payload: 'ride:${e.key}',
          );
        }
        if (st == 'completed' || st == 'cancelled' || st == 'noshow') {
          done.add(e.key);
        }
      }
      for (final id in done) {
        _watch.remove(id);
      }
      // Passenger mode: saari rides final — service ka kaam khatam.
      if (_mode == 'passenger' && _watch.isEmpty) {
        try {
          await FlutterForegroundTask.stopService();
        } catch (_) {}
      }
    }
  }

  @override
  Future<void> onDestroy(DateTime timestamp) async {}
}
