import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart' as ll2;
import 'store.dart';
import 'theme.dart';
import 'safar_map.dart';
import 'backend.dart';
import 'main.dart' show ModeToggleButton, UpdateBanner;
import 'passenger.dart' show kStatusUrdu;

class DriverSide extends StatefulWidget {
  final AppStore store;
  final VoidCallback onSwitchToPassenger;
  const DriverSide(
      {super.key, required this.store, required this.onSwitchToPassenger});

  @override
  State<DriverSide> createState() => _DriverSideState();
}

class _DriverSideState extends State<DriverSide> {
  int _tab = 0; // 0 Home | 1 Bookings | 2 Wallet | 3 Profile
  final ImagePicker _picker = ImagePicker();

  AppStore get store => widget.store;
  DriverProfile get p => store.profile;

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _takeSelfie() async {
    try {
      // LIVE selfie — camera ONLY. No gallery option anywhere, by design.
      final XFile? img =
          await _picker.pickImage(source: ImageSource.camera);
      if (img == null) return;
      await store.setSelfie(img.path);
      if (mounted) _snack('Aaj ki selfie ho gayi — ab ride qubool ho sakti hai.');
    } catch (_) {
      if (mounted) _snack('Camera nahi khul saka.');
    }
  }

  int _todayNetEarnings() {
    final now = DateTime.now();
    var sum = 0;
    for (final b in store.bookings) {
      final c = b.completedAt;
      if (b.status == 'completed' &&
          c != null &&
          c.year == now.year &&
          c.month == now.month &&
          c.day == now.day) {
        sum += b.total - Fares.serviceFee(b.fare + b.waitingCharge);
      }
    }
    return sum;
  }

  @override
  Widget build(BuildContext context) {
    final incoming =
        store.bookings.where((b) => b.status == 'pending').length;
    return Scaffold(
      body: Column(
        children: [
          const BrandHeader(sideLabel: 'DRIVER APP · KARACHI'),
          if (store.updateAvailable && !store.updateDismissed)
            UpdateBanner(store: store),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
            child: ModeToggleButton(
                toDriver: false, onTap: widget.onSwitchToPassenger),
          ),
          // Malik ki driver mode artwork (brand board — rickshaw driver)
          // header + toggle ke foran neeche.
          const ModeBanner(asset: 'assets/mode-driver.png'),
          Expanded(
            child: _tab == 0
                ? _homeView()
                : _tab == 1
                    ? _bookingsView()
                    : _tab == 2
                        ? _walletView()
                        : _profileView(),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) => setState(() => _tab = i),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Brand.green,
        items: [
          const BottomNavigationBarItem(
              icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
            icon: Badge(
              label: Text('$incoming'),
              isLabelVisible: incoming > 0,
              child: const Icon(Icons.notifications_active),
            ),
            label: 'Bookings',
          ),
          const BottomNavigationBarItem(
              icon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          const BottomNavigationBarItem(
              icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  // --- HOME: big online/offline state ---------------------------------------

  Widget _homeView() {
    final online = p.online;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        // BIG state card — inDrive style
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: online ? Brand.green : const Color(0xFF5A5A5A),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Brand.gold, width: 2),
          ),
          child: Column(
            children: [
              Icon(online ? Icons.check_circle : Icons.do_not_disturb_on,
                  color: Colors.white, size: 44),
              const SizedBox(height: 6),
              Text(online ? 'Aap ONLINE hain' : 'Aap OFFLINE hain',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w900)),
              Text(
                online
                    ? 'Ride requests aa sakti hain'
                    : 'Online honay par ride requests ayengi',
                style: const TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () async {
                    p.online = !p.online;
                    await store.save();
                    setState(() {});
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: online ? Colors.white : Brand.gold,
                    foregroundColor:
                        online ? Brand.green : Brand.greenDark,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: Text(online ? 'Offline Ho Jayein' : 'Online Ho Jayein',
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        // inDrive D1 language: status ke foran baad aaj ki kamai +
        // wallet balance ki jhalak (top cards), phir profile/gates.
        Row(
          children: [
            Expanded(
              child: _statCard('Aaj ki kamai', rs(_todayNetEarnings()),
                  Icons.trending_up),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _statCard(
                  'Wallet balance', rs(p.walletBalance), Icons.wallet),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: Brand.deepGreen,
                  child: Text(
                    p.name.isNotEmpty ? p.name[0] : 'R',
                    style: const TextStyle(
                        color: Brand.gold,
                        fontSize: 22,
                        fontWeight: FontWeight.w900),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.name,
                          style: const TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w800)),
                      Text(
                          '${p.vehicle}${p.plate.isEmpty ? '' : ' · ${p.plate}'} · ${p.zone}'),
                      Text('Karachi Driver',
                          style: TextStyle(
                              fontSize: 12, color: Colors.grey.shade600)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 6),
        _gateRow(
          icon: Icons.payments,
          label: 'Joining Deposit (Rs ${Fares.joiningDeposit})',
          done: p.depositDone,
          doneText: 'Ho gaya',
          pendingText:
              'Baqi — ${rs(Fares.joiningDeposit - p.totalDeposited)} aur chahiye',
          onFix: p.depositDone ? null : () => setState(() => _tab = 2),
          fixLabel: 'Wallet',
        ),
        _gateRow(
          icon: Icons.camera_alt,
          label: 'Aaj ki Live Selfie',
          done: p.selfieToday,
          doneText: 'Ho gayi',
          pendingText: 'Baqi — baghair selfie ride qubool nahi hogi',
          onFix: p.selfieToday ? null : _takeSelfie,
          fixLabel: 'Selfie Lein',
        ),
        _gateRow(
          icon: Icons.badge,
          label: 'CNIC Tasdeeq',
          done: p.cnicStatus == 'verified',
          doneText: 'Verified',
          pendingText: 'Pending',
          onFix: () => setState(() => _tab = 3),
          fixLabel: 'Profile',
        ),
        const SizedBox(height: 10),
        if (p.selfiePath.isNotEmpty && p.selfieToday)
          Card(
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(File(p.selfiePath),
                    width: 46, height: 46, fit: BoxFit.cover),
              ),
              title: const Text('Aaj ki selfie'),
              subtitle: Text('Tareekh: ${p.selfieDate}'),
            ),
          ),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text(
              'Usool: Kiraya pehle se pakka hai — koi mol-bhav nahi. Service charges sirf ${fmtPct(Fares.feePercent)} (kiraya + waiting par). Wallet kabhi minus nahi jata. Pehle 5 minute intezaar muft, phir gaari ke hisab se waiting charges.',
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ),
      ],
    );
  }

  Widget _statCard(String label, String value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Icon(icon, color: Brand.gold, size: 26),
            const SizedBox(height: 6),
            Text(value,
                style: const TextStyle(
                    fontSize: 19, fontWeight: FontWeight.w900)),
            Text(label,
                style: const TextStyle(fontSize: 12, color: Colors.black54)),
          ],
        ),
      ),
    );
  }

  Widget _gateRow({
    required IconData icon,
    required String label,
    required bool done,
    required String doneText,
    required String pendingText,
    required VoidCallback? onFix,
    required String fixLabel,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: done ? Brand.green : Brand.ajrakRed),
        title: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(done ? doneText : pendingText),
        trailing: done
            ? const Icon(Icons.check_circle, color: Brand.green)
            : TextButton(onPressed: onFix, child: Text(fixLabel)),
      ),
    );
  }

  // --- BOOKINGS: large incoming request cards --------------------------------

  Widget _bookingsView() {
    final incoming =
        store.bookings.where((b) => b.status == 'pending').toList();
    final active = store.bookings
        .where((b) => b.status == 'accepted' || b.status == 'arrived')
        .toList();
    final past = store.bookings
        .where((b) =>
            b.status == 'completed' ||
            b.status == 'noshow' ||
            b.status == 'cancelled')
        .toList();
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('Aane wali bookings',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (incoming.isEmpty)
          const Text('Abhi koi nayi booking nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...incoming.map(_incomingCard),
        const SizedBox(height: 16),
        const Text('Chal rahi rides',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (active.isEmpty)
          const Text('Koi ride chal nahi rahi.',
              style: TextStyle(color: Colors.black54)),
        ...active.map(_activeCard),
        const SizedBox(height: 16),
        const Text('Purani rides',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (past.isEmpty)
          const Text('Abhi koi purani ride nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...past.map((b) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: const Icon(Icons.history, color: Brand.green),
                title: Text('${b.pickupLabel} → ${b.dropLabel}'),
                subtitle: Text(
                    '${kStatusUrdu[b.status] ?? b.status} · ${fmtDate(b.completedAt ?? b.createdAt)}'),
                trailing: Text(rs(b.total),
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
            )),
      ],
    );
  }

  Widget _routeLines(Booking b) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          const Icon(Icons.circle, color: Brand.green, size: 14),
          const SizedBox(width: 8),
          Expanded(
              child: Text('Pickup: ${b.pickupLabel}',
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700))),
        ]),
        const Padding(
          padding: EdgeInsets.only(left: 6),
          child: Icon(Icons.more_vert, size: 16, color: Colors.grey),
        ),
        Row(children: [
          const Icon(Icons.location_on, color: Brand.ajrakRed, size: 16),
          const SizedBox(width: 8),
          Expanded(
              child: Text('Drop: ${b.dropLabel}',
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700))),
        ]),
      ],
    );
  }

  Widget _incomingCard(Booking b) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: Brand.gold, width: 2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Chip(
                  label: Text('NAYI BOOKING'),
                  backgroundColor: Brand.goldLight,
                  labelStyle:
                      TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
                ),
                const Spacer(),
                Text(fmtTime(b.createdAt),
                    style: const TextStyle(color: Colors.black54)),
              ],
            ),
            const SizedBox(height: 8),
            Text(b.passengerName,
                style:
                    const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            if (b.passengerPhone.isNotEmpty)
              Text(b.passengerPhone,
                  style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 10),
            _routeLines(b),
            if (b.note.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('Note: ${b.note}',
                  style: const TextStyle(
                      fontSize: 13, fontStyle: FontStyle.italic)),
            ],
            if (b.hasDropPin) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  height: 180,
                  child: SafarRouteMap(
                    pickup: ll2.LatLng(b.pickupLat, b.pickupLng),
                    drop: ll2.LatLng(b.dropLat, b.dropLng),
                    interactive: false,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                Chip(
                  avatar: const Icon(Icons.route, size: 16),
                  label: Text(
                      '${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm} km · ${b.vehicle}'),
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('KUL KIRAYA',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Colors.black54)),
                    Text(rs(b.fare),
                        style: const TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w900)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _accept(b),
                    style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                    child:
                        const Text('Qubool Karein', style: TextStyle(fontSize: 16)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () async {
                      await store.cancelBooking(b);
                      if (mounted) _snack('Booking rehne di gayi.');
                      setState(() {});
                    },
                    style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                    child:
                        const Text('Rehne Dein', style: TextStyle(fontSize: 16)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _accept(Booking b) async {
    final reason = store.acceptBlockReason();
    if (reason != null) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Ride qubool nahi ho sakti'),
          content: Text(reason),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Theek hai')),
          ],
        ),
      );
      return;
    }
    await store.acceptBooking(b);
    if (mounted) {
      _snack('Booking qubool ho gayi.');
      setState(() {});
    }
  }

  Widget _activeCard(Booking b) {
    final arrived = b.status == 'arrived';
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(b.passengerName,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w900)),
                const Spacer(),
                Chip(
                  label: Text(arrived ? 'Pohanch gaye' : 'Qubool shuda'),
                  backgroundColor:
                      arrived ? const Color(0xFFF3E9C8) : const Color(0xFFDFF5E6),
                  labelStyle: const TextStyle(fontSize: 11),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _routeLines(b),
            const SizedBox(height: 8),
            if (b.hasDropPin) ...[
              DriverNavView(booking: b),
              const SizedBox(height: 10),
            ],
            Text(
                'Kiraya: ${rs(b.fare)} · ${b.vehicle} · ${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm} km'),
            if (!arrived) ...[
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () async {
                    await store.markArrived(b);
                    if (mounted) {
                      _snack(
                          'Waiting timer shuru — pehle ${Fares.freeWaitingMinutes} minute muft hain.');
                      setState(() {});
                    }
                  },
                  icon: const Icon(Icons.location_on),
                  label: const Text('Pohanch Gaya'),
                ),
              ),
            ] else ...[
              const SizedBox(height: 10),
              _LiveWaiting(booking: b, store: store),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => _complete(b),
                  icon: const Icon(Icons.flag),
                  label: const Text('Ride Mukammal Karein'),
                  style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14)),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => _noShow(b),
                  icon: const Icon(Icons.person_off),
                  label: const Text('Sawari Nahi Aayi (No-show)'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _complete(Booking b) async {
    final err = await store.completeBooking(b);
    if (!mounted) return;
    if (err != null) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Ride mukammal nahi ho sakti'),
          content: Text(err),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Theek hai')),
          ],
        ),
      );
    } else {
      _snack(
          'Ride mukammal — kiraya ${rs(b.fare)} + waiting ${rs(b.waitingCharge)}; ${fmtPct(Fares.feePercent)} service charges wallet se kat gaya.');
    }
    setState(() {});
  }

  Future<void> _noShow(Booking b) async {
    final err = await store.markNoShow(b);
    if (!mounted) return;
    _snack(err ??
        'No-show darj ho gaya — waiting charges ${rs(b.waitingCharge)} record mein hain.');
    setState(() {});
  }

  // --- WALLET -----------------------------------------------------------------

  final _depositCtrl = TextEditingController();
  String _depositMethod = 'Cash';

  @override
  void dispose() {
    _depositCtrl.dispose();
    super.dispose();
  }

  Widget _walletView() {
    final remaining = Fares.joiningDeposit - p.totalDeposited;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Brand.deepGreen,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Brand.gold, width: 2),
          ),
          child: Column(
            children: [
              const Text('WALLET BALANCE',
                  style: TextStyle(
                      color: Brand.goldLight,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2)),
              Text(rs(p.walletBalance),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.w900)),
              Text(
                p.depositDone
                    ? 'Joining deposit mukammal hai'
                    : 'Joining deposit baqi: ${rs(remaining > 0 ? remaining : 0)} aur chahiye',
                style: const TextStyle(color: Brand.cream, fontSize: 12),
              ),
              const SizedBox(height: 6),
              const Text(
                'Wallet kabhi minus nahi jata — fee sirf balance se kat ti hai.',
                style: TextStyle(color: Colors.white60, fontSize: 11),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        const Text('Deposit Darj Karein',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        TextField(
          controller: _depositCtrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
              labelText: 'Raqam (Rs)', prefixIcon: Icon(Icons.payments)),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            const Text('Tareeqa: ',
                style: TextStyle(fontWeight: FontWeight.w700)),
            ChoiceChip(
              label: const Text('Cash'),
              selected: _depositMethod == 'Cash',
              onSelected: (_) => setState(() => _depositMethod = 'Cash'),
            ),
            const SizedBox(width: 8),
            ChoiceChip(
              label: const Text('Raast'),
              selected: _depositMethod == 'Raast',
              onSelected: (_) => setState(() => _depositMethod = 'Raast'),
            ),
          ],
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () async {
              final amt = int.tryParse(_depositCtrl.text.trim()) ?? 0;
              if (amt <= 0) {
                _snack('Durust raqam likhein.');
                return;
              }
              await store.addDeposit(amt, _depositMethod);
              _depositCtrl.clear();
              if (mounted) {
                _snack('Deposit ${rs(amt)} darj ho gaya.');
                setState(() {});
              }
            },
            child: const Text('Deposit Jama Karein'),
          ),
        ),
        const SizedBox(height: 20),
        const Text('Monthly Packages',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.monthlyPackages.isEmpty)
          const Text('Abhi koi monthly package nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...store.monthlyPackages.map((mp) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading:
                    const Icon(Icons.calendar_month, color: Brand.green),
                title: Text('${mp.pickup} → ${mp.drop}'),
                subtitle: Text(
                    '${mp.passengerName.isEmpty ? 'Sawari' : mp.passengerName} · ${mp.vehicle} · ${mp.days} din'),
                trailing: Text(rs(mp.monthlyAmount),
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            )),
        const SizedBox(height: 20),
        const Text('Hisab Kitab (Ledger)',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.txns.isEmpty)
          const Text('Abhi koi entry nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...store.txns.map((t) {
          final isDeposit = t.type == 'deposit';
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Icon(
                isDeposit ? Icons.arrow_downward : Icons.percent,
                color: isDeposit ? Brand.green : Brand.ajrakRed,
              ),
              title: Text(isDeposit
                  ? 'Deposit — ${t.method}'
                  : 'Service charges ${fmtPct(Fares.feePercent)}'),
              subtitle: Text('${t.note}\n${fmtDate(t.date)} ${fmtTime(t.date)}'),
              isThreeLine: true,
              trailing: Text(
                isDeposit ? '+ ${rs(t.amount)}' : '− ${rs(t.amount)}',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: isDeposit ? Brand.green : Brand.ajrakRed,
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  // --- PROFILE -----------------------------------------------------------------

  late final TextEditingController _nameCtrl =
      TextEditingController(text: p.name);
  late final TextEditingController _phoneCtrl =
      TextEditingController(text: p.phone);
  late final TextEditingController _plateCtrl =
      TextEditingController(text: p.plate);

  Widget _profileView() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('Driver Profile',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        // Master tasdeeq ki haalat — backend drivers.active se ati hai.
        // Profile Save = registration (pending); Master ACTIVE kare to
        // ye card badal jata hai. Refresh se foran nayi haalat pull.
        Card(
          color: p.masterActive ? Brand.deepGreen : null,
          child: ListTile(
            leading: Icon(
              p.masterActive ? Icons.verified : Icons.pending_actions,
              color: p.masterActive ? Brand.gold : Brand.ajrakRed,
            ),
            title: Text(
              p.masterActive
                  ? 'Account ACTIVE hai'
                  : 'Account PENDING hai',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                color: p.masterActive ? Colors.white : null,
              ),
            ),
            subtitle: Text(
              p.masterActive
                  ? 'Master ne tasdeeq kar di hai — aap ka account online system mein active hai.'
                  : 'Profile Save karna hi registration hai. Master ki tasdeeq ke baad account active hoga.',
              style: TextStyle(
                color: p.masterActive ? Colors.white70 : null,
              ),
            ),
            trailing: IconButton(
              icon: Icon(Icons.refresh,
                  color: p.masterActive ? Brand.gold : Brand.green),
              tooltip: 'Status refresh karein',
              onPressed: () async {
                await Backend.refreshDriverStatus(store);
                if (mounted) setState(() {});
              },
            ),
          ),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _nameCtrl,
          decoration: const InputDecoration(
              labelText: 'Driver ka naam', prefixIcon: Icon(Icons.person)),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _phoneCtrl,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
              labelText: 'Mobile number (call/WhatsApp ke liye)',
              prefixIcon: Icon(Icons.phone)),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _plateCtrl,
          decoration: const InputDecoration(
              labelText: 'Gaari ka number plate',
              prefixIcon: Icon(Icons.pin)),
        ),
        const SizedBox(height: 10),
        const Text('Gaari', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: kVehicles
              .map((v) => ChoiceChip(
                    label: Text(v),
                    selected: p.vehicle == v,
                    onSelected: (_) => setState(() => p.vehicle = v),
                  ))
              .toList(),
        ),
        const SizedBox(height: 10),
        const Text('Ilaqa (Zone)',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          value: kZones.contains(p.zone) ? p.zone : 'Liaquatabad',
          items: kZones
              .map((z) => DropdownMenuItem(value: z, child: Text(z)))
              .toList(),
          onChanged: (v) => setState(() => p.zone = v ?? p.zone),
          decoration: const InputDecoration(labelText: 'Zone'),
        ),
        const SizedBox(height: 18),
        const Text('Documents ki Tasdeeq',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        const Text('CNIC lazmi hai. Licence ikhtiyari hai — na ho to koi baat nahi.',
            style: TextStyle(fontSize: 12, color: Colors.black54)),
        const SizedBox(height: 10),
        _docRow(
          'CNIC',
          p.cnicStatus == 'verified',
          (v) => p.cnicStatus = v ? 'verified' : 'pending',
        ),
        _docRow(
          'Gaari ke kagazat (Registration)',
          p.vehiclePapers == 'verified',
          (v) => p.vehiclePapers = v ? 'verified' : 'pending',
        ),
        const SizedBox(height: 10),
        const Text('Driving Licence',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: [
            ChoiceChip(
              label: const Text('Licence hai'),
              selected: p.licenceStatus == 'has',
              onSelected: (_) => setState(() => p.licenceStatus = 'has'),
            ),
            ChoiceChip(
              label: const Text('Licence nahi hai'),
              selected: p.licenceStatus == 'none',
              onSelected: (_) => setState(() {
                p.licenceStatus = 'none';
                p.licenceVerified = false;
              }),
            ),
          ],
        ),
        if (p.licenceStatus == 'has') ...[
          const SizedBox(height: 8),
          _docRow(
            'Licence Tasdeeq',
            p.licenceVerified,
            (v) => p.licenceVerified = v,
          ),
        ] else
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text(
              'Licence nahi hai — CNIC se kaam chal jayega.',
              style: TextStyle(fontSize: 13, color: Colors.black54),
            ),
          ),
        const SizedBox(height: 18),
        Card(
          child: ListTile(
            leading: Icon(Icons.camera_alt,
                color: p.selfieToday ? Brand.green : Brand.ajrakRed),
            title: const Text('Rozana Live Selfie'),
            subtitle: Text(p.selfieToday
                ? 'Aaj ki selfie ho gayi (${p.selfieDate})'
                : 'Aaj ki selfie baqi hai — camera se hi hogi, gallery se nahi'),
            trailing: p.selfieToday
                ? const Icon(Icons.check_circle, color: Brand.green)
                : ElevatedButton(
                    onPressed: _takeSelfie,
                    child: const Text('Selfie Lein'),
                  ),
          ),
        ),
        // NOTE (v1.0.5): "Service Charges %" editor HATA diya gaya hai —
        // fee sirf Master app mein set hoti hai; is app mein woh khamosh
        // internal hissaab hai, koi option nahi.
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () async {
              p.name = _nameCtrl.text.trim().isEmpty
                  ? p.name
                  : _nameCtrl.text.trim();
              p.phone = _phoneCtrl.text.trim();
              p.plate = _plateCtrl.text.trim();
              await store.save();
              if (mounted) {
                _snack('Profile save ho gaya.');
                setState(() {});
              }
            },
            child: const Text('Profile Save Karein'),
          ),
        ),
      ],
    );
  }

  Widget _docRow(String label, bool verified, void Function(bool) onChanged) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(verified ? Icons.verified : Icons.pending_actions,
            color: verified ? Brand.green : Brand.ajrakRed),
        title: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(verified ? 'Verified' : 'Pending'),
        trailing: Wrap(
          spacing: 6,
          children: [
            ChoiceChip(
              label: const Text('Verified'),
              selected: verified,
              onSelected: (_) => setState(() => onChanged(true)),
            ),
            ChoiceChip(
              label: const Text('Pending'),
              selected: !verified,
              onSelected: (_) => setState(() => onChanged(false)),
            ),
          ],
        ),
      ),
    );
  }

}

/// Live waiting display for an arrived ride: minutes ticking + current charge.
class _LiveWaiting extends StatefulWidget {
  final Booking booking;
  final AppStore store;
  const _LiveWaiting({required this.booking, required this.store});

  @override
  State<_LiveWaiting> createState() => _LiveWaitingState();
}

class _LiveWaitingState extends State<_LiveWaiting> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final mins = widget.store.liveWaitingMinutes(b);
    final charge = widget.store.liveWaitingCharge(b);
    final freeLeft = Fares.freeWaitingMinutes - mins;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Brand.cream,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Brand.gold),
      ),
      child: Row(
        children: [
          const Icon(Icons.timer, color: Brand.ajrakRed),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Intezaar: $mins minute',
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 15)),
                Text(
                  freeLeft > 0
                      ? 'Abhi $freeLeft minute muft baqi hain'
                      : 'Waiting charges ab tak: ${rs(charge)}',
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
          if (charge > 0)
            Text(rs(charge),
                style:
                    const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        ],
      ),
    );
  }
}

