import 'dart:async';
import 'package:flutter/material.dart';
import 'backend.dart';
import 'store.dart';
import 'theme.dart';

/// RIDE CHAT (v1.4.16) — passenger ↔ driver ki ACTIVE ride ke
/// andar wali chat (backend table `ride_messages`, mukammal
/// package ki 01-ride-chat.sql)।
///
/// DESIGN LOCKS (owner ke qawaneen):
/// - Chat SIRF active ride (accepted/arrived) ke liye khulti hai;
///   ride completed/cancelled ho to chat band — purani history
///   record ke tor par server par rehti hai (saboot)।
/// - NUMBER KABHI SHARE NAHI hota — chat hi wahid rabta hai।
/// - Sirf USI ride ke do fareeq: ye screen sirf apni ride ki
///   booking se khulti hai, fetch sirf usi ride_id ka hota hai,
///   aur bhejte waqt sender meri apni pehchan (sawari = deviceId,
///   driver = driverId) hoti hai — teesra banda is chat mein
///   na parh sakta hai na likh sakta hai (data-access qanoon)।
/// - Khuli chat har ~12 second khud refresh hoti hai.
///   v1.4.17 se bheje gaye message par doosre fareeq ko FCM
///   push ki koshish bhi hoti hai (Backend.invokePush —
///   'send-push' function deploy hone par foran khabar;
///   tab tak refresh wala rasta hi asal hai)।
/// - Server/table/policy ki kisi nakami par chat khamoshi se
///   "dastiyab nahi" dikhati hai — app crash NAHI hoti; call
///   aur SOS ke raste waise hi chalte rehte hain।

/// Sawari ke tayyar (preset) messages।
const List<String> kPassengerQuickMessages = [
  'Main bahar khara/khari hun',
  'Thoda intezaar karein',
  'Main aa raha/rahi hun',
  'Main pickup par nazar aa raha/rahi hun',
  'Gaari nazar aa gayi hai, main aa raha/rahi hun',
];

/// Driver ke tayyar (preset) messages — 'Main Pahunch Gaya' in
/// ke ilawa ALAG bara button hai (kind='arrival')।
const List<String> kDriverQuickMessages = [
  'Main raste mein hun',
  'Main 2 minute mein pohanch raha hun',
  'Main pickup ke qareeb hun',
  'Traffic hai, thoda waqt lagega',
  'Main wohi jagah khara hun jahan pin hai',
];

class RideChatScreen extends StatefulWidget {
  final AppStore store;
  final Booking booking;

  /// 'passenger' | 'driver' — kis mode se chat khuli hai।
  final String role;

  const RideChatScreen({
    super.key,
    required this.store,
    required this.booking,
    required this.role,
  });

  @override
  State<RideChatScreen> createState() => _RideChatScreenState();
}

class _RideChatScreenState extends State<RideChatScreen> {
  final _textCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final List<RideMessage> _messages = [];
  Timer? _timer;
  bool _sending = false;

  /// Server se pehla jawab aya ya nahi — null jawab (table /
  /// policy / network nakami) par chat "dastiyab nahi" dikhati
  /// hai lekin koshish jaari rehti hai।
  bool _serverOk = false;
  bool _loaded = false;

  AppStore get store => widget.store;
  Booking get b => widget.booking;
  bool get _isDriver => widget.role == 'driver';

  /// Meri pehchan is chat mein: sawari = deviceId, driver =
  /// driverId (ride_messages.sender_id ki design ke ain mutabiq)।
  String get _myId => _isDriver ? store.driverId : store.deviceId;
  String get _myKind => _isDriver ? 'driver' : 'passenger';

  /// Ride abhi chat ke qabil hai ya nahi (sirf accepted/arrived)।
  bool get _rideActive => b.status == 'accepted' || b.status == 'arrived';

  /// PEHCHAN KI SARHAD: driver side par chat sirf tab jab ye ride
  /// asal mein MERI hai — assigned driver main hi hun, ya isi
  /// phone par accept hui thi (same-device pilot)। Sawari side
  /// par bookings hamesha meri apni hoti hain (mere device ki
  /// rides hi store mein hain)।
  bool get _rideIsMine {
    if (!_isDriver) return true;
    if (b.acceptedHere) return true;
    return b.assignedDriverId.isNotEmpty &&
        b.assignedDriverId == store.driverId;
  }

  @override
  void initState() {
    super.initState();
    unawaited(_refresh());
    _timer = Timer.periodic(const Duration(seconds: 12), (_) {
      unawaited(_refresh());
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _textCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  /// Server se is ride ki poori chat lana aur local list se
  /// milana — meri bheji hui jo messages abhi server par darj
  /// nahi ho sakin (sent=false) woh list se NAHI girtin।
  Future<void> _refresh() async {
    if (!_rideIsMine) return;
    final rows = await Backend.fetchRideMessages(b.id);
    if (!mounted) return;
    setState(() {
      _loaded = true;
      if (rows != null) {
        _serverOk = true;
        final serverIds = rows.map((m) => m.id).toSet();
        final pendingMine =
            _messages.where((m) => !m.sent && !serverIds.contains(m.id));
        _messages
          ..clear()
          ..addAll(rows)
          ..addAll(pendingMine);
        _messages.sort((a, c) => a.createdAt.compareTo(c.createdAt));
      }
    });
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  /// Ek message bhejna (text / quick / arrival) — pehle local
  /// list mein optimistically ata hai, server par darj ho to
  /// sent=true; na ho to sent=false ke saath wahin rehta hai
  /// aur agli refresh par dobara koshish nahi hoti (duplicate
  /// rokne ke liye) — user khud dobara bhej sakta hai।
  Future<void> _send(String body, String kind) async {
    final text = body.trim();
    if (text.isEmpty || _sending) return;
    if (!_rideActive) {
      _snack('Ride khatam ho chuki hai — chat band hai.');
      return;
    }
    if (_myId.isEmpty) {
      _snack('Pehchan nahi mili — app dobara khol kar koshish karein.');
      return;
    }
    final m = RideMessage(
      id: Backend.newUuid(),
      rideId: b.id,
      senderKind: _myKind,
      senderId: _myId,
      kind: kind,
      body: text,
      createdAt: DateTime.now(),
      sent: false,
    );
    setState(() {
      _sending = true;
      _messages.add(m);
    });
    _scrollToBottom();
    final ok = await Backend.sendRideMessage(m);
    if (!mounted) return;
    setState(() {
      _sending = false;
      m.sent = ok;
      if (ok) _serverOk = true;
    });
    // v1.4.17 FCM: message server tak gaya to doosre fareeq ki
    // device par foran ghanti (chat khuli na ho tab bhi khabar
    // mile). 'arrival' kind yahan skip hai — us ki khabar
    // _sendArrival apne khaas push se deta hai (double nahi)।
    // Fire-and-forget; function deploy na ho to khamosh aur
    // chat ka ~12s refresh wala rasta barkarar hai।
    if (ok && kind != 'arrival') {
      unawaited(_pushChatToOther(text));
    }
    if (!ok) {
      _snack(
          'Message server tak nahi gaya — internet check karein. Call/SOS ka rasta khula hai.');
    }
  }

  /// v1.4.17 FCM: chat message ki push doosre fareeq ko —
  /// driver likhe to sawari ki device, sawari likhe to driver
  /// ki bandhi device. Device na mile to khamosh skip।
  Future<void> _pushChatToOther(String text) async {
    var targetDev = '';
    if (_isDriver) {
      targetDev = await Backend.fetchPassengerDeviceId(
          rideId: b.id, passengerPhone: b.passengerPhone);
    } else if (b.assignedDriverId.isNotEmpty) {
      targetDev = await Backend.fetchDriverDeviceId(b.assignedDriverId);
    }
    if (targetDev.isEmpty) return;
    final short =
        text.length > 80 ? '${text.substring(0, 80)}…' : text;
    await Backend.invokePush({
      'audience': 'device',
      'device_id': targetDev,
      'title': _isDriver ? 'Driver ka message' : 'Sawari ka message',
      'body': short,
      'data': {'ride_id': b.id},
    });
  }

  /// Driver ka khaas BARA button: 'Main Pahunch Gaya' —
  /// chat mein kind='arrival' message jata hai AUR ride ki
  /// asal haalat bhi 'arrived' ho jati hai (waiting timer wala
  /// wohi purana amal — store.markArrived)।
  Future<void> _sendArrival() async {
    if (b.status == 'accepted') {
      await _send('Main Pahunch Gaya', 'arrival');
      await store.markArrived(b);
      // v1.4.17 FCM: sawari ko arrival ki foran khabar।
      unawaited(Backend.pushDriverArrived(b));
      if (mounted) setState(() {});
    } else {
      await _send('Main Pahunch Gaya', 'arrival');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isDriver ? 'Sawari se Chat' : 'Driver se Chat'),
        actions: [
          IconButton(
            tooltip: 'Chat refresh karein',
            icon: const Icon(Icons.refresh),
            onPressed: () => unawaited(_refresh()),
          ),
        ],
      ),
      body: !_rideIsMine
          ? const Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                'Ye ride aap ki nahi hai — is ki chat aap ko nahi khul sakti.',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              ),
            )
          : Column(
              children: [
                Container(
                  width: double.infinity,
                  color: Brand.cream,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  child: Text(
                    '${b.pickupLabel}  →  ${b.dropLabel}\n'
                    'Number share nahi hota — baat sirf is chat se hoti hai. '
                    'Chat ride khatam hone par band ho jati hai.',
                    style:
                        const TextStyle(fontSize: 12, color: Colors.black87),
                  ),
                ),
                if (!_rideActive)
                  Container(
                    width: double.infinity,
                    color: const Color(0xFFF3E9C8),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 8),
                    child: const Text(
                      'Ride khatam ho gayi hai — chat band hai. Purani baat record mein mehfooz hai.',
                      style: TextStyle(
                          fontSize: 12.5, fontWeight: FontWeight.w700),
                    ),
                  ),
                Expanded(child: _messageList()),
                if (_rideActive) _composer(),
              ],
            ),
    );
  }

  Widget _messageList() {
    if (!_loaded) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_messages.isEmpty) {
      return Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          _serverOk
              ? 'Abhi is ride par koi message nahi — pehla message neeche se bhejein.'
              : 'Abhi chat server se rabta nahi ho pa raha — internet check karein. '
                  'Zarurat ho to call ya SOS ka button istemal karein; chat khud theek hote hi messages yahan ajayenge.',
          style: const TextStyle(color: Colors.black54, fontSize: 13.5),
        ),
      );
    }
    return ListView.builder(
      controller: _scrollCtrl,
      padding: const EdgeInsets.all(14),
      itemCount: _messages.length,
      itemBuilder: (context, i) => _bubble(_messages[i]),
    );
  }

  /// Ek bubble: mera message DAYEIN sabz mein; dusre fareeq ka
  /// BAYEIN cream mein; 'arrival' (Main Pahunch Gaya) aur system
  /// events darmiyan mein khaas chip ki shakal mein — taaki dono
  /// ko door se nazar aye ke driver pohanch gaya hai।
  Widget _bubble(RideMessage m) {
    final mine = m.senderKind == _myKind && m.senderId == _myId;
    final time = fmtTime(m.createdAt);
    if (m.kind == 'arrival' || m.senderKind == 'system') {
      return Center(
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: m.kind == 'arrival'
                ? const Color(0xFFF3E9C8)
                : const Color(0xFFECEFF1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
                color: m.kind == 'arrival' ? Brand.gold : Colors.black26),
          ),
          child: Text(
            m.kind == 'arrival' ? '📍 ${m.body}' : m.body,
            style: const TextStyle(
                fontSize: 13.5, fontWeight: FontWeight.w800),
          ),
        ),
      );
    }
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(bottom: 10, left: mine ? 46 : 0, right: mine ? 0 : 46),
        padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
        decoration: BoxDecoration(
          color: mine ? const Color(0xFFE7F2EC) : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(14),
            topRight: const Radius.circular(14),
            bottomLeft: Radius.circular(mine ? 14 : 3),
            bottomRight: Radius.circular(mine ? 3 : 14),
          ),
          border: Border.all(color: Colors.black12),
        ),
        child: Column(
          crossAxisAlignment:
              mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Text(m.body, style: const TextStyle(fontSize: 14.5)),
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(time,
                    style:
                        const TextStyle(color: Colors.black45, fontSize: 10.5)),
                if (mine) ...[
                  const SizedBox(width: 5),
                  Icon(m.sent ? Icons.done : Icons.schedule,
                      size: 13,
                      color: m.sent ? Brand.green : Brand.ajrakRed),
                  const SizedBox(width: 3),
                  Text(m.sent ? 'Bhej diya' : 'Nahi gaya',
                      style: TextStyle(
                          color: m.sent ? Brand.green : Brand.ajrakRed,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w700)),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// Neeche wala hissa: driver ke liye BARA 'Main Pahunch Gaya'
  /// button (sirf arrived se pehle), tayyar messages ki chips,
  /// aur free-text likhne ki jagah + bhejne ka button।
  Widget _composer() {
    final quicks = _isDriver ? kDriverQuickMessages : kPassengerQuickMessages;
    return SafeArea(
      child: Container(
        color: Colors.white,
        padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (_isDriver && b.status == 'accepted') ...[
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _sending ? null : _sendArrival,
                  icon: const Icon(Icons.location_on, size: 20),
                  label: const Text('Main Pahunch Gaya',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Brand.green,
                    padding: const EdgeInsets.symmetric(vertical: 13),
                  ),
                ),
              ),
              const SizedBox(height: 8),
            ],
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  for (final q in quicks)
                    Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: ActionChip(
                        label: Text(q, style: const TextStyle(fontSize: 12.5)),
                        onPressed:
                            _sending ? null : () => unawaited(_send(q, 'quick')),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _textCtrl,
                    minLines: 1,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      hintText: 'Message likhein…',
                      isDense: true,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  tooltip: 'Bhejein',
                  onPressed: _sending
                      ? null
                      : () {
                          final t = _textCtrl.text;
                          _textCtrl.clear();
                          unawaited(_send(t, 'text'));
                        },
                  icon: const Icon(Icons.send, color: Brand.green),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Active ride par chat ka DARWAZA (button) — passenger aur
/// driver dono ki active-ride screens isi ko istemal karti hain
/// taaki shakl-o-soorat har jagah ek jaisi rahe।
class RideChatButton extends StatelessWidget {
  final AppStore store;
  final Booking booking;
  final String role; // 'passenger' | 'driver'

  const RideChatButton({
    super.key,
    required this.store,
    required this.booking,
    required this.role,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: () {
          Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => RideChatScreen(
              store: store,
              booking: booking,
              role: role,
            ),
          ));
        },
        icon: const Icon(Icons.chat_bubble_outline, size: 18),
        label: Text(role == 'driver' ? 'Sawari se Chat' : 'Driver se Chat'),
        style: OutlinedButton.styleFrom(
          foregroundColor: Brand.green,
          side: const BorderSide(color: Brand.green, width: 1.2),
          padding: const EdgeInsets.symmetric(vertical: 10),
          textStyle:
              const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}
