package com.bozdar.safar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
