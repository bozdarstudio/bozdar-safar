import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart' as ll2;
import 'package:url_launcher/url_launcher.dart';
import 'store.dart';
import 'theme.dart';
import 'route_service.dart';
import 'agent_section.dart';
import 'legal.dart';
import 'safar_map.dart';
import 'photo_pin.dart';
import 'backend.dart';
import 'duty_service.dart';
import 'registration.dart';
import 'guide_audio.dart';
import 'messages.dart';
import 'health_engine.dart';
import 'ride_chat.dart';
import 'lang.dart';
import 'display_prefs.dart';
import 'notifications.dart';
import 'otp.dart';
import 'selfie_gate.dart';
import 'vehicle_change.dart';
import 'pool_filter.dart';
import 'profile_photo.dart';
import 'main.dart' show ModeToggleButton, UpdateBanner;
import 'passenger.dart' show kStatusUrdu;

class DriverSide extends StatefulWidget {
  final AppStore store;
  final VoidCallback onSwitchToPassenger;
  const DriverSide(
      {super.key, required this.store, required this.onSwitchToPassenger});

  @override
  State<DriverSide> createState() => _DriverSideState();
}

class _DriverSideState extends State<DriverSide>
    with NotificationBannerMixin {
  int _tab = 0; // 0 Home | 1 Pool | 2 Bookings | 3 Wallet | 4 Profile
  final ImagePicker _picker = ImagePicker();

  // v1.4.0 two-phone live dispatch: duty ke doran location timer —
  // har ~20 second GPS le kar backend drivers row (lat/lng/loc_at)
  // aur chal rahi ride ke row (driver_lat/lng) ko taaza rakhta hai.
  Timer? _dutyTimer;
  bool _dutyTickBusy = false;

  // v1.4.32 PHOTO-PIN: har active ride ki sawari ka photo-pin
  // (ride id → tayyar PNG) — nav map par pickup wale maqam par
  // dikhta hai. Ek ride ke liye sirf ek dafa banta hai
  // (PhotoPin ka cache alag bhi hai); card sirf tab milta hai
  // jab ye driver us ride ka assign driver ho (passenger_card
  // RPC, v149) — doosri rides ki photo kabhi NAHI ati.
  final Map<String, Uint8List> _passengerPins = {};
  final Set<String> _pinLoading = {};

  Future<void> _ensurePassengerPin(Booking b) async {
    if (b.status != 'accepted' && b.status != 'arrived') return;
    if (_passengerPins.containsKey(b.id) || _pinLoading.contains(b.id)) {
      return;
    }
    _pinLoading.add(b.id);
    try {
      final card = await Backend.fetchPassengerCard(b.id);
      final path = card?['profile_photo_path'] as String? ?? '';
      final png = await PhotoPin.load(
          bucket: 'selfies', path: path, name: b.passengerName);
      if (png != null && mounted) {
        setState(() => _passengerPins[b.id] = png);
      }
    } finally {
      _pinLoading.remove(b.id);
    }
  }

  // v1.4.2: backend Pool feed ka timer — har ~15 second backend se
  // pending rides ki taaza list (ONLINE ho ya OFFLINE, Pool dono
  // haalton mein khulta hai). Isi ke saath offline reh gayi booking
  // pushes (outbox) ki dobara koshish bhi hoti hai.
  Timer? _poolTimer;

  // v1.4.7 SELFIE DEMANDS (spec §2): random schedule ki jaanch +
  // complaint demands ka backend poll — har ~45 second. Gate page
  // khula ho to dobara nahi khulta.
  Timer? _selfieTimer;
  bool _selfieGateOpen = false;
  bool _selfiePollBusy = false;

  // Driver ki apni mojooda jagah — har ride ki pickup-doori ginne aur
  // 2 km radius filter (kDriverPickupRadiusKm) ke liye. Best-effort hai:
  // ijazat/location na mile to _myPos null rehta hai aur us surat mein
  // filter NAHI lagta (saari rides dikhti hain, doori wali line par
  // "location off hai" likha aata hai) — pilot band nahi hota.
  ll2.LatLng? _myPos;
  bool _locBusy = false;

  /// Registration wizard is app session mein khud khula ya nahi —
  /// dobara dobara khud nahi khulta (Home/Profile par us ka card
  /// button hamesha maujood hai).
  bool _wizardPrompted = false;

  /// FINAL-PACK A2 (REJECT AWAAZ): rejected documents ke set ka
  /// aakhri announce shuda signature (group names ki jod, misal
  /// 'cnic,gaari,selfie'). Signature wohi rahe to awaaz DOBARA
  /// nahi bajti — har rebuild / har Profile visit par repeat
  /// mana hai; set badle (naya reject ya resubmit) to naya
  /// signature banta hai.
  String _lastRejectSig = '';

  AppStore get store => widget.store;
  DriverProfile get p => store.profile;

  // v1.4.27 (#23): ghanti/push par tap → ride ki darkhwast
  // (rideOpenSignal)। Ride Pool mein khadi ho to Pool tab,
  // driver ki apni bookings mein ho to Bookings tab khul
  // jata hai। Cold start wali darkhwast initState ke aakhir
  // mein ek dafa jaanchi jati hai।
  int _rideOpenSeenSeq = 0;

  void _onRideOpenRequest() {
    final seq = rideOpenSignal.seq;
    if (seq == _rideOpenSeenSeq) return;
    _rideOpenSeenSeq = seq;
    final id = rideOpenSignal.rideId;
    if (id == null || !mounted) return;
    if (store.remotePool.any((b) => b.id == id)) {
      rideOpenSignal.consume();
      setState(() => _tab = 1);
    } else if (store.bookings.any((b) => b.id == id)) {
      rideOpenSignal.consume();
      setState(() => _tab = 2);
    }
  }

  @override
  void dispose() {
    rideOpenSignal.removeListener(_onRideOpenRequest);
    cancelNotificationBanners();
    _dutyTimer?.cancel();
    _poolTimer?.cancel();
    _selfieTimer?.cancel();
    super.dispose();
  }

  /// v1.4.7: selfie demands ki ek jaanch — (1) complaint demands
  /// ka backend poll (driver_selfies ki baqi rows), (2) duty par
  /// ho to random schedule ka waqt, (3) demand ho to gate page।
  /// Chalti ride ke beech random demand NAHI khulti (safety) —
  /// store.dueRandomSelfie yehi shart rakhta hai; complaint
  /// demand ride ke beech bhi NAHI rokti, woh ride ke baad ke
  /// gate par ati hai (poll use darj kar deta hai, gate tab
  /// khulta hai jab koi active ride na ho — neeche wali shart)।
  Future<void> _selfieCheck() async {
    if (_selfiePollBusy || !mounted) return;
    if (store.driverId.isEmpty || !p.registrationComplete) return;
    _selfiePollBusy = true;
    try {
      final onRideNow = store.bookings.any(
          (b) => b.status == 'accepted' || b.status == 'arrived');
      if (store.currentSelfieDemand == null) {
        final pending = await Backend.fetchPendingSelfieDemands(
            store.driverId);
        if (pending != null && pending.isNotEmpty) {
          final r = pending.first;
          store.setSelfieDemand(SelfieDemand(
            kind: (r['kind'] as String?) ?? 'random',
            date: (r['date'] as String?) ?? AppStore.todayKey(),
            complaintId: (r['complaint_id'] as String?) ?? '',
          ));
        }
      }
      if (store.currentSelfieDemand == null && p.online) {
        await store.ensureRandomSelfieSchedule();
        final due = store.dueRandomSelfie(onRideNow: onRideNow);
        if (due != null) {
          store.setSelfieDemand(due);
          unawaited(Backend.insertSelfieDemand(
            driverId: store.driverId,
            date: due.date,
            kind: 'random',
          ));
        }
      }
      if (store.currentSelfieDemand != null && !onRideNow) {
        await _maybeOpenSelfieGate();
      }
    } catch (_) {
      // Selfie jaanch ki nakami khamosh — agli tick dobara hogi।
    } finally {
      _selfiePollBusy = false;
    }
  }

  Future<void> _maybeOpenSelfieGate() async {
    if (_selfieGateOpen || !mounted) return;
    final demand = store.currentSelfieDemand;
    if (demand == null) return;
    _selfieGateOpen = true;
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => SelfieGatePage(store: store, demand: demand),
    ));
    _selfieGateOpen = false;
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    rideOpenSignal.addListener(_onRideOpenRequest);
    WidgetsBinding.instance
        .addPostFrameCallback((_) => _onRideOpenRequest());
    _refreshMyLocation();
    // v1.4.0: foreground notification banners + elanaat pull +
    // apna rating ausat (Profile ke liye) + duty location timer.
    listenNotificationBanners(store);
    unawaited(Backend.syncFeeSettlements(store));
    unawaited(Backend.syncAmanatDeposits(store));
    unawaited(Backend.refreshAnnouncements(store));
    unawaited(Backend.pullOwnRatingAverage(store));
    unawaited(store.observeBookingStatuses('driver'));
    _dutyTimer = Timer.periodic(
        const Duration(seconds: 20), (_) => unawaited(_dutyTick()));
    // v1.4.2: Pool feed foran + har ~15s — doosre phones ki rides
    // ab asal mein is phone tak pohanchti hain (dispatch fix #1).
    unawaited(Backend.refreshRemotePool(store));
    _poolTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      unawaited(Backend.refreshRemotePool(store));
      unawaited(Backend.syncRideOutbox(store));
      // LIVE CHAT: Master ke jawabat bhi isi chakkar se ate hain
      // (naya jawab = store notification + banner + Madad badge).
      unawaited(Backend.syncMessages(store));
    });
    // v1.4.7: selfie demands ka timer — pehli jaanch foran,
    // phir har ~45 second (random waqt + complaint poll)।
    _selfieTimer = Timer.periodic(
        const Duration(seconds: 45), (_) => unawaited(_selfieCheck()));
    WidgetsBinding.instance
        .addPostFrameCallback((_) => unawaited(_selfieCheck()));
    // v1.4.5: app dobara khuli aur driver pehle se ONLINE hai
    // (duty ki haalat mehfooz rehti hai) to duty service bhi
    // dobara chalu — warna app restart ke baad khabar band rehti.
    if (p.online) unawaited(_syncDutyService());
    // Registration baqi ho to Driver Mode mein ate hi Yango-style
    // registration form khud khul jata hai (ek dafa, is session mein).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // FINAL-PACK A2: DriverSide pehle se Profile tab par khule
      // (tab ki haalat mehfooz ho) to reject awaaz yahin se baje.
      if (mounted && _tab == 4) _announceRejectedDocs();
      // HOTFIX v1.2.9 (RC2): gate ab registrationComplete par hai —
      // legacy profile (sirf naam+mobile, photos nahi) bhi wizard
      // mein jayega taaki baqi documents jama ho jayen.
      if (mounted && !p.registrationComplete && !_wizardPrompted) {
        _wizardPrompted = true;
        _openRegistration();
      }
    });
  }

  /// Duty location timer ka ek chakkar (v1.4.0): driver ONLINE ho
  /// to GPS le kar —
  ///  1) store.noteDriverLocation drivers row par lat/lng/loc_at
  ///     PATCH karwata hai (halki si, sirf location);
  ///  2) agar koi ride chal rahi hai (accepted/arrived) to us ke
  ///     backend row par driver_lat/driver_lng bhi likhta hai,
  ///     taaki passenger ke phone par ETA taaza rahe.
  /// Offline ho to kuch nahi hota. Har nakami khamosh.
  Future<void> _dutyTick() async {
    if (_dutyTickBusy || !p.online) return;
    final last = store.lastLocationPushAt;
    // v1.4.32 LIVE: active ride chal rahi ho to push ka waqfa
    // 15s ki bajaye ~3s — sawari ko driver ki jagah takreeban
    // LIVE mile. Aam duty par purana 15s waqfa hi hai (battery/
    // data ki bachat); nav view ki har GPS harkat bhi yahi
    // tick bulati hai, ye gate hi asal hadd hai।
    final hasActiveRide = store.bookings
        .any((b) => b.status == 'accepted' || b.status == 'arrived');
    final minGapSec = hasActiveRide ? 3 : 15;
    if (last != null &&
        DateTime.now().difference(last).inSeconds < minGapSec) {
      return;
    }
    _dutyTickBusy = true;
    try {
      double? lat, lng;
      final pos = await Geolocator.getLastKnownPosition();
      if (pos != null) {
        lat = pos.latitude;
        lng = pos.longitude;
      }
      final fresh = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      lat = fresh.latitude;
      lng = fresh.longitude;
      store.noteDriverLocation(lat, lng);
      if (mounted) {
        setState(() => _myPos = ll2.LatLng(lat!, lng!));
      }
      final actives = store.bookings
          .where((b) => b.status == 'accepted' || b.status == 'arrived')
          .toList();
      for (final b in actives) {
        await Backend.pushRideDriverPosition(store, b.id, lat, lng);
      }
    } catch (_) {
      // Khamosh — GPS na mile to agla chakkar dobara koshish karega.
    } finally {
      _dutyTickBusy = false;
    }
  }

  /// Registration wizard (v1.2.6) full-screen kholna — Home aur
  /// Profile dono ke registration card yahin ate hain.
  Future<void> _openRegistration() async {
    await Navigator.of(context).push(
      MaterialPageRoute<bool>(
        builder: (_) => RegistrationWizard(store: store),
      ),
    );
    // Wizard band hone par sirf display taaza karna hai — Profile
    // mein ab koi editing controllers nahi hain (FORM USOOL
    // 2026-11-08: Profile sirf status + button hai), is liye koi
    // controller-sync ki zaroorat nahi.
    if (mounted) setState(() {});
  }

  /// Master ko Message screen (v1.2.7) — Profile se khulti hai.
  Future<void> _openMessages() async {
    await Navigator.of(context).push(
      MaterialPageRoute<bool>(
        builder: (_) => MasterMessagesScreen(store: store, role: 'driver'),
      ),
    );
    if (mounted) setState(() {});
  }

  /// DriverNavView (safar_map.dart) wala hi tareeqa: pehle last known,
  /// phir ek dafa ki taaza position. Koi stream nahi — Bookings tab
  /// khulne par dobara refresh ho jata hai. Har nakami khamosh hai.
  Future<void> _refreshMyLocation() async {
    if (_locBusy) return;
    _locBusy = true;
    try {
      final service = await Geolocator.isLocationServiceEnabled();
      if (!service) return;
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        return;
      }
      final last = await Geolocator.getLastKnownPosition();
      if (last != null && mounted) {
        setState(
            () => _myPos = ll2.LatLng(last.latitude, last.longitude));
        // Store mein bhi darj — passenger ki "driver kitni door hai"
        // wali line aur backend drivers.lat/lng isi se chalte hain.
        store.setDriverPosition(last.latitude, last.longitude);
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      if (mounted) {
        setState(() => _myPos = ll2.LatLng(pos.latitude, pos.longitude));
        store.setDriverPosition(pos.latitude, pos.longitude);
      }
    } catch (_) {
      // Khamosh — position na mile to filter nahi lagta.
    } finally {
      _locBusy = false;
    }
  }

  /// Booking ki pickup tak ki doori (km) driver ki apni jagah se.
  /// null = hisaab nahi ho sakta — ya driver ki position maloom nahi,
  /// ya booking ke paas pickup pin/coords hi nahi (0,0).
  double? _pickupDistanceKm(Booking b) {
    final pos = _myPos;
    if (pos == null) return null;
    if (b.pickupLat == 0 && b.pickupLng == 0) return null;
    return const ll2.Distance().as(ll2.LengthUnit.Kilometer, pos,
        ll2.LatLng(b.pickupLat, b.pickupLng));
  }

  /// Abhi available (pending) rides — is phone ki local bookings
  /// AUR backend Pool feed ki doosre phones wali rides, dono par
  /// POOL SARHADEIN (v1.4.27, postmortem #16 — pool_filter.dart):
  /// sirf apni gaari (vehicle) ki, apne sheher ki, aur doori gin
  /// sake to 2 km ke andar wali rides dikhti hain; doori na gin
  /// sake to ride dikhti hai lekin claim par rukawat ati hai
  /// (_accept mein poolClaimBlockReason)। Pool screen, Bookings
  /// ki incoming list aur nav badges teeno yahi ek list istemal
  /// karte hain (v1.4.2 dispatch fix: pehle sirf local list thi,
  /// is liye doosre phone ki ride driver tak pohanchti hi nahi thi).
  List<Booking> get _availableRides => [
        ...store.bookings.where((b) => b.status == 'pending'),
        ...store.remotePool,
      ]
          .where((b) => poolRideVisible(
                b,
                driverVehicle: store.profile.vehicle,
                driverZone: store.profile.zone,
                distanceKm: _pickupDistanceKm(b),
                radiusKm: store.profile.radiusKm,
              ))
          .toList();

  /// "Sawari kitni door hai" wali line — incoming aur active dono
  /// cards par. Location off ho to wohi saaf likha aata hai; pickup
  /// pin na ho to sirf pickup ka label/ilaqa dikhta hai.
  Widget _pickupDistanceLine(Booking b) {
    final String text;
    if (_myPos == null) {
      text = 'Sawari ki doori: location off hai';
    } else {
      final d = _pickupDistanceKm(b);
      text = d == null
          ? 'Sawari: ${b.pickupLabel}'
          : 'Sawari: ${d.toStringAsFixed(1)} km door';
    }
    return Row(
      children: [
        const Icon(Icons.near_me, size: 17, color: Brand.green),
        const SizedBox(width: 6),
        Expanded(
          child: Text(text,
              style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: Brand.greenDark)),
        ),
      ],
    );
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  /// FINAL-PACK A2 — REJECT AWAAZ (driver Profile): Profile tab
  /// khulte hi Master ke reject shuda documents ki rehnumai
  /// wali awaazein (GuideAudio) tartib se chalti hain:
  ///   cnic rejected    → reject_cnic_front + reject_cnic_back
  ///   gaari rejected   → reject_vehicle + reject_vehicle_reg
  ///   licence rejected → reject_licence
  ///   registration mukammal (flag) lekin profile selfie baqi
  ///                    → reject_selfie
  ///   PTA reject       → KOI line nahi (usool).
  /// Jo group driver ne dobara bhej diya ho (docGroupResubmitted)
  /// woh announce NAHI hota. Awaaz har dafa nahi bajti: rejected
  /// set ka signature [_lastRejectSig] mein rehta hai — wohi set
  /// dobara aye to khamoshi.
  void _announceRejectedDocs() {
    final clips = <String>[];
    final sigParts = <String>[];
    void addGroup(String group, List<String> groupClips) {
      if (p.masterStatusFor(group) == 'rejected' &&
          !p.docGroupResubmitted(group)) {
        clips.addAll(groupClips);
        sigParts.add(group);
      }
    }

    addGroup('cnic', const [
      'guidance/reject_cnic_front.mp3',
      'guidance/reject_cnic_back.mp3',
    ]);
    addGroup('gaari', const [
      'guidance/reject_vehicle.mp3',
      'guidance/reject_vehicle_reg.mp3',
    ]);
    addGroup('licence', const [
      'guidance/reject_licence.mp3',
    ]);
    // Selfie: registration ka flag mukammal ho lekin ID wali
    // profile photo hi na ho — ye registrationComplete getter se
    // NAHI parkha jata (us mein photo khud shart hai, woh kabhi
    // trigger hi na hota); flag + khaali path hi asal surat hai.
    if (p.registrationDone && p.profilePhotoPath.isEmpty) {
      clips.add('guidance/reject_selfie.mp3');
      sigParts.add('selfie');
    }
    // PTA reject par koi awaaz nahi — jaan boojh kar khaali.
    final sig = sigParts.join(',');
    if (sig == _lastRejectSig) return;
    _lastRejectSig = sig;
    if (clips.isEmpty) return;
    GuideAudio.playSequence(clips);
  }

  /// Duty on/off (v1.2.5 — malik ka hukm). Offline karna hamesha
  /// seedha hai. Online (duty) hone se pehle do darwaze hain:
  ///  1) PASSWORD: set na ho to pehle SET karna lazmi hai (backend
  ///     uniqueness check ke saath — ek password sirf ek driver ka);
  ///     set ho to is session mein ek dafa likhna lazmi hai; 5 ghalat
  ///     koshishon par 10 minute ka lockout.
  ///  2) ROZANA LIVE SELFIE: aaj ki selfie na ho to camera wahi
  ///     khulta hai — selfie ke baghair duty shuru nahi hoti.
  /// Dono pass hon tab hi online hota hai.
  /// v1.4.5 DUTY SERVICE ko duty ki haalat se jodna: online →
  /// foreground service (location + nayi ride ki ghanti, app band
  /// ho tab bhi); offline → service band. Notification ki ijazat
  /// (Android 13+) pehli dafa yahin mangi jati hai — na mile to
  /// wajah saaf bata kar service phir bhi chalu rehti hai (ghanti
  /// nahi bajegi, location chalega).
  Future<void> _syncDutyService({bool askPermission = false}) async {
    if (!p.online) {
      await DutyService.stop();
      return;
    }
    if (askPermission) {
      final granted = await DutyService.ensureNotificationPermission();
      if (!granted && mounted) {
        _snack(
            'Notification ki ijazat band hai — nayi ride ki ghanti nahi bajegi. Phone ki Settings se Bozdar Safar ki notifications ON karein.');
      }
    }
    await DutyService.startOrUpdate(
      mode: 'driver',
      driverId: store.driverId,
      radiusKm: store.profile.radiusKm,
      watch: DutyService.watchFromStore(store),
      title: 'Bozdar Safar — aap duty par hain',
      text: 'Nayi rides ki khabar aur aap ki location chal rahi hai',
    );
  }

  Future<void> _toggleOnline() async {
    if (p.online) {
      p.online = false;
      await store.save();
      unawaited(_syncDutyService());
      if (mounted) setState(() {});
      return;
    }
    // v1.4.7 SELFIE GATE (spec §2): demand baqi ho ya selfie
    // block laga ho to duty NAHI chalti — pehle selfie।
    if (p.selfieBlocked) {
      final mins = ((p.selfieBlockUntilMs -
                  DateTime.now().millisecondsSinceEpoch) /
              60000)
          .ceil();
      _snack(
          'Ghalat selfie ki wajah se ID abhi block hai — taqreeban $mins minute baqi hain.');
      return;
    }
    if (store.currentSelfieDemand != null) {
      _snack('Pehle live selfie dein — us ke baghair duty nahi chalegi.');
      unawaited(_maybeOpenSelfieGate());
      return;
    }
    // ID-ACTIVE GATE sab se pehle (v1.4.1 — Owner Tasdeeq Duty):
    // Master ki tasdeeq ke baghair driver ONLINE hi nahi ho sakta.
    // Khamosh nakami bilkul nahi — wajah wala tay shuda jumla
    // screen par saaf ata hai.
    if (!p.masterActive) {
      _snack('Aap ki ID abhi Master ki tasdeeq mein hai');
      return;
    }
    // v1.4.18 KAGAZ GATE (postmortem fix): ID active hone ke baad
    // Master kisi lazmi kagaz ko reject kar de (ya CNIC ki
    // tasdeeq adhoori reh jaye) to ONLINE hona band — pehle ye
    // haalat sirf "Mere Kagaz" mein dikhti thi, rok nahi thi.
    // Faisla taaza tareen haalat par ho: pehle status pull.
    await Backend.refreshDriverStatus(store);
    if (!mounted) return;
    setState(() {});
    final docBlock = store.docBlockReason();
    if (docBlock != null) {
      _snack(docBlock);
      return;
    }
    // NUMBER TABDEELI BLOCK (2026-11-08): number badla ho to
    // 12 ghante online hona band — baqi waqt paighaam mein hai.
    final numBlock = store.numberBlockReason();
    if (numBlock != null) {
      _snack(numBlock);
      return;
    }
    // DEVICE TABDEELI BLOCK (2026-11-08): doosri device par
    // account khula ho to 6 ghante online hona band.
    final devBlock = store.deviceBlockReason();
    if (devBlock != null) {
      _snack(devBlock);
      return;
    }
    // FEE HISAAB TAZA (naya usool 2026-11-10 19:32): Master ki
    // tasdeeq shuda settlements taaza kar lein taaki Wallet ka
    // hisaab durust rahe. Fee par ab koi BLOCK nahi hai —
    // feeBlockReason() hamesha null deta hai; ye check sirf
    // purane raste ki hifazat ke liye baqi hai.
    await Backend.syncFeeSettlements(store);
    if (!mounted) return;
    final feeBlock = store.feeBlockReason();
    if (feeBlock != null) {
      setState(() {});
      _snack(feeBlock);
      return;
    }
    // AMANAT GATE (v1.4.21 — malik ka faisla 2026-11-10 20:05):
    // Master-darj deposit jama taaza karke balance ki shart —
    // balance ≤ 0 ho to ONLINE nahi ho sakta; pehle Rs 500
    // top-up (wasool honay par Master darj karega).
    await Backend.syncAmanatDeposits(store);
    if (!mounted) return;
    final depBlock = store.depositBlockReason();
    if (depBlock != null) {
      setState(() {});
      _snack(depBlock);
      return;
    }
    // Lockout chalu ho to password ka darwaza hi band hai.
    if (p.pwdFp.isNotEmpty && p.pwdLocked) {
      final mins =
          ((p.pwdLockUntilMs - DateTime.now().millisecondsSinceEpoch) /
                  60000)
              .ceil();
      _snack(
          'Zyada ghalat koshishen — kuch der baad koshish karein (abhi $mins minute baqi hain).');
      return;
    }
    if (p.pwdFp.isEmpty) {
      final ok = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _SetPasswordDialog(store: store),
      );
      if (ok != true || !mounted) return;
      // RC2 follow-through (v1.2.9): naya password isi waqt backend
      // drivers row par bhi darj ho jaye taaki row phone se peeche
      // na reh jaye. Registration mukammal ho chuki ho to ensure
      // row ka bhi dobara jaiza — warna sirf fingerprint ki PATCH;
      // dono best-effort aur khamosh (duty flow nahi rukta).
      if (p.registrationComplete) {
        unawaited(Backend.ensureDriverRow(store));
      } else {
        unawaited(Backend.pushDriverFingerprint(store));
      }
    } else if (!store.dutyUnlocked) {
      final ok = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _AskPasswordDialog(store: store),
      );
      if (!mounted) return;
      if (ok != true) {
        if (p.pwdLocked) {
          _snack('Zyada ghalat koshishen — kuch der baar koshish karein.');
        }
        return;
      }
    }
    // FINAL-PACK C-PD — LAZMI PASSWORD CHANGE: Master ne aarzi
    // password lagaya ho (must_change_password) to driver ne wohi
    // aarzi password likh kar unlock to kar liya, lekin ONLINE
    // hone se PEHLE apna naya password lagana lazmi hai. Dialog
    // barrierDismissible:false hai aur us mein koi "rehne dein"
    // wala rasta nahi — baghair change kiye ye flow yahin ruk
    // jata hai, duty aage NAHI barhti.
    if (p.mustChangePassword) {
      final changed = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _MustChangePasswordDialog(store: store),
      );
      if (changed != true || !mounted) return;
    }
    // v1.4.7 EMAIL OTP DARWAZA (spec §1): logout ke baad dobara
    // login par — password ke baad — usi Gmail par aya OTP lazmi
    // hai. Apne band phone par roz ke istemal mein (session
    // verified) ye darwaza NAHI ata. Legacy driver (email verify
    // hi nahi hua) par bhi ye gate NAHI lagta — us ke liye
    // Profile mein email darj karne ka card hai।
    if (p.emailVerified && !p.otpSessionVerified) {
      final ok = await Navigator.of(context).push<bool>(MaterialPageRoute(
        builder: (_) =>
            OtpGatePage(email: p.email, title: 'Email OTP Tasdeeq'),
      ));
      if (ok != true || !mounted) {
        if (mounted) {
          _snack('Email OTP tasdeeq ke baghair duty shuru nahi ho sakti.');
        }
        return;
      }
      p.otpSessionVerified = true;
      await store.save();
      // v1.4.14: OTP kamyabi = session mehfooz ho chuka hai —
      // ab is phone ki driver pehchan Auth pehchan se bandh do
      // (identity_links)।
      unawaited(Backend.linkIdentities(store));
      if (!mounted) return;
    }
    if (!p.selfieToday) {
      final take = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Pehle aaj ki selfie'),
          content: const Text(
              'Duty shuru karne se pehle aaj ki LIVE selfie lazmi hai — camera se hi hogi, gallery se nahi.'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Rehne Dein')),
            ElevatedButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Selfie Lein')),
          ],
        ),
      );
      if (take != true || !mounted) return;
      await _takeSelfie();
      if (!mounted) return;
      // Camera band karke wapas a gaya to selfie nahi bani — duty
      // shuru nahi hogi (HOTFIX v1.2.9: ab wajah bhi batayi jati
      // hai — pehle khamoshi se wapas ho jata tha).
      if (!p.selfieToday) {
        _snack(
            'Selfie ke baghair duty shuru nahi ho sakti — pehle aaj ki selfie lein.');
        return;
      }
    }
    p.online = true;
    await store.save();
    // v1.4.8: duty-on = driver login ka lamha — is build ka
    // version code backend mein report (Master ko nazar aye ke
    // kaun purani app par hai); guarded, duty flow nahi rukta।
    unawaited(Backend.reportAppVersion(store));
    // v1.4.7: duty shuru — aaj ka random selfie schedule khud
    // ban jata hai (waqt driver ko pehle se pata NAHI hota)।
    unawaited(store.ensureRandomSelfieSchedule());
    unawaited(_syncDutyService(askPermission: true));
    if (mounted) setState(() {});
  }

  Future<void> _changePassword() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => _ChangePasswordDialog(store: store),
    );
    if (ok == true && mounted) {
      _snack('Password badal gaya.');
      setState(() {});
    }
  }

  /// DRIVER ACCOUNT DELETE (v1.4.16) — sawari wale flow ka
  /// hum-manzar (legal.dart ka _deleteAccount):
  ///   0) Gmail verify shuda lazmi (tasdeeq ka rasta wohi hai)।
  ///   1) Tasdeeqi dialog — asal behavior ki saaf wazahat:
  ///      server par pehchan (naam/mobile/CNIC/email/password)
  ///      khatam, documents/selfies ke record delete + un ke
  ///      raste band (asal SQL bucket ki FILES delete NAHI
  ///      karta — v1.4.25 mein dialog ka lafz isi sach ke
  ///      mutabiq kiya gaya), ID band; rides/fee ka hisaab
  ///      baghair pehchan ke Master ke record mein mehfooz;
  ///      dobara ana ho to poori registration + Master Tasdeeq
  ///      naye sire se hogi।
  ///   2) OTP se dobara tasdeeq (OtpGatePage)।
  ///   3) Server RPC `delete_my_driver_account` — fail ho to
  ///      YAHEEN rukawat: saaf error, local data ko haath NAHI
  ///      lagta, deletion adhura NAHI rehta।
  ///   4) Master ko khabar (purani behavior)।
  ///   5) Local wipe (store.deleteDriverProfileLocal) + duty
  ///      service band — sab se aakhir, sirf server kamyabi par।
  Future<void> _deleteDriverAccount() async {
    final email = p.email.trim().toLowerCase();
    if (email.isEmpty || !p.emailVerified) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Pehle Gmail verify karein'),
          content: const Text(
              'Account delete karne se pehle pehchan ki tasdeeq lazmi hai — is ke liye aap ki Gmail pehle se verify shuda honi chahiye.\n\n'
              'Profile mein Email wali card se apni Gmail verify kar lein, phir dobara koshish karein. Masla ho to Master ko Madad se message kar dein.',
              style: TextStyle(fontSize: 13.5, height: 1.45)),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Theek Hai')),
          ],
        ),
      );
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Driver account delete karein?'),
        content: const Text(
            'Aap ki DRIVER ID band aur account delete ho jayega:\n'
            '• Server par aap ki pehchan — naam, mobile, CNIC, email, password — khatam kar di jayegi; documents aur selfies ke record bhi delete ho jayenge aur un ke raste (links) band ho jayenge.\n'
            '• Is phone se bhi aap ka poora driver profile saaf ho jayega.\n\n'
            'Ek baat saaf sun lein: purani RIDES aur FEE ka HISAAB delete NAHI hota — woh Master ke record mein baghair aap ki pehchan ke mehfooz rehta hai (safety aur hisaab ki zimmedari ki wajah se).\n\n'
            'Dobara driver banna ho to poori registration aur Master ki Tasdeeq naye sire se karni hogi.\n\n'
            'Aage badhne par aap ki Gmail par OTP code ayega — dobara tasdeeq ke baghair delete NAHI hoga.',
            style: TextStyle(fontSize: 13.5, height: 1.45)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Rehne Dein')),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style:
                  ElevatedButton.styleFrom(backgroundColor: Brand.ajrakRed),
              child: const Text('Aage — OTP Tasdeeq')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final verified = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => OtpGatePage(
          email: email,
          title: 'Account Delete — Tasdeeq',
        ),
      ),
    );
    if (verified != true || !mounted) return;
    final done = await Backend.deleteDriverAccountRemote(email);
    if (!mounted) return;
    if (!done) {
      _snack(
          'Server par account delete nahi ho saka — internet check karke dobara koshish karein. Aap ka account abhi mehfooz hai, kuch delete NAHI hua.');
      return;
    }
    // Master ko khabar (local naam/number se — wipe se pehle)।
    final name = p.name.trim();
    final phone = p.phone.trim();
    await store.addMasterMessage(MasterMessage(
      id: store.newId(),
      senderKey: store.driverId,
      senderRole: 'driver',
      senderName: name,
      senderMobile: phone,
      senderZone: p.zone,
      category: 'Deegar',
      body: 'ACCOUNT DELETE: Driver ${name.isEmpty ? '(naam darj nahi tha)' : name}'
          '${phone.isEmpty ? '' : ' ($phone)'} ne OTP tasdeeq ke baad apna driver account delete kar diya hai. '
          'Server par us ki pehchan anonymize ho gayi hai aur ID band hai; rides/fee ka hisaab baghair pehchan ke record mein rahega.',
      createdAt: DateTime.now(),
    ));
    // Local wipe + duty service band — sab se aakhir।
    await store.deleteDriverProfileLocal();
    unawaited(Backend.clearSession());
    unawaited(_syncDutyService());
    if (mounted) {
      _snack('Aap ka driver account delete ho gaya hai.');
      setState(() {});
    }
  }

  Future<void> _takeSelfie() async {
    try {
      // LIVE selfie — camera ONLY. No gallery option anywhere, by design.
      final XFile? img =
          await _picker.pickImage(source: ImageSource.camera);
      if (img == null) {
        // HOTFIX v1.2.9 (RC3): camera band karne / permission na
        // milne par khamoshi se wapas NAHI — wajah batao, warna
        // driver samajhta hai selfie wala option khulta hi nahi.
        if (mounted) {
          _snack(
              'Selfie nahi li gayi — camera band ho gaya ya permission nahi mili. Dobara koshish karein.');
        }
        return;
      }
      await store.setSelfie(img.path);
      if (mounted) _snack('Aaj ki selfie ho gayi — ab ride qubool ho sakti hai.');
    } catch (_) {
      if (mounted) _snack('Camera nahi khul saka.');
    }
  }

  int _todayNetEarnings() {
    final now = DateTime.now();
    var sum = 0;
    for (final b in store.bookings) {
      final c = b.completedAt;
      if (b.status == 'completed' &&
          c != null &&
          c.year == now.year &&
          c.month == now.month &&
          c.day == now.day) {
        // v1.4.30: muft ride par driver ki kamai cash nahi —
        // company ki taraf se Amanat credit (freeCreditRs)
        // hai; aam ride par wohi purana (kul − fee) hisaab।
        sum += b.freeRide ? b.freeCreditRs : b.total - b.effectiveFeeRs;
      }
    }
    return sum;
  }

  @override
  Widget build(BuildContext context) {
    final incoming = _availableRides.length;
    return Scaffold(
      body: Column(
        children: [
          // v1.4.5 (B5): ghanti + avatar ab header ke ANDAR hain
          // (brief §3/§4) — ghanti = Notification Centre (nayi ride /
          // Master ka deposit / elanaat), avatar tap = Profile tab.
          BrandHeader(
            sideLabel: 'DRIVER APP',
            actions: [
              // v1.4.30: EK display button (Din/Raat/Auto) —
              // poori app + map isi ek pasand se badalte hain।
              const DisplayModeButton(),
              const SizedBox(width: 6),
              NotificationBell(store: store, onDark: true),
              InitialAvatar(
                name: p.name,
                onTap: () {
                  setState(() => _tab = 4);
                  // Avatar se Profile khulna bhi Profile ka khulna
                  // hai — A2 ki reject awaaz yahan bhi wohi usool.
                  _announceRejectedDocs();
                },
              ),
              const SizedBox(width: 2),
            ],
          ),
          // v1.4.8: recommended band par banner har waqt (policy),
          // warna aam update notice apne rawaiye par.
          if (UpdatePolicy.level == 1 ||
              (store.updateAvailable && !store.updateDismissed))
            UpdateBanner(store: store),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
            child: ModeToggleButton(
                toDriver: false, onTap: widget.onSwitchToPassenger),
          ),
          // v1.4.30 (owner hukm 2026-11-11 17:04): driver mode
          // ka BARA banner (ModeBanner, 170px artwork) HATA diya
          // — woh poora display gherta tha. Us ki jagah sirf
          // CHHOTI si tafseel wali patti: chhota logo nishan +
          // ek line (mode · gaari · zone). Passenger side ki
          // banner pehle hi v1.4.28 mein khatam ho chuki thi;
          // Master app ko is mein bilkul NAHI chheda gaya।
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
            child: Row(
              children: [
                Image.asset('assets/safar-logo-mark.png', height: 28),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Driver Mode · ${p.vehicle} · ${p.zone}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                        color: Brand.greenDark),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _tab == 0
                ? _homeView()
                : _tab == 1
                    ? _poolView()
                    : _tab == 2
                        ? _bookingsView()
                        : _tab == 3
                            ? _walletView()
                            : _profileView(),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) {
          setState(() => _tab = i);
          // Pool ya Bookings par aate hi position taaza — doori/filter taaza rahe.
          if (i == 1 || i == 2) _refreshMyLocation();
          // FINAL-PACK A2: Profile tab khulte hi reject awaaz
          // (signature wohi ho to _announceRejectedDocs khud
          // khamosh rehta hai — har dafa repeat nahi hoti).
          if (i == 4) _announceRejectedDocs();
        },
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Brand.green,
        items: [
          const BottomNavigationBarItem(
              icon: Icon(Icons.home), label: 'Home'),
          // POOL (DESIGN WAVE — brief Addendum): khadi rides ki
          // list; badge = abhi available pool rides ki tadaad.
          BottomNavigationBarItem(
            icon: Badge(
              label: Text('$incoming'),
              isLabelVisible: incoming > 0,
              child: const Icon(Icons.pool),
            ),
            label: 'Pool',
          ),
          BottomNavigationBarItem(
            icon: Badge(
              label: Text('$incoming'),
              isLabelVisible: incoming > 0,
              child: const Icon(Icons.notifications_active),
            ),
            label: 'Bookings',
          ),
          const BottomNavigationBarItem(
              icon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          const BottomNavigationBarItem(
              icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  // --- HOME: big online/offline state ---------------------------------------

  Widget _homeView() {
    final online = p.online;
    final numBlock = store.numberBlockReason();
    final devBlock = store.deviceBlockReason();
    final feeBlock = store.feeBlockReason();
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        // BLOCK NOTICES: number tabdeeli (12 ghante) ya device
        // ka block laga ho to Home par sab se upar saaf notice —
        // wajah + baqi waqt ke saath. Block khatam hote hi khud
        // gayab. (Fee par block 2026-11-10 ke naye usool se
        // khatam hai — feeBlockReason hamesha null hai, is liye
        // fee ki wajah se ye notice kabhi nahi ata.)
        if (numBlock != null || devBlock != null || feeBlock != null) ...[
          Card(
            color: const Color(0xFFFBEAEA),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.block, color: Brand.ajrakRed, size: 26),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(numBlock ?? devBlock ?? feeBlock!,
                        style: const TextStyle(
                            fontSize: 13.5, height: 1.45,
                            fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],
        // Registration baqi ho to sab se pehle us ka card — Yango-style
        // form yahin se khulta hai (v1.2.6). Gate ab
        // registrationComplete par hai (HOTFIX v1.2.9, RC2).
        if (!p.registrationComplete) ...[
          Card(
            color: Brand.deepGreen,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.app_registration,
                          color: Brand.gold, size: 26),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text('Registration baqi hai',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w900)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Driver banne ke liye registration form mukammal karein — mobile, CNIC, password, gaari aur selfie, qadam ba qadam.',
                    style: TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _openRegistration,
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Brand.gold,
                          foregroundColor: Brand.greenDark),
                      child: const Text('Registration Mukammal Karein'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],
        // ID tasdeeq ka intezaar — numaya khabar (v1.4.1):
        // registration mukammal ho lekin Master ne ID active na
        // ki ho to driver ko saaf pata ho ke woh kis marhale par
        // hai — na online ho sakta hai, na ride/pool qubool.
        if (p.registrationComplete && !p.masterActive) ...[
          Card(
            color: const Color(0xFFFFF3CD),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.hourglass_top, color: Brand.ajrakRed),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Aap ki ID abhi Master ki tasdeeq mein hai',
                          style: TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 15),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          p.hasRejectedDocUi
                              ? 'Ek document reject hua hai — Profile ke "Mere Kagaz" mein Master ki wajah parh kar sahi kagaz dobara bhejein.'
                              : 'Documents Master ke paas check ho rahe hain. Tasdeeq hote hi aap online ho sakenge. Documents ki haalat Profile ke "Mere Kagaz" mein dekhein.',
                          style: const TextStyle(fontSize: 12.5),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],
        // MADAD — SUPPORT KA EK HI DARWAZA (owner 2026-11-08):
        // driver ko Master se rabte ke liye dhoondhna NA pare —
        // Home par sab se numaya jagah saaf button; yehi wohi
        // messages wala rasta hai jo Profile se bhi khulta hai
        // (koi alag support/team NAHI — baat seedha Master se).
        Card(
          color: const Color(0xFFE7F2EC),
          child: ListTile(
            leading: const Icon(Icons.support_agent,
                color: Brand.green, size: 28),
            title: const Text('Madad — Master se Rabta',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5)),
            subtitle: Text(
              store.unreadMasterReplies > 0
                  ? 'Master ka naya jawab aya hai (${store.unreadMasterReplies}) — parhne ke liye tap karein.'
                  : 'Koi masla, sawal ya shikayat ho to seedha Master ko message bhejein — jawab bhi yahin ayega.',
              style: const TextStyle(fontSize: 12.5),
            ),
            trailing: const Icon(Icons.chevron_right, color: Brand.green),
            onTap: _openMessages,
          ),
        ),
        const SizedBox(height: 14),
        // BAND SADAK REPORT (MAP WAVE v1.4.20, malik ka hukm
        // 2026-11-10): driver raste mein band sadak /
        // construction / diversion dekhe to ek tap mein apni
        // GPS location ke saath Master ko report — Master app
        // ki "Sadak Reports" screen mein nazar ati hai.
        Card(
          color: const Color(0xFFFFF6E0),
          child: ListTile(
            leading: const Icon(Icons.construction,
                color: Color(0xFFB8860B), size: 28),
            title: const Text('Band Sadak? Report Karein',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5)),
            subtitle: const Text(
              'Raste mein sadak band, construction ya diversion mile to Master ko bataein — aap ki mojooda location khud saath jayegi.',
              style: TextStyle(fontSize: 12.5),
            ),
            trailing:
                const Icon(Icons.chevron_right, color: Color(0xFFB8860B)),
            onTap: _showRoadReportDialog,
          ),
        ),
        const SizedBox(height: 14),
        // MONTHLY PACKAGES (v1.4.25 — postmortem #9): driver
        // apne assign shuda packages aur khule (naye) packages
        // yahan dekhta hai aur khula package apne naam pakka
        // kar sakta hai — pehle package ka driver-assign rasta
        // app mein tha hi nahi।
        Card(
          color: const Color(0xFFE7F2EC),
          child: ListTile(
            leading: const Icon(Icons.calendar_month,
                color: Brand.green, size: 28),
            title: const Text('Monthly Packages',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5)),
            subtitle: const Text(
              'Rozana wale pakke packages — apne packages dekhein, naya khula package qubool karein.',
              style: TextStyle(fontSize: 12.5),
            ),
            trailing: const Icon(Icons.chevron_right, color: Brand.green),
            onTap: () async {
              await Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => _MonthlyPackagesPage(store: store),
              ));
              if (mounted) setState(() {});
            },
          ),
        ),
        const SizedBox(height: 14),
        // BIG state card — inDrive style.
        // v1.4.5 (B6): ONLINE par board wala sabz GRADIENT card
        // (balance card wali chamak) — offline par gehri sarmayi.
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: online ? null : const Color(0xFF5A5A5A),
            gradient: online
                ? const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Brand.brightGreen,
                      Brand.green,
                      Brand.greenDark,
                    ],
                  )
                : null,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Brand.gold, width: 2),
          ),
          child: Column(
            children: [
              Icon(online ? Icons.check_circle : Icons.do_not_disturb_on,
                  color: Colors.white, size: 44),
              const SizedBox(height: 6),
              Text(online ? 'Aap ONLINE hain' : 'Aap OFFLINE hain',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w900)),
              Text(
                online
                    ? 'Ride requests aa sakti hain'
                    : 'Online honay par ride requests ayengi',
                style: const TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _toggleOnline,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: online ? Colors.white : Brand.gold,
                    foregroundColor:
                        online ? Brand.green : Brand.greenDark,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: Text(online ? 'Offline Ho Jayein' : 'Online Ho Jayein',
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        // inDrive D1 language: status ke foran baad aaj ki kamai +
        // wallet balance ki jhalak (top cards), phir profile/gates.
        Row(
          children: [
            Expanded(
              child: _statCard('Aaj ki kamai', rs(_todayNetEarnings()),
                  Icons.trending_up),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _statCard(
                  'Wallet balance', rs(p.walletBalance), Icons.wallet),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: Brand.deepGreen,
                  child: Text(
                    p.name.isNotEmpty ? p.name[0] : 'R',
                    style: const TextStyle(
                        color: Brand.gold,
                        fontSize: 22,
                        fontWeight: FontWeight.w900),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.name,
                          style: const TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w800)),
                      Text(
                          '${p.vehicle}${p.plate.isEmpty ? '' : ' · ${p.plate}'}${p.zone.isEmpty ? '' : ' · ${p.zone}'}'),
                      Text(p.zone.isEmpty ? 'Driver' : '${p.zone} Driver',
                          style: TextStyle(
                              fontSize: 12, color: Colors.grey.shade600)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 6),
        _gateRow(
          icon: Icons.payments,
          label: 'Amanat Deposit (Rs ${Fares.joiningDeposit})',
          // AMANAT GATE (v1.4.21): balance > 0 hi "ho gaya" hai —
          // balance khatam ho to online/ride band (store ka
          // depositBlockReason wohi wajah deta hai).
          done: store.amanatBalance > 0,
          doneText: 'Balance: ${rs(store.amanatBalance)}',
          pendingText:
              'Balance khatam — Rs ${Fares.joiningDeposit} top-up karein (Raast 0312 2635002, Master darj karega)',
          // 'Wallet' wala alag button hata diya (v1.2.6 faltu-button
          // safai) — Wallet neeche wale tab se hi khulta hai.
          onFix: null,
          fixLabel: '',
        ),
        _gateRow(
          icon: Icons.camera_alt,
          label: 'Aaj ki Live Selfie',
          done: p.selfieToday,
          doneText: 'Ho gayi',
          pendingText: 'Baqi — baghair selfie ride qubool nahi hogi',
          onFix: p.selfieToday ? null : _takeSelfie,
          fixLabel: 'Selfie Lein',
        ),
        _gateRow(
          icon: Icons.badge,
          label: 'CNIC Tasdeeq',
          // HOTFIX v1.2.9 (RC1): tasdeeq ki haalat ab sirf MASTER ke
          // pull shuda verdict se ati hai — local self-attestation
          // (cnicStatus) yahan kabhi istemal nahi hoti.
          done: p.masterCnicStatus == 'verified',
          doneText: 'Master ne Tasdeeq kar di',
          pendingText: p.masterCnicStatus == 'rejected'
              ? 'Reject ho gaya — sahi kagaz dobara dein'
              : 'Tasdeeq baqi hai',
          // Registration baqi ho to ye button registration form mein
          // le jata hai (CNIC wahan jama hota hai). Registration ke
          // baad 'Profile' wala duplicate button nahi — Profile
          // neeche wale tab se khulta hai (v1.2.6 safai).
          onFix: p.registrationComplete ? null : _openRegistration,
          fixLabel: 'Registration',
        ),
        const SizedBox(height: 10),
        if (p.selfiePath.isNotEmpty && p.selfieToday)
          Card(
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(File(p.selfiePath),
                    width: 46, height: 46, fit: BoxFit.cover),
              ),
              title: const Text('Aaj ki selfie'),
              subtitle: Text('Tareekh: ${p.selfieDate}'),
            ),
          ),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text(
              'Usool: Kiraya pehle se pakka hai — koi mol-bhav nahi. Service charges sirf ${fmtPct(Fares.feePercent)} (kiraya + waiting par). Wallet kabhi minus nahi jata. Pehle 5 minute intezaar muft, phir gaari ke hisab se waiting charges. Sawari ko ride cancel karwa kar app se BAHIR le jana SAKHT MANA hai — aisa karne par ID block kar di jayegi.',
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ),
      ],
    );
  }

  Widget _statCard(String label, String value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Icon(icon, color: Brand.gold, size: 26),
            const SizedBox(height: 6),
            Text(value,
                style: const TextStyle(
                    fontSize: 19, fontWeight: FontWeight.w900)),
            Text(label,
                style: const TextStyle(fontSize: 12, color: Colors.black54)),
          ],
        ),
      ),
    );
  }

  Widget _gateRow({
    required IconData icon,
    required String label,
    required bool done,
    required String doneText,
    required String pendingText,
    required VoidCallback? onFix,
    required String fixLabel,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: done ? Brand.green : Brand.ajrakRed),
        title: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(done ? doneText : pendingText),
        // onFix null ho to koi button NAHI — sirf pending ka nishan
        // (faltu navigation buttons v1.2.6 mein hata diye gaye hain;
        // Wallet/Profile neeche wale tabs se hi khulte hain).
        trailing: done
            ? const Icon(Icons.check_circle, color: Brand.green)
            : onFix != null
                ? TextButton(onPressed: onFix, child: Text(fixLabel))
                : const Icon(Icons.pending_actions,
                    color: Brand.ajrakRed),
      ),
    );
  }

  // --- POOL: khadi rides ki list (DESIGN WAVE — brief Addendum) --------------
  //
  // Pool screen mojooda nafsiati usool par bani hai:
  //  - ONLINE driver ko rides push bhi hoti hain AUR woh yahan list
  //    mein bhi khadi nazar ati hain — driver yahan se bhi utha
  //    sakta hai.
  //  - OFFLINE driver ko koi ride push NAHI hoti, lekin woh Pool
  //    mein aa kar apni pasand ki ride KHUD utha sakta hai (owner
  //    ka hukm 2026-11-07 ~22:46–22:48).
  //  - Har card par poori tafseel: passenger ka naam, pickup, drop,
  //    safar ki doori (km), sawari tak ki doori AUR tay-shuda FIXED
  //    kiraya — driver kiraya dekh kar apni marzi se uthaye ya
  //    chhor de; koi pabandi/penalty NAHI, bidding NAHI (fare lock
  //    sirf passenger side ka hai — driver ko kiraya dikhta hai).
  //  - Ride uthana wohi EK gate hai jo har accept par chalta hai
  //    (store.acceptBlockReason — ID active, deposit, aur PEHLI
  //    Pool pick par bhi rozana live selfie lazmi).
  //  - List ka source (v1.4.2): is phone ki local pending rides
  //    AUR backend Pool feed (doosre phones ki asal rides,
  //    coordinates samait) — _availableRides dono ko jodta hai.
  //  - 2 km radius filter yahan bhi wohi hai jo Bookings par hai:
  //    doori maloom ho aur radius se bahar ho to ride nahi dikhti;
  //    location off ho to sab dikhti hain (chhupana kabhi nahi).
  Widget _poolView() {
    final available = _availableRides;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Row(
          children: [
            const Expanded(
              child: Text('Ride Pool',
                  style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            ),
            OutlinedButton.icon(
              onPressed: () {
                _refreshMyLocation();
                unawaited(Backend.refreshRemotePool(store));
                setState(() {});
                _snack('Pool taaza kar diya gaya.');
              },
              icon: const Icon(Icons.refresh, size: 17),
              label: const Text('Update'),
              style: OutlinedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          p.online
              ? 'Aap ONLINE hain — nayi rides aap ko push bhi hoti hain aur yahan Pool mein bhi khadi milti hain.'
              : 'Aap OFFLINE hain — koi ride push nahi hogi, lekin yahan Pool se apni pasand ki ride khud utha sakte hain.',
          style: const TextStyle(fontSize: 12.5, color: Colors.black54),
        ),
        const SizedBox(height: 4),
        Text(
          _myPos == null
              ? 'Location off hai — apni gaari aur sheher ki khadi rides dikh rahi hain (ride lene ke liye location on karna hogi)'
              : 'Sirf aap ki gaari ki, aap ke sheher ki aur ${store.profile.radiusKm.toStringAsFixed(0)} km ke andar ki rides dikh rahi hain',
          style: const TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 4),
        const Text(
          'Har ride ka kiraya pakka (fixed) hai — dekh kar apni marzi se uthayein, koi pabandi nahi.',
          style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w700,
              color: Brand.greenDark),
        ),
        const SizedBox(height: 10),
        if (available.isEmpty) ...[
          const SizedBox(height: 30),
          const Center(
            child: Icon(Icons.pool, size: 54, color: Colors.black26),
          ),
          const SizedBox(height: 10),
          const Center(
            child: Text(
              'Abhi koi ride request nahi hai — thodi der mein dobara dekhein.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14.5, color: Colors.black54),
            ),
          ),
        ],
        ...available.map(_poolCard),
      ],
    );
  }

  /// Pool ka ek ride card (brief Addendum ka namuna, Safar ki apni
  /// sabz/safed pehchan mein): sab se upar BADA fixed kiraya, saath
  /// passenger ka naam; neeche pickup/drop ki do lines + doori;
  /// aakhir mein "Ride Uthayein" — wohi _accept jo Bookings par
  /// hai (saare gates samet). Pool mein ride "rehne dena" koi
  /// button NAHI hai — na uthana hi driver ki marzi hai; booking
  /// kisi aur driver ke liye khadi rehti hai.
  Widget _poolCard(Booking b) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: Brand.gold, width: 2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // v1.4.30 SAHULAT: muft ride ka saaf sunehra
            // nishan — driver pehle se jane ke ye company ki
            // muft ride hai aur us ka hissa company degi
            // (inkar/ghabrahat na ho)।
            if (b.freeRide) ...[
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                decoration: BoxDecoration(
                  color: Brand.gold,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.card_giftcard,
                        size: 18, color: Brand.greenDark),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        tr('sahulat_free_driver_note'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 13,
                            color: Brand.greenDark),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
            ],
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('TAY-SHUDA KIRAYA',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Colors.black54)),
                    Text(rs(b.fare),
                        style: const TextStyle(
                            fontSize: 28, fontWeight: FontWeight.w900)),
                  ],
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(b.passengerName,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w900)),
                    if (b.passengerPhone.isNotEmpty)
                      Text(b.passengerPhone,
                          style: const TextStyle(color: Colors.black54)),
                    Text(fmtTime(b.createdAt),
                        style: const TextStyle(
                            color: Colors.black54, fontSize: 12)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
            _pickupDistanceLine(b),
            // v1.4.29: driver ki apni jagah se pickup tak ka
            // andazan waqt (asal road route se; na mile to
            // khamoshi se gayab)।
            if (_myPos != null && b.pickupLat != 0) ...[
              const SizedBox(height: 2),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(tr('pickup_eta_prefix'),
                      style: TextStyle(fontWeight: FontWeight.w600)),
                  _TargetEta(
                    from: _myPos,
                    to: ll2.LatLng(b.pickupLat, b.pickupLng),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 10),
            _routeLines(b),
            if (b.note.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('Note: ${b.note}',
                  style: const TextStyle(
                      fontSize: 13, fontStyle: FontStyle.italic)),
            ],
            if (b.hasDropPin) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  height: 180,
                  child: SafarRouteMap(
                    pickup: ll2.LatLng(b.pickupLat, b.pickupLng),
                    drop: ll2.LatLng(b.dropLat, b.dropLng),
                    interactive: false,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                Chip(
                  avatar: const Icon(Icons.route, size: 16),
                  label: Text(
                      'Safar: ${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm} km · ${b.vehicle}'),
                ),
                const Spacer(),
                Text(
                    '${store.profile.radiusKm.toStringAsFixed(0)} km ke andar',
                    style: const TextStyle(
                        fontSize: 11.5, color: Colors.black45)),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => _accept(b),
                style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14)),
                child:
                    Text(tr('accept_ride'), style: const TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- BOOKINGS: large incoming request cards --------------------------------

  Widget _bookingsView() {
    // POOL SARHADEIN yahin lagti hain — list ki satah par
    // (_availableRides → pool_filter.dart): doosri gaari, doosre
    // sheher aur (doori gin sake to) 2 km se door ki pending
    // rides is driver ki list mein aati hi nahi; booking khud
    // kahin change/delete nahi hoti (doosra munasib driver use
    // dekh sakta hai). Location maloom na ho to ride dikhti hai
    // lekin claim _accept mein rukta hai.
    final incoming = _availableRides;
    final active = store.bookings
        .where((b) => b.status == 'accepted' || b.status == 'arrived')
        .toList();
    final past = store.bookings
        .where((b) =>
            b.status == 'completed' ||
            b.status == 'noshow' ||
            b.status == 'cancelled')
        .toList();
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('Aane wali bookings',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        Text(
          _myPos == null
              ? 'Location off hai — apni gaari aur sheher ki rides dikh rahi hain (ride lene ke liye location on karna hogi)'
              : 'Sirf aap ki gaari ki, aap ke sheher ki aur ${store.profile.radiusKm.toStringAsFixed(0)} km ke andar ki rides dikh rahi hain',
          style: const TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 8),
        if (incoming.isEmpty)
          const Text('Abhi koi nayi booking nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...incoming.map(_incomingCard),
        const SizedBox(height: 16),
        const Text('Chal rahi rides',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (active.isEmpty)
          const Text('Koi ride chal nahi rahi.',
              style: TextStyle(color: Colors.black54)),
        ...active.map(_activeCard),
        const SizedBox(height: 16),
        const Text('Purani rides',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (past.isEmpty)
          const Text('Abhi koi purani ride nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...past.map((b) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ListTile(
                      leading: const Icon(Icons.history, color: Brand.green),
                      title: Text('${b.pickupLabel} → ${b.dropLabel}'),
                      subtitle: Text(
                          '${kStatusUrdu[b.status] ?? b.status} · ${fmtDate(b.completedAt ?? b.createdAt)} · ${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm} km'),
                      trailing: Text(rs(b.total),
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                    // v1.4.4: wajah record mein yahan bhi saaf.
                    if (b.status == 'cancelled' &&
                        b.cancelReason.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
                        child: Text('Mansookh ki wajah: ${b.cancelReason}',
                            style: const TextStyle(
                                fontSize: 12, color: Brand.ajrakRed)),
                      ),
                    if (b.status == 'completed' && b.endedEarly)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
                        child: Text(
                            'Sawari ne beech raaste mein yahin khatam ki${b.endReason.isEmpty ? '' : ' — wajah: ${b.endReason}'}',
                            style: const TextStyle(
                                fontSize: 12, color: Colors.black54)),
                      ),
                    // SABOOT: is ride ki recording ho to yahan se
                    // dobara suni ja sakti hai (koi delete nahi).
                    if (b.evidenceLocalPath.isNotEmpty ||
                        b.evidenceRemotePath.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                        child: EvidencePlayRow(store: store, booking: b),
                      ),
                    // v1.4.4: mukammal ride par driver sawari ko
                    // rating de sakta hai + is ride ki report bhi.
                    if (b.status == 'completed')
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 10, 8),
                        child: Row(
                          children: [
                            Expanded(
                                child:
                                    PassengerRatingRow(store: store, booking: b)),
                            TextButton.icon(
                              onPressed: () => showReportDialog(
                                  context, store, b,
                                  role: 'driver'),
                              icon: const Icon(Icons.report_outlined,
                                  size: 16, color: Brand.ajrakRed),
                              label: const Text('Report',
                                  style: TextStyle(color: Brand.ajrakRed)),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            )),
      ],
    );
  }

  Widget _routeLines(Booking b) {
    // v1.4.29: A (pickup) / B (drop) wale kaale badge — har card
    // par wohi pehchan jo map ke pins par hai (spec 2026-11-11)।
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          safarAbBadge('A', size: 24),
          const SizedBox(width: 8),
          Expanded(
              child: Text(b.pickupLabel,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700))),
        ]),
        const Padding(
          padding: EdgeInsets.only(left: 11),
          child: Icon(Icons.more_vert, size: 16, color: Colors.grey),
        ),
        Row(children: [
          safarAbBadge('B', size: 24),
          const SizedBox(width: 8),
          Expanded(
              child: Text(b.dropLabel,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700))),
        ]),
      ],
    );
  }

  /// During-trip sheet ka bara tappable option row (spec
  /// 2026-11-11): gol icon, wazeh label, neeche chhoti wazahat,
  /// dayein chevron — poori row tap hoti hai।
  Widget _optionRow({
    required IconData icon,
    required String label,
    String? sub,
    Color? iconColor,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: const BoxDecoration(
                color: Color(0xFFF1F5F2),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 21, color: iconColor ?? Brand.greenDark),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                          fontSize: 15.5, fontWeight: FontWeight.w800)),
                  if (sub != null)
                    Text(sub,
                        style: const TextStyle(
                            fontSize: 12, color: Colors.black54)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.black38),
          ],
        ),
      ),
    );
  }

  /// Waiting option ki tafseel sheet — maujooda waiting
  /// mechanism hi dikhaya jata hai: timer "Pohanch Gaya" par
  /// KHUD shuru hota hai, ride mukammal hone tak chalta hai;
  /// beech raaste ki rukawat bhi isi mein gini jati hai।
  void _showWaitingSheet(Booking b) {
    showModalBottomSheet<void>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('waiting_title'),
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text(
              trf('waiting_explain', {'n': '${Fares.freeWaitingMinutes}'}),
              style: const TextStyle(fontSize: 13, height: 1.45),
            ),
            const SizedBox(height: 12),
            _LiveWaiting(booking: b, store: store),
          ],
        ),
      ),
    );
  }

  Widget _incomingCard(Booking b) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: Brand.gold, width: 2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Chip(
                  label: Text(tr('new_booking_chip')),
                  backgroundColor: Brand.goldLight,
                  labelStyle:
                      TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
                ),
                const Spacer(),
                Text(fmtTime(b.createdAt),
                    style: const TextStyle(color: Colors.black54)),
              ],
            ),
            const SizedBox(height: 8),
            Text(b.passengerName,
                style:
                    const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            if (b.passengerPhone.isNotEmpty)
              Text(b.passengerPhone,
                  style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 8),
            // Sawari yahan se kitni door khari hai — driver ki apni
            // mojooda jagah se pickup tak ki doori.
            _pickupDistanceLine(b),
            const SizedBox(height: 10),
            _routeLines(b),
            if (b.note.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('Note: ${b.note}',
                  style: const TextStyle(
                      fontSize: 13, fontStyle: FontStyle.italic)),
            ],
            if (b.hasDropPin) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  height: 180,
                  child: SafarRouteMap(
                    pickup: ll2.LatLng(b.pickupLat, b.pickupLng),
                    drop: ll2.LatLng(b.dropLat, b.dropLng),
                    interactive: false,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                Chip(
                  avatar: const Icon(Icons.route, size: 16),
                  label: Text(
                      '${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm} km · ${b.vehicle}'),
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(tr('total_fare'),
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Colors.black54)),
                    Text(rs(b.fare),
                        style: const TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w900)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _accept(b),
                    style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                    child:
                        const Text('Qubool Karein', style: TextStyle(fontSize: 16)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () async {
                      // v1.4.4: driver ride cancel kare to us se
                      // bhi WAJAH — record ke saath mehfooz rehti
                      // hai (Master ko nazar ati hai). Sheet band
                      // karne par kuch nahi hota (ride rehti hai).
                      final reason = await showReasonSheet(
                        context,
                        title: tr('driver_decline_title'),
                        options: kRideReasonOptions,
                      );
                      if (reason == null) return;
                      await store.cancelBooking(b, reason: reason);
                      if (mounted) _snack('Booking rehne di gayi.');
                      setState(() {});
                    },
                    style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                    child:
                        const Text('Rehne Dein', style: TextStyle(fontSize: 16)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _accept(Booking b) async {
    // v1.4.27 POOL SARHADEIN (postmortem #16 — pool_filter.dart):
    // claim se PEHLE client-side pakki jaanch — gaari (vehicle)
    // match, sheher (zone) match, aur doori ki TASDEEQ lazmi
    // (doori na gin sake to claim NAHI hota; purana fail-open
    // khatam)। Server par claim_ride ka race-guard is ke upar
    // ki hifazat hai, ye us ki jagah nahi।
    final poolReason = poolClaimBlockReason(
      b,
      driverVehicle: store.profile.vehicle,
      driverZone: store.profile.zone,
      distanceKm: _pickupDistanceKm(b),
      radiusKm: store.profile.radiusKm,
    );
    if (poolReason != null) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Ye ride aap nahi le sakte'),
          content: Text(poolReason),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(tr('ok_btn'))),
          ],
        ),
      );
      return;
    }
    final reason = store.acceptBlockReason();
    if (reason != null) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Ride qubool nahi ho sakti'),
          content: Text(reason),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(tr('ok_btn'))),
          ],
        ),
      );
      return;
    }
    // v1.4.2 RACE GUARD (audit fix #2): backend Pool ki ride pehle
    // backend par ATOMIC claim hoti hai (status=eq.pending shart
    // wala PATCH) — do driver ek saath dabayein to sirf pehla
    // jeet-ta hai; doosre ko saaf paighaam milta hai aur ride us
    // ki list se nikal jati hai. Local (same-device) ride par
    // purana seedha accept hi chalta hai.
    if (b.fromBackend) {
      final claimed = await Backend.tryClaimRide(store, b.id);
      if (!claimed) {
        store.setRemotePool(
            store.remotePool.where((x) => x.id != b.id).toList());
        if (mounted) {
          _snack('Ye ride kisi aur driver ne le li hai.');
          setState(() {});
        }
        return;
      }
      await store.acceptRemoteBooking(b);
    } else {
      await store.acceptBooking(b);
    }
    // v1.4.7: do-phone ride ka start code Pool select mein na
    // aya ho (purani DB) to accept ke baad ride row se le lein —
    // code ke baghair driver ride shuru hi nahi kar payega।
    if (b.fromBackend && b.startCode <= 0) {
      unawaited(() async {
        final row =
            await Backend.fetchRideFields(b.id, 'start_code,ride_started');
        final code = (row?['start_code'] as num?)?.toInt() ?? 0;
        if (code > 0 && b.startCode <= 0) {
          b.startCode = code;
          await store.save();
          if (mounted) setState(() {});
        }
      }());
    }
    // v1.4.17 FCM: sawari ko foran khabar ke driver mil gaya
    // (passenger ki device pehle backend se dhoondhi jati hai;
    // na mile ya function deploy na ho to khamosh — passenger
    // ka polling wala rasta barkarar hai). Fire-and-forget.
    unawaited(() async {
      final dev = await Backend.fetchPassengerDeviceId(
          rideId: b.id, passengerPhone: b.passengerPhone);
      if (dev.isEmpty) return;
      await Backend.invokePush({
        'audience': 'device',
        'device_id': dev,
        'title': 'Driver mil gaya',
        'body':
            '${store.profile.name} aap ki ride ke liye aa raha hai · ${b.pickupLabel} → ${b.dropLabel}',
        'data': {'ride_id': b.id},
      });
    }());
    // Qubool karte hi taaza position — passenger ko foran sahi
    // doori/ETA nazar aye (refresh khud store mein bhi darj karta hai).
    unawaited(_refreshMyLocation());
    // v1.4.0 two-phone: qubool shuda ride ke backend row par driver
    // ki pehli jagah foran likh dein — passenger ka ETA poll (~15s)
    // isi ko uthata hai. Position na mile to duty timer baad mein
    // likh dega. Khamosh nakami.
    final lat = p.lastLat;
    final lng = p.lastLng;
    if (lat != null && lng != null) {
      unawaited(Backend.pushRideDriverPosition(store, b.id, lat, lng));
    }
    if (mounted) {
      _snack('Booking qubool ho gayi.');
      setState(() {});
    }
  }

  /// Navigation (DriverNavView) ki GPS stream se ane wali position —
  /// store mein sirf tab darj hoti hai jab driver aakhri darj jagah
  /// se kam az kam ~50 m aage barh gaya ho, taaki har GPS tick par
  /// persist/backend-push na chale. Passenger ki doori/ETA line isi
  /// taaza position se khud taza ho jati hai.
  void _onNavPosition(ll2.LatLng pos) {
    final lat = p.lastLat;
    final lng = p.lastLng;
    if (lat != null && lng != null) {
      final moved = const ll2.Distance().as(ll2.LengthUnit.Meter,
          ll2.LatLng(lat, lng), pos);
      if (moved < 50) {
        // v1.4.32: chhoti harkat par bhi waqt-waqfa wala push
        // chalao — _dutyTick ke andar ka ~3s gate khud faisla
        // karega; khade hue GPS par faltu push NAHI hoga।
        unawaited(_dutyTick());
        return;
      }
    }
    store.setDriverPosition(pos.latitude, pos.longitude);
    unawaited(_dutyTick());
  }

  Widget _activeCard(Booking b) {
    // v1.4.32: sawari ka photo-pin tayyar karo (ek dafa, guarded)।
    unawaited(_ensurePassengerPin(b));
    final arrived = b.status == 'arrived';
    // v1.4.29 DURING-TRIP SHEET (DRIVER-FLOW-SPEC 2026-11-11):
    // tartib — (1) sab se upar maujooda hadaf: A (pickup) ya
    // B (manzil) badge + poora pata + baqi waqt ka ETA chip;
    // (2) Cash line par kul kiraya BARE adad mein (driver ko
    // trip ke dauraan bhi kiraya dikhta hai — purana lock);
    // (3) passenger line: naam + gaari qisam chip (rating/trips
    // ka data maujooda model mein hai hi nahi — jaali rating
    // NAHI dikhayi); (4) A/B route lines; (5) bare tappable
    // option rows: Call · Waiting · Route in Navigator ·
    // (pickup marhale mein) Cancel; (6) aakhir mein SLIDE wale
    // bare buttons: Pohanch Gaya (Arrived) aur Ride Mukammal
    // (Complete) — Start Trip ka slide _StartCodeBox ke andar
    // hai (6-digit code ke saath)। Rang gehra sabz + sunehri —
    // peela bilkul NAHI।
    final target = arrived
        ? ll2.LatLng(b.dropLat, b.dropLng)
        : ll2.LatLng(b.pickupLat, b.pickupLng);
    final cashTotal =
        b.fare + (arrived ? store.liveWaitingCharge(b) : b.waitingCharge);
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // (1) Hadaf header
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                safarAbBadge(arrived ? 'B' : 'A', size: 30),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(arrived ? tr('target_drop') : tr('target_pickup'),
                          style: const TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w700,
                              color: Colors.black54)),
                      Text(arrived ? b.dropLabel : b.pickupLabel,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
                _TargetEta(from: _myPos, to: target),
              ],
            ),
            const SizedBox(height: 12),
            // (2) CASH line — kul kiraya bare adad mein
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFFEAF6EF),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Brand.green.withOpacity(0.35)),
              ),
              child: Row(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Brand.green,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.payments, size: 15, color: Colors.white),
                        SizedBox(width: 5),
                        Text('Cash',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                                fontSize: 13)),
                      ],
                    ),
                  ),
                  const Spacer(),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(tr('total_fare'),
                          style: TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w700,
                              color: Colors.black54)),
                      Text(rs(cashTotal),
                          style: const TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.w900,
                              color: Brand.greenDark)),
                      if (arrived && store.liveWaitingCharge(b) > 0)
                        Text(
                            'kiraya ${rs(b.fare)} + waiting ${rs(store.liveWaitingCharge(b))}',
                            style: const TextStyle(
                                fontSize: 11, color: Colors.black54)),
                      if (b.hasTax)
                        Text(
                            '+ ${taxLabelFor(b.vehicle)} ${rs(b.taxAmount)} sawari ada karegi',
                            style: const TextStyle(
                                fontSize: 11, color: Colors.black54)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            // (3) Passenger line + gaari chip
            Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: Brand.deepGreen,
                    shape: BoxShape.circle,
                    border: Border.all(color: Brand.gold, width: 1.4),
                  ),
                  child: const Icon(Icons.person,
                      color: Brand.goldLight, size: 21),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(b.passengerName,
                          style: const TextStyle(
                              fontSize: 16.5, fontWeight: FontWeight.w900)),
                      if (b.passengerPhone.isNotEmpty)
                        Text(b.passengerPhone,
                            style: const TextStyle(
                                color: Colors.black54, fontSize: 12.5)),
                    ],
                  ),
                ),
                Chip(
                  avatar: const Icon(Icons.directions_car, size: 15),
                  label: Text(b.vehicle),
                  labelStyle: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ],
            ),
            const SizedBox(height: 10),
            // (4) A/B route lines
            _routeLines(b),
            if (!arrived) ...[
              const SizedBox(height: 8),
              _pickupDistanceLine(b),
            ],
            const SizedBox(height: 8),
            if (b.hasDropPin) ...[
              DriverNavView(
                  booking: b,
                  onPosition: _onNavPosition,
                  driverOnline: p.online,
                  passengerPhotoPng: _passengerPins[b.id]),
              const SizedBox(height: 6),
            ],
            // (5) Bare tappable option rows
            const Divider(height: 1),
            _optionRow(
              icon: Icons.call,
              label: tr('call'),
              sub: b.passengerPhone.isNotEmpty
                  ? b.passengerPhone
                  : 'Number maujood nahi',
              onTap: () async {
                if (b.passengerPhone.trim().isEmpty) {
                  _snack(tr('no_number'));
                  return;
                }
                try {
                  await launchUrl(Uri.parse('tel:${b.passengerPhone.trim()}'));
                } catch (_) {
                  _snack(tr('call_failed'));
                }
              },
            ),
            _optionRow(
              icon: Icons.pause_circle_outline,
              label: tr('waiting'),
              sub: arrived
                  ? trf('waiting_sub_live', {
                      'mins': '${store.liveWaitingMinutes(b)}',
                      'amt': rs(store.liveWaitingCharge(b)),
                      'n': '${Fares.freeWaitingMinutes}',
                    })
                  : tr('waiting_sub_before'),
              onTap: () => _showWaitingSheet(b),
            ),
            _optionRow(
              icon: Icons.navigation,
              label: tr('route_in_navigator'),
              sub: tr('route_in_navigator_sub'),
              onTap: () async {
                try {
                  await launchUrl(
                    Uri.parse(
                        'geo:${target.latitude},${target.longitude}?q=${target.latitude},${target.longitude}'),
                    mode: LaunchMode.externalApplication,
                  );
                } catch (_) {
                  try {
                    await launchUrl(
                      Uri.parse(
                          'https://www.google.com/maps/dir/?api=1&destination=${target.latitude},${target.longitude}'),
                      mode: LaunchMode.externalApplication,
                    );
                  } catch (_) {
                    _snack(tr('nav_failed'));
                  }
                }
              },
            ),
            if (!arrived)
              _optionRow(
                icon: Icons.cancel,
                iconColor: Brand.ajrakRed,
                label: tr('cancel_ride_driver'),
                sub: tr('cancel_reason_sub'),
                onTap: () async {
                  final reason = await showReasonSheet(
                    context,
                    title: tr('cancel_why'),
                    options: kRideReasonOptions,
                  );
                  if (reason == null) return;
                  await store.cancelBooking(b, reason: reason);
                  if (mounted) {
                    _snack(tr('ride_cancelled'));
                    setState(() {});
                  }
                },
              ),
            const Divider(height: 1),
            const SizedBox(height: 8),
            // v1.4.0: SOS — ride chal rahi ho to driver ke liye bhi
            // hifazat ka button (police call + ride tafseel ghar
            // walon ko WhatsApp)।
            SosButton(store: store, booking: b, role: 'driver'),
            const SizedBox(height: 8),
            // SABOOT RECORDING (owner 2026-11-08): gambhir haalat
            // mein active ride par audio saboot — Master ko khud
            // khabar jati hai; recording delete nahi hoti।
            EvidenceRecorderButton(
              store: store,
              booking: b,
              role: 'driver',
              recorderName: p.name,
            ),
            const SizedBox(height: 8),
            // v1.4.16 RIDE CHAT: number share kiye baghair sawari
            // se baat।
            RideChatButton(store: store, booking: b, role: 'driver'),
            const SizedBox(height: 12),
            // (6) SLIDE wale bare buttons
            if (!arrived) ...[
              SlideConfirm(
                label: tr('arrived_slide'),
                handleIcon: Icons.location_on,
                onConfirm: () async {
                  await store.markArrived(b);
                  // v1.4.17 FCM: sawari ko foran khabar ke driver
                  // pohanch gaya (fire-and-forget)।
                  unawaited(Backend.pushDriverArrived(b));
                  if (mounted) {
                    _snack(trf('waiting_started_snack',
                        {'n': '${Fares.freeWaitingMinutes}'}));
                    setState(() {});
                  }
                },
              ),
            ] else ...[
              _LiveWaiting(booking: b, store: store),
              // v1.4.29 5-MINUTE RULE (owner hukm 2026-11-11):
              // driver ko saaf likha mile ke muft 5 minute ke
              // baad us ke paas dono raste hain aur no-show
              // cancel us ke record mein kharabi NAHI hai।
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  tr('noshow_rule_hint'),
                  style: const TextStyle(
                      fontSize: 12, color: Colors.black54, height: 1.4),
                ),
              ),
              // v1.4.7 RIDE START CODE (spec §3; v1.4.14 se
              // 6-digit): ride asal mein tab SHURU mani jati hai
              // jab driver sawari ka code daal de — code ke
              // baghair "Ride Mukammal" bhi nahi chalti (neeche
              // _complete gate)। Start ka slide usi khane ke
              // andar hai।
              if (!b.rideStarted) ...[
                const SizedBox(height: 12),
                _StartCodeBox(
                  booking: b,
                  store: store,
                  onStarted: () {
                    if (mounted) setState(() {});
                  },
                ),
              ],
              const SizedBox(height: 12),
              SlideConfirm(
                label: tr('complete_slide'),
                handleIcon: Icons.flag,
                onConfirm: () async {
                  await _complete(b);
                },
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => _noShow(b),
                  icon: const Icon(Icons.person_off),
                  label: Text(tr('no_show')),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _complete(Booking b) async {
    // v1.4.7 START CODE GATE (spec §3): jo ride code se shuru hi
    // nahi hui woh mukammal bhi nahi hogi — pehle code।
    if (b.status == 'arrived' && !b.rideStarted) {
      _snack(
          'Pehle sawari se 6-digit start code le kar ride shuru karein — code ke baghair ride mukammal nahi hogi.');
      return;
    }
    final err = await store.completeBooking(b);
    if (!mounted) return;
    if (err != null) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(tr('ride_cannot_complete')),
          content: Text(err),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(tr('ok_btn'))),
          ],
        ),
      );
    } else {
      // v1.4.29 CASH WASOOLI SCREEN (spec 2026-11-11): complete
      // hote hi saaf patti — sawari kul kitna degi, trip price,
      // bara Done। Fee/tax ka record system khud bana chuka hai
      // (completeBooking); is screen par koi hisaab TALAB nahi —
      // sirf wasooli ki raqam saaf dikhani hai।
      _showCashSheet(b);
    }
    setState(() {});
  }

  /// v1.4.29: Complete ke baad ki cash screen — notice patti
  /// "Sawari Rs X degi", bara card "Rs X — Trip mukammal",
  /// Trip price line, bara Done button (wapas home/online)।
  void _showCashSheet(Booking b) {
    // v1.4.30 SAHULAT: sawari ki asal adaigi — muft ride par
    // Rs 0, warna kul raqam mein se pehli-ride riayat minus
    // (Booking.passengerPays)।
    final pay = b.passengerPays;
    showModalBottomSheet<void>(
      context: context,
      isDismissible: false,
      enableDrag: false,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF6EF),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Brand.green.withOpacity(0.4)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.info_outline,
                        size: 18, color: Brand.greenDark),
                    const SizedBox(width: 8),
                    Text(trf('passenger_will_pay', {'amt': rs(pay)}),
                        style: const TextStyle(
                            fontSize: 16.5,
                            fontWeight: FontWeight.w800,
                            color: Brand.greenDark)),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Text(tr('collect_cash'),
                  textAlign: TextAlign.center,
                  style:
                      TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Brand.deepGreen,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Brand.gold, width: 1.2),
                ),
                child: Column(
                  children: [
                    Text(rs(pay),
                        style: const TextStyle(
                            fontSize: 34,
                            fontWeight: FontWeight.w900,
                            color: Brand.goldLight)),
                    const SizedBox(height: 2),
                    Text(tr('trip_completed'),
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 14)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Text(tr('trip_price'),
                      style: TextStyle(
                          fontWeight: FontWeight.w600, fontSize: 14.5)),
                  const Spacer(),
                  Text(rs(b.fare),
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 14.5)),
                ],
              ),
              if (b.waitingCharge > 0) ...[
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(tr('waiting_charge'),
                        style: TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14.5)),
                    const Spacer(),
                    Text(rs(b.waitingCharge),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 14.5)),
                  ],
                ),
              ],
              if (b.hasTax) ...[
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(taxLabelFor(b.vehicle),
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14.5)),
                    const Spacer(),
                    Text(rs(b.taxAmount),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 14.5)),
                  ],
                ),
              ],
              // v1.4.30 SAHULAT lines: muft ride par saaf
              // paighaam (sawari se kuch NAHI lena — hissa
              // company ki taraf se Amanat mein jama), aur
              // pehli-ride riayat ki line (driver ko poora
              // paisa — riayat sirf sawari ki adaigi se kam)।
              if (b.freeRide) ...[
                const SizedBox(height: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                  decoration: BoxDecoration(
                    color: Brand.gold.withOpacity(0.16),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Brand.gold),
                  ),
                  child: Text(
                    '${tr('sahulat_free_driver_note')} — Rs ${b.freeCreditRs} aap ke Amanat Deposit hisaab mein jama ho gaya hai. Sawari se cash NAHI lena.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        color: Brand.greenDark),
                  ),
                ),
              ],
              if (!b.freeRide && b.promoDiscountRs > 0) ...[
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(trf('sahulat_first_discount', {'amt': '${b.promoDiscountRs}'}),
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14.5)),
                    const Spacer(),
                    Text('−${rs(b.promoDiscountRs)}',
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 14.5)),
                  ],
                ),
              ],
              const SizedBox(height: 6),
              Text(
                  tr('fee_record_note'),
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black54, fontSize: 12.5)),
              const SizedBox(height: 16),
              SizedBox(
                height: 54,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Brand.gold,
                    foregroundColor: Brand.greenDark,
                    textStyle: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w900),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: () => Navigator.of(ctx).pop(),
                  child: Text(tr('done')),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _noShow(Booking b) async {
    final err = await store.markNoShow(b);
    if (!mounted) return;
    _snack(err ??
        'No-show darj ho gaya — waiting charges ${rs(b.waitingCharge)} record mein hain.');
    setState(() {});
  }

  /// BAND SADAK REPORT (MAP WAVE v1.4.20): pehle GPS maqam
  /// (ijazat na ho ya GPS band ho to saaf paighaam — jaali
  /// location kabhi nahi), phir type/note wala dialog, phir
  /// Backend.submitRoadReport. Kamyabi par shukriya wala
  /// paighaam, nakami par saaf error — offline queue nahi hai.
  Future<void> _showRoadReportDialog() async {
    Position? pos;
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm != LocationPermission.denied &&
          perm != LocationPermission.deniedForever) {
        pos = await Geolocator.getCurrentPosition(
          locationSettings:
              const LocationSettings(accuracy: LocationAccuracy.high),
        );
      }
    } catch (_) {
      pos = null;
    }
    if (!mounted) return;
    if (pos == null) {
      _snack('Location nahi mil saki — GPS on karke dobara koshish karein.');
      return;
    }
    final position = pos;
    var type = 'band_sadak';
    final noteCtrl = TextEditingController();
    var sending = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Sadak ki Report'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Kya masla hai?',
                    style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final t in const [
                      ('band_sadak', 'Band Sadak'),
                      ('construction', 'Construction'),
                      ('diversion', 'Diversion'),
                    ])
                      ChoiceChip(
                        label: Text(t.$2),
                        selected: type == t.$1,
                        onSelected: (_) => setLocal(() => type = t.$1),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: noteCtrl,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'Note (ikhtiyari)',
                    hintText: 'Masalan: bridge ke paas sadak band hai',
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Location: ${position.latitude.toStringAsFixed(5)}, ${position.longitude.toStringAsFixed(5)}',
                  style:
                      const TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              // v1.4.25 bug fix: Cancel NULL pop karta hai —
              // pehle woh bhi 'false' (nakami) bhejta tha, is
              // liye Cancel par bhi "nahi bhej saki" wala snack
              // ajata tha (postmortem chhota bug)।
              onPressed: sending ? null : () => Navigator.pop(ctx, null),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: sending
                  ? null
                  : () async {
                      setLocal(() => sending = true);
                      final sent = await Backend.submitRoadReport(
                        store,
                        lat: position.latitude,
                        lng: position.longitude,
                        type: type,
                        note: noteCtrl.text.trim(),
                      );
                      if (ctx.mounted) Navigator.pop(ctx, sent);
                    },
              child: Text(sending ? 'Bhej rahe hain…' : 'Report Bhejein'),
            ),
          ],
        ),
      ),
    );
    noteCtrl.dispose();
    if (!mounted) return;
    // Cancel (ok == null) par koi snack NAHI — pehle wohi
    // nakami wala paighaam wahan bhi ajata tha (bug)।
    if (ok == null) return;
    _snack(ok
        ? 'Report Master ko bhej di gayi — shukriya!'
        : 'Report nahi bhej saki — internet check karke dobara koshish karein.');
  }

  // --- WALLET -----------------------------------------------------------------

  // (Deposit/fee ke khud-darj wale forms yahan se HATA diye
  // gaye hain — malik ke controls 2026-11-10 19:41 + 20:05:
  // jama aur wasool ki entry SIRF Master karta hai; driver
  // ki wallet screen sirf dekhne ke liye hai. Tafseel
  // _walletView ke Amanat cards mein.)

  /// Kamai report ki ek patti (hafta/mahina) — rides, kul, fee, net.
  Widget _earningsRow(
      String label, ({int rides, int gross, int fee, int tax, int net}) e) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Brand.lightBg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style:
                  const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
          const SizedBox(height: 4),
          Text(
            'Rides: ${e.rides} · Kul kamai: ${rs(e.gross)} · '
            'Service charges: ${rs(e.fee)} · Asal bachat: ${rs(e.net)}',
            style: const TextStyle(fontSize: 12.5),
          ),
          // v1.4.24: tax alag line — kamai/bachat mein shamil
          // NAHI, sirf record (sarkari tax, Master ke Tax Khata
          // mein jata hai)।
          if (e.tax > 0) ...[
            const SizedBox(height: 2),
            Text(
              'Sales Tax (SRB) wasool: ${rs(e.tax)} — ye kamai NAHI, sarkari tax hai',
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ],
        ],
      ),
    );
  }

  /// Kamai report WhatsApp par text ki surat mein share karna —
  /// passenger ke share-my-ride wala hi tareeqa (wa.me link).
  Future<void> _shareEarningsReport() async {
    final w = store.earningsThisWeek();
    final m = store.earningsThisMonth();
    final text = 'SAFAR — Meri Kamai Ki Report\n'
        'Driver: ${p.name}\n'
        'IS HAFTE: Rides ${w.rides} · Kul ${rs(w.gross)} · '
        'Service charges ${rs(w.fee)} · Asal bachat ${rs(w.net)}\n'
        'IS MAHINE: Rides ${m.rides} · Kul ${rs(m.gross)} · '
        'Service charges ${rs(m.fee)} · Asal bachat ${rs(m.net)}\n'
        'Amanat Deposit balance: ${rs(store.amanatBalance)}';
    final uri =
        Uri.parse('https://wa.me/?text=${Uri.encodeComponent(text)}');
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) _snack('WhatsApp nahi khul saka.');
  }

  // (deposit/pwd controllers ki dispose is file ke _DriverSideState
  // ke dispose() mein pehle se hoti thi — v1.4.0 mein wahan banners
  // + duty timer bhi band hote hain.)

  Widget _walletView() {
    // Kul hisaab (tamam mukammal rides, local record): kul
    // rides / kul kiraya / kul bani hui fee (v1.4.20).
    final allTime = store.earningsBetween(
        DateTime(2000, 1, 1), DateTime.now().add(const Duration(days: 1)));
    // Wasool shuda (SIRF Master ki darj shuda settlements se —
    // feeDue unhi se kam hota hai): kul bani fee − baqi.
    // Driver khud is mein kuch nahi jod sakta (19:41 control).
    final feeWasoolRaw = allTime.fee - p.feeDue;
    final feeWasool = feeWasoolRaw > 0 ? feeWasoolRaw : 0;
    // AMANAT DEPOSIT (v1.4.21 — malik ka faisla 2026-11-10
    // 20:05): maujooda balance hamesha DERIVED hai —
    //   balance = kul jama (Master-darj) − deposit se kati fees
    // aur "deposit se kati fees" wohi hai jo feeDue mein baqi
    // hai (kul bani fees − cash wasool)। EK hi hisaab hai —
    // purani "Dena Hai" wali voluntary-fee sorat aur driver ke
    // khud deposit darj karne wala form is nizaam mein KHATAM
    // hain: jama ki entry SIRF Master karta hai.
    final balance = store.amanatBalance;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        // AMANAT card: sabz GRADIENT — big number = balance.
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Brand.green, Brand.deepGreen, Brand.greenDark],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Brand.gold, width: 2),
          ),
          child: Column(
            children: [
              const Text('MERA DEPOSIT (AMANAT) — BALANCE',
                  style: TextStyle(
                      color: Brand.goldLight,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2)),
              Text(rs(balance > 0 ? balance : 0),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.w900)),
              Text(
                'Kul jama: ${rs(p.amanatJama)} · Deposit se kati fees: ${rs(p.feeDue)}',
                style: const TextStyle(color: Brand.cream, fontSize: 12),
              ),
              const SizedBox(height: 6),
              const Text(
                'Ye raqam aap ki apni AMANAT hai — Bozdar Safar ki kamai NAHI hai. Is mein se sirf aap ki mukammal rides ki fees kat ti hai; baqi raqam har waqt aap ki apni hai.',
                style: TextStyle(color: Colors.white60, fontSize: 11),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // --- AMANAT HISAAB — tafseel ---
        // Kul jama (Master-darj), kul bani fees, cash wasool
        // (purani, agar ho), deposit se kati fees aur maujooda
        // balance — sab EK hisaab se. Neeche top-up ki hidayat:
        // jama SIRF Master darj karta hai (wasool ke baad)।
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF6E0),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Brand.gold, width: 1.5),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text('Amanat Hisaab — Tafseel',
                      style: TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w900)),
                  const Spacer(),
                  Text(rs(balance > 0 ? balance : 0),
                      style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: Brand.greenDark)),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                'Kul mukammal rides: ${allTime.rides} · Kul kiraya: ${rs(allTime.gross)}',
                style: const TextStyle(
                    fontSize: 12.5, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 4),
              Text(
                'Kul Deposit Jama (Master ke record se): ${rs(p.amanatJama)}',
                style: const TextStyle(fontSize: 12.5),
              ),
              const SizedBox(height: 4),
              Text(
                'Kul bani hui fees (${fmtPct(Fares.feePercent)}): ${rs(allTime.fee)}',
                style: const TextStyle(fontSize: 12.5),
              ),
              if (feeWasool > 0) ...[
                const SizedBox(height: 4),
                Text(
                  'Cash wasool — purani (Master-darj): ${rs(feeWasool)}',
                  style: const TextStyle(fontSize: 12.5),
                ),
              ],
              const SizedBox(height: 4),
              Text(
                'Deposit se kati hui fees: ${rs(p.feeDue)}',
                style: const TextStyle(fontSize: 12.5),
              ),
              // v1.4.24 TAX (SRB): driver ke hisaab mein tax
              // ALAG nazar aye — ye us ki kamai NAHI hai: sarkari
              // tax hai jo sawari ke kiraye par alag wasool hua,
              // fees ke saath Master ke Tax Khata mein record
              // hai aur sarkar (SRB) ko jama karana hai।
              if (allTime.tax > 0) ...[
                const SizedBox(height: 4),
                Text(
                  'Kul bana hua Sales Tax (SRB): ${rs(allTime.tax)}',
                  style: const TextStyle(
                      fontSize: 12.5, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 2),
                const Text(
                  'Ye tax aap ki kamai NAHI hai — ye sarkari tax hai jo sawari ke kiraye par alag wasool hua; is ka record Master ke Tax Khata mein hai.',
                  style: TextStyle(fontSize: 11.5, color: Colors.black54),
                ),
              ],
              const SizedBox(height: 8),
              if (balance <= 0)
                const Text(
                  'Balance khatam hai — online honay aur ride qubool karne ke liye pehle deposit top-up karein.',
                  style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w800,
                      color: Brand.ajrakRed),
                ),
              if (balance <= 0) const SizedBox(height: 6),
              Text(
                'Top-up ki hidayat: apne Easypaisa ya JazzCash account se Raast ke zariye Rs ${Fares.joiningDeposit} is number par bhejein: 0312 2635002. Ye aap ka apna account hai — us ka number hum kahin record NAHI karte. Wasool honay par Master darj karega to aap ka deposit balance barh jayega. Jama ki entry SIRF Master karta hai; aap yahan khud kuch darj nahi kar sakte.',
                style: const TextStyle(
                    fontSize: 12, color: Colors.black54, height: 1.4),
              ),
              const SizedBox(height: 6),
              const Text(
                'Amanat ki shartein: fees ke ilawa aap ki raqam se ek rupee bhi idhar udhar NAHI hota; kaam chhorne par baqi raqam aap ko poori wapas milegi. Poori shartein Sharait (Terms) mein parhein.',
                style: TextStyle(
                    fontSize: 12, color: Colors.black54, height: 1.4),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        // v1.4.0 — KAMAI KI REPORT: is hafte + is mahine ka khulasa
        // (rides, kul kamai, service charges, asal bachat) — sirf
        // local bookings/ledger se (store.earnings*), koi backend
        // nahi. Share-as-text WhatsApp par — app ka mojooda tareeqa.
        Row(
          children: [
            const Text('Kamai Ki Report',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
            const Spacer(),
            TextButton.icon(
              onPressed: _shareEarningsReport,
              icon: const Icon(Icons.share, size: 16),
              label: const Text('Share Karein'),
            ),
          ],
        ),
        const SizedBox(height: 4),
        _earningsRow('Is Hafte', store.earningsThisWeek()),
        const SizedBox(height: 6),
        _earningsRow('Is Mahine', store.earningsThisMonth()),
        const SizedBox(height: 20),
        const Text('Monthly Packages',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.monthlyPackages.isEmpty)
          const Text('Abhi koi monthly package nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...store.monthlyPackages.map((mp) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading:
                    const Icon(Icons.calendar_month, color: Brand.green),
                title: Text('${mp.pickup} → ${mp.drop}'),
                subtitle: Text(
                    '${mp.passengerName.isEmpty ? 'Sawari' : mp.passengerName} · ${mp.vehicle} · ${mp.days} din'),
                trailing: Text(rs(mp.monthlyAmount),
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            )),
        const SizedBox(height: 20),
        const Text('Hisab Kitab (Ledger)',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.txns.isEmpty)
          const Text('Abhi koi entry nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...store.txns.map((t) {
          final isDeposit = t.type == 'deposit';
          final isFeePay = t.type == 'fee_payment';
          // v1.4.24: 'tax' entry = Sales Tax (SRB) — service
          // charges se ALAG pehchan (ye driver ki kamai/katauti
          // NAHI, sarkari tax ka record hai)।
          final isTax = t.type == 'tax';
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Icon(
                isDeposit
                    ? Icons.arrow_downward
                    : isFeePay
                        ? Icons.receipt_long
                        : isTax
                            ? Icons.account_balance
                            : Icons.percent,
                color: isDeposit
                    ? Brand.green
                    : isFeePay
                        ? Brand.green
                        : Brand.ajrakRed,
              ),
              title: Text(isDeposit
                  ? 'Deposit — ${t.method}'
                  : isFeePay
                      ? 'Fee Payment — ${t.method} (tasdeeq baqi)'
                      : isTax
                          ? 'Sales Tax (SRB) — sarkari tax'
                          : 'Service charges ${fmtPct(Fares.feePercent)}'),
              subtitle: Text('${t.note}\n${fmtDate(t.date)} ${fmtTime(t.date)}'),
              isThreeLine: true,
              trailing: Text(
                isDeposit ? '+ ${rs(t.amount)}' : '− ${rs(t.amount)}',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: isDeposit || isFeePay
                      ? Brand.green
                      : Brand.ajrakRed,
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  // --- PROFILE (FORM USOOL — 2026-11-08) --------------------------------------
  //
  // FORM USOOL (owner ka hukm): Profile par koi form display par
  // khula/pehle-bhara NAHI ata. Profile sirf:
  //   (1) STATUS LINES — account ki haalat, driver ki apni maloomat
  //       (naam/mobile/gaari/sheher), Tasdeeq ki asal haalat
  //       (Verified pill sirf Master ke faisle par), Mere Kagaz ki
  //       haalatein, rozana selfie ki haalat, password ki haalat;
  //   (2) BUTTONS — jo sahi step par RegistrationWizard khol dein
  //       (har tabdeeli sirf wizard mein, step-by-step hoti hai),
  //       password ke liye set/change wale dialogs, Master ko
  //       Message ka darwaza, aur reject shuda document ko Dobara
  //       Bhejne ka amal (woh editing form nahi — sirf wohi ek
  //       document ki nayi photo hai).
  // Purane inline editing fields (naam/phone/plate/brand/model/
  // year/color/zone/vehicle chips) aur "Profile Save Karein" wala
  // khula form yahan se KHTAM hai. Password ke usool (fingerprint,
  // uniqueness, lockout) aur un ke exact jumle bilkul nahi chhere
  // gaye — set/change ke dialogs wohi hain jo pehle thay.

  /// Read-only maloomat ki ek line (status display — koi field nahi).
  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 118,
            child: Text(label,
                style: const TextStyle(
                    fontWeight: FontWeight.w700, color: Colors.black54)),
          ),
          Expanded(
            child: Text(value.isEmpty ? '—' : value,
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _profileView() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('Driver Profile',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        // Master tasdeeq ki haalat — backend drivers.active se ati hai.
        // Profile Save = registration (pending); Master ACTIVE kare to
        // ye card badal jata hai. Refresh se foran nayi haalat pull.
        Card(
          color: p.masterActive ? Brand.deepGreen : null,
          child: ListTile(
            leading: Icon(
              p.masterActive ? Icons.verified : Icons.pending_actions,
              color: p.masterActive ? Brand.gold : Brand.ajrakRed,
            ),
            title: Text(
              p.masterActive
                  ? 'Account ACTIVE hai'
                  : 'Account PENDING hai',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                color: p.masterActive ? Colors.white : null,
              ),
            ),
            subtitle: Text(
              p.masterActive
                  ? 'Master ne tasdeeq kar di hai — aap ka account online system mein active hai.'
                  : 'Registration form mukammal karein — Master ki tasdeeq ke baad account active hoga.',
              style: TextStyle(
                color: p.masterActive ? Colors.white70 : null,
              ),
            ),
            trailing: IconButton(
              icon: Icon(Icons.refresh,
                  color: p.masterActive ? Brand.gold : Brand.green),
              tooltip: 'Status refresh karein',
              onPressed: () async {
                await Backend.refreshDriverStatus(store);
                if (mounted) setState(() {});
              },
            ),
          ),
        ),
        const SizedBox(height: 10),
        // v1.4.22 MERI PHOTO (malik ka hukm 2026-11-10 23:36):
        // driver apni profile photo laga/badla sakta hai — kul
        // 3 dafa ki hadd ke saath; baqi moqay card par likhe
        // ate hain aur hadd par likha hua notice (Master-route
        // wali sahulat samait)।
        ProfilePhotoCard(store: store, forDriver: true),
        const SizedBox(height: 10),
        // AGENT HISA (v1.4.6): driver ke mobile ka ACTIVE agent
        // ho to "Mera Agent Hisa" card yahin khulta hai — na ho
        // to widget khud ghayab rehta hai (SizedBox.shrink).
        AgentSection(store: store),
        const SizedBox(height: 10),
        // Registration (v1.2.6): pehli registration Yango-style wizard
        // se hoti hai — Profile mein us ka darwaza hai, doosri
        // competing form NAHI. Mukammal ho to tafseel yahin se dobara
        // khol kar badli ja sakti hai.
        Card(
          // HOTFIX v1.2.9 (RC2): card ki haalat registrationComplete
          // par — flag laga ho lekin photos baqi hon to card
          // "tasaveer baqi hain" wali soorat mein dikhta hai.
          color: p.registrationComplete ? null : Brand.deepGreen,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.app_registration,
                        color:
                            p.registrationComplete ? Brand.green : Brand.gold),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        p.registrationComplete
                            ? 'Registration mukammal hai'
                            : (p.registrationDone
                                ? 'Registration ki tasaveer baqi hain'
                                : 'Registration baqi hai'),
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                          color: p.registrationComplete ? null : Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  p.registrationComplete
                      ? 'CNIC, gaari, licence aur selfie ki tafseel form mein darj hai.'
                      : (p.registrationDone
                          ? 'Form pehle bhara gaya tha lekin CNIC, gaari aur selfie ki tasaveer baqi hain — form khol kar sirf wohi jama karein, baqi tafseel bhari hui milegi.'
                          : 'Mobile, CNIC, password, gaari aur selfie — qadam ba qadam form bharein.'),
                  style: TextStyle(
                    fontSize: 12,
                    color: p.registrationComplete
                        ? Colors.black54
                        : Colors.white70,
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _openRegistration,
                    style: p.registrationComplete
                        ? null
                        : ElevatedButton.styleFrom(
                            backgroundColor: Brand.gold,
                            foregroundColor: Brand.greenDark),
                    child: Text(p.registrationComplete
                        ? 'Tafseel Dekhein / Badlein'
                        : 'Registration Mukammal Karein'),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        // v1.4.29 ZUBAAN (owner hukm 2026-11-11): driver
        // profile se bhi wahi shared zubaan ki pasand —
        // passenger mode par bhi yehi lagu hoti hai।
        Card(
          child: ListTile(
            leading: const Icon(Icons.language, color: Brand.green),
            title: Text(tr('language'),
                style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(tr('language_sub')),
            trailing: Text(
                store.langCode == 'en' ? 'English' : 'Urdu',
                style: const TextStyle(
                    fontWeight: FontWeight.w800, color: Brand.greenDark)),
            onTap: () => showLanguageChooser(
              context,
              current: store.langCode,
              onPick: (c) => store.setLang(c),
            ),
          ),
        ),
        const SizedBox(height: 10),
        // v1.4.29 RADIUS SETTING — FINAL RULE (owner, 2026-11-11
        // 16:36): driver apna pickup daira yahan se jab chahe
        // 2–5 km ke beech badal sakta hai (2 se kam NAHI)।
        // Registration par set shuda value hi yahan dikhti hai;
        // tabdeeli local store + backend record (radius_km)
        // dono mein jati hai।
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.radar, color: Brand.green),
                    const SizedBox(width: 10),
                    Text(tr('radius_title'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 15)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(tr('radius_hint'),
                    style: const TextStyle(
                        fontSize: 12.5, color: Colors.black54, height: 1.4)),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final km in kRadiusOptionsKm)
                      ChoiceChip(
                        label: Text('${km.toStringAsFixed(0)} km'),
                        selected: p.radiusKm == km,
                        onSelected: (sel) async {
                          if (!sel) return;
                          setState(() => p.radiusKm = km);
                          await store.save();
                          if (mounted) _snack(tr('radius_saved'));
                        },
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        // Master ko Message (v1.2.7): masla/shikayat seedha Master
        // (head) ko — Profile tab se hi darwaza hai.
        Card(
          child: ListTile(
            leading: const Icon(Icons.mail_outline, color: Brand.green),
            title: const Text('Madad — Master se Rabta',
                style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text(
                'Koi masla ya shikayat ho to seedha Master ko message bhejein — Master ka jawab bhi yahin chat mein ayega.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _openMessages,
          ),
        ),
        const SizedBox(height: 10),
        // v1.4.26 HEALTH ENGINE: app ki sehat ki jhalak + Repair
        // Log ka rasta — engine khamoshi se khud repair karta
        // hai, ye satar sirf haalat batati hai.
        AppHealthTile(store: store),
        const SizedBox(height: 10),
        // v1.4.4 LEGAL: Sharait + Privacy ke darwaze — "Sharait
        // dobara parhein" yahin hai; driver ki registration wali
        // qubooliyat ka waqt bhi yahin nazar ata hai.
        LegalLinksCard(
          store: store,
          driverAcceptedAtMs:
              p.termsAcceptedAtMs > 0 ? p.termsAcceptedAtMs : null,
          // Driver Profile hai — Sharait mein Driver ki sharait
          // (fees/deposit/top-up) bhi khulengi (20:40 tarmim).
          showDriverTerms: true,
        ),
        // v1.4.0: driver ki apni rating — backend se pull shuda
        // ausat (backendRatingAvg) pehle; woh na ho to is phone par
        // sawariyon ki di hui ratings ka local ausat. Koi rating hi
        // na ho to ye patti NAHI dikhti (jhoota number kabhi nahi).
        if (store.backendRatingAvg != null ||
            store.localOwnRatingAverage != null) ...[
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const Icon(Icons.star, color: Brand.gold),
              title: Text(
                'Meri Rating: ${(store.backendRatingAvg ?? store.localOwnRatingAverage)!.toStringAsFixed(1)} / 5',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text(store.backendRatingAvg != null
                  ? '${store.backendRatingCount} sawariyon ne rating di'
                  : 'Is phone par di gayi ratings se'),
            ),
          ),
        ],
        const SizedBox(height: 10),
        // --- APNI MALOOMAT (sirf status lines — koi form NAHI) ---
        // FORM USOOL (2026-11-08): naam/mobile/gaari/sheher yahan
        // sirf DIKHTE hain (read-only status lines). Koi tabdeeli
        // chahiye ho to neeche ka button seedha RegistrationWizard
        // kholta hai — tafseel pehle se bhari hui milegi, badalna
        // step-by-step wizard mein hi hoga.
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.person, color: Brand.green),
                    SizedBox(width: 9),
                    Text('Meri Maloomat',
                        style: TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 15)),
                  ],
                ),
                const SizedBox(height: 8),
                _infoRow('Naam', p.name),
                _infoRow('Mobile', p.phone),
                _infoRow('Sheher (Zone)',
                    p.zone.isEmpty ? 'Abhi set nahi hai' : p.zone),
                _infoRow('Gaari',
                    '${p.vehicle}${p.vehicleBrand.isEmpty ? '' : ' · ${p.vehicleBrand}'}${p.vehicleModel.isEmpty ? '' : ' ${p.vehicleModel}'}'),
                _infoRow('Saal / Rang',
                    '${p.vehicleYear == 0 ? '—' : p.vehicleYear} / ${p.vehicleColor.isEmpty ? '—' : p.vehicleColor}'),
                _infoRow('Number plate', p.plate),
                const SizedBox(height: 8),
                // TASDEEQ PILL (brief S6): badge SIRF Master ke asal
                // faisle par — ID active ho to sabz 'Verified';
                // reject ho to laal; warna amber 'Tasdeeq baqi hai'.
                // Driver khud ye badge kabhi nahi laga sakta.
                Row(
                  children: [
                    const Text('Tasdeeq: ',
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: Colors.black54)),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: (p.hasRejectedDocUi
                                ? Brand.ajrakRed
                                : p.masterActive
                                    ? Brand.green
                                    : const Color(0xFFB8860B))
                            .withOpacity(0.13),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: p.hasRejectedDocUi
                              ? Brand.ajrakRed
                              : p.masterActive
                                  ? Brand.green
                                  : const Color(0xFFB8860B),
                          width: 0.9,
                        ),
                      ),
                      child: Text(
                        p.hasRejectedDocUi
                            ? 'Reject — neeche wajah dekhein'
                            : p.masterActive
                                ? '✓ Verified'
                                : 'Tasdeeq baqi hai',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: p.hasRejectedDocUi
                              ? Brand.ajrakRed
                              : p.masterActive
                                  ? Brand.green
                                  : const Color(0xFFB8860B),
                        ),
                      ),
                    ),
                  ],
                ),
                // MUKAMMAL TASDEEQ DARJA (v1.4.19 — malik ka FINAL
                // faisla 2026-11-10 18:18): saare documents Master
                // se verified hon to sunehra wazeh nishan; warna
                // kitne kagaz baqi hain woh line (sirf registered
                // profile par)।
                if (p.registrationDone && p.mukammalTasdeeq) ...[
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 9),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF6E0),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Brand.gold, width: 1.2),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.workspace_premium,
                            color: Color(0xFFB8860B), size: 22),
                        SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            'Mukammal Tasdeeq — aap ke SAARE kagaz Master se verify hain. Mubarak ho!',
                            style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF8D6E00)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ] else if (p.registrationDone &&
                    p.unverifiedDocCount > 0) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Mukammal Tasdeeq ke liye abhi ${p.unverifiedDocCount} kagaz ki tasdeeq baqi hai — neeche "Mere Kagaz" mein har kagaz ki haalat aur rehnumai di hai.',
                    style: const TextStyle(
                        fontSize: 12, color: Colors.black54),
                  ),
                ],
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: _openRegistration,
                    child: const Text('Tafseel Badlein (Form)'),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 18),
        const Text('Mere Kagaz',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        // MERE KAGAZ panel (v1.4.1 — Owner Tasdeeq Duty, Part B):
        // har document ki Master-wali asal haalat — Tasdeeq Shuda ✓ /
        // Reject ✗ Master ki wajah ke saath (lafz-ba-lafz) /
        // Intezaar Mein… Tasdeeq SIRF Master karta hai (v1.2.9 lock
        // barkarar): driver yahan se sirf document DOBARA bhej sakta
        // hai — koi *_status woh khud kabhi set nahi kar sakta.
        const Text(
            'Online hone ke liye CNIC aur Gaari ke kagazon ki tasdeeq lazmi hai. Licence ikhtiyari hai — na ho to koi baat nahi. Fitness Certificate, Insurance aur Character Certificate bhi har driver ke record ke lazmi kagaz hain — saare kagaz verify hon to "Mukammal Tasdeeq" darja milta hai. Har document ki tasdeeq sirf Master karta hai; reject ho to wajah ke saath wohi document dobara bheja ja sakta hai. Jo kagaz abhi na ho, us ke saath rehnumai di hai ke woh kahan se banta hai.',
            style: TextStyle(fontSize: 12, color: Colors.black54)),
        const SizedBox(height: 8),
        // DEVICE KA USOOL — mustaqil hidayat (malik ka hukm
        // 2026-11-08): ek account, sirf ek device.
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF6E0),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Brand.gold),
          ),
          child: const Text(
            'Device ka usool: sirf EK hi device istemal karein — aap ka account isi device se bandha hua hai. '
            'Device tabdeel na karein; doosri device par account khula to ID khud-ba-khud 6 ghante block ho jati hai aur Master ko khabar chali jati hai. '
            'Agar device badalna zaruri ho to PEHLE Master ko message karke batayein.',
            style: TextStyle(fontSize: 12.5, height: 1.45),
          ),
        ),
        const SizedBox(height: 10),
        _mereKagazRow(
          group: 'cnic',
          label: 'CNIC',
          kinds: const [
            ('cnic_front', 'CNIC — Samne wali photo'),
            ('cnic_back', 'CNIC — Peeche wali photo'),
          ],
          photoMissing: p.cnicFrontPath.isEmpty || p.cnicBackPath.isEmpty,
        ),
        _mereKagazRow(
          group: 'gaari',
          label: 'Gaari ke Kaghaz',
          kinds: const [
            ('vehicle', 'Gaari ki photo'),
            ('vehicle_reg', 'Kaghaz (Registration) ki photo'),
          ],
          photoMissing: p.vehicleRegPath.isEmpty,
        ),
        // PTA PROOF (2026-11-08): IMEI wala hisaab — screenshot
        // NAHI. Status Master ka (pull shuda); IMEI sirf wizard se
        // badalta hai. PTA LAZMI shart sirf tab hai jab malik ne
        // Master se "PTA Proof lazmi" ON kiya ho (Fares.ptaRequired,
        // migration v133) — default band (ikhtiyari) hai.
        Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      p.masterStatusFor('pta') == 'verified'
                          ? Icons.verified
                          : p.masterStatusFor('pta') == 'rejected'
                              ? Icons.cancel
                              : Icons.pending_actions,
                      color: p.masterStatusFor('pta') == 'verified'
                          ? Brand.green
                          : p.masterStatusFor('pta') == 'rejected'
                              ? Brand.ajrakRed
                              : const Color(0xFFB8860B),
                    ),
                    const SizedBox(width: 9),
                    const Expanded(
                      child: Text('PTA Proof',
                          style: TextStyle(fontWeight: FontWeight.w800)),
                    ),
                    Text(
                      p.masterStatusFor('pta') == 'verified'
                          ? 'Tasdeeq Shuda ✓'
                          : p.masterStatusFor('pta') == 'rejected'
                              ? 'Reject ✗'
                              : 'Intezaar Mein…',
                      style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: p.masterStatusFor('pta') == 'verified'
                              ? Brand.green
                              : p.masterStatusFor('pta') == 'rejected'
                                  ? Brand.ajrakRed
                                  : const Color(0xFFB8860B)),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  p.imei.isEmpty
                      ? 'IMEI abhi darj nahi — registration form ke "PTA Proof" hisse mein *#06# wala IMEI likhein.'
                      : 'Aap ka IMEI: ${p.imei}',
                  style: const TextStyle(fontSize: 13),
                ),
                if (p.masterStatusFor('pta') == 'rejected' &&
                    p.masterReasonFor('pta').isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text('Master ki wajah: ${p.masterReasonFor('pta')}',
                      style: const TextStyle(
                          fontSize: 12.5,
                          color: Brand.ajrakRed,
                          fontWeight: FontWeight.w600)),
                ],
                const SizedBox(height: 4),
                Text(
                  Fares.ptaRequired
                      ? 'IMEI ghalat ya mobile PTA-approved na ho to ID NAHI banti. IMEI badalna ho to registration form se badlein — naya IMEI dobara check hoga.'
                      : 'Filhal IMEI ikhtiyari hai — Master ne "PTA Proof lazmi" band rakha hai, is liye IMEI na ho to bhi ID ban sakti hai. IMEI badalna ho to registration form se badlein.',
                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        const Text('Driving Licence',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        // Licence hai/nahi — ye registration DATA hai, tasdeeq nahi;
        // ab sirf wizard mein badalta hai, yahan sirf maloomat.
        Text(
          p.licenceStatus == 'has'
              ? 'Licence hai${p.licenceNumber.isNotEmpty ? ' — ${p.licenceNumber}' : ''} (badalna ho to registration form se)'
              : 'Licence nahi hai — CNIC se kaam chal jayega. (Badalna ho to registration form se.)',
          style: const TextStyle(fontSize: 13, color: Colors.black54),
        ),
        if (p.licenceStatus == 'has') ...[
          const SizedBox(height: 8),
          _mereKagazRow(
            group: 'licence',
            label: 'Licence Tasdeeq',
            kinds: const [
              ('licence', 'Licence ki photo'),
            ],
            photoMissing: p.licencePhotoPath.isEmpty,
          ),
        ],
        const SizedBox(height: 10),
        // TEENO NAYE KAGAZ (v1.4.19 — darmiyani model): Fitness,
        // Insurance, Character Certificate — har ek ki asal
        // Master haalat + reject wajah + sirf wahi document
        // dobara bhejne ka rasta, bilkul CNIC/Gaari wale pattern
        // par। Photo baqi ho ya reject ho to row mein REHNUMAI
        // bhi dikhti hai (kagaz kahan se banta hai)।
        const Text('Fitness, Insurance aur Character Certificate',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        _mereKagazRow(
          group: 'fitness',
          label: 'Fitness Certificate',
          kinds: const [
            ('fitness_cert', 'Fitness Certificate ki photo'),
          ],
          photoMissing: p.fitnessPhotoPath.isEmpty,
        ),
        _mereKagazRow(
          group: 'insurance',
          label: 'Gaari ki Insurance (Third-Party)',
          kinds: const [
            ('insurance', 'Insurance ki photo'),
          ],
          photoMissing: p.insurancePhotoPath.isEmpty,
        ),
        _mereKagazRow(
          group: 'character',
          label: 'Police Character Certificate',
          kinds: const [
            ('character', 'Character Certificate ki photo'),
          ],
          photoMissing: p.characterPhotoPath.isEmpty,
        ),
        const SizedBox(height: 10),
        // ROUTE PERMIT (v1.4.14 — owner faisla
        // 2026-11-09): ikhtiyari kagaz; is ka koi Master *_status
        // NAHI hai — haalat sirf ye hai ke photo record mein hai
        // ya nahi। (Fitness Certificate v1.4.19 se is card se
        // nikal kar upar apni Master-status wali row mein chala
        // gaya hai — yahan sirf Route Permit bacha hai।) Na hon
        // to ID par koi asar nahi, lekin driver ki khud-zimmedari
        // wali tasdeeq (registration mein qabool shuda) yahan bhi
        // dikhti hai aur kagaz poora karne ki yaad-dehani bhi —
        // kagaz milte hi yahin se photo lag jati hai (record
        // pakka)।
        const Text('Route Permit (Ikhtiyari)',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _permitDocRow(
                  label: 'Route Permit',
                  hasPhoto: p.permitPhotoPath.isNotEmpty,
                  onUpload: () => _reuploadDoc('route_permit'),
                ),
                const SizedBox(height: 8),
                Text(
                  p.permitFitnessDeclAtMs > 0
                      ? 'Khud-zimmedari ki tasdeeq aap ne ${DateTime.fromMillisecondsSinceEpoch(p.permitFitnessDeclAtMs).toString().split('.').first} par qabool ki thi — ye waqt saboot ke liye mehfooz hai. Permit/Fitness aap ki apni zimmedari hai; na honay par challan/gaari bandi ka zimmedar aap khud hain, Bozdar Safar nahi.'
                      : 'Khud-zimmedari ki tasdeeq abhi baqi hai — registration form ke "Fitness, Insurance aur Permit" wale qadam par qabool karein. Permit/Fitness aap ki apni zimmedari hai; na honay par challan/gaari bandi ka zimmedar aap khud honge, Bozdar Safar nahi.',
                  style: const TextStyle(fontSize: 12.5, height: 1.45),
                ),
                if (p.permitPhotoPath.isEmpty) ...[
                  const SizedBox(height: 6),
                  const Text(
                    'Yaad-dehani: jo kagaz abhi nahi hai, woh jald poora karke yahin se photo laga dein — aap ka record pakka ho jayega aur sadak par pareshani nahi hogi.',
                    style: TextStyle(
                        fontSize: 12.5,
                        color: Color(0xFF8D6E00),
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 4),
        // Profile selfie — Master ki ID wali photo. Is ka alag
        // *_status nahi hai; haalat = photo Master tak gayi ya nahi
        // (ID ki asal tasdeeq upar wale Account card mein hai).
        Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: Icon(
              p.profilePhotoPath.isNotEmpty
                  ? Icons.verified
                  : Icons.pending_actions,
              color: p.profilePhotoPath.isNotEmpty
                  ? Brand.green
                  : Brand.ajrakRed,
            ),
            title: const Text('Profile Selfie (ID wali photo)',
                style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(
              p.profilePhotoPath.isNotEmpty
                  ? 'Photo Master ke paas hai — ID ki tasdeeq upar wale card mein hai'
                  : 'Photo abhi baqi hai — camera se live selfie dein',
              style: TextStyle(
                  color: p.profilePhotoPath.isNotEmpty
                      ? Brand.green
                      : Brand.ajrakRed,
                  fontWeight: FontWeight.w600),
            ),
            trailing: p.profilePhotoPath.isEmpty
                ? OutlinedButton(
                    onPressed: () => _reuploadDoc('profile'),
                    child: const Text('Selfie Dein'),
                  )
                : null,
          ),
        ),
        const SizedBox(height: 18),
        Card(
          child: ListTile(
            leading: Icon(Icons.camera_alt,
                color: p.selfieToday ? Brand.green : Brand.ajrakRed),
            title: const Text('Rozana Live Selfie'),
            subtitle: Text(p.selfieToday
                ? 'Aaj ki selfie ho gayi (${p.selfieDate})'
                : 'Aaj ki selfie baqi hai — camera se hi hogi, gallery se nahi'),
            // Yahan wala 'Selfie Lein' button hata diya (v1.2.6 safai) —
            // wohi amal Home ke gate row aur duty-on par pehle se
            // hota hai; yahan sirf haalat dikhti hai.
            trailing: p.selfieToday
                ? const Icon(Icons.check_circle, color: Brand.green)
                : const Icon(Icons.pending_actions,
                    color: Brand.ajrakRed),
          ),
        ),
        const SizedBox(height: 14),
        // PASSWORD (v1.2.5 — malik ka hukm): har driver apna password
        // khud lagata hai; ek password sirf EK driver ka hota hai.
        // v1.2.6: registration baqi ho to password WIZARD ke qadam mein
        // lagta hai — yahan wale inline fields sirf un profiles ke
        // liye hain jin ki registration mukammal hai lekin password
        // abhi nahi laga (purane profiles), taaki do competing forms
        // na hon. Registration wale card (upar) se form khulta hai.
        if (p.pwdFp.isEmpty && !p.registrationComplete)
          const Card(
            child: ListTile(
              leading: Icon(Icons.lock_outline, color: Brand.ajrakRed),
              title: Text('Password baqi hai',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(
                  'Password registration form ke qadam mein lagayein — upar wale Registration card se form kholein.'),
            ),
          )
        else if (p.pwdFp.isEmpty)
          // FORM USOOL (2026-11-08): password ke inline khule fields
          // khatam — Profile sirf haalat dikhati hai aur button wohi
          // _SetPasswordDialog kholta hai jo duty-on par bhi ata hai
          // (usool, uniqueness check aur exact jumle bilkul waisay
          // hi — sirf jagah badli hai, amal nahi).
          Card(
            child: ListTile(
              leading:
                  const Icon(Icons.lock_outline, color: Brand.ajrakRed),
              title: const Text('Password baqi hai',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text(
                  'Har driver apna password khud lagata hai — ek password sirf ek hi driver ka hota hai. Duty shuru karne par yahi password manga jayega.'),
              trailing: TextButton(
                onPressed: () async {
                  final ok = await showDialog<bool>(
                    context: context,
                    barrierDismissible: false,
                    builder: (_) => _SetPasswordDialog(store: store),
                  );
                  if (ok == true && mounted) {
                    _snack('Password lag gaya.');
                    setState(() {});
                  }
                },
                child: const Text('Lagayein'),
              ),
            ),
          )
        else
          Card(
            child: ListTile(
              leading: const Icon(Icons.lock, color: Brand.green),
              title: const Text('Password set hai',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text(
                  'Duty shuru karne par password manga jata hai — ek password sirf aap ka hai.'),
              trailing: TextButton(
                onPressed: _changePassword,
                child: const Text('Badlein'),
              ),
            ),
          ),
        // v1.4.7 EMAIL (spec §1): verified Gmail ki haalat — ya
        // purane driver ke liye email darj karne ka darwaza।
        const SizedBox(height: 10),
        if (p.emailVerified)
          Card(
            child: ListTile(
              leading: const Icon(Icons.mark_email_read, color: Brand.green),
              title: const Text('Gmail — OTP verify hai',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(
                  '${p.email}\nLogout ke baad dobara login isi Gmail par aye OTP se hoga.'),
              isThreeLine: true,
            ),
          )
        else
          Card(
            child: ListTile(
              leading:
                  const Icon(Icons.email_outlined, color: Brand.ajrakRed),
              title: const Text('Gmail darj karein — lazmi hai',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text(
                  'Aap ki ID ke liye Gmail + OTP tasdeeq lazmi hai. Email darj karke code verify karein.'),
              trailing: TextButton(
                onPressed: () async {
                  final ok = await Navigator.of(context).push<bool>(
                    MaterialPageRoute(
                        builder: (_) => _EmailSetupPage(store: store)),
                  );
                  if (ok == true && mounted) {
                    _snack('Gmail verify ho gaya hai.');
                    setState(() {});
                  }
                },
                child: const Text('Darj Karein'),
              ),
            ),
          ),
        // v1.4.7 GAARI CHANGE (spec §7): wohi ID, nayi gaari —
        // Master ki tasdeeq ke baad update; purani gaari history
        // mein mehfooz।
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.swap_horiz,
                        color: Brand.green, size: 20),
                    SizedBox(width: 8),
                    Text('Meri Gaari',
                        style: TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 15)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                    '${p.vehicle} · ${p.vehicleBrand} ${p.vehicleModel} · Plate: ${p.plate.isEmpty ? '—' : p.plate}'),
                if (p.vehicleHistory.isNotEmpty)
                  Text(
                    'Purani gaariyon ka record: ${p.vehicleHistory.length} (history mehfooz hai)',
                    style:
                        const TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                const SizedBox(height: 8),
                if (p.vehicleChangeStatus == 'pending') ...[
                  const Text(
                    'Gaari change ki darkhwast Master ke paas hai — tasdeeq ka intezaar karein.',
                    style: TextStyle(
                        color: Color(0xFFB8860B),
                        fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 6),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final ok = await Backend.submitVehicleChange(
                          store, p.vehicleChangePending);
                      if (mounted) {
                        _snack(ok
                            ? 'Darkhwast dobara Master ko bhej di gayi hai.'
                            : 'Abhi nahi bheji ja saki — net check karke dobara koshish karein.');
                      }
                    },
                    icon: const Icon(Icons.refresh, size: 16),
                    label: const Text('Darkhwast Dobara Bhejein'),
                  ),
                ] else ...[
                  if (p.vehicleChangeStatus == 'rejected') ...[
                    Text(
                      'Pichli gaari change REJECT hui${p.vehicleChangeReason.isEmpty ? '' : ' — Wajah: ${p.vehicleChangeReason}'}',
                      style: const TextStyle(
                          color: Brand.ajrakRed,
                          fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 6),
                  ],
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        await Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => VehicleChangePage(store: store),
                        ));
                        if (mounted) setState(() {});
                      },
                      icon: const Icon(Icons.directions_car),
                      label: const Text('Gaari Change Karein'),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        // v1.4.7 LOGOUT: session OTP flag saaf — dobara duty ke
        // liye password ke baad Email OTP lazmi (jin ka email
        // verify hai)। Profile/record kuch delete NAHI hota।
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Logout karein?'),
                  content: const Text(
                      'Logout ke baad dobara duty shuru karne ke liye password ke saath aap ki Gmail par aya OTP code bhi lazmi hoga. Aap ka profile aur record mehfooz rahega.'),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('Rehne Dein')),
                    ElevatedButton(
                        onPressed: () => Navigator.pop(ctx, true),
                        child: const Text('Logout Karein')),
                  ],
                ),
              );
              if (ok == true) {
                await store.driverLogout();
                // v1.4.14: Auth session bhi saaf — dobara login
                // OTP se naya session banayega (plan §8.1.1)।
                unawaited(Backend.clearSession());
                unawaited(_syncDutyService());
                if (mounted) {
                  _snack('Logout ho gaya hai.');
                  setState(() {});
                }
              }
            },
            icon: const Icon(Icons.logout, size: 18),
            label: const Text('Logout'),
            style: OutlinedButton.styleFrom(
              foregroundColor: Brand.ajrakRed,
              side: const BorderSide(color: Brand.ajrakRed),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
        // v1.4.16 ACCOUNT DELETE: Logout se alag, mustaqil amal —
        // OTP tasdeeq + server RPC ke baad hi local wipe hota
        // hai (poora flow _deleteDriverAccount mein hai)।
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: TextButton.icon(
            onPressed: _deleteDriverAccount,
            icon: const Icon(Icons.delete_forever, size: 18),
            label: const Text('Account Delete Karein'),
            style: TextButton.styleFrom(
              foregroundColor: Brand.ajrakRed,
              padding: const EdgeInsets.symmetric(vertical: 10),
              textStyle:
                  const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700),
            ),
          ),
        ),
        // NOTE (v1.0.5): "Service Charges %" editor yahan kabhi tha
        // hi nahi rakha gaya — fee sirf Master app mein set hoti hai.
        // NOTE (FORM USOOL 2026-11-08): purana "Profile Save Karein"
        // wala khula form (naam/phone/plate/gaari ke inline fields
        // + un ke saath chalta password set) yahan se KHTAM hai —
        // Profile ab sirf status + buttons hai; har tabdeeli
        // RegistrationWizard mein step-by-step hoti hai.
      ],
    );
  }

  /// Permit/Fitness ki ek saadi row (v1.4.14): photo hai to
  /// sabz nishan + 'Record mein hai', nahi hai to 'Abhi nahi'
  /// + photo lagane ka button। Master ka koi faisla in par
  /// NAHI hota — ye sirf driver ke apne record ke kagaz hain।
  Widget _permitDocRow({
    required String label,
    required bool hasPhoto,
    required VoidCallback onUpload,
  }) {
    return Row(
      children: [
        Icon(
          hasPhoto ? Icons.verified : Icons.pending_actions,
          color: hasPhoto ? Brand.green : const Color(0xFFB8860B),
        ),
        const SizedBox(width: 9),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              Text(
                hasPhoto
                    ? 'Photo record mein hai ✓'
                    : 'Photo abhi nahi — ho to laga dein (ikhtiyari hai)',
                style: TextStyle(
                    fontSize: 12.5,
                    color: hasPhoto ? Brand.green : Colors.black54,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        OutlinedButton(
          onPressed: onUpload,
          child: Text(hasPhoto ? 'Badlein' : 'Photo Lagayein'),
        ),
      ],
    );
  }

  /// Mere Kagaz ki ek document row (v1.4.1): SIRF Master ka pull
  /// shuda faisla + us ki wajah lafz-ba-lafz. Teen asal haalatein:
  ///  - verified → 'Tasdeeq Shuda ✓' (sabz)
  ///  - rejected → 'Reject ✗' (laal) + Master ki wajah wali numaya
  ///    patti + 'Dobara Bhejein' — sirf yehi document dobara jata
  ///    hai (upload flow se; status driver NAHI badalta)
  ///  - rejected lekin nayi photo bhej di gayi → 'Dobara bhej diya
  ///    gaya — Intezaar Mein…' (amber; pichli wajah chhoti line mein)
  ///  - warna → 'Intezaar Mein…' (amber)
  /// Photo hi baqi ho to bhi yehi row 'Kagaz Dein' se sirf wohi
  /// photo mangti hai.
  Widget _mereKagazRow({
    required String group,
    required String label,
    required List<(String, String)> kinds,
    required bool photoMissing,
  }) {
    final status = p.masterStatusFor(group);
    final reason = p.masterReasonFor(group);
    final resubmitted = p.docGroupResubmitted(group);
    final rejected = status == 'rejected' && !resubmitted;
    // v1.4.19 REHNUMAI (malik ka hukm ~18:12): naye kagazon
    // (fitness/insurance/character) ke liye woh madad wali line
    // jo batati hai kagaz kahan se banta hai — photo baqi ho ya
    // reject ho, dono halaton mein row ke andar dikhti hai।
    final rehnumai = docRehnumaiFor(group);
    final (statusText, color, icon) = switch (status) {
      'verified' => ('Tasdeeq Shuda ✓', Brand.green, Icons.verified),
      'rejected' when resubmitted => (
          'Dobara bhej diya gaya — Intezaar Mein…',
          const Color(0xFFB8860B),
          Icons.hourglass_top
        ),
      'rejected' => ('Reject ✗', Brand.ajrakRed, Icons.cancel),
      _ => ('Intezaar Mein…', const Color(0xFFB8860B), Icons.pending_actions),
    };
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(label,
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
                Text(statusText,
                    style:
                        TextStyle(color: color, fontWeight: FontWeight.w800)),
              ],
            ),
            if (photoMissing && status != 'rejected') ...[
              const SizedBox(height: 6),
              const Text(
                'Photo abhi baqi hai — tasdeeq ke liye photo lazmi hai.',
                style: TextStyle(fontSize: 12.5, color: Brand.ajrakRed),
              ),
              if (rehnumai.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(rehnumai,
                    style: const TextStyle(
                        fontSize: 12.5,
                        height: 1.45,
                        color: Colors.black54)),
              ],
            ],
            if (rejected) ...[
              const SizedBox(height: 8),
              // Numaya wajah wali patti — Master ke alfaaz bilkul
              // waisay hi (verbatim) jo Master ne reject par likhe.
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFFDECEA),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Brand.ajrakRed),
                ),
                child: Text(
                  reason.isNotEmpty
                      ? 'Master ki wajah: $reason'
                      : 'Master ne ye document reject kiya hai (wajah nahi likhi gayi) — sahi kagaz dobara bhejein ya Master ko message karein.',
                  style: const TextStyle(
                      fontSize: 13,
                      color: Brand.ajrakRed,
                      fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => _reuploadGroup(kinds),
                  icon: const Icon(Icons.upload_file, size: 19),
                  label: const Text('Dobara Bhejein'),
                ),
              ),
              if (rehnumai.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(rehnumai,
                    style: const TextStyle(
                        fontSize: 12.5,
                        height: 1.45,
                        color: Colors.black54)),
              ],
            ] else if (status == 'rejected' && resubmitted) ...[
              const SizedBox(height: 6),
              Text(
                'Nayi photo Master ke paas chali gayi hai — naya faisla baqi hai.${reason.isNotEmpty ? ' Pichli wajah: $reason' : ''}',
                style: const TextStyle(fontSize: 12.5, color: Colors.black54),
              ),
              const SizedBox(height: 6),
              Align(
                alignment: Alignment.centerRight,
                child: OutlinedButton(
                  onPressed: () => _reuploadGroup(kinds),
                  child: const Text('Ek aur photo bhejein'),
                ),
              ),
            ] else if (photoMissing) ...[
              const SizedBox(height: 6),
              Align(
                alignment: Alignment.centerRight,
                child: OutlinedButton(
                  onPressed: () => _reuploadGroup(kinds),
                  child: const Text('Kagaz Dein'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Dobara bhejne ke liye photo chunnna: group mein ek se zyada
  /// photo ho (CNIC samne/peeche, gaari/kaghaz) to pehle kaun si
  /// photo, phir camera/gallery — registration wala wohi pattern.
  /// Sirf chuni hui EK photo profile mein lagti hai; baqi documents
  /// bilkul nahi chharte.
  Future<void> _reuploadGroup(List<(String, String)> kinds) async {
    if (kinds.length == 1) {
      await _reuploadDoc(kinds.first.$1);
      return;
    }
    final picked = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(14),
              child: Text('Kaun si photo dobara bhejni hai?',
                  style: TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 15)),
            ),
            for (final k in kinds)
              ListTile(
                leading: const Icon(Icons.photo_camera, color: Brand.green),
                title: Text(k.$2),
                onTap: () => Navigator.pop(ctx, k.$1),
              ),
          ],
        ),
      ),
    );
    if (picked != null && mounted) await _reuploadDoc(picked);
  }

  /// SIRF ek document ki nayi photo bhejna (v1.4.1): photo profile
  /// ke usi ek field mein lagti hai, phir store.save() → 'profile'
  /// hook → Backend.syncDriverDocs SIRF is kind ko dobara upload
  /// karta hai (docUploaded marker usi ek ka badla hota hai) —
  /// Master ke paas nayi photo puhanchti hai aur woh dobara check
  /// karta hai. Is amal mein driver koi *_status NAHI likhta:
  /// backend status Master ke naye faisle tak waisa hi rehta hai
  /// (migration v130 ka resubmit-trigger use 'pending' par wapas
  /// le jata hai — database khud, driver nahi). Profile selfie
  /// hamesha camera se hi (live) hoti hai.
  Future<void> _reuploadDoc(String kind) async {
    ImageSource? src = kind == 'profile' ? ImageSource.camera : null;
    src ??= await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Brand.green),
              title: const Text('Camera se tasveer lein'),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Brand.green),
              title: const Text('Gallery se chunein'),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (src == null || !mounted) return;
    try {
      final img = await _picker.pickImage(source: src, imageQuality: 85);
      if (img == null) {
        if (mounted) {
          _snack(
              'Tasveer nahi li gayi — camera band ho gaya ya permission nahi mili. Dobara koshish karein.');
        }
        return;
      }
      switch (kind) {
        case 'cnic_front':
          p.cnicFrontPath = img.path;
        case 'cnic_back':
          p.cnicBackPath = img.path;
        case 'vehicle':
          p.vehiclePhotoPath = img.path;
        case 'vehicle_reg':
          p.vehicleRegPath = img.path;
        case 'licence':
          p.licencePhotoPath = img.path;
        // v1.4.14: ikhtiyari kagaz — Mere Kagaz ke Route Permit
        // hisse se (koi Master *_status nahi; upload sirf record
        // ke liye hai — syncDriverDocs bucket bhej deta hai)।
        case 'route_permit':
          p.permitPhotoPath = img.path;
        // v1.4.19: Fitness ab Master-status wala kagaz hai
        // (fitness_status, migration v139) — baqi status walay
        // kagazon ki tarah resubmit marker lagta hai।
        case 'fitness_cert':
          p.fitnessPhotoPath = img.path;
        // v1.4.19: do naye kagaz — sirf in ki apni photo badalti
        // hai, baqi documents bilkul nahi chharte।
        case 'insurance':
          p.insurancePhotoPath = img.path;
        case 'character':
          p.characterPhotoPath = img.path;
        case 'profile':
          p.profilePhotoPath = img.path;
      }
      await store.save();
      final isPermitKind = kind == 'route_permit';
      if (!isPermitKind) {
        await store.markDocResubmitted(kind, img.path);
      }
      if (mounted) {
        _snack(isPermitKind
            ? 'Photo lag gayi hai — ye kagaz aap ke record mein mehfooz ho gaya hai.'
            : 'Dobara bhej diya gaya — Master dobara check karega.');
        setState(() {});
      }
    } catch (_) {
      if (mounted) _snack('Tasveer nahi li ja saki.');
    }
  }

}

/// A / B wala kaala gol-chokor badge — v1.4.29 (DRIVER-FLOW-SPEC
/// 2026-11-11): cardon/sheeton mein pickup = A, manzil = B ki
/// pehchan, bilkul map wale pins jaisi. Apna widget hai, kisi
/// doosri app ka asset/design NAHI.
Widget safarAbBadge(String letter, {double size = 26}) {
  return Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      color: const Color(0xFF141414),
      borderRadius: BorderRadius.circular(size * 0.28),
      border: Border.all(color: Colors.white, width: 1.6),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.25),
          blurRadius: 3,
          offset: const Offset(0, 1),
        ),
      ],
    ),
    alignment: Alignment.center,
    child: Text(
      letter,
      style: TextStyle(
        color: Colors.white,
        fontSize: size * 0.52,
        fontWeight: FontWeight.w900,
      ),
    ),
  );
}

/// Bara SLIDE-wala confirm button — v1.4.29 (spec 2026-11-11):
/// Arrived / Start Trip / Complete jaise ahem amal sirf gol
/// handle ko dayein kinare tak slide karne par hote hain —
/// galti se tap ho jane ka khatra khatam. Rang Bozdar Safar
/// ke hain: gehra sabz track, sunehra handle (peela NAHI —
/// sunehra hamara apna brand rang hai)।
class SlideConfirm extends StatefulWidget {
  final String label;
  final IconData handleIcon;
  final Future<void> Function() onConfirm;

  /// Bahari busy haalat (masalan start-code ki jaanch chal
  /// rahi ho) — slide band rehta hai।
  final bool busy;
  const SlideConfirm({
    super.key,
    required this.label,
    required this.onConfirm,
    this.handleIcon = Icons.arrow_forward,
    this.busy = false,
  });

  @override
  State<SlideConfirm> createState() => _SlideConfirmState();
}

class _SlideConfirmState extends State<SlideConfirm> {
  double _dx = 0;
  bool _busy = false;

  /// Slide band hai: apni amal-haalat ya bahari [SlideConfirm.busy]।
  bool get _locked => _busy || widget.busy;
  static const double _h = 58;
  static const double _handle = 50;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, cons) {
        final maxDx = cons.maxWidth - _handle - 8;
        final frac = maxDx <= 0 ? 0.0 : (_dx / maxDx).clamp(0.0, 1.0);
        return Container(
          height: _h,
          decoration: BoxDecoration(
            color: Brand.deepGreen,
            borderRadius: BorderRadius.circular(_h / 2),
            border: Border.all(color: Brand.gold, width: 1.2),
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: FractionallySizedBox(
                    widthFactor: frac,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Brand.green.withOpacity(0.55),
                        borderRadius: BorderRadius.circular(_h / 2),
                      ),
                    ),
                  ),
                ),
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(left: 30),
                  child: Text(
                    _locked ? '…' : widget.label,
                    style: TextStyle(
                      color: Colors.white.withOpacity(1 - frac * 0.55),
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 4 + _dx,
                top: 4,
                child: GestureDetector(
                  onHorizontalDragUpdate: _locked
                      ? null
                      : (d) => setState(() =>
                          _dx = (_dx + d.delta.dx).clamp(0.0, maxDx)),
                  onHorizontalDragEnd: _locked
                      ? null
                      : (_) async {
                          if (maxDx > 0 && _dx >= maxDx * 0.85) {
                            setState(() {
                              _busy = true;
                              _dx = maxDx;
                            });
                            await widget.onConfirm();
                            if (mounted) {
                              setState(() {
                                _busy = false;
                                _dx = 0;
                              });
                            }
                          } else {
                            setState(() => _dx = 0);
                          }
                        },
                  child: Container(
                    width: _handle,
                    height: _handle,
                    decoration: const BoxDecoration(
                      color: Brand.gold,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(widget.handleIcon,
                        color: Brand.deepGreen, size: 26),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Hadaf (pickup/manzil) tak ke asal route ka ETA chip —
/// RouteService (OSRM + cache) se banta hai. Driver ki position
/// ya asal route na mile to chip NAHI dikhta (jaali number
/// kabhi NAHI). Position ka ~100 m se zyada badlav (rounded
/// key) par hi dobara fetch hota hai — cache ki wajah se
/// sastah hai।
class _TargetEta extends StatefulWidget {
  final ll2.LatLng? from;
  final ll2.LatLng to;
  const _TargetEta({required this.from, required this.to});

  @override
  State<_TargetEta> createState() => _TargetEtaState();
}

class _TargetEtaState extends State<_TargetEta> {
  RouteResult? _r;
  String _key = '';

  String get _k {
    final f = widget.from;
    if (f == null) return '';
    return '${f.latitude.toStringAsFixed(3)},${f.longitude.toStringAsFixed(3)}>'
        '${widget.to.latitude.toStringAsFixed(3)},${widget.to.longitude.toStringAsFixed(3)}';
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(_TargetEta old) {
    super.didUpdateWidget(old);
    if (_k != _key) _load();
  }

  Future<void> _load() async {
    final f = widget.from;
    _key = _k;
    if (f == null) {
      if (mounted) setState(() => _r = null);
      return;
    }
    final key = _key;
    final r = await RouteService.fetch(f, widget.to);
    if (mounted && key == _key) setState(() => _r = r);
  }

  @override
  Widget build(BuildContext context) {
    final r = _r;
    if (r == null) return const SizedBox.shrink();
    final mins = (r.durationS / 60).round();
    final label = r.isStraightFallback
        ? fmtDist(r.distanceM)
        : '≈ ${mins < 1 ? 1 : mins} min · ${fmtDist(r.distanceM)}';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: Brand.deepGreen,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Brand.gold, width: 0.8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.schedule, size: 13, color: Brand.goldLight),
          const SizedBox(width: 4),
          Text(label,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

/// Live waiting display for an arrived ride: minutes ticking + current charge.
/// RIDE START CODE wala khana (v1.4.7, spec §3; v1.4.14 se code
/// 6-digit) — 'arrived' haalat mein active card par: driver sawari
/// se 6-digit code pooch kar daalta hai; sahi code par ride asal
/// mein SHURU। Ghalat code par koshish darj; 3 par Master ko
/// khabar (store.verifyAndStartRide)। Purani booking (code bana
/// hi nahi — v1.4.7 se pehle ki) par seedha "Ride Shuru Karein";
/// purani 4-digit code wali booking apne purane code se hi
/// shuru hoti hai।
class _StartCodeBox extends StatefulWidget {
  final Booking booking;
  final AppStore store;
  final VoidCallback onStarted;
  const _StartCodeBox({
    required this.booking,
    required this.store,
    required this.onStarted,
  });

  @override
  State<_StartCodeBox> createState() => _StartCodeBoxState();
}

class _StartCodeBoxState extends State<_StartCodeBox> {
  final _ctrl = TextEditingController();
  bool _busy = false;
  String? _error;

  Booking get b => widget.booking;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    final code = int.tryParse(_ctrl.text.trim()) ?? -1;
    // v1.4.14: code ab 6-digit hai (owner ka hukm 2026-11-09)।
    // Purani (v1.4.13 se pehle ki) booking ka apna code 4-digit
    // tha — woh booking apne purane code se hi shuru hogi
    // (uska code sawari ki app mein waisa hi dikhta hai)।
    final legacy = b.startCode > 0 && b.startCode < 100000;
    if (b.startCode > 0 &&
        _ctrl.text.trim().length != (legacy ? 4 : 6)) {
      setState(() => _error = legacy
          ? 'Sawari wala 4-digit code pura likhein.'
          : 'Sawari wala 6-digit code pura likhein.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final ok = await widget.store.verifyAndStartRide(b, code);
    if (!mounted) return;
    setState(() => _busy = false);
    if (ok) {
      widget.onStarted();
    } else {
      setState(() => _error = b.startCodeAttempts >= 3
          ? 'Ghalat code — 3 koshishen ho gayi hain, Master ko khabar bhej di gayi hai. Sawari se SAHI code le kar dobara likhein.'
          : 'Ghalat code — dobara koshish karein (koshish ${b.startCodeAttempts}/3).');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (b.startCode <= 0) {
      // Purani booking — code bana hi nahi tha; seedha shuru।
      // v1.4.29: Start bhi SLIDE se (galti se tap na ho)।
      return SlideConfirm(
        label: tr('start_legacy_slide'),
        handleIcon: Icons.play_arrow,
        busy: _busy,
        onConfirm: _submit,
      );
    }
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF6E0),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Brand.gold, width: 1.2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.pin, size: 18, color: Color(0xFFB8860B)),
              SizedBox(width: 6),
              Expanded(
                child: Text('Ride shuru karne ke liye START CODE',
                    style: TextStyle(fontWeight: FontWeight.w900)),
              ),
            ],
          ),
          const SizedBox(height: 4),
          const Text(
            'Sawari ki app par ek 6-digit code hai — sawari se pooch kar wohi code yahan likhein. Sahi code ke baghair ride shuru nahi hogi.',
            style: TextStyle(fontSize: 12.5),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _ctrl,
            keyboardType: TextInputType.number,
            maxLength: 6,
            textAlign: TextAlign.center,
            style: const TextStyle(
                fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 6),
            decoration: const InputDecoration(
              hintText: '••••••',
              counterText: '',
              isDense: true,
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          // v1.4.29: Start Trip bhi SLIDE se — code likh kar
          // slide karein; ghalat code par khana khud error dikha
          // dega aur slide wapas aa jayega।
          SlideConfirm(
            label: tr('start_slide'),
            handleIcon: Icons.play_arrow,
            busy: _busy,
            onConfirm: _submit,
          ),
          if (_error != null) ...[
            const SizedBox(height: 6),
            Text(_error!,
                style: const TextStyle(
                    color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
    );
  }
}

class _LiveWaiting extends StatefulWidget {
  final Booking booking;
  final AppStore store;
  const _LiveWaiting({required this.booking, required this.store});

  @override
  State<_LiveWaiting> createState() => _LiveWaitingState();
}

class _LiveWaitingState extends State<_LiveWaiting> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final mins = widget.store.liveWaitingMinutes(b);
    final charge = widget.store.liveWaitingCharge(b);
    final freeLeft = Fares.freeWaitingMinutes - mins;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Brand.cream,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Brand.gold),
      ),
      child: Row(
        children: [
          const Icon(Icons.timer, color: Brand.ajrakRed),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Intezaar: $mins minute',
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 15)),
                Text(
                  freeLeft > 0
                      ? 'Abhi $freeLeft minute muft baqi hain'
                      : 'Waiting charges ab tak: ${rs(charge)}',
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
          if (charge > 0)
            Text(rs(charge),
                style:
                    const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Password dialogs (v1.2.5) — set / unlock / change.
// Teeno mein wohi usool: asal password sirf fingerprint banta hai;
// uniqueness backend se check hoti hai; check na ho sake (offline)
// to aage NAHI barhte.
// ---------------------------------------------------------------------------

/// Pehli dafa password SET karna (duty-on par, jab pwdFp khaali ho).
/// EMAIL SETUP (v1.4.7) — purana (legacy) driver apni Gmail
/// darj karke OTP verify karta hai; kamyabi par email profile +
/// backend (drivers.email) dono jagah darj ho jati hai।
class _EmailSetupPage extends StatefulWidget {
  final AppStore store;
  const _EmailSetupPage({required this.store});

  @override
  State<_EmailSetupPage> createState() => _EmailSetupPageState();
}

class _EmailSetupPageState extends State<_EmailSetupPage> {
  late final _emailCtrl =
      TextEditingController(text: widget.store.profile.email);

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gmail Darj Karein')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Aap ki driver ID aap ki Gmail se bandhi rahegi. Gmail likhein, "Code bhejein" dabayein, phir email par aya 6-digit code verify karein.',
            style: TextStyle(fontSize: 14, height: 1.5),
          ),
          const SizedBox(height: 16),
          EmailOtpSection(
            emailCtrl: _emailCtrl,
            onVerified: (email) async {
              final nav = Navigator.of(context);
              await widget.store.applyDriverEmailVerified(email);
              unawaited(Backend.pushDriverEmail(
                widget.store.driverId,
                email,
                DateTime.fromMillisecondsSinceEpoch(
                    widget.store.profile.emailVerifiedAtMs),
              ));
              // v1.4.14: email verify = Auth session ban gaya —
              // driver pehchan usi se bandh do (link_driver)।
              unawaited(Backend.linkIdentities(widget.store));
              if (mounted) nav.pop(true);
            },
          ),
        ],
      ),
    );
  }
}

class _SetPasswordDialog extends StatefulWidget {
  final AppStore store;
  const _SetPasswordDialog({required this.store});

  @override
  State<_SetPasswordDialog> createState() => _SetPasswordDialogState();
}

class _SetPasswordDialogState extends State<_SetPasswordDialog> {
  final _c1 = TextEditingController();
  final _c2 = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _c1.dispose();
    _c2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final pw = _c1.text;
    if (pw.length < 6) {
      setState(() => _error = 'Password kam az kam 6 haroof ka ho.');
      return;
    }
    if (pw != _c2.text) {
      setState(() => _error = 'Dono password ek jaise nahi hain.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final fp = passwordFingerprint(pw);
    final taken =
        await Backend.passwordFingerprintTaken(widget.store, fp);
    if (!mounted) return;
    if (taken == null) {
      setState(() {
        _busy = false;
        _error =
            'Password ki safety check ke liye internet chahiye — net on karke dobara koshish karein.';
      });
      return;
    }
    if (taken) {
      _c1.clear();
      _c2.clear();
      setState(() {
        _busy = false;
        _error =
            'Ye password kisi aur ne lagaya hua hai, aap koi aur password lagayen';
      });
      return;
    }
    final p = widget.store.profile;
    p.pwdFp = fp;
    p.pwdFailCount = 0;
    p.pwdLockUntilMs = 0;
    await widget.store.save();
    widget.store.dutyUnlocked = true;
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Apna Password Lagayein'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
              'Duty shuru karne se pehle apna password lagayein. Ek password sirf ek hi driver ka hota hai — jo pehle lag jaye, wohi us ka ho jata hai.'),
          const SizedBox(height: 8),
          // HOTFIX v1.2.9 (RC3): qadam ki tartib pehle se saaf —
          // password pura hue baghair selfie wala qadam nahi ata,
          // aur driver samajhta tha selfie "khulti hi nahi".
          const Text(
            'Pehle apna password lagayein — us ke baad selfie wala qadam ayega.',
            style: TextStyle(
                fontWeight: FontWeight.w700, color: Brand.green),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _c1,
            obscureText: true,
            enabled: !_busy,
            decoration: const InputDecoration(
                labelText: 'Password (kam az kam 6 haroof)'),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _c2,
            obscureText: true,
            enabled: !_busy,
            decoration:
                const InputDecoration(labelText: 'Password dobara likhein'),
          ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!,
                style: const TextStyle(
                    color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(false),
          child: const Text('Rehne Dein'),
        ),
        ElevatedButton(
          onPressed: _busy ? null : _submit,
          child: Text(_busy ? 'Check ho raha hai…' : 'Password Lagayein'),
        ),
      ],
    );
  }
}

/// Duty unlock: set shuda password likhna. 5 ghalat = 10 minute lockout.
class _AskPasswordDialog extends StatefulWidget {
  final AppStore store;
  const _AskPasswordDialog({required this.store});

  @override
  State<_AskPasswordDialog> createState() => _AskPasswordDialogState();
}

class _AskPasswordDialogState extends State<_AskPasswordDialog> {
  final _c = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final p = widget.store.profile;
    if (passwordFingerprint(_c.text) == p.pwdFp) {
      p.pwdFailCount = 0;
      await widget.store.save();
      widget.store.dutyUnlocked = true;
      if (mounted) Navigator.of(context).pop(true);
      return;
    }
    p.pwdFailCount += 1;
    if (p.pwdFailCount >= 5) {
      // Lockout: ginati zero karke 10 minute ka taala — waqt khatm
      // hone par 5 nayi koshishen milengi.
      p.pwdFailCount = 0;
      p.pwdLockUntilMs =
          DateTime.now().millisecondsSinceEpoch + 10 * 60 * 1000;
      await widget.store.save();
      if (mounted) Navigator.of(context).pop(false);
      return;
    }
    await widget.store.save();
    if (!mounted) return;
    _c.clear();
    setState(() => _error =
        'Ghalat password — ${5 - p.pwdFailCount} koshishen baqi hain.');
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Password Likhein'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Duty shuru karne ke liye apna password likhein.'),
          const SizedBox(height: 12),
          TextField(
            controller: _c,
            obscureText: true,
            autofocus: true,
            decoration: const InputDecoration(labelText: 'Password'),
            onSubmitted: (_) => _submit(),
          ),
          // FINAL-PACK C-PD: bhool jane par asal rasta — Master
          // aarzi password laga kar must_change_password on kar
          // deta hai, phir upar wala lazmi-change flow chalta hai.
          const SizedBox(height: 10),
          const Text(
            'Password bhool gaye? Master se rabta karein — 0332 9467211',
            style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
                color: Brand.greenDark),
          ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!,
                style: const TextStyle(
                    color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: const Text('Rehne Dein'),
        ),
        ElevatedButton(
          onPressed: _submit,
          child: const Text('Duty Shuru Karein'),
        ),
      ],
    );
  }
}

/// FINAL-PACK C-PD — LAZMI password change: Master ke diye hue
/// AARZI password se unlock hone ke baad driver apna naya password
/// lagata hai. Usool wohi jo set/change dialogs ke hain:
/// fingerprint + backend uniqueness check (passwordFingerprintTaken)
/// — check na ho sake (offline) to aage NAHI barhte; takraav par
/// wohi pakka jumla. Is dialog mein "Rehne Dein" NAHI hai aur
/// barrierDismissible:false ke saath ye flow bypass NAHI ho sakta:
/// sirf kamyab change hi true lautata hai. Kamyabi par naya pwd_fp
/// + must_change_password=false backend par push hota hai
/// (Backend.pushDriverPasswordReset — column na ho to sirf pwd_fp
/// wala rasta chal jata hai) aur local flag saaf ho jata hai.
class _MustChangePasswordDialog extends StatefulWidget {
  final AppStore store;
  const _MustChangePasswordDialog({required this.store});

  @override
  State<_MustChangePasswordDialog> createState() =>
      _MustChangePasswordDialogState();
}

class _MustChangePasswordDialogState
    extends State<_MustChangePasswordDialog> {
  final _n1 = TextEditingController();
  final _n2 = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _n1.dispose();
    _n2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final p = widget.store.profile;
    final pw = _n1.text;
    if (pw.length < 6) {
      setState(() => _error = 'Naya password kam az kam 6 haroof ka ho.');
      return;
    }
    if (pw != _n2.text) {
      setState(() => _error = 'Dono password ek jaise nahi hain.');
      return;
    }
    final fp = passwordFingerprint(pw);
    if (fp == p.pwdFp) {
      setState(() => _error =
          'Ye aarzi password hi hai — apna koi NAYA password lagayein.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final taken =
        await Backend.passwordFingerprintTaken(widget.store, fp);
    if (!mounted) return;
    if (taken == null) {
      setState(() {
        _busy = false;
        _error =
            'Password ki safety check ke liye internet chahiye — net on karke dobara koshish karein.';
      });
      return;
    }
    if (taken) {
      _n1.clear();
      _n2.clear();
      setState(() {
        _busy = false;
        _error =
            'Ye password kisi aur ne lagaya hua hai, aap koi aur password lagayen';
      });
      return;
    }
    p.pwdFp = fp;
    p.mustChangePassword = false;
    p.pwdFailCount = 0;
    p.pwdLockUntilMs = 0;
    await widget.store.save();
    widget.store.dutyUnlocked = true;
    // Backend par naya fingerprint + must_change_password=false
    // (best-effort — column na ho to pushDriverPasswordReset khud
    // sirf pwd_fp wale raste par gir jata hai; local flag upar
    // saaf ho chuka hai).
    unawaited(Backend.pushDriverPasswordReset(widget.store));
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Naya Password Lagayein'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
                'Master ne aap ko aarzi password diya tha. Duty shuru karne se pehle apna NAYA password lagana lazmi hai — baghair is ke duty aage nahi barhegi.'),
            const SizedBox(height: 12),
            TextField(
              controller: _n1,
              obscureText: true,
              enabled: !_busy,
              decoration: const InputDecoration(
                  labelText: 'Naya password (kam az kam 6 haroof)'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _n2,
              obscureText: true,
              enabled: !_busy,
              decoration: const InputDecoration(
                  labelText: 'Naya password dobara likhein'),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!,
                  style: const TextStyle(
                      color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
            ],
          ],
        ),
      ),
      actions: [
        ElevatedButton(
          onPressed: _busy ? null : _submit,
          child: Text(_busy ? 'Check ho raha hai…' : 'Password Lagayein'),
        ),
      ],
    );
  }
}

/// Password badalna: pehle mojooda password ki tasdeeq, phir naya —
/// naye par wohi uniqueness check.
class _ChangePasswordDialog extends StatefulWidget {
  final AppStore store;
  const _ChangePasswordDialog({required this.store});

  @override
  State<_ChangePasswordDialog> createState() =>
      _ChangePasswordDialogState();
}

class _ChangePasswordDialogState extends State<_ChangePasswordDialog> {
  final _cur = TextEditingController();
  final _n1 = TextEditingController();
  final _n2 = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _cur.dispose();
    _n1.dispose();
    _n2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final p = widget.store.profile;
    if (passwordFingerprint(_cur.text) != p.pwdFp) {
      setState(() => _error = 'Mojooda password ghalat hai.');
      return;
    }
    final pw = _n1.text;
    if (pw.length < 6) {
      setState(() => _error = 'Naya password kam az kam 6 haroof ka ho.');
      return;
    }
    if (pw != _n2.text) {
      setState(() => _error = 'Dono naye password ek jaise nahi hain.');
      return;
    }
    final fp = passwordFingerprint(pw);
    if (fp == p.pwdFp) {
      setState(() =>
          _error = 'Ye aap ka mojooda password hi hai — koi aur lagayein.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final taken =
        await Backend.passwordFingerprintTaken(widget.store, fp);
    if (!mounted) return;
    if (taken == null) {
      setState(() {
        _busy = false;
        _error =
            'Password ki safety check ke liye internet chahiye — net on karke dobara koshish karein.';
      });
      return;
    }
    if (taken) {
      _n1.clear();
      _n2.clear();
      setState(() {
        _busy = false;
        _error =
            'Ye password kisi aur ne lagaya hua hai, aap koi aur password lagayen';
      });
      return;
    }
    p.pwdFp = fp;
    p.pwdFailCount = 0;
    p.pwdLockUntilMs = 0;
    await widget.store.save();
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Password Badlein'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _cur,
              obscureText: true,
              enabled: !_busy,
              decoration:
                  const InputDecoration(labelText: 'Mojooda password'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _n1,
              obscureText: true,
              enabled: !_busy,
              decoration: const InputDecoration(
                  labelText: 'Naya password (kam az kam 6 haroof)'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _n2,
              obscureText: true,
              enabled: !_busy,
              decoration: const InputDecoration(
                  labelText: 'Naya password dobara likhein'),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!,
                  style: const TextStyle(
                      color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(false),
          child: const Text('Rehne Dein'),
        ),
        ElevatedButton(
          onPressed: _busy ? null : _submit,
          child: Text(_busy ? 'Check ho raha hai…' : 'Password Badlein'),
        ),
      ],
    );
  }
}


// ---------------------------------------------------------------------------
// MONTHLY PACKAGES — DRIVER (v1.4.25, postmortem #9)
// ---------------------------------------------------------------------------

/// Driver ke Monthly Packages ka safha: (1) mujhe ASSIGN shuda
/// packages, (2) KHULE naye packages jin par "Qubool Karein" se
/// package driver ke naam pakka ho jata hai — package ki fee
/// row par pehle se bandhi hai, assign hote hi wohi fee isi
/// driver ki ho jati hai (Master ka Fees Register wohi parhta
/// hai)। Data backend se ata hai; jawab na mile to saaf khaali
/// haalat dikhti hai — jhooti list kabhi NAHI।
class _MonthlyPackagesPage extends StatefulWidget {
  final AppStore store;
  const _MonthlyPackagesPage({required this.store});

  @override
  State<_MonthlyPackagesPage> createState() => _MonthlyPackagesPageState();
}

class _MonthlyPackagesPageState extends State<_MonthlyPackagesPage> {
  bool _loading = true;
  bool _claiming = false;
  List<Map<String, dynamic>> _mine = [];
  List<Map<String, dynamic>> _open = [];

  AppStore get store => widget.store;

  @override
  void initState() {
    super.initState();
    unawaited(_load());
  }

  Future<void> _load() async {
    final mine = await Backend.fetchMyPackages(store);
    final open = await Backend.fetchOpenPackages();
    if (!mounted) return;
    setState(() {
      _mine = mine;
      _open = open;
      _loading = false;
    });
  }

  String _line(Map<String, dynamic> r) {
    final km = (r['km'] as num?)?.toDouble() ?? 0;
    final days = (r['days'] as num?)?.toInt() ?? 0;
    final amount = (r['amount'] as num?)?.toInt() ?? 0;
    return '${r['vehicle'] ?? ''} · ${km.toStringAsFixed(1)} km rozana · '
        '$days din · kul ${rs(amount)}';
  }

  Future<void> _claim(Map<String, dynamic> r) async {
    if (_claiming) return;
    final id = r['id']?.toString() ?? '';
    if (id.isEmpty) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Package Qubool Karein?'),
        content: Text(
            '${r['pickup'] ?? ''} → ${r['drop_off'] ?? ''}\n${_line(r)}\n\n'
            'Qubool karne par ye package aap ke naam pakka ho jayega — rozana wohi sawari, wohi jagah, wohi waqt. Package ki 10% service fee Master ke hisaab mein aap ke naam darj hogi (payment par).'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Rehne Dein'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Qubool Karein'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _claiming = true);
    final done = await Backend.claimPackage(store, id);
    if (!mounted) return;
    setState(() => _claiming = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(done
          ? 'Package aap ke naam pakka ho gaya hai.'
          : 'Package qubool nahi ho saka — ho sakta hai kisi aur driver ne pehle le liya ho, ya internet ka masla hai. Dobara koshish karein.'),
    ));
    if (done) await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Monthly Packages'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Dobara load karein',
            onPressed: _loading ? null : _load,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(14),
              children: [
                const Text('Mere Packages',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                if (_mine.isEmpty)
                  const Text('Abhi aap ko koi package assign nahi hua.',
                      style: TextStyle(color: Colors.black54)),
                ..._mine.map((r) => Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: ListTile(
                        leading: const Icon(Icons.calendar_month,
                            color: Brand.green),
                        title: Text('${r['pickup'] ?? ''} → ${r['drop_off'] ?? ''}',
                            style:
                                const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text(
                            '${r['customer_name'] ?? ''}\n${_line(r)}'),
                        isThreeLine: true,
                        trailing: r['paid'] == true
                            ? const Chip(
                                label: Text('Paid'),
                                visualDensity: VisualDensity.compact)
                            : null,
                      ),
                    )),
                const SizedBox(height: 18),
                const Text('Naye Khule Packages',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                if (_open.isEmpty)
                  const Text(
                      'Abhi koi naya khula package nahi hai — naya package bane to yahan nazar ayega.',
                      style: TextStyle(color: Colors.black54)),
                ..._open.map((r) => Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          ListTile(
                            leading: const Icon(Icons.calendar_month_outlined,
                                color: Brand.green),
                            title: Text(
                                '${r['pickup'] ?? ''} → ${r['drop_off'] ?? ''}',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w700)),
                            subtitle: Text(_line(r)),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
                            child: ElevatedButton(
                              onPressed: _claiming ? null : () => _claim(r),
                              child: const Text('Qubool Karein'),
                            ),
                          ),
                        ],
                      ),
                    )),
              ],
            ),
    );
  }
}
