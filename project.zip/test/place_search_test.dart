// v1.4.29 — ASAL JAGAH SEARCH (geocoding) ke unit tests:
// Nominatim JSON ki parsing, label (naam + sheher) ki tarkeeb
// aur request URI (countrycodes=pk) ki jaanch। Live network
// test NAHI hai — parsing/URI wohi hissa hai jo app chalati hai।
import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart' as ll2;
import 'package:safar/place_search.dart';

void main() {
  group('PlaceSearch — Nominatim parsing', () {
    test('"Mazar" ki misaal: Mazar-e-Quaid Karachi saaf label ke saath', () {
      // Asal Nominatim jawaab ki shakal (mukhtasar)।
      const body = '''
[
  {
    "name": "Mazar-e-Quaid",
    "display_name": "Mazar-e-Quaid, Shahrah-e-Quaideen, Karachi, Sindh, Pakistan",
    "lat": "24.8754",
    "lon": "67.0409",
    "address": {"city": "Karachi", "state": "Sindh", "country": "Pakistan"}
  },
  {
    "name": "Mazar-e-Quaid",
    "display_name": "Mazar-e-Quaid, Hyderabad, Sindh, Pakistan",
    "lat": "25.3960",
    "lon": "68.3779",
    "address": {"city": "Hyderabad", "state": "Sindh", "country": "Pakistan"}
  }
]
''';
      final results = PlaceSearch.parseResults(body);
      expect(results.length, 2);
      // Sheher label mein hai — do sheheron ki ek-naam jagah
      // alag pehchani jati hai (owner ki shart)।
      expect(results[0].label, 'Mazar-e-Quaid, Karachi');
      expect(results[1].label, 'Mazar-e-Quaid, Hyderabad');
      expect(results[0].point.latitude, closeTo(24.8754, 0.0001));
      expect(results[0].point.longitude, closeTo(67.0409, 0.0001));
    });

    test('sheher na mile to sooba label mein ata hai', () {
      final r = PlaceResult.fromNominatimJson({
        'name': 'Cholistan Fort',
        'display_name': 'Cholistan Fort, Punjab, Pakistan',
        'lat': '28.7679',
        'lon': '71.3340',
        'address': {'state': 'Punjab'},
      });
      expect(r.label, 'Cholistan Fort, Punjab');
    });

    test('khaali/ghalat jawaab par results khaali (jaali kuch NAHI)', () {
      expect(PlaceSearch.parseResults('[]'), isEmpty);
      expect(PlaceSearch.parseResults('{"error":"x"}'), isEmpty);
    });
  });

  group('PlaceSearch — request URI', () {
    test('countrycodes=pk lazmi; bias viewbox bounded=0 ke saath', () {
      final uri = PlaceSearch.buildUri('Mazar',
          near: const ll2.LatLng(24.86, 67.0));
      expect(uri.host, 'nominatim.openstreetmap.org');
      expect(uri.queryParameters['countrycodes'], 'pk');
      expect(uri.queryParameters['q'], 'Mazar');
      expect(uri.queryParameters['bounded'], '0');
      expect(uri.queryParameters.containsKey('viewbox'), isTrue);
    });

    test('spelling variants: chirangi -> chowrangi wali koshish banti hai', () {
      // Malik ka live masla 2026-11-12: ghalat spelling par
      // Nominatim 0 results deta hai — doosri koshish durust
      // spelling se lazmi hai।
      final v = PlaceSearch.queryVariants('munawar chirangi');
      expect(v.first, 'munawar chirangi');
      expect(v, contains('munawar chowrangi'));
    });

    test('correction: "chirangi" theek ho kar "chowrangi" banta hai', () {
      expect(PlaceSearch.correctQuery('munawar chirangi'),
          'munawar chowrangi');
    });

    test('correction: "chorangi" bhi theek hota hai', () {
      expect(PlaceSearch.correctQuery('munawar chorangi'),
          'munawar chowrangi');
    });

    test('correction: sahi spelling chhedi NAHI jati', () {
      expect(PlaceSearch.correctQuery('munawar chowrangi'), isNull);
      expect(PlaceSearch.correctQuery('mazar-e-quaid karachi'), isNull);
    });

    test('correction: ghair-mutalliq lafz nahi badalta', () {
      expect(PlaceSearch.correctQuery('munawar zaman road'), isNull);
    });

    test('variants: sahi spelling par ek hi koshish, dohrao NAHI', () {
      expect(PlaceSearch.queryVariants('Munawar Chowrangi'),
          ['Munawar Chowrangi']);
      expect(PlaceSearch.queryVariants('  Mazar-e-Quaid  '),
          ['Mazar-e-Quaid']);
    });

    test('3 harf se kam par network call hi NAHI hoti', () async {
      expect(await PlaceSearch.search('ab'), isEmpty);
    });
  });

  group('PlaceSearch.sortByDistance — v1.4.42 doori ki tartib', () {
    PlaceResult at(String name, double lat, double lon) => PlaceResult(
          name: name,
          label: name,
          displayName: name,
          point: ll2.LatLng(lat, lon),
        );

    test('qareeb pehle: door ki hum-naam jagah neeche chali jati hai', () {
      // Pickup: North Karachi (4K Chowrangi ke paas)।
      const near = ll2.LatLng(24.9820, 67.0690);
      final input = [
        at('Door Wala', 25.3960, 68.3779), // Hyderabad taraf — bohat door
        at('Qareeb Wala', 24.9890, 67.0750), // ~1 km
        at('Beech Wala', 25.0500, 67.1200), // ~9 km
      ];
      final out = PlaceSearch.sortByDistance(input, near);
      expect(out.map((r) => r.name).toList(),
          ['Qareeb Wala', 'Beech Wala', 'Door Wala']);
      // Asal list ki tartib NAHI badalti (copy par kaam hota hai)।
      expect(input.map((r) => r.name).toList(),
          ['Door Wala', 'Qareeb Wala', 'Beech Wala']);
    });

    test('khaali aur ek-result wali list waisi ki waisi', () {
      const near = ll2.LatLng(24.8608, 67.0011);
      expect(PlaceSearch.sortByDistance(const [], near), isEmpty);
      final one = [at('Akeli', 24.8700, 67.0100)];
      expect(PlaceSearch.sortByDistance(one, near).single.name, 'Akeli');
    });

    test('distanceLabel: m/km ki saaf shakal', () {
      const near = ll2.LatLng(24.8608, 67.0011);
      expect(
          PlaceSearch.distanceLabel(near, const ll2.LatLng(24.8618, 67.0016)),
          startsWith('≈ '));
      expect(
          PlaceSearch.distanceLabel(near, const ll2.LatLng(24.8618, 67.0016)),
          endsWith(' m'));
      expect(
          PlaceSearch.distanceLabel(near, const ll2.LatLng(24.9500, 67.0500)),
          endsWith(' km'));
    });
  });
}
