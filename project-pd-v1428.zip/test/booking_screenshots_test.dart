// v1.4.28 — SCREENSHOT HARNESS (malik ki approval ke liye):
// ASAL PassengerSide screen ko test environment mein render
// karke 5 haalaton ki PNG banata hai — koi alag preview page
// NAHI, wohi asal code/widgets hain jo app mein chalte hain।
//
// Har haalat apni ALAG test hai taake ek ka render slow ho
// to baqi mehfooz rahen (is VM par raster boht slow hai)।
//  S1 Home (map + "Kahan Jana Hai?" bar + 5 gaari tiles)
//  S2 Booking flow — sirf Pickup/Drop + jagahon ki list +
//     "Map Se Pin Lagayein" (tafseel abhi band)
//  S4 Pin mode (poora map + hidayat patti + Wapas)
//  S3 Booking ready (drop pin + asal route ke baad gaariyan,
//     note, "Ride Pakki Karein" — kul kiraya NAHI, lock hai)
//  S5 Menu/Profile tab (header + shortcuts + list rows)
//
// NOTE (imaandari): test environment mein MapLibre ka asal
// map (platform view + online tiles) render NAHI hota — map
// wali jagah khaali/placeholder aati hai। PNGs mein wohi
// asal haalat hai; baqi saari UI (panel, bar, menu) asal
// app ki hai। Route S3 ke liye RouteService ke cache mein
// pehle se mehfooz ASAL route (usi pair ka) seed kiya gaya
// hai — ye wohi rasta hai jo app offline/cache par leti hai,
// koi jaali fare NAHI banta (doori cache wale route ki hai)।
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:safar/passenger.dart';
import 'package:safar/store.dart';
import 'package:safar/theme.dart';

const _shotsDir =
    '/home/hatch/workspace/bozdar-safar/builds/booking-fix-shots';
const _fontsDir =
    '/home/hatch/workspace/flutter-sdk/bin/cache/artifacts/material_fonts';

// Pickup = Karachi center (default), Drop = Clifton wala
// saved place — isi pair ka cache route seed hota hai।
const _routeKey = 'route_v1_24.861,67.001|24.880,67.020';

Future<void> _loadFonts() async {
  final roboto = FontLoader('Roboto');
  // NOTE: Roboto-Black (w900) test renderer mein blocks ban
  // jata hai — is liye Black ki jagah Bold hi do dafa, taake
  // w900 wale button texts bhi asal harfon mein ayen।
  for (final f in [
    'Roboto-Regular.ttf',
    'Roboto-Medium.ttf',
    'Roboto-Bold.ttf',
    'Roboto-Bold.ttf',
  ]) {
    final bytes = await File('$_fontsDir/$f').readAsBytes();
    roboto.addFont(Future.value(ByteData.view(bytes.buffer)));
  }
  await roboto.load();
  final icons = FontLoader('Material Icons');
  final iconBytes =
      await File('$_fontsDir/MaterialIcons-Regular.otf').readAsBytes();
  icons.addFont(Future.value(ByteData.view(iconBytes.buffer)));
  await icons.load();
}

AppStore _seededStore() {
  final s = AppStore();
  s.passengerName = 'Ahmed Raza';
  s.passengerPhone = '0300 1234567';
  s.savedPlaces = [
    SavedPlace(
      id: 'sp1',
      name: 'Clifton',
      label: 'Clifton Beach, Karachi',
      lat: 24.8800,
      lng: 67.0200,
      hasPin: true,
    ),
  ];
  s.bookings = [
    Booking(
      id: 'old1',
      passengerName: 'Ahmed Raza',
      passengerPhone: '0300 1234567',
      pickupLabel: 'Meri Location',
      dropLabel: 'Saddar, Karachi',
      pickupLat: 24.8608,
      pickupLng: 67.0011,
      dropLat: 24.8550,
      dropLng: 67.0050,
      hasDropPin: true,
      vehicle: 'Rickshaw',
      distanceKm: 2.1,
      fare: 105,
      note: '',
      status: 'completed',
      createdAt: DateTime(2026, 11, 10),
    ),
  ];
  return s;
}

Future<GlobalKey> _pumpApp(WidgetTester tester) async {
  final routeJson = jsonEncode({
    'pts': [
      [24.8608, 67.0011],
      [24.8700, 67.0100],
      [24.8800, 67.0200],
    ],
    'd': 3400.0,
    't': 600.0,
    'steps': <dynamic>[],
    'fb': false,
    'ts': DateTime.now().millisecondsSinceEpoch,
  });
  SharedPreferences.setMockInitialValues({_routeKey: routeJson});
  tester.view.devicePixelRatio = 1.0;
  tester.view.physicalSize = const Size(390, 844);
  final shotKey = GlobalKey();
  await tester.pumpWidget(
    RepaintBoundary(
      key: shotKey,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: Brand.theme(),
        home: PassengerSide(store: _seededStore(), onSwitchToDriver: () {}),
      ),
    ),
  );
  await tester.pump();
  await tester.pump(const Duration(milliseconds: 300));
  await tester.pump();
  return shotKey;
}

Future<void> _shot(WidgetTester tester, GlobalKey key, String name) async {
  final boundary =
      key.currentContext!.findRenderObject()! as RenderRepaintBoundary;
  final image = await tester.runAsync(() => boundary.toImage(pixelRatio: 1.0));
  expect(image, isNotNull, reason: '$name ka render na ban saka');
  final data = await image!.toByteData(format: ui.ImageByteFormat.png);
  File('$_shotsDir/$name').writeAsBytesSync(data!.buffer.asUint8List());
}

Future<void> _openFlow(WidgetTester tester) async {
  await tester.tap(find.text('Kahan Jana Hai?'));
  await tester.pump();
  await tester.pump(const Duration(milliseconds: 300));
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  // Fonts + folder setUpAll mein — ye asal (real) async kaam
  // hai; testWidgets ke fake-async zone ke ANDAR file IO
  // atak jata hai।
  setUpAll(() async {
    debugDefaultTargetPlatformOverride = TargetPlatform.android;
    Directory(_shotsDir).createSync(recursive: true);
    await _loadFonts();
    // MapLibre ka AndroidView test engine mein asal platform
    // view NAHI bana sakta — channel mock na ho to har layout
    // par MissingPluginException test ko gira deta hai। Mock
    // ke baad map wali jagah khaali rehti hai (asal tiles sirf
    // phone par ati hain — notes mein darj hai)।
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
      const MethodChannel('flutter/platform_views'),
      // 'create' ko texture id (int) wapas chahiye, baqi null।
      (MethodCall call) async => call.method == 'create' ? 0 : null,
    );
    // MapLibre ke apne method channels (har map instance ka
    // alag channel) — warna 'map#waitForMap' jaisi calls par
    // MissingPluginException test ko gira deta hai।
    for (var i = 0; i < 4; i++) {
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(
        MethodChannel('plugins.flutter.io/maplibre_gl_$i'),
        (MethodCall call) async => null,
      );
    }
  });

  tearDownAll(() {
    debugDefaultTargetPlatformOverride = null;
  });

  testWidgets('S1 — Home', (WidgetTester tester) async {
    final key = await _pumpApp(tester);
    addTearDown(tester.view.reset);
    expect(find.text('Kahan Jana Hai?'), findsOneWidget);
    expect(find.text('Ride Pakki Karein'), findsNothing);
    for (final v in ['Rickshaw', 'Bike', 'Car', 'Taxi', 'Van']) {
      expect(find.text(v), findsWidgets, reason: 'tile $v gayab hai');
    }
    await _shot(tester, key, 's1-home.png');
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets('S2 — Booking flow stage 1', (WidgetTester tester) async {
    final key = await _pumpApp(tester);
    addTearDown(tester.view.reset);
    await _openFlow(tester);
    expect(find.text('Map Se Pin Lagayein'), findsOneWidget);
    expect(find.text('Mehfooz aur Pichhli Jagahen'), findsOneWidget);
    expect(find.text('Ride Pakki Karein'), findsNothing);
    await _shot(tester, key, 's2-booking.png');
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets('S4 — Pin mode', (WidgetTester tester) async {
    final key = await _pumpApp(tester);
    addTearDown(tester.view.reset);
    await _openFlow(tester);
    await tester.tap(find.text('Map Se Pin Lagayein'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('Apni manzil ki jagah map par tap karein'),
        findsOneWidget);
    expect(find.text('Wapas'), findsWidgets);
    expect(find.text('Kahan Jana Hai?'), findsNothing);
    expect(find.text('Ride Pakki Karein'), findsNothing);
    await _shot(tester, key, 's4-pin-mode.png');
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets('S3 — Drop + route ke baad', (WidgetTester tester) async {
    final key = await _pumpApp(tester);
    addTearDown(tester.view.reset);
    await _openFlow(tester);
    await tester.ensureVisible(find.text('Clifton'));
    await tester.pump();
    await tester.tap(find.text('Clifton'));
    // Cache se asal route ane ke liye chand pumps (asal fetch
    // ka cache wala rasta)।
    for (var i = 0; i < 6; i++) {
      await tester.pump(const Duration(milliseconds: 150));
    }
    expect(find.text('Ride Pakki Karein'), findsOneWidget,
        reason: 'drop+route ke baad bhi booking button na khula');
    // Sheet ko upar scroll karke gaariyan + note + button
    // frame mein lao।
    final sheetScroll = find.byType(SingleChildScrollView);
    await tester.drag(sheetScroll, const Offset(0, -260));
    await tester.pump(const Duration(milliseconds: 200));
    await tester.drag(sheetScroll, const Offset(0, -260));
    await tester.pump(const Duration(milliseconds: 200));
    await _shot(tester, key, 's3-booking-ready.png');
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets('S5 — Menu / Profile tab', (WidgetTester tester) async {
    final key = await _pumpApp(tester);
    addTearDown(tester.view.reset);
    await tester.tap(find.text('Profile'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('Madad / Support'), findsOneWidget);
    // Neeche wali rows pehle scroll karke verify (ListView
    // fold ke neeche wali rows build hi nahi karti), phir
    // wapas upar karke asal pehli haalat capture।
    await tester.drag(find.byType(ListView), const Offset(0, -520));
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('Kiraye Ki List'), findsWidgets);
    expect(find.text('Maloomat / About'), findsWidgets);
    await tester.drag(find.byType(ListView), const Offset(0, 520));
    await tester.pump(const Duration(milliseconds: 300));
    await _shot(tester, key, 's5-menu.png');
    await tester.pumpWidget(const SizedBox());
  });
}
