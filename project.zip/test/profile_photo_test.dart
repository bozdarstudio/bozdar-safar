// v1.4.22 — PROFILE PHOTO HADD ke tests (malik ka hukm
// 2026-11-10 23:36 + 23:40): kul 3 dafa ki hadd ka khalis
// hisaab, driver/passenger notice ke asal jumle, aur
// DriverProfile ke naye fields ka JSON record।
import 'package:flutter_test/flutter_test.dart';
import 'package:safar/profile_photo.dart';
import 'package:safar/store.dart';

void main() {
  group('ProfilePhotoLimit — kul 3 dafa ki hadd', () {
    test('hadd 3 hai', () {
      expect(ProfilePhotoLimit.maxChanges, 3);
    });

    test('baqi moqay ginti ke hisaab se', () {
      expect(ProfilePhotoLimit.remaining(0), 3);
      expect(ProfilePhotoLimit.remaining(1), 2);
      expect(ProfilePhotoLimit.remaining(2), 1);
      expect(ProfilePhotoLimit.remaining(3), 0);
    });

    test('ginti hadd se aage ho to bhi baqi manfi nahi hota', () {
      expect(ProfilePhotoLimit.remaining(4), 0);
      expect(ProfilePhotoLimit.remaining(99), 0);
    });

    test('tabdeeli sirf hadd se pehle mumkin hai', () {
      expect(ProfilePhotoLimit.canChange(0), isTrue);
      expect(ProfilePhotoLimit.canChange(2), isTrue);
      expect(ProfilePhotoLimit.canChange(3), isFalse);
      expect(ProfilePhotoLimit.canChange(7), isFalse);
    });

    test('baqi moqon wali line mein asal adad likha ata hai', () {
      expect(ProfilePhotoLimit.remainingLine(0),
          'Image badalne ke baqi moqay: 3 / 3');
      expect(ProfilePhotoLimit.remainingLine(2),
          'Image badalne ke baqi moqay: 1 / 3');
      expect(ProfilePhotoLimit.remainingLine(3),
          'Image badalne ke baqi moqay: 0 / 3');
    });
  });

  group('Hadd wale notice — malik ke tay-shuda jumle', () {
    test('driver notice: app se band + Master-route wali sahulat', () {
      const n = ProfilePhotoLimit.limitNoticeDriver;
      expect(n, contains('Aap ki image badalne ki hadd (3) poori ho chuki hai'));
      expect(n, contains('ab app se image change nahi ho sakti'));
      expect(n, contains('Master ko support message mein apni photo bhej dein'));
      expect(n, contains('malik Master app se aap ki photo laga dega'));
    });

    test('passenger notice: sada hai, Master-route ka wada nahi', () {
      const n = ProfilePhotoLimit.limitNoticePassenger;
      expect(n, contains('Aap ki image badalne ki hadd (3) poori ho chuki hai'));
      expect(n, contains('ab image change nahi ho sakti'));
      expect(n, isNot(contains('support message')));
    });
  });

  group('DriverProfile — photo hadd ke fields ka record', () {
    test('naye fields JSON mein mehfooz aur wapas load hote hain', () {
      final p = DriverProfile()
        ..profilePhotoBackendPath = 'drv-1/profile_123.jpg'
        ..photoChanges = 2;
      final loaded = DriverProfile()..loadJson(p.toJson());
      expect(loaded.profilePhotoBackendPath, 'drv-1/profile_123.jpg');
      expect(loaded.photoChanges, 2);
    });

    test('purani JSON (naye keys baghair) mehfooz defaults leti hai', () {
      final loaded = DriverProfile()
        ..loadJson({'name': 'Test', 'profilePhotoPath': '/tmp/x.jpg'});
      expect(loaded.profilePhotoBackendPath, '');
      expect(loaded.photoChanges, 0);
    });
  });
}
