import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'backend.dart';
import 'lang.dart';
import 'otp.dart';
import 'store.dart';
import 'theme.dart';

/// Agent ka khaas LINK (v1.4.7, spec §6) — GitHub Pages par
/// rakhi agent.html wali shakal: link khule to app download ka
/// button + "Register" jo app ko code ke saath kholta hai
/// (bozdarsafar://register?agent=CODE, deep link)।
String agentLinkFor(String code) =>
    'https://bozdarstudio.github.io/bozdar-safar/agent.html?code=$code';

/// "MERA AGENT HISA" (v1.4.6 — Agent System, AGENT-SYSTEM-SPEC §2)
///
/// Profile (DONO modes — passenger Profile tab aur driver Profile)
/// mein lagne wala hisa. Logged-in mobile (passenger = apna mobile
/// login, driver = driver record ka mobile) backend `agents`
/// table mein kisi ACTIVE agent se match kare to hi ye card
/// khulta hai — match na ho to hisa BILKUL nazar nahi ata
/// (SizedBox.shrink). Agent sirf Master se banta hai; yahan koi
/// agent NAHI banta.
///
/// Card mein sirf ye hai (spec ki sakht had — is se zyada NAHI):
///  (a) Agent ki apni profile: photo lagana/badlana + naam/sheher.
///  (b) Us ke drivers ki list: sirf naam, gaari, active/tasdeeq
///      status, kul (mukammal) rides, kul fee RECORD.
///  (c) Apna kul hisaab (RECORD ONLY): kul drivers, kul rides,
///      kul fare, kul fee.
/// v1.4.7 (spec §6/§9): (a2) agent ka khaas LINK (copy/WhatsApp)
/// aur (c2) REFER BONUS ka hisaab — faisla ho gaya hai: har
/// referred driver ki pehle mahine ki wasool-shuda fee, cap
/// Rs 15,000, shart pehle mahine mein 300 mukammal rides
/// (BonusMath dekhein)। Is ke ilawa koi percent ya doosri
/// "kamai" wali raqam NAHI dikhti।
class AgentSection extends StatefulWidget {
  final AppStore store;
  const AgentSection({super.key, required this.store});

  @override
  State<AgentSection> createState() => _AgentSectionState();
}

class _AgentSectionState extends State<AgentSection> {
  final ImagePicker _picker = ImagePicker();
  bool _loading = true;
  bool _photoBusy = false;
  AgentInfo? _agent;
  List<AgentDriverTally> _drivers = const [];
  String _localPhoto = '';

  /// v1.4.7: har referred driver ka bonus hisaab (spec §9)।
  Map<String, BonusStats> _bonus = const {};

  // --- v1.4.14: AGENT EMAIL DARWAZA (faisla D-1) ------------------
  // Agent ke liye bhi Gmail + OTP LAZMI hai: email verify hue
  // baghair agent ka hisa (drivers ki list, hisaab, bonus, photo,
  // link) NAHI khulta — data load hi nahi hota। Verify shuda
  // email is phone par agent ke code ke saath mehfooz rehti hai
  // (SharedPreferences: agent_email_<code> /
  // agent_email_verified_ms_<code>)। Server-side record Phase 0b
  // (2026-11-09) se live hai: agents.email column + link_agent
  // RPC — verify kamyab hote hi Backend.linkAgentIdentity se
  // server par email + identity_links ka 'agent' record banta
  // hai; local record us ka phone-side saboot rehta hai।
  final _agentEmailCtrl = TextEditingController();
  bool _emailGateOpen = false;
  String _agentVerifiedEmail = '';

  AppStore get store => widget.store;

  @override
  void dispose() {
    _agentEmailCtrl.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    // Dono pehchanen check hoti hain (same-device par aksar ek
    // hi number driver bhi hota hai aur passenger bhi).
    AgentInfo? found;
    for (final m in {store.passengerPhone, store.profile.phone}) {
      if (m.trim().isEmpty) continue;
      found = await AgentApi.fetchAgentForMobile(m);
      if (found != null) break;
    }
    if (!mounted) return;
    if (found == null) {
      setState(() {
        _agent = null;
        _loading = false;
      });
      return;
    }
    // v1.4.14 D-1: email darwaza — is agent code ke liye is
    // phone par email verify pehle se ho chuki hai ya nahi।
    var gateOpen = false;
    var verifiedEmail = '';
    try {
      final prefs = await SharedPreferences.getInstance();
      verifiedEmail = prefs.getString('agent_email_${found.code}') ?? '';
      final ms = prefs.getInt('agent_email_verified_ms_${found.code}') ?? 0;
      gateOpen = ms > 0 && verifiedEmail.isNotEmpty;
    } catch (_) {
      gateOpen = false;
    }
    if (!mounted) return;
    setState(() {
      _agent = found;
      _emailGateOpen = gateOpen;
      _agentVerifiedEmail = verifiedEmail;
      if (verifiedEmail.isNotEmpty) _agentEmailCtrl.text = verifiedEmail;
      _loading = false;
    });
    // Email band ho to agent ka DATA load hi nahi hota (access
    // band — D-1); darwaza khulte hi _loadAgentData chalega।
    // Darwaza pehle se khula ho to server-side pehchan (link_agent)
    // ki khamosh retry bhi yahin — verify ke waqt fail hua ho to
    // yahan pakra jata hai।
    if (gateOpen) {
      await Backend.linkAgentIdentity(found.id);
      await _loadAgentData(found);
    }
  }

  /// Agent ka asal data (drivers, bonus, photo) — SIRF email
  /// darwaza khulne ke baad load hota hai।
  Future<void> _loadAgentData(AgentInfo found) async {
    final drivers = await AgentApi.fetchAgentDrivers(found.code);
    // v1.4.7: bonus hisaab (pehle mahine ki rides + wasool fee)।
    final bonus = await AgentApi.fetchBonusStats(
        drivers.map((d) => d.driverId).toList());
    String local = '';
    try {
      final prefs = await SharedPreferences.getInstance();
      local = prefs.getString('agent_photo_local_${found.code}') ?? '';
      if (local.isNotEmpty && !await File(local).exists()) local = '';
    } catch (_) {
      local = '';
    }
    if (!mounted) return;
    setState(() {
      _drivers = drivers;
      _bonus = bonus;
      _localPhoto = local;
    });
  }

  /// Email OTP verify kamyab — record mehfooz + darwaza khula।
  Future<void> _onAgentEmailVerified(String email) async {
    final a = _agent;
    if (a == null) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('agent_email_${a.code}', email);
      await prefs.setInt('agent_email_verified_ms_${a.code}',
          DateTime.now().millisecondsSinceEpoch);
    } catch (_) {
      // Record na likha jaye to bhi is session ke liye darwaza
      // khul jata hai; agli dafa phir verify karna hoga।
    }
    if (!mounted) return;
    setState(() {
      _emailGateOpen = true;
      _agentVerifiedEmail = email;
    });
    // Phase 0b: server par bhi pehchan bandhna (link_agent RPC —
    // agents.email + identity_links 'agent' record)। Khamosh
    // best-effort: fail ho to agent ka rasta nahi rukta; agli
    // dafa data load par phir koshish hoti hai।
    await Backend.linkAgentIdentity(a.id);
    await _loadAgentData(a);
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  /// Apni profile photo lagana/badlana: pehle source (camera /
  /// gallery), phir upload (driver-docs: agents/<code>/profile
  /// .jpg) — kamyabi par is phone par LOCAL file hi dikhti hai
  /// (bucket v132 se private hai; Master signed URL se dekhta
  /// hai).
  Future<void> _changePhoto() async {
    final agent = _agent;
    if (agent == null || _photoBusy) return;
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera),
              title: Text(tr('agent_pick_camera')),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: Text(tr('agent_pick_gallery')),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (src == null || !mounted) return;
    XFile? img;
    try {
      img = await _picker.pickImage(source: src, imageQuality: 85);
    } catch (_) {
      _snack(tr('agent_snack_photo_fail'));
      return;
    }
    if (img == null) {
      _snack(tr('agent_snack_photo_none'));
      return;
    }
    setState(() => _photoBusy = true);
    final path = await AgentApi.uploadAgentPhoto(agent, File(img.path));
    if (!mounted) return;
    setState(() => _photoBusy = false);
    if (path == null) {
      _snack(tr('agent_snack_upload_fail'));
      return;
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('agent_photo_local_${agent.code}', img.path);
    } catch (_) {
      // Local nishan na lage to bhi upload ho chuka hai.
    }
    if (!mounted) return;
    setState(() => _localPhoto = img!.path);
    _snack(tr('agent_snack_photo_done'));
  }

  static String _docLabel(String s) => switch (s) {
        'verified' => tr('agent_doc_done'),
        'rejected' => tr('agent_doc_rejected'),
        _ => tr('agent_doc_pending'),
      };

  @override
  Widget build(BuildContext context) {
    // Load ho raha ho ya is mobile ka koi agent hi na ho — hisa
    // bilkul nazar nahi ata (spec: match na ho to ghayab).
    if (_loading || _agent == null) return const SizedBox.shrink();
    // v1.4.14 D-1: email darwaza band ho to sirf band card —
    // agent ka koi data (drivers/hisaab/bonus/link) nazar NAHI
    // ata aur load bhi nahi hua hota।
    if (!_emailGateOpen) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.badge, color: Brand.green),
                  const SizedBox(width: 9),
                  Text(tr('agent_title'),
                      style: const TextStyle(
                          fontWeight: FontWeight.w900, fontSize: 15)),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                tr('agent_gate_text'),
                style: const TextStyle(fontSize: 13, height: 1.5),
              ),
              const SizedBox(height: 10),
              EmailOtpSection(
                emailCtrl: _agentEmailCtrl,
                alreadyVerifiedEmail: _agentVerifiedEmail,
                onVerified: _onAgentEmailVerified,
              ),
            ],
          ),
        ),
      );
    }
    final a = _agent!;
    final totalRides = _drivers.fold<int>(0, (s, d) => s + d.rides);
    final totalFare = _drivers.fold<int>(0, (s, d) => s + d.fare);
    final totalFee = _drivers.fold<int>(0, (s, d) => s + d.fee);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.badge, color: Brand.green),
                const SizedBox(width: 9),
                Text(tr('agent_title'),
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 15)),
              ],
            ),
            const SizedBox(height: 12),
            // (a) Agent ki apni profile
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Brand.green,
                  backgroundImage:
                      _localPhoto.isNotEmpty ? FileImage(File(_localPhoto)) : null,
                  child: _localPhoto.isNotEmpty
                      ? null
                      : Text(
                          a.name.isNotEmpty ? a.name[0].toUpperCase() : '?',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.bold),
                        ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(a.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 15.5)),
                      Text(
                        trf('agent_city_code', {
                          'city': a.city.isEmpty ? '—' : a.city,
                          'code': a.code
                        }),
                        style: const TextStyle(
                            color: Colors.black54, fontSize: 12.5),
                      ),
                      const SizedBox(height: 2),
                      Text(tr('agent_badge'),
                          style: const TextStyle(
                              color: Brand.green,
                              fontSize: 12,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                icon: _photoBusy
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.photo_camera, size: 18),
                label: Text(_localPhoto.isEmpty && a.photoPath.isEmpty
                    ? tr('agent_photo_add')
                    : tr('agent_photo_change')),
                onPressed: _photoBusy ? null : _changePhoto,
              ),
            ),
            const SizedBox(height: 10),
            // (a2) v1.4.7 AGENT LINK (spec §6): yehi link driver
            // ko bhejna hai — link khule to app milegi aur code
            // khud bhara milega (registration dobara nahi rukti)।
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF6E0),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Brand.gold),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('agent_link_title'),
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 13)),
                  const SizedBox(height: 4),
                  Text(agentLinkFor(a.code),
                      style: const TextStyle(
                          fontSize: 12, color: Brand.greenDark)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.copy, size: 16),
                          label: Text(tr('agent_copy')),
                          onPressed: () async {
                            await Clipboard.setData(
                                ClipboardData(text: agentLinkFor(a.code)));
                            _snack(tr('agent_snack_link_copied'));
                          },
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.share, size: 16),
                          label: const Text('WhatsApp'),
                          onPressed: () async {
                            final text = trf('agent_share_text', {
                              'code': a.code,
                              'link': agentLinkFor(a.code)
                            });
                            final uri = Uri.parse(
                                'https://wa.me/?text=${Uri.encodeComponent(text)}');
                            final ok = await launchUrl(uri,
                                mode: LaunchMode.externalApplication);
                            if (!ok) {
                              _snack(tr('agent_snack_wa_fail'));
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const Divider(height: 22),
            // (c) Kul hisaab — RECORD ONLY
            Text(tr('agent_total_title'),
                style: const TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 13.5)),
            const SizedBox(height: 8),
            Row(
              children: [
                _stat('Drivers', '${_drivers.length}'),
                _stat('Rides', '$totalRides'),
                _stat(tr('agent_stat_fare'), rs(totalFare)),
                _stat(tr('agent_stat_fee'), rs(totalFee)),
              ],
            ),
            const SizedBox(height: 8),
            // (c2) v1.4.7 REFER BONUS (spec §9 — faisla ho gaya
            // hai): har referred driver ki PEHLE MAHINE ki
            // wasool-shuda fee, cap Rs 15,000 — shart pehle
            // mahine mein 300 mukammal rides। Bonus sirf usi
            // driver ki fee se banta hai: pehle wasooli, phir
            // bonus; target miss ya fee wasool na ho to bonus
            // ZERO। Kul bonus neeche tamam drivers ka jod hai।
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: Brand.lightBg,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Brand.fieldBorder),
              ),
              child: Text(
                trf('agent_bonus_text', {
                  'target': '${BonusMath.targetRides}',
                  'cap': rs(BonusMath.capRs),
                  'total':
                      rs(_bonus.values.fold<int>(0, (s, b) => s + b.bonus))
                }),
                style: const TextStyle(
                    fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.45),
              ),
            ),
            // (b) Us ke drivers ki list
            if (_drivers.isNotEmpty) ...[
              const Divider(height: 22),
              Text(tr('agent_drivers_title'),
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 13.5)),
              const SizedBox(height: 6),
              for (final d in _drivers) _driverRow(d),
            ] else ...[
              const SizedBox(height: 10),
              Text(
                tr('agent_no_drivers'),
                style: const TextStyle(fontSize: 12.5, color: Colors.black54),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value,
              style:
                  const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
          Text(label,
              style: const TextStyle(color: Colors.black54, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _driverRow(AgentDriverTally d) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(d.active ? Icons.check_circle : Icons.pending_actions,
              size: 19, color: d.active ? Brand.green : Brand.gold),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  d.name.isEmpty ? tr('agent_name_missing') : d.name,
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 13.5),
                ),
                Text(
                  [
                    if (d.vehicle.isNotEmpty) d.vehicle,
                    if (d.plate.isNotEmpty) d.plate,
                  ].join(' · '),
                  style:
                      const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                Text(
                  d.active
                      ? tr('agent_id_active')
                      : trf('agent_doc_status', {
                          'c': _docLabel(d.cnicStatus),
                          'g': _docLabel(d.gaariStatus),
                          'l': _docLabel(d.licenceStatus)
                        }),
                  style:
                      const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                Text(
                  trf('agent_driver_rides',
                      {'n': '${d.rides}', 'fee': rs(d.fee)}),
                  style: const TextStyle(fontSize: 12.5),
                ),
                // v1.4.7: is driver ka bonus hisaab (spec §9)।
                Builder(builder: (_) {
                  final bs = _bonus[d.driverId];
                  if (bs == null || bs.anchor == null) {
                    return Text(
                      tr('agent_bonus_waiting'),
                      style: const TextStyle(
                          fontSize: 12, color: Colors.black54),
                    );
                  }
                  return Text(
                    bs.bonus > 0
                        ? trf('agent_bonus_made', {
                            'bonus': rs(bs.bonus),
                            'rides': '${bs.firstMonthRides}',
                            'target': '${BonusMath.targetRides}',
                            'fee': rs(bs.settledInFirstMonth)
                          })
                        : trf('agent_bonus_progress', {
                            'rides': '${bs.firstMonthRides}',
                            'target': '${BonusMath.targetRides}',
                            'fee': rs(bs.settledInFirstMonth)
                          }),
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight:
                            bs.bonus > 0 ? FontWeight.w800 : FontWeight.w400,
                        color:
                            bs.bonus > 0 ? Brand.green : Colors.black54),
                  );
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
