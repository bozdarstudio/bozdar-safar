// v1.4.24 — SRB TAX (ASAL WASOOLI) ke tests (malik ka tay-shuda
// design 2026-11-10 20:50): Sindh aam gaari 5% (poora kiraya),
// Sindh Bike 2% (fee ke baad ka net), Punjab 0, ghair-mukammal
// ride 0 — aur Master ke taxForRide se EK hisaab ki tasdeeq۔
import 'package:flutter_test/flutter_test.dart';
import 'package:safar/store.dart';

void main() {
  group('kTaxCitiesSindh — Sindh ki tay-shuda list', () {
    test('kul 6 sheher hain — Master wali wohi list', () {
      expect(kTaxCitiesSindh, {
        'Karachi',
        'Hyderabad',
        'Sukkur',
        'Larkana',
        'Nawabshah',
        'Mirpurkhas',
      });
    });

    test('Punjab ke sheher list mein NAHI hain', () {
      expect(kTaxCitiesSindh.contains('Lahore'), isFalse);
      expect(kTaxCitiesSindh.contains('Multan'), isFalse);
      expect(kTaxCitiesSindh.contains('Faisalabad'), isFalse);
    });
  });

  group('taxOnAmounts — khalis formula', () {
    test('Sindh aam gaari: poore kiraye (fare+waiting) ka 5%', () {
      // fare 800 + waiting 200 = total 1000 → 50
      expect(
        taxOnAmounts(total: 1000, fee: 100, vehicle: 'Rickshaw', city: 'Karachi'),
        50,
      );
      expect(
        taxOnAmounts(total: 1200, fee: 120, vehicle: 'Car', city: 'Hyderabad'),
        60,
      );
      expect(
        taxOnAmounts(total: 700, fee: 70, vehicle: 'Van', city: 'Sukkur'),
        35,
      );
    });

    test('Sindh Bike: fee katne ke baad ke NET kiraye ka 2%', () {
      // total 1000, fee 100 → net 900 → 18
      expect(
        taxOnAmounts(total: 1000, fee: 100, vehicle: 'Bike', city: 'Karachi'),
        18,
      );
      // total 500, fee 50 → net 450 → 9
      expect(
        taxOnAmounts(total: 500, fee: 50, vehicle: 'Bike', city: 'Larkana'),
        9,
      );
    });

    test('Bike par fee total se zyada ho to tax manfi NAHI hota', () {
      expect(
        taxOnAmounts(total: 100, fee: 150, vehicle: 'Bike', city: 'Karachi'),
        0,
      );
    });

    test('Punjab par tax 0 hai (PRA ruling baqi)', () {
      expect(
        taxOnAmounts(total: 1000, fee: 100, vehicle: 'Car', city: 'Lahore'),
        0,
      );
      expect(
        taxOnAmounts(total: 1000, fee: 100, vehicle: 'Bike', city: 'Multan'),
        0,
      );
    });

    test('sheher maloom na ho (null/khaali) to tax 0 hai', () {
      expect(
        taxOnAmounts(total: 1000, fee: 100, vehicle: 'Car', city: null),
        0,
      );
      expect(
        taxOnAmounts(total: 1000, fee: 100, vehicle: 'Car', city: ''),
        0,
      );
    });

    test('rounding Master ki tarah .round() se hota hai', () {
      // 999 ka 5% = 49.95 → 50
      expect(
        taxOnAmounts(total: 999, fee: 100, vehicle: 'Taxi', city: 'Karachi'),
        50,
      );
      // Bike: net 925 ka 2% = 18.5 → 19
      expect(
        taxOnAmounts(total: 1025, fee: 100, vehicle: 'Bike', city: 'Karachi'),
        19,
      );
    });
  });

  group('taxForRide — status wali shart (Master ki ain shakal)', () {
    test('mukammal Sindh ride par tax banta hai', () {
      expect(
        taxForRide(
            total: 1000,
            fee: 100,
            vehicle: 'Rickshaw',
            city: 'Karachi',
            status: 'completed'),
        50,
      );
    });

    test('ghair-mukammal ride par tax 0 hai', () {
      for (final st in ['pending', 'accepted', 'arrived', 'cancelled', 'noshow']) {
        expect(
          taxForRide(
              total: 1000, fee: 100, vehicle: 'Car', city: 'Karachi', status: st),
          0,
          reason: 'status $st par tax nahi banna chahiye',
        );
      }
    });

    test('asal fee (Fares.serviceFee) ke saath Master wala hisaab', () {
      // Master: fee = total ka 10%; Bike net = total − fee۔
      final fee = Fares.serviceFee(2000);
      expect(fee, 200);
      expect(
        taxForRide(
            total: 2000,
            fee: fee,
            vehicle: 'Bike',
            city: 'Nawabshah',
            status: 'completed'),
        36, // net 1800 ka 2%
      );
      expect(
        taxForRide(
            total: 2000,
            fee: fee,
            vehicle: 'Car',
            city: 'Mirpurkhas',
            status: 'completed'),
        100, // poore 2000 ka 5%
      );
    });
  });

  group('taxLabelFor — rate gaari ke hisaab se', () {
    test('Bike 2%, baqi 5%', () {
      expect(taxLabelFor('Bike'), contains('2%'));
      expect(taxLabelFor('Car'), contains('5%'));
      expect(taxLabelFor('Rickshaw'), contains('5%'));
    });
  });

  group('Booking — tax fields aur grandTotal', () {
    Booking mk({int tax = 0, String city = ''}) => Booking(
          id: 't1',
          passengerName: 'Sawari',
          passengerPhone: '03000000000',
          pickupLabel: 'A',
          dropLabel: 'B',
          pickupLat: 0,
          pickupLng: 0,
          dropLat: 0,
          dropLng: 0,
          hasDropPin: true,
          vehicle: 'Rickshaw',
          distanceKm: 10,
          fare: 500,
          note: '',
          status: 'completed',
          createdAt: DateTime(2026, 11, 11),
          waitingCharge: 100,
          taxAmount: tax,
          taxCity: city,
        );

    test('total tax base hai; grandTotal kul adaigi hai', () {
      final b = mk(tax: 30, city: 'Karachi');
      expect(b.total, 600);
      expect(b.grandTotal, 630);
      expect(b.hasTax, isTrue);
    });

    test('tax na ho to grandTotal == total', () {
      final b = mk();
      expect(b.grandTotal, b.total);
      expect(b.hasTax, isFalse);
    });

    test('tax fields JSON mein mehfooz rehte hain', () {
      final b = mk(tax: 30, city: 'Karachi');
      final back = Booking.fromJson(b.toJson());
      expect(back.taxAmount, 30);
      expect(back.taxCity, 'Karachi');
    });

    test('purani JSON (tax keys ke baghair) par 0/khaali ata hai', () {
      final j = mk().toJson()
        ..remove('taxAmount')
        ..remove('taxCity');
      final back = Booking.fromJson(j);
      expect(back.taxAmount, 0);
      expect(back.taxCity, '');
    });
  });
}
