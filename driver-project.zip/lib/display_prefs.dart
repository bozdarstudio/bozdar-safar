import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'lang.dart';
import 'theme.dart';

// =====================================================================
// v1.4.30 — DISPLAY PASAND: Din / Raat / Khud-ba-khud (EK BUTTON)
// (malik ka hukm 2026-11-11 17:10 + tashheesh 17:11)
//
// EK hi pasand hai aur EK hi button (DisplayModeButton) isay
// badalta hai — is se POORI APP ka theme AUR har map ka style
// DONO ek saath badalte hain (alag alag button NAHI hain):
//   Day   → halka Safar theme + CARTO Voyager (roshan map)
//   Night → gehra Safar theme + CARTO Dark Matter (gehra map)
//   Auto  → phone ki apni brightness ke mutabiq
// Pasand SharedPreferences mein mehfooz rehti hai — band karke
// kholne par bhi wohi rehti hai. Passenger + driver dono modes
// mein yehi ek pasand chalti hai.
// =====================================================================

enum DisplayMode { day, night, auto }

/// v1.4.60: notifier ki apni qism — ghante ki tabdeeli par
/// (Auto) sunne walon ko dobara khabar dene ke liye ping()
/// (ValueNotifier.notifyListeners protected hai, is liye
/// subclass ke andar se hi bulaya gaya hai)।
class _DisplayModeNotifier extends ValueNotifier<DisplayMode> {
  _DisplayModeNotifier(super.value);
  void ping() => notifyListeners();
}

class DisplayPrefs {
  static const String _key = 'display_mode_v1';

  static final ValueNotifier<DisplayMode> notifier =
      _DisplayModeNotifier(DisplayMode.auto);

  static bool _loaded = false;

  static Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      // v1.4.57 (Part 7): pehli dafa (koi mehfooz pasand
      // NAHI) to AUTO — malik ka hukm: default khud-ba-khud
      // wala andaaz; jis ne Din/Raat khud chuna ho us ki
      // mehfooz pasand hi chalti hai।
      notifier.value = switch (prefs.getString(_key)) {
        'night' => DisplayMode.night,
        'day' => DisplayMode.day,
        _ => DisplayMode.auto,
      };
    } catch (_) {
      // Pasand na mile to Auto — app rukti nahi।
    }
  }

  static Future<void> set(DisplayMode m) async {
    notifier.value = m;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key, m.name);
    } catch (_) {}
  }

  /// Button ka amal: Day → Night → Auto → Day …
  static Future<void> cycle() => set(switch (notifier.value) {
        DisplayMode.day => DisplayMode.night,
        DisplayMode.night => DisplayMode.auto,
        DisplayMode.auto => DisplayMode.day,
      });

  /// v1.4.60: EK HI resolver — map ka style AUR poori app ka
  /// theme DONO isi ek hisaab se chalte hain (alag alag
  /// hisaab bilkul NAHI, warna aadhi app din aur aadha map
  /// raat ho jata tha — malik ki shikayat 2026-11-16 02:38:
  /// raat mein sirf map gehra tha, neeche wali sheet safed
  /// reh kar aankhon ko chubhti thi)।
  ///   Day   → hamesha roshan
  ///   Night → hamesha gehra
  ///   Auto  → phone ki brightness dark YA shaam/raat ke
  ///           ghante (18:30–05:59) — v1.4.57 (Part 7) wala
  ///           malik ka hukm barkarar: shaam hote hi sab
  ///           kuch khud gehra ho jaye। (v1.4.81/66:
  ///           sarhad 18:00 → 18:30 — din ka rangeen map
  ///           06:00–18:30 tak rahe, malik ka taza hukm।)
  static bool get isDarkResolved => switch (notifier.value) {
        DisplayMode.day => false,
        DisplayMode.night => true,
        DisplayMode.auto =>
          WidgetsBinding.instance.platformDispatcher.platformBrightness ==
                  Brightness.dark ||
              _isNightHour(),
      };

  static ThemeMode get themeMode =>
      isDarkResolved ? ThemeMode.dark : ThemeMode.light;

  /// Is waqt asal mein RAAT wala nazara hai ya nahi (map ka
  /// style chunne ke liye) — v1.4.60 se ye bhi usi EK
  /// resolver (isDarkResolved) ka jawab hai, doosra hisaab
  /// NAHI।
  static bool isDarkNow(BuildContext context) => isDarkResolved;

  /// v1.4.60: Auto mein ghanta badalne (18:30 / 06:00) par
  /// dobara hisaab — main.dart ka har-minute wala timer isay
  /// bulata hai; notifier ke sunne wale (MaterialApp + har
  /// map) setState ho kar naya Din/Raat le lete hain, app
  /// band kiye baghair।
  static void recheckClock() {
    (notifier as _DisplayModeNotifier).ping();
  }

  static bool _isNightHour() {
    // Din ka window: 06:00–18:30 (us ke baad raat) —
    // minute tak ka hisaab taake 18:30 wali sarhad
    // durust lage।
    final now = DateTime.now();
    final mins = now.hour * 60 + now.minute;
    return mins >= 18 * 60 + 30 || mins < 6 * 60;
  }
}

/// v1.4.42 (H1R — owner hukm 2026-11-13 02:40): Din/Raat ka
/// CHHOTA GOL ICON button — koi likhai NAHI, sirf nishani
/// (sooraj / chaand / auto)। Map ke side controls wali
/// column mein yehi rehta hai; amal wohi hai jo pill wala
/// button karta tha — tap par Day → Night → Auto → Day
/// (DisplayPrefs.cycle), poori app + map ek saath badalte
/// hain। Function bilkul khatam NAHI hua, sirf shakal
/// badli hai: likha hua "Raat" pill header se gaya, gol
/// icon map ke controls mein aa gaya।
class DisplayModeIconButton extends StatelessWidget {
  const DisplayModeIconButton({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<DisplayMode>(
      valueListenable: DisplayPrefs.notifier,
      builder: (context, mode, _) {
        final icon = switch (mode) {
          DisplayMode.day => Icons.light_mode,
          DisplayMode.night => Icons.dark_mode,
          DisplayMode.auto => Icons.brightness_auto,
        };
        return Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => DisplayPrefs.cycle(),
            customBorder: const CircleBorder(),
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Brand.deepGreen.withOpacity(0.92),
                border: Border.all(color: Brand.gold, width: 1),
              ),
              child: Icon(icon, color: Brand.goldLight, size: 18),
            ),
          ),
        );
      },
    );
  }
}

/// EK display button — header aur map ke side controls, dono
/// jagah yehi ek button hai aur yehi ek pasand badalta hai।
class DisplayModeButton extends StatelessWidget {
  final bool compact;
  const DisplayModeButton({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<DisplayMode>(
      valueListenable: DisplayPrefs.notifier,
      builder: (context, mode, _) {
        final (icon, label) = switch (mode) {
          DisplayMode.day => (Icons.light_mode, tr('display_day')),
          DisplayMode.night => (Icons.dark_mode, tr('display_night')),
          DisplayMode.auto =>
            (Icons.brightness_auto, tr('display_auto')),
        };
        return Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => DisplayPrefs.cycle(),
            borderRadius: BorderRadius.circular(20),
            child: Container(
              padding: EdgeInsets.symmetric(
                  horizontal: compact ? 8 : 10, vertical: 6),
              decoration: BoxDecoration(
                color: Brand.deepGreen.withOpacity(0.92),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Brand.gold, width: 1),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: Brand.goldLight, size: 15),
                  const SizedBox(width: 5),
                  Text(label,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// =====================================================================
// v1.4.57 (Part 13) — DRIVER KA APNA NISHAN: Teer ya Gaari
// (malik ka hukm: marker ki shakal DRIVER ki apni pasand hai)
//
// Driver apne maqam ke nishan ki shakal khud chunta hai:
//   Teer  → hara navigation teer (Part 11 wala asset) — DEFAULT
//   Gaari → us ki apni qisam ka asal-numa marker (Part 3 ke
//           halo wale assets — rickshaw wale ko rickshaw)
// Pasand SharedPreferences mein mehfooz; sirf DRIVER side ke
// maqam par lagu hoti hai — sawari side bilkul alag hai
// (wahan assign driver hamesha apni qisam ke marker se
// dikhta hai, Part 3/4 wala usool)।
// =====================================================================

enum MarkerStyle { arrow, vehicle }

class MarkerPrefs {
  static const String _key = 'driver_marker_style_v1';

  static final ValueNotifier<MarkerStyle> notifier =
      ValueNotifier<MarkerStyle>(MarkerStyle.arrow);

  static bool _loaded = false;

  static Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      notifier.value = switch (prefs.getString(_key)) {
        'vehicle' => MarkerStyle.vehicle,
        _ => MarkerStyle.arrow,
      };
    } catch (_) {
      // Pasand na mile to Teer — app rukti nahi।
    }
  }

  static Future<void> set(MarkerStyle m) async {
    notifier.value = m;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key, m.name);
    } catch (_) {}
  }
}
