# v1.4.19 — Nayi awaaz wali hidayat: Fitness/Insurance wala qadam + Character Certificate wala qadam

**Zaroori files (abhi banana baqi hain):**
- `assets/guidance/guidance_gate_docs.mp3` — wizard qadam 6 (Fitness, Insurance aur Permit)
- `assets/guidance/guidance_character.mp3` — wizard qadam 7 (Police Character Certificate)

- Wohi awaaz/andaaz jo maujooda guidance set ka hai (guidance_permit.mp3 wali hi awaaz), offline bundle ke liye.
- Files `assets/guidance/` mein rakhte hi app khud chala legi — code mein wiring ho chuki hai
  (registration.dart ke `_stepGuides` mein qadam 6 aur 7 par yehi naam diye hain).
- Jab tak mp3 nahi banti, GuideAudio khamoshi se fail hota hai — registration NAHI rukti.
- NOTE: purani `guidance_permit.mp3` qadam 6 par ab NAHI bajti — us ka matan purane
  (ikhtiyari) model ka tha; naye qadam par nayi clip hi chalegi.

## Clip 1 — guidance_gate_docs.mp3 (Fitness, Insurance aur Permit)

> Assalam-o-Alaikum bhai. Ye qadam Fitness Certificate aur Gaari ki Insurance ka hai.
> Ye dono kagaz har driver ke record ke lazmi kagaz hain — jis ke paas jo kagaz hai, us ki saaf tasveer yahan laga dein.
> Fitness Certificate sarkari Vehicle Fitness Center se banta hai, jahan aap ki gaari ki jaanch hoti hai.
> Aur Gaari ki third-party Insurance kisi bhi insurance company ya un ke agent se asaani se mil jati hai.
> Agar koi kagaz abhi aap ke paas nahi hai to ghabrayein nahi — aap ki ID ban jayegi aur aap ki registration yahin mehfooz rahegi.
> Baad mein jab kagaz ban jaye to Profile ke "Mere Kagaz" hisse se sirf wohi kagaz laga dein — shuru se dobara kuch nahi karna.
> Saare kagaz poore aur verify ho jayein to aap ko "Mukammal Tasdeeq" ka darja milega.
> Route Permit ab bhi ikhtiyari hai — ho to us ki tasveer bhi yahin laga dein.
> Aur aakhir mein neeche wali khud-zimmedari ki tasdeeq par nishan laga kar Aage dabayein.

## Clip 2 — guidance_character.mp3 (Police Character Certificate)

> Assalam-o-Alaikum bhai. Ye qadam Police Character Certificate ka hai.
> Ye certificate har driver ke record ke liye lazmi hai — ye saabit karta hai ke driver ka koi mujrimana record nahi hai, aur sawari ke liye ye bharose ki baat hai.
> Ye certificate apne ilaqe ke Police Khidmat Markaz ya thane se banta hai.
> Jaate waqt apna asal CNIC saath le jayein — fees mamuli hai, takreeban paanch sau rupay.
> Certificate mil jaye to us ki saaf tasveer yahan laga dein.
> Agar certificate abhi nahi bana to pareshan na hon — aap ki registration yahin mehfooz rahegi, ID ban jayegi.
> Baad mein certificate ban jaye to Profile ke "Mere Kagaz" hisse se sirf yehi kagaz laga dein — baqi sab kuch dobara nahi karna.
> Saare kagaz verify ho jayein to aap ko "Mukammal Tasdeeq" ka darja milega.
