import 'dart:convert';

/// REMOTE ENGINE (v1.4.81 — malik ka hukm 2026-11-24): Master
/// app ke "Driver App Control" panel se chhoti-moti tabdeeliyan
/// BINA app update kiye driver ki app tak pohanchti hain।
///
/// Rasta maujooda settings wala hi hai, koi naya parallel
/// system NAHI: backend settings row (id=1) ke JSON column
/// `driver_remote_config` se value ati hai — settings_public
/// view ko chherna khatarnak tha (live columns gir sakte thay),
/// is liye sahulat_target wale usool par chhoti RPC
/// `get_driver_remote_config` se (SQL: sql-fixes/
/// driver-remote-config.sql; Backend._pullSettings bulata hai)।
/// View wali row mein key kabhi aa jaye to _applySettings bhi
/// yahin lagata hai।
///
/// Usool (kabhi crash nahi):
/// - Har key ka default MAUJOODA behavior ke barabar hai —
///   config bilkul na mile to app bilkul waisi hi chalti hai
///   jaisi hamesha se chalti thi।
/// - Akhri kamyab config SharedPreferences cache
///   (`srv_remote_config_json`) mein rehti hai — agli dafa
///   fetch fail ho (offline / SQL abhi na lagi ho) to cache
///   chalti hai, woh bhi na ho to defaults।
/// - Parse har key par type-check ke saath hai; ghalat type ya
///   range se bahar value us key ke default par rehti hai।
class DriverRemoteConfig {
  /// Company ka maujooda WhatsApp number — app ki purani
  /// strings ("Master se rabta karein: 0332 9467211") wala
  /// hi number is ka default hai।
  static const String kDefaultSupportWhatsapp = '03329467211';

  /// 1) Elaan banner — Driver Home ke upar Master ka elaan।
  static bool announcementOn = false;
  static String announcementText = '';

  /// 2) Maintenance — ON ho to driver ONLINE nahi ho sakta,
  /// sirf ye paighaam dikhta hai (home par bhi patti rehti hai)।
  static bool maintenanceOn = false;
  static String maintenanceText = '';

  /// 3) Monthly Pick & Drop ke options driver app mein
  /// dikhen ya na dikhen (default: dikhen — maujooda behavior)।
  static bool monthlyPickdropOn = true;

  /// 4) Pending booking ka auto-cancel waqt, minuteon mein
  /// (default 10 — maujooda behavior; store ka expiry aur pool
  /// filter isi se chalte hain)।
  static int bookingExpiryMinutes = 10;

  /// 5) Rozana live selfie ki shart (default ON — maujooda
  /// behavior: duty se pehle aaj ki selfie lazmi)।
  static bool dailySelfieOn = true;

  /// 6) Random live-selfie checks ki rozana zyada se zyada
  /// tadaad (default 3; 0 = random checks band)। Schedule ka
  /// purana 2–3 wala random usool is hadd ke andar rehta hai।
  static int randomSelfiePerDay = 3;

  /// 7) Madad ke liye WhatsApp number — Master messages wali
  /// screen par "WhatsApp par madad" ka button isi number par
  /// khulta hai।
  static String supportWhatsapp = kDefaultSupportWhatsapp;

  /// WhatsApp ke liye been-ul-aqwami shakal (92...) — driver
  /// jo number Master ne diya ho (0332... / +92... / 92...)
  /// usi ko wa.me ke qabil banata hai।
  static String get supportWhatsappIntl {
    var d = supportWhatsapp.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.startsWith('92')) return d;
    if (d.startsWith('0')) return '92${d.substring(1)}';
    if (d.length == 10 && d.startsWith('3')) return '92$d';
    return d;
  }

  /// Config lagana — [raw] Map, JSON string, RPC ka jawab
  /// (List / wrapped Map) kuch bhi ho sakta hai; jo samajh na
  /// aye use khamoshi se nazar-andaz kar do। Kuch asal mein
  /// apply hua to true (caller cache isi par likhta hai)।
  static bool apply(dynamic raw) {
    Map? m;
    if (raw is Map) {
      m = raw;
    } else if (raw is String) {
      try {
        final d = jsonDecode(raw);
        if (d is Map) m = d;
      } catch (_) {
        // Kharab JSON — defaults/cache hi sahi।
      }
    } else if (raw is List && raw.isNotEmpty) {
      // RPC agar table/setof shakal mein jawab de to pehli
      // row ke andar wali value asal config hai।
      final f = raw.first;
      if (f is Map) {
        final inner = f['driver_remote_config'] ??
            f['get_driver_remote_config'] ??
            f['config'];
        if (inner != null) return apply(inner);
        m = f;
      }
    }
    if (m == null) return false;
    // Settings row se seedha aya ho to asal config andar
    // wale 'driver_remote_config' key mein hoti hai।
    final inner = m['driver_remote_config'];
    if (inner is Map || inner is String) return apply(inner);

    bool b(String k, bool cur) => m![k] is bool ? m[k] as bool : cur;
    String t(String k, String cur) {
      final v = m![k];
      if (v is! String) return cur;
      final s = v.trim();
      return s.length <= 500 ? s : s.substring(0, 500);
    }

    int n(String k, int cur, int lo, int hi) {
      final v = m![k];
      final x = v is num ? v.toInt() : int.tryParse('$v');
      if (x == null) return cur;
      return x < lo ? lo : (x > hi ? hi : x);
    }

    announcementOn = b('announcement_on', announcementOn);
    announcementText = t('announcement_text', announcementText);
    maintenanceOn = b('maintenance_on', maintenanceOn);
    maintenanceText = t('maintenance_text', maintenanceText);
    monthlyPickdropOn = b('monthly_pickdrop_on', monthlyPickdropOn);
    bookingExpiryMinutes =
        n('booking_expiry_minutes', bookingExpiryMinutes, 1, 120);
    dailySelfieOn = b('daily_selfie_on', dailySelfieOn);
    randomSelfiePerDay =
        n('random_selfie_per_day', randomSelfiePerDay, 0, 10);
    final wa = t('support_whatsapp', supportWhatsapp);
    // Number mein kam az kam 7 digits hon tabhi badlo —
    // warna purana/default number hi rahe।
    if (wa.replaceAll(RegExp(r'[^0-9]'), '').length >= 7) {
      supportWhatsapp = wa;
    }
    return true;
  }

  /// Cache mein likhne ke liye maujooda haalat (snake_case —
  /// backend wali hi shakl, taake cache aur server ek jaise
  /// rahen)।
  static Map<String, dynamic> toJson() => {
        'announcement_on': announcementOn,
        'announcement_text': announcementText,
        'maintenance_on': maintenanceOn,
        'maintenance_text': maintenanceText,
        'monthly_pickdrop_on': monthlyPickdropOn,
        'booking_expiry_minutes': bookingExpiryMinutes,
        'daily_selfie_on': dailySelfieOn,
        'random_selfie_per_day': randomSelfiePerDay,
        'support_whatsapp': supportWhatsapp,
      };
}
