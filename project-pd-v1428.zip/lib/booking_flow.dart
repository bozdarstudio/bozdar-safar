// v1.4.28 — BOOKING PANEL ka PROGRESSIVE DISCLOSURE usool
// (malik ne live test mein pakra, 2026-11-11 ~02:53): purana
// panel poora map dhak deta tha aur us mein sab cheezein ek
// saath khuli hoti theen — sawari drop pin lagaa hi nahi sakta
// tha, "Ride Pakki Karein" par sirf snack ata tha "map par pin
// lagayein" lekin map nazar hi nahi aata tha.
//
// Naya usool (malik ka design hukm):
//  1. Panel mein pehle SIRF Pickup + Drop fields — compact
//     panel, map saaf nazar aata hai.
//  2. Baqi tafseel (gaariyan, note, Ride Pakki Karein button,
//     Monthly Package card) SIRF tab khulti hai jab drop ka
//     PIN lag jaye AUR usi pickup/drop jori ka ASAL sadak
//     route (OSRM/cache) aa jaye — yehi v1.4.25 ke FARE GATE
//     ka usool hai: booking ki bunyaad sirf asal route hai,
//     koi placeholder km NAHI.
//  3. Pin lagane ka khaas mode: panel ghayab, poora map, upar
//     patli hidayat patti — map tap = drop pin.
//
// Ye file sirf khalis hisaab hai (koi widget nahi) taake usool
// unit tests se pakka parkha ja sake.
import 'store.dart';

/// Booking ki tafseel (gaariyan/note/button waghera) kab dikhe:
/// drop pin maujood ho AUR maujooda jori ka asal route aa gaya
/// ho. [routeKm] null, ya us ka sig maujooda jori se na mile,
/// to tafseel BAND rehti hai — purani jori ki doori par form
/// kabhi NAHI khulta.
bool bookingDetailsReady({
  required bool hasDropPin,
  required double? routeKm,
  required bool routeSigMatches,
}) {
  if (!hasDropPin) return false;
  if (routeKm == null) return false;
  if (!routeSigMatches) return false;
  return true;
}

/// Pin-mode ki hidayat patti ka asal jumla (test se bandha hua —
/// lafz badle to test bhi badalna padega, jaan boojh kar)।
const String kPinModeHint =
    'Apni manzil ki jagah map par tap karein';

/// Drop field ke saath wale pin button ka label।
const String kPinModeButtonLabel = 'Map Se Pin Lagayein';

/// Bina pin ke "Ride Pakki Karein" dabne par ab sirf snack
/// NAHI ata — pin-mode khud khul jata hai; ye jumla us ke
/// saath wali wazahat hai।
const String kPinNeededSnack =
    'Pehle manzil ka pin lagayein — map khul gaya hai, apni manzil ki jagah tap karein.';

/// OpenStreetMap attribution — MapLibre/OSM ki license
/// shart: map jahan bhi dikhe, ye line parhi ja sakne wali
/// haalat mein lazmi hai। Map widget (safar_map.dart) ke
/// badge aur un screens ki footer line jahan apni sheet map
/// ke neeche wale kinare ko dhak deti hai — sab isi ek
/// constant se ate hain।
const String kOsmAttribution = '© OpenStreetMap contributors';

/// Map par pin lagne par field ka label — SIRF tab jab field
/// pehle se khaali ho (user ka likha hua naam kabhi NAHI
/// badalta)। Geocoding/address-search app mein maujood NAHI
/// hai, is liye pin wali jagah ka koi jaali pata NAHI banta —
/// ye saaf label yehi batata hai ke jagah map se chuni gayi
/// hai। Is ke baghair pin-only rasta booking tak pohanch hi
/// nahi sakta tha (form ko pickup/drop ka likha naam bhi
/// chahiye hota hai)।
const String kPinPlaceLabel = 'Map Pin Wali Jagah';

/// Pin lagne par field ka asal label: khaali ho to
/// [kPinPlaceLabel], warna user ka apna likha hua hi।
String pinLabelIfEmpty(String currentLabel) =>
    currentLabel.trim().isEmpty ? kPinPlaceLabel : currentLabel;

/// Pichhli (recent) jagahen — Yango-style list ki khalis
/// tartib: store ki bookings pehle se NAWEN pehle (newest
/// first) hain; un mein se jin ka drop PIN tha, label ki
/// bunyaad par dohrao hata kar, pehli [limit] jagahen।
/// Pin ke baghair wali purani booking list mein NAHI ati —
/// us se route ban hi nahi sakta।
List<Booking> recentDropPlaces(List<Booking> bookings, {int limit = 4}) {
  final seen = <String>{};
  final out = <Booking>[];
  for (final b in bookings) {
    if (!b.hasDropPin) continue;
    final label = b.dropLabel.trim();
    if (label.isEmpty) continue;
    if (!seen.add(label.toLowerCase())) continue;
    out.add(b);
    if (out.length >= limit) break;
  }
  return out;
}
