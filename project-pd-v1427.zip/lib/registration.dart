import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'store.dart';
import 'theme.dart';
import 'legal.dart';
import 'backend.dart';
import 'guide_audio.dart';
import 'otp.dart';

/// Driver REGISTRATION WIZARD (v1.2.6 — malik ka hukm: "Register form
/// waise hi banao jaise Yango ka hai").
///
/// Yango Pro ke driver registration jaisi qadam-ba-qadam (step-by-step)
/// full-screen form: mobile → zaati maloomat/CNIC → password → gaari →
/// licence (ikhtiyari) → live selfie → ilaqa + jaiza → Register.
/// Driver Mode mein jab tak registration mukammal nahi, ye form khud
/// bhi khulta hai aur Profile se bhi dobara khul sakta hai (tafseel
/// mukammal/badlein). Purani Profile-wali save is ki jagah NAHI leti —
/// pehli registration yahin se hoti hai; Profile sirf editing ke liye.
///
/// Usool jo nahi badle:
/// - Password: v1.2.5 ke wohi usool (kam az kam 6 haroof, sirf
///   fingerprint, ek password sirf ek driver — backend uniqueness
///   check, internet ke baghair check skip NAHI hota).
/// - Licence OPTIONAL hai: "Licence nahi hai — skip karein" se aage
///   barh sakte hain; CNIC lazmi hai.
/// - Tasaveer phone par bhi rehti hain AUR backend Storage
///   (driver-docs bucket) mein bhi upload hoti hain — Master
///   TASDEEQ asal tasveer dekh kar hi karta hai (v1.2.8 se;
///   pehla "sirf phone par" wala khayal ghalat tha, v1.4.25
///   mein comment durust kiya gaya)। Backend par numbers/tafseel
///   aur documents ki STATUS bhi jati hai।
/// - Register hone par darkhwast Master ke paas jati hai — duty ki
///   asal tasdeeq masterActive (Master app) se hi ati hai.
class RegistrationWizard extends StatefulWidget {
  final AppStore store;
  const RegistrationWizard({super.key, required this.store});

  @override
  State<RegistrationWizard> createState() => _RegistrationWizardState();
}

class _RegistrationWizardState extends State<RegistrationWizard> {
  static const _titles = [
    'Mobile Number',
    'Zaati Maloomat',
    'Password',
    'Gaari ki Maloomat',
    'Driving Licence',
    // v1.4.19: qadam 6 ab Fitness + Insurance (record ke lazmi
    // kagaz) + Route Permit (ikhtiyari) ka hai; qadam 7 bilkul
    // naya — Police Character Certificate।
    'Fitness, Insurance aur Permit',
    'Police Character Certificate',
    'Live Selfie',
    'Ilaqa aur Jaiza',
  ];

  static const _brandSuggestions = <String, List<String>>{
    'Rickshaw': ['Sazgar', 'New Asia', 'Vespa', 'Super Power', 'Tez Raftaar'],
    'Bike': ['Honda', 'Yamaha', 'Suzuki', 'United', 'Super Star'],
    'Car': ['Suzuki', 'Toyota', 'Honda', 'Kia', 'Hyundai'],
    'Taxi': ['Suzuki', 'Toyota', 'Honda', 'Hyundai'],
    'Van': ['Suzuki Bolan', 'Toyota HiAce', 'Suzuki APV', 'Suzuki Every', 'Changan Karvaan'],
  };

  final ImagePicker _picker = ImagePicker();

  // --- v1.4.7: Email + OTP (spec §1) ----------------------------------
  // Gmail LAZMI hai; OTP usi email par jata hai aur tasdeeq ke
  // baad hi ID aage badhti hai. [_emailVerifiedFor] woh email hai
  // jis ki OTP tasdeeq is form mein ho chuki hai (ya profile mein
  // pehle se verified hai aur email wohi hai)।
  late final _emailCtrl = TextEditingController(text: p.email);
  String _emailVerifiedFor = '';

  // --- v1.4.7: Gaari ki baqi tasaveer (spec §7 photo set) --------------
  late String _vehicleBack = p.vehicleBackPath;
  late String _vehicleLeft = p.vehicleLeftPath;
  late String _vehicleRight = p.vehicleRightPath;
  late String _vehicleInterior = p.vehicleInteriorPath;

  // --- AWAAZ KI HIDAYAT (v1.4.5 — malik ka hukm 2026-11-08) ------
  // Har qadam par Urdu awaaz ki hidayat: clips pehle se bana kar
  // assets/guidance/ mein bundle hain (OFFLINE chalte hain —
  // internet ho ya na ho). Qadam khulte hi awaaz khud bajti hai;
  // AppBar ke speaker button se dobara suni ja sakti hai; CNIC /
  // gaari ki tasveer wale khano par tap karne par un ki apni
  // hidayat bhi bajti hai. Awaaz SIRF is wizard mein hai — baqi
  // poori app mein kahin awaaz nahi bajti.
  // v1.4.6 (Package A): player ab shared [GuideAudio] helper mein
  // hai (guide_audio.dart) — wizard apna AudioPlayer NAHI rakhta.

  /// Har step ki entry hidayat (index = step number).
  static const _stepGuides = [
    'guidance/guidance_mobile.mp3', // 0 Mobile
    'guidance/guidance_personal.mp3', // 1 Zaati maloomat
    'guidance/guidance_password.mp3', // 2 Password
    'guidance/guidance_vehicle.mp3', // 3 Gaari
    'guidance/guidance_licence.mp3', // 4 Licence (ikhtiyari)
    // v1.4.19: qadam 6 ki NAYI hidayat — purani guidance_permit.mp3
    // ka matan purane (sirf-ikhtiyari) model ka tha, naye record
    // model se nahi milta, is liye woh clip is qadam par AB NAHI
    // bajti।
    // Nayi clip ka script GUIDANCE-GATE-TEXT.md mein hai; file
    // assets/guidance/ mein ane tak GuideAudio khamoshi se fail
    // hota hai (v1.4.14 wala hi rollout pattern) — qadam NAHI
    // rukta, screen ka likha hua matan asal hidayat rehta hai।
    'guidance/guidance_gate_docs.mp3', // 5 Fitness+Insurance+Permit
    'guidance/guidance_character.mp3', // 6 Character Certificate
    'guidance/guidance_selfie.mp3', // 7 Live selfie
    'guidance/guidance_review.mp3', // 8 Ilaqa + jaiza
  ];

  /// Mojooda step ki hidayat (dobara) chalana.
  void _playStepGuide() {
    if (_step >= 0 && _step < _stepGuides.length) {
      unawaited(GuideAudio.play(_stepGuides[_step]));
    }
  }

  @override
  void initState() {
    super.initState();
    // v1.4.7: profile ki email pehle se verify shuda ho to
    // section "verify shuda" haalat se shuru hoti hai (email
    // badalne par EmailOtpSection khud tasdeeq khatam kar deti
    // hai — yahan sirf woh email yaad rakha jata hai)।
    if (p.emailVerified) _emailVerifiedFor = p.email.trim().toLowerCase();
    // v1.4.7 AGENT LINK (spec §6): agent ke link se app khuli ho
    // to code pehle se bhara mile — driver ko kuch likhna hi
    // nahi padta। Checked-code khaali rakha hai taaki aakhri
    // qadam par is ki backend jaanch lazmi ho (band agent ka
    // code nayi registration par nahi lagta — purana usool)।
    if (p.agentCode.isEmpty && store.pendingAgentCode.isNotEmpty) {
      _agentCodeCtrl.text = store.pendingAgentCode;
      _agentCheckedCode = '';
      _agentValidCode = '';
    }
    // Pehla qadam khulte hi us ki hidayat khud bajti hai.
    WidgetsBinding.instance
        .addPostFrameCallback((_) => _playStepGuide());
  }

  int _step = 0;
  bool _busy = false;
  bool _done = false;
  String? _error;

  /// v1.4.25: darkhwast ASAL mein backend (Master ki queue) tak
  /// pohanchi ya nahi — "Darkhwast Master ke paas chali gayi"
  /// ka dawa sirf isi par hoga; false ho to done screen imaandar
  /// khabar + "Dobara Bhejein" dikhati hai।
  bool _backendSent = false;
  bool _sendRetrying = false;

  AppStore get store => widget.store;
  DriverProfile get p => store.profile;

  // --- Form state (profile se shuru — edit par purani values dikhti hain)
  late final _mobileCtrl = TextEditingController(text: p.phone);
  late final _nameCtrl = TextEditingController(text: p.name);
  late final _cnicCtrl = TextEditingController(text: p.cnicNumber);
  late final _pwdCtrl = TextEditingController();
  late final _pwd2Ctrl = TextEditingController();
  late final _brandCtrl = TextEditingController(text: p.vehicleBrand);
  late final _modelCtrl = TextEditingController(text: p.vehicleModel);
  late final _colorCtrl = TextEditingController(text: p.vehicleColor);
  late final _plateCtrl = TextEditingController(text: p.plate);
  late final _licenceCtrl = TextEditingController(text: p.licenceNumber);
  // AGENT CODE (v1.4.6): aakhri qadam ka ikhtiyari field — profile
  // mein pehle se code ho (dobara registration/edit) to bhara
  // hua ata hai.
  late final _agentCodeCtrl = TextEditingController(text: p.agentCode);

  late String _vehicle = p.vehicle;
  late int? _year = p.vehicleYear > 0 ? p.vehicleYear : null;
  // FORM USOOL (owner, 2026-11-08): sheher pehle se set NAHI hota —
  // profile mein zone darj ho to wohi, warna khaali (null) aur
  // driver aakhri qadam mein apna sheher KHUD chunta hai. Pehle
  // yahan khamoshi se 'Karachi' lag jata tha — woh khatam.
  late String _zone = kZones.contains(p.zone) ? p.zone : '';
  late String _cnicFront = p.cnicFrontPath;
  late String _cnicBack = p.cnicBackPath;
  late String _vehiclePhoto = p.vehiclePhotoPath;
  late String _vehicleReg = p.vehicleRegPath;
  late final _imeiCtrl = TextEditingController(text: p.imei);
  late String _licencePhoto = p.licencePhotoPath;
  late String _selfie = p.profilePhotoPath;

  // --- v1.4.14: Route Permit + Fitness wala qadam (naya qadam 6) ---
  // Tasaveer ikhtiyari hain; tasdeeq (checkbox) aage barhne ke
  // liye lazmi hai — ya phir driver yahin se registration khatam
  // karke bahir nikal sakta hai (koi zabardasti nahi)।
  late String _permitPhoto = p.permitPhotoPath;
  late String _fitnessPhoto = p.fitnessPhotoPath;
  // v1.4.19: do naye kagaz (record ke lazmi hisse) — profile se
  // pehle se bhare hue ate hain (adhoori registration mehfooz
  // rehti hai: driver baad mein aye to SIRF baqi kagaz lagata
  // hai, shuru se dobara NAHI)।
  late String _insurancePhoto = p.insurancePhotoPath;
  late String _characterPhoto = p.characterPhotoPath;
  late bool _permitDeclChecked = p.permitFitnessDeclAtMs > 0;
  late bool _licenceSkip =
      !(p.licenceStatus == 'has' || p.licenceNumber.isNotEmpty);

  /// Sharait ki qubooliyat (v1.4.4 LEGAL): review wale aakhri
  /// qadam par driver "Mein ne parh liya, qabool hai" par nishan
  /// lagata hai — baghair is ke register NAHI hota. Nishan lagte
  /// hi waqt profile mein darj ho jata hai (aur save par backend
  /// drivers.terms_accepted_at mein Master ke saboot ke liye
  /// jata hai). Pehle se qabool shuda ho to nishan laga hua ata hai.
  late bool _termsChecked = p.termsAcceptedAtMs > 0;

  /// AMANAT DEPOSIT ki alag tasdeeq (v1.4.21 — malik ka faisla
  /// 2026-11-10 20:05): review qadam par driver alag se nishan
  /// lagata hai ke us ne Amanat Deposit ki shartein samajh li
  /// hain — baghair is tasdeeq ke register NAHI hota. Asal
  /// shartein Sharait (legal.dart — "Amanat Deposit" wala hissa)
  /// mein hain; qubooliyat ka saboot termsAcceptedAtMs wala
  /// wohi waqt hai (tasdeeq usi sharait ki hai).
  bool _amanatChecked = false;

  /// Password jo is wizard mein uniqueness check PASS kar chuka hai —
  /// us ka fingerprint. Register dabane par profile mein lagta hai.
  /// (Profile par pehle se password ho to ye null rehta hai aur
  /// password wala qadam sirf maloomat dikhata hai.)
  String? _stagedFp;

  /// Jo password text check pass kar chuka hai — wohi dobara likha
  /// jaye to backend check dobara nahi chalta.
  String _checkedPw = '';

  /// AGENT CODE ki haalat (v1.4.6): [_agentCheckedCode] woh code
  /// hai jis ki backend jaanch ho chuki hai; [_agentValidCode]
  /// sirf tab bhara hota hai jab woh code kisi ACTIVE agent ka
  /// nikla ho — submit par profile mein sirf yehi jata hai.
  /// Code ikhtiyari hai: na mile to registration NAHI rukti,
  /// sirf halki warning ati hai. Profile ka purana code pehle
  /// se checked/valid mana jata hai (dobara edit par jab tak
  /// driver code BADLE nahi); agent baad mein band ho jaye to
  /// purana link/record waisa hi rehta hai (malik ka usool).
  late String _agentCheckedCode = p.agentCode;
  late String _agentValidCode = p.agentCode;

  @override
  void dispose() {
    unawaited(GuideAudio.stop());
    _mobileCtrl.dispose();
    _nameCtrl.dispose();
    _cnicCtrl.dispose();
    _imeiCtrl.dispose();
    _pwdCtrl.dispose();
    _pwd2Ctrl.dispose();
    _brandCtrl.dispose();
    _modelCtrl.dispose();
    _colorCtrl.dispose();
    _plateCtrl.dispose();
    _licenceCtrl.dispose();
    _agentCodeCtrl.dispose();
    _emailCtrl.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  // --- Tasveer chunna --------------------------------------------------------

  // Quality check thresholds (v1.4.6 Package A — conservative:
  // sirf WAZEH kharab tasveer rukti hai, aam tasveer kabhi nahi).
  static const double _kDarkLuminanceThreshold = 26.0;
  static const double _kBlurVarianceThreshold = 15.0;

  /// Halki quality jaanch: picked file ke bytes se chhota (96px
  /// wide) frame decode karke mean luminance (andhera) aur
  /// grayscale Laplacian variance (dhundlapan) napta hai.
  ///
  /// Wapas: 'dark' | 'blur' | null (theek hai).
  /// Check KHUD fail ho (exception / decode na ho) to null —
  /// quality check registration ko KABHI nahi rokti.
  Future<String?> _checkPhotoQuality(String path) async {
    try {
      final bytes = await File(path).readAsBytes();
      if (bytes.isEmpty) return null;
      final codec = await ui.instantiateImageCodec(
        bytes,
        targetWidth: 96,
      );
      final frame = await codec.getNextFrame();
      final image = frame.image;
      final int w = image.width;
      final int h = image.height;
      final ByteData? data =
          await image.toByteData(format: ui.ImageByteFormat.rawRgba);
      image.dispose();
      if (data == null) return null;
      final Uint8List px = data.buffer.asUint8List();
      final int count = w * h;
      if (count <= 0 || px.length < count * 4) return null;

      // Grayscale + mean luminance (ek hi pass).
      final Float64List gray = Float64List(count);
      double lumSum = 0;
      for (var i = 0; i < count; i++) {
        final int o = i * 4;
        final double lum =
            0.299 * px[o] + 0.587 * px[o + 1] + 0.114 * px[o + 2];
        gray[i] = lum;
        lumSum += lum;
      }
      final double meanLum = lumSum / count;
      if (meanLum < _kDarkLuminanceThreshold) return 'dark';

      // Laplacian variance — 3x3 kernel [0,1,0; 1,-4,1; 0,1,0],
      // andar wale pixels par stride sampling (bare frame par
      // har doosra pixel) taaki hisaab halka rahe.
      if (w < 3 || h < 3) return null;
      const int stride = 2;
      double lapSum = 0;
      double lapSqSum = 0;
      int n = 0;
      for (var y = 1; y < h - 1; y += stride) {
        for (var x = 1; x < w - 1; x += stride) {
          final int idx = y * w + x;
          final double lap = gray[idx - w] +
              gray[idx + w] +
              gray[idx - 1] +
              gray[idx + 1] -
              4 * gray[idx];
          lapSum += lap;
          lapSqSum += lap * lap;
          n++;
        }
      }
      if (n == 0) return null;
      final double mean = lapSum / n;
      final double variance = (lapSqSum / n) - (mean * mean);
      if (variance < _kBlurVarianceThreshold) return 'blur';
      return null;
    } catch (_) {
      // Check fail = photo apply ho jaye (kabhi rok NAHI).
      return null;
    }
  }

  /// Camera ya gallery se tasveer — selfie wale qadam ke ilawa har
  /// jagah dono option hain (mojooda app ka image picking pattern).
  /// v1.4.6: apply se PEHLE halki quality jaanch (andhera/dhundla)
  /// — fail par awaaz wali hidayat + snack, photo apply NAHI hoti.
  Future<void> _pickPhoto(void Function(String path) apply,
      {bool cameraOnly = false}) async {
    ImageSource? src = cameraOnly ? ImageSource.camera : null;
    if (!cameraOnly) {
      src = await showModalBottomSheet<ImageSource>(
        context: context,
        builder: (ctx) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt, color: Brand.green),
                title: const Text('Camera se tasveer lein'),
                onTap: () => Navigator.pop(ctx, ImageSource.camera),
              ),
              ListTile(
                leading:
                    const Icon(Icons.photo_library, color: Brand.green),
                title: const Text('Gallery se chunein'),
                onTap: () => Navigator.pop(ctx, ImageSource.gallery),
              ),
            ],
          ),
        ),
      );
    }
    if (src == null || !mounted) return;
    try {
      final img = await _picker.pickImage(source: src, imageQuality: 85);
      if (img == null) {
        // HOTFIX v1.2.9 (RC3): camera/gallery band karne par
        // khamoshi se wapas NAHI — wajah batao (duty selfie wala
        // wohi jumla/andaaz).
        if (mounted) {
          _snack(
              'Selfie nahi li gayi — camera band ho gaya ya permission nahi mili. Dobara koshish karein.');
        }
        return;
      }
      // --- Quality jaanch (apply se pehle) ---
      final String? issue = await _checkPhotoQuality(img.path);
      if (!mounted) return;
      if (issue == 'dark') {
        unawaited(GuideAudio.play('guidance/guidance_error_dark.mp3'));
        _snack(
            'Tasveer bohat andheri hai — roshni wali jagah par ja kar dobara saaf tasveer lein.');
        return;
      }
      if (issue == 'blur') {
        unawaited(GuideAudio.play('guidance/guidance_error_blur.mp3'));
        _snack(
            'Tasveer dhundli hai — mobile ko sabit rakh kar dobara saaf tasveer lein.');
        return;
      }
      if (mounted) setState(() => apply(img.path));
    } catch (_) {
      unawaited(GuideAudio.play('guidance/guidance_error_upload.mp3'));
      if (mounted) _snack('Tasveer nahi li ja saki.');
    }
  }

  // --- Validation -------------------------------------------------------------

  String _digits(String s) => s.replaceAll(RegExp(r'[^0-9]'), '');

  bool _fail(String msg) {
    setState(() => _error = msg);
    return false;
  }

  /// IMEI ki durusti: 15 digits + Luhn check digit (aakhri digit
  /// baqion se hisaab hota hai — ek digit ki typo bhi pakri jati
  /// hai). Ye sirf TYPO ki jaanch hai; PTA-approved hai ya nahi,
  /// ye faisla Master Tasdeeq mein 8484/DIRBS check se karta hai.
  bool _validImei(String d) {
    if (d.length != 15) return false;
    var sum = 0;
    for (var i = 0; i < 15; i++) {
      var n = int.tryParse(d[i]) ?? -1;
      if (n < 0) return false;
      if (i.isOdd) {
        n *= 2;
        if (n > 9) n -= 9;
      }
      sum += n;
    }
    return sum % 10 == 0;
  }

  /// Plate ki normalized shakal (bare haroof + number; spaces/
  /// dashes khatam) — takrao ki jaanch har jagah isi par hoti hai।
  static String _normPlate(String s) =>
      s.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

  /// EK GAARI = EK ID wala hold (spec §7 — wazahat ka rasta):
  /// plate doosri ID par mile to driver yahan SAARI tafseel
  /// likhta hai; "bhejein" par baat Master ke inbox mein
  /// ('Gaari Transfer' category) jati hai aur true wapas ata hai।
  Future<bool> _showPlateTransferDialog(String plateNorm) async {
    final ctrl = TextEditingController();
    final sent = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Ye gaari doosri ID par hai'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Plate $plateNorm pehle se ek aur driver ki ID par darj hai — ek gaari sirf ek hi ID par ho sakti hai.\n\nAgar ye gaari asal mein AAP ki hai (masalan aap ne khareedi hai), to neeche SAARI tafseel likhein — purana malik kaun tha, gaari kab/kahan se li, jo saboot hai woh likhein. Master wazahat dekh kar faisla karega; manzoori par gaari purani ID se hat kar aap ki ID par lag jayegi.',
                style: const TextStyle(fontSize: 13.5, height: 1.45),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: ctrl,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Apni wazahat — saari tafseel',
                  border: OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Rehne Dein'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Master ko Wazahat Bhejein'),
          ),
        ],
      ),
    );
    final tafseel = ctrl.text.trim();
    ctrl.dispose();
    if (sent != true) return false;
    await store.addMasterMessage(MasterMessage(
      id: store.newId(),
      senderKey: store.driverId,
      senderRole: 'driver',
      senderName: _nameCtrl.text.trim(),
      senderMobile: _digits(_mobileCtrl.text),
      senderZone: '',
      category: 'Gaari Transfer',
      body: 'GAARI TRANSFER WAZAHAT\n'
          'Plate: ${_plateCtrl.text.trim()} (normalized: $plateNorm)\n'
          'Gaari: $_vehicle · ${_brandCtrl.text.trim()} ${_modelCtrl.text.trim()}\n'
          'Masla: ye gaari pehle se doosri driver ID par darj hai — registration wahin ruk gayi hai.\n'
          'Driver ki wazahat: ${tafseel.isEmpty ? '(tafseel nahi likhi)' : tafseel}',
      createdAt: DateTime.now(),
    ));
    return true;
  }

  Future<bool> _validateStep() async {
    setState(() => _error = null);
    switch (_step) {
      case 0:
        final d = _digits(_mobileCtrl.text);
        if (!(d.length == 11 && d.startsWith('03'))) {
          return _fail(
              'Durust mobile number likhein — 03 se shuru, kul 11 number (masalan 03123456789).');
        }
        return true;
      case 1:
        if (_nameCtrl.text.trim().length < 3) {
          return _fail('Apna pura naam likhein (CNIC wala naam).');
        }
        if (_digits(_cnicCtrl.text).length != 13) {
          return _fail(
              'CNIC number durust likhein — XXXXX-XXXXXXX-X (kul 13 number).');
        }
        // v1.4.7 EMAIL + OTP (spec §1): Gmail lazmi hai aur us ki
        // OTP tasdeeq ke baghair ID aage NAHI badhti।
        final email = _emailCtrl.text.trim().toLowerCase();
        if (!(email.length >= 5 &&
            email.contains('@') &&
            email.split('@').last.contains('.'))) {
          return _fail(
              'Apni durust Gmail likhein — OTP code usi par jayega.');
        }
        if (_emailVerifiedFor != email) {
          return _fail(
              'Pehle "Code bhejein" dabakar apni Gmail par aya hua OTP code verify karein — tasdeeq ke baghair ID aage nahi badhegi.');
        }
        // EK CNIC = EK ACCOUNT (malik ka hukm 2026-11-08):
        // account shakhs (CNIC) ka hota hai, number/SIM ka nahi.
        // Ye CNIC kisi aur driver account mein pehle se darj ho
        // to doosra/fake account yahin ruk jata hai. Password
        // wale qadam wala hi usool: internet na mile to check
        // pass NAHI mana jata.
        setState(() => _busy = true);
        final cnicTaken = await Backend.cnicTakenByOther(
            _digits(_cnicCtrl.text), store.driverId);
        if (!mounted) return false;
        setState(() => _busy = false);
        if (cnicTaken == null) {
          return _fail(
              'CNIC ki jaanch ke liye internet chahiye — net on karke dobara koshish karein.');
        }
        if (cnicTaken) {
          return _fail(
              'Ye CNIC pehle se ek driver account mein darj hai — ek CNIC par sirf EK hi driver account ban sakta hai. Account shakhs (CNIC) ka hota hai, number ya SIM ka nahi. Agar ye aap ka apna purana account hai to naya account nahi banega — Master se rabta karein.');
        }
        if (_cnicFront.isEmpty) {
          return _fail('CNIC ki SAMNE wali tasveer lazmi hai.');
        }
        if (_cnicBack.isEmpty) {
          return _fail('CNIC ki PEECHE wali tasveer lazmi hai.');
        }
        return true;
      case 2:
        return _validatePasswordStep();
      case 3:
        if (_brandCtrl.text.trim().isEmpty) {
          return _fail('Gaari ki company/brand likhein (masalan Sazgar).');
        }
        if (_modelCtrl.text.trim().isEmpty) {
          return _fail('Gaari ka model likhein.');
        }
        if (_year == null) return _fail('Gaari ka saal (year) chunein.');
        if (_colorCtrl.text.trim().isEmpty) {
          return _fail('Gaari ka rang likhein.');
        }
        // v1.4.7 PLATE RULE (spec §7 + malik ki voice line
        // 2026-11-08 23:48): kam az kam EK side (samne ya peeche)
        // par number lazmi hai — plate hi na ho to qadam yahin
        // rukta hai aur awaaz wali hidayat chalti hai।
        if (_plateCtrl.text.trim().isEmpty) {
          unawaited(GuideAudio.play('guidance/guidance_plate.mp3'));
          return _fail(
              'Bhai, pehle apni gaari par number likhwayen — number plate lagwayen — us ke baad hi aap ki ID aage badhegi, warna nahi badhegi. Gaari ke samne ya peeche — kam az kam ek taraf number plate lazmi hai.');
        }
        if (_vehiclePhoto.isEmpty) {
          return _fail(
              'Gaari ki SAMNE wali tasveer lazmi hai — us mein number plate saaf parhi jaye.');
        }
        // v1.4.7 PHOTO SET (spec §7): chaaron taraf + andar ki
        // tasveer har registration par lazmi hai।
        if (_vehicleBack.isEmpty) {
          return _fail('Gaari ki PEECHE wali tasveer lazmi hai.');
        }
        if (_vehicleLeft.isEmpty) {
          return _fail('Gaari ki BAYEIN (left) taraf ki tasveer lazmi hai.');
        }
        if (_vehicleRight.isEmpty) {
          return _fail('Gaari ki DAYEIN (right) taraf ki tasveer lazmi hai.');
        }
        if (_vehicleInterior.isEmpty) {
          return _fail(
              'Gaari ke ANDAR ki tasveer lazmi hai (meter/seat wali).');
        }
        if (_vehicleReg.isEmpty) {
          return _fail('Gaari ke kaghaz (registration) ki tasveer lazmi hai.');
        }
        // PTA Proof: IMEI ki shart Master ke switch par hai
        // (settings.pta_required, migration v133; Fares.ptaRequired).
        // Default BAND hai — IMEI filhal IKHTIYARI hai: khaali ho
        // to koi rok nahi; LIKHA jaye to durust (15 digits + Luhn
        // check digit — typo yahin pakra jata hai) hona lazmi hai.
        // Master switch ON kare to IMEI lazmi ho jata hai.
        final imeiDigits = _digits(_imeiCtrl.text);
        if (Fares.ptaRequired &&
            (imeiDigits.length != 15 || !_validImei(imeiDigits))) {
          return _fail(
              'PTA Proof: durust IMEI likhein — *#06# dial karke 15 digits ka IMEI bilkul waisa hi likhein. IMEI ghalat ho to ID nahi banti.');
        }
        if (!Fares.ptaRequired &&
            imeiDigits.isNotEmpty &&
            (imeiDigits.length != 15 || !_validImei(imeiDigits))) {
          return _fail(
              'PTA Proof: IMEI likha hai to durust likhein — *#06# dial karke 15 digits ka IMEI bilkul waisa hi likhein, warna khaali chhor dein — filhal ye ikhtiyari hai.');
        }
        // v1.4.7 EK GAARI = EK ID (spec §7): ye plate kisi AUR
        // driver ki ID par pehle se ho to registration wahin rukti
        // hai — lekin band gali NAHI: driver apni saari tafseel
        // Master ko likh sakta hai; Master manzoor kare to gaari
        // purani ID se hat kar is ID par lag jayegi। Check khud
        // fail ho (net na mile) to registration NAHI rukti — asal
        // takrao hi rokta hai (warna net ki kharabi par har
        // registration atki rahegi); backend unique index (v137)
        // peeche ki asal hifazat hai।
        final plateNorm = _normPlate(_plateCtrl.text);
        if (plateNorm.length >= 4) {
          setState(() => _busy = true);
          // v1.4.23: takrao ka check ab plate_taken RPC se (sirf
          // boolean) — tamam drivers ki plates ki list ab app tak
          // ati hi nahi (flip ke baad woh parhai band hai)।
          final plateTaken = await Backend.plateTakenByOther(
              _plateCtrl.text, store.driverId);
          if (!mounted) return false;
          setState(() => _busy = false);
          if (plateTaken == true) {
            final sent = await _showPlateTransferDialog(plateNorm);
            if (!mounted) return false;
            if (sent) {
              return _fail(
                  'Aap ki wazahat Master ko bhej di gayi hai — ye gaari abhi doosri ID par darj hai, is liye registration yahin ruke gi. Master wazahat dekh kar faisla karega; manzoori par gaari purani ID se hat kar aap ki ID par lag jayegi aur aap ko khabar mil jayegi.');
            }
            return _fail(
                'Ye gaari (plate $plateNorm) pehle se ek aur driver ki ID par darj hai — ek gaari sirf ek hi ID par ho sakti hai. Apni gaari ka asal number plate darj karein aur documents complete karein, ya upar wali wazahat Master ko bhejein.');
          }
        }
        return true;
      case 4:
        if (_licenceSkip) return true;
        if (_licenceCtrl.text.trim().isEmpty) {
          return _fail(
              'Licence number likhein — ya neeche "Licence nahi hai — skip karein" dabayein.');
        }
        return true;
      case 5:
        // v1.4.19 DARMIYANI MODEL (malik ka FINAL faisla
        // 2026-11-10 18:18): Fitness Certificate aur Insurance
        // ke khane is qadam par maujood hain — jis ke paas hai
        // woh yahin upload kar deta hai; na hon to qadam NAHI
        // rukta (rehnumai neeche di hai, baad mein "Mere Kagaz"
        // se bhi lag jate hain)। In ki tasdeeq Master karega aur
        // saare kagaz verify hon to 'Mukammal Tasdeeq' darja
        // milta hai। Khud-zimmedari ki TASDEEQ (permit wala
        // hisaab, v1.4.14 se) barkarar hai — is qadam se aage
        // barhne ke liye woh qabool karna lazmi hai (saboot
        // waqt ke saath mehfooz hota hai)।
        if (!_permitDeclChecked && p.permitFitnessDeclAtMs == 0) {
          return _fail(
              'Aage barhne se pehle neeche wali tasdeeq parh kar "Mujhe qabool hai" par nishan lagayein — ya account nahi banana to neeche "Abhi nahi — registration yahin khatam karein" dabakar bahir nikal jayein. Koi zabardasti nahi hai.');
        }
        return true;
      case 6:
        // v1.4.19 DARMIYANI MODEL: Police Character Certificate
        // ka khana maujood hai aur har driver se manga jata hai
        // (Karachi/Sindh mein official rule abhi na aya ho, phir
        // bhi; Punjab mein baghair is ke tasdeeq mukammal nahi
        // hoti) — lekin certificate ki tangi par registration
        // NAHI rukti: photo ho to yahin lag jati hai, na ho to
        // rehnumai se banwa kar baad mein "Mere Kagaz" se lag
        // jayegi। Tasdeeq Master karega; ye kagaz 'Mukammal
        // Tasdeeq' darje ke set mein shamil hai।
        return true;
      case 7:
        if (_selfie.isEmpty) {
          return _fail(
              'Live selfie lazmi hai — camera se abhi tasveer lein.');
        }
        return true;
      case 8:
        // FORM USOOL: sheher driver khud chunta hai — khaali ho to
        // register aage nahi barhta (koi default sheher NAHI lagta).
        if (_zone.isEmpty) {
          return _fail('Apna sheher (ilaqa) chunein — upar wale list se.');
        }
        // v1.4.4 LEGAL: Sharait ki qubooliyat lazmi hai — baghair
        // "Mein ne parh liya, qabool hai" ke register NAHI hota.
        if (!_termsChecked && store.profile.termsAcceptedAtMs == 0) {
          return _fail(
              'Sharait qabool karna lazmi hai — neeche Sharait parh kar "Mein ne parh liya, qabool hai" par nishan lagayein.');
        }
        // AMANAT DEPOSIT (v1.4.21): is ki alag tasdeeq bhi
        // lazmi hai — driver saaf samjhe ke Rs 500 sirf us ki
        // amanat hai, us mein se sirf fees kategi aur baqi
        // us ki apni raqam hai jo chhorne par wapas milegi.
        if (!_amanatChecked) {
          return _fail(
              'Amanat Deposit ki tasdeeq lazmi hai — neeche "Amanat Deposit ki shartein mujhe samajh hain" par nishan lagayein.');
        }
        // AGENT CODE (v1.4.6): ikhtiyari hai — likha jaye to
        // backend `agents` mein jaanch hoti hai: ACTIVE agent
        // mile to code pakka ho jata hai (drivers.agent_code);
        // na mile to sirf halki warning — registration KABHI
        // nahi rukti, driver baghair code ke aage barh sakta hai.
        // Band (inactive) agent ka code nayi registration par
        // NAHI lagta (yahin se ruk jata hai: active check lazmi).
        // v1.4.14 (faisla D-1 — agents ke liye email lazmi):
        // agent code tab hi lagta hai jab driver ki Gmail OTP
        // se verify shuda ho — email tasdeeq ke baghair koi
        // agent link NAHI banta। (Wizard ka Zaati Maloomat
        // wala qadam isay pehle hi lazmi kar chuka hai; ye
        // guard usool ko yahan bhi wazeh rakhta hai।)
        final emailOk =
            _emailVerifiedFor == _emailCtrl.text.trim().toLowerCase();
        final agentCode = _agentCodeCtrl.text.trim().toUpperCase();
        if (agentCode.isEmpty || !emailOk) {
          _agentValidCode = '';
        } else if (agentCode != _agentCheckedCode) {
          setState(() => _busy = true);
          final agent = await AgentApi.fetchAgentByCode(agentCode);
          if (!mounted) return false;
          setState(() => _busy = false);
          _agentCheckedCode = agentCode;
          if (agent != null && agent.active) {
            _agentValidCode = agentCode;
          } else {
            _agentValidCode = '';
            _snack(
                'Ye code nahi mila — baghair code ke aage barh sakte hain.');
          }
        }
        return true;
      default:
        return true;
    }
  }

  /// Password wala qadam — v1.2.5 ke AIN usool: min 6, match, aur
  /// backend uniqueness check (internet ke baghair aage nahi).
  Future<bool> _validatePasswordStep() async {
    if (p.pwdFp.isNotEmpty) return true; // pehle se set hai
    final pw = _pwdCtrl.text;
    if (pw.isNotEmpty && pw == _checkedPw && _stagedFp != null) {
      return true; // yehi password pehle check pass kar chuka hai
    }
    if (pw.length < 6) {
      return _fail('Password kam az kam 6 haroof ka ho.');
    }
    if (pw != _pwd2Ctrl.text) {
      return _fail('Dono password ek jaise nahi hain.');
    }
    setState(() => _busy = true);
    final fp = passwordFingerprint(pw);
    final taken = await Backend.passwordFingerprintTaken(store, fp);
    if (!mounted) return false;
    setState(() => _busy = false);
    if (taken == null) {
      return _fail(
          'Password ki safety check ke liye internet chahiye — net on karke dobara koshish karein.');
    }
    if (taken) {
      _pwdCtrl.clear();
      _pwd2Ctrl.clear();
      _stagedFp = null;
      _checkedPw = '';
      return _fail(
          'Ye password kisi aur ne lagaya hua hai, aap koi aur password lagayen');
    }
    _stagedFp = fp;
    _checkedPw = pw;
    return true;
  }

  Future<void> _next() async {
    if (_busy) return;
    if (!await _validateStep()) return;
    if (!mounted) return;
    setState(() {
      _error = null;
      if (_step < 8) _step++;
    });
    // Naya qadam khula — us ki awaaz wali hidayat khud bajti hai.
    _playStepGuide();
  }

  void _back() {
    setState(() {
      _error = null;
      if (_step > 0) _step--;
    });
    _playStepGuide();
  }

  // --- Register (submit) ------------------------------------------------------

  Future<void> _submit() async {
    final v = store.profile;
    // v1.4.17 FCM: ye submit PEHLI registration hai ya purani
    // ID ki edit — Master ko push sirf pehli dafa jati hai
    // (har edit par khabar shor hogi)।
    final firstRegistration = !v.registrationDone;
    // NUMBER TABDEELI = 12 GHANTE BLOCK (malik ka hukm
    // 2026-11-08): pehle se registered driver apna number badle
    // to ID khud-ba-khud 12 ghante block — na online, na ride.
    // Waqt poora hote hi block khud khatam ho jata hai. Pehli
    // registration (purana number khaali) par ye NAHI lagta.
    final oldPhone = v.phone;
    final newPhone = _digits(_mobileCtrl.text);
    if (v.registrationDone &&
        oldPhone.isNotEmpty &&
        newPhone.isNotEmpty &&
        newPhone != oldPhone) {
      v.numberBlockedUntilMs =
          DateTime.now().millisecondsSinceEpoch + 12 * 3600 * 1000;
    }
    v.phone = newPhone;
    v.name = _nameCtrl.text.trim();
    v.cnicNumber = _formatCnic(_digits(_cnicCtrl.text));
    v.cnicFrontPath = _cnicFront;
    v.cnicBackPath = _cnicBack;
    if (_stagedFp != null) {
      v.pwdFp = _stagedFp!;
      v.pwdFailCount = 0;
      v.pwdLockUntilMs = 0;
    }
    v.vehicle = _vehicle;
    v.vehicleBrand = _brandCtrl.text.trim();
    v.vehicleModel = _modelCtrl.text.trim();
    v.vehicleYear = _year ?? 0;
    v.vehicleColor = _colorCtrl.text.trim();
    v.plate = _plateCtrl.text.trim();
    v.vehiclePhotoPath = _vehiclePhoto;
    v.vehicleRegPath = _vehicleReg;
    // v1.4.7: gaari ki baqi tasaveer (photo set)।
    v.vehicleBackPath = _vehicleBack;
    v.vehicleLeftPath = _vehicleLeft;
    v.vehicleRightPath = _vehicleRight;
    v.vehicleInteriorPath = _vehicleInterior;
    // v1.4.7 EMAIL (spec §1): OTP tasdeeq shuda email profile
    // mein darj + is session ki tasdeeq bhi pakki (registration
    // par hi OTP hua hai) — dobara login wala darwaza logout ke
    // baad hi ayega।
    final email = _emailCtrl.text.trim().toLowerCase();
    v.email = email;
    if (_emailVerifiedFor == email && email.isNotEmpty) {
      v.emailVerifiedAtMs = DateTime.now().millisecondsSinceEpoch;
      v.otpSessionVerified = true;
    }
    // PTA Proof — IMEI: badla ho to Master ka pta_status dobara
    // 'pending' (v131 trigger pta_resubmit_at se) taaki naya IMEI
    // dobara check ho — driver *_status khud NAHI likhta (lock).
    final newImei = _digits(_imeiCtrl.text);
    if (newImei.isNotEmpty && v.imei.isNotEmpty && newImei != v.imei) {
      v.docResubmitAt['pta'] = DateTime.now().toUtc().toIso8601String();
    }
    v.imei = newImei;
    if (_licenceSkip) {
      v.licenceStatus = 'none';
      v.licenceVerified = false;
      v.licenceNumber = '';
      v.licencePhotoPath = '';
    } else {
      final newNumber = _licenceCtrl.text.trim();
      if (newNumber != v.licenceNumber) v.licenceVerified = false;
      v.licenceStatus = 'has';
      v.licenceNumber = newNumber;
      v.licencePhotoPath = _licencePhoto;
    }
    // v1.4.14: Route Permit / Fitness ki tasaveer + khud-
    // zimmedari TASDEEQ ka waqt (saboot ke liye profile mein
    // mehfooz; pehli qubooliyat par hi waqt lagta hai, dobara
    // edit par purana waqt hi saboot rehta hai)।
    v.permitPhotoPath = _permitPhoto;
    v.fitnessPhotoPath = _fitnessPhoto;
    // v1.4.19: Insurance + Character Certificate ki tasaveer —
    // jo is run mein lagi hon wohi profile mein jati hain
    // (khaali hon to khaali hi — registration in par NAHI rukti;
    // baad mein Mere Kagaz se lag jayengi)।
    v.insurancePhotoPath = _insurancePhoto;
    v.characterPhotoPath = _characterPhoto;
    if (_permitDeclChecked && v.permitFitnessDeclAtMs == 0) {
      v.permitFitnessDeclAtMs =
          DateTime.now().millisecondsSinceEpoch;
    }
    v.profilePhotoPath = _selfie;
    v.zone = _zone;
    // AGENT CODE (v1.4.6): sirf wohi code jo aakhri qadam ki
    // jaanch mein kisi ACTIVE agent ka nikla ho (ya profile ka
    // purana barkarar code). Ghalat/na-mila code kabhi profile
    // mein nahi jata.
    v.agentCode = _agentValidCode;
    v.registrationDone = true;
    // Kagazat ki rukawatein registration ke waqt hi saaf (v1.2.9):
    // purane self-attestation wale local jhande nayi tasaveer par
    // dobara 'pending' ho jate hain — faisla ab sirf Master ka hai.
    v.cnicStatus = 'pending';
    v.vehiclePapers = 'pending';
    // store.save() → 'profile' hook → backend drivers row (numbers,
    // tafseel, fingerprint) Master tak mirror ho jata hai. Document
    // STATUS columns is mirror mein NAHI jate (Master-owned hain).
    await store.save();
    // v1.4.7: email ka backend record (v137 drivers.email) —
    // best-effort; column abhi na ho to local record asal hai।
    if (v.emailVerified) {
      unawaited(Backend.pushDriverEmail(
          store.driverId,
          v.email,
          DateTime.fromMillisecondsSinceEpoch(v.emailVerifiedAtMs)));
    }
    // v1.4.14: tasdeeq ke waqt ka backend record (guarded —
    // column abhi na ho to khamosh; local waqt asal saboot hai)
    // aur pehchan ka link (identity_links — OTP session se
    // driver ki pehchan bandhna; documents ki upload se pehle
    // hona chahiye taaki Phase 4 ki storage policies par link
    // pehle se maujood ho — syncDriverDocs is ke baad ke sync
    // par chalta hai)।
    if (v.permitFitnessDeclAtMs > 0) {
      // v1.4.25: Recorded wala roop — nakami par pending nishan
      // lagta hai aur startup dobara koshish karta hai (pehle
      // ye call khamoshi se fail hoti thi jab ke column abhi
      // schema mein hai hi nahi; draft sql-v148 mein hai)।
      unawaited(Backend.pushPermitFitnessDeclRecorded(
          store.driverId, v.permitFitnessDeclAtMs));
    }
    unawaited(Backend.linkIdentities(store));
    // v1.4.17 FCM: pehli registration mukammal — Master ko
    // foran khabar (Tasdeeq ki queue ke saath saath push bhi)।
    // Fire-and-forget; function deploy na ho to khamosh।
    if (firstRegistration) {
      unawaited(Backend.invokePush({
        'audience': 'masters',
        'title': 'Nayi Driver Registration',
        'body':
            '${v.name} · ${v.zone} · ${v.vehicle}${v.plate.isEmpty ? '' : ' · ${v.plate}'} — Tasdeeq ke liye tayyar hai',
        'data': {'driver_id': store.driverId},
      }));
    }
    // v1.4.7: agent link ka code istemal ho gaya — pending saaf
    // (refer ek-dafa lock: code ab profile mein mustaqil hai)।
    if (store.pendingAgentCode.isNotEmpty) {
      store.pendingAgentCode = '';
      await store.save();
    }
    // v1.4.25 BACKEND TASDEEQ (postmortem #4): pehle "Darkhwast
    // Master ke paas chali gayi" ka dawa baghair kisi tasdeeq ke
    // ho jata tha — pushes saare unawaited thay aur fail bhi ho
    // jayein to screen kamyabi dikhati thi। Ab asal jawab ka
    // intezaar hota hai: drivers row Master ki queue mein asal
    // mein maujood hai ya nahi (ensureDriverRow ka bool jawab)।
    // Na pohanchay to done screen imaandar khabar + "Dobara
    // Bhejein" dikhayegi; registration is phone mein mukammal
    // mehfooz hai aur app dobara khulte hi startup sync
    // (ensureDriverRow + documents) khud dobara koshish karega।
    var sent = false;
    try {
      sent = await Backend.ensureDriverRow(store).timeout(
          const Duration(seconds: 15),
          onTimeout: () => false);
    } catch (_) {
      sent = false;
    }
    _backendSent = sent;
    if (mounted) setState(() => _done = true);
  }

  /// "Dobara Bhejein" — done screen se darkhwast ki dobara
  /// koshish (v1.4.25): drivers row + documents dono ka rasta
  /// dobara chalaya jata hai; kamyabi par screen asal kamyabi
  /// wali shakl mein badal jati hai।
  Future<void> _retrySendRegistration() async {
    if (_sendRetrying) return;
    setState(() => _sendRetrying = true);
    var sent = false;
    try {
      sent = await Backend.ensureDriverRow(store).timeout(
          const Duration(seconds: 15),
          onTimeout: () => false);
      if (sent) {
        await Backend.syncDriverDocs(store);
      }
    } catch (_) {
      sent = false;
    }
    if (!mounted) return;
    setState(() {
      _sendRetrying = false;
      _backendSent = sent;
    });
  }

  static String _formatCnic(String d) {
    if (d.length != 13) return d;
    return '${d.substring(0, 5)}-${d.substring(5, 12)}-${d.substring(12)}';
  }

  // --- Build ------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Driver Registration'),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          // Dobara sunein — is qadam ki awaaz wali hidayat phir se.
          IconButton(
            icon: const Icon(Icons.volume_up),
            tooltip: 'Hidayat dobara sunein',
            onPressed: _playStepGuide,
          ),
        ],
      ),
      body: _done ? _doneView() : _formView(),
    );
  }

  Widget _doneView() {
    // v1.4.25: do shaklein — asal kamyabi (backend tasdeeq ke
    // saath) ya imaandar "abhi nahi gayi" (retry ke saath)।
    // Dawa hamesha asal haalat ke mutabiq hoga।
    if (!_backendSent) {
      return Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.cloud_off, color: Brand.ajrakRed, size: 84),
            const SizedBox(height: 16),
            const Text('Registration Is Phone Mein Mehfooz Hai',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            const Text(
              'Aap ki darkhwast abhi Master tak NAHI gayi — internet ka masla lagta hai.\n\n'
              'Fikr na karein: aap ki saari maloomat is phone mein mukammal mehfooz hai. Internet ate hi neeche wala button dabayein — ya app dobara khol lein, darkhwast khud chali jayegi.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, height: 1.5),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _sendRetrying ? null : _retrySendRegistration,
                icon: _sendRetrying
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.refresh, size: 19),
                label: Text(_sendRetrying ? 'Bhej rahe hain…' : 'Dobara Bhejein'),
              ),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Baad Mein Bhej Dunga'),
            ),
          ],
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.check_circle, color: Brand.green, size: 84),
          const SizedBox(height: 16),
          const Text('Registration Mukammal!',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          const Text(
            'Darkhwast Master ke paas chali gayi hai — tasdeeq ke baad aap online ho sakenge.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Theek hai'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _formView() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
          child: Row(
            children: [
              Text('Qadam ${_step + 1} / 9',
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, color: Brand.greenDark)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(_titles[_step],
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w900)),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: LinearProgressIndicator(
            value: (_step + 1) / 9,
            color: Brand.gold,
            backgroundColor: Brand.fieldBorder,
            minHeight: 6,
            borderRadius: BorderRadius.circular(3),
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _stepBody(),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!,
                    style: const TextStyle(
                        color: Brand.ajrakRed,
                        fontWeight: FontWeight.w700,
                        fontSize: 14)),
              ],
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Row(
              children: [
                if (_step > 0)
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _busy ? null : _back,
                      child: const Text('Peeche'),
                    ),
                  ),
                if (_step > 0) const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: _step == 8
                      ? ElevatedButton(
                          onPressed: () async {
                            // Register se pehle aakhri qadam ki
                            // jaanch (sheher lazmi hai — FORM USOOL).
                            if (await _validateStep()) _submit();
                          },
                          child: const Text('Register Karein'),
                        )
                      : ElevatedButton(
                          onPressed: _busy ? null : _next,
                          child:
                              Text(_busy ? 'Check ho raha hai…' : 'Aage'),
                        ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _stepBody() {
    switch (_step) {
      case 0:
        return _stepMobile();
      case 1:
        return _stepPersonal();
      case 2:
        return _stepPassword();
      case 3:
        return _stepVehicle();
      case 4:
        return _stepLicence();
      case 5:
        return _stepFitnessInsurance();
      case 6:
        return _stepCharacter();
      case 7:
        return _stepSelfie();
      default:
        return _stepReview();
    }
  }

  // --- Step 1: Mobile ---------------------------------------------------------

  Widget _stepMobile() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Apna mobile number likhein — isi number par sawari aur Master rabta karenge.',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _mobileCtrl,
          keyboardType: TextInputType.phone,
          maxLength: 11,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(
            labelText: 'Mobile number (03XXXXXXXXX)',
            prefixIcon: Icon(Icons.phone),
          ),
        ),
      ],
    );
  }

  // --- Step 2: Zaati maloomat ---------------------------------------------------

  Widget _stepPersonal() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: _nameCtrl,
          decoration: const InputDecoration(
            labelText: 'Pura naam (CNIC wala)',
            prefixIcon: Icon(Icons.person),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _cnicCtrl,
          keyboardType: TextInputType.number,
          inputFormatters: [_CnicInputFormatter()],
          decoration: const InputDecoration(
            labelText: 'CNIC number (XXXXX-XXXXXXX-X)',
            prefixIcon: Icon(Icons.badge),
          ),
        ),
        const SizedBox(height: 16),
        const Text('CNIC ki tasaveer',
            style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: _photoSlot(
                label: 'CNIC — Samne',
                path: _cnicFront,
                icon: Icons.credit_card,
                onPick: () => _pickPhoto((v) => _cnicFront = v),
                guideAsset: 'guidance/guidance_cnic_front.mp3',
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _photoSlot(
                label: 'CNIC — Peeche',
                path: _cnicBack,
                icon: Icons.credit_card,
                onPick: () => _pickPhoto((v) => _cnicBack = v),
                guideAsset: 'guidance/guidance_cnic_back.mp3',
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        // v1.4.7 EMAIL + OTP (spec §1): Gmail lazmi — code usi
        // par jata hai, tasdeeq ke baghair ye qadam aage NAHI
        // badhta (validation case 1 dekhein)।
        const Text('Gmail aur OTP tasdeeq',
            style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        const Text(
          'Aaj kal Gmail sab ke paas hai — aap ki ID aap ki Gmail se bandhi rahegi. Random number se login band hai: logout ya nayi device par dobara login bhi isi Gmail par aye OTP se hoga.',
          style: TextStyle(fontSize: 12.5, color: Colors.black54),
        ),
        const SizedBox(height: 8),
        EmailOtpSection(
          emailCtrl: _emailCtrl,
          alreadyVerifiedEmail: p.emailVerified ? p.email : '',
          playGuideOnInit: true,
          onVerified: (email) => _emailVerifiedFor = email,
        ),
      ],
    );
  }

  // --- Step 3: Password ---------------------------------------------------------

  Widget _stepPassword() {
    if (p.pwdFp.isNotEmpty) {
      return const Card(
        child: ListTile(
          leading: Icon(Icons.lock, color: Brand.green),
          title: Text('Password pehle se set hai',
              style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(
              'Aap ka password laga hua hai — ek password sirf aap ka hai. Badalna ho to Profile se badlein.'),
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Apna password khud lagayein. Ek password sirf ek hi driver ka hota hai — jo pehle lag jaye, wohi us ka ho jata hai. Duty shuru karne par yahi password manga jayega.',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _pwdCtrl,
          obscureText: true,
          decoration: const InputDecoration(
            labelText: 'Password (kam az kam 6 haroof)',
            prefixIcon: Icon(Icons.lock),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _pwd2Ctrl,
          obscureText: true,
          decoration: const InputDecoration(
            labelText: 'Password dobara likhein',
            prefixIcon: Icon(Icons.lock_outline),
          ),
        ),
      ],
    );
  }

  // --- Step 4: Gaari ki maloomat ----------------------------------------------

  Widget _stepVehicle() {
    final years = <int>[
      for (var y = DateTime.now().year + 1; y >= 1990; y--) y
    ];
    final suggestions = _brandSuggestions[_vehicle] ?? const <String>[];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Gaari ki qisam',
            style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Row(
          children: [
            for (final v in kVehicles) ...[
              Expanded(child: _vehicleCard(v)),
              if (v != kVehicles.last) const SizedBox(width: 10),
            ],
          ],
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _brandCtrl,
          decoration: const InputDecoration(
            labelText: 'Company / Brand (masalan Sazgar)',
            prefixIcon: Icon(Icons.factory),
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: suggestions
              .map((s) => ChoiceChip(
                    label: Text(s),
                    selected: _brandCtrl.text.trim() == s,
                    onSelected: (_) =>
                        setState(() => _brandCtrl.text = s),
                  ))
              .toList(),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _modelCtrl,
          decoration: const InputDecoration(
            labelText: 'Model (masalan 150cc, Mehran VX)',
            prefixIcon: Icon(Icons.directions_car),
          ),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<int>(
          value: _year,
          isExpanded: true,
          decoration: const InputDecoration(
            labelText: 'Saal (Year)',
            prefixIcon: Icon(Icons.calendar_month),
          ),
          items: years
              .map((y) => DropdownMenuItem(value: y, child: Text('$y')))
              .toList(),
          onChanged: (v) => setState(() => _year = v),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _colorCtrl,
          decoration: const InputDecoration(
            labelText: 'Rang (Color)',
            prefixIcon: Icon(Icons.palette),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _plateCtrl,
          decoration: const InputDecoration(
            labelText: 'Number plate',
            prefixIcon: Icon(Icons.pin),
          ),
        ),
        const SizedBox(height: 16),
        // v1.4.7 PHOTO SET (spec §7): chaaron taraf (samne wali
        // mein number plate saaf parhi jaye) + andar ki ek
        // tasveer — registrtion book ke saath kul 6 tasaveer।
        const Text('Gaari ki tasaveer — chaaron taraf + andar',
            style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: _photoSlot(
                label: 'Samne (Front) — plate saaf nazar aye',
                path: _vehiclePhoto,
                icon: Icons.photo_camera,
                onPick: () => _pickPhoto((v) => _vehiclePhoto = v),
                guideAsset: 'guidance/guidance_vehicle_photo.mp3',
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _photoSlot(
                label: 'Peeche (Back)',
                path: _vehicleBack,
                icon: Icons.photo_camera,
                onPick: () => _pickPhoto((v) => _vehicleBack = v),
                guideAsset: 'guidance/guidance_vehicle_photo.mp3',
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _photoSlot(
                label: 'Bayein taraf (Left)',
                path: _vehicleLeft,
                icon: Icons.photo_camera,
                onPick: () => _pickPhoto((v) => _vehicleLeft = v),
                guideAsset: 'guidance/guidance_vehicle_photo.mp3',
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _photoSlot(
                label: 'Dayein taraf (Right)',
                path: _vehicleRight,
                icon: Icons.photo_camera,
                onPick: () => _pickPhoto((v) => _vehicleRight = v),
                guideAsset: 'guidance/guidance_vehicle_photo.mp3',
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _photoSlot(
                label: 'Andar (Meter / Seat)',
                path: _vehicleInterior,
                icon: Icons.photo_camera,
                onPick: () => _pickPhoto((v) => _vehicleInterior = v),
                guideAsset: 'guidance/guidance_vehicle_photo.mp3',
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _photoSlot(
                label: 'Kaghaz (Registration)',
                path: _vehicleReg,
                icon: Icons.description,
                onPick: () => _pickPhoto((v) => _vehicleReg = v),
                guideAsset: 'guidance/guidance_vehicle_reg.mp3',
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        const Text('PTA Proof',
            style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Text(
          Fares.ptaRequired
              ? 'Apne mobile ka IMEI number likhein — *#06# dial karne se IMEI screen par a jata hai, bilkul waisa hi yahan likh dein. '
                  'ID sirf tab OK (Active) hogi jab ye IMEI check hone par PTA-approved nikle. IMEI ghalat ya mobile PTA-approved na ho to ID NAHI banti. '
                  'Master Tasdeeq mein is IMEI ko 8484/DIRBS par check karke faisla karega.'
              : 'Apne mobile ka IMEI number likh dein — *#06# dial karne se IMEI screen par a jata hai, bilkul waisa hi yahan likh dein. '
                  'Filhal ye IKHTIYARI hai — na likhein to bhi ID ban sakti hai; likh dein to Master Tasdeeq mein is IMEI ko 8484/DIRBS par check kar sakta hai. '
                  'Jab Master "PTA Proof lazmi" ON karega, tab IMEI lazmi ho jayega.',
          style: const TextStyle(
              fontSize: 12.5, height: 1.45, color: Colors.black87),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _imeiCtrl,
          keyboardType: TextInputType.number,
          maxLength: 15,
          decoration: const InputDecoration(
            labelText: 'IMEI Number (15 digits)',
            prefixIcon: Icon(Icons.verified),
            counterText: '',
          ),
        ),
      ],
    );
  }

  Widget _vehicleCard(String v) {
    final selected = _vehicle == v;
    // B7 (DESIGN WAVE): har gaari ka APNA icon — passenger side
    // wale sahi icons (Rickshaw = electric_rickshaw, Taxi =
    // local_taxi); pehle Rickshaw/Taxi bhi airport_shuttle par thay.
    final icon = v == 'Bike'
        ? Icons.two_wheeler
        : v == 'Car'
            ? Icons.directions_car
            : v == 'Taxi'
                ? Icons.local_taxi
                : v == 'Rickshaw'
                    ? Icons.electric_rickshaw
                    : Icons.airport_shuttle;
    return InkWell(
      onTap: () => setState(() => _vehicle = v),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: selected ? Brand.green : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: selected ? Brand.gold : Brand.fieldBorder, width: 2),
        ),
        child: Column(
          children: [
            Icon(icon,
                size: 32,
                color: selected ? Colors.white : Brand.green),
            const SizedBox(height: 6),
            Text(v,
                style: TextStyle(
                    fontWeight: FontWeight.w800,
                    color: selected ? Colors.white : Brand.ink)),
          ],
        ),
      ),
    );
  }

  // --- Step 5: Driving licence (OPTIONAL) ---------------------------------------

  Widget _stepLicence() {
    if (_licenceSkip) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Card(
            child: ListTile(
              leading: Icon(Icons.info_outline, color: Brand.green),
              title: Text('Licence skip hai',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(
                  'Koi baat nahi — CNIC se registration ho jayegi. Licence ho to neeche se tafseel likh dein.'),
            ),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => setState(() {
              _licenceSkip = false;
              _error = null;
            }),
            icon: const Icon(Icons.badge),
            label: const Text('Licence hai — tafseel likhein'),
          ),
        ],
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Licence hai to number aur tasveer dein. Licence NA ho to registration nahi rukti — CNIC hi kafi hai.',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _licenceCtrl,
          decoration: const InputDecoration(
            labelText: 'Licence number',
            prefixIcon: Icon(Icons.badge),
          ),
        ),
        const SizedBox(height: 16),
        _photoSlot(
          label: 'Licence ki tasveer',
          path: _licencePhoto,
          icon: Icons.badge,
          onPick: () => _pickPhoto((v) => _licencePhoto = v),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: () {
              setState(() {
                _licenceSkip = true;
                _error = null;
                if (_step < 8) _step++;
              });
              _playStepGuide();
            },
            child: const Text('Licence nahi hai — skip karein'),
          ),
        ),
      ],
    );
  }

  // --- Step 6 (v1.4.19): Fitness + Insurance + Route Permit ----
  //
  // v1.4.14 mein ye qadam Route Permit + Fitness ka tha। v1.4.19
  // DARMIYANI MODEL (malik ka FINAL faisla 2026-11-10 18:18):
  // Fitness Certificate aur Gaari ki Insurance har driver ke
  // record ke lazmi kagaz hain — khane yahan maujood hain, jis
  // ke paas hai woh upload kar deta hai, Master tasdeeq karta
  // hai aur asal haalat dono apps mein dikhti hai — LEKIN in ki
  // tangi par na registration rukti hai, na (is build mein)
  // online; woh sakhti sirf Master ke full_docs_required flag
  // se ayegi। Saare kagaz verified hon to 'Mukammal Tasdeeq'
  // darja milta hai। Route Permit ab bhi ikhtiyari hai (us ki
  // khud-zimmedari wali tasdeeq barkarar hai)। Har kagaz ke
  // neeche REHNUMAI hai (malik ka hukm ~18:12): kagaz na ho to
  // driver ko rasta bhi dikhana hai।
  Widget _stepFitnessInsurance() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Ye qadam gaari ke kagazon ka hai. Fitness Certificate aur Gaari ki Insurance (third-party) har driver ke record ke liye lazmi kagaz hain — jis ke paas hain, un ki tasveer yahan laga dein; Master in ki tasdeeq karega. Saare kagaz tasdeeq ho jayein to aap ko "Mukammal Tasdeeq" ka darja milta hai. Kagaz abhi na hon to ghabrayein nahi — neeche rehnumai hai; banwa kar baad mein Profile ke "Mere Kagaz" se bhi laga sakte hain. Route Permit ho to woh bhi laga dein (ikhtiyari hai).',
          style: TextStyle(fontSize: 13.5, height: 1.5),
        ),
        const SizedBox(height: 14),
        _photoSlot(
          label: 'Fitness Certificate ki tasveer',
          path: _fitnessPhoto,
          icon: Icons.fact_check,
          onPick: () => _pickPhoto((v) => _fitnessPhoto = v),
          guideAsset: 'guidance/guidance_gate_docs.mp3',
        ),
        const SizedBox(height: 6),
        const Text(kFitnessRehnumai,
            style: TextStyle(fontSize: 12.5, height: 1.45, color: Colors.black54)),
        const SizedBox(height: 16),
        _photoSlot(
          label: 'Gaari ki Insurance (Third-Party) ki tasveer',
          path: _insurancePhoto,
          icon: Icons.shield,
          onPick: () => _pickPhoto((v) => _insurancePhoto = v),
          guideAsset: 'guidance/guidance_gate_docs.mp3',
        ),
        const SizedBox(height: 6),
        const Text(kInsuranceRehnumai,
            style: TextStyle(fontSize: 12.5, height: 1.45, color: Colors.black54)),
        const SizedBox(height: 16),
        _photoSlot(
          label: 'Route Permit ki tasveer (ho to — ikhtiyari)',
          path: _permitPhoto,
          icon: Icons.assignment,
          onPick: () => _pickPhoto((v) => _permitPhoto = v),
        ),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF6E0),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Brand.gold),
          ),
          child: const Text(
            'Fitness Certificate aur Gaari ki Insurance har driver ke record ke lazmi kagaz hain — in ki tasdeeq Master karega; saare kagaz verify hon to "Mukammal Tasdeeq" darja milta hai. In kagazon ko har waqt VALID (taaza) rakhna aap ki apni zimmedari hai.\n\nRoute Permit ab bhi ikhtiyari hai — lekin ye baat saaf samajh lein: Route Permit rakhna meri apni zimmedari hai. Ye kagaz na honay ki wajah se agar challan ho, gaari band ho, ya koi aur nuqsan ho to us ka zimmedar mein khud hunga — Bozdar Safar is ka zimmedar nahi hoga.\n\nYe app drivers ke liye bilkul FREE hai — koi fee nahi li jati. Ye app drivers aur ghareebon ke bhale ke liye banayi gayi hai, is liye har driver apne kagaz khud poore rakhe.',
            style: TextStyle(fontSize: 13, height: 1.55),
          ),
        ),
        const SizedBox(height: 10),
        CheckboxListTile(
          value: _permitDeclChecked,
          onChanged: (v) =>
              setState(() => _permitDeclChecked = v ?? false),
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          title: const Text(
            'Mein ne upar wali baat parh/sun li hai — mujhe qabool hai ke Fitness Certificate, Insurance aur Route Permit ke kagaz meri apni zimmedari hain.',
            style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600),
          ),
        ),
        const SizedBox(height: 6),
        // WAZEH EXIT (owner ka hukm): account na banana ho to
        // yahin se khatam karke bahir — registration adhoori
        // rehti hai, koi penalty nahi, koi zabardasti nahi।
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text(
                'Abhi nahi — registration yahin khatam karein'),
          ),
        ),
        const SizedBox(height: 4),
        const Text(
          'Is button se aap baghair account banaye bahir nikal jayenge — jab marzi ho, wapas aakar registration wahan se aage badha sakte hain jahan chhori thi.',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
      ],
    );
  }

  // --- Step 7 (v1.4.19): Police Character Certificate ------------
  //
  // DARMIYANI MODEL (malik ka FINAL faisla 2026-11-10 18:18):
  // ye kagaz SAB drivers se manga jata hai — Karachi/Sindh mein
  // is ka official rule abhi nahi aya, lekin record mein wahan
  // ka driver bhi bana kar upload karega; Punjab mein baghair
  // is ke tasdeeq mukammal nahi hoti। Ek hi usool, koi
  // sheher-exception nahi — LEKIN certificate ki tangi par
  // registration NAHI rukti (validation case 6 hamesha pass):
  // khana + rehnumai + Master tasdeeq + 'Mukammal Tasdeeq'
  // darje mein shumaar — yehi darmiyani rasta hai। Certificate
  // abhi na ho to driver form band karke baad mein wapas a
  // sakta hai — registration mehfooz rehti hai, sirf yehi
  // photo lagani baqi rehti hai ("Mere Kagaz" se bhi lagti hai)।
  Widget _stepCharacter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Ye qadam Police Character Certificate ka hai. Ye certificate har driver ke record ke liye manga jata hai — is se saabit hota hai ke driver ka koi criminal record nahi hai. Ye usool har sheher ke har driver ke liye ek jaisa hai. Certificate ho to tasveer yahan laga dein — Master tasdeeq karega, aur ye kagaz "Mukammal Tasdeeq" darje ke liye lazmi hai. Abhi na ho to neeche rehnumai se banwayein — registration is par nahi rukti.',
          style: TextStyle(fontSize: 13.5, height: 1.5),
        ),
        const SizedBox(height: 14),
        _photoSlot(
          label: 'Character Certificate ki tasveer',
          path: _characterPhoto,
          icon: Icons.badge,
          onPick: () => _pickPhoto((v) => _characterPhoto = v),
          guideAsset: 'guidance/guidance_character.mp3',
        ),
        const SizedBox(height: 10),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF6E0),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Brand.gold),
          ),
          child: const Text(kCharacterRehnumai,
              style: TextStyle(fontSize: 13, height: 1.55)),
        ),
        const SizedBox(height: 10),
        const Text(
          'Certificate abhi na ho to koi baat nahi — peeche ja kar ya form band karke ja sakte hain; aap ki bhari hui registration mehfooz rahegi. Certificate mil jaye to wapas aakar SIRF yehi photo lagani hai — dobara shuru se kuch nahi bharna.',
          style: TextStyle(fontSize: 12.5, height: 1.45, color: Colors.black54),
        ),
      ],
    );
  }

  // --- Step 8: Live selfie ------------------------------------------------------

  Widget _stepSelfie() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Apni asal tasveer — ye aap ki registration profile photo hai. Camera se hi hogi, gallery se nahi. (Rozana wali duty selfie is se alag hoti hai.)',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 18),
        Center(
          child: ClipOval(
            child: _selfie.isNotEmpty && File(_selfie).existsSync()
                ? Image.file(File(_selfie),
                    width: 170, height: 170, fit: BoxFit.cover)
                : Container(
                    width: 170,
                    height: 170,
                    color: Brand.fieldBorder,
                    child: const Icon(Icons.face,
                        size: 80, color: Brand.green),
                  ),
          ),
        ),
        const SizedBox(height: 18),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: () =>
                _pickPhoto((v) => _selfie = v, cameraOnly: true),
            icon: const Icon(Icons.camera_alt),
            label:
                Text(_selfie.isEmpty ? 'Live Selfie Lein' : 'Dobara Lein'),
          ),
        ),
      ],
    );
  }

  // --- Step 8: Ilaqa + Jaiza -----------------------------------------------------

  Widget _stepReview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Apna sheher (ilaqa) chunein',
            style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        // Sheher pehle se set NAHI hota (FORM USOOL 2026-11-08):
        // _zone khaali ho to dropdown khaali (hint) dikhta hai aur
        // driver apna sheher khud chunta hai.
        DropdownButtonFormField<String>(
          value: _zone.isEmpty ? null : _zone,
          isExpanded: true,
          hint: const Text('Apna sheher chunein'),
          items: kZones
              .map((z) => DropdownMenuItem(value: z, child: Text(z)))
              .toList(),
          onChanged: (v) => setState(() => _zone = v ?? _zone),
          decoration: const InputDecoration(labelText: 'Sheher (Zone)'),
        ),
        const SizedBox(height: 18),
        // AGENT CODE (v1.4.6): ikhtiyari field — jaiza se pehle.
        // Agent ne bheja ho to us ka code; warna khaali chhor
        // dein, registration is ke baghair bhi mukammal hoti hai.
        TextField(
          controller: _agentCodeCtrl,
          textCapitalization: TextCapitalization.characters,
          decoration: const InputDecoration(
            labelText:
                'Agent Code (agar kisi agent ne aap ko bheja hai to likhein — lazmi nahi)',
            hintText: 'Masalan: BS12345',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 18),
        const Text('Jaiza — apni maloomat check kar lein',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        _reviewRow('Mobile', _digits(_mobileCtrl.text)),
        _reviewRow('Naam', _nameCtrl.text.trim()),
        _reviewRow('CNIC', _formatCnic(_digits(_cnicCtrl.text))),
        _reviewRow(
            'Gmail',
            _emailCtrl.text.trim().isEmpty
                ? '—'
                : '${_emailCtrl.text.trim()}${_emailVerifiedFor == _emailCtrl.text.trim().toLowerCase() ? ' (OTP verify hai)' : ''}'),
        _reviewRow(
            'Password', p.pwdFp.isNotEmpty || _stagedFp != null ? 'Set hai' : '—'),
        _reviewRow('Gaari',
            '$_vehicle · ${_brandCtrl.text.trim()} ${_modelCtrl.text.trim()}'),
        _reviewRow('Saal / Rang',
            '${_year ?? '—'} · ${_colorCtrl.text.trim()}'),
        _reviewRow('Number plate', _plateCtrl.text.trim()),
        _reviewRow(
            'Licence',
            _licenceSkip
                ? 'Licence nahi hai'
                : (_licenceCtrl.text.trim().isEmpty
                    ? '—'
                    : _licenceCtrl.text.trim())),
        // v1.4.19: naye kagazon ki haalat bhi jaize mein saaf —
        // lagi hai ya baqi (baqi ho to registration NAHI rukti,
        // baad mein Mere Kagaz se lag jayegi)।
        _reviewRow('Fitness Certificate',
            _fitnessPhoto.isNotEmpty ? 'Photo lagi hai' : 'Baqi hai'),
        _reviewRow('Insurance',
            _insurancePhoto.isNotEmpty ? 'Photo lagi hai' : 'Baqi hai'),
        _reviewRow('Character Certificate',
            _characterPhoto.isNotEmpty ? 'Photo lagi hai' : 'Baqi hai'),
        _reviewRow('Zone', _zone),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _thumb('CNIC Samne', _cnicFront),
            _thumb('CNIC Peeche', _cnicBack),
            _thumb('Gaari', _vehiclePhoto),
            _thumb('Kaghaz', _vehicleReg),
            if (!_licenceSkip && _licencePhoto.isNotEmpty)
              _thumb('Licence', _licencePhoto),
            if (_fitnessPhoto.isNotEmpty) _thumb('Fitness', _fitnessPhoto),
            if (_insurancePhoto.isNotEmpty)
              _thumb('Insurance', _insurancePhoto),
            if (_characterPhoto.isNotEmpty)
              _thumb('Character', _characterPhoto),
            _thumb('Selfie', _selfie),
          ],
        ),
        const SizedBox(height: 14),
        const Text(
          'Register karne par ye maloomat Master ke paas chali jayegi. Tasdeeq ke baad account active hoga.',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 16),
        // v1.4.4 LEGAL: Sharait ki qubooliyat — aakhri qadam ki
        // lazmi shart. Qabool karne ka waqt darj ho jata hai aur
        // Master ko backend par saboot ke tor par nazar ata hai.
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Brand.lightBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Brand.fieldBorder),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(Icons.description, size: 19, color: Brand.green),
                  SizedBox(width: 8),
                  Text('Bozdar Safar ki Sharait',
                      style: TextStyle(
                          fontWeight: FontWeight.w900, fontSize: 14.5)),
                ],
              ),
              const SizedBox(height: 4),
              const Text(
                'Driver ki tamam sharait — gaari ke kaghaz, traffic qanoon, hadse ki soorat, 10% service fee aur Amanat Deposit (Rs 500) ki shartein samait — parh lein. Register karne ke liye sharait qabool karna lazmi hai.',
                style: TextStyle(fontSize: 12.5, color: Colors.black54),
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                        builder: (_) =>
                            const TermsPage(showDriverTerms: true)),
                  ),
                  icon: const Icon(Icons.menu_book, size: 17),
                  label: const Text('Sharait Parhein'),
                ),
              ),
              CheckboxListTile(
                value: _termsChecked,
                onChanged: (v) async {
                  setState(() => _termsChecked = v ?? false);
                  if (v == true) {
                    // Qabool karte hi waqt darj (profile + backend).
                    await store.acceptDriverTerms();
                  }
                },
                title: const Text('Mein ne parh liya, qabool hai',
                    style: TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 14)),
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.zero,
                dense: true,
              ),
              // AMANAT DEPOSIT ki alag tasdeeq (v1.4.21): driver
              // ki apni raqam ka muamla hai — is liye aam sharait
              // wale nishan ke ilawa is ki tasdeeq alag satr mein।
              CheckboxListTile(
                value: _amanatChecked,
                onChanged: (v) =>
                    setState(() => _amanatChecked = v ?? false),
                title: const Text(
                    'Amanat Deposit ki shartein mujhe samajh hain: Rs 500 sirf meri apni AMANAT hai, Bozdar Safar ki kamai nahi; is mein se sirf meri rides ki 10% fees kategi; fees ke ilawa meri raqam se ek rupee bhi idhar udhar nahi ho sakta; baqi raqam meri apni hai aur kaam chhorne par mujhe poori wapas milegi.',
                    style: TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 12.5)),
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.zero,
                dense: true,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _reviewRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(label,
                style: const TextStyle(
                    fontWeight: FontWeight.w700, color: Colors.black54)),
          ),
          Expanded(
            child: Text(value.isEmpty ? '—' : value,
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _thumb(String label, String path) {
    final ok = path.isNotEmpty && File(path).existsSync();
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: ok
              ? Image.file(File(path),
                  width: 64, height: 64, fit: BoxFit.cover)
              : Container(
                  width: 64,
                  height: 64,
                  color: Brand.fieldBorder,
                  child: const Icon(Icons.image_not_supported,
                      color: Brand.ajrakRed),
                ),
        ),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(fontSize: 10)),
      ],
    );
  }

  // --- Photo slot (tasveer wali jagah) ------------------------------------------

  Widget _photoSlot({
    required String label,
    required String path,
    required IconData icon,
    required VoidCallback onPick,
    // v1.4.5: is khane ki apni awaaz wali hidayat (assets/guidance)
    // — tap par pehle awaaz bajti hai, phir camera/gallery khulta
    // hai, taaki anparh driver bhi sun kar sahi tasveer lagaye.
    String? guideAsset,
  }) {
    final ok = path.isNotEmpty && File(path).existsSync();
    return InkWell(
      onTap: () {
        if (guideAsset != null) unawaited(GuideAudio.play(guideAsset));
        onPick();
      },
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: ok ? Brand.green : Brand.fieldBorder,
              width: ok ? 1.8 : 1.2),
        ),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: ok
                  ? Image.file(File(path),
                      width: double.infinity, height: 92, fit: BoxFit.cover)
                  : Container(
                      width: double.infinity,
                      height: 92,
                      color: Brand.lightBg,
                      child: Icon(icon, size: 40, color: Brand.green),
                    ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(ok ? Icons.check_circle : Icons.add_a_photo,
                    size: 16,
                    color: ok ? Brand.green : Brand.ajrakRed),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(label,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.w700)),
                ),
              ],
            ),
            Text(ok ? 'Badalne ke liye dabayein' : 'Tasveer lazmi hai',
                style:
                    const TextStyle(fontSize: 10, color: Colors.black54)),
          ],
        ),
      ),
    );
  }
}

/// CNIC ka input formatter: sirf number, kul 13, khud-ba-khud
/// XXXXX-XXXXXXX-X ki shakal (5-7-1) banata hai.
class _CnicInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    var d = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.length > 13) d = d.substring(0, 13);
    final buf = StringBuffer();
    for (var i = 0; i < d.length; i++) {
      if (i == 5 || i == 12) buf.write('-');
      buf.write(d[i]);
    }
    final out = buf.toString();
    return TextEditingValue(
      text: out,
      selection: TextSelection.collapsed(offset: out.length),
    );
  }
}
