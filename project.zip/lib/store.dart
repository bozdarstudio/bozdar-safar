import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Fare rules — INTERNAL only. Per-km rates are never shown to passengers;
/// the passenger only ever sees the TOTAL fare.
class Fares {
  static const Map<String, int> perKm = {
    'Rickshaw': 50,
    'Bike': 40,
    'Car': 120,
  };
  static const Map<String, int> waitingPerMin = {
    'Rickshaw': 5,
    'Bike': 4,
    'Car': 10,
  };
  static const int freeWaitingMinutes = 5;
  static const int joiningDeposit = 500;

  /// Service charges % — SIRF internal hissaab. Ye fee sirf Master app
  /// mein set hoti hai; is app mein ye hamesha ek khamosh const hai —
  /// passenger ko kabhi nazar nahi aati aur is app mein kahin se badli
  /// bhi nahi ja sakti. Driver ke apne wallet hisaab mein katauti
  /// "Service charges (5%)" ke tor par sirf usi ko dikhti hai.
  static const double feePercent = 5.0;

  static int fareFor(String vehicle, double km) =>
      ((perKm[vehicle] ?? 50) * km).round();

  /// Waiting charge: first [freeWaitingMinutes] minutes free, then per-minute.
  static int waitingCharge(String vehicle, int elapsedMinutes) {
    final billable = elapsedMinutes - freeWaitingMinutes;
    if (billable <= 0) return 0;
    return billable * (waitingPerMin[vehicle] ?? 5);
  }

  static int monthlyAmount(String vehicle, double routeKm, int days) =>
      ((perKm[vehicle] ?? 50) * routeKm * days).round();

  static int serviceFee(int farePlusWaiting) =>
      (farePlusWaiting * feePercent / 100).round();
}

const List<String> kVehicles = ['Rickshaw', 'Bike', 'Car'];

/// Is build ka version (pubspec ki versionName se milta julta rakhein).
const String kAppVersion = '1.0.7';

/// Nayi update hamesha isi link se milti hai — release asset ka naam
/// kabhi nahi badalta, sirf us ke andar ki file nayi ho jati hai.
const String kUpdateDownloadUrl =
    'https://github.com/bozdarstudio/bozdar-safar/releases/download/v1.0.0/BozdarSafar-v1.0.0.apk';

/// Percent saaf likhna: 5 -> "5%", 7.5 -> "7.5%", 7.25 -> "7.25%".
String fmtPct(double p) {
  var s = p.toStringAsFixed(2);
  if (s.contains('.')) {
    s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }
  return '$s%';
}

/// "1.0.4" > "1.0.3" type muqabla — har hisa number ke tor par.
bool versionIsNewer(String remote, String local) {
  List<int> parts(String v) =>
      v.split('.').map((e) => int.tryParse(e) ?? 0).toList();
  final r = parts(remote);
  final l = parts(local);
  for (var i = 0; i < 3; i++) {
    final rv = i < r.length ? r[i] : 0;
    final lv = i < l.length ? l[i] : 0;
    if (rv != lv) return rv > lv;
  }
  return false;
}

const List<String> kZones = [
  'Liaquatabad',
  'Saddar',
  'Clifton',
  'Gulshan-e-Iqbal',
  'Nazimabad',
  'Korangi',
  'Malir',
  'Gulistan-e-Johar',
  'North Karachi',
  'Surjani Town',
  'DHA',
  'PECHS',
  'Bahadurabad',
  'Federal B Area',
  'Doosra Ilaqa',
];

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------

class Booking {
  String id;
  String passengerName;
  String passengerPhone;
  String pickupLabel;
  String dropLabel;
  double pickupLat;
  double pickupLng;
  double dropLat;
  double dropLng;
  bool hasDropPin;
  String vehicle;
  double distanceKm;
  int fare; // distance fare only; waiting is separate
  String note;
  String status; // pending | accepted | arrived | completed | cancelled | noshow
  DateTime createdAt;
  DateTime? arrivedAt;
  DateTime? completedAt;
  int waitingMinutes;
  int waitingCharge;
  String driverName;

  Booking({
    required this.id,
    required this.passengerName,
    required this.passengerPhone,
    required this.pickupLabel,
    required this.dropLabel,
    required this.pickupLat,
    required this.pickupLng,
    required this.dropLat,
    required this.dropLng,
    required this.hasDropPin,
    required this.vehicle,
    required this.distanceKm,
    required this.fare,
    required this.note,
    required this.status,
    required this.createdAt,
    this.arrivedAt,
    this.completedAt,
    this.waitingMinutes = 0,
    this.waitingCharge = 0,
    this.driverName = 'Rashid Bozdar',
  });

  int get total => fare + waitingCharge;

  Map<String, dynamic> toJson() => {
        'id': id,
        'passengerName': passengerName,
        'passengerPhone': passengerPhone,
        'pickupLabel': pickupLabel,
        'dropLabel': dropLabel,
        'pickupLat': pickupLat,
        'pickupLng': pickupLng,
        'dropLat': dropLat,
        'dropLng': dropLng,
        'hasDropPin': hasDropPin,
        'vehicle': vehicle,
        'distanceKm': distanceKm,
        'fare': fare,
        'note': note,
        'status': status,
        'createdAt': createdAt.toIso8601String(),
        'arrivedAt': arrivedAt?.toIso8601String(),
        'completedAt': completedAt?.toIso8601String(),
        'waitingMinutes': waitingMinutes,
        'waitingCharge': waitingCharge,
        'driverName': driverName,
      };

  factory Booking.fromJson(Map<String, dynamic> j) => Booking(
        id: j['id'] as String,
        passengerName: j['passengerName'] as String? ?? '',
        passengerPhone: j['passengerPhone'] as String? ?? '',
        pickupLabel: j['pickupLabel'] as String? ?? '',
        dropLabel: j['dropLabel'] as String? ?? '',
        pickupLat: (j['pickupLat'] as num?)?.toDouble() ?? 0,
        pickupLng: (j['pickupLng'] as num?)?.toDouble() ?? 0,
        dropLat: (j['dropLat'] as num?)?.toDouble() ?? 0,
        dropLng: (j['dropLng'] as num?)?.toDouble() ?? 0,
        hasDropPin: j['hasDropPin'] as bool? ?? false,
        vehicle: j['vehicle'] as String? ?? 'Rickshaw',
        distanceKm: (j['distanceKm'] as num?)?.toDouble() ?? 0,
        fare: (j['fare'] as num?)?.toInt() ?? 0,
        note: j['note'] as String? ?? '',
        status: j['status'] as String? ?? 'pending',
        createdAt:
            DateTime.tryParse(j['createdAt'] as String? ?? '') ?? DateTime.now(),
        arrivedAt: DateTime.tryParse(j['arrivedAt'] as String? ?? ''),
        completedAt: DateTime.tryParse(j['completedAt'] as String? ?? ''),
        waitingMinutes: (j['waitingMinutes'] as num?)?.toInt() ?? 0,
        waitingCharge: (j['waitingCharge'] as num?)?.toInt() ?? 0,
        driverName: j['driverName'] as String? ?? 'Rashid Bozdar',
      );
}

class MonthlyPackage {
  String id;
  String passengerName;
  String pickup;
  String drop;
  String vehicle;
  double routeKm;
  int days;
  int monthlyAmount;
  DateTime createdAt;
  String status; // active

  MonthlyPackage({
    required this.id,
    required this.passengerName,
    required this.pickup,
    required this.drop,
    required this.vehicle,
    required this.routeKm,
    required this.days,
    required this.monthlyAmount,
    required this.createdAt,
    this.status = 'active',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'passengerName': passengerName,
        'pickup': pickup,
        'drop': drop,
        'vehicle': vehicle,
        'routeKm': routeKm,
        'days': days,
        'monthlyAmount': monthlyAmount,
        'createdAt': createdAt.toIso8601String(),
        'status': status,
      };

  factory MonthlyPackage.fromJson(Map<String, dynamic> j) => MonthlyPackage(
        id: j['id'] as String,
        passengerName: j['passengerName'] as String? ?? '',
        pickup: j['pickup'] as String? ?? '',
        drop: j['drop'] as String? ?? '',
        vehicle: j['vehicle'] as String? ?? 'Rickshaw',
        routeKm: (j['routeKm'] as num?)?.toDouble() ?? 0,
        days: (j['days'] as num?)?.toInt() ?? 26,
        monthlyAmount: (j['monthlyAmount'] as num?)?.toInt() ?? 0,
        createdAt:
            DateTime.tryParse(j['createdAt'] as String? ?? '') ?? DateTime.now(),
        status: j['status'] as String? ?? 'active',
      );
}

class WalletTxn {
  String id;
  String type; // deposit | fee
  int amount; // deposit: +amount stored positive; fee: fee amount positive
  String method; // Cash | Raast | '' (fee)
  DateTime date;
  String note;

  WalletTxn({
    required this.id,
    required this.type,
    required this.amount,
    required this.method,
    required this.date,
    required this.note,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'amount': amount,
        'method': method,
        'date': date.toIso8601String(),
        'note': note,
      };

  factory WalletTxn.fromJson(Map<String, dynamic> j) => WalletTxn(
        id: j['id'] as String,
        type: j['type'] as String? ?? 'deposit',
        amount: (j['amount'] as num?)?.toInt() ?? 0,
        method: j['method'] as String? ?? '',
        date: DateTime.tryParse(j['date'] as String? ?? '') ?? DateTime.now(),
        note: j['note'] as String? ?? '',
      );
}

class DriverProfile {
  String name = 'Rashid Bozdar';
  String phone = '';
  String vehicle = 'Rickshaw';
  String plate = '';
  String zone = 'Liaquatabad';
  bool online = false;
  String cnicStatus = 'pending'; // verified | pending
  String licenceStatus = 'none'; // has | none  (none = "Licence nahi hai")
  bool licenceVerified = false;
  String vehiclePapers = 'pending'; // verified | pending
  String selfieDate = ''; // yyyy-mm-dd
  String selfiePath = '';
  bool depositDone = false;
  int walletBalance = 0;
  int totalDeposited = 0;

  bool get selfieToday {
    if (selfieDate.isEmpty) return false;
    final now = DateTime.now();
    final today =
        '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    return selfieDate == today;
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'phone': phone,
        'vehicle': vehicle,
        'plate': plate,
        'zone': zone,
        'online': online,
        'cnicStatus': cnicStatus,
        'licenceStatus': licenceStatus,
        'licenceVerified': licenceVerified,
        'vehiclePapers': vehiclePapers,
        'selfieDate': selfieDate,
        'selfiePath': selfiePath,
        'depositDone': depositDone,
        'walletBalance': walletBalance,
        'totalDeposited': totalDeposited,
      };

  void loadJson(Map<String, dynamic> j) {
    name = j['name'] as String? ?? name;
    phone = j['phone'] as String? ?? '';
    vehicle = j['vehicle'] as String? ?? 'Rickshaw';
    plate = j['plate'] as String? ?? '';
    zone = j['zone'] as String? ?? 'Liaquatabad';
    online = j['online'] as bool? ?? false;
    cnicStatus = j['cnicStatus'] as String? ?? 'pending';
    licenceStatus = j['licenceStatus'] as String? ?? 'none';
    licenceVerified = j['licenceVerified'] as bool? ?? false;
    vehiclePapers = j['vehiclePapers'] as String? ?? 'pending';
    selfieDate = j['selfieDate'] as String? ?? '';
    selfiePath = j['selfiePath'] as String? ?? '';
    depositDone = j['depositDone'] as bool? ?? false;
    walletBalance = (j['walletBalance'] as num?)?.toInt() ?? 0;
    totalDeposited = (j['totalDeposited'] as num?)?.toInt() ?? 0;
  }
}

// ---------------------------------------------------------------------------
// Store — one on-device store shared by BOTH sides (same device), exactly like
// the web app: a booking made on the Passenger side appears on the Driver side.
// ---------------------------------------------------------------------------

class AppStore extends ChangeNotifier {
  final DriverProfile profile = DriverProfile();
  List<Booking> bookings = [];
  List<MonthlyPackage> monthlyPackages = [];
  List<WalletTxn> txns = [];
  String savedGhar = '';
  String savedDaftar = '';
  String passengerName = '';
  bool loaded = false;

  /// Update notice: checkForUpdate nayi version dekh le to true;
  /// dismissUpdate sirf is session ke liye banner chhupata hai.
  bool updateAvailable = false;
  bool updateDismissed = false;

  int _seq = 0;
  String newId() =>
      '${DateTime.now().millisecondsSinceEpoch}-${_seq++}';

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final b = prefs.getString('bookings');
    if (b != null) {
      bookings = (jsonDecode(b) as List)
          .map((e) => Booking.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    final m = prefs.getString('monthly');
    if (m != null) {
      monthlyPackages = (jsonDecode(m) as List)
          .map((e) => MonthlyPackage.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    final t = prefs.getString('txns');
    if (t != null) {
      txns = (jsonDecode(t) as List)
          .map((e) => WalletTxn.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    final p = prefs.getString('profile');
    if (p != null) {
      profile.loadJson(jsonDecode(p) as Map<String, dynamic>);
    }
    savedGhar = prefs.getString('place_ghar') ?? '';
    savedDaftar = prefs.getString('place_daftar') ?? '';
    passengerName = prefs.getString('passenger_name') ?? '';
    loaded = true;
    notifyListeners();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        'bookings', jsonEncode(bookings.map((e) => e.toJson()).toList()));
    await prefs.setString('monthly',
        jsonEncode(monthlyPackages.map((e) => e.toJson()).toList()));
    await prefs.setString(
        'txns', jsonEncode(txns.map((e) => e.toJson()).toList()));
    await prefs.setString('profile', jsonEncode(profile.toJson()));
    await prefs.setString('place_ghar', savedGhar);
    await prefs.setString('place_daftar', savedDaftar);
    await prefs.setString('passenger_name', passengerName);
  }

  Future<void> save() async {
    await _persist();
    notifyListeners();
  }

  // --- Update notice ---------------------------------------------------------

  void dismissUpdate() {
    updateDismissed = true;
    notifyListeners();
  }

  /// App shuru hone par EK dafa, khamoshi se: GitHub release mein nayi
  /// version hai to banner ka flag on. Offline/error par bilkul khamosh —
  /// na error dikhta hai, na UI rukti hai.
  Future<void> checkForUpdate() async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = const Duration(seconds: 6);
      final req = await client
          .getUrl(Uri.parse(
              'https://api.github.com/repos/bozdarstudio/bozdar-safar/releases/tags/v1.0.0'))
          .timeout(const Duration(seconds: 6));
      req.headers.set(HttpHeaders.acceptHeader, 'application/vnd.github+json');
      final resp = await req.close().timeout(const Duration(seconds: 6));
      if (resp.statusCode != 200) return;
      final body =
          await resp.transform(utf8.decoder).join().timeout(
                const Duration(seconds: 6),
              );
      String? remote;
      final m = RegExp(r'Version:\s*(\d+\.\d+\.\d+)').firstMatch(body);
      if (m != null) {
        remote = m.group(1);
      } else {
        final j = jsonDecode(body) as Map<String, dynamic>;
        final tag = (j['tag_name'] as String? ?? '').replaceFirst('v', '');
        if (RegExp(r'^\d+\.\d+\.\d+$').hasMatch(tag)) remote = tag;
      }
      if (remote != null && versionIsNewer(remote, kAppVersion)) {
        updateAvailable = true;
        notifyListeners();
      }
    } catch (_) {
      // Khamosh — offline par kuch nahi hota.
    } finally {
      client?.close();
    }
  }

  // --- Passenger actions ----------------------------------------------------

  Future<void> addBooking(Booking b) async {
    bookings.insert(0, b);
    await save();
  }

  Future<void> addMonthly(MonthlyPackage p) async {
    monthlyPackages.insert(0, p);
    await save();
  }

  // --- Driver actions -------------------------------------------------------

  /// Returns null on success, or the Urdu reason the ride cannot be accepted.
  String? acceptBlockReason() {
    if (!profile.depositDone) {
      return 'Pehle Rs ${Fares.joiningDeposit} ka joining deposit darj karein — baghair deposit ride qubool nahi ho sakti.';
    }
    if (!profile.selfieToday) {
      return 'Aaj ki live selfie baqi hai — pehle selfie lein, phir ride qubool karein.';
    }
    return null;
  }

  Future<void> acceptBooking(Booking b) async {
    b.status = 'accepted';
    b.driverName = profile.name;
    await save();
  }

  Future<void> markArrived(Booking b) async {
    b.status = 'arrived';
    b.arrivedAt = DateTime.now();
    await save();
  }

  int liveWaitingMinutes(Booking b) {
    if (b.arrivedAt == null) return 0;
    return DateTime.now().difference(b.arrivedAt!).inMinutes;
  }

  int liveWaitingCharge(Booking b) {
    if (b.arrivedAt == null) return 0;
    return Fares.waitingCharge(b.vehicle, liveWaitingMinutes(b));
  }

  /// Completes the ride. Returns null on success, or the blocking reason.
  /// Wallet NEVER goes negative: if the service fee would take it below
  /// zero the completion is refused and nothing is recorded.
  Future<String?> completeBooking(Booking b) async {
    final mins = liveWaitingMinutes(b);
    final wCharge = Fares.waitingCharge(b.vehicle, mins);
    final fee = Fares.serviceFee(b.fare + wCharge);
    if (profile.walletBalance - fee < 0) {
      return 'Balance khatam — pehle deposit karein';
    }
    b.waitingMinutes = mins;
    b.waitingCharge = wCharge;
    b.status = 'completed';
    b.completedAt = DateTime.now();
    profile.walletBalance -= fee;
    txns.insert(
      0,
      WalletTxn(
        id: newId(),
        type: 'fee',
        amount: fee,
        method: '',
        date: DateTime.now(),
        note:
            'Service charges ${fmtPct(Fares.feePercent)} — ride ${b.pickupLabel} → ${b.dropLabel} (kiraya + waiting)',
      ),
    );
    await save();
    return null;
  }

  /// No-show: allowed once total waiting reaches 10 minutes. Waiting charges
  /// are recorded on the booking.
  Future<String?> markNoShow(Booking b) async {
    final mins = liveWaitingMinutes(b);
    if (mins < 10) {
      return 'No-show ke liye kul 10 minute intezaar lazmi hai — abhi $mins minute hue hain.';
    }
    b.waitingMinutes = mins;
    b.waitingCharge = Fares.waitingCharge(b.vehicle, mins);
    b.status = 'noshow';
    b.completedAt = DateTime.now();
    await save();
    return null;
  }

  Future<void> cancelBooking(Booking b) async {
    b.status = 'cancelled';
    await save();
  }

  Future<void> addDeposit(int amount, String method) async {
    profile.walletBalance += amount;
    profile.totalDeposited += amount;
    if (profile.totalDeposited >= Fares.joiningDeposit) {
      profile.depositDone = true;
    }
    txns.insert(
      0,
      WalletTxn(
        id: newId(),
        type: 'deposit',
        amount: amount,
        method: method,
        date: DateTime.now(),
        note: 'Deposit — $method',
      ),
    );
    await save();
  }

  Future<void> setSelfie(String path) async {
    final now = DateTime.now();
    profile.selfiePath = path;
    profile.selfieDate =
        '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    await save();
  }
}
