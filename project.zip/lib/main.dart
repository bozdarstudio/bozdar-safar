import 'dart:async';
import 'dart:math' as math;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'store.dart';
import 'theme.dart';
import 'backend.dart';
import 'passenger.dart';
import 'driver.dart';

void main() {
  runApp(const BozdarSafarApp());
}

class BozdarSafarApp extends StatefulWidget {
  const BozdarSafarApp({super.key});

  @override
  State<BozdarSafarApp> createState() => _BozdarSafarAppState();
}

class _BozdarSafarAppState extends State<BozdarSafarApp> {
  final AppStore store = AppStore();

  /// Branded intro sirf cold start par EK dafa — ~3.4 second. Ye timer
  /// sirf UI ka hai: backend sync is se peeche background mein chalti
  /// rehti hai, intro use kabhi nahi rokti.
  bool _introDone = false;
  Timer? _introTimer;

  @override
  void initState() {
    super.initState();
    _introTimer = Timer(const Duration(milliseconds: 3400), () {
      if (mounted) setState(() => _introDone = true);
    });
    // Load ke baad ek dafa khamosh update check + backend sync —
    // dono fire-and-forget, intro se bilkul alag.
    store.load().then((_) {
      store.checkForUpdate();
      Backend.start(store);
    });
  }

  @override
  void dispose() {
    _introTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Safar',
      debugShowCheckedModeBanner: false,
      theme: Brand.theme(),
      home: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          final ready = store.loaded && _introDone;
          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 450),
            child: ready
                ? ModeShell(key: const ValueKey('shell'), store: store)
                : const IntroSplash(key: ValueKey('intro')),
          );
        },
      ),
    );
  }
}

/// LIVING racing intro (v1.1.0 — malik ka hukm): still tasveer par
/// plain zoom NAHI — asal hulchul wala scene hai. Full-bleed racing
/// artwork (rickshaw seedha viewer ki taraf bhagti hui) par:
/// (1) MOTION phase 0–2.4s — push-in scale 1.00→1.22 (rickshaw
/// qareeb ati hui), engine ki tez halki vibration, neeche se lagatar
/// behti dhool (CustomPainter) aur kinaron par speed streaks;
/// (2) SETTLE phase 2.4–3.4s — harkat tham jati hai, deep-green
/// overlay (~55%) fade-in hota hai aur gol SAFAR badge darmiyan
/// mein scale/fade-in ho kar ~0.6s thehra rehta hai, phir display
/// khulti hai. Saath intro ki awaaz bhi hai (audioplayers): engine
/// qareeb ata hua aur ~2.4s par brake ki cheekh — file bilkul
/// 3.4s ki hai, animation ke saath mili hui. Kul ~3.4s, sirf cold
/// start par; koi video player nahi.
class IntroSplash extends StatefulWidget {
  const IntroSplash({super.key});

  @override
  State<IntroSplash> createState() => _IntroSplashState();
}

class _IntroSplashState extends State<IntroSplash>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 3400),
  )..forward();

  /// Dhool ke behte zarre + speed streaks — fixed seeds, har dafa
  /// ek jaisa lekin lagatar behta hua scene.
  final List<_FlowDust> _dust = _makeDust();
  final List<_Streak> _streaks = _makeStreaks();

  /// Intro ki awaaz: engine qareeb ata hua, phir brake ki cheekh
  /// (~2.4s par — bilkul settle/brake lamhe ke saath mili hui).
  final AudioPlayer _introPlayer = AudioPlayer();

  @override
  void initState() {
    super.initState();
    unawaited(_playIntroSound());
  }

  /// Awaaz sirf aik dafa, intro ke shuru mein. Koi bhi audio
  /// khata (file/codec/device) khamoshi se nazar-andaz — awaaz
  /// app ke khulne ko KABHI nahi rok sakti.
  Future<void> _playIntroSound() async {
    try {
      await _introPlayer.play(
        AssetSource('intro-sound.mp3'),
        volume: 0.8,
      );
    } catch (_) {
      // Khamoshi — intro baghair awaaz ke bhi waisa hi chalega.
    }
  }

  static List<_FlowDust> _makeDust() {
    final rnd = math.Random(4242);
    const shades = [Color(0xFFD9C29A), Color(0xFFC8AE7E), Color(0xFFE6D5AC)];
    return List.generate(26, (i) {
      return _FlowDust(
        phase: rnd.nextDouble(),
        dir: i.isEven ? 1 : -1,
        xSpread: rnd.nextDouble(),
        yStart: rnd.nextDouble(),
        size: 0.55 + 0.95 * rnd.nextDouble(),
        alpha: 0.13 + 0.11 * rnd.nextDouble(),
        color: shades[i % shades.length],
      );
    });
  }

  static List<_Streak> _makeStreaks() {
    final rnd = math.Random(99);
    return List.generate(10, (i) {
      return _Streak(
        left: i.isEven,
        inset: 5 + 22 * rnd.nextDouble(),
        yPhase: rnd.nextDouble(),
        speed: 0.9 + 0.8 * rnd.nextDouble(),
        length: 42 + 68 * rnd.nextDouble(),
        thickness: 1.6 + 1.4 * rnd.nextDouble(),
        alpha: 0.10 + 0.10 * rnd.nextDouble(),
        gold: i % 3 == 0,
      );
    });
  }

  double _clamp01(double v) => v.clamp(0.0, 1.0);

  @override
  void dispose() {
    unawaited(_introPlayer.dispose());
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Brand.deepGreen,
      body: AnimatedBuilder(
        animation: _ctrl,
        builder: (context, _) {
          final s = _ctrl.value * 3.4; // seconds, 0..3.4

          // MOTION: push-in 1.00 -> 1.22 (0–2.4s), phir wahin ruka.
          final push = 1.0 +
              0.22 * Curves.easeInOut.transform(_clamp01(s / 2.4));
          // Engine vibration: tez halki vertical bounce, shuru mein
          // ramp-in, settle (2.4–2.9s) mein aahista khatm.
          var vibAmp = 2.5 * _clamp01(s / 0.3);
          if (s >= 2.4) vibAmp *= 1 - _clamp01((s - 2.4) / 0.5);
          final vibDy = math.sin(s * 55) * vibAmp;

          // SETTLE: green overlay 2.4–2.9s mein ~55% tak fade-in.
          final overlay = 0.55 *
              Curves.easeInOut.transform(_clamp01((s - 2.4) / 0.5));
          // Badge: 2.45s se fade + scale-in (easeOutBack ki halki
          // pop ke saath), ~2.9s par mukammal, phir hold.
          final badgeP = _clamp01((s - 2.45) / 0.45);
          final badgeOpacity = _clamp01((s - 2.45) / 0.35);
          final badgeScale =
              0.7 + 0.3 * Curves.easeOutBack.transform(badgeP);

          return Stack(
            fit: StackFit.expand,
            children: [
              // Full-bleed racing artwork — push-in + vibration.
              Transform.translate(
                offset: Offset(0, vibDy),
                child: Transform.scale(
                  scale: push,
                  child: Image.asset(
                    'assets/safar-intro-racing.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              // Behti dhool + speed streaks (motion layer).
              CustomPaint(
                size: Size.infinite,
                painter: _MotionPainter(
                  seconds: s,
                  dust: _dust,
                  streaks: _streaks,
                ),
              ),
              // Settle overlay — deep green ~55%.
              Opacity(
                opacity: overlay,
                child: const ColoredBox(color: Brand.deepGreen),
              ),
              // Gol SAFAR badge — settle par darmiyan mein.
              Center(
                child: Opacity(
                  opacity: badgeOpacity,
                  child: Transform.scale(
                    scale: badgeScale,
                    child: Image.asset(
                      'assets/safar-logo-new.png',
                      width: 200,
                      height: 200,
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// Ek behte dhool-zarre ki pehchan (sab kuch pehle se fixed; waqt
/// ke saath is ki position cycle mein chalti hai).
class _FlowDust {
  const _FlowDust({
    required this.phase,
    required this.dir,
    required this.xSpread,
    required this.yStart,
    required this.size,
    required this.alpha,
    required this.color,
  });
  final double phase;
  final double dir; // -1 bayein, +1 dayein ki taraf behta hai
  final double xSpread;
  final double yStart;
  final double size;
  final double alpha;
  final Color color;
}

/// Kinare par peeche ki taraf daudti ek speed line.
class _Streak {
  const _Streak({
    required this.left,
    required this.inset,
    required this.yPhase,
    required this.speed,
    required this.length,
    required this.thickness,
    required this.alpha,
    required this.gold,
  });
  final bool left;
  final double inset;
  final double yPhase;
  final double speed; // cycles per second
  final double length;
  final double thickness;
  final double alpha;
  final bool gold;
}

/// Motion layer ka painter: (1) neeche-darmiyan se lagatar behti
/// dhool — har zarra apne cycle mein bahar/neeche ki taraf behta,
/// barhta aur ghayab hota hai; (2) left/right kinaron par neeche
/// ki taraf sweep karti speed streaks. Dono motion phase mein
/// ghane, settle (2.4s ke baad) mein aahista ghayab.
class _MotionPainter extends CustomPainter {
  _MotionPainter({
    required this.seconds,
    required this.dust,
    required this.streaks,
  });

  final double seconds;
  final List<_FlowDust> dust;
  final List<_Streak> streaks;

  /// Motion ki shiddat: pehle 0.3s ramp-in, 2.4s tak full, phir
  /// 3.1s tak pura ghayab.
  double get _intensity {
    final s = seconds;
    if (s <= 0) return 0;
    if (s < 2.4) return (s / 0.3).clamp(0.0, 1.0);
    if (s < 3.1) return 1 - Curves.easeInOut.transform((s - 2.4) / 0.7);
    return 0;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final inten = _intensity;
    if (inten <= 0) return;
    final w = size.width;
    final h = size.height;
    final paint = Paint()..style = PaintingStyle.fill;

    // --- Dhool: bottom-center se bahar/neeche behti hui ---
    for (final d in dust) {
      final u = (seconds / 1.15 + d.phase) % 1.0; // cycle ~1.15s
      final x = w / 2 +
          d.dir * (0.03 + 0.36 * u) * w * (0.35 + 0.65 * d.xSpread);
      final y = h * (0.66 + 0.10 * d.yStart) + u * 0.26 * h;
      final radius = (6 + 22 * u) * d.size;
      final a = (d.alpha * inten * math.sin(math.pi * u)).clamp(0.0, 1.0);
      if (a <= 0.003) continue;
      paint.color = d.color.withOpacity(a);
      canvas.drawCircle(Offset(x, y), radius, paint);
    }

    // --- Speed streaks: kinaron par neeche sweep ---
    final linePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    for (final st in streaks) {
      final v = (st.yPhase + seconds * st.speed) % 1.0;
      final y = v * (h + st.length) - st.length / 2;
      final x = st.left ? st.inset : w - st.inset;
      final lean = st.left ? -5.0 : 5.0;
      final a = (st.alpha * inten).clamp(0.0, 1.0);
      linePaint
        ..strokeWidth = st.thickness
        ..color = (st.gold ? const Color(0xFFF2C94C) : Colors.white)
            .withOpacity(a);
      canvas.drawLine(
        Offset(x, y),
        Offset(x + lean, y + st.length),
        linePaint,
      );
    }
  }

  @override
  bool shouldRepaint(_MotionPainter oldDelegate) =>
      oldDelegate.seconds != seconds;
}

/// ONE app, TWO fully separated sides. One tap replaces the whole
/// display; the other side never renders. Mode badalne ka SIRF EK
/// tareeqa hai (v1.0.8 — malik ka hukm): har side ke BrandHeader ke
/// foran neeche ek hi wazeh toggle button [ModeToggleButton], jis par
/// us mode ka naam likha hota hai jis mein jana hai ("Driver Mode" /
/// "Passenger Mode"). Kyunke ek waqt mein sirf ek side render hoti
/// hai, screen par hamesha ek hi mode button hota hai. Pehli dafa app
/// Passenger mode mein khulti hai.
class ModeShell extends StatefulWidget {
  final AppStore store;
  const ModeShell({super.key, required this.store});

  @override
  State<ModeShell> createState() => _ModeShellState();
}

class _ModeShellState extends State<ModeShell> {
  bool driverMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Brand.deepGreen,
      body: SafeArea(
        bottom: false,
        child: driverMode
            ? DriverSide(
                store: widget.store,
                onSwitchToPassenger: () {
                  setState(() => driverMode = false);
                  // Backend `devices` entry mein akhri mode taza.
                  unawaited(Backend.touchDevice(widget.store, 'passenger'));
                },
              )
            : PassengerSide(
                store: widget.store,
                onSwitchToDriver: () {
                  setState(() => driverMode = true);
                  unawaited(Backend.touchDevice(widget.store, 'driver'));
                },
              ),
      ),
    );
  }
}

/// THE single mode toggle (v1.0.8 — malik ka hukm: mode badalne ka
/// sirf yehi ek button hoga). Har side ke BrandHeader ke foran neeche
/// wazeh tor par lagta hai. Is par us mode ka naam likha hota hai jis
/// mein ye le jayega: Passenger mode mein "Driver Mode" (gaari/driver
/// icon ke saath), Driver mode mein "Passenger Mode" (sawari icon ke
/// saath). Ek tap = side badal gayi.
class ModeToggleButton extends StatelessWidget {
  final bool toDriver;
  final VoidCallback onTap;
  const ModeToggleButton(
      {super.key, required this.toDriver, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(
            toDriver
                ? Icons.drive_eta
                : Icons.airline_seat_recline_normal,
            size: 22),
        label: Text(toDriver ? 'Driver Mode' : 'Passenger Mode'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Brand.gold,
          foregroundColor: Brand.greenDark,
          padding: const EdgeInsets.symmetric(vertical: 13),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
        ),
      ),
    );
  }
}

/// Nayi update ka slim gold banner — dono sides ke home ke upar dikhta
/// hai. "Update karein" download link kholta hai; × dabane se sirf is
/// session ke liye chhup jata hai.
class UpdateBanner extends StatelessWidget {
  final AppStore store;
  const UpdateBanner({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: Brand.gold,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(
        children: [
          const Icon(Icons.system_update, size: 18, color: Brand.greenDark),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              'Safar ki nayi update aa gayi hai',
              style: TextStyle(
                  color: Brand.greenDark,
                  fontSize: 13,
                  fontWeight: FontWeight.w800),
            ),
          ),
          TextButton(
            onPressed: () => launchUrl(
              Uri.parse(kUpdateDownloadUrl),
              mode: LaunchMode.externalApplication,
            ),
            style: TextButton.styleFrom(
              backgroundColor: Brand.greenDark,
              foregroundColor: Brand.cream,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              minimumSize: Size.zero,
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: const Text('Update karein',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(width: 4),
          IconButton(
            onPressed: store.dismissUpdate,
            icon: const Icon(Icons.close, size: 18, color: Brand.greenDark),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
            tooltip: 'Band karein',
          ),
        ],
      ),
    );
  }
}
