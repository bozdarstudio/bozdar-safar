package com.bozdar.whitefilter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.view.View

/**
 * Full-screen view that draws the latest person mask.
 *
 * The mask bitmap already contains pure white pixels where a person is and
 * transparent pixels everywhere else, so drawing it stretched to the full
 * view size paints white over people and leaves everything else untouched.
 * The window hosting this view is FLAG_NOT_TOUCHABLE, so touches pass
 * straight through to the app/game/video underneath.
 *
 * All bitmap swaps and recycles happen on the UI thread (same thread as
 * onDraw), so a bitmap is never recycled while it is being drawn.
 */
class OverlayView(context: Context) : View(context) {

    private var maskBitmap: Bitmap? = null

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dstRect = Rect()

    /** May be called from any thread; the swap itself runs on the UI thread. */
    fun updateMask(bitmap: Bitmap) {
        post {
            val old = maskBitmap
            maskBitmap = bitmap
            if (old != null && old !== bitmap && !old.isRecycled) {
                old.recycle()
            }
            invalidate()
        }
    }

    fun clearMask() {
        post {
            val old = maskBitmap
            maskBitmap = null
            if (old != null && !old.isRecycled) {
                old.recycle()
            }
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = maskBitmap ?: return
        if (bmp.isRecycled) return
        val w = width
        val h = height
        if (w == 0 || h == 0) return
        dstRect.set(0, 0, w, h)
        canvas.drawBitmap(bmp, null, dstRect, paint)
    }
}
