import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart' as ll;
import 'package:maplibre_gl/maplibre_gl.dart' as ml;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'day_style.dart';
import 'display_prefs.dart';
import 'lang.dart';
import 'night_style.dart';
import 'route_service.dart';
import 'store.dart';
import 'theme.dart';
import 'booking_flow.dart' show kOsmAttribution;

/// Muft OpenFreeMap "Liberty" style — vector tiles, bina API key.
/// (v1.4.29 se default streets style CARTO Voyager hai — neeche
/// dekhein; Liberty sirf reference ke tor par rakha hai.)
const String kLibertyStyleUrl = 'https://tiles.openfreemap.org/styles/liberty';

/// v1.4.29 MAP SAAF (malik ka hukm 2026-11-11): purana Liberty
/// style feeka tha — galiyan aur naam saaf nazar nahi ate thay.
/// Ab default streets style CARTO Voyager hai: roshan, wazeh,
/// Google-jaisi saaf galiyan/naam, vector tiles, bina API key.
/// Data OpenStreetMap ka hi hai; attribution badge mein
/// © OpenStreetMap contributors © CARTO dono lazmi hain
/// (booking_flow.dart ka kOsmAttribution).
const String kStreetsStyleUrl =
    'https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json';

/// v1.4.30 RAAT wala map style — CARTO Dark Matter: wohi
/// OpenStreetMap data, gehre rangon mein (galiyan/naam saaf
/// rehte hain). DisplayPrefs ki Night pasand par map khud
/// is par ajata hai; Day par Voyager, Auto par phone ki
/// brightness ke mutabiq (DisplayPrefs.isDarkNow)।
const String kNightStyleUrl =
    'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json';

/// v1.4.32 GEHRA-SAAF RAAT MAP (malik ka hukm 2026-11-11
/// raat — Yango-sample jaisa): Dark Matter ka apna banaya
/// hua roop [kNightStyleJson] (night_style.dart) — gehra
/// neela pas-manzar (#0a1128), MOTI aur ROSHAN sadkein
/// (bari sadkein safed/sunehri), SAFED baray gali-naam
/// gehre halo ke saath. URL wala style feeka parhta tha —
/// is liye ab inline JSON hai; URL sirf reference ke liye
/// rakha hai।

/// Satellite hybrid style — Esri World Imagery (muft, bina key) + upar
/// jagah/road ke labels wali reference layers. Sirf ONLINE chalta hai;
/// offline mein streets style hi kaam aata hai (uska region cache hai).
const String kSatelliteStyleJson = '''
{
  "version": 8,
  "name": "Safar Satellite",
  "sources": {
    "esri-imagery": {
      "type": "raster",
      "tiles": ["https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"],
      "tileSize": 256,
      "attribution": "Esri World Imagery"
    },
    "esri-roads": {
      "type": "raster",
      "tiles": ["https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}"],
      "tileSize": 256
    },
    "esri-labels": {
      "type": "raster",
      "tiles": ["https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}"],
      "tileSize": 256
    }
  },
  "layers": [
    {"id": "imagery", "type": "raster", "source": "esri-imagery"},
    {"id": "roads-ref", "type": "raster", "source": "esri-roads"},
    {"id": "labels-ref", "type": "raster", "source": "esri-labels"}
  ]
}
''';

/// Pakistan ke shehron (zones) ke markazi coordinates — store.dart ke
/// kZones se match. 'Doosra Sheher' ka pin Karachi par hai (fallback).
const Map<String, ll.LatLng> kZoneCoords = {
  'Karachi': ll.LatLng(24.8608, 67.0011),
  'Hyderabad': ll.LatLng(25.3960, 68.3578),
  'Sukkur': ll.LatLng(27.7132, 68.8482),
  'Larkana': ll.LatLng(27.5569, 68.2100),
  'Nawabshah': ll.LatLng(26.2442, 68.4100),
  'Mirpurkhas': ll.LatLng(25.5276, 69.0159),
  'Lahore': ll.LatLng(31.5497, 74.3436),
  'Faisalabad': ll.LatLng(31.4504, 73.1350),
  'Rawalpindi': ll.LatLng(33.5651, 73.0169),
  'Islamabad': ll.LatLng(33.7294, 73.0931),
  'Multan': ll.LatLng(30.1575, 71.5249),
  'Gujranwala': ll.LatLng(32.1877, 74.1945),
  'Sialkot': ll.LatLng(32.4945, 74.5229),
  'Bahawalpur': ll.LatLng(29.4000, 71.6833),
  'Sargodha': ll.LatLng(32.0836, 72.6711),
  'Peshawar': ll.LatLng(34.0151, 71.5249),
  'Mardan': ll.LatLng(34.1989, 72.0404),
  'Abbottabad': ll.LatLng(34.1688, 73.2215),
  'Quetta': ll.LatLng(30.1798, 66.9750),
  'Gwadar': ll.LatLng(25.1216, 62.3254),
  'Doosra Sheher': ll.LatLng(24.8608, 67.0011),
};

ml.LatLng _m(ll.LatLng p) => ml.LatLng(p.latitude, p.longitude);

ll.LatLng _l(ml.LatLng p) => ll.LatLng(p.latitude, p.longitude);

/// Do points ke darmiyan simt (degrees, 0 = shumaal) — GPS heading na
/// mile to lagatar positions se teer ki simt nikalne ke liye (v1.4.9).
double safarBearingBetween(ll.LatLng a, ll.LatLng b) {
  final lat1 = a.latitude * math.pi / 180;
  final lat2 = b.latitude * math.pi / 180;
  final dLng = (b.longitude - a.longitude) * math.pi / 180;
  final y = math.sin(dLng) * math.cos(lat2);
  final x = math.cos(lat1) * math.sin(lat2) -
      math.sin(lat1) * math.cos(lat2) * math.cos(dLng);
  return (math.atan2(y, x) * 180 / math.pi + 360) % 360;
}

/// Do simton ke darmiyan sab se CHHOTA signed farq (degrees,
/// -180..180] — teer ki rotation ko hamesha chhote raste se
/// ghumane ke liye (v1.4.11).
double safarAngleDelta(double from, double to) {
  var d = (to - from) % 360;
  if (d > 180) d -= 360;
  if (d < -180) d += 360;
  return d;
}

/// Simt ko [from] se [to] ki taraf [t] hissa (0..1) naram andaz
/// mein ghumana — shortest arc par, kabhi jhatke se snap nahi
/// (v1.4.11: teer gali ki simt par aahista aahista jamta hai).
double safarLerpBearing(double from, double to, double t) =>
    (from + safarAngleDelta(from, to) * t) % 360;

/// Offline region: poore Pakistan ka COUNTRY-OVERVIEW vector map
/// pehli dafa khulne par khamoshi se download ho jata hai (sirf
/// zoom 5–9 — mulk ka majmooi naksha; poore mulk ki gali-level
/// offline copy mumkin nahi aur koshish bhi nahi ki jati). Is ke
/// baad kamzor ya band net par bhi mulk ka overview map chalta hai.
/// Sheher ki gali-level tafseel online milti hai; MapLibre ka apna
/// ambient cache dekhe hue hisse bhi offline mehfooz rakhta hai.
class OfflineMaps {
  static bool _started = false;

  static Future<void> ensurePakistan() async {
    if (_started) return;
    _started = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool('ofm_pakistan_v1') == true) return;
      final regions = await ml.getListOfRegions();
      final exists =
          regions.any((r) => r.metadata['name'] == 'safar-pakistan');
      if (!exists) {
        await ml.downloadOfflineRegion(
          ml.OfflineRegionDefinition(
            bounds: ml.LatLngBounds(
              southwest: const ml.LatLng(23.50, 60.90),
              northeast: const ml.LatLng(37.10, 77.90),
            ),
            mapStyleUrl: kStreetsStyleUrl,
            minZoom: 5,
            maxZoom: 9,
          ),
          metadata: const {'name': 'safar-pakistan'},
        );
      }
      await prefs.setBool('ofm_pakistan_v1', true);
    } catch (_) {
      // Best effort — fail ho to agli dafa phir koshish hogi; map online
      // bhi chalta rehta hai aur ambient cache kaam karta hai.
      _started = false;
    }
  }

  /// Purana naam — jo jagah ensureKarachi bulati thi wohi amal ab
  /// Pakistan region par hota hai.
  static Future<void> ensureKarachi() => ensurePakistan();

  /// MAP WAVE (v1.4.20): offline Pakistan region ki TAZA copy —
  /// purana region delete karke wohi hadood/zoom par dobara
  /// download. MapDataRefresh apne 24 ghante wale chakkar se
  /// bulata hai, taaki offline wala naksha bhi purana na rahe
  /// (band/khuli sadkon ki OSM tabdeeliyan is mein bhi ayen).
  /// v1.4.27 (audit N3): jawab ab bool hai — true sirf ASAL
  /// kamyab refresh par; pehle nakami andar nigal li jati thi
  /// aur bulane wala (MapDataRefresh) nakami ko bhi kamyabi
  /// samajh kar apna timestamp aage badha deta tha.
  static Future<bool> refreshPakistanRegion() async {
    try {
      final regions = await ml.getListOfRegions();
      for (final r in regions) {
        if (r.metadata['name'] == 'safar-pakistan') {
          await ml.deleteOfflineRegion(r.id);
        }
      }
      await ml.downloadOfflineRegion(
        ml.OfflineRegionDefinition(
          bounds: ml.LatLngBounds(
            southwest: const ml.LatLng(23.50, 60.90),
            northeast: const ml.LatLng(37.10, 77.90),
          ),
          mapStyleUrl: kStreetsStyleUrl,
          minZoom: 5,
          maxZoom: 9,
        ),
        metadata: const {'name': 'safar-pakistan'},
      );
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('ofm_pakistan_v1', true);
      return true;
    } catch (_) {
      // Best effort: delete ho jaye aur download fail ho to
      // flag gira dein — agli app run par ensurePakistan region
      // khud dobara bana degi. Map is wajah se rukta nahi.
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool('ofm_pakistan_v1', false);
      } catch (_) {}
      return false;
    }
  }
}

/// MAP DATA AUTO-REFRESH (v1.4.20, malik ka hukm 2026-11-10
/// 19:29–19:31): map data har ~24 GHANTE khud tazah ho, taake
/// band/khuli sadkon ki asal tabdeeliyan app mein nazar ayen.
/// Asal mechanism do hisso par hai (koi jaali button nahi):
///  1) AMBIENT CACHE INVALIDATE — MapLibre ka apna asal API
///     (MapLibreMapController.invalidateAmbientCache): online
///     browsing mein cache hui tiles/style/resources "expired"
///     ho jati hain, is liye agli dafa istemal par woh server
///     (OpenFreeMap/OSM) se TAZA utarti hain. Downloaded offline
///     region ambient cache ka hissa NAHI hota — woh is se
///     muta'asir nahi hota, is liye dusra hissa alag hai:
///  2) OFFLINE REGION REFRESH — Pakistan overview region delete
///     karke dobara download (OfflineMaps.refreshPakistanRegion),
///     taaki offline copy bhi 24 ghante se purani na rahe.
/// Aakhri refresh ka waqt SharedPreferences ke
/// 'last_map_refresh_ms' mein mehfooz rehta hai. Check har app
/// run mein sirf EK dafa hota hai — pehle map controller ke
/// bante hi (SafarMapView.onMapCreated se). Net na ho ya koi
/// qadam fail ho to map purane data par chalta rehta hai aur
/// agli run par dobara koshish hoti hai.
class MapDataRefresh {
  static const String prefKey = 'last_map_refresh_ms';
  static const int intervalMs = 24 * 60 * 60 * 1000; // ~24 ghante
  static bool _checkedThisRun = false;

  static Future<void> maybeRefresh(ml.MapLibreMapController c) async {
    if (_checkedThisRun) return;
    _checkedThisRun = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final last = prefs.getInt(prefKey) ?? 0;
      final now = DateTime.now().millisecondsSinceEpoch;
      if (last > 0 && now - last < intervalMs) return;
      await c.invalidateAmbientCache();
      // v1.4.27 (audit N3): timestamp SIRF asal kamyab refresh
      // par aage badhe — region refresh fail ho to waqt wohi
      // purana rahe taaki agli run par dobara koshish ho
      // (pehle nakami par bhi timestamp aage barh jata tha aur
      // naksha 24 ghante tak purana hi rehta tha)।
      final regionOk = await OfflineMaps.refreshPakistanRegion();
      if (!regionOk) {
        _checkedThisRun = false;
        return;
      }
      await prefs.setInt(
          prefKey, DateTime.now().millisecondsSinceEpoch);
    } catch (_) {
      // Is run mein dobara koshish ki ijazat — agli map screen
      // par phir check hoga.
      _checkedThisRun = false;
    }
  }
}

/// Sab jagah istemal hone wala asal LIVE map (MapLibre GL):
/// - Jhuka hua (tilt) 3D-style view, asal vector galiyan
/// - Streets (CARTO Voyager, v1.4.29 se) / Satellite hybrid toggle
/// - Pickup par kaala "A" pin, manzil par kaala "B" pin (v1.4.29;
///   v1.4.42 mein pin thode baray), route line moti GEHRI NEELI
///   safed casing ke saath (v1.4.42 — pehle hari thi)
/// - Zone pins (chhote sunehre nuqtay), driver ki position ka nav-arrow:
///   ONLINE (duty par) = hara, OFFLINE = kala-safaid (v1.4.9, malik ki
///   farmaish; v1.4.11 mein chhota — galiyan nahi dhakta)
class SafarMapView extends StatefulWidget {
  final ll.LatLng center;
  final double initialZoom;
  final double tilt;
  final ll.LatLng? pickup;
  final ll.LatLng? drop;
  final List<ll.LatLng>? routePoints;
  final List<ll.LatLng>? zonePoints;
  final ll.LatLng? position;
  final double positionBearing;

  /// Follow camera ki simt (v1.4.11): sirf DRIVER ke nav view se
  /// di jati hai — woh bhi gated (challti haalat mein hi badalti
  /// hai, rukne par aakhri simt par thehri rehti hai). Na di jaye
  /// to follow camera hamesha NORTH-UP (0) rehta hai — passenger
  /// ki tamam screens isi par hain. v1.4.33: user ne do ungliyon
  /// se ghumaya ho to _manualBearing is par bhaari hai (compass
  /// reset tak) — follow phir bhi jagah taza karta rehta hai.
  final double? cameraBearing;

  /// Position wala teer kis haalat mein hai: true = ONLINE (hara teer),
  /// false = OFFLINE (kala-safaid teer). Driver mode mein duty ki
  /// haalat, passenger mode mein assign driver ki haalat (v1.4.9).
  final bool positionOnline;

  /// v1.4.32 PHOTO-PIN: doosre fareeq ki photo wala gol pin —
  /// [photoPinAt] jagah par dikhta hai, [photoPinPng] PhotoPin
  /// se bana hua tayyar PNG hai. Dono hon tab hi pin banta hai;
  /// warna map bilkul pehle jaisa (pin sirf izafa hai)।
  final ll.LatLng? photoPinAt;
  final Uint8List? photoPinPng;

  /// v1.4.42 LIVE APNI JAGAH (M4 — owner hukm 2026-11-13):
  /// device ki APNI taaza GPS position; caller (page) apne
  /// geolocator stream se deta hai. Map isay alag pehchan —
  /// halo wale neele nuqte — se dikhata hai (A/B pins aur
  /// doosre fareeq ke teer se mukhtalif)। Na di jaye to map
  /// bilkul pehle jaisa।
  final ll.LatLng? myPosition;

  /// v1.4.42 FOLLOW (M4): true ho to banda maujooda camera
  /// center se ~500 m se zyada hat jaye to map KHUD us par
  /// wapas center hota hai — har GPS tick par jump NAHI,
  /// sirf badi harkat par। User haath se pan kare to follow
  /// ruk jata hai; focusSeq wala saaf re-center (page ka
  /// "Meri Location" button) use dobara chala deta hai।
  final bool followMyPosition;
  final bool followPosition;

  /// Follow camera ka zoom — null ho to purana default
  /// (16.5)। v1.4.42 (H2 — owner hukm 2026-11-13 02:33):
  /// DriverNavView gali-level zoom (19.0, mor ke qareeb
  /// 19.5) yahin se deta hai taake driver ko galiyan aur
  /// chhoti sadkein BARI saaf nazar ayen; baqi follow
  /// istemal default par hi rehte hain (passenger ka
  /// overview fit pehle jaisa)।
  final double? followZoom;

  /// v1.4.42 FOLLOW (owner hukm 2026-11-13 02:57 — Uber
  /// navigation wala follow andaaz, apni shakal mein):
  /// follow camera ka nishana asal jagah se itne meter
  /// AAGE (heading ki taraf) rakha jata hai — gaari/teer
  /// screen ke markaz se neeche rehta hai aur AAGE ka
  /// rasta zyada nazar ata hai, peeche kam। 0 = offset
  /// nahi (purana markaz wala follow)।
  final double followForwardOffsetM;

  /// User ne follow ke doran map ko haath se hila diya
  /// (pan ki pehchan lag gayi) to ye callback chalta hai —
  /// caller (DriverNavView) apni Follow haalat OFF kar
  /// deta hai; us ke recenter/Follow button se follow
  /// dobara lock hota hai।
  final VoidCallback? onFollowPaused;
  final bool interactive;
  final bool fitToRoute;
  final ll.LatLng? focusPoint;
  final int focusSeq;
  final bool externalStyleControl;
  final bool satellite;
  final ValueChanged<bool>? onSatelliteChanged;
  final void Function(ll.LatLng)? onTapPoint;
  final void Function(ll.LatLng)? onLongPressPoint;
  final void Function(ll.LatLng)? onCameraTarget;
  final VoidCallback? onCameraIdle;

  const SafarMapView({
    super.key,
    required this.center,
    this.initialZoom = 13,
    this.tilt = 50,
    this.pickup,
    this.drop,
    this.routePoints,
    this.zonePoints,
    this.position,
    this.positionBearing = 0,
    this.cameraBearing,
    this.positionOnline = true,
    this.photoPinAt,
    this.photoPinPng,
    this.myPosition,
    this.followMyPosition = false,
    this.followPosition = false,
    this.followZoom,
    this.followForwardOffsetM = 0,
    this.onFollowPaused,
    this.interactive = true,
    this.fitToRoute = false,
    this.focusPoint,
    this.focusSeq = 0,
    this.externalStyleControl = false,
    this.satellite = false,
    this.onSatelliteChanged,
    this.onTapPoint,
    this.onLongPressPoint,
    this.onCameraTarget,
    this.onCameraIdle,
  });

  @override
  State<SafarMapView> createState() => _SafarMapViewState();
}

class _SafarMapViewState extends State<SafarMapView> {
  ml.MapLibreMapController? _c;
  bool _styleReady = false;

  /// v1.4.32: photo-pin ki tasveer is style mein register ho
  /// chuki hai ya nahi (har nayi style par dobara register
  /// hoti hai; PNG baad mein aye to didUpdateWidget se)।
  bool _photoImgReady = false;
  bool _satelliteInternal = false;
  String _routeSig = '';
  ll.LatLng? _lastFollowed;

  /// v1.4.42 (M4): apni-jagah follow ki haalat — user ke
  /// haath ke pan par true (follow ruka hua); page ka saaf
  /// re-center (focusSeq) ane par false (follow dobara)।
  bool _followPaused = false;

  /// v1.4.42 FOLLOW: position-follow (driver nav) ki
  /// haalat — user ke haath ke pan par true; caller ke
  /// follow dobara ON karne (followPosition false→true)
  /// par saaf hota hai aur camera foran lock ho jata hai।
  bool _followPosPaused = false;

  /// Aakhri dafa CODE ne camera kab ghumaya — onControllerNotify
  /// mein is se farq hota hai ke camera ki harkat code ki hai
  /// ya user ke haath ki (pan ki pehchan isi par hai)।
  DateTime? _lastCodeMoveAt;
  ll.LatLng? _lastCamTarget;

  /// v1.4.33 (owner hukm 2026-11-12 00:35): user ne do ungliyon se
  /// map khud ghumaya ho to us ki disha yahan mehfooz rehti hai —
  /// follow/recenter usay wapas seedha (0) NAHI karta; compass
  /// dabane par (bearing ~0) ye saaf ho jata hai aur heading-up /
  /// north-up wapas aa jata hai.
  double? _manualBearing;

  /// Aakhri dafa code ne camera ko kis bearing par bheja tha —
  /// onCameraIdle par isi se pehchan hoti hai ke ghumao user ka
  /// tha ya code ka.
  double _lastCommandedBearing = 0;

  /// Camera ke liye disha: pehle user ki ghumai hui (manual),
  /// phir caller ki heading (driver nav), warna north-up (0).
  double _bearingForCamera() =>
      _manualBearing ?? widget.cameraBearing ?? 0;

  /// Camera animation ka ek hi rasta (disha wali jagah par):
  /// commanded bearing note kar lo taake onCameraIdle par user
  /// ki ghumai hui disha pehchani ja sake.
  void _animateCamera(ml.CameraPosition pos) {
    _lastCommandedBearing = pos.bearing;
    _lastCodeMoveAt = DateTime.now();
    final c = _c;
    if (c != null) {
      _guard(c.animateCamera(ml.CameraUpdate.newCameraPosition(pos)));
    }
  }

  /// Camera rukne par: agar disha aakhri commanded disha se 3°
  /// se zyada hat kar hai to ye user ki manual ghumai hai —
  /// mehfooz kar lo. Disha ~0 ho to manual saaf (compass reset).
  void _onCameraIdleInternal() {
    final b = _c?.cameraPosition?.bearing;
    if (b != null) {
      var d = (b - _lastCommandedBearing) % 360;
      if (d > 180) d -= 360;
      if (d < -180) d += 360;
      if (d.abs() > 3) {
        // ~0 (ya ~360) = compass se seedha — manual saaf.
        _manualBearing = (b < 2 || b > 358) ? null : b;
      }
    }
    widget.onCameraIdle?.call();
  }

  /// v1.4.30: 3D pasand (default 2D/normal) — SharedPreferences
  /// mein mehfooz; ON par camera pitched (60°) aur imaaratein
  /// (zoom 15+ par pehle se mojood buildings layer) numaya
  /// nazar ati hain. Disha phir bhi north-up hi rehti hai।
  bool _threeD = false;

  bool get _sat =>
      widget.externalStyleControl ? widget.satellite : _satelliteInternal;

  @override
  void initState() {
    super.initState();
    _satelliteInternal = widget.satellite;
    OfflineMaps.ensurePakistan();
    _load3d();
    // Display pasand (Din/Raat/Auto) badle to map ka style
    // bhi usi waqt badle — EK button, poori app + map।
    DisplayPrefs.notifier.addListener(_onDisplayChanged);
  }

  void _onDisplayChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _load3d() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final v = prefs.getBool('map_3d_v1') ?? false;
      if (mounted && v != _threeD) setState(() => _threeD = v);
    } catch (_) {}
  }

  Future<void> _set3d(bool v) async {
    setState(() => _threeD = v);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('map_3d_v1', v);
    } catch (_) {}
    final c = _c;
    if (c != null && _styleReady) {
      final pos = c.cameraPosition;
      if (pos != null) {
        _animateCamera(ml.CameraPosition(
          target: pos.target,
          zoom: pos.zoom,
          bearing: _bearingForCamera(),
          tilt: v ? 60 : widget.tilt,
        ));
      }
    }
  }

  /// Map ka style — satellite ON ho to satellite; warna
  /// Display pasand: Raat (ya Auto + phone dark) par Dark
  /// Matter, warna Voyager (Din)।
  String _styleFor(BuildContext context) {
    if (_sat) return kSatelliteStyleJson;
    return DisplayPrefs.isDarkNow(context)
        ? kNightStyleJson
        : kDayStyleJson;
  }

  Future<void> _guard(Future<void> f) async {
    try {
      await f;
    } catch (_) {}
  }

  /// _guard ki bool wali shakal — jahan kamyabi/naakami se
  /// agla qadam tay hota hai (masalan buildings layer ka
  /// source channa: pehle ek, fail ho to doosra).
  Future<bool> _guardOk(Future<void> f) async {
    try {
      await f;
      return true;
    } catch (_) {
      return false;
    }
  }

  Map<String, dynamic> _fc(List<Map<String, dynamic>> features) =>
      {'type': 'FeatureCollection', 'features': features};

  Map<String, dynamic> _pointFeature(ll.LatLng p,
          {Map<String, dynamic>? props}) =>
      {
        'type': 'Feature',
        'geometry': {
          'type': 'Point',
          'coordinates': [p.longitude, p.latitude]
        },
        'properties': props ?? {},
      };

  Future<void> _applyStyle() async {
    final c = _c;
    if (c == null) return;
    _styleReady = false;
    _photoImgReady = false;
    // Marker tasveerein style ke andar register karein
    for (final entry in {
      'safar-pin': 'assets/map-pin-green.png',
      'safar-arrow': 'assets/map-arrow-down.png',
      'safar-nav-on': 'assets/map-nav-green.png',
      'safar-nav-off': 'assets/map-nav-grey.png',
      // v1.4.29: A (pickup) / B (drop) wale kaale gol-chokor pins
      // — owner ke example screenshots wali shakal (DRIVER-FLOW-
      // SPEC 2026-11-11); apni banayi hui PNG hain, kisi company
      // ka asset NAHI.
      'safar-pin-a': 'assets/map-pin-a.png',
      'safar-pin-b': 'assets/map-pin-b.png',
    }.entries) {
      await _guard(() async {
        final data = await rootBundle.load(entry.value);
        await c.addImage(entry.key, data.buffer.asUint8List());
      }());
    }
    // Sources
    await _guard(c.addGeoJsonSource('safar-route', _fc([])));
    await _guard(c.addGeoJsonSource('safar-points', _fc([])));
    await _guard(c.addGeoJsonSource('safar-pos', _fc([])));
    await _guard(c.addGeoJsonSource('safar-zones', _fc([])));
    await _guard(c.addGeoJsonSource('safar-photo', _fc([])));
    await _guard(c.addGeoJsonSource('safar-mypos', _fc([])));
    await _ensurePhotoImage();
    // 3D imaaratein — sirf streets style par (satellite par nahi).
    // Vector data mein render_height jahan maujood hai wahan
    // imaaratein uthi hui nazar aati hain (zoom 15+).
    // v1.4.42: asal layer ab Day/Night style JSON ke ANDAR
    // hai (day_style.dart/night_style.dart ki 'safar-
    // buildings-3d'); ye runtime koshish sirf backup hai।
    // (v1.4.29 wala comment source id 'carto' batata tha —
    // woh ghalat tha; inline styles ka source 'protomaps'
    // hai, source-layer 'buildings'।)
    if (!_sat) {
      const props = ml.FillExtrusionLayerProperties(
        fillExtrusionColor: '#CFC4B0',
        fillExtrusionOpacity: 0.9,
        fillExtrusionHeight: [
          'coalesce',
          ['to-number', ['get', 'render_height']],
          8
        ],
        fillExtrusionBase: [
          'coalesce',
          ['to-number', ['get', 'render_min_height']],
          0
        ],
      );
      // v1.4.42 DURUSTI: inline Day/Night styles ka asal
      // source id 'protomaps' hai aur source-layer
      // 'buildings' — purana pehla andaza ('carto'/'building')
      // is liye hamesha fail hota tha aur 3D imaaratein asal
      // mein banti hi NAHI theen (style JSON mein ab yehi
      // layer pehle se hai; ye runtime koshish sirf us surat
      // ka sahara hai jab JSON wali layer kisi wajah se na
      // ho — id ek hi hai, dohra nahi banta)।
      final okCarto = await _guardOk(c.addFillExtrusionLayer(
        'protomaps',
        'safar-buildings-3d',
        props,
        sourceLayer: 'buildings',
        minzoom: 15,
      ));
      if (!okCarto) {
        await _guard(c.addFillExtrusionLayer(
          'openmaptiles',
          'safar-buildings-3d',
          props,
          sourceLayer: 'building',
          minzoom: 15,
        ));
      }
    }
    // Route line — pehle safed kinara (casing), phir MOTI
    // line (v1.4.29 tak hari thi)।
    // v1.4.42 (malik ka hukm 2026-11-13, reference wali
    // shakal): route ab GEHRI NEELI (#0B63E5) moti line hai,
    // neeche safed casing ke saath — vivid 3D map par neeli
    // line sab se saaf numayan rehti hai।
    await _guard(c.addLineLayer(
      'safar-route',
      'safar-route-casing',
      const ml.LineLayerProperties(
        lineColor: '#FFFFFF',
        lineWidth: 12.5,
        lineOpacity: 0.95,
        lineCap: 'round',
        lineJoin: 'round',
      ),
    ));
    await _guard(c.addLineLayer(
      'safar-route',
      'safar-route-line',
      const ml.LineLayerProperties(
        lineColor: '#0B63E5',
        lineWidth: 8.5,
        lineOpacity: 1,
        lineCap: 'round',
        lineJoin: 'round',
      ),
    ));
    // Zone pins — chhote sunehre nuqtay
    await _guard(c.addCircleLayer(
      'safar-zones',
      'safar-zone-dots',
      const ml.CircleLayerProperties(
        circleRadius: 5,
        circleColor: '#D4AF37',
        circleStrokeColor: '#FFFFFF',
        circleStrokeWidth: 1.6,
        circleOpacity: 0.95,
      ),
    ));
    // Pickup pin — v1.4.29: kaala gol-chokor "A" pin (owner ke
    // example wali shakal; apni PNG asset)।
    await _guard(c.addSymbolLayer(
      'safar-points',
      'safar-pickup-sym',
      const ml.SymbolLayerProperties(
        iconImage: 'safar-pin-a',
        // v1.4.42: pin thoda bara (0.42 → 0.5) — vivid map
        // par A/B door se saaf parhe jayein।
        iconSize: 0.5,
        iconAnchor: 'bottom',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
      filter: ['==', 'kind', 'pickup'],
    ));
    // Manzil pin — v1.4.29: kaala gol-chokor "B" pin (pehle
    // wala sunehra teer hata diya — A/B usool har jagah ek hai)।
    await _guard(c.addSymbolLayer(
      'safar-points',
      'safar-drop-sym',
      const ml.SymbolLayerProperties(
        iconImage: 'safar-pin-b',
        iconSize: 0.5,
        iconAnchor: 'bottom',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
      filter: ['==', 'kind', 'drop'],
    ));
    // Driver ki position — nav arrow (v1.4.9; v1.4.11 mein CHHOTA:
    // malik ka hukm ke bara teer galiyan dhakta tha — iconSize
    // 0.45 → 0.25, taake aas paas ki galiyan saaf nazar ayen), simt
    // ke saath ghumta hua. Do layers: ONLINE (duty par) = HARA teer,
    // OFFLINE = KALA-SAFAID teer — feature ki 'state' property se
    // chuna jata hai.
    await _guard(c.addSymbolLayer(
      'safar-pos',
      'safar-pos-sym-on',
      const ml.SymbolLayerProperties(
        iconImage: 'safar-nav-on',
        iconSize: 0.25,
        iconAnchor: 'center',
        iconRotate: ['get', 'bearing'],
        iconRotationAlignment: 'map',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
      filter: ['==', 'state', 'online'],
    ));
    await _guard(c.addSymbolLayer(
      'safar-pos',
      'safar-pos-sym-off',
      const ml.SymbolLayerProperties(
        iconImage: 'safar-nav-off',
        iconSize: 0.25,
        iconAnchor: 'center',
        iconRotate: ['get', 'bearing'],
        iconRotationAlignment: 'map',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
      filter: ['==', 'state', 'offline'],
    ));
    // v1.4.32 PHOTO-PIN layer — doosre fareeq ki photo us ki
    // jagah par (Master map wale photo markers wala hi size:
    // 192x212 px ki tasveer iconSize 0.5 par)।
    await _guard(c.addSymbolLayer(
      'safar-photo',
      'safar-photo-sym',
      const ml.SymbolLayerProperties(
        iconImage: 'safar-photo',
        iconSize: 0.5,
        iconAnchor: 'bottom',
        iconAllowOverlap: true,
        iconIgnorePlacement: true,
      ),
    ));
    // v1.4.42 (M4): APNI live jagah ka marker — halka neela
    // halo + gehra neela nuqta safed kinare ke saath (aam
    // maps wali "aap yahan hain" pehchan; A/B pins aur
    // driver ke teer se bilkul alag)।
    await _guard(c.addCircleLayer(
      'safar-mypos',
      'safar-mypos-halo',
      const ml.CircleLayerProperties(
        circleRadius: 17,
        circleColor: '#1A73E8',
        circleOpacity: 0.22,
      ),
    ));
    await _guard(c.addCircleLayer(
      'safar-mypos',
      'safar-mypos-dot',
      const ml.CircleLayerProperties(
        circleRadius: 8,
        circleColor: '#1A73E8',
        circleOpacity: 1,
        circleStrokeColor: '#FFFFFF',
        circleStrokeWidth: 2.6,
      ),
    ));
    _styleReady = true;
    _routeSig = '';
    _pushData();
    _maybeFit(initial: true);
    _followIfNeeded(force: true);
    // v1.4.42 (M4): style bante hi apni live jagah se 500 m+
    // door hon to wahi center (app khulne par map pichhli
    // ride ke ilaqe par NAHI rehta)।
    _followMyPosIfNeeded();
    // v1.4.30: 3D pasand mehfooz thi to style bante hi camera
    // pitched kar do (disha north-up hi rehti hai)।
    if (_threeD) {
      final pos = c.cameraPosition;
      if (pos != null) {
        _animateCamera(ml.CameraPosition(
          target: pos.target,
          zoom: pos.zoom,
          bearing: _bearingForCamera(),
          tilt: 60,
        ));
      }
    }
  }

  String _sigOf(List<ll.LatLng>? pts) {
    if (pts == null || pts.length < 2) return '';
    final a = pts.first, b = pts.last;
    return '${pts.length}|${a.latitude.toStringAsFixed(4)},${a.longitude.toStringAsFixed(4)}'
        '|${b.latitude.toStringAsFixed(4)},${b.longitude.toStringAsFixed(4)}';
  }

  /// v1.4.32: photo-pin PNG ko style mein 'safar-photo' ke
  /// naam se register karna — style bante waqt bhi aur PNG
  /// baad mein ane par bhi (didUpdateWidget se)।
  Future<void> _ensurePhotoImage() async {
    final c = _c;
    final png = widget.photoPinPng;
    if (c == null || png == null || _photoImgReady) return;
    final ok = await _guardOk(c.addImage('safar-photo', png));
    if (ok) _photoImgReady = true;
  }

  void _pushData() {
    final c = _c;
    if (c == null || !_styleReady) return;
    final pts = widget.routePoints;
    _guard(c.setGeoJsonSource(
        'safar-route',
        _fc([
          if (pts != null && pts.length > 1)
            {
              'type': 'Feature',
              'geometry': {
                'type': 'LineString',
                'coordinates':
                    pts.map((p) => [p.longitude, p.latitude]).toList()
              },
              'properties': {},
            }
        ])));
    _guard(c.setGeoJsonSource(
        'safar-points',
        _fc([
          if (widget.pickup != null)
            _pointFeature(widget.pickup!, props: {'kind': 'pickup'}),
          if (widget.drop != null)
            _pointFeature(widget.drop!, props: {'kind': 'drop'}),
        ])));
    _guard(c.setGeoJsonSource(
        'safar-pos',
        _fc([
          if (widget.position != null)
            _pointFeature(widget.position!, props: {
              'bearing': widget.positionBearing,
              'state': widget.positionOnline ? 'online' : 'offline',
            }),
        ])));
    _guard(c.setGeoJsonSource(
        'safar-zones',
        _fc([
          for (final z in widget.zonePoints ?? <ll.LatLng>[]) _pointFeature(z),
        ])));
    _guard(c.setGeoJsonSource(
        'safar-photo',
        _fc([
          if (widget.photoPinAt != null && widget.photoPinPng != null)
            _pointFeature(widget.photoPinAt!),
        ])));
    _guard(c.setGeoJsonSource(
        'safar-mypos',
        _fc([
          if (widget.myPosition != null) _pointFeature(widget.myPosition!),
        ])));
  }

  void _fitPoints(List<ll.LatLng> pts) {
    final c = _c;
    if (c == null || pts.isEmpty) return;
    var minLat = pts.first.latitude, maxLat = minLat;
    var minLng = pts.first.longitude, maxLng = minLng;
    for (final p in pts) {
      minLat = math.min(minLat, p.latitude);
      maxLat = math.max(maxLat, p.latitude);
      minLng = math.min(minLng, p.longitude);
      maxLng = math.max(maxLng, p.longitude);
    }
    final center = ll.LatLng((minLat + maxLat) / 2, (minLng + maxLng) / 2);
    final span = math.max((maxLat - minLat).abs(), (maxLng - minLng).abs());
    final zoom = span <= 0.0005
        ? 15.5
        : (math.log(360 / (span * 1.5)) / math.ln2).clamp(11.0, 16.0);
    _animateCamera(ml.CameraPosition(
      target: _m(center),
      zoom: zoom,
      bearing: _bearingForCamera(),
      tilt: widget.tilt,
    ));
  }

  void _maybeFit({bool initial = false}) {
    if (!widget.fitToRoute) return;
    final pts = widget.routePoints;
    if (pts == null || pts.length < 2) return;
    final sig = _sigOf(pts);
    if (!initial && sig == _routeSig) return;
    _routeSig = sig;
    _fitPoints(pts);
  }

  void _followIfNeeded({bool force = false}) {
    final c = _c;
    final pos = widget.position;
    if (c == null || !_styleReady || pos == null || !widget.followPosition) {
      return;
    }
    // v1.4.42 FOLLOW: user ke haath ke pan ke baad follow
    // ruka rehta hai — dobara lock sirf caller ke recenter
    // (followPosition false→true) se hota hai।
    if (_followPosPaused) return;
    if (!force && _lastFollowed != null) {
      final d = const ll.Distance().as(ll.LengthUnit.Meter, _lastFollowed!, pos);
      // v1.4.10: pehle 4 m se kam harkat par camera rukta tha —
      // ab sirf 0.5 m se kam (khade GPS ki mamoli jitter) par
      // rukta hai; har asal harkat par camera saath chalta hai.
      if (d < 0.5) return;
    }
    _lastFollowed = pos;
    // v1.4.42 FOLLOW (aage ka rasta pehle): caller ne
    // forward offset diya ho to camera ka nishana asal
    // jagah se utne meter AAGE (maujooda simt ki taraf) —
    // teer screen ke markaz se neeche, aage ki sadak
    // zyada nazar ati hai। Har GPS fix par yehi hisaab
    // dobara lagta hai, is liye pan hamesha smooth rehta
    // hai (animateCamera ka apna transition)।
    var camTarget = pos;
    if (widget.followForwardOffsetM > 0) {
      camTarget = const ll.Distance()
          .offset(pos, widget.followForwardOffsetM, _bearingForCamera());
    }
    _animateCamera(ml.CameraPosition(
      target: _m(camTarget),
      // v1.4.42 (H2): caller followZoom de to wohi (driver
      // nav = gali-level 19.0/19.5); warna purana 16.5।
      zoom: widget.followZoom ?? 16.5,
      tilt: 55,
      // v1.4.11: heading-up SIRF wahan jahan caller cameraBearing
      // de (driver ka nav view, apni gating ke saath); warna
      // camera hamesha north-up (0) — passenger side hamesha 0.
      // v1.4.33: user ne do ungliyon se ghumaya ho to us ki
      // disha (_manualBearing) pehle — follow sirf jagah
      // (target) taza karta hai, angle user ka rehta hai.
      bearing: _bearingForCamera(),
    ));
  }

  /// v1.4.42 (M4) APNI-JAGAH FOLLOW: camera ka maujooda
  /// center live position se ~500 m se zyada door ho jaye
  /// tab hi re-center — chhoti harkaton par camera khamosh
  /// rehta hai (har GPS tick par jump NAHI)। Follow user ke
  /// pan par ruka hota hai (_followPaused)।
  void _followMyPosIfNeeded() {
    final c = _c;
    final pos = widget.myPosition;
    if (c == null ||
        !_styleReady ||
        pos == null ||
        !widget.followMyPosition ||
        _followPaused) {
      return;
    }
    final target = c.cameraPosition?.target;
    if (target == null) return;
    final d = const ll.Distance()
        .as(ll.LengthUnit.Meter, _l(target), pos);
    if (d < 500) return;
    final cur = c.cameraPosition;
    _animateCamera(ml.CameraPosition(
      target: _m(pos),
      zoom: cur?.zoom ?? widget.initialZoom,
      bearing: _bearingForCamera(),
      tilt: cur?.tilt ?? widget.tilt,
    ));
  }

  @override
  void didUpdateWidget(SafarMapView old) {
    super.didUpdateWidget(old);
    // v1.4.32: photo-pin PNG style banne ke BAAD aya ho to
    // pehle tasveer register karo, phir data dobara bhejo।
    if (widget.photoPinPng != null &&
        !identical(widget.photoPinPng, old.photoPinPng)) {
      unawaited(_ensurePhotoImage().then((_) => _pushData()));
    }
    if (widget.focusSeq != old.focusSeq && widget.focusPoint != null) {
      // v1.4.42: saaf re-center (Meri Location button) =
      // follow dobara ON।
      _followPaused = false;
      _animateCamera(ml.CameraPosition(
        target: _m(widget.focusPoint!),
        // v1.4.42 (HOME ZOOM — owner hukm 2026-11-13 02:45):
        // kisi EK jagah par focus (live location / chuni hui
        // jagah) ab street-level 17 par ata hai — pehle 15.5
        // par "bohat upar se" nazar ata tha। Route ka poora
        // fit is se alag hai (sirf asal route par _fitPoints)।
        zoom: 17,
        bearing: _bearingForCamera(),
        tilt: 55,
      ));
    }
    _pushData();
    _maybeFit();
    // v1.4.42 FOLLOW: follow dobara ON hua (recenter /
    // Follow button) — pan-wala pause saaf aur camera
    // foran wapas lock।
    if (widget.followPosition && !old.followPosition) {
      _followPosPaused = false;
      _followIfNeeded(force: true);
    }
    _followIfNeeded();
    if (widget.myPosition != old.myPosition) _followMyPosIfNeeded();
  }

  /// maplibre_gl 0.22 ke MapLibreMap widget par onCameraMove callback
  /// nahi hai; us ki jagah controller (ChangeNotifier) camera ki har
  /// harkat par notify karta hai aur cameraPosition taaza ho jata hai —
  /// wohi maloomat yahan se onCameraTarget tak pohanchti hai.
  void _onControllerNotify() {
    final t = _c?.cameraPosition?.target;
    if (t != null) {
      final lt = _l(t);
      // v1.4.42 (M4) PAN KI PEHCHAN: camera ka nishana 40 m
      // se zyada hata aur aakhri code-wali harkat ko 2 s se
      // zyada ho gaye hon to ye user ka haath hai — apni-
      // jagah follow rok do (page ka Meri Location button /
      // focusSeq use dobara chala dega)।
      final prev = _lastCamTarget;
      if (prev != null) {
        final moved =
            const ll.Distance().as(ll.LengthUnit.Meter, prev, lt);
        final lastCode = _lastCodeMoveAt;
        final codeAgo = lastCode == null
            ? const Duration(days: 1)
            : DateTime.now().difference(lastCode);
        if (moved > 40 && codeAgo.inMilliseconds > 2000) {
          // Apni-jagah follow (passenger home) ka pause।
          if (widget.followMyPosition && !_followPaused) {
            _followPaused = true;
          }
          // v1.4.42 FOLLOW: nav follow ka pause — user ne
          // map ungli se hila diya to camera lock toot gaya;
          // caller ko khabar (us ki Follow pill OFF ho
          // jayegi), recenter se dobara lock hoga।
          if (widget.followPosition && !_followPosPaused) {
            _followPosPaused = true;
            widget.onFollowPaused?.call();
          }
        }
      }
      _lastCamTarget = lt;
      widget.onCameraTarget?.call(lt);
    }
  }

  @override
  void dispose() {
    _c?.removeListener(_onControllerNotify);
    DisplayPrefs.notifier.removeListener(_onDisplayChanged);
    super.dispose();
  }

  void _toggleStyle() {
    final next = !_sat;
    if (widget.externalStyleControl) {
      widget.onSatelliteChanged?.call(next);
    } else {
      setState(() => _satelliteInternal = next);
      widget.onSatelliteChanged?.call(next);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        ml.MapLibreMap(
          styleString: _styleFor(context),
          initialCameraPosition: ml.CameraPosition(
            target: _m(widget.center),
            zoom: widget.initialZoom,
            tilt: widget.tilt,
          ),
          trackCameraPosition: true,
          // v1.4.36 FULL ZOOM-OUT (owner hukm 2026-11-12): user
          // map ko poora zoom-out karke DUNIYA ki satah (zoom
          // ~0.5) tak ja sake — pehle koi min zoom set hi nahi
          // tha, natija plugin/native ke default par tha aur
          // duniya wali satah pakki nahi milti thi. Ab min zoom
          // 0.5 wazeh taur par set hai; max zoom par koi pabandi
          // nahi (null = unbounded, pehle jaisa). Yehi ek widget
          // saari screens (normal / 3D / satellite) par chalta
          // hai, is liye teeno modes cover hain. Sheher ke andar
          // ke zoom (11–18) par is ka koi asar nahi.
          minMaxZoomPreference: const ml.MinMaxZoomPreference(0.5, null),
          compassEnabled: widget.interactive,
          scrollGesturesEnabled: widget.interactive,
          // v1.4.33 DO-UNGLI GHUMAO (owner hukm 2026-11-12 00:35):
          // driver + passenger, har interactive map par do
          // ungliyon se ghumana khula hai — 2026-11-11 17:12 wala
          // "seedha nazara" (rotation band) lock is hukm se
          // khatam. Ghumai hui disha _manualBearing mein mehfooz
          // rehti hai; compass dabane par wapas north-up /
          // heading-up. Sirf driver ke nav view (jahan caller
          // cameraBearing deta hai) mein heading-up us ka apna
          // tay-shuda amal hai — manual ghumao usay compass
          // reset tak rok deta hai.
          rotateGesturesEnabled: widget.interactive,
          tiltGesturesEnabled: widget.interactive,
          zoomGesturesEnabled: widget.interactive,
          onMapCreated: (c) {
            _c = c;
            c.addListener(_onControllerNotify);
            // MAP WAVE (v1.4.20): 24 ghante wala map-data
            // refresh check — har app run mein sirf pehle
            // controller par ek dafa (MapDataRefresh khud
            // guard rakhta hai). Background amal hai; map
            // ki loading is par nahi rukti.
            MapDataRefresh.maybeRefresh(c);
          },
          onStyleLoadedCallback: _applyStyle,
          onMapClick: (point, coords) =>
              widget.onTapPoint?.call(_l(coords)),
          onMapLongClick: (point, coords) =>
              widget.onLongPressPoint?.call(_l(coords)),
          onCameraIdle: _onCameraIdleInternal,
        ),
        // OSM ATTRIBUTION (v1.4.28 — license shart): map ka
        // data OpenStreetMap contributors ka hai (OpenFreeMap
        // "Liberty" style); attribution har map par lazmi aur
        // parha ja sakne wala hona chahiye. Native attribution
        // button style ke metadata par munhasir hota hai, is
        // liye ye apna badge pakka rasta hai — SafarMapView
        // app ka WAHID MapLibreMap hai, is liye ye badge
        // passenger + driver + route/picker, har map par
        // khud pohanchta hai. IgnorePointer: map ke taps
        // (pin lagana) is se kabhi NAHI rukte।
        Positioned(
          left: 8,
          bottom: 8,
          child: IgnorePointer(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 6, vertical: 2.5),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.78),
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Text(
                kOsmAttribution,
                style: TextStyle(fontSize: 9.5, color: Colors.black87),
              ),
            ),
          ),
        ),
        // v1.4.30 SIDE CONTROLS (dayein taraf ke gol buttons):
        // Display (Din/Raat/Auto — EK button, poori app + map),
        // 3D on/off, aur Streets/Satellite. External-control
        // wale map (booking view) par parent ke apne controls
        // dayein hain, is liye wahan yehi buttons BAYEIN taraf
        // compact shakal mein ate hain।
        // v1.4.42 (H1R — owner hukm 2026-11-13 02:40): Display
        // wala button ab likhai wala pill NAHI — chhota GOL
        // ICON button hai (chaand/sooraj ki nishani, bina
        // likhai) — function wohi (Din/Raat/Auto cycle)।
        if (!widget.externalStyleControl)
          Positioned(
            top: 8,
            right: 8,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const DisplayModeIconButton(),
                const SizedBox(height: 6),
                _controlChip(
                  icon: Icons.view_in_ar,
                  label: tr('map_3d'),
                  active: _threeD,
                  onTap: () => _set3d(!_threeD),
                ),
                const SizedBox(height: 6),
                _controlChip(
                  icon: Icons.layers,
                  label: _sat ? 'Streets' : 'Satellite',
                  active: _sat,
                  onTap: _toggleStyle,
                ),
              ],
            ),
          )
        else
          Positioned(
            top: 8,
            left: 8,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const DisplayModeIconButton(),
                const SizedBox(height: 6),
                _controlChip(
                  icon: Icons.view_in_ar,
                  label: tr('map_3d'),
                  active: _threeD,
                  onTap: () => _set3d(!_threeD),
                ),
              ],
            ),
          ),
      ],
    );
  }

  /// Side controls ka ek gol button (Display button wali
  /// shakal): gehri sabz patti, sunehra kinara; active ho to
  /// sunehra bhara hua।
  Widget _controlChip({
    required IconData icon,
    required String label,
    required bool active,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: active
                ? Brand.gold.withOpacity(0.95)
                : Brand.deepGreen.withOpacity(0.92),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Brand.gold, width: 1),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon,
                  color: active ? Brand.greenDark : Brand.goldLight,
                  size: 15),
              const SizedBox(width: 5),
              Text(label,
                  style: TextStyle(
                      color: active ? Brand.greenDark : Colors.white,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Pickup → drop ka tayyar route map: OSRM se asal sadak ka route khud
/// le aata hai (cache ke saath); net na ho to cache ya seedhi line.
/// Passenger ki booking tafseel aur driver ki nayi booking card mein
/// istemal hota hai.
class SafarRouteMap extends StatefulWidget {
  final ll.LatLng pickup;
  final ll.LatLng? drop;
  final bool interactive;
  final double tilt;

  /// Assign driver ki jagah (passenger tracking screen, v1.4.9) —
  /// di jaye to driver ka BARA teer bhi map par dikhta hai: online
  /// ho to hara, offline ho to kala-safaid. Na di jaye to map bilkul
  /// pehle jaisa (sirf pickup/drop/route).
  final ll.LatLng? driverPosition;
  final double driverBearing;
  final bool driverOnline;

  /// v1.4.32: assign driver ki photo-pin ka tayyar PNG
  /// (PhotoPin se) — driver ki jagah par photo-pin dikhta
  /// hai; null ho to sirf teer hi rehta hai।
  final Uint8List? driverPhotoPng;

  /// v1.4.42 (M4): is device ki APNI live jagah — di jaye to
  /// route map par neela nuqta (apni pehchan) bhi dikhta hai
  /// (sirf marker; follow is chhote map par NAHI — yahan
  /// fit-to-route hi usool hai)।
  final ll.LatLng? myPosition;

  const SafarRouteMap({
    super.key,
    required this.pickup,
    this.drop,
    this.interactive = true,
    this.tilt = 45,
    this.driverPosition,
    this.driverBearing = 0,
    this.driverOnline = true,
    this.driverPhotoPng,
    this.myPosition,
  });

  @override
  State<SafarRouteMap> createState() => _SafarRouteMapState();
}

class _SafarRouteMapState extends State<SafarRouteMap> {
  RouteResult? _route;
  int _token = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(SafarRouteMap old) {
    super.didUpdateWidget(old);
    if (old.pickup != widget.pickup || old.drop != widget.drop) _load();
  }

  Future<void> _load() async {
    final drop = widget.drop;
    if (drop == null) {
      setState(() => _route = null);
      return;
    }
    final token = ++_token;
    final r = await RouteService.fetch(widget.pickup, drop);
    if (mounted && token == _token) setState(() => _route = r);
  }

  @override
  Widget build(BuildContext context) {
    final drop = widget.drop;
    final center = drop != null
        ? ll.LatLng((widget.pickup.latitude + drop.latitude) / 2,
            (widget.pickup.longitude + drop.longitude) / 2)
        : widget.pickup;
    return SafarMapView(
      center: center,
      initialZoom: 13,
      tilt: widget.tilt,
      pickup: widget.pickup,
      drop: drop,
      routePoints:
          _route?.points ?? (drop != null ? [widget.pickup, drop] : null),
      position: widget.driverPosition,
      positionBearing: widget.driverBearing,
      positionOnline: widget.driverOnline,
      photoPinAt: widget.driverPosition,
      photoPinPng: widget.driverPhotoPng,
      myPosition: widget.myPosition,
      interactive: widget.interactive,
      fitToRoute: true,
    );
  }
}

/// Driver ke liye Google-style guidance: chal rahi ride par asal route,
/// agle mor ki Roman Urdu hidayat wala banner, route par aage barhta
/// hara arrow (sirf asal GPS position par — ijazat/position na ho
/// to na arrow, na banner; kuch jhooti nahi dikhta), aur follow camera.
/// v1.4.11: teer ki simt gali-simt smoothed bearing (baseline +
/// route-segment tarjeeh) aur camera heading-up sirf chalti
/// haalat mein — tafseel _DriverNavViewState ke andar.
class DriverNavView extends StatefulWidget {
  final Booking booking;

  /// Har taaza GPS position par pukar — driver side is se store ki
  /// driver-position taza rakhta hai, taaki passenger ko driver ki
  /// doori/ETA mil sake. Optional hai; na diya jaye to nav bilkul
  /// pehle ki tarah apne andar hi rehta hai.
  final ValueChanged<ll.LatLng>? onPosition;

  /// Driver ki duty haalat — teer ka rang isi se banta hai (v1.4.9):
  /// online = hara, offline = kala-safaid.
  final bool driverOnline;

  /// v1.4.32: sawari ki photo-pin ka tayyar PNG (PhotoPin se) —
  /// pickup ki taraf jate hue sawari ki photo pickup wale
  /// maqam par dikhti hai; ride shuru (arrived) hone ke baad
  /// pin gayab (sawari saath bethi hai)।
  final Uint8List? passengerPhotoPng;
  const DriverNavView(
      {super.key,
      required this.booking,
      this.onPosition,
      this.driverOnline = true,
      this.passengerPhotoPng});

  @override
  State<DriverNavView> createState() => _DriverNavViewState();
}

class _DriverNavViewState extends State<DriverNavView> {
  StreamSubscription<Position>? _sub;
  ll.LatLng? _pos;

  // --- v1.4.11: GALI-SIMT TEER (malik ke hukm 2026-11-09) --------
  // Teer ki simt aakhri do fixes se NAHI banti, balkay ~12 m
  // PEETHE ke baseline se banti hai — taake teer GPS ke shor ki
  // bajaye asal GALI ki simt dikhaye aur driver confuse na ho.
  // Ruki hui haalat (speed < 1 m/s) mein simt JAMA rehti hai —
  // teer khada ho kar kabhi nahi ghumta. Har badlav shortest-arc
  // lerp se aahista ata hai, snap kabhi nahi. Route maujood ho aur
  // position route se <= 25 m ke andar ho to sab se qareebi route
  // segment ki simt ko tarjeeh milti hai — teer tay shuda gali
  // par chipka rehta hai.
  static const double _kBearingBaselineM = 12;
  static const double _kHoldMoveM = 3;
  static const double _kHoldSpeedMps = 1.0;
  static const double _kCameraSpeedMps = 1.5;
  static const double _kRouteNearM = 25;
  static const double _kBearingLerp = 0.35;

  /// Haal ki positions ki trail (purani → nayi) — baseline anchor
  /// isi se nikalta hai.
  final List<({ll.LatLng p, DateTime t})> _trail = [];

  /// Teer ki NUMAYA (smoothed) simt — build isi ko istemal karta
  /// hai. _hasBearing false ho to abhi koi pakki simt nahi bani.
  double _displayBearing = 0;
  bool _hasBearing = false;

  /// Follow camera ki simt (heading-up): sirf jab driver asal
  /// mein chal raha ho (speed > 1.5 m/s) tab _displayBearing se
  /// taaza hoti hai; rukte hi aakhri value par JAMA rehti hai —
  /// camera kabhi khud north ki taraf wapas nahi ghumta.
  double _camBearing = 0;

  /// [pos] se ~[_kBearingBaselineM] meter peeche ka trail point
  /// (trail chhota ho to sab se purana point) aur us ki asal doori.
  ({ll.LatLng anchor, double dist}) _trailAnchor(ll.LatLng pos) {
    var acc = 0.0;
    var prev = pos;
    for (var i = _trail.length - 1; i >= 0; i--) {
      final p = _trail[i].p;
      final seg = const ll.Distance().as(ll.LengthUnit.Meter, p, prev);
      if (seg > 0 && acc + seg >= _kBearingBaselineM) {
        final frac = (_kBearingBaselineM - acc) / seg;
        return (
          anchor: ll.LatLng(
            prev.latitude + (p.latitude - prev.latitude) * frac,
            prev.longitude + (p.longitude - prev.longitude) * frac,
          ),
          dist: _kBearingBaselineM,
        );
      }
      acc += seg;
      prev = p;
    }
    return (anchor: prev, dist: acc);
  }

  /// Speed ka andaza: GPS ki apni speed mile to wohi; warna
  /// pichhle ~2.5+ second ki trail harkat se hisaab.
  double _speedEstimate(Position p, ll.LatLng pos, DateTime now) {
    if (p.speed >= 0) return p.speed;
    for (var i = _trail.length - 1; i >= 0; i--) {
      final e = _trail[i];
      final dt = now.difference(e.t).inMilliseconds / 1000.0;
      if (dt >= 2.5) {
        return const ll.Distance().as(ll.LengthUnit.Meter, e.p, pos) / dt;
      }
    }
    return 0;
  }

  RouteResult? _route;
  ll.LatLng? _routeOrigin;
  int _fetchToken = 0;
  bool _follow = true;
  bool _noGps = false;

  ll.LatLng get _target => widget.booking.status == 'arrived'
      ? ll.LatLng(widget.booking.dropLat, widget.booking.dropLng)
      : ll.LatLng(widget.booking.pickupLat, widget.booking.pickupLng);

  String get _targetLabel => widget.booking.status == 'arrived'
      ? 'Drop: ${widget.booking.dropLabel}'
      : 'Pickup: ${widget.booking.pickupLabel}';

  String get _targetKey =>
      '${widget.booking.status}|${_target.latitude.toStringAsFixed(4)},${_target.longitude.toStringAsFixed(4)}';
  String _lastTargetKey = '';

  @override
  void initState() {
    super.initState();
    _lastTargetKey = _targetKey;
    _initLocation();
  }

  @override
  void didUpdateWidget(DriverNavView old) {
    super.didUpdateWidget(old);
    if (_targetKey != _lastTargetKey) {
      _lastTargetKey = _targetKey;
      _route = null;
      _routeOrigin = null;
      final p = _pos;
      if (p != null) _fetchRoute(p, force: true);
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _initLocation() async {
    try {
      final service = await Geolocator.isLocationServiceEnabled();
      if (!service) {
        if (mounted) setState(() => _noGps = true);
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        if (mounted) setState(() => _noGps = true);
        return;
      }
      final last = await Geolocator.getLastKnownPosition();
      if (last != null && mounted) _onPos(last);
      // v1.4.10 (malik ka hukm 2026-11-09): distanceFilter 0 —
      // har GPS fix par naya maqam mile, taake qadam-qadam ki
      // harkat bhi map par saath saath nazar aye.
      _sub = Geolocator.getPositionStream(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 0),
      ).listen(_onPos, onError: (_) {});
    } catch (_) {
      if (mounted) setState(() => _noGps = true);
    }
  }

  void _onPos(Position p) {
    if (!mounted) return;
    final pos = ll.LatLng(p.latitude, p.longitude);
    widget.onPosition?.call(pos);
    final now = DateTime.now();
    _trail.add((p: pos, t: now));
    while (_trail.length > 120) {
      _trail.removeAt(0);
    }
    while (_trail.length > 2 &&
        now.difference(_trail.first.t) > const Duration(seconds: 45)) {
      _trail.removeAt(0);
    }
    final speed = _speedEstimate(p, pos, now);
    final anch = _trailAnchor(pos);
    // Route segment ki simt — sirf tab jab position route ki line
    // se <= 25 m ke andar ho; door ho to woh simt ghlt hogi, is
    // liye wahan movement baseline hi chalega.
    double? routeBearing;
    final route = _route;
    if (route != null) {
      final prog = route.track.progressAt(pos);
      final dRoute =
          const ll.Distance().as(ll.LengthUnit.Meter, pos, prog.snapped);
      if (dRoute <= _kRouteNearM) routeBearing = prog.bearingDeg;
    }
    // Candidate simt: speed < 1 m/s ho to KOI candidate nahi —
    // simt jama rehti hai (khade GPS ki jitter teer ko kabhi
    // nahi ghumati). Chalti haalat mein route segment ko tarjeeh,
    // warna ~12 m baseline; baseline < 3 m ho to bhi hold.
    double? candidate;
    if (speed >= _kHoldSpeedMps) {
      candidate = routeBearing ??
          (anch.dist >= _kHoldMoveM
              ? safarBearingBetween(anch.anchor, pos)
              : null);
    }
    setState(() {
      _pos = pos;
      if (candidate != null) {
        _displayBearing = _hasBearing
            ? safarLerpBearing(_displayBearing, candidate, _kBearingLerp)
            : candidate;
        _hasBearing = true;
      }
      // Heading-up camera: sirf asal drive ki raftaar (> 1.5 m/s)
      // par taaza hoti hai; rukne par aakhri simt hi rehti hai.
      if (speed > _kCameraSpeedMps && _hasBearing) {
        _camBearing = _displayBearing;
      }
    });
    final origin = _routeOrigin;
    if (_route == null ||
        origin == null ||
        const ll.Distance().as(ll.LengthUnit.Meter, origin, pos) > 120) {
      _fetchRoute(pos, force: _route != null);
    }
  }

  Future<void> _fetchRoute(ll.LatLng from, {required bool force}) async {
    final token = ++_fetchToken;
    final target = _target;
    final r = await RouteService.fetch(from, target, forceNetwork: force);
    if (!mounted || token != _fetchToken) return;
    setState(() {
      _route = r;
      _routeOrigin = from;
    });
  }

  /// v1.4.29: driver is waqt jis route-hisse par hai, us ka
  /// gali/sadak ka naam (steps ke road field se); na mile to
  /// agle hisse ka naam; bilkul na mile to null (chip gayab)।
  String? _currentRoad(RouteResult? route,
      ({ll.LatLng snapped, double alongM, double bearingDeg})? progress) {
    if (route == null || progress == null || !route.hasSteps) {
      return null;
    }
    String? current;
    for (final s in route.steps) {
      if (s.alongM <= progress.alongM + 5) {
        if (s.road.trim().isNotEmpty) current = s.road.trim();
      } else {
        if (current != null) return current;
        if (s.road.trim().isNotEmpty) return s.road.trim();
        break;
      }
    }
    return current;
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final target = _target;
    final route = _route;
    final pos = _pos;
    final progress =
        (route != null && pos != null) ? route.track.progressAt(pos) : null;
    final arrowPoint = progress?.snapped ?? pos;
    // v1.4.11: teer ki simt hamesha smoothed _displayBearing —
    // route-segment tarjeeh, ~12 m baseline aur hold/lerp ka
    // saara hisaab _onPos mein ho chuka hota hai.
    final arrowBearing = _displayBearing;

    // Guidance banner ka hisaab
    String? bannerMain;
    String? bannerSub;
    if (pos != null && route != null && progress != null) {
      final remaining = math.max(0.0, route.track.totalM - progress.alongM);
      bannerSub = '$_targetLabel · ${fmtDist(remaining)} ${tr('remaining')}';
      if (remaining <= 25) {
        bannerMain = widget.booking.status == 'arrived'
            ? tr('arrived_destination')
            : tr('arrived_pickup');
      } else if (route.hasSteps) {
        RouteStep? next;
        for (final s in route.steps) {
          if (!s.isArrive && s.alongM > progress.alongM + 10) {
            next = s;
            break;
          }
        }
        final arriveStep = route.steps.where((s) => s.isArrive).firstOrNull;
        if (next != null) {
          final d = next.alongM - progress.alongM;
          bannerMain = d < 40
              ? 'Ab ${next.instruction[0].toLowerCase()}${next.instruction.substring(1)}'
              : '${fmtDist(d)} baad ${next.instruction[0].toLowerCase()}${next.instruction.substring(1)}';
          // v1.4.30 (owner hukm 2026-11-11 17:12): AGLI GALI
          // ka naam PEHLE se banner mein — OSRM steps ke road
          // field se; naam na mile to kuch nahi jodte (jaali
          // naam kabhi nahi)।
          if (next.road.trim().isNotEmpty) {
            bannerSub = '$bannerSub · ${tr('next_road')}: ${next.road.trim()}';
          }
        } else if (arriveStep != null) {
          final d = math.max(0.0, arriveStep.alongM - progress.alongM);
          bannerMain = '${fmtDist(d)} baad manzil hai';
        } else {
          bannerMain = 'Manzil ${fmtDist(remaining)} door hai';
        }
      } else {
        bannerMain = 'Manzil ${fmtDist(remaining)} door hai';
        bannerSub = '$_targetLabel · seedha rasta (offline)';
      }
    }

    final linePoints = route?.points ??
        (pos != null
            ? [pos, target]
            : [
                ll.LatLng(b.pickupLat, b.pickupLng),
                if (b.hasDropPin) ll.LatLng(b.dropLat, b.dropLng),
              ]);

    // v1.4.42 (H2 — owner hukm 2026-11-13 02:33; zoom owner
    // hukm 2026-11-13 03:10 par aur barhaya gaya): GALI-LEVEL
    // NAV ZOOM — driver door se galiyon ka hisaab nahi laga
    // sakta, is liye follow camera street-level 19.0 par
    // rehta hai (heading-up follow ke saath); agla mor
    // 150 m se qareeb ajaye to zoom aur qareeb — 19.5।
    // Passenger ka poora-route overview is se bilkul
    // alag hai aur pehle jaisa hi hai।
    var navZoom = 19.0;
    if (route != null && progress != null && route.hasSteps) {
      for (final s in route.steps) {
        if (!s.isArrive && s.alongM > progress.alongM + 10) {
          if (s.alongM - progress.alongM < 150) navZoom = 19.5;
          break;
        }
      }
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: SizedBox(
            height: 300,
            child: Stack(
              children: [
                Positioned.fill(
                  child: SafarMapView(
                    center: pos ?? target,
                    initialZoom: 14,
                    tilt: 55,
                    // v1.4.29 A/B USOOL: pickup ki taraf ja rahe
                    // hon to target "A" pin hai; ride shuru hone
                    // (arrived) ke baad manzil "B" pin hai —
                    // bilkul spec ki tartib।
                    pickup: b.status == 'arrived' ? null : target,
                    drop: b.status == 'arrived' ? target : null,
                    routePoints: linePoints.length > 1 ? linePoints : null,
                    position: arrowPoint,
                    positionBearing: arrowBearing,
                    // v1.4.32 PHOTO-PIN: pickup marhale mein
                    // sawari ki photo us ke intezaar wale maqam
                    // par; arrived ke baad pin NAHI (sawari
                    // gaari mein hai)।
                    photoPinAt:
                        b.status == 'arrived' ? null : target,
                    photoPinPng: widget.passengerPhotoPng,
                    // v1.4.11: heading-up camera SIRF is nav view
                    // mein — _camBearing _onPos mein speed-gated
                    // hai (rukne par jama rehta hai).
                    cameraBearing: _camBearing,
                    positionOnline: widget.driverOnline,
                    followPosition: _follow,
                    // v1.4.42 (H2): gali-level follow zoom
                    // (19.0; mor qareeb ho to 19.5)।
                    followZoom: navZoom,
                    // v1.4.42 FOLLOW: camera ka nishana
                    // gaari se 70 m AAGE — teer markaz se
                    // neeche rehta hai, aage ka rasta zyada
                    // nazar ata hai; har fix par smooth pan
                    // (animateCamera), jump nahi।
                    followForwardOffsetM: 70,
                    // User map ko haath se hila de to
                    // follow toot jata hai — pill bhi sach
                    // bolegi (OFF); usi pill ko dabane se
                    // follow dobara lock ho jata hai।
                    onFollowPaused: () {
                      if (mounted && _follow) {
                        setState(() => _follow = false);
                      }
                    },
                    interactive: true,
                    fitToRoute: pos == null,
                  ),
                ),
                if (bannerMain != null)
                  Positioned(
                    top: 8,
                    left: 8,
                    right: 64,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: Brand.deepGreen.withOpacity(0.96),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Brand.gold, width: 1),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.navigation,
                              color: Brand.goldLight, size: 26),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(bannerMain,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 15.5,
                                        fontWeight: FontWeight.w800)),
                                if (bannerSub != null)
                                  Text(bannerSub,
                                      style: const TextStyle(
                                          color: Brand.goldLight,
                                          fontSize: 12)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                // v1.4.29 (spec NAV VIEW): maujooda gali ka naam
                // chip mein — route ke steps se (driver jis hisse
                // par hai, usi ka road name); naam na mile to chip
                // gayab। Speed-limit badge NAHI lagaya — OSRM se
                // speed-limit data nahi milta, jaali adad dikhana
                // mana hai (notes mein darj)।
                if (_currentRoad(route, progress) != null)
                  Positioned(
                    bottom: 8,
                    left: 8,
                    child: Container(
                      constraints: const BoxConstraints(maxWidth: 210),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.72),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.signpost,
                              size: 14, color: Colors.white70),
                          const SizedBox(width: 5),
                          Flexible(
                            child: Text(_currentRoad(route, progress)!,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700)),
                          ),
                        ],
                      ),
                    ),
                  ),
                Positioned(
                  bottom: 8,
                  right: 8,
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () => setState(() => _follow = !_follow),
                      borderRadius: BorderRadius.circular(20),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: _follow
                              ? Brand.green
                              : Colors.white.withOpacity(0.92),
                          borderRadius: BorderRadius.circular(20),
                          border:
                              Border.all(color: Brand.greenDark, width: 0.6),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.my_location,
                                size: 15,
                                color: _follow
                                    ? Colors.white
                                    : Brand.greenDark),
                            const SizedBox(width: 5),
                            Text(_follow ? 'Follow ON' : 'Follow OFF',
                                style: TextStyle(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w700,
                                    color: _follow
                                        ? Colors.white
                                        : Brand.greenDark)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        // v1.4.29 INFO PATTI (spec NAV VIEW): baqi doori ·
        // baqi waqt · pahunchne ka time + neeche progress line।
        // Waqt route ke kul duration ko baqi hisse ke tanasub
        // se andaza lagata hai (asal route data se — jaali
        // adad nahi)।
        if (route != null && progress != null && pos != null) ...[
          const SizedBox(height: 8),
          Builder(builder: (_) {
            final total = route.track.totalM;
            final remainM = math.max(0.0, total - progress.alongM);
            final frac = total > 0
                ? (progress.alongM / total).clamp(0.0, 1.0).toDouble()
                : 0.0;
            final remainS = route.durationS > 0 && total > 0
                ? route.durationS * (remainM / total)
                : 0.0;
            final eta = DateTime.now()
                .add(Duration(seconds: remainS.round()));
            String two(int v) => v.toString().padLeft(2, '0');
            return Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Brand.green.withOpacity(0.35)),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.route,
                              size: 16, color: Brand.greenDark),
                          const SizedBox(width: 5),
                          Text(fmtDist(remainM),
                              style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14.5)),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.schedule,
                              size: 16, color: Brand.greenDark),
                          const SizedBox(width: 5),
                          Text(
                              remainS >= 60
                                  ? '~${(remainS / 60).ceil()} min'
                                  : '< 1 min',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14.5)),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.flag,
                              size: 16, color: Brand.greenDark),
                          const SizedBox(width: 5),
                          Text('${two(eta.hour)}:${two(eta.minute)}',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14.5)),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: frac,
                      minHeight: 5,
                      color: const Color(0xFF00C853),
                      backgroundColor: const Color(0xFFE3EFE7),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
        // v1.4.29: "Open another navigation app" row — driver
        // chahe to bahari maps app mein maujooda hadaf khole
        // (geo intent; na khule to Google Maps ka web rasta)।
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () async {
                final t = _target;
                try {
                  await launchUrl(
                    Uri.parse(
                        'geo:${t.latitude},${t.longitude}?q=${t.latitude},${t.longitude}'),
                    mode: LaunchMode.externalApplication,
                  );
                } catch (_) {
                  try {
                    await launchUrl(
                      Uri.parse(
                          'https://www.google.com/maps/dir/?api=1&destination=${t.latitude},${t.longitude}'),
                      mode: LaunchMode.externalApplication,
                    );
                  } catch (_) {}
                }
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.black12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.open_in_new,
                        size: 17, color: Brand.greenDark),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(tr('open_other_nav'),
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 13.5)),
                    ),
                    const Icon(Icons.chevron_right,
                        size: 18, color: Colors.black38),
                  ],
                ),
              ),
            ),
          ),
        ),
        if (_noGps)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              tr('gps_needed'),
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
          )
        else if (pos == null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              tr('location_waiting'),
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ),
      ],
    );
  }
}
