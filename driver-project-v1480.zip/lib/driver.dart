import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart' as ll2;
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'data_export.dart';
import 'display_prefs.dart';
import 'store.dart';
import 'theme.dart';
import 'route_service.dart';
import 'agent_section.dart';
import 'legal.dart';
import 'safar_map.dart';
import 'photo_pin.dart';
import 'backend.dart';
import 'duty_service.dart';
import 'registration.dart';
import 'login_page.dart';
import 'guide_audio.dart';
import 'voice.dart';
import 'voice_nav.dart';
import 'messages.dart';
import 'health_engine.dart';
import 'ride_chat.dart';
import 'lang.dart';
import 'liveness_selfie.dart';
import 'notifications.dart';
import 'otp.dart';
import 'permissions.dart';
import 'selfie_gate.dart';
import 'vehicle_change.dart';
import 'pool_filter.dart';
import 'profile_photo.dart';
import 'main.dart' show ModeToggleButton, UpdateBanner;
import 'passenger.dart' show kStatusUrdu;

class DriverSide extends StatefulWidget {
  final AppStore store;
  final VoidCallback onSwitchToPassenger;
  const DriverSide(
      {super.key, required this.store, required this.onSwitchToPassenger});

  @override
  State<DriverSide> createState() => _DriverSideState();
}

class _DriverSideState extends State<DriverSide>
    with NotificationBannerMixin, WidgetsBindingObserver {
  // v1.4.77 GUIDE S1/S13: bottom navigation ab CHAAR tab —
  // 0 Home | 1 My Rides | 2 Wallet | 3 Profile। Pool aur
  // Bookings My Rides ke andar do hisse hain ([_ridesShowPool])।
  int _tab = 0;
  bool _ridesShowPool = false;
  final ImagePicker _picker = ImagePicker();

  // v1.4.78 IN-APP PERMISSIONS: ijazaton ki taaza haalat ka
  // cache — Home ke alert banner aur "Online Hone ki
  // Shartein" wale card ke liye (asal screen permissions.dart
  // ki PermissionsPage hai)। Null = abhi parhi NAHI gayi —
  // is haalat mein banner ijazat wali khabar NAHI deta।
  PermSnapshot? _permSnap;

  // v1.4.0 two-phone live dispatch: duty ke doran location timer —
  // har ~20 second GPS le kar backend drivers row (lat/lng/loc_at)
  // aur chal rahi ride ke row (driver_lat/lng) ko taaza rakhta hai.
  Timer? _dutyTimer;
  bool _dutyTickBusy = false;

  /// v1.4.57 (Part 5): navigation stream se store mein
  /// aakhri dafa jagah kab darj hui — nav wala store-write
  /// ab doori (≥ 10 m) AUR waqt (≥ 3 s) dono gate se hota
  /// hai (backend par 3 s se zyada baar-baar write NAHI)।
  DateTime? _lastNavStoreAt;

  /// v1.4.57 (Part 13): apni simt (GPS heading) — home map
  /// par apne nishan (teer/gaari) ko ghumane ke liye; GPS
  /// simt na de to aakhri simt hi rehti hai।
  double _myBearing = 0;

  // v1.4.32 PHOTO-PIN: har active ride ki sawari ka photo-pin
  // (ride id → tayyar PNG) — nav map par pickup wale maqam par
  // dikhta hai. Ek ride ke liye sirf ek dafa banta hai
  // (PhotoPin ka cache alag bhi hai); card sirf tab milta hai
  // jab ye driver us ride ka assign driver ho (passenger_card
  // RPC, v149) — doosri rides ki photo kabhi NAHI ati.
  final Map<String, Uint8List> _passengerPins = {};
  final Set<String> _pinLoading = {};

  Future<void> _ensurePassengerPin(Booking b) async {
    if (b.status != 'accepted' && b.status != 'arrived') return;
    if (_passengerPins.containsKey(b.id) || _pinLoading.contains(b.id)) {
      return;
    }
    _pinLoading.add(b.id);
    try {
      final card = await Backend.fetchPassengerCard(b.id);
      final path = card?['profile_photo_path'] as String? ?? '';
      final png = await PhotoPin.load(
          bucket: 'selfies', path: path, name: b.passengerName);
      if (png != null && mounted) {
        setState(() => _passengerPins[b.id] = png);
      }
    } finally {
      _pinLoading.remove(b.id);
    }
  }

  // v1.4.2: backend Pool feed ka timer — har ~15 second backend se
  // pending rides ki taaza list (ONLINE ho ya OFFLINE, Pool dono
  // haalton mein khulta hai). Isi ke saath offline reh gayi booking
  // pushes (outbox) ki dobara koshish bhi hoti hai.
  Timer? _poolTimer;

  /// FIX 2026-11-21 (postmortem kami #5): jin Pool rides ko
  /// driver ne Decline karke sirf apni list se hataya hai un ki
  /// ids — Pool feed har 15s par taaza list lati hai, ye set
  /// un rides ko dobara list mein ane se rokta hai. Decline
  /// pool ride ko kabhi cancel NAHI karta (woh kisi aur driver
  /// ke liye khadi rehti hai); ye sirf is phone ki local
  /// dismiss hai।
  final Set<String> _dismissedPoolIds = {};

  /// FIX 2026-11-21 (kami #7): online rehne ke doran gates ki
  /// dobara jaanch ek waqt mein ek hi chale।
  bool _gateRecheckBusy = false;

  // v1.4.7 SELFIE DEMANDS (spec §2): random schedule ki jaanch +
  // complaint demands ka backend poll — har ~45 second. Gate page
  // khula ho to dobara nahi khulta.
  Timer? _selfieTimer;
  bool _selfieGateOpen = false;
  bool _selfiePollBusy = false;

  // Driver ki apni mojooda jagah — har ride ki pickup-doori ginne aur
  // 2 km radius filter (kDriverPickupRadiusKm) ke liye. Best-effort hai:
  // ijazat/location na mile to _myPos null rehta hai aur us surat mein
  // filter NAHI lagta (saari rides dikhti hain, doori wali line par
  // "location off hai" likha aata hai) — pilot band nahi hota.
  ll2.LatLng? _myPos;
  bool _locBusy = false;

  /// v1.4.59 (Part C): apni LIVE position ki stream — home
  /// map ka teer/gaari har ~1 second khud taaza hota hai
  /// (sirf display; backend par likhna duty tick ka kaam
  /// hai, us ki cadence/gates bilkul NAHI badle)।
  StreamSubscription<Position>? _posSub;

  /// Registration wizard is app session mein khud khula ya nahi —
  /// dobara dobara khud nahi khulta (Home/Profile par us ka card
  /// button hamesha maujood hai).
  bool _wizardPrompted = false;

  /// FINAL-PACK A2 (REJECT AWAAZ): rejected documents ke set ka
  /// aakhri announce shuda signature (group names ki jod, misal
  /// 'cnic,gaari,selfie'). Signature wohi rahe to awaaz DOBARA
  /// nahi bajti — har rebuild / har Profile visit par repeat
  /// mana hai; set badle (naya reject ya resubmit) to naya
  /// signature banta hai.
  String _lastRejectSig = '';

  AppStore get store => widget.store;
  DriverProfile get p => store.profile;

  // v1.4.27 (#23): ghanti/push par tap → ride ki darkhwast
  // (rideOpenSignal)। Ride Pool mein khadi ho to Pool tab,
  // driver ki apni bookings mein ho to Bookings tab khul
  // jata hai। Cold start wali darkhwast initState ke aakhir
  // mein ek dafa jaanchi jati hai।
  int _rideOpenSeenSeq = 0;

  void _onRideOpenRequest() {
    final seq = rideOpenSignal.seq;
    if (seq == _rideOpenSeenSeq) return;
    _rideOpenSeenSeq = seq;
    final id = rideOpenSignal.rideId;
    if (id == null || !mounted) return;
    if (store.remotePool.any((b) => b.id == id)) {
      rideOpenSignal.consume();
      setState(() {
        _tab = 1;
        _ridesShowPool = true;
      });
    } else if (store.bookings.any((b) => b.id == id)) {
      rideOpenSignal.consume();
      setState(() {
        _tab = 1;
        _ridesShowPool = false;
      });
    }
  }

  void _onMarkerPrefChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    MarkerPrefs.notifier.removeListener(_onMarkerPrefChanged);
    rideOpenSignal.removeListener(_onRideOpenRequest);
    cancelNotificationBanners();
    _dutyTimer?.cancel();
    _poolTimer?.cancel();
    _selfieTimer?.cancel();
    _posSub?.cancel();
    super.dispose();
  }

  /// v1.4.78: app dobara saamne aye (masalan Settings se
  /// ijazat de kar wapas) to ijazaton ki haalat taaza —
  /// banner/readiness foran durust ho jayein।
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(_refreshPermSnap());
    }
  }

  /// v1.4.78: ijazaton ki asal haalat system se parh kar
  /// cache mein rakho (khamosh nakami — purani haalat hi
  /// rehti hai)।
  Future<void> _refreshPermSnap() async {
    try {
      final s = await AppPerms.load();
      if (mounted) setState(() => _permSnap = s);
    } catch (_) {}
  }

  /// v1.4.78: PEHLI DAFA wala khud-kar prompt — registration
  /// mukammal ho aur koi lazmi ijazat baqi ho to Permissions
  /// screen khud khul jati hai। Sirf EK dafa (parchah
  /// mehfooz rehta hai); driver baad mein Profile/Settings
  /// se hamesha khol sakta hai। Registration adhoori ho to
  /// wizard pehle — prompt agli dafa ke liye reh jata hai।
  Future<void> _maybePromptPermissions() async {
    if (!mounted || !p.registrationDone) return;
    if (await AppPerms.introSeen()) return;
    final s = await AppPerms.load();
    if (mounted) setState(() => _permSnap = s);
    await AppPerms.markIntroSeen();
    if (!s.hasPendingWork || !mounted) return;
    await _openPermissions();
  }

  /// v1.4.78: Permissions screen kholo — wapas ane par
  /// haalat taaza (banner/readiness foran badal jayein)।
  Future<void> _openPermissions() async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => const PermissionsPage(),
    ));
    await _refreshPermSnap();
  }

  /// Banner ki maujooda khabar ijazat wali hai? Ho to tap
  /// seedha Permissions screen kholta hai, warna hamesha
  /// ki tarah Tafseel page।
  bool _alertIsPerm(String text) =>
      text == tr('perm_banner_loc') || text == tr('perm_banner_notif');

  /// v1.4.7: selfie demands ki ek jaanch — (1) complaint demands
  /// ka backend poll (driver_selfies ki baqi rows), (2) duty par
  /// ho to random schedule ka waqt, (3) demand ho to gate page।
  /// Chalti ride ke beech random demand NAHI khulti (safety) —
  /// store.dueRandomSelfie yehi shart rakhta hai; complaint
  /// demand ride ke beech bhi NAHI rokti, woh ride ke baad ke
  /// gate par ati hai (poll use darj kar deta hai, gate tab
  /// khulta hai jab koi active ride na ho — neeche wali shart)।
  Future<void> _selfieCheck() async {
    if (_selfiePollBusy || !mounted) return;
    if (store.driverId.isEmpty || !p.registrationComplete) return;
    _selfiePollBusy = true;
    try {
      final onRideNow = store.bookings.any(
          (b) => b.status == 'accepted' || b.status == 'arrived');
      if (store.currentSelfieDemand == null) {
        final pending = await Backend.fetchPendingSelfieDemands(
            store.driverId);
        if (pending != null && pending.isNotEmpty) {
          final r = pending.first;
          store.setSelfieDemand(SelfieDemand(
            kind: (r['kind'] as String?) ?? 'random',
            date: (r['date'] as String?) ?? AppStore.todayKey(),
            complaintId: (r['complaint_id'] as String?) ?? '',
          ));
        }
      }
      if (store.currentSelfieDemand == null && p.online) {
        await store.ensureRandomSelfieSchedule();
        final due = store.dueRandomSelfie(onRideNow: onRideNow);
        if (due != null) {
          store.setSelfieDemand(due);
          unawaited(Backend.insertSelfieDemand(
            driverId: store.driverId,
            date: due.date,
            kind: 'random',
          ));
        }
      }
      if (store.currentSelfieDemand != null && !onRideNow) {
        await _maybeOpenSelfieGate();
      }
    } catch (_) {
      // Selfie jaanch ki nakami khamosh — agli tick dobara hogi।
    } finally {
      _selfiePollBusy = false;
    }
  }

  Future<void> _maybeOpenSelfieGate() async {
    if (_selfieGateOpen || !mounted) return;
    final demand = store.currentSelfieDemand;
    if (demand == null) return;
    _selfieGateOpen = true;
    final done = await Navigator.of(context).push<bool>(MaterialPageRoute(
      builder: (_) => SelfieGatePage(store: store, demand: demand),
    ));
    _selfieGateOpen = false;
    if (!mounted) return;
    setState(() {});
    // INKAR PAR OFFLINE (malik ka hukm 2026-11-21): gate
    // selfie diye baghair band ho jaye (wapas ka button,
    // blocked haalat mein OK dabana, ya page ka hat jana)
    // aur demand abhi bhi baqi ho, aur driver duty par ho,
    // to woh KHUD-BA-KHUD offline ho jata hai — wajah screen
    // par saaf ati hai (_recheckOnlineGates wala wohi
    // andaaz)। Chalti ride ke beech offline NAHI karte
    // (gate waisay bhi ride ke beech nahi khulta)।
    if (done == true || store.currentSelfieDemand == null || !p.online) {
      return;
    }
    final onRide = store.bookings
        .any((b) => b.status == 'accepted' || b.status == 'arrived');
    if (onRide) return;
    p.online = false;
    await store.save();
    unawaited(_syncDutyService());
    if (!mounted) return;
    setState(() {});
    if (p.selfieBlocked) {
      final leftMs =
          p.selfieBlockUntilMs - DateTime.now().millisecondsSinceEpoch;
      _snack(leftMs >= 120 * 60 * 1000
          ? trf('sf_offline_blocked_hours',
              {'hours': '${(leftMs / 3600000).ceil()}'})
          : trf('sf_offline_blocked',
              {'mins': '${(leftMs / 60000).ceil()}'}));
    } else {
      _snack(tr('sf_offline_refused'));
    }
  }

  @override
  void initState() {
    super.initState();
    rideOpenSignal.addListener(_onRideOpenRequest);
    WidgetsBinding.instance
        .addPostFrameCallback((_) => _onRideOpenRequest());
    _refreshMyLocation();
    // v1.4.59 (Part C): LIVE position stream — home map par
    // apna nishan har ~1 second khud taaza (neeche dekhein)।
    unawaited(_startLivePosition());
    // v1.4.0: foreground notification banners + elanaat pull +
    // apna rating ausat (Profile ke liye) + duty location timer.
    listenNotificationBanners(store);
    unawaited(Backend.syncFeeSettlements(store));
    unawaited(Backend.syncAmanatDeposits(store));
    unawaited(Backend.refreshAnnouncements(store));
    unawaited(Backend.pullOwnRatingAverage(store));
    unawaited(store.observeBookingStatuses('driver'));
    // v1.4.57 (Part 5): duty tick 20 s → 5 s — teer qadam-
    // qadam chale, lambi khamoshi ke baad chhalang NA mare
    // (asli write-gate _dutyTick ke andar hai: aam duty 5 s,
    // active ride ~3 s)।
    // v1.4.62: timer 5 s → 3 s — taaki active ride par _dutyTick
    // ka 3 s wala write-gate asal mein chal sake (pehle timer hi
    // 5 s ka tha, is liye sawari ko jagah ~15 s dair se milti thi);
    // aam duty par gate 5 s hi rehta hai, zyada write nahi hoti।
    _dutyTimer = Timer.periodic(
        const Duration(seconds: 3), (_) => unawaited(_dutyTick()));
    // v1.4.57 (Part 13): apne nishan ki pasand badle to
    // driver ki screens foran taaza।
    MarkerPrefs.notifier.addListener(_onMarkerPrefChanged);
    // v1.4.2: Pool feed foran + har ~15s — doosre phones ki rides
    // ab asal mein is phone tak pohanchti hain (dispatch fix #1).
    unawaited(Backend.refreshRemotePool(store));
    _poolTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      unawaited(Backend.refreshRemotePool(store));
      // FIX 2026-11-21 (kami #7/#12): online ho to gates ki
      // dobara jaanch, aur reh gaya agent code pakka karne ki
      // dobara koshish — dono best-effort/khamosh।
      unawaited(_recheckOnlineGates());
      unawaited(Backend.retryPendingAgentCode(store));
      unawaited(Backend.syncRideOutbox(store));
      // LIVE CHAT: Master ke jawabat bhi isi chakkar se ate hain
      // (naya jawab = store notification + banner + Madad badge).
      unawaited(Backend.syncMessages(store));
    });
    // v1.4.7: selfie demands ka timer — pehli jaanch foran,
    // phir har ~45 second (random waqt + complaint poll)।
    _selfieTimer = Timer.periodic(
        const Duration(seconds: 45), (_) => unawaited(_selfieCheck()));
    WidgetsBinding.instance
        .addPostFrameCallback((_) => unawaited(_selfieCheck()));
    // v1.4.5: app dobara khuli aur driver pehle se ONLINE hai
    // (duty ki haalat mehfooz rehti hai) to duty service bhi
    // dobara chalu — warna app restart ke baad khabar band rehti.
    if (p.online) unawaited(_syncDutyService());
    // Registration baqi ho to Driver Mode mein ate hi Yango-style
    // registration form khud khul jata hai (ek dafa, is session mein).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // FINAL-PACK A2: DriverSide pehle se Profile tab par khule
      // (tab ki haalat mehfooz ho) to reject awaaz yahin se baje.
      if (mounted && _tab == 3) _announceRejectedDocs();
      // v1.4.68 AASAN MODEL: wizard khud-ba-khud sirf tab khulta
      // hai jab ID bani hi NAHI ho (!registrationDone)। ID ban
      // jane ke baad baqi documents Home ki checklist se lagte
      // hain — wizard dobara khol kar driver ko pareshan NAHI
      // kiya jata (purana registrationComplete wala gate isi
      // liye badla: woh har session mein wizard khol deta tha,
      // jabke checklist wala rasta ab maujood hai)।
      if (mounted && !p.registrationDone && !_wizardPrompted) {
        _wizardPrompted = true;
        _openRegistration();
      }
    });
    // v1.4.78 IN-APP PERMISSIONS: ijazaton ki haalat parho
    // (banner + readiness card ke liye), app wapas ane par
    // dobara parhne ke liye observer lagao, aur pehli-dafa
    // wala khud-kar prompt dekho (registration mukammal ho
    // to hi — warna wizard pehle hai)।
    WidgetsBinding.instance.addObserver(this);
    unawaited(_refreshPermSnap());
    WidgetsBinding.instance
        .addPostFrameCallback((_) => unawaited(_maybePromptPermissions()));
  }

  /// Duty location timer ka ek chakkar (v1.4.0): driver ONLINE ho
  /// to GPS le kar —
  ///  1) store.noteDriverLocation drivers row par lat/lng/loc_at
  ///     PATCH karwata hai (halki si, sirf location);
  ///  2) agar koi ride chal rahi hai (accepted/arrived) to us ke
  ///     backend row par driver_lat/driver_lng bhi likhta hai,
  ///     taaki passenger ke phone par ETA taaza rahe.
  /// Offline ho to kuch nahi hota. Har nakami khamosh.
  Future<void> _dutyTick() async {
    if (_dutyTickBusy || !p.online) return;
    final last = store.lastLocationPushAt;
    // v1.4.32 LIVE: active ride chal rahi ho to push ka waqfa
    // ~3s — sawari ko driver ki jagah takreeban LIVE mile.
    // v1.4.57 (Part 5): aam duty par bhi waqfa 15 s → 5 s —
    // teer atak kar chhalang na mare, qadam-qadam chale;
    // backend write ki hadd phir bhi yehi gate hai (3 s se
    // zyada baar-baar kabhi NAHI)। Nav view ki har GPS
    // harkat bhi yahi tick bulati hai।
    final hasActiveRide = store.bookings
        .any((b) => b.status == 'accepted' || b.status == 'arrived');
    final minGapSec = hasActiveRide ? 3 : 5;
    if (last != null &&
        DateTime.now().difference(last).inSeconds < minGapSec) {
      return;
    }
    _dutyTickBusy = true;
    try {
      double? lat, lng;
      final pos = await Geolocator.getLastKnownPosition();
      if (pos != null) {
        lat = pos.latitude;
        lng = pos.longitude;
      }
      final fresh = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      lat = fresh.latitude;
      lng = fresh.longitude;
      // v1.4.57 (Part 13): GPS simt mile to apne nishan ke
      // liye mehfooz — home map ka teer/gaari is par ghumta
      // hai (simt na mile to purani simt barkarar)।
      if (fresh.heading >= 0) _myBearing = fresh.heading;
      store.noteDriverLocation(lat, lng);
      if (mounted) {
        setState(() => _myPos = ll2.LatLng(lat!, lng!));
      }
      final actives = store.bookings
          .where((b) => b.status == 'accepted' || b.status == 'arrived')
          .toList();
      for (final b in actives) {
        await Backend.pushRideDriverPosition(store, b.id, lat, lng);
      }
    } catch (_) {
      // Khamosh — GPS na mile to agla chakkar dobara koshish karega.
    } finally {
      _dutyTickBusy = false;
    }
  }

  /// LOGIN darwaza (v1.4.47 — malik ka hukm 2026-11-22):
  /// maujooda account walon ke liye — mobile number ya Gmail
  /// + OTP se purana account is phone par ajata hai, dobara
  /// registration NAHI bharna parta। Home/Profile ke
  /// registration cards par registration button ke bilkul
  /// neeche numaya button hai।
  Future<void> _openLogin() async {
    final ok = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => DriverLoginPage(store: store),
      ),
    );
    if (ok == true && mounted) setState(() {});
  }

  /// Registration wizard (v1.2.6) full-screen kholna — Home aur
  /// Profile dono ke registration card yahin ate hain.
  Future<void> _openRegistration() async {
    await Navigator.of(context).push(
      MaterialPageRoute<bool>(
        builder: (_) => RegistrationWizard(store: store),
      ),
    );
    // Wizard band hone par sirf display taaza karna hai — Profile
    // mein ab koi editing controllers nahi hain (FORM USOOL
    // 2026-11-08: Profile sirf status + button hai), is liye koi
    // controller-sync ki zaroorat nahi.
    if (mounted) setState(() {});
  }

  /// Master ko Message screen (v1.2.7) — Profile se khulti hai.
  Future<void> _openMessages() async {
    await Navigator.of(context).push(
      MaterialPageRoute<bool>(
        builder: (_) => MasterMessagesScreen(store: store, role: 'driver'),
      ),
    );
    if (mounted) setState(() {});
  }

  /// DriverNavView (safar_map.dart) wala hi tareeqa: pehle last known,
  /// phir ek dafa ki taaza position. Koi stream nahi — Bookings tab
  /// khulne par dobara refresh ho jata hai. Har nakami khamosh hai.
  Future<void> _refreshMyLocation() async {
    if (_locBusy) return;
    _locBusy = true;
    try {
      final service = await Geolocator.isLocationServiceEnabled();
      if (!service) return;
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        return;
      }
      final last = await Geolocator.getLastKnownPosition();
      if (last != null && mounted) {
        setState(
            () => _myPos = ll2.LatLng(last.latitude, last.longitude));
        // Store mein bhi darj — passenger ki "driver kitni door hai"
        // wali line aur backend drivers.lat/lng isi se chalte hain.
        store.setDriverPosition(last.latitude, last.longitude);
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      if (mounted) {
        if (pos.heading >= 0) _myBearing = pos.heading;
        setState(() => _myPos = ll2.LatLng(pos.latitude, pos.longitude));
        store.setDriverPosition(pos.latitude, pos.longitude);
      }
    } catch (_) {
      // Khamosh — position na mile to filter nahi lagta.
    } finally {
      _locBusy = false;
    }
  }

  /// v1.4.59 (Part C — malik ka hukm 2026-11-16): LIVE
  /// position stream — driver ke HOME map par us ka apna
  /// nishan (teer/gaari) har ~1 second KHUD taaza hota
  /// rahe, baghair haath lagaye। Passenger side wale hi
  /// khamosh usool: service/ijazat na mile to kuch nahi
  /// hota (one-shot + duty tick pehle ki tarah chalte
  /// hain)। Ye stream SIRF display ke liye hai — backend
  /// par location likhna duty tick (_dutyTick) ka kaam
  /// hai, us ki cadence aur gates bilkul NAHI badle;
  /// store.setDriverPosition sirf local record hai (jo
  /// _refreshMyLocation pehle se karta aya hai)। Map ki
  /// Part 5 wali smoothing dikhne wali jagah ko fixes ke
  /// darmiyan glide karti hai — nishan chhalang NAHI
  /// marta।
  Future<void> _startLivePosition() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return;
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        return;
      }
      _posSub = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 5,
        ),
      ).listen((pos) {
        if (!mounted) return;
        if (pos.heading >= 0) _myBearing = pos.heading;
        setState(() => _myPos = ll2.LatLng(pos.latitude, pos.longitude));
        store.setDriverPosition(pos.latitude, pos.longitude);
      });
    } catch (_) {
      // Khamosh — stream na mile to one-shot/duty tick hi hai।
    }
  }

  /// Booking ki pickup tak ki doori (km) driver ki apni jagah se.
  /// null = hisaab nahi ho sakta — ya driver ki position maloom nahi,
  /// ya booking ke paas pickup pin/coords hi nahi (0,0).
  double? _pickupDistanceKm(Booking b) {
    final pos = _myPos;
    if (pos == null) return null;
    if (b.pickupLat == 0 && b.pickupLng == 0) return null;
    return const ll2.Distance().as(ll2.LengthUnit.Kilometer, pos,
        ll2.LatLng(b.pickupLat, b.pickupLng));
  }

  /// Abhi available (pending) rides — is phone ki local bookings
  /// AUR backend Pool feed ki doosre phones wali rides, dono par
  /// POOL SARHADEIN (v1.4.27, postmortem #16 — pool_filter.dart):
  /// sirf apni gaari (vehicle) ki, apne sheher ki, aur doori gin
  /// sake to 2 km ke andar wali rides dikhti hain; doori na gin
  /// sake to ride dikhti hai lekin claim par rukawat ati hai
  /// (_accept mein poolClaimBlockReason)। Pool screen, Bookings
  /// ki incoming list aur nav badges teeno yahi ek list istemal
  /// karte hain (v1.4.2 dispatch fix: pehle sirf local list thi,
  /// is liye doosre phone ki ride driver tak pohanchti hi nahi thi).
  List<Booking> get _availableRides => [
        ...store.bookings.where((b) => b.status == 'pending'),
        // FIX 2026-11-21 (kami #5): remotePool se sirf PENDING
        // rides aur woh bhi jo driver ne Decline karke dismiss
        // na ki hon — pehle status ki koi filter hi nahi thi,
        // is liye declined/guzri hui ride card agle refresh tak
        // khada rehta tha।
        ...store.remotePool.where((b) =>
            b.status == 'pending' && !_dismissedPoolIds.contains(b.id)),
      ]
          .where((b) => poolRideVisible(
                b,
                driverVehicle: store.profile.vehicle,
                driverZone: store.profile.zone,
                distanceKm: _pickupDistanceKm(b),
                radiusKm: store.profile.radiusKm,
              ))
          .toList();

  /// "Sawari kitni door hai" wala MATAN — incoming/active cards
  /// ki line aur Pool card (v1.4.36) ki pickup meta line dono
  /// yahi istemal karti hain. Location off ho to wohi saaf likha
  /// aata hai; pickup pin na ho to sirf pickup ka label/ilaqa।
  String _pickupDistanceText(Booking b) {
    if (_myPos == null) return tr('drv_sawari_ki_doori_location');
    final d = _pickupDistanceKm(b);
    return d == null
        ? trf('drv_sawari', {'pickupLabel': b.pickupLabel})
        : trf('drv_sawari_km_door', {'p1': d.toStringAsFixed(1)});
  }

  /// "Sawari kitni door hai" wali line — incoming aur active dono
  /// cards par. Location off ho to wohi saaf likha aata hai; pickup
  /// pin na ho to sirf pickup ka label/ilaqa dikhta hai.
  Widget _pickupDistanceLine(Booking b) {
    final String text = _pickupDistanceText(b);
    return Row(
      children: [
        const Icon(Icons.near_me, size: 17, color: Brand.green),
        const SizedBox(width: 6),
        Expanded(
          child: Text(text,
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: Theme.of(context).colorScheme.primary)),
        ),
      ],
    );
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  /// FINAL-PACK A2 — REJECT AWAAZ (driver Profile): Profile tab
  /// khulte hi Master ke reject shuda documents ki rehnumai
  /// wali awaazein (GuideAudio) tartib se chalti hain:
  ///   cnic rejected    → reject_cnic_front + reject_cnic_back
  ///   gaari rejected   → reject_vehicle + reject_vehicle_reg
  ///   licence rejected → reject_licence
  ///   registration mukammal (flag) lekin profile selfie baqi
  ///                    → reject_selfie
  ///   PTA reject       → KOI line nahi (usool).
  /// Jo group driver ne dobara bhej diya ho (docGroupResubmitted)
  /// woh announce NAHI hota. Awaaz har dafa nahi bajti: rejected
  /// set ka signature [_lastRejectSig] mein rehta hai — wohi set
  /// dobara aye to khamoshi.
  void _announceRejectedDocs() {
    final clips = <String>[];
    final sigParts = <String>[];
    void addGroup(String group, List<String> groupClips) {
      if (p.masterStatusFor(group) == 'rejected' &&
          !p.docGroupResubmitted(group)) {
        clips.addAll(groupClips);
        sigParts.add(group);
      }
    }

    addGroup('cnic', const [
      'guidance/reject_cnic_front.mp3',
      'guidance/reject_cnic_back.mp3',
    ]);
    addGroup('gaari', const [
      'guidance/reject_vehicle.mp3',
      'guidance/reject_vehicle_reg.mp3',
    ]);
    addGroup('licence', const [
      'guidance/reject_licence.mp3',
    ]);
    // Selfie: registration ka flag mukammal ho lekin ID wali
    // profile photo hi na ho — ye registrationComplete getter se
    // NAHI parkha jata (us mein photo khud shart hai, woh kabhi
    // trigger hi na hota); flag + khaali path hi asal surat hai.
    if (p.registrationDone && p.profilePhotoPath.isEmpty) {
      clips.add('guidance/reject_selfie.mp3');
      sigParts.add('selfie');
    }
    // PTA reject par koi awaaz nahi — jaan boojh kar khaali.
    final sig = sigParts.join(',');
    if (sig == _lastRejectSig) return;
    _lastRejectSig = sig;
    if (clips.isEmpty) return;
    GuideAudio.playSequence(clips);
  }

  /// Duty on/off (v1.2.5 — malik ka hukm). Offline karna hamesha
  /// seedha hai. Online (duty) hone se pehle do darwaze hain:
  ///  1) PASSWORD: set na ho to pehle SET karna lazmi hai (backend
  ///     uniqueness check ke saath — ek password sirf ek driver ka);
  ///     set ho to is session mein ek dafa likhna lazmi hai; 5 ghalat
  ///     koshishon par 10 minute ka lockout.
  ///  2) ROZANA LIVE SELFIE: aaj ki selfie na ho to camera wahi
  ///     khulta hai — selfie ke baghair duty shuru nahi hoti.
  /// Dono pass hon tab hi online hota hai.
  /// v1.4.5 DUTY SERVICE ko duty ki haalat se jodna: online →
  /// foreground service (location + nayi ride ki ghanti, app band
  /// ho tab bhi); offline → service band. Notification ki ijazat
  /// (Android 13+) pehli dafa yahin mangi jati hai — na mile to
  /// wajah saaf bata kar service phir bhi chalu rehti hai (ghanti
  /// nahi bajegi, location chalega).
  Future<void> _syncDutyService({bool askPermission = false}) async {
    if (!p.online) {
      await DutyService.stop();
      return;
    }
    if (askPermission) {
      final granted = await DutyService.ensureNotificationPermission();
      if (!granted && mounted) {
        _snack(
            tr('drv_notification_ki_ijazat_band'));
      }
    }
    await DutyService.startOrUpdate(
      mode: 'driver',
      driverId: store.driverId,
      radiusKm: store.profile.radiusKm,
      // FIX 2026-11-21: ghanti ke filter ke liye driver ki gaari
      // aur sheher bhi service ko — baghair in ke ghanti har
      // ride par bajti thi।
      vehicle: store.profile.vehicle,
      zone: store.profile.zone,
      watch: DutyService.watchFromStore(store),
      title: tr('drv_bozdar_safar_aap_duty'),
      text: tr('drv_nayi_rides_ki_khabar'),
    );
  }

  /// ONLINE GATE RECHECK (fix 2026-11-21 — postmortem kami #7):
  /// pehle ID-active / kagaz / balance ki jaanch sirf online
  /// honay ke waqt (aur ride qubool karne par) hoti thi — duty
  /// ke beech Master ID band kar de, kagaz reject kar de ya
  /// balance khatam ho jaye to driver "online" khada rehta tha
  /// aur us ki location bhi jati rehti thi. Ab har pool chakkar
  /// (~15s) par wohi taaza jaanch dobara chalti hai jo
  /// _toggleOnline karta hai (refreshDriverStatus +
  /// syncFeeSettlements + syncAmanatDeposits); koi gate band
  /// mile to driver KHUD-BA-KHUD offline ho jata hai aur wajah
  /// screen par saaf ati hai. Chalti hui ride (accepted/arrived)
  /// ke beech offline NAHI karte — woh ride mukammal honay ke
  /// baad accept/online ke aam gates waisay hi rok laga dete
  /// hain; yahan sirf haalat taaza kar di jati hai. Jaanch ki
  /// nakami (internet na ho) par driver offline NAHI hota.
  Future<void> _recheckOnlineGates() async {
    if (_gateRecheckBusy || !mounted || !p.online) return;
    if (store.driverId.isEmpty) return;
    _gateRecheckBusy = true;
    try {
      await Backend.refreshDriverStatus(store);
      await Backend.syncFeeSettlements(store);
      await Backend.syncAmanatDeposits(store);
      if (!mounted || !p.online) return;
      String? reason;
      if (!p.masterActive) {
        reason =
            'Master ne aap ki ID band kar di hai. Tafseel ke liye Master se rabta karein.';
      }
      reason ??= store.docBlockReason();
      reason ??= store.depositBlockReason();
      reason ??= store.feeBlockReason();
      if (reason == null) return;
      final onRide = store.bookings.any(
          (b) => b.status == 'accepted' || b.status == 'arrived');
      if (onRide) return;
      p.online = false;
      await store.save();
      unawaited(_syncDutyService());
      if (mounted) {
        setState(() {});
        _snack('Aap ko offline kar diya gaya hai — $reason');
      }
    } catch (_) {
      // Khamosh — agli tick par dobara jaanch hogi।
    } finally {
      _gateRecheckBusy = false;
    }
  }

  Future<void> _toggleOnline() async {
    if (p.online) {
      p.online = false;
      await store.save();
      unawaited(_syncDutyService());
      if (mounted) setState(() {});
      return;
    }
    // v1.4.7 SELFIE GATE (spec §2): demand baqi ho ya selfie
    // block laga ho to duty NAHI chalti — pehle selfie।
    if (p.selfieBlocked) {
      final mins = ((p.selfieBlockUntilMs -
                  DateTime.now().millisecondsSinceEpoch) /
              60000)
          .ceil();
      // Lamba block (random check wala — 6 GHANTE) ghanton
      // mein saaf dikhao; aadhe ghante wala purana jumla
      // minuteon mein hi rahe।
      _snack(mins >= 120
          ? trf('drv_ghalat_selfie_hours',
              {'hours': '${(mins / 60).ceil()}'})
          : trf('drv_ghalat_selfie_ki_wajah', {'mins': '$mins'}));
      return;
    }
    if (store.currentSelfieDemand != null) {
      _snack(tr('drv_pehle_live_selfie_dein'));
      unawaited(_maybeOpenSelfieGate());
      return;
    }
    // ID-ACTIVE GATE sab se pehle (v1.4.1 — Owner Tasdeeq Duty):
    // Master ki tasdeeq ke baghair driver ONLINE hi nahi ho sakta.
    // Khamosh nakami bilkul nahi — wajah wala tay shuda jumla
    // screen par saaf ata hai.
    if (!p.masterActive) {
      _snack(tr('drv_aap_ki_id_abhi'));
      return;
    }
    // ZONE GATE (malik ka hukm 2026-11-21): driver ka apna ilaqa
    // band ho to ONLINE nahi — ilaqa Master kholta hai. Account
    // har sheher mein ban sakta hai, duty sirf khule ilaqe mein.
    // FAIL-CLOSED (fix 2026-11-21 — postmortem kami #3): pehle
    // sheher khaali ho to gate bilkul skip ho jata tha, aur
    // server se haalat ane se pehle (cold start) saare sheher
    // khule samjhe jate thay. Ab teenon haalaton mein rok hai:
    if (p.zone.isEmpty) {
      // (a) Sheher darj hi nahi — profile adhoora hai।
      _snack(
          'Aap ke profile mein sheher (ilaqa) darj nahi hai — pehle Profile se apna sheher mukammal karein, phir online hon.');
      return;
    }
    if (!store.zonesLoadedFromServer) {
      // (b) Server se ilaqon ki haalat abhi tak pakki taur par
      // nahi ayi aur mehfooz shuda haalat bhi nahi — rabta lazmi।
      _snack(
          'Ilaqon ki haalat abhi server se nahi ayi — internet on karke chand second intezaar karein, phir dobara koshish karein.');
      return;
    }
    if (!store.zoneNames.contains(p.zone)) {
      // (c) Apna sheher band hai (ya server par hai hi nahi =
      // band hi gina jata hai)।
      _snack(tr('drv_zone_band'));
      return;
    }
    // v1.4.18 KAGAZ GATE (postmortem fix): ID active hone ke baad
    // Master kisi lazmi kagaz ko reject kar de (ya CNIC ki
    // tasdeeq adhoori reh jaye) to ONLINE hona band — pehle ye
    // haalat sirf "Mere Kagaz" mein dikhti thi, rok nahi thi.
    // Faisla taaza tareen haalat par ho: pehle status pull.
    await Backend.refreshDriverStatus(store);
    if (!mounted) return;
    setState(() {});
    final docBlock = store.docBlockReason();
    if (docBlock != null) {
      _snack(docBlock);
      return;
    }
    // NUMBER TABDEELI BLOCK (2026-11-08): number badla ho to
    // 12 ghante online hona band — baqi waqt paighaam mein hai.
    final numBlock = store.numberBlockReason();
    if (numBlock != null) {
      _snack(numBlock);
      return;
    }
    // DEVICE TABDEELI BLOCK (2026-11-08): doosri device par
    // account khula ho to 6 ghante online hona band.
    final devBlock = store.deviceBlockReason();
    if (devBlock != null) {
      _snack(devBlock);
      return;
    }
    // FEE HISAAB TAZA: Master ki tasdeeq shuda settlements
    // taaza kar lein taaki Wallet ka hisaab durust rahe aur
    // settle-limit wala block (fix 2026-11-21 — feeBlockReason
    // ab feeDue settle limit tak pahunche to asal wajah deta
    // hai) taaza tareen number par lage।
    await Backend.syncFeeSettlements(store);
    if (!mounted) return;
    final feeBlock = store.feeBlockReason();
    if (feeBlock != null) {
      setState(() {});
      _snack(feeBlock);
      return;
    }
    // AMANAT GATE (v1.4.21 — malik ka faisla 2026-11-10 20:05):
    // Master-darj deposit jama taaza karke balance ki shart —
    // balance ≤ 0 ho to ONLINE nahi ho sakta; pehle Rs 500
    // top-up (wasool honay par Master darj karega).
    await Backend.syncAmanatDeposits(store);
    if (!mounted) return;
    final depBlock = store.depositBlockReason();
    if (depBlock != null) {
      setState(() {});
      _snack(depBlock);
      return;
    }
    // Lockout chalu ho to password ka darwaza hi band hai.
    if (p.pwdFp.isNotEmpty && p.pwdLocked) {
      final mins =
          ((p.pwdLockUntilMs - DateTime.now().millisecondsSinceEpoch) /
                  60000)
              .ceil();
      _snack(
          trf('drv_zyada_ghalat_koshishen_kuch', {'mins': '$mins'}));
      return;
    }
    if (p.pwdFp.isEmpty) {
      final ok = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _SetPasswordDialog(store: store),
      );
      if (ok != true || !mounted) return;
      // RC2 follow-through (v1.2.9): naya password isi waqt backend
      // drivers row par bhi darj ho jaye taaki row phone se peeche
      // na reh jaye. Registration mukammal ho chuki ho to ensure
      // row ka bhi dobara jaiza — warna sirf fingerprint ki PATCH;
      // dono best-effort aur khamosh (duty flow nahi rukta).
      if (p.registrationComplete) {
        unawaited(Backend.ensureDriverRow(store));
      } else {
        unawaited(Backend.pushDriverFingerprint(store));
      }
    } else if (!store.dutyUnlocked) {
      final ok = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _AskPasswordDialog(store: store),
      );
      if (!mounted) return;
      if (ok != true) {
        if (p.pwdLocked) {
          _snack(tr('drv_zyada_ghalat_koshishen_kuch_2'));
        }
        return;
      }
    }
    // FINAL-PACK C-PD — LAZMI PASSWORD CHANGE: Master ne aarzi
    // password lagaya ho (must_change_password) to driver ne wohi
    // aarzi password likh kar unlock to kar liya, lekin ONLINE
    // hone se PEHLE apna naya password lagana lazmi hai. Dialog
    // barrierDismissible:false hai aur us mein koi "rehne dein"
    // wala rasta nahi — baghair change kiye ye flow yahin ruk
    // jata hai, duty aage NAHI barhti.
    if (p.mustChangePassword) {
      final changed = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _MustChangePasswordDialog(store: store),
      );
      if (changed != true || !mounted) return;
    }
    // v1.4.7 EMAIL OTP DARWAZA (spec §1): logout ke baad dobara
    // login par — password ke baad — usi Gmail par aya OTP lazmi
    // hai. Apne band phone par roz ke istemal mein (session
    // verified) ye darwaza NAHI ata. Legacy driver (email verify
    // hi nahi hua) par bhi ye gate NAHI lagta — us ke liye
    // Profile mein email darj karne ka card hai।
    if (p.emailVerified && !p.otpSessionVerified) {
      final ok = await Navigator.of(context).push<bool>(MaterialPageRoute(
        builder: (_) =>
            OtpGatePage(email: p.email, title: tr('drv_email_otp_tasdeeq')),
      ));
      if (ok != true || !mounted) {
        if (mounted) {
          _snack(tr('drv_email_otp_tasdeeq_ke'));
        }
        return;
      }
      p.otpSessionVerified = true;
      await store.save();
      // v1.4.14: OTP kamyabi = session mehfooz ho chuka hai —
      // ab is phone ki driver pehchan Auth pehchan se bandh do
      // (identity_links)।
      unawaited(Backend.linkIdentities(store));
      if (!mounted) return;
    }
    if (!p.selfieToday) {
      final take = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(tr('drv_pehle_aaj_ki_selfie')),
          content: Text(
              tr('drv_duty_shuru_karne_se')),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: Text(tr('veh_dialog_cancel'))),
            ElevatedButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: Text(tr('drv_selfie_lein'))),
          ],
        ),
      );
      if (take != true || !mounted) return;
      final selfieDone = await _takeSelfie();
      if (!mounted) return;
      // Selfie na bani ho to duty shuru nahi hogi — wajah
      // _takeSelfie har nakami par KHUD batata hai (cancel,
      // ghalat selfie ki ginti, jaanch error; HOTFIX v1.2.9
      // ka "wajah lazmi" wala usool wahin mehfooz hai);
      // yahan aam jumla sirf us haalat ke liye hai jahan
      // selfie ho kar bhi aaj ki darj na hui ho.
      if (!p.selfieToday) {
        if (selfieDone) _snack(tr('drv_selfie_ke_baghair_duty'));
        return;
      }
    }
    p.online = true;
    await store.save();
    // v1.4.8: duty-on = driver login ka lamha — is build ka
    // version code backend mein report (Master ko nazar aye ke
    // kaun purani app par hai); guarded, duty flow nahi rukta।
    unawaited(Backend.reportAppVersion(store));
    // v1.4.7: duty shuru — aaj ka random selfie schedule khud
    // ban jata hai (waqt driver ko pehle se pata NAHI hota)।
    unawaited(store.ensureRandomSelfieSchedule());
    unawaited(_syncDutyService(askPermission: true));
    if (mounted) setState(() {});
  }

  Future<void> _changePassword() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => _ChangePasswordDialog(store: store),
    );
    if (ok == true && mounted) {
      _snack(tr('drv_password_badal_gaya'));
      setState(() {});
    }
  }

  /// DRIVER ACCOUNT DELETE (v1.4.16) — sawari wale flow ka
  /// hum-manzar (legal.dart ka _deleteAccount):
  ///   0) Gmail verify shuda lazmi (tasdeeq ka rasta wohi hai)।
  ///   1) Tasdeeqi dialog — asal behavior ki saaf wazahat:
  ///      server par pehchan (naam/mobile/CNIC/email/password)
  ///      khatam, documents/selfies ke record delete + un ke
  ///      raste band (asal SQL bucket ki FILES delete NAHI
  ///      karta — v1.4.25 mein dialog ka lafz isi sach ke
  ///      mutabiq kiya gaya), ID band; rides/fee ka hisaab
  ///      baghair pehchan ke Master ke record mein mehfooz;
  ///      dobara ana ho to poori registration + Master Tasdeeq
  ///      naye sire se hogi।
  ///   2) OTP se dobara tasdeeq (OtpGatePage)।
  ///   3) Server RPC `delete_my_driver_account` — fail ho to
  ///      YAHEEN rukawat: saaf error, local data ko haath NAHI
  ///      lagta, deletion adhura NAHI rehta।
  ///   4) Master ko khabar (purani behavior)।
  ///   5) Local wipe (store.deleteDriverProfileLocal) + duty
  ///      service band — sab se aakhir, sirf server kamyabi par।
  Future<void> _deleteDriverAccount() async {
    final email = p.email.trim().toLowerCase();
    if (email.isEmpty || !p.emailVerified) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(tr('legal_del_verify_first_title')),
          content: Text(
              tr('drv_account_delete_karne_se'),
              style: const TextStyle(fontSize: 13.5, height: 1.45)),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(tr('legal_ok'))),
          ],
        ),
      );
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('drv_driver_account_delete_karein')),
        content: Text(
            tr('drv_aap_ki_driver_id'),
            style: const TextStyle(fontSize: 13.5, height: 1.45)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(tr('veh_dialog_cancel'))),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style:
                  ElevatedButton.styleFrom(backgroundColor: Brand.ajrakRed),
              child: Text(tr('legal_del_next'))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final verified = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => OtpGatePage(
          email: email,
          title: tr('legal_del_otp_title'),
        ),
      ),
    );
    if (verified != true || !mounted) return;
    final done = await Backend.deleteDriverAccountRemote(email);
    if (!mounted) return;
    if (!done) {
      _snack(
          tr('legal_del_server_fail'));
      return;
    }
    // Master ko khabar (local naam/number se — wipe se pehle)।
    final name = p.name.trim();
    final phone = p.phone.trim();
    await store.addMasterMessage(MasterMessage(
      id: store.newId(),
      senderKey: store.driverId,
      senderRole: 'driver',
      senderName: name,
      senderMobile: phone,
      senderZone: p.zone,
      category: 'Deegar',
      body: 'ACCOUNT DELETE: Driver ${name.isEmpty ? '(naam darj nahi tha)' : name}'
          '${phone.isEmpty ? '' : ' ($phone)'} ne OTP tasdeeq ke baad apna driver account delete kar diya hai. '
          'Server par us ki pehchan anonymize ho gayi hai aur ID band hai; rides/fee ka hisaab baghair pehchan ke record mein rahega.',
      createdAt: DateTime.now(),
    ));
    // Local wipe + duty service band — sab se aakhir।
    await store.deleteDriverProfileLocal();
    unawaited(Backend.clearSession());
    unawaited(_syncDutyService());
    if (mounted) {
      _snack(tr('drv_aap_ka_driver_account'));
      setState(() {});
    }
  }

  /// Rozana duty selfie — LIVE, sirf camera se। Returns:
  /// selfie darj ho gayi ya nahi — har nakami ki wajah yahin
  /// se jati hai, is liye caller doosra paighaam sirf khaas
  /// haalat mein deta hai।
  Future<bool> _takeSelfie() async {
    try {
      // v1.4.79 LIVENESS (malik ka hukm 2026-11-24): rozana
      // selfie bhi ab asal liveness flow (liveness_selfie.dart)
      // se — gold dayra, random LEFT/RIGHT hidayat, ML Kit
      // head-pose jaanch; tasveer sirf tamam harkatein durust
      // honay par banti hai। Nateejay ki mapping purani hi hai:
      // - cancelled (camera band / ijazat nahi) → ginti NAHI,
      //   sirf wajah wala paighaam (v1.2.9 wala rawaiya)।
      // - error (camera/detector na chala) → ginti NAHI,
      //   sirf dobara ka paighaam; selfie darj nahi hoti।
      // - failed (harkat waqt par na hui / chehra nazar na
      //   aya) → ghalat selfie ki warn ginti
      //   (noteSelfieMismatch — 3 par aadha ghanta block;
      //   rozana selfie par purana usool hi hai) aur block
      //   backend par bhi darj (pushSelfieBlockUntil,
      //   fail-soft); wajah (lv_fail_*) paighaam ke shuru mein।
      // - success → purani warnings saaf, selfie darj
      //   (setSelfie → wohi purana upload rasta: bucket
      //   'selfies', <driver_id>/<date>.jpg, driver_selfies)।
      final live = await runLivenessSelfie(context);
      if (!mounted) return false;
      if (live.outcome == LivenessOutcome.cancelled) {
        _snack(tr('sf_note_cancelled'));
        return false;
      }
      if (live.outcome == LivenessOutcome.error) {
        _snack(tr('sf_note_check_error'));
        return false;
      }
      if (live.outcome == LivenessOutcome.failed) {
        final reason =
            live.noteKey != null ? '${tr(live.noteKey!)} ' : '';
        final blocked = await store.noteSelfieMismatch();
        if (!mounted) return false;
        if (blocked) {
          unawaited(Backend.pushSelfieBlockUntil(
              store.driverId, store.profile.selfieBlockUntilMs));
          _snack('$reason${tr('sf_note_blocked')}');
        } else {
          final left = 3 - store.profile.selfieWarnCount;
          _snack(left <= 1
              ? '$reason${tr('sf_note_last')}'
              : '$reason${trf('sf_note_retry', {'left': '$left'})}');
        }
        return false;
      }
      p.selfieWarnCount = 0;
      await store.setSelfie(live.photoPath!);
      if (mounted) _snack(tr('drv_aaj_ki_selfie_ho'));
      return true;
    } catch (_) {
      if (mounted) _snack(tr('drv_camera_nahi_khul_saka'));
      return false;
    }
  }

  int _todayNetEarnings() {
    final now = DateTime.now();
    var sum = 0;
    for (final b in store.bookings) {
      final c = b.completedAt;
      if (b.status == 'completed' &&
          c != null &&
          c.year == now.year &&
          c.month == now.month &&
          c.day == now.day) {
        // v1.4.30: muft ride par driver ki kamai cash nahi —
        // company ki taraf se Amanat credit (freeCreditRs)
        // hai; aam ride par wohi purana (kul − fee) hisaab।
        // v1.4.57: partial-free ride par kamai = ada hissa
        // (cash) + Amanat credit − ada hissay ki fee, jo
        // (kul − effectiveFeeRs) ke ain barabar hai
        // (effectiveFeeRs ab Sahulat ki dono feerein ginata
        // hai); purani mukammal-muft records par un ka pakka
        // credit hi kamai hai।
        sum += b.isLegacyFullFree
            ? b.freeCreditRs
            : b.total - b.effectiveFeeRs;
      }
    }
    return sum;
  }

  /// v1.4.41: aaj MUKAMMAL rides ki tadaad — wohi shartein
  /// (status 'completed' + completedAt aaj ki tareekh) jo
  /// [_todayNetEarnings] ki hain; kamai wale card par kamai
  /// ke saath ye ginti bhi dikhti hai।
  int _todayCompletedRides() {
    final now = DateTime.now();
    var n = 0;
    for (final b in store.bookings) {
      final c = b.completedAt;
      if (b.status == 'completed' &&
          c != null &&
          c.year == now.year &&
          c.month == now.month &&
          c.day == now.day) {
        n++;
      }
    }
    return n;
  }

  /// v1.4.42: screen ke upar wale gol ghaira ki tasveer —
  /// driver ki apni ASAL profile photo (profile mein
  /// mehfooz local file) ho to woh, sunehre gol kinare ke
  /// saath; photo na ho/file na mile to naam ke harf wala
  /// maujooda ghaira। Jaali photo kabhi NAHI।
  Widget _headerAvatar() {
    final p = store.profile;
    // Driver ki profile photo = registration wali asal
    // selfie ka local path (DriverProfile.profilePhotoPath)।
    final path = p.profilePhotoPath;
    if (path.isEmpty) return InitialAvatar(name: p.name);
    return Container(
      width: 38,
      height: 38,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: Brand.gold, width: 1.6),
      ),
      child: ClipOval(
        child: Image.file(
          File(path),
          width: 38,
          height: 38,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => InitialAvatar(name: p.name),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final incoming = _availableRides.length;
    return Scaffold(
      body: Column(
        children: [
          // v1.4.42 HEADER SAAF (H1 aakhri revision — owner
          // hukm 2026-11-13 02:40 + 02:45): purani LAMBI
          // dark header patti (BrandHeader — logo + "Safar /
          // Bozdar" naam + DRIVER APP label + Ajrak patti)
          // POORI KHATAM. Ab screen ke upar SIRF EK cheez
          // hai: RIGHT par driver ki ASAL PROFILE PHOTO
          // wala gol ghaira (photo na ho to naam ke harf
          // wala ghaira) — na logo, na naam, na patti।
          // Avatar tap = Profile tab (A2 reject awaaz wala
          // usool barkarar)। Din/Raat map ke side controls
          // mein gol icon button hai (DisplayModeIconButton)।
          // v1.4.59 (malik ka hukm 2026-11-16): EK hi mode
          // button ab PROFILE PHOTO ke BARAABAR isi kataar
          // mein hai (hara pill — "Passenger Mode"); neeche
          // wali full-width Mode patti KHATAM, ghanti isi
          // kataar ke bayein kinare par aa gayi hai।
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
            child: Row(
              children: [
                NotificationBell(store: store, onDark: true),
                const Spacer(),
                ModeToggleButton(
                    toDriver: false, onTap: widget.onSwitchToPassenger),
                const SizedBox(width: 10),
                InkWell(
                  onTap: () {
                    setState(() => _tab = 3);
                    _announceRejectedDocs();
                  },
                  customBorder: const CircleBorder(),
                  child: _headerAvatar(),
                ),
              ],
            ),
          ),
          // v1.4.8: recommended band par banner har waqt (policy),
          // warna aam update notice apne rawaiye par.
          if (UpdatePolicy.level == 1 ||
              (store.updateAvailable && !store.updateDismissed))
            UpdateBanner(store: store),
          // v1.4.30 (owner hukm 2026-11-11 17:04): driver mode
          // ka BARA banner (ModeBanner, 170px artwork) HATA diya
          // — woh poora display gherta tha. Us ki jagah sirf
          // CHHOTI si tafseel wali patti: chhota logo nishan +
          // ek line (mode · gaari · zone). Passenger side ki
          // banner pehle hi v1.4.28 mein khatam ho chuki thi;
          // Master app ko is mein bilkul NAHI chheda gaya।
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
            child: Row(
              children: [
                Image.asset('assets/safar-logo-mark.png', height: 28),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    trf('drv_driver_mode', {'vehicle': p.vehicle, 'zone': p.zone}),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w700,
                        color: Theme.of(context).colorScheme.primary),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _tab == 0
                ? _homeMapView()
                : _tab == 1
                    ? _myRidesView()
                    : _tab == 2
                        ? _walletView()
                        : _profileView(),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) {
          setState(() => _tab = i);
          // My Rides par aate hi position taaza — doori/filter taaza rahe.
          if (i == 1) _refreshMyLocation();
          // FINAL-PACK A2: Profile tab khulte hi reject awaaz
          // (signature wohi ho to _announceRejectedDocs khud
          // khamosh rehta hai — har dafa repeat nahi hoti).
          if (i == 3) _announceRejectedDocs();
        },
        type: BottomNavigationBarType.fixed,
        // v1.4.60: nav ke rang Din/Raat se — pas-manzar theme
        // ke bottomNavigationBarTheme se ata hai।
        backgroundColor: Pal.navBg(context),
        selectedItemColor:
            Pal.isDark(context) ? Brand.brightGreen : Brand.green,
        unselectedItemColor: Pal.textSub(context),
        items: [
          const BottomNavigationBarItem(
              icon: Icon(Icons.home), label: 'Home'),
          // v1.4.77 GUIDE S13: MY RIDES — Pool (nayi rides) aur
          // Bookings (meri rides) isi ek tab ke do hisse hain;
          // badge = abhi available pool rides ki tadaad.
          BottomNavigationBarItem(
            icon: Badge(
              label: Text('$incoming'),
              isLabelVisible: incoming > 0,
              child: const Icon(Icons.directions_car),
            ),
            label: tr('my_rides'),
          ),
          const BottomNavigationBarItem(
              icon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          const BottomNavigationBarItem(
              icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  // --- HOME (v1.4.56 — malik ka hukm: full-screen map + neeche
  // bara slide control wala flow; naam, rang aur matan sab Boz
  // Safar ke apne hain): poori screen par LIVE MAP, neeche ek
  // safed panel — haalat ki patti, jaldi wale buttons ki kataar,
  // aur aakhir mein EK do-rukha SLIDE switch (bayaen = Offline,
  // dayen = Online)। Duty ka wahid control yehi slide hai — is
  // ke peeche wohi _toggleOnline hai jo hamesha se hai, saare
  // gates samet (selfie, ID active, kagaz, Amanat balance,
  // password, OTP)। Purani Home ki poori list "Tafseel" page
  // par mehfooz hai (_homeDetailView) — koi sahulat hati nahi।

  Widget _homeMapView() {
    final center = _myPos ??
        kZoneCoords[p.zone] ??
        const ll2.LatLng(24.8608, 67.0011);
    return Column(
      children: [
        Expanded(
          child: SafarMapView(
            center: center,
            // Passenger home wala hi street-level zoom/tilt
            // (17 / 0) — v1.4.60 (malik ka hukm: dono modes ka
            // map EK jaisa): pehle driver home tilt 50 par
            // khulta tha aur passenger home 0 (top-down) par;
            // ab dono ka default nazara EK hai, jhukao sirf
            // map ke 3D button se।
            initialZoom: 17,
            tilt: 0,
            interactive: true,
            // v1.4.59: HOME map — sheher wala lock (ghumao/
            // jhukao band, zoom kam se kam 10) + pehla GPS
            // fix ane par camera ek dafa zoom 16 par apni
            // jagah (map duniya par NAHI khulta)।
            cityLock: true,
            firstFixZoom: true,
            // Apni LIVE jagah + follow (M4 wala usool — bari
            // harkat par map khud center hota hai; duty tick
            // se _myPos taaza hota rehta hai)।
            myPosition: _myPos,
            followMyPosition: true,
            // v1.4.57 (Part 11 + 13): duty map par apna
            // nishan — driver ki pasand: Teer (default) ya
            // apni Gaari ka marker। Wahi jagah par neela
            // nuqta map khud daba deta hai (dohra nishan
            // NAHI); follow ke liye myPosition barkarar hai।
            // Part 5 ki smoothing is par bhi chalti hai।
            position: _myPos,
            positionBearing: _myBearing,
            positionOnline: p.online,
            positionCategory:
                MarkerPrefs.notifier.value == MarkerStyle.vehicle &&
                        p.vehicle.trim().isNotEmpty
                    ? p.vehicle
                    : null,
            // v1.4.80 DEMAND HEAT (malik ka hukm 2026-11-24):
            // map par Low→High jamni heat — ASAL maujooda
            // darkhwaston (_availableRides, backend se ayi
            // hui pool list) ke pickup maqamat se banti hai;
            // koi darkhwast na ho to heat bhi NAHI (jaali
            // rang kabhi NAHI)।
            demandPoints: [
              for (final b in _availableRides)
                if (b.pickupLat != 0 && b.pickupLng != 0)
                  ll2.LatLng(b.pickupLat, b.pickupLng),
            ],
          ),
        ),
        _homeBottomPanel(),
      ],
    );
  }

  Widget _homeBottomPanel() {
    final online = p.online;
    final alert = _homeAlertText();
    return Container(
      // v1.4.60: panel ka rang Din/Raat theme se (Pal) — raat
      // mein safed panel aankhon ko chubhta tha।
      decoration: BoxDecoration(
        color: Pal.panel(context),
        border: const Border(top: BorderSide(color: Brand.gold, width: 2)),
        boxShadow: const [
          BoxShadow(
              color: Colors.black26, blurRadius: 10, offset: Offset(0, -3)),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (alert != null) ...[
                _homeAlertBanner(alert),
                const SizedBox(height: 10),
              ],
              // v1.4.77 GUIDE S8: selected vehicle + service
              // area hamesha nazar — driver ko pata ho kis
              // gaari par aur kis ilaqe mein duty hai।
              Row(
                children: [
                  const Icon(Icons.directions_car,
                      size: 17, color: Brand.green),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      '${tr('guide_selected_vehicle')}: ${p.vehicle}${p.vehicleBrand.isEmpty ? '' : ' · ${p.vehicleBrand} ${p.vehicleModel}'}${p.plate.isEmpty ? '' : ' · ${p.plate}'}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 12.5, fontWeight: FontWeight.w800),
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Icon(Icons.location_on,
                      size: 16, color: Brand.green),
                  const SizedBox(width: 3),
                  Text(
                    p.zone.isEmpty ? '—' : p.zone,
                    style: const TextStyle(
                        fontSize: 12.5, fontWeight: FontWeight.w800),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              // Haalat ki patti: duty ki haalat + aaj ki kamai
              // (aur rides) + wallet balance। Gehri sabz satah
              // par safed/sunehri likhai — TEXT DARK usool ke
              // mutabiq parhne mein saaf।
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                decoration: BoxDecoration(
                  color: Brand.deepGreen,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 11,
                      height: 11,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: online ? Brand.brightGreen : Brand.goldLight,
                      ),
                    ),
                    const SizedBox(width: 7),
                    Text(
                      online
                          ? tr('drv_slide_on_word')
                          : tr('drv_slide_off_word'),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.trending_up,
                                  color: Brand.gold, size: 16),
                              const SizedBox(width: 4),
                              Text(rs(_todayNetEarnings()),
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w900)),
                            ],
                          ),
                          Text(
                              trf('drv_aaj_rides_done',
                                  {'count': '${_todayCompletedRides()}'}),
                              style: const TextStyle(
                                  color: Brand.goldLight,
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                    Container(
                      width: 1,
                      height: 30,
                      color: Colors.white24,
                      margin: const EdgeInsets.symmetric(horizontal: 10),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(rs(p.walletBalance),
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.w900)),
                        Text(tr('drv_wallet_balance'),
                            style: const TextStyle(
                                color: Brand.goldLight,
                                fontSize: 10.5,
                                fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              // Jaldi wale buttons ki kataar — purani Home ki
              // har numaya sahulat yahin se ek tap par; baqi
              // poori list "Tafseel" chip se khulti hai।
              SizedBox(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    _quickChip(
                        icon: Icons.support_agent,
                        label: tr('drv_chip_madad'),
                        onTap: _openMessages,
                        badge: store.unreadMasterReplies),
                    _quickChip(
                        icon: Icons.construction,
                        label: tr('drv_chip_band_sadak'),
                        onTap: _showRoadReportDialog),
                    _quickChip(
                        icon: Icons.calendar_month,
                        label: tr('drv_monthly_packages'),
                        onTap: () async {
                          await Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => _MonthlyPackagesPage(store: store),
                          ));
                          if (mounted) setState(() {});
                        }),
                    _quickChip(
                        icon: Icons.emergency,
                        label: tr('drv_chip_sos'),
                        iconColor: Brand.ajrakRed,
                        onTap: _sosFromHome),
                    _quickChip(
                        icon: Icons.pool,
                        label: tr('drv_chip_pool'),
                        onTap: () {
                          setState(() {
                            _tab = 1;
                            _ridesShowPool = true;
                          });
                          _refreshMyLocation();
                        }),
                    _quickChip(
                        icon: Icons.notifications_active,
                        label: tr('my_rides'),
                        onTap: () {
                          setState(() {
                            _tab = 1;
                            _ridesShowPool = false;
                          });
                          _refreshMyLocation();
                        }),
                    _quickChip(
                        icon: Icons.account_balance_wallet,
                        label: tr('drv_chip_wallet'),
                        onTap: () => setState(() => _tab = 2)),
                    _quickChip(
                        icon: Icons.person,
                        label: tr('drv_chip_profile'),
                        onTap: () {
                          setState(() => _tab = 3);
                          _announceRejectedDocs();
                        }),
                    _quickChip(
                        icon: Icons.list_alt,
                        label: tr('drv_chip_tafseel'),
                        onTap: _openHomeDetail),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              // DUTY KA WAHID CONTROL — do-rukha slide switch
              // (koi doosra on/off button kahin nahi)।
              DutySlideSwitch(online: online, onToggle: _toggleOnline),
            ],
          ),
        ),
      ),
    );
  }

  /// Map Home ki numaya khabar: koi block laga ho to us ki
  /// wajah, warna registration/ID tasdeeq ki haalat। Tap par
  /// Tafseel page khulta hai (wajah + hal wahan maujood hain)।
  /// Koi khabar na ho to null — patti banti hi nahi।
  String? _homeAlertText() {
    // v1.4.77 GUIDE S8: rok ki wajah hamesha saaf — number/
    // device/fee ke baad ab kagaz (docBlock), Amanat
    // (deposit), selfie aur zone ki wajahen bhi yahin ati
    // hain (woh gate jo _toggleOnline asal mein lagata hai)।
    final block = store.numberBlockReason() ??
        store.deviceBlockReason() ??
        store.feeBlockReason() ??
        store.docBlockReason() ??
        store.depositBlockReason();
    if (block != null) return block;
    if (p.selfieBlocked) return tr('guide_selfie_blocked');
    if (store.currentSelfieDemand != null) {
      return tr('guide_selfie_demand');
    }
    if (!p.registrationComplete) return tr('drv_registration_baqi_hai');
    if (!p.masterActive) return tr('drv_aap_ki_id_abhi');
    if (p.zone.isNotEmpty &&
        store.zonesLoadedFromServer &&
        !store.zoneNames.contains(p.zone)) {
      return tr('drv_zone_band');
    }
    // v1.4.78 IN-APP PERMISSIONS: ijazat ki khabar SAB SE
    // AAKHIR mein — sirf tab jab baqi tamam gates saaf hon।
    // Ye koi naya gate NAHI hai (_toggleOnline bilkul
    // waisa hi hai); sirf wajah + seedha hal (tap par
    // Permissions screen) ek jagah mil jata hai।
    final snap = _permSnap;
    if (snap != null && !snap.locGranted) return tr('perm_banner_loc');
    if (snap != null && !snap.notifGranted) {
      return tr('perm_banner_notif');
    }
    return null;
  }

  Widget _homeAlertBanner(String text) {
    // v1.4.60: alert patti bhi Din/Raat se — raat mein gehri
    // surkh-bhoori satah + saaf halka text (khabar numaya
    // rehti hai, chubhti NAHI)।
    final dark = Pal.isDark(context);
    return Material(
      color: dark ? const Color(0xFF3A2225) : const Color(0xFFFBEAEA),
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        // v1.4.78: ijazat wali khabar par tap seedha
        // Permissions screen kholta hai (hal wahin hai)।
        onTap: _alertIsPerm(text) ? _openPermissions : _openHomeDetail,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              Icon(Icons.info_outline,
                  color: dark ? const Color(0xFFE88A8A) : Brand.ajrakRed,
                  size: 22),
              const SizedBox(width: 9),
              Expanded(
                child: Text(text,
                    style: TextStyle(
                        fontSize: 13,
                        height: 1.35,
                        color: Pal.text(context),
                        fontWeight: FontWeight.w700)),
              ),
              Icon(Icons.chevron_right,
                  color: dark ? const Color(0xFFE88A8A) : Brand.ajrakRed),
            ],
          ),
        ),
      ),
    );
  }

  /// Purani Home ki poori list ek alag page par (Tafseel)।
  void _openHomeDetail() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => Scaffold(
        appBar: AppBar(title: Text(tr('drv_home_detail_title'))),
        body: _homeDetailView(),
      ),
    ));
  }

  /// SOS — Profile wala hi rasta (showSosDialog): ride chal
  /// rahi ho to us ride ke saath, warna baghair ride ke; jagah
  /// profile ki aakhri jagah se jati hai।
  void _sosFromHome() {
    Booking? active;
    for (final x in store.bookings) {
      if (x.status == 'accepted' ||
          x.status == 'arrived' ||
          x.status == 'started') {
        active = x;
        break;
      }
    }
    showSosDialog(context,
        store: store,
        role: 'driver',
        booking: active,
        lat: p.lastLat,
        lng: p.lastLng);
  }

  Widget _quickChip({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    Color iconColor = Brand.green,
    int badge = 0,
  }) {
    // v1.4.60: chip ke rang Din/Raat se (Pal) — din mein wahi
    // halki sabz chip, raat mein gehri sabz chip + saaf text।
    final dark = Pal.isDark(context);
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: Material(
        color: dark ? const Color(0xFF1F3D2C) : const Color(0xFFE7F2EC),
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Pal.divider(context)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: 19, color: iconColor),
                const SizedBox(width: 6),
                Text(label,
                    style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: Pal.text(context))),
                if (badge > 0) ...[
                  const SizedBox(width: 6),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                    decoration: BoxDecoration(
                        color: Brand.ajrakRed,
                        borderRadius: BorderRadius.circular(9)),
                    child: Text('$badge',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w900)),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  // --- HOME TAFSEEL (v1.4.56): purani Home ki poori list — ab ye
  // "Tafseel" wale page par khulti hai (map wale naye Home se chip
  // ke zariye). Is ke tamam cards/gates bilkul wohi hain jo pehle
  // Home par thay — kuch bhi hata NAHI. Sirf bare state card ka
  // Online/Offline BUTTON khatam hai: duty ka wahid control ab
  // map Home ke neeche wala do-rukha slide switch hai (malik ka
  // hukm — ek hi control, koi doosra toggle nahi)।

  /// v1.4.77 GUIDE S7: Darkhwast ki haalat wala card — Draft /
  /// Jama / Jaanch mein / Manzoor / Radd (wajah ke saath) /
  /// Band। Home ki Tafseel aur Profile dono jagah yehi card
  /// hai taaki haalat har jagah ek jaisi nazar aye। Asal
  /// haalat profile + Master ke pull shuda faislon se banti
  /// hai — jaali haalat kabhi nahi।
  Widget _applicationStatusCard() {
    String label;
    String note;
    Color color;
    IconData icon;
    final blocked =
        store.numberBlockReason() ?? store.deviceBlockReason();
    final rejectedGroups = ['cnic', 'gaari', 'licence', 'fitness', 'insurance', 'character']
        .where((g) => p.masterStatusFor(g) == 'rejected')
        .toList();
    if (blocked != null) {
      label = tr('guide_status_band');
      note = blocked;
      color = Brand.ajrakRed;
      icon = Icons.block;
    } else if (rejectedGroups.isNotEmpty) {
      label = tr('guide_status_radd');
      final reasons = rejectedGroups
          .map((g) => p.masterReasonFor(g))
          .where((r) => r.isNotEmpty)
          .join(' · ');
      note = reasons.isNotEmpty ? reasons : tr('guide_review_status_note');
      color = Brand.ajrakRed;
      icon = Icons.cancel;
    } else if (p.masterActive) {
      label = tr('guide_status_manzoor');
      note = tr('guide_review_status_note');
      color = Brand.green;
      icon = Icons.verified;
    } else if (p.registrationDone) {
      label = '${tr('guide_status_jama')} · ${tr('guide_status_jaanch')}';
      note = tr('guide_review_status_note');
      color = const Color(0xFFB8860B);
      icon = Icons.hourglass_top;
    } else {
      label = tr('guide_status_draft');
      note = tr('guide_review_status_note');
      color = const Color(0xFFB8860B);
      icon = Icons.edit_note;
    }
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 26),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('guide_status_title'),
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 12.5)),
                  const SizedBox(height: 3),
                  Text(label,
                      style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                          color: color)),
                  const SizedBox(height: 3),
                  Text(note,
                      style: const TextStyle(fontSize: 12.5, height: 1.4)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// v1.4.77 GUIDE S8: Online hone ki shartein — har shart ki
  /// asal haalat (ho gayi / baqi) ek fehrist mein: manzoor
  /// profile, manzoor gaari + durust kaghazat, GPS, internet,
  /// khula zone, Amanat balance, aaj ki live selfie। Ye wohi
  /// gates hain jo _toggleOnline asal mein check karta hai —
  /// ye card sirf un ki numaish hai, koi naya gate NAHI।
  Widget _guideReadinessCard() {
    Widget row(String label, bool ok) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Icon(ok ? Icons.check_circle : Icons.cancel,
                size: 19, color: ok ? Brand.green : Brand.ajrakRed),
            const SizedBox(width: 9),
            Expanded(
              child: Text(label,
                  style: const TextStyle(
                      fontSize: 13.5, fontWeight: FontWeight.w700)),
            ),
            Text(ok ? tr('agent_doc_done') : tr('guide_baqi'),
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: ok ? Brand.green : Brand.ajrakRed)),
          ],
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.fact_check, color: Brand.green, size: 22),
                const SizedBox(width: 8),
                Text(tr('guide_readiness_title'),
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 15)),
              ],
            ),
            const SizedBox(height: 6),
            row(tr('guide_req_profile'), p.masterActive),
            row(tr('guide_req_docs'),
                p.registrationComplete && store.docBlockReason() == null),
            row(tr('guide_req_gps'), _myPos != null),
            // v1.4.78: ijazaton ki satar bhi yahin — location +
            // notifications mili hon to hi durust nishan।
            row(tr('perm_req_row'),
                _permSnap != null && _permSnap!.mustHaveOk),
            row(tr('guide_req_net'), store.zonesLoadedFromServer),
            row(
                tr('guide_req_zone'),
                p.zone.isNotEmpty &&
                    store.zonesLoadedFromServer &&
                    store.zoneNames.contains(p.zone)),
            row(tr('guide_req_amanat'), store.amanatBalance > 0),
            row(tr('guide_req_selfie'),
                p.selfieToday && !p.selfieBlocked),
          ],
        ),
      ),
    );
  }

  /// v1.4.77 GUIDE S13: Profile Menu — Personal details,
  /// Documents, Vehicles, Rating, Settings, Help, Logout।
  /// Har satr maujooda asal raste par jati hai (wizard,
  /// checklist wali Home Tafseel, gaari change, settings
  /// page, Master messages, logout) — koi cheez delete
  /// NAHI hui, neeche wali poori Profile list apni jagah
  /// barkarar hai।
  Widget _guideProfileMenuCard() {
    final rating = store.backendRatingAvg ?? store.localOwnRatingAverage;
    Widget row(IconData icon, String label, String sub, VoidCallback onTap,
        {Color? color}) {
      return ListTile(
        leading: Icon(icon, color: color ?? Brand.green),
        title: Text(label,
            style: TextStyle(
                fontWeight: FontWeight.w800, color: color)),
        subtitle: sub.isEmpty ? null : Text(sub),
        trailing: const Icon(Icons.chevron_right, size: 20),
        onTap: onTap,
      );
    }

    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 2),
            child: Text(tr('guide_menu_title'),
                style: const TextStyle(
                    fontWeight: FontWeight.w900, fontSize: 15)),
          ),
          row(Icons.person, tr('guide_menu_personal'),
              '${p.name}${p.phone.isEmpty ? '' : ' · ${p.phone}'}',
              _openRegistration),
          row(Icons.folder, tr('guide_menu_docs'),
              p.registrationComplete
                  ? tr('agent_doc_done')
                  : tr('drv_registration_baqi_hai'),
              _openHomeDetail),
          row(Icons.directions_car, tr('guide_menu_vehicles'),
              '${p.vehicle}${p.plate.isEmpty ? '' : ' · ${p.plate}'}',
              () async {
                await Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => VehicleChangePage(store: store),
                ));
                if (mounted) setState(() {});
              }),
          row(Icons.star, tr('guide_menu_rating'),
              rating != null ? rating.toStringAsFixed(1) : '—', () {
            _snack(rating != null
                ? '${tr('guide_menu_rating')}: ${rating.toStringAsFixed(1)}'
                : tr('guide_menu_rating'));
          }),
          row(Icons.settings, tr('guide_menu_settings'), '',
              _openGuideSettings),
          // v1.4.78: Ijazatein — Profile Menu se hamesha
          // dastiyab (haalat + wahin se ijazat dena)।
          row(Icons.verified_user, tr('perm_title'),
              tr('perm_menu_sub'), _openPermissions),
          row(Icons.support_agent, tr('guide_menu_help'), '', _openMessages),
          row(Icons.logout, tr('guide_menu_logout'), '', _guideLogout,
              color: Brand.ajrakRed),
        ],
      ),
    );
  }

  /// v1.4.77 GUIDE S13: Settings page — zubaan, daira
  /// (radius), nishan, app ki sehat aur sharait ke darwaze
  /// (yehi cheezein Profile ki list mein bhi hain — ye page
  /// menu se seedha rasta hai)।
  Future<void> _openGuideSettings() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (ctx) => Scaffold(
        appBar: AppBar(title: Text(tr('guide_settings_title'))),
        body: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            // v1.4.78: Ijazatein — Settings se bhi hamesha
            // dastiyab; wapas ane par haalat taaza।
            Card(
              child: ListTile(
                leading:
                    const Icon(Icons.verified_user, color: Brand.green),
                title: Text(tr('perm_title'),
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(tr('perm_menu_sub')),
                trailing: const Icon(Icons.chevron_right, size: 20),
                onTap: () async {
                  await Navigator.of(ctx).push(MaterialPageRoute(
                    builder: (_) => const PermissionsPage(),
                  ));
                  await _refreshPermSnap();
                },
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: ListTile(
                leading: const Icon(Icons.language, color: Brand.green),
                title: Text(tr('language'),
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(tr('language_sub')),
                trailing: Text(
                    store.langCode == 'en' ? 'English' : 'Urdu',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                onTap: () => showLanguageChooser(
                  ctx,
                  current: store.langCode,
                  onPick: (c) => store.setLang(c),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.radar, color: Brand.green),
                        const SizedBox(width: 10),
                        Text(tr('radius_title'),
                            style: const TextStyle(
                                fontWeight: FontWeight.w800, fontSize: 15)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    StatefulBuilder(
                      builder: (ctx2, setLocal) => Wrap(
                        spacing: 8,
                        children: [
                          for (final km in kRadiusOptionsKm)
                            ChoiceChip(
                              label: Text('${km.toStringAsFixed(0)} km'),
                              selected: p.radiusKm == km,
                              onSelected: (sel) async {
                                if (!sel) return;
                                setLocal(() => p.radiusKm = km);
                                await store.save();
                                if (mounted) {
                                  setState(() {});
                                  _snack(tr('radius_saved'));
                                }
                              },
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            AppHealthTile(store: store),
            const SizedBox(height: 10),
            LegalLinksCard(
              store: store,
              driverAcceptedAtMs:
                  p.termsAcceptedAtMs > 0 ? p.termsAcceptedAtMs : null,
              showDriverTerms: true,
            ),
          ],
        ),
      ),
    ));
    if (mounted) setState(() {});
  }

  /// v1.4.77: Profile Menu ka Logout — amal bilkul wohi jo
  /// Profile ke Logout button ka hai (session OTP flag saaf,
  /// auth session saaf, duty service sync)।
  Future<void> _guideLogout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('drv_logout_karein')),
        content: Text(tr('drv_logout_ke_baad_dobara_2')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(tr('veh_dialog_cancel'))),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(tr('drv_logout_karein_2'))),
        ],
      ),
    );
    if (ok == true) {
      await store.driverLogout();
      unawaited(Backend.clearSession());
      unawaited(_syncDutyService());
      if (mounted) {
        _snack(tr('drv_logout_ho_gaya_hai'));
        setState(() {});
      }
    }
  }

  Widget _homeDetailView() {
    final online = p.online;
    final numBlock = store.numberBlockReason();
    final devBlock = store.deviceBlockReason();
    final feeBlock = store.feeBlockReason();
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        // BLOCK NOTICES: number tabdeeli (12 ghante) ya device
        // ka block laga ho to Home par sab se upar saaf notice —
        // wajah + baqi waqt ke saath. Block khatam hote hi khud
        // gayab. (Fee wala notice sirf tab ata hai jab baqi fee
        // settle limit tak pahunch jaye — fix 2026-11-21 se
        // feeBlockReason us haalat mein asal wajah deta hai;
        // limit se neeche feeBlock hamesha null rehta hai.)
        if (numBlock != null || devBlock != null || feeBlock != null) ...[
          Card(
            color: const Color(0xFFFBEAEA),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.block, color: Brand.ajrakRed, size: 26),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(numBlock ?? devBlock ?? feeBlock!,
                        style: const TextStyle(
                            fontSize: 13.5, height: 1.45, color: Brand.ink,
                            fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],
        // Registration baqi ho to sab se pehle us ka card — Yango-style
        // form yahin se khulta hai (v1.2.6). Gate ab
        // registrationComplete par hai (HOTFIX v1.2.9, RC2).
        if (!p.registrationComplete) ...[
          Card(
            color: Brand.deepGreen,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.app_registration,
                          color: Brand.gold, size: 26),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(tr('drv_registration_baqi_hai'),
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w900)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    tr('drv_driver_banne_ke_liye'),
                    style: const TextStyle(color: Colors.white, fontSize: 13),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      // v1.4.68: ID bani hui ho to button seedha
                      // Home ki documents checklist par le jata
                      // hai (wizard dobara NAHI khulta — kagazat
                      // ab wahin se lagte hain); ID hi na bani ho
                      // to purana wizard wala rasta।
                      onPressed: p.registrationDone
                          ? _scrollToChecklist
                          : _openRegistration,
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Brand.gold,
                          foregroundColor: Brand.greenDark),
                      child: Text(tr('drv_registration_mukammal_karein')),
                    ),
                  ),
                  const SizedBox(height: 8),
                  // LOGIN (v1.4.47): pehle se account walon ke
                  // liye numaya darwaza — registration ke neeche
                  // chhupa chhota link NAHI, poora button hai।
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _openLogin,
                      style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          minimumSize: const Size.fromHeight(54),
                          side: const BorderSide(color: Colors.white70)),
                      icon: const Icon(Icons.login, size: 19),
                      label: Text(tr('reg_welcome_login'),
                          style: const TextStyle(
                              fontSize: 15.5, fontWeight: FontWeight.w800)),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],
        // DOCUMENTS CHECKLIST (v1.4.68 — malik ka hukm
        // 2026-11-22): ID ban jane ke baad baqi kagazat yahin
        // Home par ek ek karke lagte hain — har qadam apna
        // card, apni haalat, apna button। Jab tak koi lazmi
        // tasveer baqi hai ye list numaya rehti hai; saari lag
        // jayein to khud ghayab ho jati hai (asal haalat phir
        // "Mere Kagaz" aur tasdeeq wale card mein dikhti hai)।
        if (p.registrationDone && _checklistHasMissing) ...[
          _docsChecklistCard(),
          const SizedBox(height: 14),
        ],
        // ID tasdeeq ka intezaar — numaya khabar (v1.4.1):
        // registration mukammal ho lekin Master ne ID active na
        // ki ho to driver ko saaf pata ho ke woh kis marhale par
        // hai — na online ho sakta hai, na ride/pool qubool.
        if (p.registrationComplete && !p.masterActive) ...[
          Card(
            color: const Color(0xFFFFF3CD),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.hourglass_top, color: Brand.ajrakRed),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tr('drv_aap_ki_id_abhi'),
                          style: const TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 15,
                              color: Brand.ink),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          p.hasRejectedDocUi
                              ? tr('drv_ek_document_reject_hua')
                              : tr('drv_documents_master_ke_paas'),
                          style: const TextStyle(
                              fontSize: 12.5, color: Brand.ink),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],
        // MADAD — SUPPORT KA EK HI DARWAZA (owner 2026-11-08):
        // driver ko Master se rabte ke liye dhoondhna NA pare —
        // Home par sab se numaya jagah saaf button; yehi wohi
        // messages wala rasta hai jo Profile se bhi khulta hai
        // (koi alag support/team NAHI — baat seedha Master se).
        Card(
          color: const Color(0xFFE7F2EC),
          child: ListTile(
            leading: const Icon(Icons.support_agent,
                color: Brand.green, size: 28),
            title: Text(tr('drv_madad_master_se_rabta'),
                style: const TextStyle(
                fontWeight: FontWeight.w900, fontSize: 15.5, color: Brand.ink)),
            subtitle: Text(
              store.unreadMasterReplies > 0
                  ? trf('drv_master_ka_naya_jawab', {'unreadMasterReplies': '${store.unreadMasterReplies}'})
                  : tr('drv_koi_masla_sawal_ya'),
              style: const TextStyle(fontSize: 12.5, color: Brand.ink),
            ),
            trailing: const Icon(Icons.chevron_right, color: Brand.green),
            onTap: _openMessages,
          ),
        ),
        const SizedBox(height: 14),
        // BAND SADAK REPORT (MAP WAVE v1.4.20, malik ka hukm
        // 2026-11-10): driver raste mein band sadak /
        // construction / diversion dekhe to ek tap mein apni
        // GPS location ke saath Master ko report — Master app
        // ki "Sadak Reports" screen mein nazar ati hai.
        Card(
          color: const Color(0xFFFFF6E0),
          child: ListTile(
            leading: const Icon(Icons.construction,
                color: Color(0xFFB8860B), size: 28),
            title: Text(tr('drv_band_sadak_report_karein'),
                style: const TextStyle(
                fontWeight: FontWeight.w900, fontSize: 15.5, color: Brand.ink)),
            subtitle: Text(
              tr('drv_raste_mein_sadak_band'),
              style: const TextStyle(fontSize: 12.5, color: Brand.ink),
            ),
            trailing:
                const Icon(Icons.chevron_right, color: Color(0xFFB8860B)),
            onTap: _showRoadReportDialog,
          ),
        ),
        const SizedBox(height: 14),
        // MONTHLY PACKAGES (v1.4.25 — postmortem #9): driver
        // apne assign shuda packages aur khule (naye) packages
        // yahan dekhta hai aur khula package apne naam pakka
        // kar sakta hai — pehle package ka driver-assign rasta
        // app mein tha hi nahi।
        Card(
          color: const Color(0xFFE7F2EC),
          child: ListTile(
            leading: const Icon(Icons.calendar_month,
                color: Brand.green, size: 28),
            title: Text(tr('drv_monthly_packages'),
                style: const TextStyle(
                fontWeight: FontWeight.w900, fontSize: 15.5, color: Brand.ink)),
            subtitle: Text(
              tr('drv_rozana_wale_pakke_packages'),
              style: const TextStyle(fontSize: 12.5, color: Brand.ink),
            ),
            trailing: const Icon(Icons.chevron_right, color: Brand.green),
            onTap: () async {
              await Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => _MonthlyPackagesPage(store: store),
              ));
              if (mounted) setState(() {});
            },
          ),
        ),
        const SizedBox(height: 14),
        // BIG state card — inDrive style.
        // v1.4.5 (B6): ONLINE par board wala sabz GRADIENT card
        // (balance card wali chamak) — offline par gehri sarmayi.
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: online ? null : const Color(0xFF5A5A5A),
            gradient: online
                ? const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Brand.brightGreen,
                      Brand.green,
                      Brand.greenDark,
                    ],
                  )
                : null,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Brand.gold, width: 2),
          ),
          child: Column(
            children: [
              Icon(online ? Icons.check_circle : Icons.do_not_disturb_on,
                  color: Colors.white, size: 44),
              const SizedBox(height: 6),
              Text(online ? tr('drv_aap_online_hain') : tr('drv_aap_offline_hain'),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w900)),
              Text(
                online
                    ? tr('drv_ride_requests_aa_sakti')
                    : tr('drv_online_honay_par_ride'),
                style: const TextStyle(color: Colors.white, fontSize: 13),
              ),
              // v1.4.56: yahan ka Online/Offline BUTTON khatam —
              // duty ka wahid control map Home ka slide switch
              // hai (ek hi control wala malik ka usool)। Ye card
              // ab sirf haalat dikhata hai।
            ],
          ),
        ),
        const SizedBox(height: 14),
        // v1.4.77 GUIDE S7 + S8: darkhwast ki haalat aur
        // online hone ki shartein — saaf fehrist mein।
        _applicationStatusCard(),
        const SizedBox(height: 10),
        _guideReadinessCard(),
        const SizedBox(height: 14),
        // inDrive D1 language: status ke foran baad aaj ki kamai +
        // wallet balance ki jhalak (top cards), phir profile/gates.
        Row(
          children: [
            Expanded(
              child: _statCard(tr('drv_aaj_ki_kamai'), rs(_todayNetEarnings()),
                  Icons.trending_up,
                  sub: trf('drv_aaj_rides_done',
                      {'count': '${_todayCompletedRides()}'})),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _statCard(
                  tr('drv_wallet_balance'), rs(p.walletBalance), Icons.wallet),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: Brand.deepGreen,
                  child: Text(
                    p.name.isNotEmpty ? p.name[0] : 'R',
                    style: const TextStyle(
                        color: Brand.gold,
                        fontSize: 22,
                        fontWeight: FontWeight.w900),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.name,
                          style: const TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w800)),
                      Text(
                          '${p.vehicle}${p.plate.isEmpty ? '' : ' · ${p.plate}'}${p.zone.isEmpty ? '' : ' · ${p.zone}'}'),
                      Text(p.zone.isEmpty ? 'Driver' : trf('drv_driver', {'zone': p.zone}),
                          style: TextStyle(
                              fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 6),
        _gateRow(
          icon: Icons.payments,
          label: trf('drv_amanat_deposit_rs', {'joiningDeposit': '${Fares.joiningDeposit}'}),
          // AMANAT GATE (v1.4.21): balance > 0 hi "ho gaya" hai —
          // balance khatam ho to online/ride band (store ka
          // depositBlockReason wohi wajah deta hai).
          done: store.amanatBalance > 0,
          doneText: trf('drv_balance', {'p1': rs(store.amanatBalance)}),
          pendingText:
              trf('drv_balance_khatam_rs_top', {'joiningDeposit': '${Fares.joiningDeposit}'}),
          // 'Wallet' wala alag button hata diya (v1.2.6 faltu-button
          // safai) — Wallet neeche wale tab se hi khulta hai.
          onFix: null,
          fixLabel: '',
        ),
        _gateRow(
          icon: Icons.camera_alt,
          label: tr('drv_aaj_ki_live_selfie'),
          done: p.selfieToday,
          doneText: tr('agent_doc_done'),
          pendingText: tr('drv_baqi_baghair_selfie_ride'),
          onFix: p.selfieToday ? null : _takeSelfie,
          fixLabel: tr('drv_selfie_lein'),
        ),
        _gateRow(
          icon: Icons.badge,
          label: tr('drv_cnic_tasdeeq'),
          // HOTFIX v1.2.9 (RC1): tasdeeq ki haalat ab sirf MASTER ke
          // pull shuda verdict se ati hai — local self-attestation
          // (cnicStatus) yahan kabhi istemal nahi hoti.
          done: p.masterCnicStatus == 'verified',
          doneText: tr('drv_master_ne_tasdeeq_kar'),
          pendingText: p.masterCnicStatus == 'rejected'
              ? tr('drv_reject_ho_gaya_sahi')
              : tr('drv_tasdeeq_baqi_hai'),
          // Registration baqi ho to ye button registration form mein
          // le jata hai (CNIC wahan jama hota hai). Registration ke
          // baad 'Profile' wala duplicate button nahi — Profile
          // neeche wale tab se khulta hai (v1.2.6 safai).
          onFix: p.registrationComplete ? null : _openRegistration,
          fixLabel: 'Registration',
        ),
        const SizedBox(height: 10),
        if (p.selfiePath.isNotEmpty && p.selfieToday)
          Card(
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(File(p.selfiePath),
                    width: 46, height: 46, fit: BoxFit.cover),
              ),
              title: Text(tr('drv_aaj_ki_selfie')),
              subtitle: Text(trf('drv_tareekh', {'selfieDate': p.selfieDate})),
            ),
          ),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text(
              trf('drv_usool_kiraya_pehle_se', {'p1': fmtPct(Fares.feePercent)}),
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ),
      ],
    );
  }

  Widget _statCard(String label, String value, IconData icon,
      {String? sub}) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Icon(icon, color: Brand.gold, size: 26),
            const SizedBox(height: 6),
            Text(value,
                style: const TextStyle(
                    fontSize: 19, fontWeight: FontWeight.w900)),
            Text(label,
                style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
            // v1.4.41: ikhtiyari dusri satar (masalan aaj ki
            // mukammal rides ki ginti kamai wale card par)।
            if (sub != null) ...[
              const SizedBox(height: 2),
              Text(sub,
                  style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700,
                      color: Theme.of(context).colorScheme.primary)),
            ],
          ],
        ),
      ),
    );
  }

  Widget _gateRow({
    required IconData icon,
    required String label,
    required bool done,
    required String doneText,
    required String pendingText,
    required VoidCallback? onFix,
    required String fixLabel,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: done ? Brand.green : Brand.ajrakRed),
        title: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(done ? doneText : pendingText),
        // onFix null ho to koi button NAHI — sirf pending ka nishan
        // (faltu navigation buttons v1.2.6 mein hata diye gaye hain;
        // Wallet/Profile neeche wale tabs se hi khulte hain).
        trailing: done
            ? const Icon(Icons.check_circle, color: Brand.green)
            : onFix != null
                ? TextButton(onPressed: onFix, child: Text(fixLabel))
                : const Icon(Icons.pending_actions,
                    color: Brand.ajrakRed),
      ),
    );
  }

  // --- POOL: khadi rides ki list (DESIGN WAVE — brief Addendum) --------------
  //
  // Pool screen mojooda nafsiati usool par bani hai:
  //  - ONLINE driver ko rides push bhi hoti hain AUR woh yahan list
  //    mein bhi khadi nazar ati hain — driver yahan se bhi utha
  //    sakta hai.
  //  - OFFLINE driver ko koi ride push NAHI hoti, lekin woh Pool
  //    mein aa kar apni pasand ki ride KHUD utha sakta hai (owner
  //    ka hukm 2026-11-07 ~22:46–22:48).
  //  - Har card par poori tafseel: passenger ka naam, pickup, drop,
  //    safar ki doori (km), sawari tak ki doori AUR tay-shuda FIXED
  //    kiraya — driver kiraya dekh kar apni marzi se uthaye ya
  //    chhor de; koi pabandi/penalty NAHI, bidding NAHI (fare lock
  //    sirf passenger side ka hai — driver ko kiraya dikhta hai).
  //  - Ride uthana wohi EK gate hai jo har accept par chalta hai
  //    (store.acceptBlockReason — ID active, deposit, aur PEHLI
  //    Pool pick par bhi rozana live selfie lazmi).
  //  - List ka source (v1.4.2): is phone ki local pending rides
  //    AUR backend Pool feed (doosre phones ki asal rides,
  //    coordinates samait) — _availableRides dono ko jodta hai.
  //  - 2 km radius filter yahan bhi wohi hai jo Bookings par hai:
  //    doori maloom ho aur radius se bahar ho to ride nahi dikhti;
  //    location off ho to sab dikhti hain (chhupana kabhi nahi).
  /// v1.4.77 GUIDE S13: MY RIDES tab — upar do hisse wali
  /// patti (Nayi Rides/Pool · Meri Rides/Bookings), neeche
  /// chuna hua hissa। Dono purani screens apni jagah hain —
  /// koi sahulat hati nahi, sirf tartib guide wali hai।
  Widget _myRidesView() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
          child: Row(
            children: [
              Expanded(
                child: _ridesShowPool
                    ? ElevatedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.pool, size: 18),
                        label: Text(tr('guide_rides_pool')),
                      )
                    : OutlinedButton.icon(
                        onPressed: () =>
                            setState(() => _ridesShowPool = true),
                        icon: const Icon(Icons.pool, size: 18),
                        label: Text(tr('guide_rides_pool')),
                      ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: !_ridesShowPool
                    ? ElevatedButton.icon(
                        onPressed: () {},
                        icon: const Icon(Icons.directions_car, size: 18),
                        label: Text(tr('guide_rides_mine')),
                      )
                    : OutlinedButton.icon(
                        onPressed: () =>
                            setState(() => _ridesShowPool = false),
                        icon: const Icon(Icons.directions_car, size: 18),
                        label: Text(tr('guide_rides_mine')),
                      ),
              ),
            ],
          ),
        ),
        Expanded(child: _ridesShowPool ? _poolView() : _bookingsView()),
      ],
    );
  }

  Widget _poolView() {
    final available = _availableRides;
    return ListView(
      key: const ValueKey('drv-tab-pool'),
      padding: const EdgeInsets.all(14),
      children: [
        Row(
          children: [
            Expanded(
              child: Text(tr('drv_ride_pool'),
                  style:
                      const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            ),
            OutlinedButton.icon(
              onPressed: () {
                _refreshMyLocation();
                unawaited(Backend.refreshRemotePool(store));
                setState(() {});
                _snack(tr('drv_pool_taaza_kar_diya'));
              },
              icon: const Icon(Icons.refresh, size: 17),
              label: const Text('Update'),
              style: OutlinedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          p.online
              ? tr('drv_aap_online_hain_nayi')
              : tr('drv_aap_offline_hain_koi'),
          style: TextStyle(fontSize: 12.5, color: Theme.of(context).colorScheme.onSurfaceVariant),
        ),
        const SizedBox(height: 4),
        Text(
          _myPos == null
              ? tr('drv_location_off_hai_apni')
              : trf('drv_sirf_aap_ki_gaari', {'p1': store.profile.radiusKm.toStringAsFixed(0)}),
          style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
        ),
        const SizedBox(height: 4),
        Text(
          tr('drv_har_ride_ka_kiraya'),
          style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w700,
              color: Theme.of(context).colorScheme.primary),
        ),
        const SizedBox(height: 10),
        if (available.isEmpty) ...[
          const SizedBox(height: 30),
          const Center(
            child: Icon(Icons.pool, size: 54, color: Colors.black26),
          ),
          const SizedBox(height: 10),
          Center(
            child: Text(
              tr('drv_abhi_koi_ride_request'),
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14.5, color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ),
        ],
        ...available.map(_poolCard),
      ],
    );
  }

  /// Pool ka ek ride card — Safar ki apni sabz-sunehri pehchan,
  /// apni tarteeb (v1.4.36, owner hukm 2026-11-12): sab se upar
  /// aur sab se BADA tay-shuda kiraya; saath sawari ka naam aur
  /// (server asal data de to) us ki rating ★ + kul rides; phir
  /// PICKUP line: A badge + pata, neeche doori (km) + asal road
  /// route ke andazan minutes; phir DROP line: B badge + pata,
  /// neeche safar ki doori (km) + andazan minutes; aakhir mein
  /// "Ride Uthayein" — wohi _accept jo Bookings par hai (saare
  /// gates samet)। Rating/rides ka data `pool_rides` RPC abhi
  /// deta NAHI hai — data na ho to woh line banti hi NAHI
  /// (jaali number kabhi NAHI)। Pool mein ride "rehne dena" koi
  /// button NAHI hai — na uthana hi driver ki marzi hai; booking
  /// kisi aur driver ke liye khadi rehti hai।
  /// TEST RIDE ka saaf nishan (v1.4.73) — Pool aur Bookings
  /// dono cards par: driver pehle hi jaan le ke ye Master ki
  /// jaanch hai, asal sawari NAHI. Qubool karna hi test hai;
  /// us ke baad ride wahin khatam ho jati hai (koi kiraya /
  /// kamai / ginti NAHI)।
  Widget _testRideBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: Brand.ajrakRed,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          const Icon(Icons.science, size: 18, color: Colors.white),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              tr('test_ride_banner'),
              style: const TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 13,
                  color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _poolCard(Booking b) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: Brand.gold, width: 2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // v1.4.30 SAHULAT: muft ride ka saaf sunehra
            // nishan — driver pehle se jane ke ye Sahulat
            // wali ride hai (inkar/ghabrahat na ho); v1.4.57
            // TWIST LOCK: is nishan par koi raqam/tafseel
            // NAHI — poora hisaab sirf completion par।
            if (b.freeRide) ...[
              Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                decoration: BoxDecoration(
                  color: Brand.gold,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.card_giftcard,
                        size: 18, color: Brand.greenDark),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        tr('sahulat_free_driver_note'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 13,
                            color: Brand.greenDark),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
            ],
            if (b.isTestRide) ...[
              _testRideBanner(),
              const SizedBox(height: 10),
            ],
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tr('drv_tay_shuda_kiraya'),
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Theme.of(context).colorScheme.onSurfaceVariant)),
                    // v1.4.36: kiraya card ki SAB SE numayan
                    // cheez — gehra sabz, aur bara।
                    Text(rs(b.fare),
                        style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.w900,
                            color: Theme.of(context).colorScheme.primary)),
                  ],
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(b.passengerName,
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w900)),
                    // v1.4.36: rating ★ + kul rides — SIRF tab
                    // jab asal data maujood ho (server se aya
                    // ho); data na ho to ye line NAHI banti।
                    if (b.passengerRatingAvg > 0) ...[
                      const SizedBox(height: 2),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.star,
                              size: 15, color: Brand.gold),
                          const SizedBox(width: 3),
                          Text(
                              b.passengerRatingAvg.toStringAsFixed(1),
                              style: const TextStyle(
                                  fontSize: 13.5,
                                  fontWeight: FontWeight.w800)),
                          if (b.passengerRidesCount > 0) ...[
                            const SizedBox(width: 6),
                            Text(
                                '· ${trf('pool_rides_count', {'p1': '${b.passengerRidesCount}'})}',
                                style: TextStyle(
                                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                                    fontSize: 12.5)),
                          ],
                        ],
                      ),
                    ],
                    if (b.passengerPhone.isNotEmpty)
                      Text(b.passengerPhone,
                          style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                    Text(fmtTime(b.createdAt),
                        style: TextStyle(
                            color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10),
            // v1.4.36 PICKUP line: A badge + pata; neeche meta
            // line — driver se pickup tak ki doori (km) + asal
            // road route ke andazan minutes wali chip (route na
            // mile to chip khamoshi se gayab — jaali waqt NAHI)।
            Row(children: [
              safarAbBadge('A', size: 24),
              const SizedBox(width: 8),
              Expanded(
                  child: Text(b.pickupLabel,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w700))),
            ]),
            const SizedBox(height: 4),
            Padding(
              padding: const EdgeInsets.only(left: 32),
              child: Wrap(
                crossAxisAlignment: WrapCrossAlignment.center,
                spacing: 8,
                runSpacing: 4,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.near_me,
                          size: 15, color: Brand.green),
                      const SizedBox(width: 4),
                      Text(_pickupDistanceText(b),
                          style: TextStyle(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w700,
                              color: Theme.of(context).colorScheme.primary)),
                    ],
                  ),
                  if (_myPos != null && b.pickupLat != 0)
                    _TargetEta(
                      from: _myPos,
                      to: ll2.LatLng(b.pickupLat, b.pickupLng),
                    ),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(left: 11),
              child: Icon(Icons.more_vert, size: 16, color: Colors.grey),
            ),
            // v1.4.36 DROP line: B badge + pata; neeche meta
            // line — gaari + safar ki doori (km) + asal road
            // route ke andazan minutes wali chip (sirf asal
            // route par; seedhi-line wale andaze par chip NAHI)।
            Row(children: [
              safarAbBadge('B', size: 24),
              const SizedBox(width: 8),
              Expanded(
                  child: Text(b.dropLabel,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w700))),
            ]),
            const SizedBox(height: 4),
            Padding(
              padding: const EdgeInsets.only(left: 32),
              child: Wrap(
                crossAxisAlignment: WrapCrossAlignment.center,
                spacing: 8,
                runSpacing: 4,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.route,
                          size: 15, color: Brand.green),
                      const SizedBox(width: 4),
                      Text(
                          trf('drv_safar_km', {
                            'p1':
                                '${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm}',
                            'vehicle': b.vehicle
                          }),
                          style: TextStyle(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w700,
                              color: Theme.of(context).colorScheme.primary)),
                    ],
                  ),
                  if (b.hasDropPin)
                    _TripEta(
                      from: ll2.LatLng(b.pickupLat, b.pickupLng),
                      to: ll2.LatLng(b.dropLat, b.dropLng),
                    ),
                ],
              ),
            ),
            if (b.note.isNotEmpty && !b.isTestRide) ...[
              const SizedBox(height: 8),
              Text(trf('drv_note', {'note': b.note}),
                  style: const TextStyle(
                      fontSize: 13, fontStyle: FontStyle.italic)),
            ],
            if (b.hasDropPin) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  height: 180,
                  child: SafarRouteMap(
                    pickup: ll2.LatLng(b.pickupLat, b.pickupLng),
                    drop: ll2.LatLng(b.dropLat, b.dropLng),
                    // v1.4.58: pins ke upar booking wale naam।
                    pickupLabel: b.pickupLabel,
                    dropLabel: b.dropLabel,
                    interactive: false,
                    // v1.4.42 (M4): driver ki apni live jagah
                    // (duty tick se taaza _myPos) ka neela
                    // nuqta bhi card ke map par।
                    myPosition: _myPos,
                    // v1.4.45: preview map ka khamosh re-route tick
                    store: store,
                  ),
                ),
              ),
            ],
            // v1.4.36: safar ki doori/gaari wali chip yahan se
            // hat gayi — woh maloomat ab DROP wali meta line
            // mein hai (upar); card saaf aur ek-nazar wala hai।
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => _accept(b),
                style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14)),
                child:
                    Text(tr('accept_ride'), style: const TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- BOOKINGS: large incoming request cards --------------------------------

  Widget _bookingsView() {
    // POOL SARHADEIN yahin lagti hain — list ki satah par
    // (_availableRides → pool_filter.dart): doosri gaari, doosre
    // sheher aur (doori gin sake to) 2 km se door ki pending
    // rides is driver ki list mein aati hi nahi; booking khud
    // kahin change/delete nahi hoti (doosra munasib driver use
    // dekh sakta hai). Location maloom na ho to ride dikhti hai
    // lekin claim _accept mein rukta hai.
    final incoming = _availableRides;
    final active = store.bookings
        .where((b) => b.status == 'accepted' || b.status == 'arrived')
        .toList();
    final past = store.bookings
        .where((b) =>
            b.status == 'completed' ||
            b.status == 'noshow' ||
            b.status == 'cancelled')
        .toList();
    return ListView(
      key: const ValueKey('drv-tab-bookings'),
      padding: const EdgeInsets.all(14),
      children: [
        Text(tr('drv_aane_wali_bookings'),
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        Text(
          _myPos == null
              ? tr('drv_location_off_hai_apni_2')
              : trf('drv_sirf_aap_ki_gaari', {'p1': store.profile.radiusKm.toStringAsFixed(0)}),
          style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
        ),
        const SizedBox(height: 8),
        if (incoming.isEmpty)
          Text(tr('drv_abhi_koi_nayi_booking'),
              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ...incoming.map(_incomingCard),
        const SizedBox(height: 16),
        Text(tr('drv_chal_rahi_rides'),
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (active.isEmpty)
          Text(tr('drv_koi_ride_chal_nahi'),
              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ...active.map(_activeCard),
        const SizedBox(height: 16),
        Text(tr('drv_purani_rides'),
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (past.isEmpty)
          Text(tr('drv_abhi_koi_purani_ride'),
              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ...past.map((b) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ListTile(
                      leading: const Icon(Icons.history, color: Brand.green),
                      title: Text('${b.pickupLabel} → ${b.dropLabel}'),
                      subtitle: Text(
                          trf('drv_km', {'p1': kStatusUrdu[b.status] ?? b.status, 'p2': fmtDate(b.completedAt ?? b.createdAt), 'p3': '${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm}'})),
                      trailing: Text(rs(b.total),
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                    // v1.4.4: wajah record mein yahan bhi saaf.
                    if (b.status == 'cancelled' &&
                        b.cancelReason.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
                        child: Text(trf('drv_mansookh_ki_wajah', {'cancelReason': b.cancelReason}),
                            style: TextStyle(
                                fontSize: 12, color: Theme.of(context).colorScheme.error)),
                      ),
                    if (b.status == 'completed' && b.endedEarly)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
                        child: Text(
                            trf('drv_sawari_ne_beech_raaste', {'p1': b.endReason.isEmpty ? '' : trf('frag_wajah_suffix', {'reason': b.endReason})}),
                            style: TextStyle(
                                fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                      ),
                    // SABOOT: is ride ki recording ho to yahan se
                    // dobara suni ja sakti hai (koi delete nahi).
                    if (b.evidenceLocalPath.isNotEmpty ||
                        b.evidenceRemotePath.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                        child: EvidencePlayRow(store: store, booking: b),
                      ),
                    // v1.4.4: mukammal ride par driver sawari ko
                    // rating de sakta hai + is ride ki report bhi.
                    if (b.status == 'completed')
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 10, 8),
                        child: Row(
                          children: [
                            Expanded(
                                child:
                                    PassengerRatingRow(store: store, booking: b)),
                            TextButton.icon(
                              onPressed: () => showReportDialog(
                                  context, store, b,
                                  role: 'driver'),
                              icon: const Icon(Icons.report_outlined,
                                  size: 16, color: Brand.ajrakRed),
                              label: Text('Report',
                                  style: TextStyle(color: Theme.of(context).colorScheme.error)),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            )),
      ],
    );
  }

  Widget _routeLines(Booking b) {
    // v1.4.29: A (pickup) / B (drop) wale kaale badge — har card
    // par wohi pehchan jo map ke pins par hai (spec 2026-11-11)।
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          safarAbBadge('A', size: 24),
          const SizedBox(width: 8),
          Expanded(
              child: Text(b.pickupLabel,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700))),
        ]),
        const Padding(
          padding: EdgeInsets.only(left: 11),
          child: Icon(Icons.more_vert, size: 16, color: Colors.grey),
        ),
        Row(children: [
          safarAbBadge('B', size: 24),
          const SizedBox(width: 8),
          Expanded(
              child: Text(b.dropLabel,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700))),
        ]),
      ],
    );
  }

  /// During-trip sheet ka bara tappable option row (spec
  /// 2026-11-11): gol icon, wazeh label, neeche chhoti wazahat,
  /// dayein chevron — poori row tap hoti hai।
  Widget _optionRow({
    required IconData icon,
    required String label,
    String? sub,
    Color? iconColor,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: const BoxDecoration(
                color: Color(0xFFF1F5F2),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 21, color: iconColor ?? Brand.greenDark),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                          fontSize: 15.5, fontWeight: FontWeight.w800)),
                  if (sub != null)
                    Text(sub,
                        style: TextStyle(
                            fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.black54),
          ],
        ),
      ),
    );
  }

  /// Waiting option ki tafseel sheet — maujooda waiting
  /// mechanism hi dikhaya jata hai: timer "Pohanch Gaya" par
  /// KHUD shuru hota hai, ride mukammal hone tak chalta hai;
  /// beech raaste ki rukawat bhi isi mein gini jati hai।
  void _showWaitingSheet(Booking b) {
    showModalBottomSheet<void>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('waiting_title'),
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text(
              trf('waiting_explain', {'n': '${Fares.freeWaitingMinutes}'}),
              style: const TextStyle(fontSize: 13, height: 1.45),
            ),
            const SizedBox(height: 12),
            _LiveWaiting(booking: b, store: store),
          ],
        ),
      ),
    );
  }

  Widget _incomingCard(Booking b) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: Brand.gold, width: 2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (b.isTestRide) ...[
              _testRideBanner(),
              const SizedBox(height: 10),
            ],
            Row(
              children: [
                Chip(
                  label: Text(tr('new_booking_chip')),
                  backgroundColor: Brand.goldLight,
                  labelStyle:
                      const TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
                ),
                const Spacer(),
                Text(fmtTime(b.createdAt),
                    style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
              ],
            ),
            const SizedBox(height: 8),
            // v1.4.77 GUIDE S9: accept timer — booking ki
            // 10-minute wali miyaad ka baqi waqt saaf nazar
            // (ghanti/vibration DutyNotify se pehle se hai)।
            _AcceptTimer(booking: b),
            const SizedBox(height: 8),
            Text(b.passengerName,
                style:
                    const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            if (b.passengerPhone.isNotEmpty)
              Text(b.passengerPhone,
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
            const SizedBox(height: 8),
            // Sawari yahan se kitni door khari hai — driver ki apni
            // mojooda jagah se pickup tak ki doori.
            _pickupDistanceLine(b),
            const SizedBox(height: 10),
            _routeLines(b),
            if (b.note.isNotEmpty && !b.isTestRide) ...[
              const SizedBox(height: 8),
              Text(trf('drv_note', {'note': b.note}),
                  style: const TextStyle(
                      fontSize: 13, fontStyle: FontStyle.italic)),
            ],
            if (b.hasDropPin) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  height: 180,
                  child: SafarRouteMap(
                    pickup: ll2.LatLng(b.pickupLat, b.pickupLng),
                    drop: ll2.LatLng(b.dropLat, b.dropLng),
                    // v1.4.58: pins ke upar booking wale naam।
                    pickupLabel: b.pickupLabel,
                    dropLabel: b.dropLabel,
                    interactive: false,
                    // v1.4.42 (M4): driver ki apni live jagah
                    // (duty tick se taaza _myPos) ka neela
                    // nuqta bhi card ke map par।
                    myPosition: _myPos,
                    // v1.4.45: preview map ka khamosh re-route tick
                    store: store,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                Chip(
                  avatar: const Icon(Icons.route, size: 16),
                  label: Text(
                      trf('drv_km_2', {'p1': '${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm}', 'vehicle': b.vehicle})),
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(tr('total_fare'),
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Theme.of(context).colorScheme.onSurfaceVariant)),
                    Text(rs(b.fare),
                        style: const TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w900)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _accept(b),
                    style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                    child:
                        Text(tr('drv_qubool_karein'), style: const TextStyle(fontSize: 16)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () async {
                      // FIX 2026-11-21 (postmortem kami #5):
                      // POOL ki ride (jo driver ne kabhi claim
                      // hi nahi ki) par Decline sirf LOCAL dismiss
                      // hai — ride kisi aur driver ke liye backend
                      // par pending hi rehti hai. Pehle ye button
                      // cancelBooking chala kar us ride ko
                      // 'cancelled' karne ki koshish karta tha jo
                      // driver ki thi hi nahi।
                      if (b.fromBackend) {
                        setState(() => _dismissedPoolIds.add(b.id));
                        store.setRemotePool(store.remotePool
                            .where((x) => x.id != b.id)
                            .toList());
                        if (mounted) _snack(tr('drv_declined_snack'));
                        return;
                      }
                      // v1.4.4: driver ride cancel kare to us se
                      // bhi WAJAH — record ke saath mehfooz rehti
                      // hai (Master ko nazar ati hai). Sheet band
                      // karne par kuch nahi hota (ride rehti hai).
                      // (Ye rasta sirf is phone ki APNI local
                      // booking ke liye hai — pool ride ke liye
                      // upar wala local-dismiss hi chalta hai।)
                      final reason = await showReasonSheet(
                        context,
                        title: tr('driver_decline_title'),
                        options: kDriverCancelReasonOptions,
                      );
                      if (reason == null) return;
                      await store.cancelBooking(b, reason: reason);
                      if (mounted) _snack(tr('drv_declined_snack'));
                      setState(() {});
                    },
                    style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                    child: Text(tr('drv_decline_btn'),
                        style: const TextStyle(fontSize: 16)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _accept(Booking b) async {
    // v1.4.27 POOL SARHADEIN (postmortem #16 — pool_filter.dart):
    // claim se PEHLE client-side pakki jaanch — gaari (vehicle)
    // match, sheher (zone) match, aur doori ki TASDEEQ lazmi
    // (doori na gin sake to claim NAHI hota; purana fail-open
    // khatam)। Server par claim_ride ka race-guard is ke upar
    // ki hifazat hai, ye us ki jagah nahi।
    final poolReason = poolClaimBlockReason(
      b,
      driverVehicle: store.profile.vehicle,
      driverZone: store.profile.zone,
      distanceKm: _pickupDistanceKm(b),
      radiusKm: store.profile.radiusKm,
    );
    if (poolReason != null) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(tr('drv_ye_ride_aap_nahi')),
          content: Text(poolReason),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(tr('ok_btn'))),
          ],
        ),
      );
      return;
    }
    final reason = store.acceptBlockReason();
    if (reason != null) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(tr('drv_ride_qubool_nahi_ho')),
          content: Text(reason),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(tr('ok_btn'))),
          ],
        ),
      );
      return;
    }
    // v1.4.2 RACE GUARD (audit fix #2): backend Pool ki ride pehle
    // backend par ATOMIC claim hoti hai (status=eq.pending shart
    // wala PATCH) — do driver ek saath dabayein to sirf pehla
    // jeet-ta hai; doosre ko saaf paighaam milta hai aur ride us
    // ki list se nikal jati hai. Local (same-device) ride par
    // purana seedha accept hi chalta hai.
    if (b.fromBackend) {
      final claimed = await Backend.tryClaimRide(store, b.id);
      if (!claimed) {
        store.setRemotePool(
            store.remotePool.where((x) => x.id != b.id).toList());
        if (mounted) {
          _snack(tr('drv_ye_ride_kisi_aur'));
          setState(() {});
        }
        return;
      }
      await store.acceptRemoteBooking(b);
    } else {
      await store.acceptBooking(b);
    }
    // v1.4.73 TEST RIDE: Master ki test ride qubool hona hi
    // test ka saboot hai — is ke baad asal flow (start code,
    // sawari ko push, position, navigation) BILKUL nahi chalta.
    // Ride mehfooz tareeqe se wahin band ho jati hai aur driver
    // ko saaf paighaam milta hai ke ye asal ride nahi thi।
    if (b.isTestRide) {
      await _finishTestRide(b);
      return;
    }
    // v1.4.7: do-phone ride ka start code Pool select mein na
    // aya ho (purani DB) to accept ke baad ride row se le lein —
    // code ke baghair driver ride shuru hi nahi kar payega।
    if (b.fromBackend && b.startCode <= 0) {
      unawaited(() async {
        final row =
            await Backend.fetchRideFields(b.id, 'start_code,ride_started');
        final code = (row?['start_code'] as num?)?.toInt() ?? 0;
        if (code > 0 && b.startCode <= 0) {
          b.startCode = code;
          await store.save();
          if (mounted) setState(() {});
        }
      }());
    }
    // v1.4.17 FCM: sawari ko foran khabar ke driver mil gaya
    // (passenger ki device pehle backend se dhoondhi jati hai;
    // na mile ya function deploy na ho to khamosh — passenger
    // ka polling wala rasta barkarar hai). Fire-and-forget.
    unawaited(() async {
      final dev = await Backend.fetchPassengerDeviceId(
          rideId: b.id, passengerPhone: b.passengerPhone);
      if (dev.isEmpty) return;
      await Backend.invokePush({
        'audience': 'device',
        'device_id': dev,
        'title': tr('drv_driver_mil_gaya'),
        'body':
            trf('drv_aap_ki_ride_ke', {'name': store.profile.name, 'pickupLabel': b.pickupLabel, 'dropLabel': b.dropLabel}),
        'data': {'ride_id': b.id},
      });
    }());
    // Qubool karte hi taaza position — passenger ko foran sahi
    // doori/ETA nazar aye (refresh khud store mein bhi darj karta hai).
    unawaited(_refreshMyLocation());
    // v1.4.0 two-phone: qubool shuda ride ke backend row par driver
    // ki pehli jagah foran likh dein — passenger ka ETA poll (~15s)
    // isi ko uthata hai. Position na mile to duty timer baad mein
    // likh dega. Khamosh nakami.
    final lat = p.lastLat;
    final lng = p.lastLng;
    if (lat != null && lng != null) {
      unawaited(Backend.pushRideDriverPosition(store, b.id, lat, lng));
    }
    if (mounted) {
      _snack(tr('drv_booking_qubool_ho_gayi'));
      setState(() {});
    }
  }

  /// TEST RIDE ka ikhtitam driver ki taraf se (v1.4.73):
  /// backend par mehfooz bandish (Backend.finishTestRide —
  /// driver_id row par rehta hai taake Master ko pata chale
  /// kis ne qubool ki) aur driver ko saaf "Test Mukammal"
  /// paighaam. Is ke baad ye booking 'cancelled' hai — active
  /// ride wali koi screen/flow is tak NAHI pohanchti, aur
  /// store ke markArrived / verifyAndStartRide / completeBooking
  /// par bhi test ki pakki rukawat hai।
  Future<void> _finishTestRide(Booking b) async {
    await Backend.finishTestRide(store, b);
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('test_ride_done_title')),
        content: Text(tr('test_ride_done_body')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(tr('ok_btn'))),
        ],
      ),
    );
    if (mounted) setState(() {});
  }

  /// Navigation (DriverNavView) ki GPS stream se ane wali position —
  /// v1.4.57 (Part 5): purana ~50 m wala gate teer ko atakata
  /// aur phir chhalang lagata tha। Ab store mein darj hone ki
  /// shart hai: kam az kam ~10 m ki harkat AUR aakhri write
  /// se kam az kam 3 second — jagah qadam-qadam taaza hoti
  /// hai, lekin backend par 3 s se zyada baar-baar write
  /// NAHI hota। Passenger ki doori/ETA line isi taaza
  /// position se khud taza ho jati hai; ride-row ki asal
  /// push _dutyTick ke 3 s wale gate se chalti hai।
  void _onNavPosition(ll2.LatLng pos) {
    final lat = p.lastLat;
    final lng = p.lastLng;
    if (lat != null && lng != null) {
      final moved = const ll2.Distance().as(ll2.LengthUnit.Meter,
          ll2.LatLng(lat, lng), pos);
      final lastStore = _lastNavStoreAt;
      final waited = lastStore == null ||
          DateTime.now().difference(lastStore).inSeconds >= 3;
      if (moved < 10 || !waited) {
        // Chhoti harkat / waqt baqi — sirf waqt-waqfa wala
        // push chalao; _dutyTick ka apna gate faisla karega।
        unawaited(_dutyTick());
        return;
      }
    }
    _lastNavStoreAt = DateTime.now();
    store.setDriverPosition(pos.latitude, pos.longitude);
    unawaited(_dutyTick());
  }

  /// v1.4.77 GUIDE S9: ride ke marahil ki patti — Pickup ki
  /// taraf → Pohanch gaya → Safar jari (4-digit code se
  /// shuru) → Mukammal। Haalat booking ki asal status se
  /// banti hai; mukammal marhala is card par nahi (ride
  /// mukammal hote hi card history mein chala jata hai)।
  Widget _rideStageRow(Booking b) {
    final current = b.rideStarted
        ? 2
        : (b.status == 'arrived' ? 1 : 0);
    final labels = [
      tr('guide_stage_pickup'),
      tr('guide_stage_arrived'),
      tr('guide_stage_started'),
      tr('guide_stage_complete'),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(tr('guide_stage_title'),
            style: const TextStyle(
                fontSize: 11.5, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Row(
          children: [
            for (var i = 0; i < labels.length; i++) ...[
              if (i > 0)
                Expanded(
                  child: Container(
                    height: 2.5,
                    color: i <= current ? Brand.green : Brand.fieldBorder,
                  ),
                ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: i < current
                      ? Brand.green
                      : i == current
                          ? Brand.gold
                          : Brand.fieldBorder,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (i < current)
                      const Icon(Icons.check, size: 12, color: Colors.white),
                    if (i < current) const SizedBox(width: 3),
                    Text(labels[i],
                        style: TextStyle(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w800,
                            color: i < current
                                ? Colors.white
                                : Brand.greenDark)),
                  ],
                ),
              ),
            ],
          ],
        ),
      ],
    );
  }

  Widget _activeCard(Booking b) {
    // v1.4.32: sawari ka photo-pin tayyar karo (ek dafa, guarded)।
    unawaited(_ensurePassengerPin(b));
    final arrived = b.status == 'arrived';
    // v1.4.29 DURING-TRIP SHEET (DRIVER-FLOW-SPEC 2026-11-11):
    // tartib — (1) sab se upar maujooda hadaf: A (pickup) ya
    // B (manzil) badge + poora pata + baqi waqt ka ETA chip;
    // (2) Cash line par kul kiraya BARE adad mein (driver ko
    // trip ke dauraan bhi kiraya dikhta hai — purana lock);
    // (3) passenger line: naam + gaari qisam chip (rating/trips
    // ka data maujooda model mein hai hi nahi — jaali rating
    // NAHI dikhayi); (4) A/B route lines; (5) bare tappable
    // option rows: Call · Waiting · Route in Navigator ·
    // (pickup marhale mein) Cancel; (6) aakhir mein SLIDE wale
    // bare buttons: Pohanch Gaya (Arrived) aur Ride Mukammal
    // (Complete) — Start Trip ka slide _StartCodeBox ke andar
    // hai (start code ke saath — v1.4.44 se 4-digit)। Rang gehra sabz + sunehri —
    // peela bilkul NAHI।
    final target = arrived
        ? ll2.LatLng(b.dropLat, b.dropLng)
        : ll2.LatLng(b.pickupLat, b.pickupLng);
    final cashTotal =
        b.fare + (arrived ? store.liveWaitingCharge(b) : b.waitingCharge);
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // v1.4.77 GUIDE S9: ride ka marhala sab se upar।
            _rideStageRow(b),
            const SizedBox(height: 12),
            // (1) Hadaf header
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                safarAbBadge(arrived ? 'B' : 'A', size: 30),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(arrived ? tr('target_drop') : tr('target_pickup'),
                          style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w700,
                              color: Theme.of(context).colorScheme.onSurfaceVariant)),
                      Text(arrived ? b.dropLabel : b.pickupLabel,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
                _TargetEta(from: _myPos, to: target),
              ],
            ),
            const SizedBox(height: 12),
            // (2) CASH line — kul kiraya bare adad mein
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFFEAF6EF),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Brand.green.withOpacity(0.35)),
              ),
              child: Row(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Brand.green,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.payments, size: 15, color: Colors.white),
                        SizedBox(width: 5),
                        Text('Cash',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                                fontSize: 13)),
                      ],
                    ),
                  ),
                  const Spacer(),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(tr('total_fare'),
                          style: const TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w700,
                              color: Brand.onLightSub)),
                      Text(rs(cashTotal),
                          style: const TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.w900,
                              color: Brand.greenDark)),
                      if (arrived && store.liveWaitingCharge(b) > 0)
                        Text(
                            trf('drv_kiraya_waiting', {'p1': rs(b.fare), 'p2': rs(store.liveWaitingCharge(b))}),
                            style: const TextStyle(
                                fontSize: 11, color: Brand.onLightSub)),
                      if (b.hasTax)
                        Text(
                            trf('drv_sawari_ada_karegi', {'p1': taxLabelFor(b.vehicle), 'p2': rs(b.taxAmount)}),
                            style: const TextStyle(
                                fontSize: 11, color: Brand.onLightSub)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            // (3) Passenger line + gaari chip
            Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: Brand.deepGreen,
                    shape: BoxShape.circle,
                    border: Border.all(color: Brand.gold, width: 1.4),
                  ),
                  child: const Icon(Icons.person,
                      color: Brand.goldLight, size: 21),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(b.passengerName,
                          style: const TextStyle(
                              fontSize: 16.5, fontWeight: FontWeight.w900)),
                      if (b.passengerPhone.isNotEmpty)
                        Text(b.passengerPhone,
                            style: TextStyle(
                                color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12.5)),
                    ],
                  ),
                ),
                Chip(
                  avatar: const Icon(Icons.directions_car, size: 15),
                  label: Text(b.vehicle),
                  labelStyle: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ],
            ),
            const SizedBox(height: 10),
            // (4) A/B route lines
            _routeLines(b),
            if (!arrived) ...[
              const SizedBox(height: 8),
              _pickupDistanceLine(b),
            ],
            const SizedBox(height: 8),
            if (b.hasDropPin) ...[
              DriverNavView(
                  booking: b,
                  onPosition: _onNavPosition,
                  driverOnline: p.online,
                  passengerPhotoPng: _passengerPins[b.id],
                  // v1.4.45: re-route engine + road reports
                  store: store),
              const SizedBox(height: 6),
            ],
            // (5) Bare tappable option rows
            const Divider(height: 1),
            _optionRow(
              icon: Icons.call,
              label: tr('call'),
              sub: b.passengerPhone.isNotEmpty
                  ? b.passengerPhone
                  : tr('drv_number_maujood_nahi'),
              onTap: () async {
                if (b.passengerPhone.trim().isEmpty) {
                  _snack(tr('no_number'));
                  return;
                }
                try {
                  await launchUrl(Uri.parse('tel:${b.passengerPhone.trim()}'));
                } catch (_) {
                  _snack(tr('call_failed'));
                }
              },
            ),
            _optionRow(
              icon: Icons.pause_circle_outline,
              label: tr('waiting'),
              sub: arrived
                  ? trf('waiting_sub_live', {
                      'mins': '${store.liveWaitingMinutes(b)}',
                      'amt': rs(store.liveWaitingCharge(b)),
                      'n': '${Fares.freeWaitingMinutes}',
                    })
                  : tr('waiting_sub_before'),
              onTap: () => _showWaitingSheet(b),
            ),
            _optionRow(
              icon: Icons.navigation,
              label: tr('route_in_navigator'),
              sub: tr('route_in_navigator_sub'),
              onTap: () async {
                try {
                  await launchUrl(
                    Uri.parse(
                        'geo:${target.latitude},${target.longitude}?q=${target.latitude},${target.longitude}'),
                    mode: LaunchMode.externalApplication,
                  );
                } catch (_) {
                  try {
                    await launchUrl(
                      Uri.parse(
                          'https://www.google.com/maps/dir/?api=1&destination=${target.latitude},${target.longitude}'),
                      mode: LaunchMode.externalApplication,
                    );
                  } catch (_) {
                    _snack(tr('nav_failed'));
                  }
                }
              },
            ),
            if (!arrived)
              _optionRow(
                icon: Icons.cancel,
                iconColor: Brand.ajrakRed,
                label: tr('cancel_ride_driver'),
                sub: tr('cancel_reason_sub'),
                onTap: () async {
                  final reason = await showReasonSheet(
                    context,
                    title: tr('cancel_why'),
                    options: kDriverCancelReasonOptions,
                  );
                  if (reason == null) return;
                  await store.cancelBooking(b, reason: reason);
                  if (mounted) {
                    _snack(tr('ride_cancelled'));
                    setState(() {});
                  }
                },
              ),
            const Divider(height: 1),
            const SizedBox(height: 8),
            // v1.4.0: SOS — ride chal rahi ho to driver ke liye bhi
            // hifazat ka button (police call + ride tafseel ghar
            // walon ko WhatsApp)।
            SosButton(store: store, booking: b, role: 'driver'),
            const SizedBox(height: 8),
            // SABOOT RECORDING (owner 2026-11-08): gambhir haalat
            // mein active ride par audio saboot — Master ko khud
            // khabar jati hai; recording delete nahi hoti।
            EvidenceRecorderButton(
              store: store,
              booking: b,
              role: 'driver',
              recorderName: p.name,
            ),
            const SizedBox(height: 8),
            // v1.4.16 RIDE CHAT: number share kiye baghair sawari
            // se baat।
            RideChatButton(store: store, booking: b, role: 'driver'),
            const SizedBox(height: 12),
            // (6) SLIDE wale bare buttons
            if (!arrived) ...[
              SlideConfirm(
                label: tr('arrived_slide'),
                handleIcon: Icons.location_on,
                onConfirm: () async {
                  await store.markArrived(b);
                  // v1.4.17 FCM: sawari ko foran khabar ke driver
                  // pohanch gaya (fire-and-forget)।
                  unawaited(Backend.pushDriverArrived(b));
                  if (mounted) {
                    _snack(trf('waiting_started_snack',
                        {'n': '${Fares.freeWaitingMinutes}'}));
                    setState(() {});
                  }
                },
              ),
            ] else ...[
              _LiveWaiting(booking: b, store: store),
              // v1.4.29 5-MINUTE RULE (owner hukm 2026-11-11):
              // driver ko saaf likha mile ke muft 5 minute ke
              // baad us ke paas dono raste hain aur no-show
              // cancel us ke record mein kharabi NAHI hai।
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  tr('noshow_rule_hint'),
                  style: TextStyle(
                      fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant, height: 1.4),
                ),
              ),
              // v1.4.7 RIDE START CODE (spec §3; v1.4.44 se
              // wapas 4-digit): ride asal mein tab SHURU mani jati hai
              // jab driver sawari ka code daal de — code ke
              // baghair "Ride Mukammal" bhi nahi chalti (neeche
              // _complete gate)। Start ka slide usi khane ke
              // andar hai।
              if (!b.rideStarted) ...[
                const SizedBox(height: 12),
                _StartCodeBox(
                  booking: b,
                  store: store,
                  onStarted: () {
                    if (mounted) setState(() {});
                  },
                ),
              ],
              const SizedBox(height: 12),
              SlideConfirm(
                label: tr('complete_slide'),
                handleIcon: Icons.flag,
                onConfirm: () async {
                  await _complete(b);
                },
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => _noShow(b),
                  icon: const Icon(Icons.person_off),
                  label: Text(tr('no_show')),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _complete(Booking b) async {
    // v1.4.7 START CODE GATE (spec §3): jo ride code se shuru hi
    // nahi hui woh mukammal bhi nahi hogi — pehle code।
    if (b.status == 'arrived' && !b.rideStarted) {
      _snack(
          tr('drv_pehle_sawari_se_6'));
      return;
    }
    final err = await store.completeBooking(b);
    if (!mounted) return;
    if (err != null) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(tr('ride_cannot_complete')),
          content: Text(err),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(tr('ok_btn'))),
          ],
        ),
      );
    } else {
      // v1.4.70 AWAAZ WALA ELAN (malik ka hukm 2026-11-22): ride
      // mukammal ho gayi — awaaz wali rehnumai ki pasand ON ho to
      // doosri ride ke intezaar ka elan bol do (sirf awaaz hai;
      // completion ka flow bilkul waisa hi rehta hai)।
      // v1.4.72 KIRAYA KA ELAN (malik ka hukm 2026-11-22): usi
      // lamhe jab cash screen khulti hai — pehle WOHI raqam
      // bol kar jo screen par dikhti hai (b.passengerPays —
      // completeBooking ke baad ki pakki raqam, _showCashSheet
      // wali hi value; koi doosra hisaab NAHI), phir queue mein
      // intezaar wala elan — dono elan takrate NAHI।
      unawaited(() async {
        await VoiceNavPrefs.load();
        if (VoiceNavPrefs.enabled) {
          unawaited(Voice.speak(
              'Ride complete karein — musafir se ${rs(b.passengerPays)} kiraya lein'));
          unawaited(
              Voice.speak('Doosri ride ka intezaar karein', queue: true));
        }
      }());
      // v1.4.29 CASH WASOOLI SCREEN (spec 2026-11-11): complete
      // hote hi saaf patti — sawari kul kitna degi, trip price,
      // bara Done। Fee/tax ka record system khud bana chuka hai
      // (completeBooking); is screen par koi hisaab TALAB nahi —
      // sirf wasooli ki raqam saaf dikhani hai।
      _showCashSheet(b);
    }
    setState(() {});
  }

  /// v1.4.29: Complete ke baad ki cash screen — notice patti
  /// "Sawari Rs X degi", bara card "Rs X — Trip mukammal",
  /// Trip price line, bara Done button (wapas home/online)।
  void _showCashSheet(Booking b) {
    // v1.4.57 SAHULAT: sawari ki asal adaigi — Sahulat
    // (partial-free) ride par kul mein se muft hissa minus,
    // aam ride par kul mein se pehli-ride riayat minus
    // (Booking.passengerPays — dono ka EK hisaab)।
    final pay = b.passengerPays;
    showModalBottomSheet<void>(
      context: context,
      isDismissible: false,
      enableDrag: false,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF6EF),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Brand.green.withOpacity(0.4)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.info_outline,
                        size: 18, color: Brand.greenDark),
                    const SizedBox(width: 8),
                    Text(trf('passenger_will_pay', {'amt': rs(pay)}),
                        style: const TextStyle(
                            fontSize: 16.5,
                            fontWeight: FontWeight.w800,
                            color: Brand.greenDark)),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Text(tr('collect_cash'),
                  textAlign: TextAlign.center,
                  style:
                      const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Brand.deepGreen,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Brand.gold, width: 1.2),
                ),
                child: Column(
                  children: [
                    Text(rs(pay),
                        style: const TextStyle(
                            fontSize: 34,
                            fontWeight: FontWeight.w900,
                            color: Brand.goldLight)),
                    const SizedBox(height: 2),
                    Text(tr('trip_completed'),
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 14)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Text(tr('trip_price'),
                      style: const TextStyle(
                          fontWeight: FontWeight.w600, fontSize: 14.5)),
                  const Spacer(),
                  Text(rs(b.fare),
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 14.5)),
                ],
              ),
              if (b.waitingCharge > 0) ...[
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(tr('waiting_charge'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14.5)),
                    const Spacer(),
                    Text(rs(b.waitingCharge),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 14.5)),
                  ],
                ),
              ],
              if (b.hasTax) ...[
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(taxLabelFor(b.vehicle),
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14.5)),
                    const Spacer(),
                    Text(rs(b.taxAmount),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 14.5)),
                  ],
                ),
              ],
              // v1.4.57 SAHULAT (Part 1) lines: completion par
              // POORA hisaab — muft hissa, us ki SAF fee line
              // (10%, jo credit se kati), Amanat credit (90%),
              // kaun si hadd lagi, aur malik ka tay-shuda
              // paighaam। Har number milta hai: muft hissa =
              // credit + us ki fee; sawari ki adaigi (upar
              // wali bari raqam) = kul − muft hissa।
              // Pehli-ride riayat ki line neeche alag hai
              // (driver ko poora paisa — riayat sirf sawari
              // ki adaigi se kam)।
              if (b.freeRide) ...[
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(tr('sahulat_free_part'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14.5)),
                    const Spacer(),
                    Text(rs(b.sahulatFreePartRs),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 14.5)),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(tr('sahulat_fee_line'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14.5)),
                    const Spacer(),
                    Text('−${rs(b.sahulatFeeRs)}',
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 14.5)),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(tr('sahulat_amanat_credit'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14.5)),
                    const Spacer(),
                    Text(rs(b.freeCreditRs),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 14.5)),
                  ],
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                      tr(b.sahulatCapApplied == 'rs'
                          ? 'sahulat_cap_rs'
                          : 'sahulat_cap_km'),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceVariant)),
                ),
                const SizedBox(height: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                  decoration: BoxDecoration(
                    color: Brand.gold.withOpacity(0.16),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Brand.gold),
                  ),
                  child: Text(
                    trf('sahulat_driver_msg', {
                      'free': '${b.sahulatFreePartRs}',
                      'pay': '$pay'
                    }),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        color: Theme.of(context).colorScheme.primary),
                  ),
                ),
              ],
              if (!b.freeRide && b.promoDiscountRs > 0) ...[
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text(trf('sahulat_first_discount', {'amt': '${b.promoDiscountRs}'}),
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14.5)),
                    const Spacer(),
                    Text('−${rs(b.promoDiscountRs)}',
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 14.5)),
                  ],
                ),
              ],
              const SizedBox(height: 6),
              Text(
                  tr('fee_record_note'),
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12.5)),
              const SizedBox(height: 16),
              SizedBox(
                height: 54,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Brand.gold,
                    foregroundColor: Brand.greenDark,
                    textStyle: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w900),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: () => Navigator.of(ctx).pop(),
                  child: Text(tr('done')),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _noShow(Booking b) async {
    final err = await store.markNoShow(b);
    if (!mounted) return;
    _snack(err ??
        trf('drv_no_show_darj_ho', {'p1': rs(b.waitingCharge)}));
    setState(() {});
  }

  /// BAND SADAK REPORT (MAP WAVE v1.4.20): pehle GPS maqam
  /// (ijazat na ho ya GPS band ho to saaf paighaam — jaali
  /// location kabhi nahi), phir type/note wala dialog, phir
  /// Backend.submitRoadReport. Kamyabi par shukriya wala
  /// paighaam, nakami par saaf error — offline queue nahi hai.
  Future<void> _showRoadReportDialog() async {
    Position? pos;
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm != LocationPermission.denied &&
          perm != LocationPermission.deniedForever) {
        pos = await Geolocator.getCurrentPosition(
          locationSettings:
              const LocationSettings(accuracy: LocationAccuracy.high),
        );
      }
    } catch (_) {
      pos = null;
    }
    if (!mounted) return;
    if (pos == null) {
      _snack(tr('drv_location_nahi_mil_saki'));
      return;
    }
    final position = pos;
    var type = 'band_sadak';
    final noteCtrl = TextEditingController();
    var sending = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(tr('drv_sadak_ki_report')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tr('drv_kya_masla_hai'),
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final t in [
                      ('band_sadak', tr('drv_band_sadak')),
                      ('construction', 'Construction'),
                      ('diversion', 'Diversion'),
                    ])
                      ChoiceChip(
                        label: Text(t.$2),
                        selected: type == t.$1,
                        onSelected: (_) => setLocal(() => type = t.$1),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: noteCtrl,
                  maxLines: 2,
                  decoration: InputDecoration(
                    labelText: tr('drv_note_ikhtiyari'),
                    hintText: tr('drv_masalan_bridge_ke_paas'),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  trf('drv_location', {'p1': position.latitude.toStringAsFixed(5), 'p2': position.longitude.toStringAsFixed(5)}),
                  style:
                      TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              // v1.4.25 bug fix: Cancel NULL pop karta hai —
              // pehle woh bhi 'false' (nakami) bhejta tha, is
              // liye Cancel par bhi "nahi bhej saki" wala snack
              // ajata tha (postmortem chhota bug)।
              onPressed: sending ? null : () => Navigator.pop(ctx, null),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: sending
                  ? null
                  : () async {
                      setLocal(() => sending = true);
                      final sent = await Backend.submitRoadReport(
                        store,
                        lat: position.latitude,
                        lng: position.longitude,
                        type: type,
                        note: noteCtrl.text.trim(),
                      );
                      if (ctx.mounted) Navigator.pop(ctx, sent);
                    },
              child: Text(sending ? tr('reg_sending') : tr('drv_report_bhejein')),
            ),
          ],
        ),
      ),
    );
    noteCtrl.dispose();
    if (!mounted) return;
    // Cancel (ok == null) par koi snack NAHI — pehle wohi
    // nakami wala paighaam wahan bhi ajata tha (bug)।
    if (ok == null) return;
    _snack(ok
        ? tr('drv_report_master_ko_bhej')
        : tr('drv_report_nahi_bhej_saki'));
  }

  // --- WALLET -----------------------------------------------------------------

  // (Deposit/fee ke khud-darj wale forms yahan se HATA diye
  // gaye hain — malik ke controls 2026-11-10 19:41 + 20:05:
  // jama aur wasool ki entry SIRF Master karta hai; driver
  // ki wallet screen sirf dekhne ke liye hai. Tafseel
  // _walletView ke Amanat cards mein.)

  /// Kamai report ki ek patti (hafta/mahina) — rides, kul, fee, net.
  Widget _earningsRow(
      String label, ({int rides, int gross, int fee, int tax, int net}) e) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Brand.lightBg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 14,
                  color: Brand.ink)),
          const SizedBox(height: 4),
          Text(
            trf('drv_rides_kul_kamai_service', {'rides': '${e.rides}', 'p1': rs(e.gross), 'p2': rs(e.fee), 'p3': rs(e.net)}),
            style: const TextStyle(fontSize: 12.5, color: Brand.ink),
          ),
          // v1.4.24: tax alag line — kamai/bachat mein shamil
          // NAHI, sirf record (sarkari tax, Master ke Tax Khata
          // mein jata hai)।
          if (e.tax > 0) ...[
            const SizedBox(height: 2),
            Text(
              trf('drv_sales_tax_srb_wasool', {'p1': rs(e.tax)}),
              style: const TextStyle(fontSize: 12, color: Brand.onLightSub),
            ),
          ],
        ],
      ),
    );
  }

  /// Kamai report WhatsApp par text ki surat mein share karna —
  /// passenger ke share-my-ride wala hi tareeqa (wa.me link).
  /// v1.4.35 (audit C-2) MERA DATA: driver ka poora record
  /// (profile + rides + fee/Amanat) ek text file ki shakal mein
  /// share sheet se — data_export.dart ke pure builder se।
  Future<void> _shareMyData() async {
    final text = buildDriverDataExport(store, now: DateTime.now());
    try {
      await Share.share(text, subject: tr('exp_mera_data'));
    } catch (_) {
      if (mounted) _snack(tr('psg_share_nahi_ho_saka'));
    }
  }

  /// v1.4.37 — DEPOSIT sheet kholna (malik ka hukm 2026-11-12):
  /// saaf steps + "Maine Bhej Diya — Master Ko Khabar Karein"
  /// wala amal. Paisa app ke andar se NAHI jata — transfer
  /// driver apni Easypaisa/JazzCash app se karta hai; yahan sirf
  /// hidayat hai aur Master ko khabar bhejne ka button. Jama ki
  /// entry SIRF Master karega — app mein koi auto-credit NAHI।
  void _showDepositSheet() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => _DepositSheet(store: store),
    );
  }

  Future<void> _shareEarningsReport() async {
    final w = store.earningsThisWeek();
    final m = store.earningsThisMonth();
    final text = trf('drv_safar_meri_kamai_ki', {'name': p.name, 'rides': '${w.rides}', 'p1': rs(w.gross), 'p2': rs(w.fee), 'p3': rs(w.net), 'rides2': '${m.rides}', 'p4': rs(m.gross), 'p5': rs(m.fee), 'p6': rs(m.net), 'p7': rs(store.amanatBalance)});
    final uri =
        Uri.parse('https://wa.me/?text=${Uri.encodeComponent(text)}');
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) _snack(tr('drv_whatsapp_nahi_khul_saka'));
  }

  // (deposit/pwd controllers ki dispose is file ke _DriverSideState
  // ke dispose() mein pehle se hoti thi — v1.4.0 mein wahan banners
  // + duty timer bhi band hote hain.)

  /// v1.4.77 GUIDE S11: Wallet ka khulasa — kul kiraya
  /// (gross), commission (service fee), asal kamai (net),
  /// cash/digital taqseem, aur payout/settlement ki haalat।
  /// Hisaab ke usool bilkul wohi purane hain (earningsBetween
  /// + Amanat ledger) — ye sirf guide wali numaish hai।
  Widget _guideWalletSummaryCard(
      ({int rides, int gross, int fee, int tax, int net}) allTime) {
    final payout = p.feeDue > 0
        ? '${tr('guide_w_pending')} (${rs(p.feeDue)})'
        : (allTime.rides > 0 ? tr('guide_w_paid') : '—');
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Pal.panel(context),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Brand.green, width: 1.4),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.summarize, color: Brand.green, size: 21),
              const SizedBox(width: 8),
              Text(tr('guide_wallet_title'),
                  style: const TextStyle(
                      fontSize: 14.5, fontWeight: FontWeight.w900)),
            ],
          ),
          const SizedBox(height: 8),
          _infoRow(tr('guide_w_gross'), rs(allTime.gross)),
          _infoRow(
              '${tr('guide_w_commission')} (${fmtPct(Fares.feePercent)})',
              rs(allTime.fee)),
          _infoRow(tr('guide_w_net'), rs(allTime.net)),
          if (allTime.tax > 0)
            _infoRow(tr('drv_sales_tax_srb_sarkari'), rs(allTime.tax)),
          const Divider(height: 16),
          _infoRow(tr('guide_w_cash'), rs(allTime.gross + allTime.tax)),
          _infoRow(tr('guide_w_digital'),
              '${rs(0)} — ${tr('guide_w_digital_note')}'),
          const Divider(height: 16),
          _infoRow(tr('guide_w_payout'), payout),
          const SizedBox(height: 4),
          Text(tr('guide_w_states_note'),
              style: const TextStyle(fontSize: 11.5, height: 1.4)),
        ],
      ),
    );
  }

  /// v1.4.77 GUIDE S11: har mukammal ride ka alag hisaab —
  /// kiraya, fee, asal kamai (aur tax alag) ride-ba-ride।
  Widget _guidePerRideCard() {
    final done = store.bookings
        .where((b) =>
            b.status == 'completed' && !b.isTestRide && b.completedAt != null)
        .toList()
      ..sort((a, b) => b.completedAt!.compareTo(a.completedAt!));
    if (done.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(tr('guide_per_ride_title'),
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        for (final b in done.take(20))
          Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: const Icon(Icons.route, color: Brand.green),
              title: Text('${b.pickupLabel} → ${b.dropLabel}',
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text(
                  '${fmtDate(b.completedAt!)} · ${tr('guide_w_commission')}: ${rs(b.effectiveFeeRs)} · ${tr('guide_w_net')}: ${rs(b.total - b.effectiveFeeRs)}${b.taxAmount > 0 ? ' · Tax: ${rs(b.taxAmount)}' : ''}'),
              trailing: Text(rs(b.total),
                  style: const TextStyle(fontWeight: FontWeight.w900)),
            ),
          ),
      ],
    );
  }

  Widget _walletView() {
    // Kul hisaab (tamam mukammal rides, local record): kul
    // rides / kul kiraya / kul bani hui fee (v1.4.20).
    final allTime = store.earningsBetween(
        DateTime(2000, 1, 1), DateTime.now().add(const Duration(days: 1)));
    // Wasool shuda (SIRF Master ki darj shuda settlements se —
    // feeDue unhi se kam hota hai): kul bani fee − baqi.
    // Driver khud is mein kuch nahi jod sakta (19:41 control).
    final feeWasoolRaw = allTime.fee - p.feeDue;
    final feeWasool = feeWasoolRaw > 0 ? feeWasoolRaw : 0;
    // AMANAT DEPOSIT (v1.4.21 — malik ka faisla 2026-11-10
    // 20:05): maujooda balance hamesha DERIVED hai —
    //   balance = kul jama (Master-darj) − deposit se kati fees
    // aur "deposit se kati fees" wohi hai jo feeDue mein baqi
    // hai (kul bani fees − cash wasool)। EK hi hisaab hai —
    // purani "Dena Hai" wali voluntary-fee sorat aur driver ke
    // khud deposit darj karne wala form is nizaam mein KHATAM
    // hain: jama ki entry SIRF Master karta hai.
    final balance = store.amanatBalance;
    return ListView(
      key: const ValueKey('drv-tab-wallet'),
      padding: const EdgeInsets.all(14),
      children: [
        // AMANAT card: sabz GRADIENT — big number = balance.
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Brand.green, Brand.deepGreen, Brand.greenDark],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Brand.gold, width: 2),
          ),
          child: Column(
            children: [
              Text(tr('drv_mera_deposit_amanat_balance'),
                  style: const TextStyle(
                      color: Brand.goldLight,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2)),
              Text(rs(balance > 0 ? balance : 0),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.w900)),
              Text(
                trf('drv_kul_jama_deposit_se', {'p1': rs(p.amanatJama), 'p2': rs(p.feeDue)}),
                style: const TextStyle(color: Brand.cream, fontSize: 12),
              ),
              const SizedBox(height: 6),
              Text(
                tr('drv_ye_raqam_aap_ki'),
                style: const TextStyle(color: Colors.white, fontSize: 11),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        // v1.4.37 — DEPOSIT JAMA KARWAYEIN ka WAZEH BARA button
        // (malik ka hukm 2026-11-12): pehle top-up ki hidayat sirf
        // chhoti grey likhai thi — driver ko amal saaf aur bara
        // nazar ana chahiye. Balance > 0 ho tab bhi dikhta hai
        // (dobara top-up kabhi bhi ho sakta hai); balance <= 0 par
        // sunehri kinari ke saath SAB SE numayan, kyunki baghair
        // deposit driver online nahi ho sakta।
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _showDepositSheet,
            icon: const Icon(Icons.payments, size: 22),
            label: Text(
              trf('drv_dep_button',
                  {'joiningDeposit': '${Fares.joiningDeposit}'}),
              style:
                  const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: Brand.green,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16),
              elevation: balance <= 0 ? 6 : 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: balance <= 0
                    ? const BorderSide(color: Brand.gold, width: 2.5)
                    : BorderSide.none,
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        // --- AMANAT HISAAB — tafseel ---
        // Kul jama (Master-darj), kul bani fees, cash wasool
        // (purani, agar ho), deposit se kati fees aur maujooda
        // balance — sab EK hisaab se. Neeche top-up ki hidayat:
        // jama SIRF Master darj karta hai (wasool ke baad)।
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF6E0),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Brand.gold, width: 1.5),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(tr('drv_amanat_hisaab_tafseel'),
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w900,
                          color: Brand.ink)),
                  const Spacer(),
                  Text(rs(balance > 0 ? balance : 0),
                      style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: Brand.greenDark)),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                trf('drv_kul_mukammal_rides_kul', {'rides': '${allTime.rides}', 'p1': rs(allTime.gross)}),
                style: const TextStyle(
                    fontSize: 12.5, fontWeight: FontWeight.w700,
                    color: Brand.ink),
              ),
              const SizedBox(height: 4),
              Text(
                trf('drv_kul_deposit_jama_master', {'p1': rs(p.amanatJama)}),
                style: const TextStyle(fontSize: 12.5, color: Brand.ink),
              ),
              const SizedBox(height: 4),
              Text(
                trf('drv_kul_bani_hui_fees', {'p1': fmtPct(Fares.feePercent), 'p2': rs(allTime.fee)}),
                style: const TextStyle(fontSize: 12.5, color: Brand.ink),
              ),
              if (feeWasool > 0) ...[
                const SizedBox(height: 4),
                Text(
                  trf('drv_cash_wasool_purani_master', {'p1': rs(feeWasool)}),
                  style: const TextStyle(fontSize: 12.5, color: Brand.ink),
                ),
              ],
              const SizedBox(height: 4),
              Text(
                trf('drv_deposit_se_kati_hui', {'p1': rs(p.feeDue)}),
                style: const TextStyle(fontSize: 12.5, color: Brand.ink),
              ),
              // v1.4.24 TAX (SRB): driver ke hisaab mein tax
              // ALAG nazar aye — ye us ki kamai NAHI hai: sarkari
              // tax hai jo sawari ke kiraye par alag wasool hua,
              // fees ke saath Master ke Tax Khata mein record
              // hai aur sarkar (SRB) ko jama karana hai।
              if (allTime.tax > 0) ...[
                const SizedBox(height: 4),
                Text(
                  trf('drv_kul_bana_hua_sales', {'p1': rs(allTime.tax)}),
                  style: const TextStyle(
                      fontSize: 12.5, fontWeight: FontWeight.w700,
                      color: Brand.ink),
                ),
                const SizedBox(height: 2),
                Text(
                  tr('drv_ye_tax_aap_ki'),
                  style: const TextStyle(fontSize: 11.5, color: Brand.onLightSub),
                ),
              ],
              const SizedBox(height: 8),
              if (balance <= 0)
                Text(
                  tr('drv_balance_khatam_hai_online'),
                  style: const TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w800,
                      color: Brand.ajrakRed),
                ),
              if (balance <= 0) const SizedBox(height: 6),
              Text(
                trf('drv_top_up_ki_hidayat', {'joiningDeposit': '${Fares.joiningDeposit}'}),
                style: const TextStyle(
                    fontSize: 12, color: Brand.onLightSub, height: 1.4),
              ),
              const SizedBox(height: 6),
              Text(
                tr('drv_amanat_ki_shartein_fees'),
                style: const TextStyle(
                    fontSize: 12, color: Brand.onLightSub, height: 1.4),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // v1.4.77 GUIDE S11: wallet ka guide-wala khulasa।
        _guideWalletSummaryCard(allTime),
        const SizedBox(height: 20),
        // v1.4.0 — KAMAI KI REPORT: is hafte + is mahine ka khulasa
        // (rides, kul kamai, service charges, asal bachat) — sirf
        // local bookings/ledger se (store.earnings*), koi backend
        // nahi. Share-as-text WhatsApp par — app ka mojooda tareeqa.
        Row(
          children: [
            Text(tr('drv_kamai_ki_report'),
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
            const Spacer(),
            TextButton.icon(
              onPressed: _shareEarningsReport,
              icon: const Icon(Icons.share, size: 16),
              label: Text(tr('drv_share_karein')),
            ),
          ],
        ),
        const SizedBox(height: 4),
        _earningsRow(tr('drv_is_hafte'), store.earningsThisWeek()),
        const SizedBox(height: 6),
        _earningsRow(tr('drv_is_mahine'), store.earningsThisMonth()),
        const SizedBox(height: 10),
        // v1.4.35 (audit C-2): MERA DATA export — poora record
        // (profile + rides history + fee/Amanat) share karein।
        Row(
          children: [
            Text(tr('exp_mera_data'),
                style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w900)),
            const Spacer(),
            TextButton.icon(
              onPressed: _shareMyData,
              icon: const Icon(Icons.share, size: 16),
              label: Text(tr('drv_share_karein')),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Text(tr('drv_monthly_packages'),
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.monthlyPackages.isEmpty)
          Text(tr('drv_abhi_koi_monthly_package'),
              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ...store.monthlyPackages.map((mp) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading:
                    const Icon(Icons.calendar_month, color: Brand.green),
                title: Text('${mp.pickup} → ${mp.drop}'),
                subtitle: Text(
                    trf('drv_din', {'p1': mp.passengerName.isEmpty ? 'Sawari' : mp.passengerName, 'vehicle': mp.vehicle, 'days': '${mp.days}'})),
                trailing: Text(rs(mp.monthlyAmount),
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            )),
        const SizedBox(height: 20),
        // v1.4.77 GUIDE S11: har ride ka alag hisaab।
        _guidePerRideCard(),
        const SizedBox(height: 20),
        Text(tr('drv_hisab_kitab_ledger'),
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.txns.isEmpty)
          Text(tr('drv_abhi_koi_entry_nahi'),
              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ...store.txns.map((t) {
          final isDeposit = t.type == 'deposit';
          final isFeePay = t.type == 'fee_payment';
          // v1.4.24: 'tax' entry = Sales Tax (SRB) — service
          // charges se ALAG pehchan (ye driver ki kamai/katauti
          // NAHI, sarkari tax ka record hai)।
          final isTax = t.type == 'tax';
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Icon(
                isDeposit
                    ? Icons.arrow_downward
                    : isFeePay
                        ? Icons.receipt_long
                        : isTax
                            ? Icons.account_balance
                            : Icons.percent,
                color: isDeposit
                    ? Brand.green
                    : isFeePay
                        ? Brand.green
                        : Brand.ajrakRed,
              ),
              title: Text(isDeposit
                  ? trf('drv_deposit', {'method': t.method})
                  : isFeePay
                      ? trf('drv_fee_payment_tasdeeq_baqi', {'method': t.method})
                      : isTax
                          ? tr('drv_sales_tax_srb_sarkari')
                          : trf('drv_service_charges', {'p1': fmtPct(Fares.feePercent)})),
              subtitle: Text('${t.note}\n${fmtDate(t.date)} ${fmtTime(t.date)}'),
              isThreeLine: true,
              trailing: Text(
                isDeposit ? '+ ${rs(t.amount)}' : '− ${rs(t.amount)}',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: isDeposit || isFeePay
                      ? Brand.green
                      : Brand.ajrakRed,
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  // --- PROFILE (FORM USOOL — 2026-11-08) --------------------------------------
  //
  // FORM USOOL (owner ka hukm): Profile par koi form display par
  // khula/pehle-bhara NAHI ata. Profile sirf:
  //   (1) STATUS LINES — account ki haalat, driver ki apni maloomat
  //       (naam/mobile/gaari/sheher), Tasdeeq ki asal haalat
  //       (Verified pill sirf Master ke faisle par), Mere Kagaz ki
  //       haalatein, rozana selfie ki haalat, password ki haalat;
  //   (2) BUTTONS — jo sahi step par RegistrationWizard khol dein
  //       (har tabdeeli sirf wizard mein, step-by-step hoti hai),
  //       password ke liye set/change wale dialogs, Master ko
  //       Message ka darwaza, aur reject shuda document ko Dobara
  //       Bhejne ka amal (woh editing form nahi — sirf wohi ek
  //       document ki nayi photo hai).
  // Purane inline editing fields (naam/phone/plate/brand/model/
  // year/color/zone/vehicle chips) aur "Profile Save Karein" wala
  // khula form yahan se KHTAM hai. Password ke usool (fingerprint,
  // uniqueness, lockout) aur un ke exact jumle bilkul nahi chhere
  // gaye — set/change ke dialogs wohi hain jo pehle thay.

  /// Read-only maloomat ki ek line (status display — koi field nahi).
  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 118,
            child: Text(label,
                style: TextStyle(
                    fontWeight: FontWeight.w700, color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ),
          Expanded(
            child: Text(value.isEmpty ? '—' : value,
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _profileView() {
    return ListView(
      key: const ValueKey('drv-tab-profile'),
      padding: const EdgeInsets.all(14),
      children: [
        Text(tr('drv_driver_profile'),
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        // Master tasdeeq ki haalat — backend drivers.active se ati hai.
        // Profile Save = registration (pending); Master ACTIVE kare to
        // ye card badal jata hai. Refresh se foran nayi haalat pull.
        Card(
          color: p.masterActive ? Brand.deepGreen : null,
          child: ListTile(
            leading: Icon(
              p.masterActive ? Icons.verified : Icons.pending_actions,
              color: p.masterActive ? Brand.gold : Brand.ajrakRed,
            ),
            title: Text(
              p.masterActive
                  ? tr('drv_account_active_hai')
                  : tr('drv_account_pending_hai'),
              style: TextStyle(
                fontWeight: FontWeight.w800,
                color: p.masterActive ? Colors.white : null,
              ),
            ),
            subtitle: Text(
              p.masterActive
                  ? tr('drv_master_ne_tasdeeq_kar_2')
                  : tr('drv_registration_form_mukammal_karein'),
              style: TextStyle(
                color: p.masterActive ? Colors.white : null,
              ),
            ),
            trailing: IconButton(
              icon: Icon(Icons.refresh,
                  color: p.masterActive ? Brand.gold : Brand.green),
              tooltip: tr('drv_status_refresh_karein'),
              onPressed: () async {
                await Backend.refreshDriverStatus(store);
                if (mounted) setState(() {});
              },
            ),
          ),
        ),
        const SizedBox(height: 10),
        // v1.4.77 GUIDE S7 + S13: darkhwast ki haalat aur
        // Profile Menu (Personal/Documents/Vehicles/Rating/
        // Settings/Help/Logout)।
        _applicationStatusCard(),
        const SizedBox(height: 10),
        _guideProfileMenuCard(),
        const SizedBox(height: 10),
        // v1.4.22 MERI PHOTO (malik ka hukm 2026-11-10 23:36):
        // driver apni profile photo laga/badla sakta hai — kul
        // 3 dafa ki hadd ke saath; baqi moqay card par likhe
        // ate hain aur hadd par likha hua notice (Master-route
        // wali sahulat samait)।
        ProfilePhotoCard(store: store, forDriver: true),
        const SizedBox(height: 10),
        // v1.4.57 (Part 13): MERA NISHAN — driver apne maqam
        // ke nishan ki shakal khud chunta hai: Teer ya apni
        // Gaari। Pasand mehfooz rehti hai (MarkerPrefs) aur
        // duty + navigation maps par foran lagu hoti hai।
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                const Icon(Icons.navigation, color: Brand.green),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text('Mera Nishan',
                      style: TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 15)),
                ),
                ValueListenableBuilder<MarkerStyle>(
                  valueListenable: MarkerPrefs.notifier,
                  builder: (context, style, _) => Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ChoiceChip(
                        label: const Text('Teer'),
                        selected: style == MarkerStyle.arrow,
                        onSelected: (_) =>
                            MarkerPrefs.set(MarkerStyle.arrow),
                      ),
                      const SizedBox(width: 8),
                      ChoiceChip(
                        label: const Text('Gaari'),
                        selected: style == MarkerStyle.vehicle,
                        onSelected: (_) =>
                            MarkerPrefs.set(MarkerStyle.vehicle),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        // AGENT HISA (v1.4.6): driver ke mobile ka ACTIVE agent
        // ho to "Mera Agent Hisa" card yahin khulta hai — na ho
        // to widget khud ghayab rehta hai (SizedBox.shrink).
        AgentSection(store: store),
        const SizedBox(height: 10),
        // Registration (v1.2.6): pehli registration Yango-style wizard
        // se hoti hai — Profile mein us ka darwaza hai, doosri
        // competing form NAHI. Mukammal ho to tafseel yahin se dobara
        // khol kar badli ja sakti hai.
        Card(
          // HOTFIX v1.2.9 (RC2): card ki haalat registrationComplete
          // par — flag laga ho lekin photos baqi hon to card
          // "tasaveer baqi hain" wali soorat mein dikhta hai.
          color: p.registrationComplete ? null : Brand.deepGreen,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.app_registration,
                        color:
                            p.registrationComplete ? Brand.green : Brand.gold),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        p.registrationComplete
                            ? tr('drv_registration_mukammal_hai')
                            : (p.registrationDone
                                ? tr('drv_registration_ki_tasaveer_baqi')
                                : tr('drv_registration_baqi_hai')),
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                          color: p.registrationComplete ? null : Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  p.registrationComplete
                      ? tr('drv_cnic_gaari_licence_aur')
                      : (p.registrationDone
                          ? tr('drv_form_pehle_bhara_gaya')
                          : tr('drv_mobile_cnic_password_gaari')),
                  style: TextStyle(
                    fontSize: 12,
                    color: p.registrationComplete
                        ? Theme.of(context).colorScheme.onSurfaceVariant
                        : Colors.white,
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _openRegistration,
                    style: p.registrationComplete
                        ? null
                        : ElevatedButton.styleFrom(
                            backgroundColor: Brand.gold,
                            foregroundColor: Brand.greenDark),
                    child: Text(p.registrationComplete
                        ? tr('drv_tafseel_dekhein_badlein')
                        : tr('drv_registration_mukammal_karein')),
                  ),
                ),
                // LOGIN (v1.4.47): registration adhuri ho to
                // pehle se account walon ke liye yahin numaya
                // login button — dobara registration ka phansa
                // khatam।
                if (!p.registrationComplete) ...[
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _openLogin,
                      style: OutlinedButton.styleFrom(
                          minimumSize: const Size.fromHeight(54)),
                      icon: const Icon(Icons.login, size: 19),
                      label: Text(tr('reg_welcome_login'),
                          style: const TextStyle(
                              fontSize: 15.5, fontWeight: FontWeight.w800)),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        // v1.4.29 ZUBAAN (owner hukm 2026-11-11): driver
        // profile se bhi wahi shared zubaan ki pasand —
        // passenger mode par bhi yehi lagu hoti hai।
        Card(
          child: ListTile(
            leading: const Icon(Icons.language, color: Brand.green),
            title: Text(tr('language'),
                style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(tr('language_sub')),
            trailing: Text(
                store.langCode == 'en' ? 'English' : 'Urdu',
                style: TextStyle(
                    fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.primary)),
            onTap: () => showLanguageChooser(
              context,
              current: store.langCode,
              onPick: (c) => store.setLang(c),
            ),
          ),
        ),
        const SizedBox(height: 10),
        // v1.4.29 RADIUS SETTING — FINAL RULE (owner, 2026-11-11
        // 16:36): driver apna pickup daira yahan se jab chahe
        // 2–5 km ke beech badal sakta hai (2 se kam NAHI)।
        // Registration par set shuda value hi yahan dikhti hai;
        // tabdeeli local store + backend record (radius_km)
        // dono mein jati hai।
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.radar, color: Brand.green),
                    const SizedBox(width: 10),
                    Text(tr('radius_title'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 15)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(tr('radius_hint'),
                    style: TextStyle(
                        fontSize: 12.5, color: Theme.of(context).colorScheme.onSurfaceVariant, height: 1.4)),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final km in kRadiusOptionsKm)
                      ChoiceChip(
                        label: Text('${km.toStringAsFixed(0)} km'),
                        selected: p.radiusKm == km,
                        onSelected: (sel) async {
                          if (!sel) return;
                          setState(() => p.radiusKm = km);
                          await store.save();
                          if (mounted) _snack(tr('radius_saved'));
                        },
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        // Master ko Message (v1.2.7): masla/shikayat seedha Master
        // (head) ko — Profile tab se hi darwaza hai.
        Card(
          child: ListTile(
            leading: const Icon(Icons.mail_outline, color: Brand.green),
            title: Text(tr('drv_madad_master_se_rabta'),
                style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(
                tr('drv_koi_masla_ya_shikayat')),
            trailing: const Icon(Icons.chevron_right),
            onTap: _openMessages,
          ),
        ),
        const SizedBox(height: 10),
        // v1.4.41 SAFETY — SOS: Profile se bhi seedha SOS
        // (ride wali screen ke button wala hi dialog aur
        // rasta — showSosDialog/sendSosToMaster); ride active
        // ho to us ride ke saath, warna baghair ride ke, aur
        // jagah profile wali akhri jagah se jati hai।
        Card(
          child: ListTile(
            leading: const Icon(Icons.emergency, color: Brand.ajrakRed),
            title: Text(tr('drv_safety_sos_title'),
                style: TextStyle(
                    fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.error)),
            subtitle: Text(tr('drv_safety_sos_sub')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Booking? active;
              for (final x in store.bookings) {
                if (x.status == 'accepted' ||
                    x.status == 'arrived' ||
                    x.status == 'started') {
                  active = x;
                  break;
                }
              }
              showSosDialog(context,
                  store: store,
                  role: 'driver',
                  booking: active,
                  lat: p.lastLat,
                  lng: p.lastLng);
            },
          ),
        ),
        const SizedBox(height: 10),
        // v1.4.26 HEALTH ENGINE: app ki sehat ki jhalak + Repair
        // Log ka rasta — engine khamoshi se khud repair karta
        // hai, ye satar sirf haalat batati hai.
        AppHealthTile(store: store),
        const SizedBox(height: 10),
        // v1.4.4 LEGAL: Sharait + Privacy ke darwaze — "Sharait
        // dobara parhein" yahin hai; driver ki registration wali
        // qubooliyat ka waqt bhi yahin nazar ata hai.
        LegalLinksCard(
          store: store,
          driverAcceptedAtMs:
              p.termsAcceptedAtMs > 0 ? p.termsAcceptedAtMs : null,
          // Driver Profile hai — Sharait mein Driver ki sharait
          // (fees/deposit/top-up) bhi khulengi (20:40 tarmim).
          showDriverTerms: true,
        ),
        // v1.4.0: driver ki apni rating — backend se pull shuda
        // ausat (backendRatingAvg) pehle; woh na ho to is phone par
        // sawariyon ki di hui ratings ka local ausat. Koi rating hi
        // na ho to ye patti NAHI dikhti (jhoota number kabhi nahi).
        if (store.backendRatingAvg != null ||
            store.localOwnRatingAverage != null) ...[
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const Icon(Icons.star, color: Brand.gold),
              title: Text(
                trf('drv_meri_rating_5', {'p1': (store.backendRatingAvg ?? store.localOwnRatingAverage)!.toStringAsFixed(1)}),
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text(store.backendRatingAvg != null
                  ? trf('drv_sawariyon_ne_rating_di', {'backendRatingCount': '${store.backendRatingCount}'})
                  : tr('drv_is_phone_par_di')),
            ),
          ),
        ],
        const SizedBox(height: 10),
        // --- APNI MALOOMAT (sirf status lines — koi form NAHI) ---
        // FORM USOOL (2026-11-08): naam/mobile/gaari/sheher yahan
        // sirf DIKHTE hain (read-only status lines). Koi tabdeeli
        // chahiye ho to neeche ka button seedha RegistrationWizard
        // kholta hai — tafseel pehle se bhari hui milegi, badalna
        // step-by-step wizard mein hi hoga.
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.person, color: Brand.green),
                    const SizedBox(width: 9),
                    Text(tr('my_info'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 15)),
                  ],
                ),
                const SizedBox(height: 8),
                _infoRow('Naam', p.name),
                _infoRow('Mobile', p.phone),
                _infoRow(tr('reg_city_label'),
                    p.zone.isEmpty ? tr('drv_abhi_set_nahi_hai') : p.zone),
                // v1.4.48: gaari wali satr mein RANG bhi — rang
                // darj ho tab hi ("Gaari: Rickshaw • Rang:
                // Golden" wali shakal); khaali ho to satr pehle
                // jaisi hi rehti hai।
                _infoRow('Gaari',
                    '${p.vehicle}${p.vehicleBrand.isEmpty ? '' : ' · ${p.vehicleBrand}'}${p.vehicleModel.isEmpty ? '' : ' ${p.vehicleModel}'}${p.vehicleColor.isEmpty ? '' : ' • Rang: ${p.vehicleColor}'}'),
                _infoRow(tr('reg_rev_year_color'),
                    '${p.vehicleYear == 0 ? '—' : p.vehicleYear} / ${p.vehicleColor.isEmpty ? '—' : p.vehicleColor}'),
                _infoRow(tr('veh_plate'), p.plate),
                // FIX 2026-11-21 (kami #12): agent code driver ko
                // apni profile mein saaf nazar aye — sirf DEKHNE
                // ke liye, tabdeeli yahan se nahi hoti. Pakka code
                // na laga ho lekin pending (tasdeeq baqi) code
                // mehfooz ho to woh bhi dikhta hai, taaki driver
                // ko pata ho ke us ka code ghum nahi hua — internet
                // ate hi woh khud-ba-khud lag jayega।
                if (p.agentCode.isNotEmpty)
                  _infoRow('Agent Code', p.agentCode),
                if (p.agentCode.isEmpty &&
                    store.pendingAgentCode.isNotEmpty)
                  _infoRow('Agent Code',
                      '${store.pendingAgentCode} (tasdeeq baqi hai)'),
                const SizedBox(height: 8),
                // TASDEEQ PILL (brief S6): badge SIRF Master ke asal
                // faisle par — ID active ho to sabz 'Verified';
                // reject ho to laal; warna amber 'Tasdeeq baqi hai'.
                // Driver khud ye badge kabhi nahi laga sakta.
                Row(
                  children: [
                    Text(tr('drv_tasdeeq'),
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: Theme.of(context).colorScheme.onSurfaceVariant)),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: (p.hasRejectedDocUi
                                ? Brand.ajrakRed
                                : p.masterActive
                                    ? Brand.green
                                    : const Color(0xFFB8860B))
                            .withOpacity(0.13),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: p.hasRejectedDocUi
                              ? Brand.ajrakRed
                              : p.masterActive
                                  ? Brand.green
                                  : const Color(0xFFB8860B),
                          width: 0.9,
                        ),
                      ),
                      child: Text(
                        p.hasRejectedDocUi
                            ? tr('drv_reject_neeche_wajah_dekhein')
                            : p.masterActive
                                ? tr('drv_verified')
                                : tr('drv_tasdeeq_baqi_hai'),
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: p.hasRejectedDocUi
                              ? Theme.of(context).colorScheme.error
                              : p.masterActive
                                  ? Theme.of(context).colorScheme.primary
                                  : Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Brand.goldLight
                                      : const Color(0xFFB8860B),
                        ),
                      ),
                    ),
                  ],
                ),
                // MUKAMMAL TASDEEQ DARJA (v1.4.19 — malik ka FINAL
                // faisla 2026-11-10 18:18): saare documents Master
                // se verified hon to sunehra wazeh nishan; warna
                // kitne kagaz baqi hain woh line (sirf registered
                // profile par)।
                if (p.registrationDone && p.mukammalTasdeeq) ...[
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 9),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF6E0),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Brand.gold, width: 1.2),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.workspace_premium,
                            color: Color(0xFFB8860B), size: 22),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            tr('drv_mukammal_tasdeeq_aap_ke'),
                            style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF8D6E00)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ] else if (p.registrationDone &&
                    p.unverifiedDocCount > 0) ...[
                  const SizedBox(height: 8),
                  Text(
                    trf('drv_mukammal_tasdeeq_ke_liye', {'unverifiedDocCount': '${p.unverifiedDocCount}'}),
                    style: TextStyle(
                        fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
                  ),
                ],
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: _openRegistration,
                    child: Text(tr('drv_tafseel_badlein_form')),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 18),
        Text(tr('drv_mere_kagaz'),
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        // MERE KAGAZ panel (v1.4.1 — Owner Tasdeeq Duty, Part B):
        // har document ki Master-wali asal haalat — Tasdeeq Shuda ✓ /
        // Reject ✗ Master ki wajah ke saath (lafz-ba-lafz) /
        // Intezaar Mein… Tasdeeq SIRF Master karta hai (v1.2.9 lock
        // barkarar): driver yahan se sirf document DOBARA bhej sakta
        // hai — koi *_status woh khud kabhi set nahi kar sakta.
        Text(
            tr('drv_online_hone_ke_liye'),
            style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
        const SizedBox(height: 8),
        // DEVICE KA USOOL — mustaqil hidayat (malik ka hukm
        // 2026-11-08): ek account, sirf ek device.
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF6E0),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Brand.gold),
          ),
          child: Text(
            tr('drv_device_ka_usool_sirf'),
            style: const TextStyle(
                fontSize: 12.5, height: 1.45, color: Brand.ink),
          ),
        ),
        const SizedBox(height: 10),
        _mereKagazRow(
          group: 'cnic',
          label: 'CNIC',
          kinds: [
            ('cnic_front', tr('drv_cnic_samne_wali_photo')),
            ('cnic_back', tr('drv_cnic_peeche_wali_photo')),
          ],
          photoMissing: p.cnicFrontPath.isEmpty || p.cnicBackPath.isEmpty,
        ),
        _mereKagazRow(
          group: 'gaari',
          label: tr('drv_gaari_ke_kaghaz'),
          kinds: [
            ('vehicle', tr('drv_gaari_ki_photo')),
            // v1.4.77 GUIDE S6: peeche + bayein + dayein
            // tasaveer bhi isi row se dobara bheji jati hain।
            ('vehicle_back', tr('chk_slot_back')),
            ('vehicle_left', tr('reg_slot_left')),
            ('vehicle_right', tr('reg_slot_right')),
            // v1.4.69: kaghaz ki samne/peeche ALAG tasaveer
            // (purani 'vehicle_reg' ki jagah — samne wali usi
            // field ko bhi update karti hai)।
            ('reg_front', tr('chk_slot_reg_front')),
            ('reg_back', tr('chk_slot_reg_back')),
          ],
          photoMissing: !_regFrontDone ||
              p.regBackPath.isEmpty ||
              p.vehiclePhotoPath.isEmpty ||
              p.vehicleBackPath.isEmpty ||
              p.vehicleLeftPath.isEmpty ||
              p.vehicleRightPath.isEmpty,
        ),
        // PTA PROOF (2026-11-08): IMEI wala hisaab — screenshot
        // NAHI. Status Master ka (pull shuda); IMEI sirf wizard se
        // badalta hai. PTA LAZMI shart sirf tab hai jab malik ne
        // Master se "PTA Proof lazmi" ON kiya ho (Fares.ptaRequired,
        // migration v133) — default band (ikhtiyari) hai.
        Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      p.masterStatusFor('pta') == 'verified'
                          ? Icons.verified
                          : p.masterStatusFor('pta') == 'rejected'
                              ? Icons.cancel
                              : Icons.pending_actions,
                      color: p.masterStatusFor('pta') == 'verified'
                          ? Brand.green
                          : p.masterStatusFor('pta') == 'rejected'
                              ? Brand.ajrakRed
                              : const Color(0xFFB8860B),
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Text(tr('drv_pta_proof'),
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                    Text(
                      p.masterStatusFor('pta') == 'verified'
                          ? tr('drv_tasdeeq_shuda')
                          : p.masterStatusFor('pta') == 'rejected'
                              ? tr('drv_reject')
                              : tr('drv_intezaar_mein'),
                      style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: p.masterStatusFor('pta') == 'verified'
                              ? Theme.of(context).colorScheme.primary
                              : p.masterStatusFor('pta') == 'rejected'
                                  ? Theme.of(context).colorScheme.error
                                  : Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Brand.goldLight
                                      : const Color(0xFFB8860B)),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  p.imei.isEmpty
                      ? tr('drv_imei_abhi_darj_nahi')
                      : trf('drv_aap_ka_imei', {'imei': p.imei}),
                  style: const TextStyle(fontSize: 13),
                ),
                if (p.masterStatusFor('pta') == 'rejected' &&
                    p.masterReasonFor('pta').isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(trf('drv_master_ki_wajah', {'p1': p.masterReasonFor('pta')}),
                      style: const TextStyle(
                          fontSize: 12.5,
                          color: Brand.ajrakRed,
                          fontWeight: FontWeight.w600)),
                ],
                const SizedBox(height: 4),
                Text(
                  Fares.ptaRequired
                      ? tr('drv_imei_ghalat_ya_mobile')
                      : tr('drv_filhal_imei_ikhtiyari_hai'),
                  style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Text(tr('reg_t_licence'),
            style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        // Licence hai/nahi — ye registration DATA hai, tasdeeq nahi;
        // ab sirf wizard mein badalta hai, yahan sirf maloomat.
        Text(
          p.licenceStatus == 'has'
              ? trf('drv_licence_hai_badalna_ho', {'p1': p.licenceNumber.isNotEmpty ? ' — ${p.licenceNumber}' : ''})
              : tr('drv_licence_nahi_hai_cnic'),
          style: TextStyle(fontSize: 13, color: Theme.of(context).colorScheme.onSurfaceVariant),
        ),
        if (p.licenceStatus == 'has') ...[
          const SizedBox(height: 8),
          _mereKagazRow(
            group: 'licence',
            label: tr('drv_licence_tasdeeq'),
            kinds: [
              // v1.4.69: licence ki teen ALAG tasaveer (purani
              // single 'licence' ki jagah)।
              ('licence_front', tr('chk_slot_lic_front')),
              ('licence_back', tr('chk_slot_lic_back')),
              ('licence_selfie', tr('chk_slot_lic_selfie')),
            ],
            photoMissing: !_licenceFrontDone ||
                p.licenceBackPath.isEmpty ||
                p.licenceSelfiePath.isEmpty,
          ),
        ],
        const SizedBox(height: 10),
        // TEENO NAYE KAGAZ (v1.4.19 — darmiyani model): Fitness,
        // Insurance, Character Certificate — har ek ki asal
        // Master haalat + reject wajah + sirf wahi document
        // dobara bhejne ka rasta, bilkul CNIC/Gaari wale pattern
        // par। Photo baqi ho ya reject ho to row mein REHNUMAI
        // bhi dikhti hai (kagaz kahan se banta hai)।
        Text(tr('drv_fitness_insurance_aur_character'),
            style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        _mereKagazRow(
          group: 'fitness',
          label: tr('drv_fitness_certificate'),
          kinds: [
            ('fitness_cert', tr('drv_fitness_certificate_ki_photo')),
          ],
          photoMissing: p.fitnessPhotoPath.isEmpty,
        ),
        _mereKagazRow(
          group: 'insurance',
          label: tr('drv_gaari_ki_insurance_third'),
          kinds: [
            ('insurance', tr('drv_insurance_ki_photo')),
          ],
          photoMissing: p.insurancePhotoPath.isEmpty,
        ),
        _mereKagazRow(
          group: 'character',
          label: tr('reg_t_character'),
          kinds: [
            ('character', tr('drv_character_certificate_ki_photo')),
          ],
          photoMissing: p.characterPhotoPath.isEmpty,
        ),
        const SizedBox(height: 10),
        // ROUTE PERMIT (v1.4.14 — owner faisla
        // 2026-11-09): ikhtiyari kagaz; is ka koi Master *_status
        // NAHI hai — haalat sirf ye hai ke photo record mein hai
        // ya nahi। (Fitness Certificate v1.4.19 se is card se
        // nikal kar upar apni Master-status wali row mein chala
        // gaya hai — yahan sirf Route Permit bacha hai।) Na hon
        // to ID par koi asar nahi, lekin driver ki khud-zimmedari
        // wali tasdeeq (registration mein qabool shuda) yahan bhi
        // dikhti hai aur kagaz poora karne ki yaad-dehani bhi —
        // kagaz milte hi yahin se photo lag jati hai (record
        // pakka)।
        Text(tr('drv_route_permit_ikhtiyari'),
            style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _permitDocRow(
                  label: tr('drv_route_permit'),
                  hasPhoto: p.permitPhotoPath.isNotEmpty,
                  onUpload: () => _reuploadDoc('route_permit'),
                ),
                const SizedBox(height: 8),
                Text(
                  p.permitFitnessDeclAtMs > 0
                      ? trf('drv_khud_zimmedari_ki_tasdeeq', {'p1': DateTime.fromMillisecondsSinceEpoch(p.permitFitnessDeclAtMs).toString().split('.').first})
                      : tr('drv_khud_zimmedari_ki_tasdeeq_2'),
                  style: const TextStyle(fontSize: 12.5, height: 1.45),
                ),
                if (p.permitPhotoPath.isEmpty) ...[
                  const SizedBox(height: 6),
                  Text(
                    tr('drv_yaad_dehani_jo_kagaz'),
                    style: const TextStyle(
                        fontSize: 12.5,
                        color: Color(0xFF8D6E00),
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 4),
        // Profile selfie — Master ki ID wali photo. Is ka alag
        // *_status nahi hai; haalat = photo Master tak gayi ya nahi
        // (ID ki asal tasdeeq upar wale Account card mein hai).
        Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: Icon(
              p.profilePhotoPath.isNotEmpty
                  ? Icons.verified
                  : Icons.pending_actions,
              color: p.profilePhotoPath.isNotEmpty
                  ? Brand.green
                  : Brand.ajrakRed,
            ),
            title: Text(tr('drv_profile_selfie_id_wali'),
                style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(
              p.profilePhotoPath.isNotEmpty
                  ? tr('drv_photo_master_ke_paas')
                  : tr('drv_photo_abhi_baqi_hai'),
              style: TextStyle(
                  color: p.profilePhotoPath.isNotEmpty
                      ? Brand.green
                      : Brand.ajrakRed,
                  fontWeight: FontWeight.w600),
            ),
            trailing: p.profilePhotoPath.isEmpty
                ? OutlinedButton(
                    onPressed: () => _reuploadDoc('profile'),
                    child: Text(tr('drv_selfie_dein')),
                  )
                : null,
          ),
        ),
        const SizedBox(height: 18),
        Card(
          child: ListTile(
            leading: Icon(Icons.camera_alt,
                color: p.selfieToday ? Brand.green : Brand.ajrakRed),
            title: Text(tr('drv_rozana_live_selfie')),
            subtitle: Text(p.selfieToday
                ? trf('drv_aaj_ki_selfie_ho_2', {'selfieDate': p.selfieDate})
                : tr('drv_aaj_ki_selfie_baqi')),
            // Yahan wala 'Selfie Lein' button hata diya (v1.2.6 safai) —
            // wohi amal Home ke gate row aur duty-on par pehle se
            // hota hai; yahan sirf haalat dikhti hai.
            trailing: p.selfieToday
                ? const Icon(Icons.check_circle, color: Brand.green)
                : const Icon(Icons.pending_actions,
                    color: Brand.ajrakRed),
          ),
        ),
        const SizedBox(height: 14),
        // PASSWORD (v1.2.5 — malik ka hukm): har driver apna password
        // khud lagata hai; ek password sirf EK driver ka hota hai.
        // v1.2.6: registration baqi ho to password WIZARD ke qadam mein
        // lagta hai — yahan wale inline fields sirf un profiles ke
        // liye hain jin ki registration mukammal hai lekin password
        // abhi nahi laga (purane profiles), taaki do competing forms
        // na hon. Registration wale card (upar) se form khulta hai.
        if (p.pwdFp.isEmpty && !p.registrationComplete)
          Card(
            child: ListTile(
              leading: const Icon(Icons.lock_outline, color: Brand.ajrakRed),
              title: Text(tr('drv_password_baqi_hai'),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(
                  tr('drv_password_registration_form_ke')),
            ),
          )
        else if (p.pwdFp.isEmpty)
          // FORM USOOL (2026-11-08): password ke inline khule fields
          // khatam — Profile sirf haalat dikhati hai aur button wohi
          // _SetPasswordDialog kholta hai jo duty-on par bhi ata hai
          // (usool, uniqueness check aur exact jumle bilkul waisay
          // hi — sirf jagah badli hai, amal nahi).
          Card(
            child: ListTile(
              leading:
                  const Icon(Icons.lock_outline, color: Brand.ajrakRed),
              title: Text(tr('drv_password_baqi_hai'),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(
                  tr('drv_har_driver_apna_password')),
              trailing: TextButton(
                onPressed: () async {
                  final ok = await showDialog<bool>(
                    context: context,
                    barrierDismissible: false,
                    builder: (_) => _SetPasswordDialog(store: store),
                  );
                  if (ok == true && mounted) {
                    _snack(tr('drv_password_lag_gaya'));
                    setState(() {});
                  }
                },
                child: Text(tr('w_lagayein')),
              ),
            ),
          )
        else
          Card(
            child: ListTile(
              leading: const Icon(Icons.lock, color: Brand.green),
              title: Text(tr('drv_password_set_hai'),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(
                  tr('drv_duty_shuru_karne_par')),
              trailing: TextButton(
                onPressed: _changePassword,
                child: Text(tr('w_badlein')),
              ),
            ),
          ),
        // v1.4.7 EMAIL (spec §1): verified Gmail ki haalat — ya
        // purane driver ke liye email darj karne ka darwaza।
        const SizedBox(height: 10),
        if (p.emailVerified)
          Card(
            child: ListTile(
              leading: const Icon(Icons.mark_email_read, color: Brand.green),
              title: Text(tr('drv_gmail_otp_verify_hai'),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(
                  trf('drv_logout_ke_baad_dobara', {'email': p.email})),
              isThreeLine: true,
            ),
          )
        else
          Card(
            child: ListTile(
              leading:
                  const Icon(Icons.email_outlined, color: Brand.ajrakRed),
              title: Text(tr('drv_gmail_darj_karein_lazmi'),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(
                  tr('drv_aap_ki_id_ke')),
              trailing: TextButton(
                onPressed: () async {
                  final ok = await Navigator.of(context).push<bool>(
                    MaterialPageRoute(
                        builder: (_) => _EmailSetupPage(store: store)),
                  );
                  if (ok == true && mounted) {
                    _snack(tr('drv_gmail_verify_ho_gaya'));
                    setState(() {});
                  }
                },
                child: Text(tr('drv_darj_karein')),
              ),
            ),
          ),
        // v1.4.7 GAARI CHANGE (spec §7): wohi ID, nayi gaari —
        // Master ki tasdeeq ke baad update; purani gaari history
        // mein mehfooz।
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.swap_horiz,
                        color: Brand.green, size: 20),
                    const SizedBox(width: 8),
                    Text(tr('drv_meri_gaari'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 15)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                    trf('drv_plate', {'vehicle': p.vehicle, 'vehicleBrand': p.vehicleBrand, 'vehicleModel': p.vehicleModel, 'p1': p.plate.isEmpty ? '—' : p.plate})),
                if (p.vehicleHistory.isNotEmpty)
                  Text(
                    trf('drv_purani_gaariyon_ka_record', {'length': '${p.vehicleHistory.length}'}),
                    style:
                        TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
                  ),
                const SizedBox(height: 8),
                if (p.vehicleChangeStatus == 'pending') ...[
                  Text(
                    tr('drv_gaari_change_ki_darkhwast'),
                    style: TextStyle(
                        color: Theme.of(context).brightness ==
                                Brightness.dark
                            ? Brand.goldLight
                            : const Color(0xFFB8860B),
                        fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 6),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final ok = await Backend.submitVehicleChange(
                          store, p.vehicleChangePending);
                      if (mounted) {
                        _snack(ok
                            ? tr('drv_darkhwast_dobara_master_ko')
                            : tr('drv_abhi_nahi_bheji_ja'));
                      }
                    },
                    icon: const Icon(Icons.refresh, size: 16),
                    label: Text(tr('drv_darkhwast_dobara_bhejein')),
                  ),
                ] else ...[
                  if (p.vehicleChangeStatus == 'rejected') ...[
                    Text(
                      trf('drv_pichli_gaari_change_reject', {'p1': p.vehicleChangeReason.isEmpty ? '' : trf('frag_wajah_suffix_cap', {'reason': p.vehicleChangeReason})}),
                      style: const TextStyle(
                          color: Brand.ajrakRed,
                          fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 6),
                  ],
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        await Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => VehicleChangePage(store: store),
                        ));
                        if (mounted) setState(() {});
                      },
                      icon: const Icon(Icons.directions_car),
                      label: Text(tr('veh_title')),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        // v1.4.7 LOGOUT: session OTP flag saaf — dobara duty ke
        // liye password ke baad Email OTP lazmi (jin ka email
        // verify hai)। Profile/record kuch delete NAHI hota।
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: Text(tr('drv_logout_karein')),
                  content: Text(
                      tr('drv_logout_ke_baad_dobara_2')),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: Text(tr('veh_dialog_cancel'))),
                    ElevatedButton(
                        onPressed: () => Navigator.pop(ctx, true),
                        child: Text(tr('drv_logout_karein_2'))),
                  ],
                ),
              );
              if (ok == true) {
                await store.driverLogout();
                // v1.4.14: Auth session bhi saaf — dobara login
                // OTP se naya session banayega (plan §8.1.1)।
                unawaited(Backend.clearSession());
                unawaited(_syncDutyService());
                if (mounted) {
                  _snack(tr('drv_logout_ho_gaya_hai'));
                  setState(() {});
                }
              }
            },
            icon: const Icon(Icons.logout, size: 18),
            label: const Text('Logout'),
            style: OutlinedButton.styleFrom(
              foregroundColor: Brand.ajrakRed,
              side: const BorderSide(color: Brand.ajrakRed),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
        // v1.4.16 ACCOUNT DELETE: Logout se alag, mustaqil amal —
        // OTP tasdeeq + server RPC ke baad hi local wipe hota
        // hai (poora flow _deleteDriverAccount mein hai)।
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: TextButton.icon(
            onPressed: _deleteDriverAccount,
            icon: const Icon(Icons.delete_forever, size: 18),
            label: Text(tr('legal_del_tile')),
            style: TextButton.styleFrom(
              foregroundColor: Brand.ajrakRed,
              padding: const EdgeInsets.symmetric(vertical: 10),
              textStyle:
                  const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700),
            ),
          ),
        ),
        // NOTE (v1.0.5): "Service Charges %" editor yahan kabhi tha
        // hi nahi rakha gaya — fee sirf Master app mein set hoti hai.
        // NOTE (FORM USOOL 2026-11-08): purana "Profile Save Karein"
        // wala khula form (naam/phone/plate/gaari ke inline fields
        // + un ke saath chalta password set) yahan se KHTAM hai —
        // Profile ab sirf status + buttons hai; har tabdeeli
        // RegistrationWizard mein step-by-step hoti hai.
      ],
    );
  }

  /// Permit/Fitness ki ek saadi row (v1.4.14): photo hai to
  /// sabz nishan + 'Record mein hai', nahi hai to 'Abhi nahi'
  /// + photo lagane ka button। Master ka koi faisla in par
  /// NAHI hota — ye sirf driver ke apne record ke kagaz hain।
  Widget _permitDocRow({
    required String label,
    required bool hasPhoto,
    required VoidCallback onUpload,
  }) {
    return Row(
      children: [
        Icon(
          hasPhoto ? Icons.verified : Icons.pending_actions,
          color: hasPhoto ? Brand.green : const Color(0xFFB8860B),
        ),
        const SizedBox(width: 9),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              Text(
                hasPhoto
                    ? tr('drv_photo_record_mein_hai')
                    : tr('drv_photo_abhi_nahi_ho'),
                style: TextStyle(
                    fontSize: 12.5,
                    color: hasPhoto
                        ? Theme.of(context).colorScheme.primary
                        : Theme.of(context).colorScheme.onSurfaceVariant,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        OutlinedButton(
          onPressed: onUpload,
          child: Text(hasPhoto ? 'Badlein' : tr('drv_photo_lagayein')),
        ),
      ],
    );
  }

  /// Mere Kagaz ki ek document row (v1.4.1): SIRF Master ka pull
  /// shuda faisla + us ki wajah lafz-ba-lafz. Teen asal haalatein:
  ///  - verified → 'Tasdeeq Shuda ✓' (sabz)
  ///  - rejected → 'Reject ✗' (laal) + Master ki wajah wali numaya
  ///    patti + 'Dobara Bhejein' — sirf yehi document dobara jata
  ///    hai (upload flow se; status driver NAHI badalta)
  ///  - rejected lekin nayi photo bhej di gayi → 'Dobara bhej diya
  ///    gaya — Intezaar Mein…' (amber; pichli wajah chhoti line mein)
  ///  - warna → 'Intezaar Mein…' (amber)
  /// Photo hi baqi ho to bhi yehi row 'Kagaz Dein' se sirf wohi
  /// photo mangti hai.
  // ===== DOCUMENTS CHECKLIST (v1.4.68 — malik ka hukm 2026-11-22) =====
  //
  // Nayi tartib: ID basic maloomat par pehle ban jati hai
  // (registration wizard), phir documents yahan Home par ek
  // ek karke lagte hain — har qadam apna card: saaf Roman
  // Urdu label, haalat (photo baqi / tasdeeq baqi / tasdeeq
  // shuda / reject + Master ki wajah), aur apna button।
  // Upload ka rasta wohi purana pakka hai jo "Mere Kagaz"
  // istemal karta hai (_reuploadDoc / _reuploadGroup →
  // profile field → store.save() → Backend.syncDriverDocs →
  // bucket 'driver-docs' + Master ki queue) — koi naya server
  // rasta NAHI banaya gaya। Progress upar "N / M ho gaye" +
  // sabz patti mein dikhti hai taake driver ko har lamhe pata
  // ho kitna reh gaya — pehli koshish mein mukammal karna
  // asaan ho।
  final GlobalKey _checklistKey = GlobalKey();

  /// v1.4.69: Licence ki SAMNE wali photo maujood hai? Nayi
  /// alag front photo ho to woh, warna purani single licence
  /// photo hi samne wali mani jati hai (backward compat — purane
  /// driver ki photo zaya nahi hoti)।
  bool get _licenceFrontDone =>
      p.licenceFrontPath.isNotEmpty || p.licencePhotoPath.isNotEmpty;

  /// v1.4.69: Registration kaghaz ki SAMNE wali photo — wohi
  /// usool: nayi reg_front ho to woh, warna purani single
  /// kaghaz photo hi samne wali।
  bool get _regFrontDone =>
      p.regFrontPath.isNotEmpty || p.vehicleRegPath.isNotEmpty;

  /// Koi lazmi checklist tasveer abhi baqi hai?
  bool get _checklistHasMissing =>
      p.cnicFrontPath.isEmpty ||
      p.cnicBackPath.isEmpty ||
      (p.licenceStatus == 'has' &&
          (!_licenceFrontDone ||
              p.licenceBackPath.isEmpty ||
              p.licenceSelfiePath.isEmpty)) ||
      !_regFrontDone ||
      p.regBackPath.isEmpty ||
      p.vehiclePhotoPath.isEmpty ||
      p.vehicleBackPath.isEmpty ||
      // v1.4.77 GUIDE S6: bayein/dayein tasaveer bhi lazmi set
      // mein hain (chaar tasaveer wala naya usool)।
      p.vehicleLeftPath.isEmpty ||
      p.vehicleRightPath.isEmpty ||
      p.profilePhotoPath.isEmpty;

  /// Home ke registration card wala button (ID bani hui ho to)
  /// checklist tak narmi se scroll kar deta hai।
  void _scrollToChecklist() {
    final ctx = _checklistKey.currentContext;
    if (ctx != null) {
      Scrollable.ensureVisible(ctx,
          duration: const Duration(milliseconds: 450),
          curve: Curves.easeInOut);
    }
  }

  Widget _docsChecklistCard() {
    // v1.4.75: checklist ki tartib ab Yango-form wali fehrist
    // par hai — pehle Licence (front/back/pakre selfie), phir
    // CNIC, phir Registration kaghaz, phir Gaari ki tasaveer,
    // aakhir mein Profile selfie।
    final items = <(IconData, String, String, bool, String?, VoidCallback)>[
      if (p.licenceStatus == 'has')
        (
          Icons.badge,
          tr('chk_licence'),
          tr('chk_licence_sub'),
          _licenceFrontDone &&
              p.licenceBackPath.isNotEmpty &&
              p.licenceSelfiePath.isNotEmpty,
          'licence',
          () => _reuploadGroup([
                ('licence_front', tr('chk_slot_lic_front')),
                ('licence_back', tr('chk_slot_lic_back')),
                ('licence_selfie', tr('chk_slot_lic_selfie')),
              ]),
        ),
      (
        Icons.credit_card,
        tr('chk_cnic'),
        tr('chk_cnic_sub'),
        p.cnicFrontPath.isNotEmpty && p.cnicBackPath.isNotEmpty,
        'cnic',
        () => _reuploadGroup([
              ('cnic_front', tr('drv_cnic_samne_wali_photo')),
              ('cnic_back', tr('drv_cnic_peeche_wali_photo')),
            ]),
      ),
      (
        Icons.description,
        tr('chk_reg'),
        tr('chk_reg_sub'),
        _regFrontDone && p.regBackPath.isNotEmpty,
        'gaari',
        () => _reuploadGroup([
              ('reg_front', tr('chk_slot_reg_front')),
              ('reg_back', tr('chk_slot_reg_back')),
            ]),
      ),
      (
        Icons.photo_camera,
        tr('chk_vehicle'),
        tr('chk_vehicle_sub'),
        p.vehiclePhotoPath.isNotEmpty &&
            p.vehicleBackPath.isNotEmpty &&
            p.vehicleLeftPath.isNotEmpty &&
            p.vehicleRightPath.isNotEmpty,
        'gaari',
        () => _reuploadGroup([
              ('vehicle', tr('chk_slot_front')),
              ('vehicle_back', tr('chk_slot_back')),
              ('vehicle_left', tr('reg_slot_left')),
              ('vehicle_right', tr('reg_slot_right')),
            ]),
      ),
      (
        Icons.face,
        tr('chk_selfie'),
        tr('chk_selfie_sub'),
        p.profilePhotoPath.isNotEmpty,
        null,
        () => _reuploadDoc('profile'),
      ),
    ];
    final doneCount = items.where((e) => e.$4).length;
    return Card(
      key: _checklistKey,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.checklist, color: Brand.green, size: 24),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(tr('chk_title'),
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w900)),
                ),
                Text(
                    trf('chk_progress', {
                      'done': '$doneCount',
                      'total': '${items.length}'
                    }),
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, color: Brand.green)),
              ],
            ),
            const SizedBox(height: 6),
            Text(tr('chk_sub'),
                style: TextStyle(
                    fontSize: 12.5,
                    height: 1.4,
                    color: Theme.of(context).colorScheme.onSurfaceVariant)),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: items.isEmpty ? 0 : doneCount / items.length,
              color: Brand.green,
              backgroundColor: Brand.fieldBorder,
              minHeight: 6,
              borderRadius: BorderRadius.circular(3),
            ),
            const SizedBox(height: 4),
            for (var i = 0; i < items.length; i++) ...[
              if (i > 0) const Divider(height: 1),
              _checklistItem(
                icon: items[i].$1,
                title: items[i].$2,
                subtitle: items[i].$3,
                photoDone: items[i].$4,
                group: items[i].$5,
                onUpload: items[i].$6,
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Checklist ki ek satr: sabz gola (ho gaya) ya sunehre
  /// kinare wala gola (baqi), label + chhoti hidayat, haalat
  /// ki satr, aur zarurat ho to "Photo Lagayein" button।
  /// Reject par Master ki wajah bhi yahin dikhti hai aur
  /// button dobara bhejne ka ho jata hai — bilkul "Mere
  /// Kagaz" wala usool, lekin Home par numaya checklist ki
  /// shakal mein (hamari apni design)।
  Widget _checklistItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool photoDone,
    required String? group,
    required VoidCallback onUpload,
  }) {
    final status = group == null ? '' : p.masterStatusFor(group);
    final verified = photoDone && status == 'verified';
    final rejected = photoDone && status == 'rejected';
    final String halat;
    if (!photoDone) {
      halat = tr('chk_baqi');
    } else if (verified) {
      halat = tr('drv_tasdeeq_shuda');
    } else if (rejected) {
      halat = tr('drv_reject');
    } else if (group == null) {
      halat = tr('chk_hogaya');
    } else {
      halat = tr('chk_tasdeeq_baqi');
    }
    final halatColor = verified || (photoDone && group == null)
        ? Brand.green
        : rejected
            ? Brand.ajrakRed
            : photoDone
                ? const Color(0xFFB8860B)
                : Brand.ajrakRed;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 9),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: photoDone ? Brand.green : Brand.lightBg,
              shape: BoxShape.circle,
              border: photoDone
                  ? null
                  : Border.all(color: Brand.gold, width: 1.4),
            ),
            child: Icon(photoDone ? Icons.check : icon,
                size: 19,
                color: photoDone ? Colors.white : Brand.greenDark),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 14.5, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(subtitle,
                    style: TextStyle(
                        fontSize: 12.5,
                        height: 1.35,
                        color:
                            Theme.of(context).colorScheme.onSurfaceVariant)),
                const SizedBox(height: 3),
                Text(halat,
                    style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: halatColor)),
                if (rejected &&
                    p.masterReasonFor(group ?? '').isNotEmpty) ...[
                  const SizedBox(height: 3),
                  Text(p.masterReasonFor(group ?? ''),
                      style: const TextStyle(
                          fontSize: 12,
                          color: Brand.ajrakRed,
                          fontWeight: FontWeight.w600)),
                ],
              ],
            ),
          ),
          if (!photoDone || rejected) ...[
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: onUpload,
              style: ElevatedButton.styleFrom(
                backgroundColor: Brand.greenDark,
                foregroundColor: Brand.goldLight,
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              ),
              child: Text(rejected ? tr('reg_retry') : tr('chk_btn'),
                  style: const TextStyle(
                      fontSize: 12.5, fontWeight: FontWeight.w800)),
            ),
          ],
        ],
      ),
    );
  }

  Widget _mereKagazRow({
    required String group,
    required String label,
    required List<(String, String)> kinds,
    required bool photoMissing,
  }) {
    final status = p.masterStatusFor(group);
    final reason = p.masterReasonFor(group);
    final resubmitted = p.docGroupResubmitted(group);
    final rejected = status == 'rejected' && !resubmitted;
    // v1.4.19 REHNUMAI (malik ka hukm ~18:12): naye kagazon
    // (fitness/insurance/character) ke liye woh madad wali line
    // jo batati hai kagaz kahan se banta hai — photo baqi ho ya
    // reject ho, dono halaton mein row ke andar dikhti hai।
    final rehnumai = docRehnumaiFor(group);
    final cs = Theme.of(context).colorScheme;
    final pendingGold = Theme.of(context).brightness == Brightness.dark
        ? Brand.goldLight
        : const Color(0xFFB8860B);
    final (statusText, color, icon) = switch (status) {
      'verified' => (tr('drv_tasdeeq_shuda'), cs.primary, Icons.verified),
      'rejected' when resubmitted => (
          tr('drv_dobara_bhej_diya_gaya'),
          pendingGold,
          Icons.hourglass_top
        ),
      'rejected' => (tr('drv_reject'), cs.error, Icons.cancel),
      _ => (tr('drv_intezaar_mein'), pendingGold, Icons.pending_actions),
    };
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(label,
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
                Text(statusText,
                    style:
                        TextStyle(color: color, fontWeight: FontWeight.w800)),
              ],
            ),
            if (photoMissing && status != 'rejected') ...[
              const SizedBox(height: 6),
              Text(
                tr('drv_photo_abhi_baqi_hai_2'),
                style: TextStyle(fontSize: 12.5, color: Theme.of(context).colorScheme.error),
              ),
              if (rehnumai.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(rehnumai,
                    style: TextStyle(
                        fontSize: 12.5,
                        height: 1.45,
                        color: Theme.of(context).colorScheme.onSurfaceVariant)),
              ],
            ],
            if (rejected) ...[
              const SizedBox(height: 8),
              // Numaya wajah wali patti — Master ke alfaaz bilkul
              // waisay hi (verbatim) jo Master ne reject par likhe.
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFFDECEA),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Brand.ajrakRed),
                ),
                child: Text(
                  reason.isNotEmpty
                      ? trf('drv_master_ki_wajah_2', {'reason': reason})
                      : tr('drv_master_ne_ye_document'),
                  style: const TextStyle(
                      fontSize: 13,
                      color: Brand.ajrakRed,
                      fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => _reuploadGroup(kinds),
                  icon: const Icon(Icons.upload_file, size: 19),
                  label: Text(tr('reg_retry')),
                ),
              ),
              if (rehnumai.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(rehnumai,
                    style: TextStyle(
                        fontSize: 12.5,
                        height: 1.45,
                        color: Theme.of(context).colorScheme.onSurfaceVariant)),
              ],
            ] else if (status == 'rejected' && resubmitted) ...[
              const SizedBox(height: 6),
              Text(
                trf('drv_nayi_photo_master_ke', {'p1': reason.isNotEmpty ? trf('frag_pichli_wajah', {'reason': reason}) : ''}),
                style: TextStyle(fontSize: 12.5, color: Theme.of(context).colorScheme.onSurfaceVariant),
              ),
              const SizedBox(height: 6),
              Align(
                alignment: Alignment.centerRight,
                child: OutlinedButton(
                  onPressed: () => _reuploadGroup(kinds),
                  child: Text(tr('drv_ek_aur_photo_bhejein')),
                ),
              ),
            ] else if (photoMissing) ...[
              const SizedBox(height: 6),
              Align(
                alignment: Alignment.centerRight,
                child: OutlinedButton(
                  onPressed: () => _reuploadGroup(kinds),
                  child: Text(tr('drv_kagaz_dein')),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Har upload slot ki chhoti helper line (v1.4.69 — malik ka
  /// hukm 2026-11-22: har khane ke saath saaf label ke saath
  /// hidayat bhi ho ke yahan KYA lagana hai)। Jis kind ki helper
  /// line nahi, wahan null (sheet mein subtitle nahi ata)।
  String? _slotHelp(String kind) => switch (kind) {
        'cnic_front' => tr('help_slot_cnic_front'),
        'cnic_back' => tr('help_slot_cnic_back'),
        'vehicle' => tr('help_slot_vehicle_front'),
        'vehicle_back' => tr('help_slot_vehicle_back'),
        // v1.4.77 GUIDE S6: bayein/dayein slots ki hidayat।
        'vehicle_left' => tr('help_slot_vehicle_left'),
        'vehicle_right' => tr('help_slot_vehicle_right'),
        'licence_front' => tr('help_slot_lic_front'),
        'licence_back' => tr('help_slot_lic_back'),
        'licence_selfie' => tr('help_slot_lic_selfie'),
        'reg_front' => tr('help_slot_reg_front'),
        'reg_back' => tr('help_slot_reg_back'),
        _ => null,
      };

  /// Dobara bhejne ke liye photo chunnna: group mein ek se zyada
  /// photo ho (CNIC samne/peeche, gaari/kaghaz) to pehle kaun si
  /// photo, phir camera/gallery — registration wala wohi pattern.
  /// Sirf chuni hui EK photo profile mein lagti hai; baqi documents
  /// bilkul nahi chharte.
  Future<void> _reuploadGroup(List<(String, String)> kinds) async {
    if (kinds.length == 1) {
      await _reuploadDoc(kinds.first.$1);
      return;
    }
    final picked = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Text(tr('drv_kaun_si_photo_dobara'),
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 15)),
            ),
            for (final k in kinds)
              ListTile(
                leading: const Icon(Icons.photo_camera, color: Brand.green),
                title: Text(k.$2),
                // v1.4.69: har slot ke naam ke neeche chhoti
                // helper line — driver ko pehle se maloom ho ke
                // is khane mein KYA lagana hai (malik ka hukm
                // 2026-11-22)।
                subtitle: _slotHelp(k.$1) == null
                    ? null
                    : Text(_slotHelp(k.$1)!,
                        style: TextStyle(
                            fontSize: 12,
                            height: 1.35,
                            color: Theme.of(context)
                                .colorScheme
                                .onSurfaceVariant)),
                onTap: () => Navigator.pop(ctx, k.$1),
              ),
          ],
        ),
      ),
    );
    if (picked != null && mounted) await _reuploadDoc(picked);
  }

  /// SIRF ek document ki nayi photo bhejna (v1.4.1): photo profile
  /// ke usi ek field mein lagti hai, phir store.save() → 'profile'
  /// hook → Backend.syncDriverDocs SIRF is kind ko dobara upload
  /// karta hai (docUploaded marker usi ek ka badla hota hai) —
  /// Master ke paas nayi photo puhanchti hai aur woh dobara check
  /// karta hai. Is amal mein driver koi *_status NAHI likhta:
  /// backend status Master ke naye faisle tak waisa hi rehta hai
  /// (migration v130 ka resubmit-trigger use 'pending' par wapas
  /// le jata hai — database khud, driver nahi). Profile selfie
  /// hamesha camera se hi (live) hoti hai.
  Future<void> _reuploadDoc(String kind) async {
    // v1.4.69: licence pakre hue selfie bhi profile selfie ki
    // tarah SIRF live camera se hoti hai (gallery se nahi)।
    ImageSource? src = (kind == 'profile' || kind == 'licence_selfie')
        ? ImageSource.camera
        : null;
    src ??= await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Brand.green),
              title: Text(tr('pick_camera')),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Brand.green),
              title: Text(tr('pick_gallery')),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (src == null || !mounted) return;
    try {
      final img = await _picker.pickImage(source: src, imageQuality: 85);
      if (img == null) {
        if (mounted) {
          _snack(
              tr('photo_snack_nophoto'));
        }
        return;
      }
      switch (kind) {
        case 'cnic_front':
          p.cnicFrontPath = img.path;
        case 'cnic_back':
          p.cnicBackPath = img.path;
        case 'vehicle':
          p.vehiclePhotoPath = img.path;
        case 'vehicle_reg':
          p.vehicleRegPath = img.path;
        // v1.4.68: gaari ki peeche wali tasveer — Home ki
        // checklist se (syncDriverDocs is kind ko pehle se
        // upload karta hai: object 'vehicle_back')।
        case 'vehicle_back':
          p.vehicleBackPath = img.path;
        // v1.4.77 GUIDE S6: bayein/dayein tasaveer — sync
        // mechanism pehle se in kinds ko upload karta hai
        // (objects 'vehicle_left' / 'vehicle_right')।
        case 'vehicle_left':
          p.vehicleLeftPath = img.path;
        case 'vehicle_right':
          p.vehicleRightPath = img.path;
        case 'licence':
          p.licencePhotoPath = img.path;
        // v1.4.69: Licence ki alag tasaveer — samne wali lagte
        // hi purani single wali field bhi usi photo par set ho
        // jati hai (purana 'licence' kind/column bilkul waisa hi
        // chalta rehta hai; Master mein purani jagah par bhi yehi
        // samne wali photo dikhti hai)।
        case 'licence_front':
          p.licenceFrontPath = img.path;
          p.licencePhotoPath = img.path;
        case 'licence_back':
          p.licenceBackPath = img.path;
        case 'licence_selfie':
          p.licenceSelfiePath = img.path;
        // v1.4.69: Registration kaghaz ki alag tasaveer — samne
        // wali purani 'vehicle_reg' field mein bhi wohi photo
        // (registrationComplete aur purani jagahain barkarar)।
        case 'reg_front':
          p.regFrontPath = img.path;
          p.vehicleRegPath = img.path;
        case 'reg_back':
          p.regBackPath = img.path;
        // v1.4.14: ikhtiyari kagaz — Mere Kagaz ke Route Permit
        // hisse se (koi Master *_status nahi; upload sirf record
        // ke liye hai — syncDriverDocs bucket bhej deta hai)।
        case 'route_permit':
          p.permitPhotoPath = img.path;
        // v1.4.19: Fitness ab Master-status wala kagaz hai
        // (fitness_status, migration v139) — baqi status walay
        // kagazon ki tarah resubmit marker lagta hai।
        case 'fitness_cert':
          p.fitnessPhotoPath = img.path;
        // v1.4.19: do naye kagaz — sirf in ki apni photo badalti
        // hai, baqi documents bilkul nahi chharte।
        case 'insurance':
          p.insurancePhotoPath = img.path;
        case 'character':
          p.characterPhotoPath = img.path;
        case 'profile':
          p.profilePhotoPath = img.path;
      }
      await store.save();
      final isPermitKind = kind == 'route_permit';
      if (!isPermitKind) {
        await store.markDocResubmitted(kind, img.path);
      }
      if (mounted) {
        _snack(isPermitKind
            ? tr('drv_photo_lag_gayi_hai')
            : tr('drv_dobara_bhej_diya_gaya_2'));
        setState(() {});
      }
    } catch (_) {
      if (mounted) _snack(tr('pick_photo_failed'));
    }
  }

}

/// A / B wala badge (safarAbBadge) v1.4.42 se theme.dart mein
/// hai — driver + passenger dono wohi widget istemal karte
/// hain (v1.4.29 ka design barkarar; yahan se hata kar wahan
/// rakha gaya hai taake do jagah do shaklain na ban jayein)।

/// Bara SLIDE-wala confirm button — v1.4.29 (spec 2026-11-11):
/// Arrived / Start Trip / Complete jaise ahem amal sirf gol
/// handle ko dayein kinare tak slide karne par hote hain —
/// galti se tap ho jane ka khatra khatam. Rang Bozdar Safar
/// ke hain: gehra sabz track, sunehra handle (peela NAHI —
/// sunehra hamara apna brand rang hai)।
class SlideConfirm extends StatefulWidget {
  final String label;
  final IconData handleIcon;
  final Future<void> Function() onConfirm;

  /// Bahari busy haalat (masalan start-code ki jaanch chal
  /// rahi ho) — slide band rehta hai।
  final bool busy;
  const SlideConfirm({
    super.key,
    required this.label,
    required this.onConfirm,
    this.handleIcon = Icons.arrow_forward,
    this.busy = false,
  });

  @override
  State<SlideConfirm> createState() => _SlideConfirmState();
}

class _SlideConfirmState extends State<SlideConfirm> {
  double _dx = 0;
  bool _busy = false;

  /// Slide band hai: apni amal-haalat ya bahari [SlideConfirm.busy]।
  bool get _locked => _busy || widget.busy;
  static const double _h = 58;
  static const double _handle = 50;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, cons) {
        final maxDx = cons.maxWidth - _handle - 8;
        final frac = maxDx <= 0 ? 0.0 : (_dx / maxDx).clamp(0.0, 1.0);
        return Container(
          height: _h,
          decoration: BoxDecoration(
            color: Brand.deepGreen,
            borderRadius: BorderRadius.circular(_h / 2),
            border: Border.all(color: Brand.gold, width: 1.2),
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: FractionallySizedBox(
                    widthFactor: frac,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Brand.green.withOpacity(0.55),
                        borderRadius: BorderRadius.circular(_h / 2),
                      ),
                    ),
                  ),
                ),
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(left: 30),
                  child: Text(
                    _locked ? '…' : widget.label,
                    style: TextStyle(
                      color: Colors.white.withOpacity(1 - frac * 0.55),
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 4 + _dx,
                top: 4,
                child: GestureDetector(
                  onHorizontalDragUpdate: _locked
                      ? null
                      : (d) => setState(() =>
                          _dx = (_dx + d.delta.dx).clamp(0.0, maxDx)),
                  onHorizontalDragEnd: _locked
                      ? null
                      : (_) async {
                          if (maxDx > 0 && _dx >= maxDx * 0.85) {
                            setState(() {
                              _busy = true;
                              _dx = maxDx;
                            });
                            await widget.onConfirm();
                            if (mounted) {
                              setState(() {
                                _busy = false;
                                _dx = 0;
                              });
                            }
                          } else {
                            setState(() => _dx = 0);
                          }
                        },
                  child: Container(
                    width: _handle,
                    height: _handle,
                    decoration: const BoxDecoration(
                      color: Brand.gold,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(widget.handleIcon,
                        color: Brand.deepGreen, size: 26),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// v1.4.56 DO-RUKHA DUTY SLIDE SWITCH — driver home ka WAHID
/// online/offline control (malik ka hukm: sirf EK slide button;
/// koi alag on/off toggle kahin nahi)। Track ke BAYEN kinare
/// par "Offline" aur DAYEN kinare par "Online" likha hai —
/// dono lafz hamesha nazar ate hain। Ghuta (knob) dayen
/// ghaseeto to ONLINE, bayen ghaseeto to OFFLINE; poori track
/// par tap bhi wohi amal karta hai (tap fallback)।
/// Peeche wohi purana _toggleOnline hai — saare gates (selfie,
/// ID active, kagaz, Amanat balance, password, OTP) usi mein
/// hain; gate rok de to ghuta khud purani jagah wapas aa jata
/// hai (asal haalat hamesha [online] prop se tay hoti hai)।
/// Rang sirf brand ke: gehri sabz track, sunehra kinara aur
/// ghuta — peela bilkul nahi। Shakal SlideConfirm wali hi
/// ghar-ki slide zubaan hai।
class DutySlideSwitch extends StatefulWidget {
  final bool online;
  final Future<void> Function() onToggle;
  const DutySlideSwitch(
      {super.key, required this.online, required this.onToggle});

  @override
  State<DutySlideSwitch> createState() => _DutySlideSwitchState();
}

class _DutySlideSwitchState extends State<DutySlideSwitch> {
  static const double _h = 64;
  static const double _knob = 52;
  // Har kinare par lafz (Offline/Online) ki pakki jagah —
  // ghuta is jagah ke andar nahi jata, is liye dono lafz
  // har haalat mein saaf nazar ate hain।
  static const double _slot = 60;

  double? _knobLeft;
  bool _busy = false;

  bool get _locked => _busy;

  Future<void> _confirm() async {
    if (_busy) return;
    setState(() => _busy = true);
    await widget.onToggle();
    if (mounted) {
      setState(() {
        _busy = false;
        // Haalat ab prop se tay hogi: toggle kamyab ho to
        // ghuta nayi kinare wali jagah par, gate ne roka ho
        // to khud purani jagah wapas।
        _knobLeft = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, cons) {
        final w = cons.maxWidth;
        const minLeft = _slot - 2;
        final maxLeft = w - _slot + 2 - _knob;
        final travel = (maxLeft - minLeft).clamp(1.0, double.infinity);
        final restLeft = widget.online ? maxLeft : minLeft;
        final left = (_knobLeft ?? restLeft).clamp(minLeft, maxLeft);
        final frac = ((left - minLeft) / travel).clamp(0.0, 1.0);
        // Darmiyan ka matan ghute wali taraf se hat kar rehta
        // hai — ghuta us ke upar se guzre to matan halka ho
        // jata hai (SlideConfirm wala hi rawaiya)।
        final fade = (widget.online ? (1 - frac) : frac) * 0.45;
        return GestureDetector(
          onTap: _locked ? null : _confirm,
          child: Container(
            height: _h,
            decoration: BoxDecoration(
              color: Brand.deepGreen,
              borderRadius: BorderRadius.circular(_h / 2),
              border: Border.all(color: Brand.gold, width: 1.5),
            ),
            child: Stack(
              children: [
                // Bharai: ghute tak sabz chamak — kitna hissa
                // "on" taraf hai, is ka khamosh ishara।
                Positioned.fill(
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: FractionallySizedBox(
                      widthFactor: ((left + _knob / 2) / w).clamp(0.0, 1.0),
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                              colors: [Brand.green, Brand.brightGreen]),
                          borderRadius: BorderRadius.circular(_h / 2),
                        ),
                      ),
                    ),
                  ),
                ),
                // BAYEN kinara = Offline (safed)।
                Positioned(
                  left: 0,
                  top: 0,
                  bottom: 0,
                  width: _slot,
                  child: Center(
                    child: Text(
                      tr('drv_slide_off_word').toUpperCase(),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.6),
                    ),
                  ),
                ),
                // DAYEN kinara = Online (sunehra)।
                Positioned(
                  right: 0,
                  top: 0,
                  bottom: 0,
                  width: _slot,
                  child: Center(
                    child: Text(
                      tr('drv_slide_on_word').toUpperCase(),
                      style: const TextStyle(
                          color: Brand.goldLight,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.6),
                    ),
                  ),
                ),
                // Darmiyan ka matan: haalat + hidayat। Ghuta jis
                // kinare par thehra hai, matan doosri taraf ki
                // khaali jagah mein rehta hai।
                Center(
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: widget.online ? _slot : _slot + _knob - 4,
                      right: widget.online ? _slot + _knob - 4 : _slot,
                    ),
                    child: Text(
                      _busy
                          ? '…'
                          : (widget.online
                              ? tr('drv_slide_on_duty')
                              : tr('drv_slide_go_online_hint')),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white.withOpacity(1 - fade),
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
                // Ghuta (knob): sunehra gol — offline par dayen
                // ka teer, online par bayen ka teer (wapas slide
                // ki hidayat)।
                Positioned(
                  left: left,
                  top: (_h - _knob) / 2,
                  child: GestureDetector(
                    onHorizontalDragUpdate: _locked
                        ? null
                        : (d) => setState(() => _knobLeft =
                            ((_knobLeft ?? restLeft) + d.delta.dx)
                                .clamp(minLeft, maxLeft)),
                    onHorizontalDragEnd: _locked
                        ? null
                        : (_) {
                            final cur = _knobLeft ?? restLeft;
                            final f =
                                ((cur - minLeft) / travel).clamp(0.0, 1.0);
                            if (!widget.online && f >= 0.75) {
                              setState(() => _knobLeft = maxLeft);
                              _confirm();
                            } else if (widget.online && f <= 0.25) {
                              setState(() => _knobLeft = minLeft);
                              _confirm();
                            } else {
                              setState(() => _knobLeft = null);
                            }
                          },
                    child: Container(
                      width: _knob,
                      height: _knob,
                      decoration: const BoxDecoration(
                        color: Brand.gold,
                        shape: BoxShape.circle,
                      ),
                      child: _busy
                          ? const Padding(
                              padding: EdgeInsets.all(14),
                              child: CircularProgressIndicator(
                                  strokeWidth: 3, color: Brand.deepGreen),
                            )
                          : Icon(
                              widget.online
                                  ? Icons.arrow_back
                                  : Icons.arrow_forward,
                              color: Brand.deepGreen,
                              size: 27),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Hadaf (pickup/manzil) tak ke asal route ka ETA chip —
/// RouteService (OSRM + cache) se banta hai. Driver ki position
/// ya asal route na mile to chip NAHI dikhta (jaali number
/// kabhi NAHI). Position ka ~100 m se zyada badlav (rounded
/// key) par hi dobara fetch hota hai — cache ki wajah se
/// sastah hai।
class _TargetEta extends StatefulWidget {
  final ll2.LatLng? from;
  final ll2.LatLng to;
  const _TargetEta({required this.from, required this.to});

  @override
  State<_TargetEta> createState() => _TargetEtaState();
}

class _TargetEtaState extends State<_TargetEta> {
  RouteResult? _r;
  String _key = '';

  String get _k {
    final f = widget.from;
    if (f == null) return '';
    return '${f.latitude.toStringAsFixed(3)},${f.longitude.toStringAsFixed(3)}>'
        '${widget.to.latitude.toStringAsFixed(3)},${widget.to.longitude.toStringAsFixed(3)}';
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(_TargetEta old) {
    super.didUpdateWidget(old);
    if (_k != _key) _load();
  }

  Future<void> _load() async {
    final f = widget.from;
    _key = _k;
    if (f == null) {
      if (mounted) setState(() => _r = null);
      return;
    }
    final key = _key;
    final r = await RouteService.fetch(f, widget.to);
    if (mounted && key == _key) setState(() => _r = r);
  }

  @override
  Widget build(BuildContext context) {
    final r = _r;
    if (r == null) return const SizedBox.shrink();
    final mins = (r.durationS / 60).round();
    final label = r.isStraightFallback
        ? fmtDist(r.distanceM)
        : trf('drv_min', {'p1': '${mins < 1 ? 1 : mins}', 'p2': fmtDist(r.distanceM)});
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: Brand.deepGreen,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Brand.gold, width: 0.8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.schedule, size: 13, color: Brand.goldLight),
          const SizedBox(width: 4),
          Text(label,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

/// v1.4.36: Pool card ki DROP line ke liye safar (pickup → drop)
/// ke andazan minutes ki chip — wohi RouteService (OSRM + cache)
/// wala rasta jo [_TargetEta] istemal karta hai. Farq sirf ye
/// hai: seedhi-line wale fallback par chip NAHI banti (seedhi
/// line se bane minutes jaali hote), aur asal route na mile to
/// bhi khamoshi — card par pehle se darj doori hi kaafi hai।
class _TripEta extends StatefulWidget {
  final ll2.LatLng from;
  final ll2.LatLng to;
  const _TripEta({required this.from, required this.to});

  @override
  State<_TripEta> createState() => _TripEtaState();
}

class _TripEtaState extends State<_TripEta> {
  RouteResult? _r;
  String _key = '';

  String get _k =>
      '${widget.from.latitude.toStringAsFixed(3)},${widget.from.longitude.toStringAsFixed(3)}>'
      '${widget.to.latitude.toStringAsFixed(3)},${widget.to.longitude.toStringAsFixed(3)}';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(_TripEta old) {
    super.didUpdateWidget(old);
    if (_k != _key) _load();
  }

  Future<void> _load() async {
    _key = _k;
    final key = _key;
    final r = await RouteService.fetch(widget.from, widget.to);
    if (mounted && key == _key) setState(() => _r = r);
  }

  @override
  Widget build(BuildContext context) {
    final r = _r;
    if (r == null || r.isStraightFallback) {
      return const SizedBox.shrink();
    }
    final mins = (r.durationS / 60).round();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: Brand.deepGreen,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Brand.gold, width: 0.8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.schedule, size: 13, color: Brand.goldLight),
          const SizedBox(width: 4),
          Text(
              trf('drv_min', {
                'p1': '${mins < 1 ? 1 : mins}',
                'p2': fmtDist(r.distanceM)
              }),
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

/// Live waiting display for an arrived ride: minutes ticking + current charge.
/// RIDE START CODE wala khana (v1.4.7, spec §3; code v1.4.44
/// se wapas 4-digit — darmiyan mein 6-digit raha) — 'arrived'
/// haalat mein active card par: driver sawari se code pooch
/// kar daalta hai; sahi code par ride asal mein SHURU। Ghalat
/// code par koshish darj; 3 par Master ko khabar
/// (store.verifyAndStartRide)। Purani booking (code bana hi
/// nahi — v1.4.7 se pehle ki) par seedha "Ride Shuru Karein";
/// jis booking ka code jitne digit ka bana tha, woh booking
/// apne usi code se shuru hoti hai।
class _StartCodeBox extends StatefulWidget {
  final Booking booking;
  final AppStore store;
  final VoidCallback onStarted;
  const _StartCodeBox({
    required this.booking,
    required this.store,
    required this.onStarted,
  });

  @override
  State<_StartCodeBox> createState() => _StartCodeBoxState();
}

class _StartCodeBoxState extends State<_StartCodeBox> {
  final _ctrl = TextEditingController();
  bool _busy = false;
  String? _error;

  Booking get b => widget.booking;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    final code = int.tryParse(_ctrl.text.trim()) ?? -1;
    // v1.4.44: code ab WAPAS 4-digit hai (owner ka hukm
    // 2026-11-13) — nayi bookings 4-digit banti hain। Darmiyan
    // wali (v1.4.14–v1.4.43) 6-digit bookings apne purane code
    // se hi shuru hongi — is liye expected lambai booking ke
    // APNE code ki digits se li jati hai, kisi fixed number
    // se nahi (sawari ki app mein us ka code waisa hi dikhta
    // hai jaisa bana tha)।
    final expected = b.startCode.toString().length;
    if (b.startCode > 0 && _ctrl.text.trim().length != expected) {
      setState(() => _error = expected <= 4
          ? tr('drv_sawari_wala_4_digit')
          : tr('drv_sawari_wala_6_digit'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final ok = await widget.store.verifyAndStartRide(b, code);
    if (!mounted) return;
    setState(() => _busy = false);
    if (ok) {
      widget.onStarted();
    } else {
      setState(() => _error = b.startCodeAttempts >= 3
          ? tr('drv_ghalat_code_3_koshishen')
          : trf('drv_ghalat_code_dobara_koshish', {'startCodeAttempts': '${b.startCodeAttempts}'}));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (b.startCode <= 0) {
      // Purani booking — code bana hi nahi tha; seedha shuru।
      // v1.4.29: Start bhi SLIDE se (galti se tap na ho)।
      return SlideConfirm(
        label: tr('start_legacy_slide'),
        handleIcon: Icons.play_arrow,
        busy: _busy,
        onConfirm: _submit,
      );
    }
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF6E0),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Brand.gold, width: 1.2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.pin, size: 18, color: Color(0xFFB8860B)),
              const SizedBox(width: 6),
              Expanded(
                child: Text(tr('drv_ride_shuru_karne_ke'),
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, color: Brand.ink)),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            tr('drv_sawari_ki_app_par'),
            style: const TextStyle(fontSize: 12.5, color: Brand.ink),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _ctrl,
            keyboardType: TextInputType.number,
            // maxLength 6 hi rakha hai taake darmiyan wali
            // 6-digit bookings ke code bhi darj ho saken;
            // nayi bookings ke code 4-digit hain (v1.4.44)।
            maxLength: 6,
            textAlign: TextAlign.center,
            style: const TextStyle(
                fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 6),
            decoration: const InputDecoration(
              hintText: '••••',
              counterText: '',
              isDense: true,
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          // v1.4.29: Start Trip bhi SLIDE se — code likh kar
          // slide karein; ghalat code par khana khud error dikha
          // dega aur slide wapas aa jayega।
          SlideConfirm(
            label: tr('start_slide'),
            handleIcon: Icons.play_arrow,
            busy: _busy,
            onConfirm: _submit,
          ),
          if (_error != null) ...[
            const SizedBox(height: 6),
            Text(_error!,
                style: const TextStyle(
                    color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
    );
  }
}

/// v1.4.77 GUIDE S9: ride request ka ACCEPT TIMER — booking
/// banne ke 10 minute ke andar qubool karna hota hai (us ke
/// baad booking khud khatam ho jati hai — store ka expiry
/// usool); ye ghari baqi waqt har second gin kar dikhati hai।
class _AcceptTimer extends StatefulWidget {
  final Booking booking;
  const _AcceptTimer({required this.booking});

  @override
  State<_AcceptTimer> createState() => _AcceptTimerState();
}

class _AcceptTimerState extends State<_AcceptTimer> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final deadline =
        widget.booking.createdAt.add(const Duration(minutes: 10));
    final left = deadline.difference(DateTime.now());
    final over = left.isNegative;
    final mm = over ? 0 : left.inMinutes;
    final ss = over ? 0 : left.inSeconds % 60;
    final text = over
        ? tr('guide_accept_timer_over')
        : trf('guide_accept_timer', {
            'time':
                '${mm.toString().padLeft(2, '0')}:${ss.toString().padLeft(2, '0')}'
          });
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: over ? const Color(0xFFFBEAEA) : const Color(0xFFFFF6E0),
        borderRadius: BorderRadius.circular(9),
        border:
            Border.all(color: over ? Brand.ajrakRed : Brand.gold),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.timer,
              size: 16, color: over ? Brand.ajrakRed : Brand.greenDark),
          const SizedBox(width: 6),
          Text(text,
              style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w900,
                  color: over ? Brand.ajrakRed : Brand.ink)),
        ],
      ),
    );
  }
}

class _LiveWaiting extends StatefulWidget {
  final Booking booking;
  final AppStore store;
  const _LiveWaiting({required this.booking, required this.store});

  @override
  State<_LiveWaiting> createState() => _LiveWaitingState();
}

class _LiveWaitingState extends State<_LiveWaiting> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final mins = widget.store.liveWaitingMinutes(b);
    final charge = widget.store.liveWaitingCharge(b);
    final freeLeft = Fares.freeWaitingMinutes - mins;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Brand.cream,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Brand.gold),
      ),
      child: Row(
        children: [
          const Icon(Icons.timer, color: Brand.ajrakRed),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(trf('drv_intezaar_minute', {'mins': '$mins'}),
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 15,
                        color: Brand.ink)),
                Text(
                  freeLeft > 0
                      ? trf('drv_abhi_minute_muft_baqi', {'freeLeft': '$freeLeft'})
                      : trf('drv_waiting_charges_ab_tak', {'p1': rs(charge)}),
                  style: const TextStyle(fontSize: 12, color: Brand.ink),
                ),
              ],
            ),
          ),
          if (charge > 0)
            Text(rs(charge),
                style: const TextStyle(
                    fontWeight: FontWeight.w900, fontSize: 17,
                    color: Brand.ink)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Password dialogs (v1.2.5) — set / unlock / change.
// Teeno mein wohi usool: asal password sirf fingerprint banta hai;
// uniqueness backend se check hoti hai; check na ho sake (offline)
// to aage NAHI barhte.
// ---------------------------------------------------------------------------

/// Pehli dafa password SET karna (duty-on par, jab pwdFp khaali ho).
/// EMAIL SETUP (v1.4.7) — purana (legacy) driver apni Gmail
/// darj karke OTP verify karta hai; kamyabi par email profile +
/// backend (drivers.email) dono jagah darj ho jati hai।
class _EmailSetupPage extends StatefulWidget {
  final AppStore store;
  const _EmailSetupPage({required this.store});

  @override
  State<_EmailSetupPage> createState() => _EmailSetupPageState();
}

class _EmailSetupPageState extends State<_EmailSetupPage> {
  late final _emailCtrl =
      TextEditingController(text: widget.store.profile.email);

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('drv_gmail_darj_karein'))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            tr('drv_aap_ki_driver_id_2'),
            style: const TextStyle(fontSize: 14, height: 1.5),
          ),
          const SizedBox(height: 16),
          EmailOtpSection(
            emailCtrl: _emailCtrl,
            onVerified: (email) async {
              final nav = Navigator.of(context);
              await widget.store.applyDriverEmailVerified(email);
              unawaited(Backend.pushDriverEmail(
                widget.store.driverId,
                email,
                DateTime.fromMillisecondsSinceEpoch(
                    widget.store.profile.emailVerifiedAtMs),
              ));
              // v1.4.14: email verify = Auth session ban gaya —
              // driver pehchan usi se bandh do (link_driver)।
              unawaited(Backend.linkIdentities(widget.store));
              if (mounted) nav.pop(true);
            },
          ),
        ],
      ),
    );
  }
}

class _SetPasswordDialog extends StatefulWidget {
  final AppStore store;
  const _SetPasswordDialog({required this.store});

  @override
  State<_SetPasswordDialog> createState() => _SetPasswordDialogState();
}

class _SetPasswordDialogState extends State<_SetPasswordDialog> {
  final _c1 = TextEditingController();
  final _c2 = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _c1.dispose();
    _c2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final pw = _c1.text;
    if (pw.length < 6) {
      setState(() => _error = tr('reg_err_pw_min'));
      return;
    }
    if (pw != _c2.text) {
      setState(() => _error = tr('reg_err_pw_match'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final fp = passwordFingerprint(pw);
    final taken =
        await Backend.passwordFingerprintTaken(widget.store, fp);
    if (!mounted) return;
    if (taken == null) {
      setState(() {
        _busy = false;
        _error =
            tr('reg_err_pw_net');
      });
      return;
    }
    if (taken) {
      _c1.clear();
      _c2.clear();
      setState(() {
        _busy = false;
        _error =
            tr('reg_err_pw_taken');
      });
      return;
    }
    final p = widget.store.profile;
    p.pwdFp = fp;
    p.pwdFailCount = 0;
    p.pwdLockUntilMs = 0;
    await widget.store.save();
    widget.store.dutyUnlocked = true;
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(tr('drv_apna_password_lagayein')),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
              tr('drv_duty_shuru_karne_se_2')),
          const SizedBox(height: 8),
          // HOTFIX v1.2.9 (RC3): qadam ki tartib pehle se saaf —
          // password pura hue baghair selfie wala qadam nahi ata,
          // aur driver samajhta tha selfie "khulti hi nahi".
          Text(
            tr('drv_pehle_apna_password_lagayein'),
            style: TextStyle(
                fontWeight: FontWeight.w700,
                color: Theme.of(context).colorScheme.primary),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _c1,
            obscureText: true,
            enabled: !_busy,
            decoration: InputDecoration(
                labelText: tr('reg_pw_label')),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _c2,
            obscureText: true,
            enabled: !_busy,
            decoration:
                InputDecoration(labelText: tr('reg_pw2_label')),
          ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!,
                style: const TextStyle(
                    color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(false),
          child: Text(tr('veh_dialog_cancel')),
        ),
        ElevatedButton(
          onPressed: _busy ? null : _submit,
          child: Text(_busy ? tr('reg_checking') : tr('drv_password_lagayein')),
        ),
      ],
    );
  }
}

/// Duty unlock: set shuda password likhna. 5 ghalat = 10 minute lockout.
class _AskPasswordDialog extends StatefulWidget {
  final AppStore store;
  const _AskPasswordDialog({required this.store});

  @override
  State<_AskPasswordDialog> createState() => _AskPasswordDialogState();
}

class _AskPasswordDialogState extends State<_AskPasswordDialog> {
  final _c = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final p = widget.store.profile;
    if (passwordFingerprint(_c.text) == p.pwdFp) {
      p.pwdFailCount = 0;
      await widget.store.save();
      widget.store.dutyUnlocked = true;
      if (mounted) Navigator.of(context).pop(true);
      return;
    }
    p.pwdFailCount += 1;
    if (p.pwdFailCount >= 5) {
      // Lockout: ginati zero karke 10 minute ka taala — waqt khatm
      // hone par 5 nayi koshishen milengi.
      p.pwdFailCount = 0;
      p.pwdLockUntilMs =
          DateTime.now().millisecondsSinceEpoch + 10 * 60 * 1000;
      await widget.store.save();
      if (mounted) Navigator.of(context).pop(false);
      return;
    }
    await widget.store.save();
    if (!mounted) return;
    _c.clear();
    setState(() => _error =
        trf('drv_ghalat_password_koshishen_baqi', {'p1': '${5 - p.pwdFailCount}'}));
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(tr('drv_password_likhein')),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(tr('drv_duty_shuru_karne_ke')),
          const SizedBox(height: 12),
          TextField(
            controller: _c,
            obscureText: true,
            autofocus: true,
            decoration: const InputDecoration(labelText: 'Password'),
            onSubmitted: (_) => _submit(),
          ),
          // FINAL-PACK C-PD: bhool jane par asal rasta — Master
          // aarzi password laga kar must_change_password on kar
          // deta hai, phir upar wala lazmi-change flow chalta hai.
          const SizedBox(height: 10),
          Text(
            tr('drv_password_bhool_gaye_master'),
            style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
                color: Theme.of(context).colorScheme.primary),
          ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!,
                style: const TextStyle(
                    color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: Text(tr('veh_dialog_cancel')),
        ),
        ElevatedButton(
          onPressed: _submit,
          child: Text(tr('drv_duty_shuru_karein')),
        ),
      ],
    );
  }
}

/// FINAL-PACK C-PD — LAZMI password change: Master ke diye hue
/// AARZI password se unlock hone ke baad driver apna naya password
/// lagata hai. Usool wohi jo set/change dialogs ke hain:
/// fingerprint + backend uniqueness check (passwordFingerprintTaken)
/// — check na ho sake (offline) to aage NAHI barhte; takraav par
/// wohi pakka jumla. Is dialog mein "Rehne Dein" NAHI hai aur
/// barrierDismissible:false ke saath ye flow bypass NAHI ho sakta:
/// sirf kamyab change hi true lautata hai. Kamyabi par naya pwd_fp
/// + must_change_password=false backend par push hota hai
/// (Backend.pushDriverPasswordReset — column na ho to sirf pwd_fp
/// wala rasta chal jata hai) aur local flag saaf ho jata hai.
class _MustChangePasswordDialog extends StatefulWidget {
  final AppStore store;
  const _MustChangePasswordDialog({required this.store});

  @override
  State<_MustChangePasswordDialog> createState() =>
      _MustChangePasswordDialogState();
}

class _MustChangePasswordDialogState
    extends State<_MustChangePasswordDialog> {
  final _n1 = TextEditingController();
  final _n2 = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _n1.dispose();
    _n2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final p = widget.store.profile;
    final pw = _n1.text;
    if (pw.length < 6) {
      setState(() => _error = tr('drv_naya_password_kam_az'));
      return;
    }
    if (pw != _n2.text) {
      setState(() => _error = tr('reg_err_pw_match'));
      return;
    }
    final fp = passwordFingerprint(pw);
    if (fp == p.pwdFp) {
      setState(() => _error =
          tr('drv_ye_aarzi_password_hi'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final taken =
        await Backend.passwordFingerprintTaken(widget.store, fp);
    if (!mounted) return;
    if (taken == null) {
      setState(() {
        _busy = false;
        _error =
            tr('reg_err_pw_net');
      });
      return;
    }
    if (taken) {
      _n1.clear();
      _n2.clear();
      setState(() {
        _busy = false;
        _error =
            tr('reg_err_pw_taken');
      });
      return;
    }
    p.pwdFp = fp;
    p.mustChangePassword = false;
    p.pwdFailCount = 0;
    p.pwdLockUntilMs = 0;
    await widget.store.save();
    widget.store.dutyUnlocked = true;
    // Backend par naya fingerprint + must_change_password=false
    // (best-effort — column na ho to pushDriverPasswordReset khud
    // sirf pwd_fp wale raste par gir jata hai; local flag upar
    // saaf ho chuka hai).
    unawaited(Backend.pushDriverPasswordReset(widget.store));
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(tr('drv_naya_password_lagayein')),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
                tr('drv_master_ne_aap_ko')),
            const SizedBox(height: 12),
            TextField(
              controller: _n1,
              obscureText: true,
              enabled: !_busy,
              decoration: InputDecoration(
                  labelText: tr('drv_naya_password_kam_az_2')),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _n2,
              obscureText: true,
              enabled: !_busy,
              decoration: InputDecoration(
                  labelText: tr('drv_naya_password_dobara_likhein')),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!,
                  style: const TextStyle(
                      color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
            ],
          ],
        ),
      ),
      actions: [
        ElevatedButton(
          onPressed: _busy ? null : _submit,
          child: Text(_busy ? tr('reg_checking') : tr('drv_password_lagayein')),
        ),
      ],
    );
  }
}

/// Password badalna: pehle mojooda password ki tasdeeq, phir naya —
/// naye par wohi uniqueness check.
class _ChangePasswordDialog extends StatefulWidget {
  final AppStore store;
  const _ChangePasswordDialog({required this.store});

  @override
  State<_ChangePasswordDialog> createState() =>
      _ChangePasswordDialogState();
}

class _ChangePasswordDialogState extends State<_ChangePasswordDialog> {
  final _cur = TextEditingController();
  final _n1 = TextEditingController();
  final _n2 = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _cur.dispose();
    _n1.dispose();
    _n2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final p = widget.store.profile;
    if (passwordFingerprint(_cur.text) != p.pwdFp) {
      setState(() => _error = tr('drv_mojooda_password_ghalat_hai'));
      return;
    }
    final pw = _n1.text;
    if (pw.length < 6) {
      setState(() => _error = tr('drv_naya_password_kam_az'));
      return;
    }
    if (pw != _n2.text) {
      setState(() => _error = tr('drv_dono_naye_password_ek'));
      return;
    }
    final fp = passwordFingerprint(pw);
    if (fp == p.pwdFp) {
      setState(() =>
          _error = tr('drv_ye_aap_ka_mojooda'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final taken =
        await Backend.passwordFingerprintTaken(widget.store, fp);
    if (!mounted) return;
    if (taken == null) {
      setState(() {
        _busy = false;
        _error =
            tr('reg_err_pw_net');
      });
      return;
    }
    if (taken) {
      _n1.clear();
      _n2.clear();
      setState(() {
        _busy = false;
        _error =
            tr('reg_err_pw_taken');
      });
      return;
    }
    p.pwdFp = fp;
    p.pwdFailCount = 0;
    p.pwdLockUntilMs = 0;
    await widget.store.save();
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(tr('drv_password_badlein')),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _cur,
              obscureText: true,
              enabled: !_busy,
              decoration:
                  InputDecoration(labelText: tr('drv_mojooda_password')),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _n1,
              obscureText: true,
              enabled: !_busy,
              decoration: InputDecoration(
                  labelText: tr('drv_naya_password_kam_az_2')),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _n2,
              obscureText: true,
              enabled: !_busy,
              decoration: InputDecoration(
                  labelText: tr('drv_naya_password_dobara_likhein')),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!,
                  style: const TextStyle(
                      color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(false),
          child: Text(tr('veh_dialog_cancel')),
        ),
        ElevatedButton(
          onPressed: _busy ? null : _submit,
          child: Text(_busy ? tr('reg_checking') : tr('drv_password_badlein')),
        ),
      ],
    );
  }
}


// ---------------------------------------------------------------------------
// MONTHLY PACKAGES — DRIVER (v1.4.25, postmortem #9)
// ---------------------------------------------------------------------------

/// Driver ke Monthly Packages ka safha: (1) mujhe ASSIGN shuda
/// packages, (2) KHULE naye packages jin par "Qubool Karein" se
/// package driver ke naam pakka ho jata hai — package ki fee
/// row par pehle se bandhi hai, assign hote hi wohi fee isi
/// driver ki ho jati hai (Master ka Fees Register wohi parhta
/// hai)। Data backend se ata hai; jawab na mile to saaf khaali
/// haalat dikhti hai — jhooti list kabhi NAHI।
class _MonthlyPackagesPage extends StatefulWidget {
  final AppStore store;
  const _MonthlyPackagesPage({required this.store});

  @override
  State<_MonthlyPackagesPage> createState() => _MonthlyPackagesPageState();
}

class _MonthlyPackagesPageState extends State<_MonthlyPackagesPage> {
  bool _loading = true;
  bool _claiming = false;
  List<Map<String, dynamic>> _mine = [];
  List<Map<String, dynamic>> _open = [];

  AppStore get store => widget.store;

  @override
  void initState() {
    super.initState();
    unawaited(_load());
  }

  Future<void> _load() async {
    final mine = await Backend.fetchMyPackages(store);
    final open = await Backend.fetchOpenPackages();
    if (!mounted) return;
    setState(() {
      _mine = mine;
      _open = open;
      _loading = false;
    });
  }

  String _line(Map<String, dynamic> r) {
    final km = (r['km'] as num?)?.toDouble() ?? 0;
    final days = (r['days'] as num?)?.toInt() ?? 0;
    final amount = (r['amount'] as num?)?.toInt() ?? 0;
    return trf('drv_km_rozana_din_kul', {'p1': r['vehicle'] ?? '', 'p2': km.toStringAsFixed(1), 'days': '$days', 'p3': rs(amount)});
  }

  Future<void> _claim(Map<String, dynamic> r) async {
    if (_claiming) return;
    final id = r['id']?.toString() ?? '';
    if (id.isEmpty) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('drv_package_qubool_karein')),
        content: Text(
            trf('drv_qubool_karne_par_ye', {'p1': r['pickup'] ?? '', 'p2': r['drop_off'] ?? '', 'p3': _line(r)})),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('veh_dialog_cancel')),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('drv_qubool_karein')),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _claiming = true);
    final done = await Backend.claimPackage(store, id);
    if (!mounted) return;
    setState(() => _claiming = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(done
          ? tr('drv_package_aap_ke_naam')
          : tr('drv_package_qubool_nahi_ho')),
    ));
    if (done) await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('drv_monthly_packages')),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: tr('drv_dobara_load_karein'),
            onPressed: _loading ? null : _load,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(14),
              children: [
                Text(tr('drv_mere_packages'),
                    style:
                        const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                if (_mine.isEmpty)
                  Text(tr('drv_abhi_aap_ko_koi'),
                      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                ..._mine.map((r) => Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: ListTile(
                        leading: const Icon(Icons.calendar_month,
                            color: Brand.green),
                        title: Text('${r['pickup'] ?? ''} → ${r['drop_off'] ?? ''}',
                            style:
                                const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text(
                            '${r['customer_name'] ?? ''}\n${_line(r)}'),
                        isThreeLine: true,
                        trailing: r['paid'] == true
                            ? const Chip(
                                label: Text('Paid'),
                                visualDensity: VisualDensity.compact)
                            : null,
                      ),
                    )),
                const SizedBox(height: 18),
                Text(tr('drv_naye_khule_packages'),
                    style:
                        const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                if (_open.isEmpty)
                  Text(
                      tr('drv_abhi_koi_naya_khula'),
                      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                ..._open.map((r) => Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          ListTile(
                            leading: const Icon(Icons.calendar_month_outlined,
                                color: Brand.green),
                            title: Text(
                                '${r['pickup'] ?? ''} → ${r['drop_off'] ?? ''}',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w700)),
                            subtitle: Text(_line(r)),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
                            child: ElevatedButton(
                              onPressed: _claiming ? null : () => _claim(r),
                              child: Text(tr('drv_qubool_karein')),
                            ),
                          ),
                        ],
                      ),
                    )),
              ],
            ),
    );
  }
}
// =====================================================================
// v1.4.37 — DEPOSIT JAMA KARWAYEIN sheet (malik ka hukm 2026-11-12;
// 15:43 par NAZIL SHUDA TABDEELI: number ki jagah BANK ACCOUNT)
// =====================================================================
/// Driver ko Amanat Deposit ke saaf steps (bank transfer) aur
/// Master ko khabar bhejne ka EK button. SAKHT usool:
///  - Paisa is app ke andar se NAHI jata — transfer driver apni
///    Easypaisa, JazzCash ya bank app se karta hai; sheet ki
///    likhai yehi wazeh karti hai।
///  - MOBILE NUMBER yahan NAHI lagta (hukm 15:43): deposit sirf
///    company ke BankIslami account mein IBAN se jata hai. IBAN +
///    account title ki value CODE MEIN NAHI hai — hamesha
///    settings sync ([Fares.companyBankIban] /
///    [Fares.companyBankTitle]) se ati hai।
///  - IBAN mayassar na ho (offline pehli dafa / settings na ayi
///    ho) to sheet mein saaf "tafseel load nahi hui" wali line
///    ati hai — koi jaali number/IBAN ya dosra rasta NAHI dikhta,
///    aur us surat mein steps + khabar wala button bhi NAHI ate
///    (aadha amal NAHI)।
///  - QR code: sirf malik ki di hui asal image
///    (assets/deposit_qr.png) — asset maujood ho to dikhta hai,
///    na ho to QR wala hissa khamoshi se ghayab rehta hai. Koi QR
///    payload/format app khud NAHI banati (ghalat QR se paisa
///    ghalat jagah ja sakta hai)।
///  - Driver ka APNA Easypaisa/JazzCash number kahin NAHI manga,
///    NAHI likha, NAHI bheja jata (RAD lock)।
///  - Jama ki entry SIRF Master karega (wasooli ki tasdeeq ke
///    baad) — is sheet se balance mein koi auto-credit NAHI hota।
///  - Khabar bhejne ke baad button isi sheet par dobara NAHI
///    dabta (duplicate khabar NAHI jati); asal pohanch ka saboot
///    message ka `sent` flag hai — offline ho to queued wali
///    imaandar line dikhti hai, jaali success NAHI।
class _DepositSheet extends StatefulWidget {
  final AppStore store;
  const _DepositSheet({required this.store});

  @override
  State<_DepositSheet> createState() => _DepositSheetState();
}

class _DepositSheetState extends State<_DepositSheet> {
  AppStore get store => widget.store;

  /// idle | sending | sent | queued | failed
  String _phase = 'idle';

  /// SABOOT (v1.4.38): driver ki chuni hui payment-receipt photo
  /// ki LOCAL file — khaali = koi photo nahi lagi. Khabar bhejte
  /// waqt ye photo usi MasterMessage ke saath jati hai
  /// (photoLocalPath → upload par photoPath; mojooda support-photo
  /// wala rasta, bucket 'driver-docs')। Photo LAZMI nahi hai —
  /// baghair photo ke bhi khabar jati hai।
  String _proofLocalPath = '';
  final ImagePicker _proofPicker = ImagePicker();

  Future<void> _pickProof() async {
    try {
      final img = await _proofPicker.pickImage(
          source: ImageSource.gallery, imageQuality: 85);
      if (img == null || !mounted) return;
      setState(() => _proofLocalPath = img.path);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(tr('pick_photo_failed'))),
      );
    }
  }

  /// QR asset (assets/deposit_qr.png) asal mein bundle mein hai
  /// ya nahi — initState mein rootBundle se jaanch; na ho to QR
  /// wala hissa ghayab rehta hai (koi khaali khana NAHI)।
  bool _hasQr = false;

  @override
  void initState() {
    super.initState();
    _checkQr();
  }

  Future<void> _checkQr() async {
    try {
      await rootBundle.load('assets/deposit_qr.png');
      if (mounted) setState(() => _hasQr = true);
    } catch (_) {
      // Asset nahi hai — QR section ghayab hi rahega।
    }
  }

  Future<void> _informMaster() async {
    if (_phase == 'sending' || _phase == 'sent' || _phase == 'queued') {
      return;
    }
    setState(() => _phase = 'sending');
    final now = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    final time =
        '${two(now.day)}/${two(now.month)}/${now.year} ${two(now.hour)}:${two(now.minute)}';
    final m = MasterMessage(
      id: store.newId(),
      senderKey: store.driverId,
      senderRole: 'driver',
      senderName: store.profile.name,
      senderMobile: store.profile.phone,
      senderZone: store.profile.zone,
      category: kMessageCategories[1], // 'Payment ya Wallet'
      body: trf('drv_dep_msg_body', {
        'name': store.profile.name,
        'amount': '${Fares.joiningDeposit}',
        'iban': Fares.companyBankIban,
        'time': time,
      }),
      createdAt: now,
    );
    // SABOOT (v1.4.38): photo lagi ho to usi message ke saath —
    // pehle mojooda support-photo upload (driver-docs bucket),
    // kamyabi par photoPath bhar jata hai aur _pushMessage usay
    // messages.photo_path mein darj kar deta hai. Upload na ho
    // paye (offline) to bhi khabar rukti NAHI: photoLocalPath
    // message ke saath mehfooz rehti hai aur _pushMessage agli
    // koshish par photo khud upload kar deta hai।
    if (_proofLocalPath.isNotEmpty) {
      m.photoLocalPath = _proofLocalPath;
      final remote =
          await Backend.uploadSupportPhoto(store, _proofLocalPath);
      if (remote != null) m.photoPath = remote;
    }
    try {
      // Store mein daalte hi 'message' hook backend push shuru kar
      // deta hai; offline ho to message phone mein queued rehta hai
      // aur internet ate hi khud chala jata hai (syncMessages)।
      await store.addMasterMessage(m);
    } catch (_) {
      if (mounted) setState(() => _phase = 'failed');
      return;
    }
    // Asal pohanch ka saboot: push kamyab ho to isi object ka sent
    // flag true ho jata hai। ~6 second tak dekho — na ho to message
    // queued hai, wohi imaandar haalat dikhao (jaali success NAHI)।
    for (var i = 0; i < 12 && !m.sent; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 500));
    }
    if (!mounted) return;
    setState(() => _phase = m.sent ? 'sent' : 'queued');
  }

  Widget _statusBox(Color bg, Color border, IconData icon, String text) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: border, width: 1.5),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: Brand.greenDark, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Text(text,
                style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w700,
                    height: 1.45,
                    color: Brand.ink)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final iban = Fares.companyBankIban.trim();
    final hasIban = iban.isNotEmpty;
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.payments, color: Brand.green, size: 26),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(tr('drv_dep_title'),
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w900)),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            Text(tr('drv_dep_intro'),
                style: const TextStyle(fontSize: 13.5, height: 1.45)),
            if (!hasIban) ...[
              // Tafseel (IBAN) hi nahi ayi — aadha amal NAHI:
              // steps/button ki jagah sirf saaf wazahat।
              const SizedBox(height: 16),
              _statusBox(const Color(0xFFFFF6E0), Brand.gold,
                  Icons.cloud_off, tr('drv_dep_iban_missing')),
            ] else ...[
              if (_hasQr) ...[
                const SizedBox(height: 16),
                // QR — sirf malik ki asal image (asset)। Safed
                // card mein taake har screen par saaf scan ho।
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Brand.gold, width: 1.5),
                  ),
                  child: Column(
                    children: [
                      Text(tr('drv_dep_qr_title'),
                          style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              color: Brand.ink)),
                      const SizedBox(height: 10),
                      Image.asset('assets/deposit_qr.png',
                          height: 220, fit: BoxFit.contain),
                      const SizedBox(height: 10),
                      Text(tr('drv_dep_qr_note'),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 12.5,
                              color: Brand.onLightSub,
                              height: 1.4)),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 16),
              Text(tr('drv_dep_step1'),
                  style: const TextStyle(
                      fontSize: 14.5, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text(tr('drv_dep_step2'),
                  style: const TextStyle(
                      fontSize: 14.5, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              // MALIK KA HUKM (2026-11-22): is safhe par sirf QR
              // code nazar aayega — IBAN number aur account title
              // (malik ka zaati naam/number) NAHI dikhana। Bhejne
              // wale ki pehchan neeche wali Master-khabar aur
              // saboot (screenshot) se ho jati hai।
              Text(
                  trf('drv_dep_step3',
                      {'joiningDeposit': '${Fares.joiningDeposit}'}),
                  style: const TextStyle(
                      fontSize: 14.5, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              Text(tr('drv_dep_after'),
                  style: const TextStyle(fontSize: 13.5, height: 1.45)),
              const SizedBox(height: 6),
              Text(tr('drv_dep_own_number_note'),
                  style: TextStyle(
                      fontSize: 12.5, color: Theme.of(context).colorScheme.onSurfaceVariant, height: 1.4)),
              const SizedBox(height: 16),
              if (_phase == 'sent')
                _statusBox(const Color(0xFFE8F5E9), Brand.green,
                    Icons.check_circle, tr('drv_dep_sent_ok'))
              else if (_phase == 'queued')
                _statusBox(const Color(0xFFFFF6E0), Brand.gold,
                    Icons.schedule, tr('drv_dep_queued'))
              else ...[
                // SABOOT (v1.4.38): receipt ki photo lagane ka
                // ikhtiyar — LAZMI nahi, lekin tasdeeq asaan
                // ho jati hai. Lagi ho to preview + hatane ka
                // button; na ho to chunne ka button।
                if (_proofLocalPath.isEmpty) ...[
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _phase == 'sending' ? null : _pickProof,
                      icon: const Icon(Icons.image_outlined, size: 20),
                      label: Text(tr('drv_dep_proof_btn'),
                          style: const TextStyle(
                              fontSize: 14.5, fontWeight: FontWeight.w800)),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Brand.greenDark,
                        side: const BorderSide(
                            color: Brand.green, width: 1.5),
                        padding:
                            const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                ] else ...[
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE8F5E9),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Brand.green, width: 1.5),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.check_circle,
                                color: Brand.greenDark, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(tr('drv_dep_proof_attached'),
                                  style: const TextStyle(
                                      fontSize: 13.5,
                                      fontWeight: FontWeight.w800,
                                      color: Brand.ink)),
                            ),
                            IconButton(
                              icon: const Icon(Icons.close, size: 20),
                              tooltip: tr('drv_dep_proof_remove'),
                              visualDensity: VisualDensity.compact,
                              onPressed: _phase == 'sending'
                                  ? null
                                  : () => setState(
                                      () => _proofLocalPath = ''),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.file(
                            File(_proofLocalPath),
                            width: double.infinity,
                            height: 150,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                const SizedBox.shrink(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 6),
                Text(tr('drv_dep_proof_note'),
                    style: TextStyle(
                        fontSize: 12.5,
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                        height: 1.4)),
                const SizedBox(height: 14),
                if (_phase == 'failed') ...[
                  Text(tr('drv_dep_failed'),
                      style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Brand.ajrakRed)),
                  const SizedBox(height: 10),
                ],
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _phase == 'sending' ? null : _informMaster,
                    icon: _phase == 'sending'
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child:
                                CircularProgressIndicator(strokeWidth: 2.5),
                          )
                        : const Icon(Icons.send, size: 20),
                    label: Text(
                      _phase == 'sending'
                          ? tr('drv_dep_sending')
                          : tr('drv_dep_send_btn'),
                      style: const TextStyle(
                          fontSize: 15.5, fontWeight: FontWeight.w900),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Brand.green,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ],
        ),
      ),
    );
  }
}
