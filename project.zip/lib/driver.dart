import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart' as ll2;
import 'package:url_launcher/url_launcher.dart';
import 'store.dart';
import 'theme.dart';
import 'safar_map.dart';
import 'backend.dart';
import 'registration.dart';
import 'messages.dart';
import 'notifications.dart';
import 'main.dart' show ModeToggleButton, UpdateBanner;
import 'passenger.dart' show kStatusUrdu;

class DriverSide extends StatefulWidget {
  final AppStore store;
  final VoidCallback onSwitchToPassenger;
  const DriverSide(
      {super.key, required this.store, required this.onSwitchToPassenger});

  @override
  State<DriverSide> createState() => _DriverSideState();
}

class _DriverSideState extends State<DriverSide>
    with NotificationBannerMixin {
  int _tab = 0; // 0 Home | 1 Pool | 2 Bookings | 3 Wallet | 4 Profile
  final ImagePicker _picker = ImagePicker();

  // v1.4.0 two-phone live dispatch: duty ke doran location timer —
  // har ~20 second GPS le kar backend drivers row (lat/lng/loc_at)
  // aur chal rahi ride ke row (driver_lat/lng) ko taaza rakhta hai.
  Timer? _dutyTimer;
  bool _dutyTickBusy = false;

  // v1.4.2: backend Pool feed ka timer — har ~15 second backend se
  // pending rides ki taaza list (ONLINE ho ya OFFLINE, Pool dono
  // haalton mein khulta hai). Isi ke saath offline reh gayi booking
  // pushes (outbox) ki dobara koshish bhi hoti hai.
  Timer? _poolTimer;

  // Driver ki apni mojooda jagah — har ride ki pickup-doori ginne aur
  // 2 km radius filter (kDriverPickupRadiusKm) ke liye. Best-effort hai:
  // ijazat/location na mile to _myPos null rehta hai aur us surat mein
  // filter NAHI lagta (saari rides dikhti hain, doori wali line par
  // "location off hai" likha aata hai) — pilot band nahi hota.
  ll2.LatLng? _myPos;
  bool _locBusy = false;

  /// Registration wizard is app session mein khud khula ya nahi —
  /// dobara dobara khud nahi khulta (Home/Profile par us ka card
  /// button hamesha maujood hai).
  bool _wizardPrompted = false;

  AppStore get store => widget.store;
  DriverProfile get p => store.profile;

  @override
  void dispose() {
    cancelNotificationBanners();
    _dutyTimer?.cancel();
    _poolTimer?.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _refreshMyLocation();
    // v1.4.0: foreground notification banners + elanaat pull +
    // apna rating ausat (Profile ke liye) + duty location timer.
    listenNotificationBanners(store);
    unawaited(Backend.syncFeeSettlements(store));
    unawaited(Backend.refreshAnnouncements(store));
    unawaited(Backend.pullOwnRatingAverage(store));
    unawaited(store.observeBookingStatuses('driver'));
    _dutyTimer = Timer.periodic(
        const Duration(seconds: 20), (_) => unawaited(_dutyTick()));
    // v1.4.2: Pool feed foran + har ~15s — doosre phones ki rides
    // ab asal mein is phone tak pohanchti hain (dispatch fix #1).
    unawaited(Backend.refreshRemotePool(store));
    _poolTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      unawaited(Backend.refreshRemotePool(store));
      unawaited(Backend.syncRideOutbox(store));
    });
    // Registration baqi ho to Driver Mode mein ate hi Yango-style
    // registration form khud khul jata hai (ek dafa, is session mein).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // HOTFIX v1.2.9 (RC2): gate ab registrationComplete par hai —
      // legacy profile (sirf naam+mobile, photos nahi) bhi wizard
      // mein jayega taaki baqi documents jama ho jayen.
      if (mounted && !p.registrationComplete && !_wizardPrompted) {
        _wizardPrompted = true;
        _openRegistration();
      }
    });
  }

  /// Duty location timer ka ek chakkar (v1.4.0): driver ONLINE ho
  /// to GPS le kar —
  ///  1) store.noteDriverLocation drivers row par lat/lng/loc_at
  ///     PATCH karwata hai (halki si, sirf location);
  ///  2) agar koi ride chal rahi hai (accepted/arrived) to us ke
  ///     backend row par driver_lat/driver_lng bhi likhta hai,
  ///     taaki passenger ke phone par ETA taaza rahe.
  /// Offline ho to kuch nahi hota. Har nakami khamosh.
  Future<void> _dutyTick() async {
    if (_dutyTickBusy || !p.online) return;
    final last = store.lastLocationPushAt;
    if (last != null && DateTime.now().difference(last).inSeconds < 15) {
      return;
    }
    _dutyTickBusy = true;
    try {
      double? lat, lng;
      final pos = await Geolocator.getLastKnownPosition();
      if (pos != null) {
        lat = pos.latitude;
        lng = pos.longitude;
      }
      final fresh = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      lat = fresh.latitude;
      lng = fresh.longitude;
      store.noteDriverLocation(lat, lng);
      if (mounted) {
        setState(() => _myPos = ll2.LatLng(lat!, lng!));
      }
      final actives = store.bookings
          .where((b) => b.status == 'accepted' || b.status == 'arrived')
          .toList();
      for (final b in actives) {
        await Backend.pushRideDriverPosition(store, b.id, lat, lng);
      }
    } catch (_) {
      // Khamosh — GPS na mile to agla chakkar dobara koshish karega.
    } finally {
      _dutyTickBusy = false;
    }
  }

  /// Registration wizard (v1.2.6) full-screen kholna — Home aur
  /// Profile dono ke registration card yahin ate hain.
  Future<void> _openRegistration() async {
    await Navigator.of(context).push(
      MaterialPageRoute<bool>(
        builder: (_) => RegistrationWizard(store: store),
      ),
    );
    // Wizard band hone par sirf display taaza karna hai — Profile
    // mein ab koi editing controllers nahi hain (FORM USOOL
    // 2026-11-08: Profile sirf status + button hai), is liye koi
    // controller-sync ki zaroorat nahi.
    if (mounted) setState(() {});
  }

  /// Master ko Message screen (v1.2.7) — Profile se khulti hai.
  Future<void> _openMessages() async {
    await Navigator.of(context).push(
      MaterialPageRoute<bool>(
        builder: (_) => MasterMessagesScreen(store: store, role: 'driver'),
      ),
    );
    if (mounted) setState(() {});
  }

  /// DriverNavView (safar_map.dart) wala hi tareeqa: pehle last known,
  /// phir ek dafa ki taaza position. Koi stream nahi — Bookings tab
  /// khulne par dobara refresh ho jata hai. Har nakami khamosh hai.
  Future<void> _refreshMyLocation() async {
    if (_locBusy) return;
    _locBusy = true;
    try {
      final service = await Geolocator.isLocationServiceEnabled();
      if (!service) return;
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        return;
      }
      final last = await Geolocator.getLastKnownPosition();
      if (last != null && mounted) {
        setState(
            () => _myPos = ll2.LatLng(last.latitude, last.longitude));
        // Store mein bhi darj — passenger ki "driver kitni door hai"
        // wali line aur backend drivers.lat/lng isi se chalte hain.
        store.setDriverPosition(last.latitude, last.longitude);
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      if (mounted) {
        setState(() => _myPos = ll2.LatLng(pos.latitude, pos.longitude));
        store.setDriverPosition(pos.latitude, pos.longitude);
      }
    } catch (_) {
      // Khamosh — position na mile to filter nahi lagta.
    } finally {
      _locBusy = false;
    }
  }

  /// Booking ki pickup tak ki doori (km) driver ki apni jagah se.
  /// null = hisaab nahi ho sakta — ya driver ki position maloom nahi,
  /// ya booking ke paas pickup pin/coords hi nahi (0,0).
  double? _pickupDistanceKm(Booking b) {
    final pos = _myPos;
    if (pos == null) return null;
    if (b.pickupLat == 0 && b.pickupLng == 0) return null;
    return const ll2.Distance().as(ll2.LengthUnit.Kilometer, pos,
        ll2.LatLng(b.pickupLat, b.pickupLng));
  }

  /// 2 km radius filter: doori gin sake aur radius se zyada ho to ride
  /// is driver ko nahi dikhti. Doori na gin sake (location off ya pin
  /// nahi) to ride hamesha dikhti hai — chhupati kabhi nahi.
  bool _inRadius(Booking b) {
    final d = _pickupDistanceKm(b);
    if (d == null) return true;
    return d <= kDriverPickupRadiusKm;
  }

  /// Abhi available (pending) rides — is phone ki local bookings
  /// AUR backend Pool feed ki doosre phones wali rides, dono par
  /// wohi 2 km radius filter. Pool screen, Bookings ki incoming
  /// list aur nav badges teeno yahi ek list istemal karte hain
  /// (v1.4.2 dispatch fix: pehle sirf local list thi, is liye
  /// doosre phone ki ride driver tak pohanchti hi nahi thi).
  List<Booking> get _availableRides => [
        ...store.bookings.where((b) => b.status == 'pending'),
        ...store.remotePool,
      ].where(_inRadius).toList();

  /// "Sawari kitni door hai" wali line — incoming aur active dono
  /// cards par. Location off ho to wohi saaf likha aata hai; pickup
  /// pin na ho to sirf pickup ka label/ilaqa dikhta hai.
  Widget _pickupDistanceLine(Booking b) {
    final String text;
    if (_myPos == null) {
      text = 'Sawari ki doori: location off hai';
    } else {
      final d = _pickupDistanceKm(b);
      text = d == null
          ? 'Sawari: ${b.pickupLabel}'
          : 'Sawari: ${d.toStringAsFixed(1)} km door';
    }
    return Row(
      children: [
        const Icon(Icons.near_me, size: 17, color: Brand.green),
        const SizedBox(width: 6),
        Expanded(
          child: Text(text,
              style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: Brand.greenDark)),
        ),
      ],
    );
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  /// Duty on/off (v1.2.5 — malik ka hukm). Offline karna hamesha
  /// seedha hai. Online (duty) hone se pehle do darwaze hain:
  ///  1) PASSWORD: set na ho to pehle SET karna lazmi hai (backend
  ///     uniqueness check ke saath — ek password sirf ek driver ka);
  ///     set ho to is session mein ek dafa likhna lazmi hai; 5 ghalat
  ///     koshishon par 10 minute ka lockout.
  ///  2) ROZANA LIVE SELFIE: aaj ki selfie na ho to camera wahi
  ///     khulta hai — selfie ke baghair duty shuru nahi hoti.
  /// Dono pass hon tab hi online hota hai.
  Future<void> _toggleOnline() async {
    if (p.online) {
      p.online = false;
      await store.save();
      if (mounted) setState(() {});
      return;
    }
    // ID-ACTIVE GATE sab se pehle (v1.4.1 — Owner Tasdeeq Duty):
    // Master ki tasdeeq ke baghair driver ONLINE hi nahi ho sakta.
    // Khamosh nakami bilkul nahi — wajah wala tay shuda jumla
    // screen par saaf ata hai.
    if (!p.masterActive) {
      _snack('Aap ki ID abhi Master ki tasdeeq mein hai');
      return;
    }
    // NUMBER TABDEELI BLOCK (2026-11-08): number badla ho to
    // 12 ghante online hona band — baqi waqt paighaam mein hai.
    final numBlock = store.numberBlockReason();
    if (numBlock != null) {
      _snack(numBlock);
      return;
    }
    // DEVICE TABDEELI BLOCK (2026-11-08): doosri device par
    // account khula ho to 6 ghante online hona band.
    final devBlock = store.deviceBlockReason();
    if (devBlock != null) {
      _snack(devBlock);
      return;
    }
    // FEE AUTO-BLOCK (2026-11-08): pehle Master ki tasdeeq shuda
    // settlements taaza kar lein (block ghalti se na lage), phir
    // baqi fee had se upar ho to ONLINE hona band — wajah screen
    // par saaf ati hai (raqam + Raast number + tareeqa).
    await Backend.syncFeeSettlements(store);
    if (!mounted) return;
    final feeBlock = store.feeBlockReason();
    if (feeBlock != null) {
      setState(() {});
      _snack(feeBlock);
      return;
    }
    // Lockout chalu ho to password ka darwaza hi band hai.
    if (p.pwdFp.isNotEmpty && p.pwdLocked) {
      final mins =
          ((p.pwdLockUntilMs - DateTime.now().millisecondsSinceEpoch) /
                  60000)
              .ceil();
      _snack(
          'Zyada ghalat koshishen — kuch der baad koshish karein (abhi $mins minute baqi hain).');
      return;
    }
    if (p.pwdFp.isEmpty) {
      final ok = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _SetPasswordDialog(store: store),
      );
      if (ok != true || !mounted) return;
      // RC2 follow-through (v1.2.9): naya password isi waqt backend
      // drivers row par bhi darj ho jaye taaki row phone se peeche
      // na reh jaye. Registration mukammal ho chuki ho to ensure
      // row ka bhi dobara jaiza — warna sirf fingerprint ki PATCH;
      // dono best-effort aur khamosh (duty flow nahi rukta).
      if (p.registrationComplete) {
        unawaited(Backend.ensureDriverRow(store));
      } else {
        unawaited(Backend.pushDriverFingerprint(store));
      }
    } else if (!store.dutyUnlocked) {
      final ok = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _AskPasswordDialog(store: store),
      );
      if (!mounted) return;
      if (ok != true) {
        if (p.pwdLocked) {
          _snack('Zyada ghalat koshishen — kuch der baad koshish karein.');
        }
        return;
      }
    }
    if (!p.selfieToday) {
      final take = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Pehle aaj ki selfie'),
          content: const Text(
              'Duty shuru karne se pehle aaj ki LIVE selfie lazmi hai — camera se hi hogi, gallery se nahi.'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Rehne Dein')),
            ElevatedButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Selfie Lein')),
          ],
        ),
      );
      if (take != true || !mounted) return;
      await _takeSelfie();
      if (!mounted) return;
      // Camera band karke wapas a gaya to selfie nahi bani — duty
      // shuru nahi hogi (HOTFIX v1.2.9: ab wajah bhi batayi jati
      // hai — pehle khamoshi se wapas ho jata tha).
      if (!p.selfieToday) {
        _snack(
            'Selfie ke baghair duty shuru nahi ho sakti — pehle aaj ki selfie lein.');
        return;
      }
    }
    p.online = true;
    await store.save();
    if (mounted) setState(() {});
  }

  Future<void> _changePassword() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => _ChangePasswordDialog(store: store),
    );
    if (ok == true && mounted) {
      _snack('Password badal gaya.');
      setState(() {});
    }
  }

  Future<void> _takeSelfie() async {
    try {
      // LIVE selfie — camera ONLY. No gallery option anywhere, by design.
      final XFile? img =
          await _picker.pickImage(source: ImageSource.camera);
      if (img == null) {
        // HOTFIX v1.2.9 (RC3): camera band karne / permission na
        // milne par khamoshi se wapas NAHI — wajah batao, warna
        // driver samajhta hai selfie wala option khulta hi nahi.
        if (mounted) {
          _snack(
              'Selfie nahi li gayi — camera band ho gaya ya permission nahi mili. Dobara koshish karein.');
        }
        return;
      }
      await store.setSelfie(img.path);
      if (mounted) _snack('Aaj ki selfie ho gayi — ab ride qubool ho sakti hai.');
    } catch (_) {
      if (mounted) _snack('Camera nahi khul saka.');
    }
  }

  int _todayNetEarnings() {
    final now = DateTime.now();
    var sum = 0;
    for (final b in store.bookings) {
      final c = b.completedAt;
      if (b.status == 'completed' &&
          c != null &&
          c.year == now.year &&
          c.month == now.month &&
          c.day == now.day) {
        sum += b.total - Fares.serviceFee(b.fare + b.waitingCharge);
      }
    }
    return sum;
  }

  @override
  Widget build(BuildContext context) {
    final incoming = _availableRides.length;
    return Scaffold(
      body: Column(
        children: [
          const BrandHeader(sideLabel: 'DRIVER APP'),
          if (store.updateAvailable && !store.updateDismissed)
            UpdateBanner(store: store),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
            child: Row(
              children: [
                Expanded(
                  child: ModeToggleButton(
                      toDriver: false, onTap: widget.onSwitchToPassenger),
                ),
                const SizedBox(width: 6),
                // v1.4.0: Notification Centre ki ghanti (unread badge) —
                // nayi ride / Master ka deposit / elanaat yahin ate hain.
                NotificationBell(store: store),
              ],
            ),
          ),
          // Malik ki driver mode artwork (brand board — rickshaw driver)
          // header + toggle ke foran neeche.
          const ModeBanner(asset: 'assets/mode-driver.png'),
          Expanded(
            child: _tab == 0
                ? _homeView()
                : _tab == 1
                    ? _poolView()
                    : _tab == 2
                        ? _bookingsView()
                        : _tab == 3
                            ? _walletView()
                            : _profileView(),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) {
          setState(() => _tab = i);
          // Pool ya Bookings par aate hi position taaza — doori/filter taaza rahe.
          if (i == 1 || i == 2) _refreshMyLocation();
        },
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Brand.green,
        items: [
          const BottomNavigationBarItem(
              icon: Icon(Icons.home), label: 'Home'),
          // POOL (DESIGN WAVE — brief Addendum): khadi rides ki
          // list; badge = abhi available pool rides ki tadaad.
          BottomNavigationBarItem(
            icon: Badge(
              label: Text('$incoming'),
              isLabelVisible: incoming > 0,
              child: const Icon(Icons.pool),
            ),
            label: 'Pool',
          ),
          BottomNavigationBarItem(
            icon: Badge(
              label: Text('$incoming'),
              isLabelVisible: incoming > 0,
              child: const Icon(Icons.notifications_active),
            ),
            label: 'Bookings',
          ),
          const BottomNavigationBarItem(
              icon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          const BottomNavigationBarItem(
              icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  // --- HOME: big online/offline state ---------------------------------------

  Widget _homeView() {
    final online = p.online;
    final numBlock = store.numberBlockReason();
    final devBlock = store.deviceBlockReason();
    final feeBlock = store.feeBlockReason();
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        // BLOCK NOTICES (2026-11-08): number tabdeeli (12 ghante)
        // ya fee hisaab (full settlement) ka block laga ho to
        // Home par sab se upar saaf notice — wajah + baqi waqt/
        // raqam ke saath. Block khatam hote hi khud gayab.
        if (numBlock != null || devBlock != null || feeBlock != null) ...[
          Card(
            color: const Color(0xFFFBEAEA),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.block, color: Brand.ajrakRed, size: 26),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(numBlock ?? devBlock ?? feeBlock!,
                        style: const TextStyle(
                            fontSize: 13.5, height: 1.45,
                            fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],
        // Registration baqi ho to sab se pehle us ka card — Yango-style
        // form yahin se khulta hai (v1.2.6). Gate ab
        // registrationComplete par hai (HOTFIX v1.2.9, RC2).
        if (!p.registrationComplete) ...[
          Card(
            color: Brand.deepGreen,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.app_registration,
                          color: Brand.gold, size: 26),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text('Registration baqi hai',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w900)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Driver banne ke liye registration form mukammal karein — mobile, CNIC, password, gaari aur selfie, qadam ba qadam.',
                    style: TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _openRegistration,
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Brand.gold,
                          foregroundColor: Brand.greenDark),
                      child: const Text('Registration Mukammal Karein'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],
        // ID tasdeeq ka intezaar — numaya khabar (v1.4.1):
        // registration mukammal ho lekin Master ne ID active na
        // ki ho to driver ko saaf pata ho ke woh kis marhale par
        // hai — na online ho sakta hai, na ride/pool qubool.
        if (p.registrationComplete && !p.masterActive) ...[
          Card(
            color: const Color(0xFFFFF3CD),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.hourglass_top, color: Brand.ajrakRed),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Aap ki ID abhi Master ki tasdeeq mein hai',
                          style: TextStyle(
                              fontWeight: FontWeight.w900, fontSize: 15),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          p.hasRejectedDocUi
                              ? 'Ek document reject hua hai — Profile ke "Mere Kagaz" mein Master ki wajah parh kar sahi kagaz dobara bhejein.'
                              : 'Documents Master ke paas check ho rahe hain. Tasdeeq hote hi aap online ho sakenge. Documents ki haalat Profile ke "Mere Kagaz" mein dekhein.',
                          style: const TextStyle(fontSize: 12.5),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],
        // BIG state card — inDrive style
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: online ? Brand.green : const Color(0xFF5A5A5A),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Brand.gold, width: 2),
          ),
          child: Column(
            children: [
              Icon(online ? Icons.check_circle : Icons.do_not_disturb_on,
                  color: Colors.white, size: 44),
              const SizedBox(height: 6),
              Text(online ? 'Aap ONLINE hain' : 'Aap OFFLINE hain',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w900)),
              Text(
                online
                    ? 'Ride requests aa sakti hain'
                    : 'Online honay par ride requests ayengi',
                style: const TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _toggleOnline,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: online ? Colors.white : Brand.gold,
                    foregroundColor:
                        online ? Brand.green : Brand.greenDark,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: Text(online ? 'Offline Ho Jayein' : 'Online Ho Jayein',
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        // inDrive D1 language: status ke foran baad aaj ki kamai +
        // wallet balance ki jhalak (top cards), phir profile/gates.
        Row(
          children: [
            Expanded(
              child: _statCard('Aaj ki kamai', rs(_todayNetEarnings()),
                  Icons.trending_up),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _statCard(
                  'Wallet balance', rs(p.walletBalance), Icons.wallet),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: Brand.deepGreen,
                  child: Text(
                    p.name.isNotEmpty ? p.name[0] : 'R',
                    style: const TextStyle(
                        color: Brand.gold,
                        fontSize: 22,
                        fontWeight: FontWeight.w900),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.name,
                          style: const TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w800)),
                      Text(
                          '${p.vehicle}${p.plate.isEmpty ? '' : ' · ${p.plate}'}${p.zone.isEmpty ? '' : ' · ${p.zone}'}'),
                      Text(p.zone.isEmpty ? 'Driver' : '${p.zone} Driver',
                          style: TextStyle(
                              fontSize: 12, color: Colors.grey.shade600)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 6),
        _gateRow(
          icon: Icons.payments,
          label: Fares.depositEnabled
              ? 'Joining Deposit (Rs ${Fares.joiningDeposit})'
              : 'Joining Deposit',
          // PILOT: deposit band ho to ye gate hamesha "ho gaya"
          // hai — joining bilkul muft hai, koi rok nahi.
          done: !Fares.depositEnabled || p.depositDone,
          doneText:
              Fares.depositEnabled ? 'Ho gaya' : 'Pilot — bilkul muft',
          pendingText:
              'Baqi — ${rs(Fares.joiningDeposit - p.totalDeposited)} aur chahiye',
          // 'Wallet' wala alag button hata diya (v1.2.6 faltu-button
          // safai) — Wallet neeche wale tab se hi khulta hai.
          onFix: null,
          fixLabel: '',
        ),
        _gateRow(
          icon: Icons.camera_alt,
          label: 'Aaj ki Live Selfie',
          done: p.selfieToday,
          doneText: 'Ho gayi',
          pendingText: 'Baqi — baghair selfie ride qubool nahi hogi',
          onFix: p.selfieToday ? null : _takeSelfie,
          fixLabel: 'Selfie Lein',
        ),
        _gateRow(
          icon: Icons.badge,
          label: 'CNIC Tasdeeq',
          // HOTFIX v1.2.9 (RC1): tasdeeq ki haalat ab sirf MASTER ke
          // pull shuda verdict se ati hai — local self-attestation
          // (cnicStatus) yahan kabhi istemal nahi hoti.
          done: p.masterCnicStatus == 'verified',
          doneText: 'Master ne Tasdeeq kar di',
          pendingText: p.masterCnicStatus == 'rejected'
              ? 'Reject ho gaya — sahi kagaz dobara dein'
              : 'Tasdeeq baqi hai',
          // Registration baqi ho to ye button registration form mein
          // le jata hai (CNIC wahan jama hota hai). Registration ke
          // baad 'Profile' wala duplicate button nahi — Profile
          // neeche wale tab se khulta hai (v1.2.6 safai).
          onFix: p.registrationComplete ? null : _openRegistration,
          fixLabel: 'Registration',
        ),
        const SizedBox(height: 10),
        if (p.selfiePath.isNotEmpty && p.selfieToday)
          Card(
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(File(p.selfiePath),
                    width: 46, height: 46, fit: BoxFit.cover),
              ),
              title: const Text('Aaj ki selfie'),
              subtitle: Text('Tareekh: ${p.selfieDate}'),
            ),
          ),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text(
              'Usool: Kiraya pehle se pakka hai — koi mol-bhav nahi. Service charges sirf ${fmtPct(Fares.feePercent)} (kiraya + waiting par). Wallet kabhi minus nahi jata. Pehle 5 minute intezaar muft, phir gaari ke hisab se waiting charges.',
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ),
      ],
    );
  }

  Widget _statCard(String label, String value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Icon(icon, color: Brand.gold, size: 26),
            const SizedBox(height: 6),
            Text(value,
                style: const TextStyle(
                    fontSize: 19, fontWeight: FontWeight.w900)),
            Text(label,
                style: const TextStyle(fontSize: 12, color: Colors.black54)),
          ],
        ),
      ),
    );
  }

  Widget _gateRow({
    required IconData icon,
    required String label,
    required bool done,
    required String doneText,
    required String pendingText,
    required VoidCallback? onFix,
    required String fixLabel,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: done ? Brand.green : Brand.ajrakRed),
        title: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(done ? doneText : pendingText),
        // onFix null ho to koi button NAHI — sirf pending ka nishan
        // (faltu navigation buttons v1.2.6 mein hata diye gaye hain;
        // Wallet/Profile neeche wale tabs se hi khulte hain).
        trailing: done
            ? const Icon(Icons.check_circle, color: Brand.green)
            : onFix != null
                ? TextButton(onPressed: onFix, child: Text(fixLabel))
                : const Icon(Icons.pending_actions,
                    color: Brand.ajrakRed),
      ),
    );
  }

  // --- POOL: khadi rides ki list (DESIGN WAVE — brief Addendum) --------------
  //
  // Pool screen mojooda nafsiati usool par bani hai:
  //  - ONLINE driver ko rides push bhi hoti hain AUR woh yahan list
  //    mein bhi khadi nazar ati hain — driver yahan se bhi utha
  //    sakta hai.
  //  - OFFLINE driver ko koi ride push NAHI hoti, lekin woh Pool
  //    mein aa kar apni pasand ki ride KHUD utha sakta hai (owner
  //    ka hukm 2026-11-07 ~22:46–22:48).
  //  - Har card par poori tafseel: passenger ka naam, pickup, drop,
  //    safar ki doori (km), sawari tak ki doori AUR tay-shuda FIXED
  //    kiraya — driver kiraya dekh kar apni marzi se uthaye ya
  //    chhor de; koi pabandi/penalty NAHI, bidding NAHI (fare lock
  //    sirf passenger side ka hai — driver ko kiraya dikhta hai).
  //  - Ride uthana wohi EK gate hai jo har accept par chalta hai
  //    (store.acceptBlockReason — ID active, deposit, aur PEHLI
  //    Pool pick par bhi rozana live selfie lazmi).
  //  - List ka source (v1.4.2): is phone ki local pending rides
  //    AUR backend Pool feed (doosre phones ki asal rides,
  //    coordinates samait) — _availableRides dono ko jodta hai.
  //  - 2 km radius filter yahan bhi wohi hai jo Bookings par hai:
  //    doori maloom ho aur radius se bahar ho to ride nahi dikhti;
  //    location off ho to sab dikhti hain (chhupana kabhi nahi).
  Widget _poolView() {
    final available = _availableRides;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Row(
          children: [
            const Expanded(
              child: Text('Ride Pool',
                  style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            ),
            OutlinedButton.icon(
              onPressed: () {
                _refreshMyLocation();
                unawaited(Backend.refreshRemotePool(store));
                setState(() {});
                _snack('Pool taaza kar diya gaya.');
              },
              icon: const Icon(Icons.refresh, size: 17),
              label: const Text('Update'),
              style: OutlinedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          p.online
              ? 'Aap ONLINE hain — nayi rides aap ko push bhi hoti hain aur yahan Pool mein bhi khadi milti hain.'
              : 'Aap OFFLINE hain — koi ride push nahi hogi, lekin yahan Pool se apni pasand ki ride khud utha sakte hain.',
          style: const TextStyle(fontSize: 12.5, color: Colors.black54),
        ),
        const SizedBox(height: 4),
        Text(
          _myPos == null
              ? 'Location off hai — saari khadi rides dikh rahi hain'
              : 'Sirf ${kDriverPickupRadiusKm.toStringAsFixed(0)} km ke andar ki rides dikh rahi hain',
          style: const TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 4),
        const Text(
          'Har ride ka kiraya pakka (fixed) hai — dekh kar apni marzi se uthayein, koi pabandi nahi.',
          style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w700,
              color: Brand.greenDark),
        ),
        const SizedBox(height: 10),
        if (available.isEmpty) ...[
          const SizedBox(height: 30),
          const Center(
            child: Icon(Icons.pool, size: 54, color: Colors.black26),
          ),
          const SizedBox(height: 10),
          const Center(
            child: Text(
              'Abhi koi ride request nahi hai — thodi der mein dobara dekhein.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14.5, color: Colors.black54),
            ),
          ),
        ],
        ...available.map(_poolCard),
      ],
    );
  }

  /// Pool ka ek ride card (brief Addendum ka namuna, Safar ki apni
  /// sabz/safed pehchan mein): sab se upar BADA fixed kiraya, saath
  /// passenger ka naam; neeche pickup/drop ki do lines + doori;
  /// aakhir mein "Ride Uthayein" — wohi _accept jo Bookings par
  /// hai (saare gates samet). Pool mein ride "rehne dena" koi
  /// button NAHI hai — na uthana hi driver ki marzi hai; booking
  /// kisi aur driver ke liye khadi rehti hai.
  Widget _poolCard(Booking b) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: Brand.gold, width: 2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('TAY-SHUDA KIRAYA',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Colors.black54)),
                    Text(rs(b.fare),
                        style: const TextStyle(
                            fontSize: 28, fontWeight: FontWeight.w900)),
                  ],
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(b.passengerName,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w900)),
                    if (b.passengerPhone.isNotEmpty)
                      Text(b.passengerPhone,
                          style: const TextStyle(color: Colors.black54)),
                    Text(fmtTime(b.createdAt),
                        style: const TextStyle(
                            color: Colors.black54, fontSize: 12)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
            _pickupDistanceLine(b),
            const SizedBox(height: 10),
            _routeLines(b),
            if (b.note.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('Note: ${b.note}',
                  style: const TextStyle(
                      fontSize: 13, fontStyle: FontStyle.italic)),
            ],
            if (b.hasDropPin) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  height: 180,
                  child: SafarRouteMap(
                    pickup: ll2.LatLng(b.pickupLat, b.pickupLng),
                    drop: ll2.LatLng(b.dropLat, b.dropLng),
                    interactive: false,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                Chip(
                  avatar: const Icon(Icons.route, size: 16),
                  label: Text(
                      'Safar: ${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm} km · ${b.vehicle}'),
                ),
                const Spacer(),
                Text(
                    '${kDriverPickupRadiusKm.toStringAsFixed(0)} km ke andar',
                    style: const TextStyle(
                        fontSize: 11.5, color: Colors.black45)),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => _accept(b),
                style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14)),
                child:
                    const Text('Ride Uthayein', style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- BOOKINGS: large incoming request cards --------------------------------

  Widget _bookingsView() {
    // 2 km RADIUS FILTER yahin lagta hai — list ki satah par. Is se
    // door ki pending rides is driver ki list mein aati hi nahi;
    // booking khud kahin change/delete nahi hoti (doosra qareeb
    // driver use dekh sakta hai). Location maloom na ho to _inRadius
    // sab ko pass kar deta hai.
    final incoming = _availableRides;
    final active = store.bookings
        .where((b) => b.status == 'accepted' || b.status == 'arrived')
        .toList();
    final past = store.bookings
        .where((b) =>
            b.status == 'completed' ||
            b.status == 'noshow' ||
            b.status == 'cancelled')
        .toList();
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('Aane wali bookings',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        Text(
          _myPos == null
              ? 'Location off hai — saari rides dikh rahi hain'
              : 'Sirf ${kDriverPickupRadiusKm.toStringAsFixed(0)} km ke andar ki rides dikh rahi hain',
          style: const TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 8),
        if (incoming.isEmpty)
          const Text('Abhi koi nayi booking nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...incoming.map(_incomingCard),
        const SizedBox(height: 16),
        const Text('Chal rahi rides',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (active.isEmpty)
          const Text('Koi ride chal nahi rahi.',
              style: TextStyle(color: Colors.black54)),
        ...active.map(_activeCard),
        const SizedBox(height: 16),
        const Text('Purani rides',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (past.isEmpty)
          const Text('Abhi koi purani ride nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...past.map((b) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: const Icon(Icons.history, color: Brand.green),
                title: Text('${b.pickupLabel} → ${b.dropLabel}'),
                subtitle: Text(
                    '${kStatusUrdu[b.status] ?? b.status} · ${fmtDate(b.completedAt ?? b.createdAt)} · ${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm} km'),
                trailing: Text(rs(b.total),
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
            )),
      ],
    );
  }

  Widget _routeLines(Booking b) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          const Icon(Icons.circle, color: Brand.green, size: 14),
          const SizedBox(width: 8),
          Expanded(
              child: Text('Pickup: ${b.pickupLabel}',
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700))),
        ]),
        const Padding(
          padding: EdgeInsets.only(left: 6),
          child: Icon(Icons.more_vert, size: 16, color: Colors.grey),
        ),
        Row(children: [
          const Icon(Icons.location_on, color: Brand.ajrakRed, size: 16),
          const SizedBox(width: 8),
          Expanded(
              child: Text('Drop: ${b.dropLabel}',
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700))),
        ]),
      ],
    );
  }

  Widget _incomingCard(Booking b) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(color: Brand.gold, width: 2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Chip(
                  label: Text('NAYI BOOKING'),
                  backgroundColor: Brand.goldLight,
                  labelStyle:
                      TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
                ),
                const Spacer(),
                Text(fmtTime(b.createdAt),
                    style: const TextStyle(color: Colors.black54)),
              ],
            ),
            const SizedBox(height: 8),
            Text(b.passengerName,
                style:
                    const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            if (b.passengerPhone.isNotEmpty)
              Text(b.passengerPhone,
                  style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 8),
            // Sawari yahan se kitni door khari hai — driver ki apni
            // mojooda jagah se pickup tak ki doori.
            _pickupDistanceLine(b),
            const SizedBox(height: 10),
            _routeLines(b),
            if (b.note.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('Note: ${b.note}',
                  style: const TextStyle(
                      fontSize: 13, fontStyle: FontStyle.italic)),
            ],
            if (b.hasDropPin) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  height: 180,
                  child: SafarRouteMap(
                    pickup: ll2.LatLng(b.pickupLat, b.pickupLng),
                    drop: ll2.LatLng(b.dropLat, b.dropLng),
                    interactive: false,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            Row(
              children: [
                Chip(
                  avatar: const Icon(Icons.route, size: 16),
                  label: Text(
                      '${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm} km · ${b.vehicle}'),
                ),
                const Spacer(),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('KUL KIRAYA',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Colors.black54)),
                    Text(rs(b.fare),
                        style: const TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w900)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => _accept(b),
                    style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                    child:
                        const Text('Qubool Karein', style: TextStyle(fontSize: 16)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () async {
                      await store.cancelBooking(b);
                      if (mounted) _snack('Booking rehne di gayi.');
                      setState(() {});
                    },
                    style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                    child:
                        const Text('Rehne Dein', style: TextStyle(fontSize: 16)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _accept(Booking b) async {
    final reason = store.acceptBlockReason();
    if (reason != null) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Ride qubool nahi ho sakti'),
          content: Text(reason),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Theek hai')),
          ],
        ),
      );
      return;
    }
    // v1.4.2 RACE GUARD (audit fix #2): backend Pool ki ride pehle
    // backend par ATOMIC claim hoti hai (status=eq.pending shart
    // wala PATCH) — do driver ek saath dabayein to sirf pehla
    // jeet-ta hai; doosre ko saaf paighaam milta hai aur ride us
    // ki list se nikal jati hai. Local (same-device) ride par
    // purana seedha accept hi chalta hai.
    if (b.fromBackend) {
      final claimed = await Backend.tryClaimRide(store, b.id);
      if (!claimed) {
        store.setRemotePool(
            store.remotePool.where((x) => x.id != b.id).toList());
        if (mounted) {
          _snack('Ye ride kisi aur driver ne le li hai.');
          setState(() {});
        }
        return;
      }
      await store.acceptRemoteBooking(b);
    } else {
      await store.acceptBooking(b);
    }
    // Qubool karte hi taaza position — passenger ko foran sahi
    // doori/ETA nazar aye (refresh khud store mein bhi darj karta hai).
    unawaited(_refreshMyLocation());
    // v1.4.0 two-phone: qubool shuda ride ke backend row par driver
    // ki pehli jagah foran likh dein — passenger ka ETA poll (~15s)
    // isi ko uthata hai. Position na mile to duty timer baad mein
    // likh dega. Khamosh nakami.
    final lat = p.lastLat;
    final lng = p.lastLng;
    if (lat != null && lng != null) {
      unawaited(Backend.pushRideDriverPosition(store, b.id, lat, lng));
    }
    if (mounted) {
      _snack('Booking qubool ho gayi.');
      setState(() {});
    }
  }

  /// Navigation (DriverNavView) ki GPS stream se ane wali position —
  /// store mein sirf tab darj hoti hai jab driver aakhri darj jagah
  /// se kam az kam ~50 m aage barh gaya ho, taaki har GPS tick par
  /// persist/backend-push na chale. Passenger ki doori/ETA line isi
  /// taaza position se khud taza ho jati hai.
  void _onNavPosition(ll2.LatLng pos) {
    final lat = p.lastLat;
    final lng = p.lastLng;
    if (lat != null && lng != null) {
      final moved = const ll2.Distance().as(ll2.LengthUnit.Meter,
          ll2.LatLng(lat, lng), pos);
      if (moved < 50) return;
    }
    store.setDriverPosition(pos.latitude, pos.longitude);
  }

  Widget _activeCard(Booking b) {
    final arrived = b.status == 'arrived';
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(b.passengerName,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w900)),
                const Spacer(),
                Chip(
                  label: Text(arrived ? 'Pohanch gaye' : 'Qubool shuda'),
                  backgroundColor:
                      arrived ? const Color(0xFFF3E9C8) : const Color(0xFFDFF5E6),
                  labelStyle: const TextStyle(fontSize: 11),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _routeLines(b),
            if (!arrived) ...[
              const SizedBox(height: 8),
              // Pickup tak kitni doori baqi hai — aakhri maloom
              // position se (nav chale to wahin se taaza hoti rehti
              // hai; yahan alag stream nahi chalaya gaya).
              _pickupDistanceLine(b),
            ],
            const SizedBox(height: 8),
            // v1.4.0: SOS — ride chal rahi ho to driver ke liye bhi
            // hifazat ka button (police call + ride tafseel ghar
            // walon ko WhatsApp).
            SosButton(store: store, booking: b, role: 'driver'),
            const SizedBox(height: 8),
            if (b.hasDropPin) ...[
              DriverNavView(booking: b, onPosition: _onNavPosition),
              const SizedBox(height: 10),
            ],
            Text(
                'Kiraya: ${rs(b.fare)} · ${b.vehicle} · ${b.distanceKm == b.distanceKm.roundToDouble() ? b.distanceKm.toInt() : b.distanceKm} km'),
            if (!arrived) ...[
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () async {
                    await store.markArrived(b);
                    if (mounted) {
                      _snack(
                          'Waiting timer shuru — pehle ${Fares.freeWaitingMinutes} minute muft hain.');
                      setState(() {});
                    }
                  },
                  icon: const Icon(Icons.location_on),
                  label: const Text('Pohanch Gaya'),
                ),
              ),
            ] else ...[
              const SizedBox(height: 10),
              _LiveWaiting(booking: b, store: store),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => _complete(b),
                  icon: const Icon(Icons.flag),
                  label: const Text('Ride Mukammal Karein'),
                  style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14)),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => _noShow(b),
                  icon: const Icon(Icons.person_off),
                  label: const Text('Sawari Nahi Aayi (No-show)'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _complete(Booking b) async {
    final err = await store.completeBooking(b);
    if (!mounted) return;
    if (err != null) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Ride mukammal nahi ho sakti'),
          content: Text(err),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Theek hai')),
          ],
        ),
      );
    } else {
      _snack(
          'Ride mukammal — kiraya ${rs(b.fare)} + waiting ${rs(b.waitingCharge)}; ${fmtPct(Fares.feePercent)} service charges wallet se kat gaya.');
    }
    setState(() {});
  }

  Future<void> _noShow(Booking b) async {
    final err = await store.markNoShow(b);
    if (!mounted) return;
    _snack(err ??
        'No-show darj ho gaya — waiting charges ${rs(b.waitingCharge)} record mein hain.');
    setState(() {});
  }

  // --- WALLET -----------------------------------------------------------------

  final _depositCtrl = TextEditingController();
  String _depositMethod = 'Cash';
  // Fee settlement (hisaab saaf) ka form — deposit form se alag.
  final _feePayCtrl = TextEditingController();
  String _feePayMethod = 'Raast';

  /// Kamai report ki ek patti (hafta/mahina) — rides, kul, fee, net.
  Widget _earningsRow(
      String label, ({int rides, int gross, int fee, int net}) e) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Brand.lightBg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style:
                  const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
          const SizedBox(height: 4),
          Text(
            'Rides: ${e.rides} · Kul kamai: ${rs(e.gross)} · '
            'Service charges: ${rs(e.fee)} · Asal bachat: ${rs(e.net)}',
            style: const TextStyle(fontSize: 12.5),
          ),
        ],
      ),
    );
  }

  /// Kamai report WhatsApp par text ki surat mein share karna —
  /// passenger ke share-my-ride wala hi tareeqa (wa.me link).
  Future<void> _shareEarningsReport() async {
    final w = store.earningsThisWeek();
    final m = store.earningsThisMonth();
    final text = 'SAFAR — Meri Kamai Ki Report\n'
        'Driver: ${p.name}\n'
        'IS HAFTE: Rides ${w.rides} · Kul ${rs(w.gross)} · '
        'Service charges ${rs(w.fee)} · Asal bachat ${rs(w.net)}\n'
        'IS MAHINE: Rides ${m.rides} · Kul ${rs(m.gross)} · '
        'Service charges ${rs(m.fee)} · Asal bachat ${rs(m.net)}\n'
        'Wallet balance: ${rs(p.walletBalance)}';
    final uri =
        Uri.parse('https://wa.me/?text=${Uri.encodeComponent(text)}');
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) _snack('WhatsApp nahi khul saka.');
  }

  // (deposit/pwd controllers ki dispose is file ke _DriverSideState
  // ke dispose() mein pehle se hoti thi — v1.4.0 mein wahan banners
  // + duty timer bhi band hote hain.)

  Widget _walletView() {
    final remaining = Fares.joiningDeposit - p.totalDeposited;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Brand.deepGreen,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Brand.gold, width: 2),
          ),
          child: Column(
            children: [
              const Text('WALLET BALANCE',
                  style: TextStyle(
                      color: Brand.goldLight,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2)),
              Text(rs(p.walletBalance),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.w900)),
              Text(
                !Fares.depositEnabled
                    ? 'Pilot marhala — joining bilkul muft hai, koi deposit nahi'
                    : p.depositDone
                        ? 'Joining deposit mukammal hai'
                        : 'Joining deposit baqi: ${rs(remaining > 0 ? remaining : 0)} aur chahiye',
                style: const TextStyle(color: Brand.cream, fontSize: 12),
              ),
              const SizedBox(height: 6),
              Text(
                !Fares.depositEnabled
                    ? (p.feeDue > 0
                        ? 'Master ko bhejna hai (service fee hisaab): ${rs(p.feeDue)} — haftawar Raast 0312 2635002 par bhejein.'
                        : 'Har ride par sirf ${fmtPct(Fares.feePercent)} service fee ka hisaab chalta hai — haftawar Master ko bhejna hota hai.')
                    : 'Wallet kabhi minus nahi jata — fee sirf balance se kat ti hai.',
                style: const TextStyle(color: Colors.white60, fontSize: 11),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // --- DENA HAI: baqi service fee ka hisaab (2026-11-08) ---
        // Har mukammal ride par fee khud jama hoti hai; yahan
        // driver apna kul dena dekhta hai aur payment darj karke
        // hisaab saaf karwata hai. Had (feeSettleLimit) se upar
        // jane par online/accept khud band ho jata hai.
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: store.feeBlockReason() != null
                ? const Color(0xFFFBEAEA)
                : const Color(0xFFFFF6E0),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: store.feeBlockReason() != null
                    ? Brand.ajrakRed
                    : Brand.gold,
                width: 1.5),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text('Dena Hai (Service Fee)',
                      style: TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w900)),
                  const Spacer(),
                  Text(rs(p.feeDue),
                      style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: store.feeBlockReason() != null
                              ? Brand.ajrakRed
                              : Brand.greenDark)),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                p.feeDue <= 0
                    ? 'Aap ka hisaab saaf hai — koi fee baqi nahi.'
                    : store.feeBlockReason() != null
                        ? 'Ye raqam had (${rs(Fares.feeSettleLimit)}) tak pahunch chuki hai — is liye nayi rides band hain. Yaad rahe: block SIRF poori raqam settle hone par khulega, juzwi (aadhi) payment se NAHI khulega. Neeche se poori payment darj karein.'
                        : 'Har mukammal ride par ${fmtPct(Fares.feePercent)} fee yahan jama hoti hai. Had ${rs(Fares.feeSettleLimit)} hai — us se pehle hisaab saaf kar lein taaki rides na rukein.',
                style: const TextStyle(fontSize: 12.5, height: 1.4),
              ),
              if (p.feeDue > 0) ...[
                const SizedBox(height: 10),
                TextField(
                  controller: _feePayCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'Payment ki raqam (Rs)',
                      prefixIcon: Icon(Icons.receipt_long)),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    const Text('Tareeqa: ',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                    for (final m in ['Raast', 'Easypaisa', 'JazzCash', 'Cash'])
                      ChoiceChip(
                        label: Text(m),
                        selected: _feePayMethod == m,
                        onSelected: (_) =>
                            setState(() => _feePayMethod = m),
                      ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  'Pehle raqam Safar ke official number 0312 2635002 par bhejein, phir yahan darj karein. Master tasdeeq karega to "Dena Hai" kam ho jayega.',
                  style: TextStyle(fontSize: 12, color: Colors.black54),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      final amt =
                          int.tryParse(_feePayCtrl.text.trim()) ?? 0;
                      if (amt <= 0) {
                        _snack('Durust raqam likhein.');
                        return;
                      }
                      await store.addFeePayment(amt, _feePayMethod);
                      _feePayCtrl.clear();
                      if (mounted) {
                        _snack(
                            'Payment ${rs(amt)} darj ho gayi — Master ki tasdeeq baqi hai.');
                        setState(() {});
                      }
                    },
                    child: const Text('Payment Darj Karein'),
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 16),
        if (!Fares.depositEnabled) ...[
          // PILOT NOTE (malik ka faisla 2026-11-08): deposit band
          // hai — form ki jagah saaf note. Joining bilkul muft;
          // sirf service fee ka hisaab chalta hai.
          Card(
            color: const Color(0xFFE8F5EE),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(
                'Pilot marhala: joining deposit abhi band hai — app bilkul muft hai. '
                'Sirf har mukammal ride par ${fmtPct(Fares.feePercent)} service fee ka hisaab chalta hai, '
                'jo haftawar Master ko bhejna hota hai (Raast 0312 2635002).',
                style: const TextStyle(fontSize: 13.5, height: 1.45),
              ),
            ),
          ),
        ] else ...[
        const Text('Deposit Darj Karein',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        TextField(
          controller: _depositCtrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
              labelText: 'Raqam (Rs)', prefixIcon: Icon(Icons.payments)),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            const Text('Tareeqa: ',
                style: TextStyle(fontWeight: FontWeight.w700)),
            ChoiceChip(
              label: const Text('Cash'),
              selected: _depositMethod == 'Cash',
              onSelected: (_) => setState(() => _depositMethod = 'Cash'),
            ),
            ChoiceChip(
              label: const Text('Raast'),
              selected: _depositMethod == 'Raast',
              onSelected: (_) => setState(() => _depositMethod = 'Raast'),
            ),
            ChoiceChip(
              label: const Text('Easypaisa'),
              selected: _depositMethod == 'Easypaisa',
              onSelected: (_) => setState(() => _depositMethod = 'Easypaisa'),
            ),
            ChoiceChip(
              label: const Text('JazzCash'),
              selected: _depositMethod == 'JazzCash',
              onSelected: (_) => setState(() => _depositMethod = 'JazzCash'),
            ),
          ],
        ),
        if (_depositMethod == 'Easypaisa' ||
            _depositMethod == 'JazzCash') ...[
          const SizedBox(height: 8),
          Text(
            'Pehle apne $_depositMethod app se Safar ke official number 0312 2635002 par raqam bhejein, phir yahan darj karein.',
            style: const TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () async {
              final amt = int.tryParse(_depositCtrl.text.trim()) ?? 0;
              if (amt <= 0) {
                _snack('Durust raqam likhein.');
                return;
              }
              await store.addDeposit(amt, _depositMethod);
              _depositCtrl.clear();
              if (mounted) {
                _snack('Deposit ${rs(amt)} darj ho gaya.');
                setState(() {});
              }
            },
            child: const Text('Deposit Jama Karein'),
          ),
        ),
        ],
        const SizedBox(height: 20),
        // v1.4.0 — KAMAI KI REPORT: is hafte + is mahine ka khulasa
        // (rides, kul kamai, service charges, asal bachat) — sirf
        // local bookings/ledger se (store.earnings*), koi backend
        // nahi. Share-as-text WhatsApp par — app ka mojooda tareeqa.
        Row(
          children: [
            const Text('Kamai Ki Report',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
            const Spacer(),
            TextButton.icon(
              onPressed: _shareEarningsReport,
              icon: const Icon(Icons.share, size: 16),
              label: const Text('Share Karein'),
            ),
          ],
        ),
        const SizedBox(height: 4),
        _earningsRow('Is Hafte', store.earningsThisWeek()),
        const SizedBox(height: 6),
        _earningsRow('Is Mahine', store.earningsThisMonth()),
        const SizedBox(height: 20),
        const Text('Monthly Packages',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.monthlyPackages.isEmpty)
          const Text('Abhi koi monthly package nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...store.monthlyPackages.map((mp) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading:
                    const Icon(Icons.calendar_month, color: Brand.green),
                title: Text('${mp.pickup} → ${mp.drop}'),
                subtitle: Text(
                    '${mp.passengerName.isEmpty ? 'Sawari' : mp.passengerName} · ${mp.vehicle} · ${mp.days} din'),
                trailing: Text(rs(mp.monthlyAmount),
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            )),
        const SizedBox(height: 20),
        const Text('Hisab Kitab (Ledger)',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.txns.isEmpty)
          const Text('Abhi koi entry nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...store.txns.map((t) {
          final isDeposit = t.type == 'deposit';
          final isFeePay = t.type == 'fee_payment';
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Icon(
                isDeposit
                    ? Icons.arrow_downward
                    : isFeePay
                        ? Icons.receipt_long
                        : Icons.percent,
                color: isDeposit
                    ? Brand.green
                    : isFeePay
                        ? Brand.green
                        : Brand.ajrakRed,
              ),
              title: Text(isDeposit
                  ? 'Deposit — ${t.method}'
                  : isFeePay
                      ? 'Fee Payment — ${t.method} (tasdeeq baqi)'
                      : 'Service charges ${fmtPct(Fares.feePercent)}'),
              subtitle: Text('${t.note}\n${fmtDate(t.date)} ${fmtTime(t.date)}'),
              isThreeLine: true,
              trailing: Text(
                isDeposit ? '+ ${rs(t.amount)}' : '− ${rs(t.amount)}',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: isDeposit || isFeePay
                      ? Brand.green
                      : Brand.ajrakRed,
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  // --- PROFILE (FORM USOOL — 2026-11-08) --------------------------------------
  //
  // FORM USOOL (owner ka hukm): Profile par koi form display par
  // khula/pehle-bhara NAHI ata. Profile sirf:
  //   (1) STATUS LINES — account ki haalat, driver ki apni maloomat
  //       (naam/mobile/gaari/sheher), Tasdeeq ki asal haalat
  //       (Verified pill sirf Master ke faisle par), Mere Kagaz ki
  //       haalatein, rozana selfie ki haalat, password ki haalat;
  //   (2) BUTTONS — jo sahi step par RegistrationWizard khol dein
  //       (har tabdeeli sirf wizard mein, step-by-step hoti hai),
  //       password ke liye set/change wale dialogs, Master ko
  //       Message ka darwaza, aur reject shuda document ko Dobara
  //       Bhejne ka amal (woh editing form nahi — sirf wohi ek
  //       document ki nayi photo hai).
  // Purane inline editing fields (naam/phone/plate/brand/model/
  // year/color/zone/vehicle chips) aur "Profile Save Karein" wala
  // khula form yahan se KHTAM hai. Password ke usool (fingerprint,
  // uniqueness, lockout) aur un ke exact jumle bilkul nahi chhere
  // gaye — set/change ke dialogs wohi hain jo pehle thay.

  /// Read-only maloomat ki ek line (status display — koi field nahi).
  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 118,
            child: Text(label,
                style: const TextStyle(
                    fontWeight: FontWeight.w700, color: Colors.black54)),
          ),
          Expanded(
            child: Text(value.isEmpty ? '—' : value,
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _profileView() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('Driver Profile',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        // Master tasdeeq ki haalat — backend drivers.active se ati hai.
        // Profile Save = registration (pending); Master ACTIVE kare to
        // ye card badal jata hai. Refresh se foran nayi haalat pull.
        Card(
          color: p.masterActive ? Brand.deepGreen : null,
          child: ListTile(
            leading: Icon(
              p.masterActive ? Icons.verified : Icons.pending_actions,
              color: p.masterActive ? Brand.gold : Brand.ajrakRed,
            ),
            title: Text(
              p.masterActive
                  ? 'Account ACTIVE hai'
                  : 'Account PENDING hai',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                color: p.masterActive ? Colors.white : null,
              ),
            ),
            subtitle: Text(
              p.masterActive
                  ? 'Master ne tasdeeq kar di hai — aap ka account online system mein active hai.'
                  : 'Registration form mukammal karein — Master ki tasdeeq ke baad account active hoga.',
              style: TextStyle(
                color: p.masterActive ? Colors.white70 : null,
              ),
            ),
            trailing: IconButton(
              icon: Icon(Icons.refresh,
                  color: p.masterActive ? Brand.gold : Brand.green),
              tooltip: 'Status refresh karein',
              onPressed: () async {
                await Backend.refreshDriverStatus(store);
                if (mounted) setState(() {});
              },
            ),
          ),
        ),
        const SizedBox(height: 10),
        // Registration (v1.2.6): pehli registration Yango-style wizard
        // se hoti hai — Profile mein us ka darwaza hai, doosri
        // competing form NAHI. Mukammal ho to tafseel yahin se dobara
        // khol kar badli ja sakti hai.
        Card(
          // HOTFIX v1.2.9 (RC2): card ki haalat registrationComplete
          // par — flag laga ho lekin photos baqi hon to card
          // "tasaveer baqi hain" wali soorat mein dikhta hai.
          color: p.registrationComplete ? null : Brand.deepGreen,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.app_registration,
                        color:
                            p.registrationComplete ? Brand.green : Brand.gold),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        p.registrationComplete
                            ? 'Registration mukammal hai'
                            : (p.registrationDone
                                ? 'Registration ki tasaveer baqi hain'
                                : 'Registration baqi hai'),
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                          color: p.registrationComplete ? null : Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  p.registrationComplete
                      ? 'CNIC, gaari, licence aur selfie ki tafseel form mein darj hai.'
                      : (p.registrationDone
                          ? 'Form pehle bhara gaya tha lekin CNIC, gaari aur selfie ki tasaveer baqi hain — form khol kar sirf wohi jama karein, baqi tafseel bhari hui milegi.'
                          : 'Mobile, CNIC, password, gaari aur selfie — qadam ba qadam form bharein.'),
                  style: TextStyle(
                    fontSize: 12,
                    color: p.registrationComplete
                        ? Colors.black54
                        : Colors.white70,
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _openRegistration,
                    style: p.registrationComplete
                        ? null
                        : ElevatedButton.styleFrom(
                            backgroundColor: Brand.gold,
                            foregroundColor: Brand.greenDark),
                    child: Text(p.registrationComplete
                        ? 'Tafseel Dekhein / Badlein'
                        : 'Registration Mukammal Karein'),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        // Master ko Message (v1.2.7): masla/shikayat seedha Master
        // (head) ko — Profile tab se hi darwaza hai.
        Card(
          child: ListTile(
            leading: const Icon(Icons.mail_outline, color: Brand.green),
            title: const Text('Master ko Message Bhejein',
                style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text(
                'Koi masla ya shikayat ho to seedha Master (head) ko message bhejein — jawab ki haalat wahin nazar ayegi.'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _openMessages,
          ),
        ),
        // v1.4.0: driver ki apni rating — backend se pull shuda
        // ausat (backendRatingAvg) pehle; woh na ho to is phone par
        // sawariyon ki di hui ratings ka local ausat. Koi rating hi
        // na ho to ye patti NAHI dikhti (jhoota number kabhi nahi).
        if (store.backendRatingAvg != null ||
            store.localOwnRatingAverage != null) ...[
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const Icon(Icons.star, color: Brand.gold),
              title: Text(
                'Meri Rating: ${(store.backendRatingAvg ?? store.localOwnRatingAverage)!.toStringAsFixed(1)} / 5',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text(store.backendRatingAvg != null
                  ? '${store.backendRatingCount} sawariyon ne rating di'
                  : 'Is phone par di gayi ratings se'),
            ),
          ),
        ],
        const SizedBox(height: 10),
        // --- APNI MALOOMAT (sirf status lines — koi form NAHI) ---
        // FORM USOOL (2026-11-08): naam/mobile/gaari/sheher yahan
        // sirf DIKHTE hain (read-only status lines). Koi tabdeeli
        // chahiye ho to neeche ka button seedha RegistrationWizard
        // kholta hai — tafseel pehle se bhari hui milegi, badalna
        // step-by-step wizard mein hi hoga.
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.person, color: Brand.green),
                    SizedBox(width: 9),
                    Text('Meri Maloomat',
                        style: TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 15)),
                  ],
                ),
                const SizedBox(height: 8),
                _infoRow('Naam', p.name),
                _infoRow('Mobile', p.phone),
                _infoRow('Sheher (Zone)',
                    p.zone.isEmpty ? 'Abhi set nahi hai' : p.zone),
                _infoRow('Gaari',
                    '${p.vehicle}${p.vehicleBrand.isEmpty ? '' : ' · ${p.vehicleBrand}'}${p.vehicleModel.isEmpty ? '' : ' ${p.vehicleModel}'}'),
                _infoRow('Saal / Rang',
                    '${p.vehicleYear == 0 ? '—' : p.vehicleYear} / ${p.vehicleColor.isEmpty ? '—' : p.vehicleColor}'),
                _infoRow('Number plate', p.plate),
                const SizedBox(height: 8),
                // TASDEEQ PILL (brief S6): badge SIRF Master ke asal
                // faisle par — ID active ho to sabz 'Verified';
                // reject ho to laal; warna amber 'Tasdeeq baqi hai'.
                // Driver khud ye badge kabhi nahi laga sakta.
                Row(
                  children: [
                    const Text('Tasdeeq: ',
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: Colors.black54)),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: (p.hasRejectedDocUi
                                ? Brand.ajrakRed
                                : p.masterActive
                                    ? Brand.green
                                    : const Color(0xFFB8860B))
                            .withOpacity(0.13),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: p.hasRejectedDocUi
                              ? Brand.ajrakRed
                              : p.masterActive
                                  ? Brand.green
                                  : const Color(0xFFB8860B),
                          width: 0.9,
                        ),
                      ),
                      child: Text(
                        p.hasRejectedDocUi
                            ? 'Reject — neeche wajah dekhein'
                            : p.masterActive
                                ? '✓ Verified'
                                : 'Tasdeeq baqi hai',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: p.hasRejectedDocUi
                              ? Brand.ajrakRed
                              : p.masterActive
                                  ? Brand.green
                                  : const Color(0xFFB8860B),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: _openRegistration,
                    child: const Text('Tafseel Badlein (Form)'),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 18),
        const Text('Mere Kagaz',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        // MERE KAGAZ panel (v1.4.1 — Owner Tasdeeq Duty, Part B):
        // har document ki Master-wali asal haalat — Tasdeeq Shuda ✓ /
        // Reject ✗ Master ki wajah ke saath (lafz-ba-lafz) /
        // Intezaar Mein… Tasdeeq SIRF Master karta hai (v1.2.9 lock
        // barkarar): driver yahan se sirf document DOBARA bhej sakta
        // hai — koi *_status woh khud kabhi set nahi kar sakta.
        const Text(
            'CNIC lazmi hai. Licence ikhtiyari hai — na ho to koi baat nahi. Har document ki tasdeeq sirf Master karta hai; reject ho to wajah ke saath wohi document dobara bheja ja sakta hai.',
            style: TextStyle(fontSize: 12, color: Colors.black54)),
        const SizedBox(height: 8),
        // DEVICE KA USOOL — mustaqil hidayat (malik ka hukm
        // 2026-11-08): ek account, sirf ek device.
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF6E0),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Brand.gold),
          ),
          child: const Text(
            'Device ka usool: sirf EK hi device istemal karein — aap ka account isi device se bandha hua hai. '
            'Device tabdeel na karein; doosri device par account khula to ID khud-ba-khud 6 ghante block ho jati hai aur Master ko khabar chali jati hai. '
            'Agar device badalna zaruri ho to PEHLE Master ko message karke batayein.',
            style: TextStyle(fontSize: 12.5, height: 1.45),
          ),
        ),
        const SizedBox(height: 10),
        _mereKagazRow(
          group: 'cnic',
          label: 'CNIC',
          kinds: const [
            ('cnic_front', 'CNIC — Samne wali photo'),
            ('cnic_back', 'CNIC — Peeche wali photo'),
          ],
          photoMissing: p.cnicFrontPath.isEmpty || p.cnicBackPath.isEmpty,
        ),
        _mereKagazRow(
          group: 'gaari',
          label: 'Gaari ke Kaghaz',
          kinds: const [
            ('vehicle', 'Gaari ki photo'),
            ('vehicle_reg', 'Kaghaz (Registration) ki photo'),
          ],
          photoMissing: p.vehicleRegPath.isEmpty,
        ),
        // PTA PROOF (2026-11-08): IMEI wala hisaab — screenshot
        // NAHI. Status Master ka (pull shuda); IMEI sirf wizard se
        // badalta hai. PTA LAZMI shart sirf tab hai jab malik ne
        // Master se "PTA Proof lazmi" ON kiya ho (Fares.ptaRequired,
        // migration v133) — default band (ikhtiyari) hai.
        Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      p.masterStatusFor('pta') == 'verified'
                          ? Icons.verified
                          : p.masterStatusFor('pta') == 'rejected'
                              ? Icons.cancel
                              : Icons.pending_actions,
                      color: p.masterStatusFor('pta') == 'verified'
                          ? Brand.green
                          : p.masterStatusFor('pta') == 'rejected'
                              ? Brand.ajrakRed
                              : const Color(0xFFB8860B),
                    ),
                    const SizedBox(width: 9),
                    const Expanded(
                      child: Text('PTA Proof',
                          style: TextStyle(fontWeight: FontWeight.w800)),
                    ),
                    Text(
                      p.masterStatusFor('pta') == 'verified'
                          ? 'Tasdeeq Shuda ✓'
                          : p.masterStatusFor('pta') == 'rejected'
                              ? 'Reject ✗'
                              : 'Intezaar Mein…',
                      style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: p.masterStatusFor('pta') == 'verified'
                              ? Brand.green
                              : p.masterStatusFor('pta') == 'rejected'
                                  ? Brand.ajrakRed
                                  : const Color(0xFFB8860B)),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  p.imei.isEmpty
                      ? 'IMEI abhi darj nahi — registration form ke "PTA Proof" hisse mein *#06# wala IMEI likhein.'
                      : 'Aap ka IMEI: ${p.imei}',
                  style: const TextStyle(fontSize: 13),
                ),
                if (p.masterStatusFor('pta') == 'rejected' &&
                    p.masterReasonFor('pta').isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text('Master ki wajah: ${p.masterReasonFor('pta')}',
                      style: const TextStyle(
                          fontSize: 12.5,
                          color: Brand.ajrakRed,
                          fontWeight: FontWeight.w600)),
                ],
                const SizedBox(height: 4),
                Text(
                  Fares.ptaRequired
                      ? 'IMEI ghalat ya mobile PTA-approved na ho to ID NAHI banti. IMEI badalna ho to registration form se badlein — naya IMEI dobara check hoga.'
                      : 'Filhal IMEI ikhtiyari hai — Master ne "PTA Proof lazmi" band rakha hai, is liye IMEI na ho to bhi ID ban sakti hai. IMEI badalna ho to registration form se badlein.',
                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        const Text('Driving Licence',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        // Licence hai/nahi — ye registration DATA hai, tasdeeq nahi;
        // ab sirf wizard mein badalta hai, yahan sirf maloomat.
        Text(
          p.licenceStatus == 'has'
              ? 'Licence hai${p.licenceNumber.isNotEmpty ? ' — ${p.licenceNumber}' : ''} (badalna ho to registration form se)'
              : 'Licence nahi hai — CNIC se kaam chal jayega. (Badalna ho to registration form se.)',
          style: const TextStyle(fontSize: 13, color: Colors.black54),
        ),
        if (p.licenceStatus == 'has') ...[
          const SizedBox(height: 8),
          _mereKagazRow(
            group: 'licence',
            label: 'Licence Tasdeeq',
            kinds: const [
              ('licence', 'Licence ki photo'),
            ],
            photoMissing: p.licencePhotoPath.isEmpty,
          ),
        ],
        const SizedBox(height: 4),
        // Profile selfie — Master ki ID wali photo. Is ka alag
        // *_status nahi hai; haalat = photo Master tak gayi ya nahi
        // (ID ki asal tasdeeq upar wale Account card mein hai).
        Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: Icon(
              p.profilePhotoPath.isNotEmpty
                  ? Icons.verified
                  : Icons.pending_actions,
              color: p.profilePhotoPath.isNotEmpty
                  ? Brand.green
                  : Brand.ajrakRed,
            ),
            title: const Text('Profile Selfie (ID wali photo)',
                style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(
              p.profilePhotoPath.isNotEmpty
                  ? 'Photo Master ke paas hai — ID ki tasdeeq upar wale card mein hai'
                  : 'Photo abhi baqi hai — camera se live selfie dein',
              style: TextStyle(
                  color: p.profilePhotoPath.isNotEmpty
                      ? Brand.green
                      : Brand.ajrakRed,
                  fontWeight: FontWeight.w600),
            ),
            trailing: p.profilePhotoPath.isEmpty
                ? OutlinedButton(
                    onPressed: () => _reuploadDoc('profile'),
                    child: const Text('Selfie Dein'),
                  )
                : null,
          ),
        ),
        const SizedBox(height: 18),
        Card(
          child: ListTile(
            leading: Icon(Icons.camera_alt,
                color: p.selfieToday ? Brand.green : Brand.ajrakRed),
            title: const Text('Rozana Live Selfie'),
            subtitle: Text(p.selfieToday
                ? 'Aaj ki selfie ho gayi (${p.selfieDate})'
                : 'Aaj ki selfie baqi hai — camera se hi hogi, gallery se nahi'),
            // Yahan wala 'Selfie Lein' button hata diya (v1.2.6 safai) —
            // wohi amal Home ke gate row aur duty-on par pehle se
            // hota hai; yahan sirf haalat dikhti hai.
            trailing: p.selfieToday
                ? const Icon(Icons.check_circle, color: Brand.green)
                : const Icon(Icons.pending_actions,
                    color: Brand.ajrakRed),
          ),
        ),
        const SizedBox(height: 14),
        // PASSWORD (v1.2.5 — malik ka hukm): har driver apna password
        // khud lagata hai; ek password sirf EK driver ka hota hai.
        // v1.2.6: registration baqi ho to password WIZARD ke qadam mein
        // lagta hai — yahan wale inline fields sirf un profiles ke
        // liye hain jin ki registration mukammal hai lekin password
        // abhi nahi laga (purane profiles), taaki do competing forms
        // na hon. Registration wale card (upar) se form khulta hai.
        if (p.pwdFp.isEmpty && !p.registrationComplete)
          const Card(
            child: ListTile(
              leading: Icon(Icons.lock_outline, color: Brand.ajrakRed),
              title: Text('Password baqi hai',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(
                  'Password registration form ke qadam mein lagayein — upar wale Registration card se form kholein.'),
            ),
          )
        else if (p.pwdFp.isEmpty)
          // FORM USOOL (2026-11-08): password ke inline khule fields
          // khatam — Profile sirf haalat dikhati hai aur button wohi
          // _SetPasswordDialog kholta hai jo duty-on par bhi ata hai
          // (usool, uniqueness check aur exact jumle bilkul waisay
          // hi — sirf jagah badli hai, amal nahi).
          Card(
            child: ListTile(
              leading:
                  const Icon(Icons.lock_outline, color: Brand.ajrakRed),
              title: const Text('Password baqi hai',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text(
                  'Har driver apna password khud lagata hai — ek password sirf ek hi driver ka hota hai. Duty shuru karne par yahi password manga jayega.'),
              trailing: TextButton(
                onPressed: () async {
                  final ok = await showDialog<bool>(
                    context: context,
                    barrierDismissible: false,
                    builder: (_) => _SetPasswordDialog(store: store),
                  );
                  if (ok == true && mounted) {
                    _snack('Password lag gaya.');
                    setState(() {});
                  }
                },
                child: const Text('Lagayein'),
              ),
            ),
          )
        else
          Card(
            child: ListTile(
              leading: const Icon(Icons.lock, color: Brand.green),
              title: const Text('Password set hai',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text(
                  'Duty shuru karne par password manga jata hai — ek password sirf aap ka hai.'),
              trailing: TextButton(
                onPressed: _changePassword,
                child: const Text('Badlein'),
              ),
            ),
          ),
        // NOTE (v1.0.5): "Service Charges %" editor yahan kabhi tha
        // hi nahi rakha gaya — fee sirf Master app mein set hoti hai.
        // NOTE (FORM USOOL 2026-11-08): purana "Profile Save Karein"
        // wala khula form (naam/phone/plate/gaari ke inline fields
        // + un ke saath chalta password set) yahan se KHTAM hai —
        // Profile ab sirf status + buttons hai; har tabdeeli
        // RegistrationWizard mein step-by-step hoti hai.
      ],
    );
  }

  /// Mere Kagaz ki ek document row (v1.4.1): SIRF Master ka pull
  /// shuda faisla + us ki wajah lafz-ba-lafz. Teen asal haalatein:
  ///  - verified → 'Tasdeeq Shuda ✓' (sabz)
  ///  - rejected → 'Reject ✗' (laal) + Master ki wajah wali numaya
  ///    patti + 'Dobara Bhejein' — sirf yehi document dobara jata
  ///    hai (upload flow se; status driver NAHI badalta)
  ///  - rejected lekin nayi photo bhej di gayi → 'Dobara bhej diya
  ///    gaya — Intezaar Mein…' (amber; pichli wajah chhoti line mein)
  ///  - warna → 'Intezaar Mein…' (amber)
  /// Photo hi baqi ho to bhi yehi row 'Kagaz Dein' se sirf wohi
  /// photo mangti hai.
  Widget _mereKagazRow({
    required String group,
    required String label,
    required List<(String, String)> kinds,
    required bool photoMissing,
  }) {
    final status = p.masterStatusFor(group);
    final reason = p.masterReasonFor(group);
    final resubmitted = p.docGroupResubmitted(group);
    final rejected = status == 'rejected' && !resubmitted;
    final (statusText, color, icon) = switch (status) {
      'verified' => ('Tasdeeq Shuda ✓', Brand.green, Icons.verified),
      'rejected' when resubmitted => (
          'Dobara bhej diya gaya — Intezaar Mein…',
          const Color(0xFFB8860B),
          Icons.hourglass_top
        ),
      'rejected' => ('Reject ✗', Brand.ajrakRed, Icons.cancel),
      _ => ('Intezaar Mein…', const Color(0xFFB8860B), Icons.pending_actions),
    };
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(label,
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
                Text(statusText,
                    style:
                        TextStyle(color: color, fontWeight: FontWeight.w800)),
              ],
            ),
            if (photoMissing && status != 'rejected') ...[
              const SizedBox(height: 6),
              const Text(
                'Photo abhi baqi hai — tasdeeq ke liye photo lazmi hai.',
                style: TextStyle(fontSize: 12.5, color: Brand.ajrakRed),
              ),
            ],
            if (rejected) ...[
              const SizedBox(height: 8),
              // Numaya wajah wali patti — Master ke alfaaz bilkul
              // waisay hi (verbatim) jo Master ne reject par likhe.
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFFDECEA),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Brand.ajrakRed),
                ),
                child: Text(
                  reason.isNotEmpty
                      ? 'Master ki wajah: $reason'
                      : 'Master ne ye document reject kiya hai (wajah nahi likhi gayi) — sahi kagaz dobara bhejein ya Master ko message karein.',
                  style: const TextStyle(
                      fontSize: 13,
                      color: Brand.ajrakRed,
                      fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () => _reuploadGroup(kinds),
                  icon: const Icon(Icons.upload_file, size: 19),
                  label: const Text('Dobara Bhejein'),
                ),
              ),
            ] else if (status == 'rejected' && resubmitted) ...[
              const SizedBox(height: 6),
              Text(
                'Nayi photo Master ke paas chali gayi hai — naya faisla baqi hai.${reason.isNotEmpty ? ' Pichli wajah: $reason' : ''}',
                style: const TextStyle(fontSize: 12.5, color: Colors.black54),
              ),
              const SizedBox(height: 6),
              Align(
                alignment: Alignment.centerRight,
                child: OutlinedButton(
                  onPressed: () => _reuploadGroup(kinds),
                  child: const Text('Ek aur photo bhejein'),
                ),
              ),
            ] else if (photoMissing) ...[
              const SizedBox(height: 6),
              Align(
                alignment: Alignment.centerRight,
                child: OutlinedButton(
                  onPressed: () => _reuploadGroup(kinds),
                  child: const Text('Kagaz Dein'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Dobara bhejne ke liye photo chunnna: group mein ek se zyada
  /// photo ho (CNIC samne/peeche, gaari/kaghaz) to pehle kaun si
  /// photo, phir camera/gallery — registration wala wohi pattern.
  /// Sirf chuni hui EK photo profile mein lagti hai; baqi documents
  /// bilkul nahi chharte.
  Future<void> _reuploadGroup(List<(String, String)> kinds) async {
    if (kinds.length == 1) {
      await _reuploadDoc(kinds.first.$1);
      return;
    }
    final picked = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(14),
              child: Text('Kaun si photo dobara bhejni hai?',
                  style: TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 15)),
            ),
            for (final k in kinds)
              ListTile(
                leading: const Icon(Icons.photo_camera, color: Brand.green),
                title: Text(k.$2),
                onTap: () => Navigator.pop(ctx, k.$1),
              ),
          ],
        ),
      ),
    );
    if (picked != null && mounted) await _reuploadDoc(picked);
  }

  /// SIRF ek document ki nayi photo bhejna (v1.4.1): photo profile
  /// ke usi ek field mein lagti hai, phir store.save() → 'profile'
  /// hook → Backend.syncDriverDocs SIRF is kind ko dobara upload
  /// karta hai (docUploaded marker usi ek ka badla hota hai) —
  /// Master ke paas nayi photo puhanchti hai aur woh dobara check
  /// karta hai. Is amal mein driver koi *_status NAHI likhta:
  /// backend status Master ke naye faisle tak waisa hi rehta hai
  /// (migration v130 ka resubmit-trigger use 'pending' par wapas
  /// le jata hai — database khud, driver nahi). Profile selfie
  /// hamesha camera se hi (live) hoti hai.
  Future<void> _reuploadDoc(String kind) async {
    ImageSource? src = kind == 'profile' ? ImageSource.camera : null;
    src ??= await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Brand.green),
              title: const Text('Camera se tasveer lein'),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Brand.green),
              title: const Text('Gallery se chunein'),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (src == null || !mounted) return;
    try {
      final img = await _picker.pickImage(source: src, imageQuality: 85);
      if (img == null) {
        if (mounted) {
          _snack(
              'Tasveer nahi li gayi — camera band ho gaya ya permission nahi mili. Dobara koshish karein.');
        }
        return;
      }
      switch (kind) {
        case 'cnic_front':
          p.cnicFrontPath = img.path;
        case 'cnic_back':
          p.cnicBackPath = img.path;
        case 'vehicle':
          p.vehiclePhotoPath = img.path;
        case 'vehicle_reg':
          p.vehicleRegPath = img.path;
        case 'licence':
          p.licencePhotoPath = img.path;
        case 'profile':
          p.profilePhotoPath = img.path;
      }
      await store.save();
      await store.markDocResubmitted(kind, img.path);
      if (mounted) {
        _snack('Dobara bhej diya gaya — Master dobara check karega.');
        setState(() {});
      }
    } catch (_) {
      if (mounted) _snack('Tasveer nahi li ja saki.');
    }
  }

}

/// Live waiting display for an arrived ride: minutes ticking + current charge.
class _LiveWaiting extends StatefulWidget {
  final Booking booking;
  final AppStore store;
  const _LiveWaiting({required this.booking, required this.store});

  @override
  State<_LiveWaiting> createState() => _LiveWaitingState();
}

class _LiveWaitingState extends State<_LiveWaiting> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final mins = widget.store.liveWaitingMinutes(b);
    final charge = widget.store.liveWaitingCharge(b);
    final freeLeft = Fares.freeWaitingMinutes - mins;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Brand.cream,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Brand.gold),
      ),
      child: Row(
        children: [
          const Icon(Icons.timer, color: Brand.ajrakRed),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Intezaar: $mins minute',
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 15)),
                Text(
                  freeLeft > 0
                      ? 'Abhi $freeLeft minute muft baqi hain'
                      : 'Waiting charges ab tak: ${rs(charge)}',
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
          if (charge > 0)
            Text(rs(charge),
                style:
                    const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Password dialogs (v1.2.5) — set / unlock / change.
// Teeno mein wohi usool: asal password sirf fingerprint banta hai;
// uniqueness backend se check hoti hai; check na ho sake (offline)
// to aage NAHI barhte.
// ---------------------------------------------------------------------------

/// Pehli dafa password SET karna (duty-on par, jab pwdFp khaali ho).
class _SetPasswordDialog extends StatefulWidget {
  final AppStore store;
  const _SetPasswordDialog({required this.store});

  @override
  State<_SetPasswordDialog> createState() => _SetPasswordDialogState();
}

class _SetPasswordDialogState extends State<_SetPasswordDialog> {
  final _c1 = TextEditingController();
  final _c2 = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _c1.dispose();
    _c2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final pw = _c1.text;
    if (pw.length < 6) {
      setState(() => _error = 'Password kam az kam 6 haroof ka ho.');
      return;
    }
    if (pw != _c2.text) {
      setState(() => _error = 'Dono password ek jaise nahi hain.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final fp = passwordFingerprint(pw);
    final taken =
        await Backend.passwordFingerprintTaken(widget.store, fp);
    if (!mounted) return;
    if (taken == null) {
      setState(() {
        _busy = false;
        _error =
            'Password ki safety check ke liye internet chahiye — net on karke dobara koshish karein.';
      });
      return;
    }
    if (taken) {
      _c1.clear();
      _c2.clear();
      setState(() {
        _busy = false;
        _error =
            'Ye password kisi aur ne lagaya hua hai, aap koi aur password lagayen';
      });
      return;
    }
    final p = widget.store.profile;
    p.pwdFp = fp;
    p.pwdFailCount = 0;
    p.pwdLockUntilMs = 0;
    await widget.store.save();
    widget.store.dutyUnlocked = true;
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Apna Password Lagayein'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
              'Duty shuru karne se pehle apna password lagayein. Ek password sirf ek hi driver ka hota hai — jo pehle lag jaye, wohi us ka ho jata hai.'),
          const SizedBox(height: 8),
          // HOTFIX v1.2.9 (RC3): qadam ki tartib pehle se saaf —
          // password pura hue baghair selfie wala qadam nahi ata,
          // aur driver samajhta tha selfie "khulti hi nahi".
          const Text(
            'Pehle apna password lagayein — us ke baad selfie wala qadam ayega.',
            style: TextStyle(
                fontWeight: FontWeight.w700, color: Brand.green),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _c1,
            obscureText: true,
            enabled: !_busy,
            decoration: const InputDecoration(
                labelText: 'Password (kam az kam 6 haroof)'),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _c2,
            obscureText: true,
            enabled: !_busy,
            decoration:
                const InputDecoration(labelText: 'Password dobara likhein'),
          ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!,
                style: const TextStyle(
                    color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(false),
          child: const Text('Rehne Dein'),
        ),
        ElevatedButton(
          onPressed: _busy ? null : _submit,
          child: Text(_busy ? 'Check ho raha hai…' : 'Password Lagayein'),
        ),
      ],
    );
  }
}

/// Duty unlock: set shuda password likhna. 5 ghalat = 10 minute lockout.
class _AskPasswordDialog extends StatefulWidget {
  final AppStore store;
  const _AskPasswordDialog({required this.store});

  @override
  State<_AskPasswordDialog> createState() => _AskPasswordDialogState();
}

class _AskPasswordDialogState extends State<_AskPasswordDialog> {
  final _c = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final p = widget.store.profile;
    if (passwordFingerprint(_c.text) == p.pwdFp) {
      p.pwdFailCount = 0;
      await widget.store.save();
      widget.store.dutyUnlocked = true;
      if (mounted) Navigator.of(context).pop(true);
      return;
    }
    p.pwdFailCount += 1;
    if (p.pwdFailCount >= 5) {
      // Lockout: ginati zero karke 10 minute ka taala — waqt khatm
      // hone par 5 nayi koshishen milengi.
      p.pwdFailCount = 0;
      p.pwdLockUntilMs =
          DateTime.now().millisecondsSinceEpoch + 10 * 60 * 1000;
      await widget.store.save();
      if (mounted) Navigator.of(context).pop(false);
      return;
    }
    await widget.store.save();
    if (!mounted) return;
    _c.clear();
    setState(() => _error =
        'Ghalat password — ${5 - p.pwdFailCount} koshishen baqi hain.');
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Password Likhein'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Duty shuru karne ke liye apna password likhein.'),
          const SizedBox(height: 12),
          TextField(
            controller: _c,
            obscureText: true,
            autofocus: true,
            decoration: const InputDecoration(labelText: 'Password'),
            onSubmitted: (_) => _submit(),
          ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!,
                style: const TextStyle(
                    color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: const Text('Rehne Dein'),
        ),
        ElevatedButton(
          onPressed: _submit,
          child: const Text('Duty Shuru Karein'),
        ),
      ],
    );
  }
}

/// Password badalna: pehle mojooda password ki tasdeeq, phir naya —
/// naye par wohi uniqueness check.
class _ChangePasswordDialog extends StatefulWidget {
  final AppStore store;
  const _ChangePasswordDialog({required this.store});

  @override
  State<_ChangePasswordDialog> createState() =>
      _ChangePasswordDialogState();
}

class _ChangePasswordDialogState extends State<_ChangePasswordDialog> {
  final _cur = TextEditingController();
  final _n1 = TextEditingController();
  final _n2 = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _cur.dispose();
    _n1.dispose();
    _n2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final p = widget.store.profile;
    if (passwordFingerprint(_cur.text) != p.pwdFp) {
      setState(() => _error = 'Mojooda password ghalat hai.');
      return;
    }
    final pw = _n1.text;
    if (pw.length < 6) {
      setState(() => _error = 'Naya password kam az kam 6 haroof ka ho.');
      return;
    }
    if (pw != _n2.text) {
      setState(() => _error = 'Dono naye password ek jaise nahi hain.');
      return;
    }
    final fp = passwordFingerprint(pw);
    if (fp == p.pwdFp) {
      setState(() =>
          _error = 'Ye aap ka mojooda password hi hai — koi aur lagayein.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final taken =
        await Backend.passwordFingerprintTaken(widget.store, fp);
    if (!mounted) return;
    if (taken == null) {
      setState(() {
        _busy = false;
        _error =
            'Password ki safety check ke liye internet chahiye — net on karke dobara koshish karein.';
      });
      return;
    }
    if (taken) {
      _n1.clear();
      _n2.clear();
      setState(() {
        _busy = false;
        _error =
            'Ye password kisi aur ne lagaya hua hai, aap koi aur password lagayen';
      });
      return;
    }
    p.pwdFp = fp;
    p.pwdFailCount = 0;
    p.pwdLockUntilMs = 0;
    await widget.store.save();
    if (mounted) Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Password Badlein'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _cur,
              obscureText: true,
              enabled: !_busy,
              decoration:
                  const InputDecoration(labelText: 'Mojooda password'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _n1,
              obscureText: true,
              enabled: !_busy,
              decoration: const InputDecoration(
                  labelText: 'Naya password (kam az kam 6 haroof)'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _n2,
              obscureText: true,
              enabled: !_busy,
              decoration: const InputDecoration(
                  labelText: 'Naya password dobara likhein'),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!,
                  style: const TextStyle(
                      color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(false),
          child: const Text('Rehne Dein'),
        ),
        ElevatedButton(
          onPressed: _busy ? null : _submit,
          child: Text(_busy ? 'Check ho raha hai…' : 'Password Badlein'),
        ),
      ],
    );
  }
}

