// v1.4.37 WAVE tests — DEPOSIT JAMA KARWAYEIN (malik ka hukm
// 2026-11-12; 15:43 tabdeeli): wallet mein wazeh bara button +
// steps wali sheet + Master ko khabar. Deposit ka rasta ab
// company ka BANK ACCOUNT (BankIslami, IBAN settings se) hai —
// deposit ki kisi hidayat mein MOBILE NUMBER nahi ana chahiye
// (FEE wala Raast tareeqa is hukm se bahir hai, woh barqarar)।
import 'package:flutter_test/flutter_test.dart';
import 'package:safar/lang.dart';
import 'package:safar/legal.dart';
import 'package:safar/store.dart';

const _depKeys = [
  'drv_dep_button',
  'drv_dep_title',
  'drv_dep_intro',
  'drv_dep_qr_title',
  'drv_dep_qr_note',
  'drv_dep_step1',
  'drv_dep_step2',
  'drv_dep_bank',
  'drv_dep_title_line',
  'drv_dep_iban_missing',
  'drv_dep_step3',
  'drv_dep_after',
  'drv_dep_own_number_note',
  'drv_dep_send_btn',
  'drv_dep_sending',
  'drv_dep_sent_ok',
  'drv_dep_queued',
  'drv_dep_failed',
  'drv_dep_msg_body',
];

void main() {
  group('v1.4.37 — Deposit: bank account, number NAHI', () {
    test('drv_dep keys dono zubaano mein maujood + number-free', () {
      for (final mode in ['ur', 'en']) {
        Lang.current = mode;
        for (final k in _depKeys) {
          final v = tr(k);
          expect(v, isNot(k), reason: '$k ($mode) lang mein missing hai');
          expect(v.trim(), isNotEmpty, reason: '$k ($mode) khali hai');
          expect(v.contains('0312'), isFalse,
              reason: '$k ($mode) mein mobile number NAHI ana chahiye');
        }
      }
      Lang.current = 'ur';
    });

    test('msg body IBAN ke saath render hoti hai — placeholder nahi rehta',
        () {
      Lang.current = 'ur';
      final s = trf('drv_dep_msg_body', {
        'name': 'Test Driver',
        'amount': '500',
        'iban': 'PK00TEST0001',
        'time': '12/11/2026 15:00',
      });
      expect(s.contains('PK00TEST0001'), isTrue);
      expect(s.contains('{iban}'), isFalse);
      expect(s.contains('BankIslami'), isTrue);
    });

    test('settings se IBAN/title lagta hai; khali sync purani value NAHI mitata',
        () {
      Fares.companyBankIban = '';
      Fares.companyBankTitle = '';
      Fares.applyServerSettings(bankIban: 'PK36ABCD', bankTitle: 'TITLE X');
      expect(Fares.companyBankIban, 'PK36ABCD');
      expect(Fares.companyBankTitle, 'TITLE X');
      Fares.applyServerSettings(bankIban: '', bankTitle: null);
      expect(Fares.companyBankIban, 'PK36ABCD',
          reason: 'khali/missing value par cached IBAN barqarar rahe');
      // Test ke baad global state saaf (doosre tests par asar na ho)।
      Fares.companyBankIban = '';
      Fares.companyBankTitle = '';
    });

    test('legal deposit paragraphs: BankIslami hai, number NAHI', () {
      final ur = kTermsDriver.expand((s) => s.lines).join('\n');
      final en = kTermsDriverEn.expand((s) => s.lines).join('\n');
      expect(ur.contains('BankIslami'), isTrue);
      expect(en.contains('BankIslami'), isTrue);
      expect(ur.contains('0312 2635002'), isFalse);
      expect(en.contains('0312 2635002'), isFalse);
    });

    test('wallet ki purani hidayat bhi bank surat par hai', () {
      for (final mode in ['ur', 'en']) {
        Lang.current = mode;
        final s = trf('drv_top_up_ki_hidayat', {'joiningDeposit': '500'});
        expect(s.contains('BankIslami'), isTrue, reason: '($mode)');
        expect(s.contains('0312'), isFalse, reason: '($mode)');
        expect(s.contains('{kFeeRaastNumber}'), isFalse, reason: '($mode)');
        final g = trf('drv_balance_khatam_rs_top', {'joiningDeposit': '500'});
        expect(g.contains('0312'), isFalse, reason: 'gate line ($mode)');
      }
      Lang.current = 'ur';
    });

    test('FEE ka Raast constant barqarar hai (scope se bahir)', () {
      expect(kFeeRaastNumber, '0312 2635002');
    });
  });
}
