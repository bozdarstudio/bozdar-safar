-- =====================================================================
-- Boz Safar — v1.4.57 · NEARBY ONLINE DRIVERS RPC
--   (nearby_online_drivers)
--
-- Sawari ki app booking / driver-dhoondhne ke marhale par apne
-- map par aas paas ke ONLINE drivers dekhna chahti hai — sirf
-- USI qisam ke jo us ne chuni hai (rickshaw ki booking par
-- sirf rickshaw, bike par sirf bike, waghera), taake use pata
-- chale ke aas paas gaariyan mojood hain aur ride kis ki taraf
-- ja rahi hai (malik ka hukm 2026-11-15)।
--
-- Ye RPC is liye lazmi hai ke drivers table ki seedhi parhai
-- Phase-4 flip ke baad har Auth user ke liye khuli NAHI hai
-- (har driver sirf apni row parh sakta hai) — nearest_driver_km
-- aur agent_driver_locations wala hi usool yahan bhi hai:
-- SECURITY DEFINER function andar sakht taala lagata hai:
--   * Sirf AUTHENTICATED session; warna khaali set।
--   * Sirf woh drivers jo: ID active + duty ONLINE + asal
--     GPS jagah mojood + jagah TAAZA (loc_at/updated_at pichhle
--     3 minute ke andar — app ke apne freshness usool par)।
--   * Sirf wohi qisam jo p_vehicle mein ayi (case ka farq
--     nahi) — doosri qisam ki gaari kabhi NAHI milti।
--   * Radius: p_radius_km (default 5 km — driver radius ki
--     zyada se zyada hadd), andar 0.5–25 km par bandha hua।
--   * Jawab mein SIRF: driver id, gaari ki qisam, lat/lng
--     aur loc_at। Naam, plate, mobile number, paisay ka koi
--     column is function mein HAI HI NAHI — sawari ko doosre
--     drivers ki zaati maloomat kabhi nahi milti (owner ka
--     data-access qanoon)।
--   * Sab se qareeb pehle; zyada se zyada 100 gaariyan।
--
-- ADDITIVE ONLY: sirf naya function — koi table/policy/data
-- change NAHI। Idempotent (CREATE OR REPLACE)।
--
-- Rollback: drop function public.nearby_online_drivers(
--   double precision, double precision, text, double precision);
-- =====================================================================

create or replace function public.nearby_online_drivers(
  p_lat       double precision,
  p_lng       double precision,
  p_vehicle   text,
  p_radius_km double precision default 5
)
returns table (
  driver_id text,
  vehicle   text,
  lat       double precision,
  lng       double precision,
  loc_at    timestamptz
)
language plpgsql security definer set search_path = public as $$
begin
  -- Tasdeeq ki shartein — fail ho to khaali set (return)।
  if auth.role() <> 'authenticated' or auth.uid() is null then
    return;
  end if;
  if p_lat is null or p_lng is null then
    return;
  end if;
  -- v1.4.57 (Part 8): p_vehicle NULL/khaali = TAMAM qisam
  -- (category cards ke ETA ke liye); warna sirf wohi qisam।

  return query
    select q.driver_id, q.vehicle, q.lat, q.lng, q.loc_at
      from (
        select d.id::text                          as driver_id,
               coalesce(d.vehicle, '')::text       as vehicle,
               d.lat                               as lat,
               d.lng                               as lng,
               coalesce(d.loc_at, d.updated_at)    as loc_at,
               6371 * acos(
                 least(1.0, greatest(-1.0,
                   cos(radians(p_lat)) * cos(radians(d.lat)) *
                     cos(radians(d.lng) - radians(p_lng)) +
                   sin(radians(p_lat)) * sin(radians(d.lat))
                 ))
               )                                   as dist_km
          from public.drivers d
         where coalesce(d.active, false)
           and coalesce(d.online, false)
           and d.lat is not null
           and d.lng is not null
           and (p_vehicle is null or btrim(p_vehicle) = ''
                or lower(coalesce(d.vehicle, '')) = lower(btrim(p_vehicle)))
           and coalesce(d.loc_at, d.updated_at)
               > now() - interval '3 minutes'
      ) q
     where q.dist_km <= greatest(0.5,
                        least(coalesce(p_radius_km, 5), 25))
     order by q.dist_km asc
     limit 100;
end $$;

revoke execute on function public.nearby_online_drivers(
  double precision, double precision, text, double precision)
  from public;
grant execute on function public.nearby_online_drivers(
  double precision, double precision, text, double precision)
  to authenticated;
