import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Ek OSRM maneuver — driver guidance banner isi se banta hai.
class RouteStep {
  /// Roman Urdu hidayat, bina doori ke (masalan
  /// "Daayein murein — M.A. Jinnah Road par").
  final String instruction;
  final String road;

  /// Route ke shuru se is maneuver tak ki doori (meters).
  final double alongM;
  final LatLng at;
  final bool isArrive;

  const RouteStep({
    required this.instruction,
    required this.road,
    required this.alongM,
    required this.at,
    this.isArrive = false,
  });

  Map<String, dynamic> toJson() => {
        'i': instruction,
        'r': road,
        'a': alongM,
        'lat': at.latitude,
        'lng': at.longitude,
        'arr': isArrive,
      };

  factory RouteStep.fromJson(Map<String, dynamic> j) => RouteStep(
        instruction: j['i'] as String,
        road: j['r'] as String? ?? '',
        alongM: (j['a'] as num).toDouble(),
        at: LatLng((j['lat'] as num).toDouble(), (j['lng'] as num).toDouble()),
        isArrive: j['arr'] as bool? ?? false,
      );
}

/// Route ki geometry par aage barhne ka hisaab (snapping + progress).
class RouteTrack {
  final List<LatLng> points;
  late final List<double> cumM;
  late final double totalM;

  RouteTrack(this.points) {
    cumM = List<double>.filled(points.length, 0);
    var acc = 0.0;
    for (var i = 1; i < points.length; i++) {
      acc += const Distance().as(LengthUnit.Meter, points[i - 1], points[i]);
      cumM[i] = acc;
    }
    totalM = acc;
  }

  double bearingBetween(LatLng a, LatLng b) {
    final lat1 = a.latitude * math.pi / 180;
    final lat2 = b.latitude * math.pi / 180;
    final dLng = (b.longitude - a.longitude) * math.pi / 180;
    final y = math.sin(dLng) * math.cos(lat2);
    final x = math.cos(lat1) * math.sin(lat2) -
        math.sin(lat1) * math.cos(lat2) * math.cos(dLng);
    return (math.atan2(y, x) * 180 / math.pi + 360) % 360;
  }

  /// [pos] ko route par sab se qareebi jagah par snap karke progress.
  ({LatLng snapped, double alongM, double bearingDeg}) progressAt(LatLng pos) {
    if (points.isEmpty) {
      return (snapped: pos, alongM: 0, bearingDeg: 0);
    }
    if (points.length == 1) {
      return (snapped: points.first, alongM: 0, bearingDeg: 0);
    }
    final cosLat = math.cos(pos.latitude * math.pi / 180);
    double px(LatLng p) => p.longitude * cosLat;
    double py(LatLng p) => p.latitude;
    var bestDist = double.infinity;
    var bestAlong = 0.0;
    var bestPoint = points.first;
    var bestBearing = 0.0;
    for (var i = 0; i < points.length - 1; i++) {
      final a = points[i];
      final b = points[i + 1];
      final ax = px(a), ay = py(a), bx = px(b), by = py(b);
      final dx = bx - ax, dy = by - ay;
      final len2 = dx * dx + dy * dy;
      var t = len2 == 0
          ? 0.0
          : ((px(pos) - ax) * dx + (py(pos) - ay) * dy) / len2;
      t = t.clamp(0.0, 1.0);
      final sx = ax + dx * t, sy = ay + dy * t;
      final ddx = px(pos) - sx, ddy = py(pos) - sy;
      final d2 = ddx * ddx + ddy * ddy;
      if (d2 < bestDist) {
        bestDist = d2;
        final segLen = cumM[i + 1] - cumM[i];
        bestAlong = cumM[i] + segLen * t;
        bestPoint = LatLng(sy, cosLat == 0 ? sx : sx / cosLat);
        bestBearing = bearingBetween(a, b);
      }
    }
    return (snapped: bestPoint, alongM: bestAlong, bearingDeg: bestBearing);
  }
}

/// Ek mukammal route: asal sadak ki line + guidance steps.
/// [steps] khaali ho to ye sirf seedhi line hai (offline pehla istemal) —
/// guidance banner is par khaas offline jumla dikhata hai.
class RouteResult {
  final List<LatLng> points;
  final double distanceM;
  final double durationS;
  final List<RouteStep> steps;
  late final RouteTrack track = RouteTrack(points);

  RouteResult({
    required this.points,
    required this.distanceM,
    required this.durationS,
    required this.steps,
  });

  bool get hasSteps => steps.length > 1;

  Map<String, dynamic> toJson() => {
        'pts': points.map((p) => [p.latitude, p.longitude]).toList(),
        'd': distanceM,
        't': durationS,
        'steps': steps.map((s) => s.toJson()).toList(),
      };

  factory RouteResult.fromJson(Map<String, dynamic> j) => RouteResult(
        points: (j['pts'] as List)
            .map((e) => LatLng((e[0] as num).toDouble(), (e[1] as num).toDouble()))
            .toList(),
        distanceM: (j['d'] as num).toDouble(),
        durationS: (j['t'] as num).toDouble(),
        steps: ((j['steps'] as List?) ?? [])
            .map((e) => RouteStep.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

/// "500 m" / "1.2 km" type saaf doori.
String fmtDist(double m) {
  if (m < 950) return '${(m / 10).round() * 10} m';
  return '${(m / 1000).toStringAsFixed(1)} km';
}

/// OSRM (muft, bina API key) se asal sadak ka route + steps/maneuvers.
/// Kamzor net ke liye: har route memory + SharedPreferences mein cache
/// hota hai — ek dafa bana hua route offline bhi line + steps ke saath
/// wapas mil jata hai. Network na mile aur cache bhi na ho to seedhi
/// line (bina steps) wapas hoti hai — jhooti position ya jhoota rasta
/// kabhi nahi banaya jata.
class RouteService {
  static final Map<String, RouteResult> _mem = {};

  static String _key(LatLng a, LatLng b) =>
      'route_v1_${a.latitude.toStringAsFixed(3)},${a.longitude.toStringAsFixed(3)}'
      '|${b.latitude.toStringAsFixed(3)},${b.longitude.toStringAsFixed(3)}';

  static RouteResult straight(LatLng from, LatLng to) {
    final d = const Distance().as(LengthUnit.Meter, from, to);
    return RouteResult(
      points: [from, to],
      distanceM: d,
      durationS: 0,
      steps: const [],
    );
  }

  static Future<RouteResult> fetch(LatLng from, LatLng to,
      {bool forceNetwork = false}) async {
    final key = _key(from, to);
    if (!forceNetwork) {
      final hit = _mem[key];
      if (hit != null) return hit;
      try {
        final prefs = await SharedPreferences.getInstance();
        final raw = prefs.getString(key);
        if (raw != null) {
          final r =
              RouteResult.fromJson(jsonDecode(raw) as Map<String, dynamic>);
          _mem[key] = r;
          return r;
        }
      } catch (_) {
        // cache kharab ho to network ki taraf barhein
      }
    }
    try {
      final r = await _fetchOsrm(from, to);
      _mem[key] = r;
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(key, jsonEncode(r.toJson()));
      } catch (_) {}
      return r;
    } catch (_) {
      final cached = _mem[key];
      if (cached != null) return cached;
      return straight(from, to);
    }
  }

  static Future<RouteResult> _fetchOsrm(LatLng from, LatLng to) async {
    final uri = Uri.parse(
        'https://router.project-osrm.org/route/v1/driving/'
        '${from.longitude},${from.latitude};${to.longitude},${to.latitude}'
        '?overview=full&geometries=geojson&steps=true&continue_straight=true');
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    try {
      final req = await client.getUrl(uri);
      req.headers.set(HttpHeaders.userAgentHeader, 'SafarApp/1.2 (com.bozdar.safar)');
      final resp = await req.close().timeout(const Duration(seconds: 10));
      if (resp.statusCode != 200) {
        throw HttpException('OSRM ${resp.statusCode}');
      }
      final body = await resp.transform(utf8.decoder).join();
      final root = jsonDecode(body) as Map<String, dynamic>;
      final routes = root['routes'] as List?;
      if (routes == null || routes.isEmpty) {
        throw const HttpException('OSRM: no route');
      }
      final route = routes.first as Map<String, dynamic>;
      final coords =
          ((route['geometry'] as Map<String, dynamic>)['coordinates'] as List)
              .map((e) => LatLng((e[1] as num).toDouble(), (e[0] as num).toDouble()))
              .toList();
      final steps = <RouteStep>[];
      final legs = route['legs'] as List?;
      if (legs != null && legs.isNotEmpty) {
        final rawSteps =
            (legs.first as Map<String, dynamic>)['steps'] as List? ?? [];
        var along = 0.0;
        for (final s in rawSteps) {
          final st = s as Map<String, dynamic>;
          final man = (st['maneuver'] as Map<String, dynamic>?) ?? {};
          final loc = man['location'] as List?;
          final at = loc != null
              ? LatLng((loc[1] as num).toDouble(), (loc[0] as num).toDouble())
              : (coords.isNotEmpty ? coords.first : from);
          final type = man['type'] as String? ?? '';
          steps.add(RouteStep(
            instruction: _instruction(
              type: type,
              modifier: man['modifier'] as String?,
              exit: (man['exit'] as num?)?.toInt(),
              name: st['name'] as String? ?? '',
            ),
            road: st['name'] as String? ?? '',
            alongM: along,
            at: at,
            isArrive: type == 'arrive',
          ));
          along += (st['distance'] as num? ?? 0).toDouble();
        }
      }
      return RouteResult(
        points: coords,
        distanceM: (route['distance'] as num).toDouble(),
        durationS: (route['duration'] as num).toDouble(),
        steps: steps,
      );
    } finally {
      client.close(force: true);
    }
  }

  /// OSRM maneuver → Roman Urdu hidayat (Google Maps walay andaaz mein).
  static String _instruction({
    required String type,
    String? modifier,
    int? exit,
    required String name,
  }) {
    final road = name.trim();
    final roadPart = road.isEmpty ? '' : ' — $road par';
    final m = modifier ?? '';
    String turn(String side) =>
        (side == 'left' ? 'Baayein murein' : 'Daayein murein') + roadPart;
    switch (type) {
      case 'depart':
        return 'Chalna shuru karein';
      case 'arrive':
        return 'Manzil aa gayi';
      case 'turn':
        switch (m) {
          case 'left':
            return turn('left');
          case 'right':
            return turn('right');
          case 'slight left':
            return 'Halki baayein murein$roadPart';
          case 'slight right':
            return 'Halki daayein murein$roadPart';
          case 'sharp left':
            return 'Tez baayein murein$roadPart';
          case 'sharp right':
            return 'Tez daayein murein$roadPart';
          case 'uturn':
            return 'U-turn lein$roadPart';
          default:
            return 'Seedha chalein$roadPart';
        }
      case 'new name':
      case 'continue':
        return 'Seedha chalein$roadPart';
      case 'merge':
        return 'Traffic mein shamil ho jayein$roadPart';
      case 'on ramp':
        return 'Ramp par chalein$roadPart';
      case 'off ramp':
        return m.contains('left')
            ? 'Ramp se baayein utrein$roadPart'
            : 'Ramp se daayein utrein$roadPart';
      case 'fork':
        return m.contains('left')
            ? 'Kaante par baayein rakhen$roadPart'
            : m.contains('right')
                ? 'Kaante par daayein rakhen$roadPart'
                : 'Seedha rakhen$roadPart';
      case 'end of road':
        return m.contains('left')
            ? 'Road ke aakhir par baayein murein$roadPart'
            : m.contains('right')
                ? 'Road ke aakhir par daayein murein$roadPart'
                : 'Road khatm ho rahi hai$roadPart';
      case 'roundabout':
      case 'rotary':
      case 'roundabout turn':
        const ord = ['', 'pehli', 'doosri', 'teesri', 'chauthi', 'panchwi'];
        final n = exit ?? 1;
        final word = n >= 1 && n < ord.length ? ord[n] : '$n wi';
        return 'Gol chowrangi se $word nikasi lein$roadPart';
      case 'exit roundabout':
      case 'exit rotary':
        return 'Gol chowrangi se bahar niklein$roadPart';
      default:
        return 'Seedha chalein$roadPart';
    }
  }
}
