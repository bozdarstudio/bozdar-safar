// =====================================================================
// place_search.dart — ASAL JAGAH SEARCH (GEOCODING)
// v1.4.29 izafa (owner hukm 2026-11-11 15:51 — SAB SE ZAROORI):
// booking mein naam type karne par asal jagahon ke naam ayen aur
// chunne par app usi jagah par jaye। Pehle geocoding tha hi nahi
// (sirf pin chalta tha) — ab dono raste hain: SEARCH + PIN।
//
// SERVICE: Nominatim (OpenStreetMap) — muft, bina API key ke।
//  - countrycodes=pk: sirf Pakistan (saare sheher — Karachi tak
//    mehdood NAHI); sheher ka naam har result ke label mein saaf
//    dikhta hai taake ek hi naam ki do sheheron wali jagahen
//    alag pehchani jayen।
//  - viewbox bias (bounded=0): maujooda jagah/sheher ke aas paas
//    ke results ko TARJEEH milti hai, pabandi NAHI lagti।
//  - Debounce UI taraf hai (passenger.dart, 400ms); yahan har
//    call ek hi request hai। Timeout 8s (route_service jaisa)।
//  - Service down/ khata aye to [PlaceSearchException] — UI saaf
//    paighaam deti hai; JAALI suggestion kabhi NAHI banti (yahan
//    koi hardcoded/fake result NAHI hai)।
// =====================================================================

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:latlong2/latlong.dart' as ll2;

/// Ek search result — asal jagah।
class PlaceResult {
  /// Chhota asal naam (masalan "Mazar-e-Quaid")।
  final String name;

  /// Saaf pehchan wala label: naam + sheher (+ sooba jab
  /// zaroorat ho) — masalan "Mazar-e-Quaid, Karachi"। Yehi
  /// label field mein aur booking ke label mein jata hai
  /// (search se chunne par "Map Pin Wali Jagah" NAHI ata)।
  final String label;

  /// Poora Nominatim display_name (subtitle/ tafseel ke liye)।
  final String displayName;

  final ll2.LatLng point;

  const PlaceResult({
    required this.name,
    required this.label,
    required this.displayName,
    required this.point,
  });

  /// Nominatim ke ek JSON item se result banao (unit-test
  /// honay wala hissa)।
  factory PlaceResult.fromNominatimJson(Map<String, dynamic> j) {
    final display = (j['display_name'] ?? '').toString();
    var name = (j['name'] ?? '').toString().trim();
    if (name.isEmpty && display.isNotEmpty) {
      name = display.split(',').first.trim();
    }
    final addr = (j['address'] as Map?) ?? const {};
    String pick(List<String> keys) {
      for (final k in keys) {
        final v = (addr[k] ?? '').toString().trim();
        if (v.isNotEmpty) return v;
      }
      return '';
    }

    final city = pick(['city', 'town', 'village', 'county']);
    final state = pick(['state']);
    // Label: naam, sheher (naam se mukhtalif ho to), aur jab
    // sheher na mile to sooba — taake do sheheron ki ek-naam
    // jagahen alag dikhen।
    final parts = <String>[name];
    if (city.isNotEmpty && city != name) parts.add(city);
    if (city.isEmpty && state.isNotEmpty && state != name) {
      parts.add(state);
    }
    return PlaceResult(
      name: name,
      label: parts.join(', '),
      displayName: display,
      point: ll2.LatLng(
        double.tryParse('${j['lat']}') ?? 0,
        double.tryParse('${j['lon']}') ?? 0,
      ),
    );
  }
}

/// Search na ho sakne ki khata — UI is par saaf paighaam
/// dikhati hai (jaali result NAHI)।
class PlaceSearchException implements Exception {
  final String message;
  const PlaceSearchException(this.message);
  @override
  String toString() => 'PlaceSearchException: $message';
}

class PlaceSearch {
  static const String _host = 'nominatim.openstreetmap.org';

  /// Request ka URI — test honay wala hissa।
  /// [near] diya jaye to viewbox us ke gird banta hai (bias,
  /// bounded=0 — tarjeeh sirf, pabandi nahi)।
  static Uri buildUri(String query, {ll2.LatLng? near}) {
    final params = <String, String>{
      'format': 'jsonv2',
      'limit': '8',
      'countrycodes': 'pk',
      'addressdetails': '1',
      'q': query,
    };
    if (near != null) {
      // ~55 km ka viewbox — aas paas ke results pehle ayenge,
      // lekin bounded=0 ki wajah se poora Pakistan phir bhi
      // search hota hai (owner ki shart: sirf Karachi NAHI)।
      const d = 0.5;
      params['viewbox'] =
          '${near.longitude - d},${near.latitude + d},${near.longitude + d},${near.latitude - d}';
      params['bounded'] = '0';
    }
    return Uri.https(_host, '/search', params);
  }

  /// JSON jawaab ko results mein badlo — test honay wala hissa।
  static List<PlaceResult> parseResults(String body) {
    final decoded = jsonDecode(body);
    if (decoded is! List) return const [];
    final out = <PlaceResult>[];
    for (final e in decoded) {
      if (e is Map<String, dynamic>) {
        final r = PlaceResult.fromNominatimJson(e);
        if (r.point.latitude != 0 && r.name.isNotEmpty) out.add(r);
      }
    }
    return out;
  }

  /// v1.4.42: results ko [near] (maujooda pickup) se doori
  /// ke hisaab se QAREEB pehle ki tartib mein lago — Nominatim
  /// apni tartib deta hai jis mein ek hi naam ki door wali
  /// jagah (doosra sheher/ilaqa) pehle aa sakti hai aur sawari
  /// ghalti se usi ko chun leta tha (malik ki live shikayat
  /// 2026-11-13: likhi jagah aur pin wali jagah alag nikli)।
  /// Asal list NAHI badalti — nayi tartib wali copy wapas
  /// hoti hai (unit-test honay wala hissa)।
  static List<PlaceResult> sortByDistance(
      List<PlaceResult> results, ll2.LatLng near) {
    const dist = ll2.Distance();
    final sorted = List<PlaceResult>.of(results);
    sorted.sort((a, b) => dist
        .as(ll2.LengthUnit.Meter, near, a.point)
        .compareTo(dist.as(ll2.LengthUnit.Meter, near, b.point)));
    return sorted;
  }

  /// Ek result ki [near] se andazan doori ka saaf label —
  /// masalan "≈ 850 m" ya "≈ 11 km" (results list mein har
  /// row ke saath dikhta hai, taake chunne se PEHLE pata ho
  /// jagah kitni door hai)।
  static String distanceLabel(ll2.LatLng near, ll2.LatLng point) {
    const dist = ll2.Distance();
    final km = dist.as(ll2.LengthUnit.Kilometer, near, point);
    if (km < 1) return '≈ ${(km * 1000).round()} m';
    if (km < 10) return '≈ ${km.toStringAsFixed(1)} km';
    return '≈ ${km.round()} km';
  }

  /// Aam ghalat-spelling ki durust shakalain — Karachi/Pakistan
  /// ke ilaqon ke naam aksar mukhtalif Roman spelling se likhe
  /// jate hain (masla malik ne live pakra 2026-11-12: "munawar
  /// chirangi" par 0 results, "Munawar Chowrangi" par jagah mil
  /// gayi — Nominatim spelling ki ghalti bilkul bardasht NAHI
  /// karta)। Har lafz ki pehchani hui ghalat shaklon ko asal
  /// shakal se badal kar ek aur koshish banti hai।
  static const Map<String, String> _spellingFixes = {
    'chirangi': 'chowrangi',
    'chrangi': 'chowrangi',
    'chorangi': 'chowrangi',
    'chaurangi': 'chowrangi',
    'chok': 'chowk',
    'chuk': 'chowk',
    'chouk': 'chowk',
    'markit': 'market',
    'airpot': 'airport',
  };

  /// Search ki koshishon ki tartib (test honay wala hissa):
  /// pehle jaisa likha waisa, phir aam-ghaltiyon wali durust
  /// shakal, phir Levenshtein se theek ki hui shakal — dohrao
  /// nahi, zyada se zyada 3 shaklain।
  static List<String> queryVariants(String query) {
    final q = query.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (q.isEmpty) return const [];
    final out = <String>[q];
    final fixed = q
        .split(' ')
        .map((w) => _spellingFixes[w.toLowerCase()] ?? w)
        .join(' ');
    if (fixed.toLowerCase() != q.toLowerCase()) out.add(fixed);
    final corrected = correctQuery(q);
    if (corrected != null &&
        !out.any((v) => v.toLowerCase() == corrected.toLowerCase())) {
      out.add(corrected);
    }
    return out;
  }

  /// Aam jagah-wale lafz — sirf in ki spelling Levenshtein se
  /// theek ki jati hai (distance ≤ 2, ek hi qareeb tareen lafz
  /// ho to; do barabar qareeb hon to ambiguous — chhedo nahi)।
  /// "chowrangi" sab se aham: malik ne "chirangi" likh kar bug
  /// pakda tha (chirangi→chowrangi distance 2, chorangi→1)।
  /// Ghair-mutalliq lafz kabhi NAHI badalta (munawar→chowrangi
  /// distance 8 hai)।
  static const _knownWords = <String>{
    'chowrangi', 'bazaar', 'masjid', 'road', 'chowk', 'park',
    'hospital', 'school', 'college', 'university', 'colony', 'town',
    'nagar', 'abad', 'goth', 'market', 'ground', 'stadium', 'gate',
    'bridge', 'underpass', 'flyover', 'society', 'block', 'sector',
    'phase', 'scheme', 'garden', 'station', 'stop', 'mor', 'pul',
    'museum', 'library', 'hall', 'plaza', 'tower', 'karachi',
    'lahore', 'islamabad', 'rawalpindi', 'hyderabad', 'multan',
    'faisalabad', 'peshawar', 'quetta',
  };

  static int _levenshtein(String a, String b) {
    if (a == b) return 0;
    final prev = List<int>.generate(b.length + 1, (j) => j);
    final cur = List<int>.filled(b.length + 1, 0);
    for (var i = 1; i <= a.length; i++) {
      cur[0] = i;
      for (var j = 1; j <= b.length; j++) {
        final sub = prev[j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1);
        var best = prev[j] + 1;
        if (cur[j - 1] + 1 < best) best = cur[j - 1] + 1;
        if (sub < best) best = sub;
        cur[j] = best;
      }
      prev.setAll(0, cur);
    }
    return prev[b.length];
  }

  /// Ghalat-spelling query ko theek karo; kuch theek na ho to
  /// null। Sirf fallback ke liye — asal search hamesha pehle
  /// hoti hai, sahi spelling kabhi NAHI badalti।
  static String? correctQuery(String query) {
    var changed = false;
    final out = query.trim().split(RegExp(r'\s+')).map((token) {
      final lower = token.toLowerCase();
      if (lower.length < 4 || _knownWords.contains(lower)) return token;
      String? best;
      var bestDist = 3; // sirf distance 1 ya 2 qabool
      for (final w in _knownWords) {
        if ((w.length - lower.length).abs() > 2) continue;
        final d = _levenshtein(lower, w);
        if (d < bestDist) {
          bestDist = d;
          best = w;
        } else if (d == bestDist) {
          best = null; // do lafz barabar qareeb — ambiguous
        }
      }
      if (best != null) {
        changed = true;
        return best;
      }
      return token;
    }).join(' ');
    return changed ? out : null;
  }

  /// Asal network search। Khata par [PlaceSearchException]।
  /// Pehli shakal par khaali jawaab aye to spelling-durust
  /// shakal se, aur phir viewbox-bias ke baghair (poora Pakistan)
  /// dobara koshish hoti hai — pehle ghair-khaali jawaab par
  /// ruk jati hai। Jaali result kabhi NAHI banta — har jawaab
  /// asal Nominatim ka hai।
  static Future<List<PlaceResult>> search(
    String query, {
    ll2.LatLng? near,
  }) async {
    final q = query.trim();
    if (q.length < 3) return const [];
    Object? firstError;
    final biases = near != null ? [near, null] : [null];
    for (final variant in queryVariants(q)) {
      for (final bias in biases) {
        try {
          final results = await _searchOnce(variant, near: bias);
          if (results.isNotEmpty) return results;
        } catch (e) {
          firstError ??= e;
        }
      }
    }
    if (firstError != null) throw firstError;
    return const [];
  }

  /// Ek hi asal Nominatim request (buildUri/parseResults wali)।
  static Future<List<PlaceResult>> _searchOnce(
    String query, {
    ll2.LatLng? near,
  }) async {
    final q = query.trim();
    if (q.length < 3) return const [];
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    try {
      final req =
          await client.getUrl(buildUri(q, near: near)).timeout(
                const Duration(seconds: 8),
              );
      // Nominatim ki policy: pehchan wala User-Agent lazmi।
      req.headers.set(HttpHeaders.userAgentHeader,
          'BozdarSafarApp/1.4.29 (ride booking place search)');
      final res = await req.close().timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) {
        throw PlaceSearchException('HTTP ${res.statusCode}');
      }
      final body = await res.transform(utf8.decoder).join();
      return parseResults(body);
    } on PlaceSearchException {
      rethrow;
    } catch (e) {
      throw PlaceSearchException('$e');
    } finally {
      client.close(force: true);
    }
  }
}
