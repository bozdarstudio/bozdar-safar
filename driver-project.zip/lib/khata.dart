import 'package:flutter/material.dart';

import 'store.dart';
import 'theme.dart';

/// MERA KHATA + SAWARI TAFSEEL (v1.4.87 — malik ka hukm 2026-11-28):
/// Driver ko apni poori sorat-e-haal EK jagah saaf nazar aye —
/// kamai ka hisaab, kagzaat ki Master-tasdeeq ki haalat, aur har
/// mukammal sawari ki payment tafseel. Ye Boz Safar ka APNA
/// tarteeb-o-andaz hai: na kisi doosri app ki naqal, na un ke
/// alfaaz. Tamam data asal store se ata hai — jaali khana kabhi
/// NAHI banta; jo cheez maujood nahi woh khaali dikhti hai.

String _rs(int v) => 'Rs ${v.toString()}';

String _dateLine(DateTime? d) {
  if (d == null) return '';
  final dd = d.day.toString().padLeft(2, '0');
  final mm = d.month.toString().padLeft(2, '0');
  var h = d.hour % 12;
  if (h == 0) h = 12;
  final ap = d.hour >= 12 ? 'PM' : 'AM';
  final min = d.minute.toString().padLeft(2, '0');
  return '$dd/$mm/${d.year} • $h:$min $ap';
}

Widget _statusChip(String raw) {
  final s = raw.trim().toLowerCase();
  late final Color c;
  late final String t;
  if (s == 'approved' || s == 'verified' || s == 'active') {
    c = Brand.green;
    t = 'Manzoor';
  } else if (s == 'rejected' || s == 'failed') {
    c = Brand.ajrakRed;
    t = 'Rad — dobara bhejein';
  } else if (s.isEmpty) {
    c = Colors.grey;
    t = '—';
  } else {
    c = Colors.orange.shade800;
    t = 'Intezar mein';
  }
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(
      color: c.withOpacity(0.12),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: c),
    ),
    child: Text(t,
        style: TextStyle(color: c, fontWeight: FontWeight.w700, fontSize: 12)),
  );
}

class MeraKhataPage extends StatelessWidget {
  final AppStore store;
  const MeraKhataPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final p = store.profile;
    final now = DateTime.now();
    final today = store.earningsBetween(
        DateTime(now.year, now.month, now.day),
        DateTime(now.year, now.month, now.day, 23, 59, 59));
    final month = store.earningsThisMonth();
    final all = store.earningsBetween(
        DateTime(2000, 1, 1), now.add(const Duration(days: 1)));
    final docs = <(String, String)>[
      ('CNIC', p.masterCnicStatus),
      ('Driving Licence', p.masterLicenceStatus),
      ('Gaari ke Kagzaat', p.masterGaariStatus),
      ('PTA Tasdeeq', p.masterPtaStatus),
      ('Fitness Certificate', p.masterFitnessStatus),
      ('Insurance', p.masterInsuranceStatus),
      ('Character Certificate', p.masterCharacterStatus),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Mera Khata')),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          Card(
            color: p.masterActive ? Brand.deepGreen : null,
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Brand.gold,
                child: Text(
                  p.name.trim().isEmpty ? 'B' : p.name.trim()[0].toUpperCase(),
                  style: const TextStyle(
                      fontWeight: FontWeight.w900, color: Colors.black87),
                ),
              ),
              title: Text(p.name,
                  style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 17,
                      color: p.masterActive ? Colors.white : null)),
              subtitle: Text(
                '${p.vehicle}${p.plate.trim().isEmpty ? '' : ' • ${p.plate}'}'
                '\n${p.masterActive ? 'Account Active hai' : 'Account Master ki tasdeeq ke intezar mein hai'}',
                style: TextStyle(color: p.masterActive ? Colors.white70 : null),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _statCard('Aaj ki Sawariyan', '${today.rides}'),
              _statCard('Aaj ki Kamai', _rs(today.net)),
              _statCard('Is Mahine', _rs(month.net)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _statCard('Kul Sawariyan', '${all.rides}'),
              _statCard('Kul Kamai', _rs(all.net)),
              _statCard('Amanat Balance', _rs(store.amanatBalance)),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Mere Kagzaat — Master Tasdeeq',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Card(
            child: Column(
              children: [
                for (final d in docs)
                  ListTile(
                    dense: true,
                    title: Text(d.$1,
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                    trailing: d.$1 == 'Driving Licence' &&
                            p.licenceStatus == 'none'
                        ? const Text('Licence nahi hai',
                            style: TextStyle(
                                color: Colors.grey,
                                fontWeight: FontWeight.w600,
                                fontSize: 12))
                        : _statusChip(d.$2),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: ListTile(
              leading: const Icon(Icons.receipt_long, color: Brand.green),
              title: const Text('Sawariyon ki Tafseel',
                  style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle:
                  const Text('Har sawari ka kiraya, company hissa aur aap ki kamai'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => SawariTafseelPage(store: store)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statCard(String label, String value) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
          child: Column(
            children: [
              Text(value,
                  style: const TextStyle(
                      fontWeight: FontWeight.w900, fontSize: 15)),
              const SizedBox(height: 4),
              Text(label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 11, color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}

class SawariTafseelPage extends StatelessWidget {
  final AppStore store;
  const SawariTafseelPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final rides = store.bookings
        .where((b) =>
            b.acceptedHere && b.status == 'completed' && !b.isTestRide)
        .toList()
      ..sort((a, b) => (b.completedAt ?? b.createdAt)
          .compareTo(a.completedAt ?? a.createdAt));
    return Scaffold(
      appBar: AppBar(title: const Text('Sawariyon ki Tafseel')),
      body: rides.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text('Abhi koi mukammal sawari nahi hai.',
                    style: TextStyle(color: Colors.grey, fontSize: 15)),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: rides.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                final b = rides[i];
                final fee = b.effectiveFeeRs;
                final net = b.total - fee;
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(_dateLine(b.completedAt ?? b.createdAt),
                                style: const TextStyle(
                                    fontWeight: FontWeight.w700, fontSize: 13)),
                            Text('${b.distanceKm.toStringAsFixed(1)} km',
                                style: const TextStyle(
                                    color: Colors.grey, fontSize: 12)),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text('📍 ${b.pickupLabel}',
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        Text('🏁 ${b.dropLabel}',
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        const Divider(height: 16),
                        _line('Kul kiraya', _rs(b.total)),
                        _line('Company hissa (10%)', '− ${_rs(fee)}'),
                        _line('Aap ki kamai', _rs(net), bold: true),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  Widget _line(String k, String v, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(k,
              style: TextStyle(
                  fontWeight: bold ? FontWeight.w800 : FontWeight.w500)),
          Text(v,
              style: TextStyle(
                  fontWeight: bold ? FontWeight.w900 : FontWeight.w600,
                  color: bold ? Brand.green : null)),
        ],
      ),
    );
  }
}
