// =====================================================================
// permissions.dart — v1.4.78 IN-APP PERMISSIONS NIZAM (malik ka
// hukm 2026-11-24): Boz ne Android ki App permissions screen ki
// tasveer bhej kar kaha ke ye ikhtiyarat app ke ANDAR bhi hon —
// "iske baghair app open nahi hogi". Matlab: driver ko ijazaton
// ke liye phone ki Settings ke chakkar na katne paren; app ke
// andar ek saaf screen ho jo har ijazat ki haalat dikhaye, wajah
// bataye aur wahin se system dialog khol kar ijazat mangwaye।
//
// IJAZATEIN SIRF KAAM KI CHAAR (screenshot wali fehrist se):
//   1. Location (foreground) — LAZMI: online/ride/navigation.
//      Geolocator hi canonical API hai (poori app yehi istemal
//      karti hai) — haalat bhi usi se, darkhwast bhi usi se।
//   2. Location "Har Waqt" (background) — LAZMI fehrist mein,
//      lekin Android ka usool: ye runtime dialog se NAHI milti,
//      sirf Settings se milti hai. Screen wajah + rehnumai +
//      Settings tak ka button deti hai. Duty asal mein
//      foreground service (location type) se chalti hai, is
//      liye is par KOI NAYA GATE NAHI lagaya gaya — jo driver
//      sirf "istemal ke doran" wali ijazat par hai woh pehle
//      ki tarah online ho sakta hai।
//   3. Notifications — LAZMI ke qareeb: nayi ride ki ghanti
//      isi se ati hai (Android 13+ par runtime ijazat)।
//   4. Camera — istemal ke waqt LAZMI: live selfie + kaghazat
//      ki tasaveer (image_picker istemal par khud bhi mangta
//      hai; yahan haalat pehle se saaf nazar ati hai)।
//   5. Microphone — IKHTIYARI: sirf saboot (evidence) recording
//      ke liye (record package istemal par khud mangta hai);
//      is par koi cheez NAHI rukti।
// Contacts / Phone / Nearby devices / Physical activity
// BILKUL nahi mangi jatin — koi function in ka muhtaj nahi,
// aur manifest mein bhi in ka elan NAHI hai।
//
// Camera/Mic/Notification ki haalat + dialog ke liye
// permission_handler hai; location ke liye Geolocator;
// Settings ke deep link permission_handler ka openAppSettings
// aur Geolocator.openLocationSettings dete hain।
// =====================================================================

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'lang.dart';
import 'theme.dart';

/// Ek lamhe par tamam ijazaton ki asal haalat — system se
/// parhi hui, koi andaza NAHI।
class PermSnapshot {
  /// Foreground location mili hui hai (whileInUse ya always)।
  final bool locGranted;

  /// "Har waqt" (always) wali location mili hui hai।
  final bool locAlways;

  /// Location hamesha ke liye rad (Settings se hi milegi)।
  final bool locDeniedForever;

  /// Phone ki Location (GPS) switch on hai।
  final bool gpsOn;

  final bool notifGranted;
  final bool notifDeniedForever;
  final bool camGranted;
  final bool camDeniedForever;
  final bool micGranted;
  final bool micDeniedForever;

  const PermSnapshot({
    required this.locGranted,
    required this.locAlways,
    required this.locDeniedForever,
    required this.gpsOn,
    required this.notifGranted,
    required this.notifDeniedForever,
    required this.camGranted,
    required this.camDeniedForever,
    required this.micGranted,
    required this.micDeniedForever,
  });

  /// Duty ke liye asal lazmi jora — foreground location +
  /// notifications. (Camera istemal ke waqt ki shart hai,
  /// background location par naya gate NAHI hai — upar
  /// wali note dekhein)।
  bool get mustHaveOk => locGranted && notifGranted;

  /// Pehli-dafa wali screen par dikhane ke qabil koi kaam
  /// baqi hai (mic ikhtiyari hai — us par screen NAHI khulti)।
  bool get hasPendingWork =>
      !(locGranted && locAlways && notifGranted && camGranted);
}

/// Ijazaton ki haalat parhna, darkhwast karna aur pehli-dafa
/// wale parchay (flag) ka hisaab — tamam static, koi state
/// NAHI rakhta।
class AppPerms {
  static const String _kIntroKey = 'perm_intro_shown_v101';

  static Future<PermissionStatus> _status(Permission p) async {
    try {
      return await p.status;
    } catch (_) {
      return PermissionStatus.denied;
    }
  }

  /// System se taaza haalat — har field apne asal zariye se:
  /// location Geolocator se (app ka canonical rasta), baqi
  /// permission_handler se।
  static Future<PermSnapshot> load() async {
    var locGranted = false;
    var locAlways = false;
    var locDeniedForever = false;
    try {
      final perm = await Geolocator.checkPermission();
      locAlways = perm == LocationPermission.always;
      locGranted = locAlways || perm == LocationPermission.whileInUse;
      locDeniedForever = perm == LocationPermission.deniedForever;
    } catch (_) {}
    var gpsOn = false;
    try {
      gpsOn = await Geolocator.isLocationServiceEnabled();
    } catch (_) {}
    final notif = await _status(Permission.notification);
    final cam = await _status(Permission.camera);
    final mic = await _status(Permission.microphone);
    return PermSnapshot(
      locGranted: locGranted,
      locAlways: locAlways,
      locDeniedForever: locDeniedForever,
      gpsOn: gpsOn,
      notifGranted: notif.isGranted,
      notifDeniedForever: notif.isPermanentlyDenied,
      camGranted: cam.isGranted,
      camDeniedForever: cam.isPermanentlyDenied,
      micGranted: mic.isGranted,
      micDeniedForever: mic.isPermanentlyDenied,
    );
  }

  /// Foreground location ka system dialog (Geolocator)।
  static Future<void> requestForegroundLocation() async {
    try {
      await Geolocator.requestPermission();
    } catch (_) {}
  }

  static Future<void> requestNotification() async {
    try {
      await Permission.notification.request();
    } catch (_) {}
  }

  static Future<void> requestCamera() async {
    try {
      await Permission.camera.request();
    } catch (_) {}
  }

  static Future<void> requestMicrophone() async {
    try {
      await Permission.microphone.request();
    } catch (_) {}
  }

  /// Is app ki Android Settings screen (jahan se "Har waqt"
  /// wali location aur hamesha-rad shuda ijazatein milti
  /// hain)।
  static Future<void> openSettings() async {
    try {
      await openAppSettings();
    } catch (_) {}
  }

  /// Phone ki Location (GPS) settings — GPS band ho to
  /// wahin se on hota hai।
  static Future<void> openLocationSettings() async {
    try {
      await Geolocator.openLocationSettings();
    } catch (_) {}
  }

  /// Pehli-dafa wali khud-khulne wali screen ka parchah —
  /// ek dafa dikh jaye to dobara khud NAHI khulti (driver
  /// Profile/Settings se hamesha khol sakta hai)।
  static Future<bool> introSeen() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(_kIntroKey) ?? false;
    } catch (_) {
      // Parchah parhne mein kharabi ho to nag NAHI karte —
      // dikhi hui hi gino (banner/Profile ka rasta baqi hai)।
      return true;
    }
  }

  static Future<void> markIntroSeen() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_kIntroKey, true);
    } catch (_) {}
  }
}

/// Permissions screen — har ijazat: naam, wajah, haalat
/// (Mil gayi / Baqi hai) aur wahin se ijazat dene ka button।
/// Settings se wapas ane par (resume) haalat khud taaza
/// ho jati hai।
class PermissionsPage extends StatefulWidget {
  const PermissionsPage({super.key});

  @override
  State<PermissionsPage> createState() => _PermissionsPageState();
}

class _PermissionsPageState extends State<PermissionsPage>
    with WidgetsBindingObserver {
  PermSnapshot? _snap;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _reload();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Settings se ijazat de kar wapas aye to haalat foran
    // taaza — driver ko kuch dabana na pare।
    if (state == AppLifecycleState.resumed) _reload();
  }

  Future<void> _reload() async {
    final s = await AppPerms.load();
    if (mounted) setState(() => _snap = s);
  }

  /// Ek darkhwast chalao, phir haalat dobara parho।
  Future<void> _act(Future<void> Function() fn) async {
    if (_busy) return;
    setState(() => _busy = true);
    await fn();
    await _reload();
    if (mounted) setState(() => _busy = false);
  }

  Widget _tag(bool lazmi) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: lazmi ? Brand.ajrakRed : Brand.gold,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        lazmi ? tr('perm_lazmi') : tr('perm_ikhtiyari'),
        style: TextStyle(
          color: lazmi ? Colors.white : Brand.greenDark,
          fontSize: 10.5,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }

  /// Ek ijazat ki satar — [guide] woh izaafi rehnumai hai jo
  /// sirf baqi honay par dikhti hai (masalan "Har waqt" wali
  /// Settings wali hidayat); [onButton] null ho to button
  /// NAHI banta (masalan jab pehli wali ijazat hi baqi ho)।
  Widget _row({
    required IconData icon,
    required String title,
    required String why,
    required bool lazmi,
    required bool granted,
    String? guide,
    String? buttonLabel,
    VoidCallback? onButton,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: Brand.green, size: 24),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(title,
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 15)),
                ),
                _tag(lazmi),
              ],
            ),
            const SizedBox(height: 6),
            Text(why, style: const TextStyle(fontSize: 13, height: 1.4)),
            if (!granted && guide != null) ...[
              const SizedBox(height: 6),
              Text(guide,
                  style: const TextStyle(
                      fontSize: 12.5,
                      height: 1.4,
                      color: Brand.onLightSub)),
            ],
            const SizedBox(height: 10),
            Row(
              children: [
                Icon(granted ? Icons.check_circle : Icons.cancel,
                    size: 19,
                    color: granted ? Brand.green : Brand.ajrakRed),
                const SizedBox(width: 7),
                Text(
                  granted ? tr('perm_granted') : tr('guide_baqi'),
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: granted ? Brand.green : Brand.ajrakRed),
                ),
                const Spacer(),
                if (!granted && onButton != null)
                  ElevatedButton(
                    onPressed: _busy ? null : onButton,
                    child: Text(buttonLabel ?? tr('perm_give')),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = _snap;
    return Scaffold(
      appBar: AppBar(title: Text(tr('perm_title'))),
      body: s == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(14),
              children: [
                Card(
                  color: Brand.cream,
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.verified_user,
                            color: Brand.green, size: 26),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(tr('perm_intro'),
                              style: const TextStyle(
                                  fontSize: 13.5, height: 1.45)),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                // GPS switch band ho to ijazat ke bawajood jagah
                // NAHI milti — ye satar sirf usi haalat mein।
                if (!s.gpsOn) ...[
                  _row(
                    icon: Icons.gps_off,
                    title: tr('perm_gps_off'),
                    why: tr('perm_gps_off_why'),
                    lazmi: true,
                    granted: false,
                    buttonLabel: tr('perm_gps_on'),
                    onButton: () =>
                        _act(() => AppPerms.openLocationSettings()),
                  ),
                  const SizedBox(height: 10),
                ],
                _row(
                  icon: Icons.location_on,
                  title: tr('perm_loc'),
                  why: tr('perm_loc_why'),
                  lazmi: true,
                  granted: s.locGranted,
                  buttonLabel: s.locDeniedForever
                      ? tr('perm_open_settings')
                      : tr('perm_give'),
                  onButton: () => _act(() => s.locDeniedForever
                      ? AppPerms.openSettings()
                      : AppPerms.requestForegroundLocation()),
                ),
                const SizedBox(height: 10),
                _row(
                  icon: Icons.location_history,
                  title: tr('perm_loc_always'),
                  why: tr('perm_loc_always_why'),
                  lazmi: true,
                  granted: s.locAlways,
                  // Foreground hi baqi ho to pehle woh — button
                  // ki jagah rehnumai; warna Settings ka rasta
                  // (ye ijazat dialog se milti hi NAHI)।
                  guide: !s.locGranted
                      ? tr('perm_loc_first')
                      : tr('perm_loc_always_guide'),
                  buttonLabel: tr('perm_open_settings'),
                  onButton: s.locGranted
                      ? () => _act(() => AppPerms.openSettings())
                      : null,
                ),
                const SizedBox(height: 10),
                _row(
                  icon: Icons.notifications_active,
                  title: tr('perm_notif'),
                  why: tr('perm_notif_why'),
                  lazmi: true,
                  granted: s.notifGranted,
                  buttonLabel: s.notifDeniedForever
                      ? tr('perm_open_settings')
                      : tr('perm_give'),
                  onButton: () => _act(() => s.notifDeniedForever
                      ? AppPerms.openSettings()
                      : AppPerms.requestNotification()),
                ),
                const SizedBox(height: 10),
                _row(
                  icon: Icons.photo_camera,
                  title: tr('perm_cam'),
                  why: tr('perm_cam_why'),
                  lazmi: true,
                  granted: s.camGranted,
                  buttonLabel: s.camDeniedForever
                      ? tr('perm_open_settings')
                      : tr('perm_give'),
                  onButton: () => _act(() => s.camDeniedForever
                      ? AppPerms.openSettings()
                      : AppPerms.requestCamera()),
                ),
                const SizedBox(height: 10),
                _row(
                  icon: Icons.mic,
                  title: tr('perm_mic'),
                  why: tr('perm_mic_why'),
                  lazmi: false,
                  granted: s.micGranted,
                  buttonLabel: s.micDeniedForever
                      ? tr('perm_open_settings')
                      : tr('perm_give'),
                  onButton: () => _act(() => s.micDeniedForever
                      ? AppPerms.openSettings()
                      : AppPerms.requestMicrophone()),
                ),
                const SizedBox(height: 12),
                if (s.locGranted &&
                    s.locAlways &&
                    s.notifGranted &&
                    s.camGranted) ...[
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Row(
                        children: [
                          const Icon(Icons.check_circle,
                              color: Brand.green, size: 24),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(tr('perm_all_ok'),
                                style: const TextStyle(
                                    fontSize: 13.5,
                                    height: 1.4,
                                    fontWeight: FontWeight.w700)),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                ],
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Text(tr('perm_note'),
                      style: const TextStyle(
                          fontSize: 12.5,
                          height: 1.4,
                          color: Brand.onLightSub)),
                ),
              ],
            ),
    );
  }
}
