import 'dart:async';

import 'package:audioplayers/audioplayers.dart';

/// Shared AWAAZ KI HIDAYAT player (v1.4.6 — Package A).
///
/// Pehle ye logic sirf registration.dart mein tha (har wizard apna
/// AudioPlayer rakhta tha). Ab ye ek hi static helper hai taaki
/// registration wizard, reject-guidance aur error-guidance sab ek
/// hi jagah se awaaz chalayein — OFFLINE bundle clips
/// (assets/guidance/) par, internet ho ya na ho.
///
/// Usool: awaaz ki nakami kabhi bhi kisi amal ko NAHI rokti —
/// har call khamoshi se fail hoti hai.
class GuideAudio {
  GuideAudio._();

  static final AudioPlayer _player = AudioPlayer();

  /// Ek clip chalana — pehle wali ruk jati hai. Nakami khamosh.
  static Future<void> play(String asset) async {
    try {
      await _player.stop();
      await _player.play(AssetSource(asset));
    } catch (_) {
      // Awaaz na baje to bhi kaam aage barhta hai.
    }
  }

  /// Clips ek ke baad ek — har clip ke KHATAM hone ka intezaar
  /// (onPlayerComplete) karke agli chalti hai. Nakami par agli
  /// clip par barh jata hai taaki sequence atak na jaye.
  static Future<void> playSequence(List<String> assets) async {
    for (final asset in assets) {
      try {
        await _player.stop();
        final done = Completer<void>();
        StreamSubscription<void>? sub;
        sub = _player.onPlayerComplete.listen((_) {
          if (!done.isCompleted) done.complete();
        });
        await _player.play(AssetSource(asset));
        await done.future.timeout(
          const Duration(seconds: 30),
          onTimeout: () {},
        );
        await sub.cancel();
      } catch (_) {
        // Is clip ki nakami — agli par jao.
      }
    }
  }

  /// Jo baj raha hai use rokna (screen dispose waghera par).
  static Future<void> stop() async {
    try {
      await _player.stop();
    } catch (_) {}
  }
}
