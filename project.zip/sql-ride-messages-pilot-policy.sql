-- =====================================================================
-- Bozdar Safar — ride_messages pilot policy (MARHALA-WAR)
-- ride_messages table Phase-4 design ke mutabiq jaan boojh kar bina
-- permissive policy ke bani thi. Pilot marhale mein baqi 15 tables
-- par `pilot_all` policy chal rahi hai — chat ko pilot mein chalane
-- ke liye wohi policy yahan bhi lagayi jati hai.
-- ⚠️ PHASE-4 FLIP ke waqt ye policy baqi pilot_all policies ke saath
-- khatam karke participant-only policies (sirf us ride ke passenger
-- + driver) lagana LAZMI hai — flip checklist mein ye table shamil
-- rakho (driver_live ke saath).
-- =====================================================================

DROP POLICY IF EXISTS pilot_all ON public.ride_messages;
CREATE POLICY pilot_all ON public.ride_messages
  FOR ALL USING (true) WITH CHECK (true);
