import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'store.dart';
import 'theme.dart';
import 'passenger.dart';
import 'driver.dart';

void main() {
  runApp(const BozdarSafarApp());
}

class BozdarSafarApp extends StatefulWidget {
  const BozdarSafarApp({super.key});

  @override
  State<BozdarSafarApp> createState() => _BozdarSafarAppState();
}

class _BozdarSafarAppState extends State<BozdarSafarApp> {
  final AppStore store = AppStore();

  @override
  void initState() {
    super.initState();
    // Load ke baad ek dafa khamosh update check (fire-and-forget).
    store.load().then((_) => store.checkForUpdate());
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Safar',
      debugShowCheckedModeBanner: false,
      theme: Brand.theme(),
      home: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          if (!store.loaded) {
            return const Scaffold(
              backgroundColor: Brand.deepGreen,
              body: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.local_taxi, color: Brand.gold, size: 56),
                    SizedBox(height: 14),
                    Text(
                      'SAFAR',
                      style: TextStyle(
                        color: Brand.gold,
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.4,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Your ride, your people.',
                      style: TextStyle(color: Brand.cream, fontSize: 13),
                    ),
                  ],
                ),
              ),
            );
          }
          return ModeShell(store: store);
        },
      ),
    );
  }
}

/// ONE app, TWO fully separated sides. One tap replaces the whole
/// display; the other side never renders. Mode badalne ke do saaf tareeqe:
///  - Shell ke sab se upar hamesha nazar aane wala segmented control
///    "Passenger | Driver" (v1.0.5 — malik ke hukm par, taake Driver side
///    dhoondhna hi na pare).
///  - Har side ke andar maujood full-width gold switch button
///    ("Driver Mode mein jayein" / "Passenger Mode mein jayein").
/// Pehli dafa app Passenger mode mein khulti hai, segmented control
/// upar wazeh nazar aata hai.
class ModeShell extends StatefulWidget {
  final AppStore store;
  const ModeShell({super.key, required this.store});

  @override
  State<ModeShell> createState() => _ModeShellState();
}

class _ModeShellState extends State<ModeShell> {
  bool driverMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Brand.deepGreen,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            ModeSegmentedControl(
              driverMode: driverMode,
              onChanged: (d) => setState(() => driverMode = d),
            ),
            Expanded(
              child: driverMode
                  ? DriverSide(
                      store: widget.store,
                      onSwitchToPassenger: () =>
                          setState(() => driverMode = false),
                    )
                  : PassengerSide(
                      store: widget.store,
                      onSwitchToDriver: () =>
                          setState(() => driverMode = true),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Shell ke sab se upar ka mode switch — do bade hisse, hamesha visible:
/// "Passenger" | "Driver". Jo mode chal raha hai woh gold mein roshan
/// hota hai; doosre hisse par ek tap mode badal deta hai.
class ModeSegmentedControl extends StatelessWidget {
  final bool driverMode;
  final ValueChanged<bool> onChanged;
  const ModeSegmentedControl(
      {super.key, required this.driverMode, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Brand.deepGreen,
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.14),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: Brand.gold, width: 1.2),
        ),
        padding: const EdgeInsets.all(4),
        child: Row(
          children: [
            _half(driver: false, icon: Icons.person, label: 'Passenger'),
            _half(driver: true, icon: Icons.drive_eta, label: 'Driver'),
          ],
        ),
      ),
    );
  }

  Widget _half(
      {required bool driver, required IconData icon, required String label}) {
    final selected = driverMode == driver;
    return Expanded(
      child: GestureDetector(
        onTap: () => onChanged(driver),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 11),
          decoration: BoxDecoration(
            color: selected ? Brand.gold : Colors.transparent,
            borderRadius: BorderRadius.circular(999),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon,
                  size: 20, color: selected ? Brand.greenDark : Brand.cream),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  color: selected ? Brand.greenDark : Brand.cream,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// The single mode-switch button. [toDriver] decides its label/direction.
class SwitchModeButton extends StatelessWidget {
  final bool toDriver;
  final VoidCallback onTap;
  const SwitchModeButton(
      {super.key, required this.toDriver, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(toDriver ? Icons.drive_eta : Icons.person, size: 20),
        label: Text(toDriver
            ? 'Driver Mode mein jayein'
            : 'Passenger Mode mein jayein'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Brand.gold,
          foregroundColor: Brand.greenDark,
          padding: const EdgeInsets.symmetric(vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }
}

/// Nayi update ka slim gold banner — dono sides ke home ke upar dikhta
/// hai. "Update karein" download link kholta hai; × dabane se sirf is
/// session ke liye chhup jata hai.
class UpdateBanner extends StatelessWidget {
  final AppStore store;
  const UpdateBanner({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: Brand.gold,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(
        children: [
          const Icon(Icons.system_update, size: 18, color: Brand.greenDark),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              'Safar ki nayi update aa gayi hai',
              style: TextStyle(
                  color: Brand.greenDark,
                  fontSize: 13,
                  fontWeight: FontWeight.w800),
            ),
          ),
          TextButton(
            onPressed: () => launchUrl(
              Uri.parse(kUpdateDownloadUrl),
              mode: LaunchMode.externalApplication,
            ),
            style: TextButton.styleFrom(
              backgroundColor: Brand.greenDark,
              foregroundColor: Brand.cream,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              minimumSize: Size.zero,
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: const Text('Update karein',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(width: 4),
          IconButton(
            onPressed: store.dismissUpdate,
            icon: const Icon(Icons.close, size: 18, color: Brand.greenDark),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
            tooltip: 'Band karein',
          ),
        ],
      ),
    );
  }
}
