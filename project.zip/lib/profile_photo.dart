import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'backend.dart';
import 'lang.dart';
import 'photo_avatar.dart';
import 'store.dart';
import 'theme.dart';

// ===========================================================================
// v1.4.22 — PROFILE PHOTO HADD (malik ka hukm 2026-11-10 23:36)
//
// Har driver aur har sawari apni profile image laga/badla sakta
// hai — KUL 3 dafa. 3 ke baad app se image change NAHI hoti aur
// is par saaf likha hua notice ata hai (driver ke notice mein
// Master-route wali sahulat bhi — malik ka izafi hukm 23:40).
//
// ASAL HADD BACKEND PAR HAI (migration v143 —
// builds/sql-v143-profile-photo.sql): drivers/passengers ki
// photo_changes ginti + BEFORE trigger jo hadd se aage ki
// tabdeeli exception se rok deta hai (malik/Master mustasna)।
// Client yahan sirf asal ginti backend se pull karke dikhata
// hai — andaze se counter NAHI chalata।
// ===========================================================================

/// Profile photo ki hadd ka khalis (pure) hisaab — tests isi
/// par chalte hain; UI aur flow dono yehi istemal karte hain।
class ProfilePhotoLimit {
  /// Kul moqay: photo lagana + badalna mila kar।
  static const int maxChanges = 3;

  /// Istemal shuda ginti par baqi moqay (kabhi manfi nahi)।
  static int remaining(int used) =>
      used >= maxChanges ? 0 : maxChanges - used;

  /// Abhi tabdeeli mumkin hai ya nahi।
  static bool canChange(int used) => used < maxChanges;

  /// Baqi moqon wali saaf likhi line (card par har haal mein
  /// dikhti hai)। v1.4.34 (P-2): tr() se — Urdu pasand par lafz
  /// wohi purane (tests isi par chalte hain), English par tarjuma।
  static String remainingLine(int used) => trf('photo_remaining',
      {'left': '${remaining(used)}', 'max': '$maxChanges'});

  /// HADD KHATAM — PASSENGER wala sada notice।
  static const String limitNoticePassenger =
      'Aap ki image badalne ki hadd (3) poori ho chuki hai — ab image change nahi ho sakti. Zaroorat ho to Master se rabta karein.';

  /// HADD KHATAM — DRIVER wala notice (malik ka izafi hukm
  /// 2026-11-10 23:40): Master app se malik photo laga sakta
  /// hai, is liye driver ko support-message wala rasta bhi
  /// likha hua milta hai।
  static const String limitNoticeDriver =
      'Aap ki image badalne ki hadd (3) poori ho chuki hai — ab app se image change nahi ho sakti. Nayi photo lagwani ho to Master ko support message mein apni photo bhej dein — malik Master app se aap ki photo laga dega.';
}

/// "Meri Photo" card — Driver Profile mein bhi aur Sawari ki
/// Profile mein bhi yehi chalta hai ([forDriver] se farq sirf
/// itna hai: asal counter/backend rasta aur hadd wala notice)।
///
/// Card khulne par asal ginti backend se taaza hoti hai
/// (Backend.refreshDriverPhotoState /
/// refreshPassengerPhotoState); tabdeeli sirf dedicated backend
/// raste (change*ProfilePhoto) se hoti hai jo pehle versioned
/// path par upload karke phir row ka path badalta hai — hadd
/// poori ho to backend trigger PATCH/upsert rok deta hai aur
/// yahan wohi likha hua notice nazar ata hai।
class ProfilePhotoCard extends StatefulWidget {
  final AppStore store;
  final bool forDriver;
  const ProfilePhotoCard(
      {super.key, required this.store, required this.forDriver});

  @override
  State<ProfilePhotoCard> createState() => _ProfilePhotoCardState();
}

class _ProfilePhotoCardState extends State<ProfilePhotoCard> {
  final ImagePicker _picker = ImagePicker();
  bool _busy = false;

  AppStore get store => widget.store;

  @override
  void initState() {
    super.initState();
    // Asal ginti/path backend se — local cache sirf pehla
    // paint hai, sach server wala ata hai।
    unawaited(_refresh());
  }

  Future<void> _refresh() async {
    if (widget.forDriver) {
      await Backend.refreshDriverPhotoState(store);
    } else {
      await Backend.refreshPassengerPhotoState(store);
    }
    if (mounted) setState(() {});
  }

  int get _used =>
      widget.forDriver ? store.profile.photoChanges : store.passengerPhotoChanges;

  String get _localPath => widget.forDriver
      ? store.profile.profilePhotoPath
      : store.passengerPhotoLocalPath;

  String get _backendPath => widget.forDriver
      ? store.profile.profilePhotoBackendPath
      : store.passengerPhotoBackendPath;

  // v1.4.34 (P-2): notice maujooda zubaan mein — Urdu par wohi
  // ProfilePhotoLimit wale malik ke jumle (constants canonical
  // Urdu mein mehfooz hain), English par un ka tarjuma।
  String get _notice =>
      widget.forDriver ? tr('photo_notice_driver') : tr('photo_notice_passenger');

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  /// Photo chunna — registration/_reuploadDoc wala wohi
  /// pattern: pehle Camera/Gallery ki sheet, phir pick।
  Future<void> _changePhoto() async {
    if (_busy || !ProfilePhotoLimit.canChange(_used)) return;
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Brand.green),
              title: Text(tr('pick_camera')),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Brand.green),
              title: Text(tr('pick_gallery')),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (src == null || !mounted) return;
    setState(() => _busy = true);
    try {
      // v1.4.31: profile photo chhoti karke bhejna (1200px, q80) —
      // asal camera photo kai MB ki hoti hai; sust net par woh
      // upload adhoora reh jata tha।
      final img = await _picker.pickImage(
          source: src, imageQuality: 80, maxWidth: 1200, maxHeight: 1200);
      if (img == null) {
        _snack(tr('photo_snack_nophoto'));
        return;
      }
      final ok = widget.forDriver
          ? await Backend.changeDriverProfilePhoto(store, img.path)
          : await Backend.changePassengerProfilePhoto(store, img.path);
      if (!mounted) return;
      if (ok) {
        _snack(tr('photo_snack_done'));
      } else if (!ProfilePhotoLimit.canChange(_used)) {
        // Backend ne hadd par rok diya — ginti taaza karke
        // wohi likha hua notice card par nazar ayega।
        await _refresh();
        _snack(tr('photo_snack_limit'));
      } else {
        _snack(tr('photo_snack_failed'));
      }
    } catch (_) {
      _snack(tr('pick_photo_failed'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final used = _used;
        final canChange = ProfilePhotoLimit.canChange(used);
        final localFile =
            _localPath.isNotEmpty ? File(_localPath) : null;
        final hasLocal = localFile != null && localFile.existsSync();
        final hasPhoto = hasLocal || _backendPath.isNotEmpty;
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    // Mojooda photo: phone par local file ho to
                    // wohi ASAL render hoti hai; sirf backend
                    // record ho (doosra phone / cache saaf) to
                    // v1.4.27 se signed-URL wale raste se asal
                    // photo mangwayi jati hai (RemotePhotoAvatar —
                    // driver: bucket 'driver-docs', sawari:
                    // bucket 'selfies'); URL/load na mile to
                    // initials/verified nishan — jaali photo
                    // kabhi NAHI।
                    if (hasLocal)
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: Brand.green,
                        backgroundImage: FileImage(localFile),
                      )
                    else if (_backendPath.isNotEmpty)
                      RemotePhotoAvatar(
                        bucket: widget.forDriver ? 'driver-docs' : 'selfies',
                        path: _backendPath,
                        name: widget.forDriver
                            ? store.profile.name
                            : store.passengerName,
                        radius: 30,
                      )
                    else
                      const CircleAvatar(
                        radius: 30,
                        backgroundColor: Brand.green,
                        child: Icon(
                          Icons.person_outline,
                          color: Colors.white,
                          size: 30,
                        ),
                      ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(tr('photo_title'),
                              style: const TextStyle(
                                  fontWeight: FontWeight.w900, fontSize: 15)),
                          const SizedBox(height: 2),
                          Text(
                            hasPhoto ? tr('photo_have') : tr('photo_none'),
                            style: const TextStyle(
                                fontSize: 12.5, color: Colors.black54),
                          ),
                          const SizedBox(height: 2),
                          // Baqi moqay — hamesha saaf likhe hue।
                          Text(
                            ProfilePhotoLimit.remainingLine(used),
                            style: const TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w700,
                                color: Brand.green),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                if (canChange)
                  Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton.icon(
                      onPressed: _busy ? null : _changePhoto,
                      icon: _busy
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white),
                            )
                          : const Icon(Icons.photo_camera, size: 18),
                      label:
                          Text(hasPhoto ? tr('photo_change') : tr('photo_add')),
                    ),
                  )
                else
                  // HADD POORI — button ki jagah LIKHA HUA notice
                  // (malik ka hukm: is par saaf likha hua aye)।
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(11),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF6E0),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Brand.gold),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.lock_outline,
                            color: Brand.ajrakRed, size: 19),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _notice,
                            style: const TextStyle(
                                fontSize: 12.5, height: 1.45),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}
