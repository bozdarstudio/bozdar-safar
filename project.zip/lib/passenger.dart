import 'dart:async';
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'store.dart';
import 'theme.dart';
import 'messages.dart';
import 'route_service.dart';
import 'safar_map.dart';
import 'main.dart' show ModeToggleButton, UpdateBanner;

const LatLng kKarachiCenter = LatLng(24.8608, 67.0011); // Karachi sheher

const Map<String, String> kStatusUrdu = {
  'pending': 'Driver ke jawab ka intezaar',
  'accepted': 'Driver ne qubool kar li',
  'arrived': 'Driver pohanch gaya hai',
  'completed': 'Ride mukammal',
  'cancelled': 'Mansookh',
  'noshow': 'Sawari nahi aayi (No-show)',
};

class PassengerSide extends StatefulWidget {
  final AppStore store;
  final VoidCallback onSwitchToDriver;
  const PassengerSide(
      {super.key, required this.store, required this.onSwitchToDriver});

  @override
  State<PassengerSide> createState() => _PassengerSideState();
}

class _PassengerSideState extends State<PassengerSide> {
  int _tab = 0; // 0 Booking | 1 Meri Bookings | 2 Monthly

  // Booking form — MapLibre 3D map: pickup/drop tap se lagte hain,
  // route line OSRM se (offline par seedhi line fallback).
  LatLng _pickup = kKarachiCenter;
  LatLng? _drop;
  bool _dropArmed = false;
  List<LatLng>? _routePoints;
  String _routeSig = '';
  int _routeToken = 0;
  // Maujooda pickup/drop jori ke ASAL ROUTE ki sadak wali doori (km) —
  // kiraya isi par banta hai (v1.2.1). Null = is jori ka road route
  // abhi dastiyab nahi (offline/seedhi-line fallback); tab kiraya
  // seedhi doori se banta hai. _routeKmSig woh jori hai jis ke liye
  // ye doori hai — jori badle to purani doori istemal nahi hoti.
  double? _routeKm;
  String _routeKmSig = '';
  bool _satellite = false;
  LatLng? _focusPoint;
  int _focusSeq = 0;
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _pickupCtrl = TextEditingController();
  final _dropCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  String _vehicle = 'Rickshaw';
  double _distanceKm = 2.0;

  // Monthly form
  final _mPickupCtrl = TextEditingController();
  final _mDropCtrl = TextEditingController();
  String _mVehicle = 'Rickshaw';
  double _mRouteKm = 2.0;
  int _mDays = 26;

  // NOTE (v1.0.5): km chip selectors HATA diye gaye hain — doori hamesha
  // AUTO hisaab (pickup pin se drop pin) se aati hai; passenger ko koi
  // km field, per-km rate ya formula kabhi nazar nahi aata.
  static const List<int> _dayChips = [20, 24, 26, 30];

  AppStore get store => widget.store;

  @override
  void initState() {
    super.initState();
    _nameCtrl.text = store.passengerName;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _pickupCtrl.dispose();
    _dropCtrl.dispose();
    _noteCtrl.dispose();
    _mPickupCtrl.dispose();
    _mDropCtrl.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  bool get _fareReady =>
      _pickupCtrl.text.trim().isNotEmpty && _dropCtrl.text.trim().isNotEmpty;

  static double _roundKm(double km) {
    final r = (km * 10).round() / 10;
    return r < 0.5 ? 0.5 : r;
  }

  /// SEEDHI (crow-flies) doori — ye sirf FALLBACK hai: jab pickup/drop
  /// jori ka asal sadak route (OSRM/cache) dastiyab na ho (masalan
  /// pehli dafa bilkul offline hon), tab kiraya isi se banta hai.
  /// Drop pin na ho to andar ka default istemal hota hai — passenger
  /// se doori kabhi poochhi nahi jati.
  double get _autoKm {
    if (_drop == null) return _distanceKm;
    final d = const Distance().as(LengthUnit.Kilometer, _pickup, _drop!);
    return _roundKm(d);
  }

  /// Kiraaye ki asal doori: maujooda pickup/drop jori ke ROUTE ki
  /// sadak wali doori (per-km rate isi par lagta hai — v1.2.1 fix).
  /// Road route dastiyab na ho to seedhi doori (_autoKm) fallback.
  double get _fareKm {
    final rk = _routeKm;
    if (_drop != null && rk != null) return rk;
    return _autoKm;
  }

  void _setPickup(LatLng point) {
    setState(() => _pickup = point);
    _refreshRoute();
  }

  static String _pairSig(LatLng a, LatLng b) =>
      '${a.latitude.toStringAsFixed(3)},${a.longitude.toStringAsFixed(3)}|${b.latitude.toStringAsFixed(3)},${b.longitude.toStringAsFixed(3)}';

  /// Pickup/drop ke liye asal sadak ka route (OSRM ya cache; offline par
  /// seedhi line) — map par line bhi isi se banti hai AUR kiraya bhi:
  /// route ki SADAK wali doori (_routeKm) hi kiraaye ki bunyaad hai
  /// (v1.2.1). Sirf seedhi-line fallback mile to _routeKm null rehta
  /// hai aur kiraya seedhi doori (_autoKm) se banta hai.
  Future<void> _refreshRoute() async {
    final drop = _drop;
    if (drop == null) {
      if (_routePoints != null && mounted) {
        setState(() => _routePoints = null);
      }
      _routeSig = '';
      _routeKm = null;
      _routeKmSig = '';
      return;
    }
    final sig = _pairSig(_pickup, drop);
    if (sig == _routeSig) return;
    _routeSig = sig;
    // Jori badal gayi — purani jori ki route doori ab kiraaye mein
    // istemal nahi hogi; nayi doori fetch mukammal hone par hi set hogi.
    _routeKm = null;
    _routeKmSig = '';
    final token = ++_routeToken;
    final r = await RouteService.fetch(_pickup, drop);
    if (mounted && token == _routeToken) {
      setState(() {
        _routePoints = r.points;
        if (r.isStraightFallback) {
          _routeKm = null;
          _routeKmSig = '';
        } else {
          _routeKm = _roundKm(r.distanceKm);
          _routeKmSig = sig;
        }
      });
    }
  }

  Future<void> _myLocation() async {
    try {
      final service = await Geolocator.isLocationServiceEnabled();
      if (!service) {
        if (mounted) _snack('Location service band hai — pehle on karein.');
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        if (mounted) _snack('Location ki ijazat nahi mili.');
        return;
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings:
            const LocationSettings(accuracy: LocationAccuracy.high),
      );
      if (!mounted) return;
      final ll = LatLng(pos.latitude, pos.longitude);
      setState(() {
        _pickup = ll;
        _focusPoint = ll;
        _focusSeq++;
        if (_pickupCtrl.text.trim().isEmpty) {
          _pickupCtrl.text = 'Meri Location';
        }
      });
      _refreshRoute();
    } catch (_) {
      if (mounted) {
        _snack('Location nahi mil saki — map par tap karke pickup lagayein.');
      }
    }
  }

  void _placeDrop(LatLng point) {
    setState(() {
      _drop = point;
      _dropArmed = false;
    });
    _refreshRoute();
  }

  Future<void> _confirmBooking() async {
    if (_nameCtrl.text.trim().isEmpty) {
      _snack('Apna naam likhein.');
      return;
    }
    if (!_fareReady) {
      _snack('Pickup aur drop dono jagah likhein.');
      return;
    }
    store.passengerName = _nameCtrl.text.trim();
    // Kiraya ASAL SADAK ki doori par banta hai (v1.2.1): agar maujooda
    // jori ki route doori abhi state mein nahi hai, to booking se pehle
    // EK dafa route le kar usi ki doori istemal karein (cache se foran
    // mil jata hai; waqt ki had 6 second). Route na mile (offline) to
    // seedhi doori par hi booking ban jayegi — booking is wajah se
    // lambi rukegi nahi, aur fail ho to khamoshi se fallback hoga.
    var km = _fareKm;
    final dropPin = _drop;
    if (dropPin != null) {
      final sig = _pairSig(_pickup, dropPin);
      if (_routeKm == null || _routeKmSig != sig) {
        try {
          final r = await RouteService.fetch(_pickup, dropPin)
              .timeout(const Duration(seconds: 6));
          if (!r.isStraightFallback && r.distanceKm > 0) {
            km = _roundKm(r.distanceKm);
            _routeKm = km;
            _routeKmSig = sig;
            if (mounted) {
              setState(() => _routePoints = r.points);
            }
          }
        } catch (_) {
          // Route na mila — km seedhi doori (_fareKm) hi rahega.
        }
      }
    }
    final b = Booking(
      id: store.newId(),
      passengerName: _nameCtrl.text.trim(),
      passengerPhone: _phoneCtrl.text.trim(),
      pickupLabel: _pickupCtrl.text.trim(),
      dropLabel: _dropCtrl.text.trim(),
      pickupLat: _pickup.latitude,
      pickupLng: _pickup.longitude,
      dropLat: _drop?.latitude ?? 0,
      dropLng: _drop?.longitude ?? 0,
      hasDropPin: _drop != null,
      vehicle: _vehicle,
      distanceKm: km,
      fare: Fares.fareFor(_vehicle, km),
      note: _noteCtrl.text.trim(),
      status: 'pending',
      createdAt: DateTime.now(),
      driverName: store.profile.name,
    );
    await store.addBooking(b);
    if (!mounted) return;
    // Kul kiraya PEHLI dafa yahin nazar aata hai — booking pakki hone
    // ke BAAD (owner ka lock, v1.0.7). Us se pehle kahin koi price nahi.
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Brand.green, size: 26),
            SizedBox(width: 8),
            Text('Booking Pakki Ho Gayi'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('${b.pickupLabel} → ${b.dropLabel}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text(b.vehicle, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Brand.deepGreen,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                children: [
                  const Text('TOTAL KIRAYA',
                      style: TextStyle(
                          color: Brand.goldLight,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.2)),
                  Text(rs(b.total),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.w900)),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Doori: ${b.distanceKm.toStringAsFixed(1)} km',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Colors.black87),
            ),
            const SizedBox(height: 6),
            const Text(
              'Booking driver ko bhej di gayi hai — jawab ka intezaar karein.',
              style: TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Theek Hai'),
          ),
        ],
      ),
    );
    if (!mounted) return;
    // Booking pakki hone ke BAAD "Driver Dhoonda Ja Raha Hai" wali
    // screen (Careem ki "Finding your Captain" style, v1.0.8) — ye
    // booking ki halat wali screen hai, asal driver assignment nahi.
    final result = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (_) => _FindingDriverView(store: store, booking: b),
      ),
    );
    if (!mounted) return;
    if (result == 'bookings') {
      setState(() => _tab = 1);
    } else if (result == 'cancelled') {
      setState(() => _tab = 0);
      _snack('Ride mansookh ho gayi.');
    }
  }

  void _clearBookingForm() {
    setState(() {
      _pickupCtrl.clear();
      _dropCtrl.clear();
      _noteCtrl.clear();
      _drop = null;
      _dropArmed = false;
      _distanceKm = 2.0;
      _routeKm = null;
      _routeKmSig = '';
      _vehicle = 'Rickshaw';
    });
    _snack('Koi booking nahi bani — sab saaf kar diya gaya.');
  }

  Future<void> _savePlace(bool isGhar) async {
    final current = isGhar ? store.savedGhar : store.savedDaftar;
    final ctrl = TextEditingController(text: current);
    final label = isGhar ? 'Ghar' : 'Daftar';
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('$label ki jagah save karein'),
        content: TextField(
          controller: ctrl,
          decoration: InputDecoration(labelText: '$label ka pata / jagah'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Rehne Dein')),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: const Text('Save Karein')),
        ],
      ),
    );
    if (result != null) {
      if (isGhar) {
        store.savedGhar = result;
      } else {
        store.savedDaftar = result;
      }
      await store.save();
      if (mounted) _snack('$label save ho gaya.');
    }
  }

  void _applyPlace(bool isGhar) {
    final v = isGhar ? store.savedGhar : store.savedDaftar;
    if (v.isEmpty) {
      _savePlace(isGhar);
    } else {
      setState(() => _dropCtrl.text = v);
    }
  }

  // -------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const BrandHeader(sideLabel: 'PASSENGER APP'),
          if (store.updateAvailable && !store.updateDismissed)
            UpdateBanner(store: store),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
            child: ModeToggleButton(
                toDriver: true, onTap: widget.onSwitchToDriver),
          ),
          // Malik ki passenger mode artwork (brand board) — header + toggle
          // ke foran neeche.
          const ModeBanner(asset: 'assets/mode-passenger.png'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Row(
              children: [
                _tabBtn(0, Icons.map, 'Booking'),
                const SizedBox(width: 8),
                _tabBtn(1, Icons.list_alt, 'Meri Bookings'),
                const SizedBox(width: 8),
                _tabBtn(2, Icons.calendar_month, 'Monthly'),
              ],
            ),
          ),
          Expanded(
            child: _tab == 0
                ? _bookingView()
                : _tab == 1
                    ? _myBookingsView()
                    : _monthlyView(),
          ),
        ],
      ),
    );
  }

  Widget _tabBtn(int idx, IconData icon, String label) {
    final selected = _tab == idx;
    return Expanded(
      child: OutlinedButton.icon(
        onPressed: () => setState(() => _tab = idx),
        icon: Icon(icon, size: 18),
        label: Text(label),
        style: OutlinedButton.styleFrom(
          backgroundColor: selected ? Brand.goldLight : Colors.white,
          foregroundColor: Brand.greenDark,
          side: BorderSide(
              color: selected ? Brand.gold : const Color(0xFFB9CFC6),
              width: selected ? 1.8 : 1.2),
          padding: const EdgeInsets.symmetric(vertical: 10),
          textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
    );
  }

  IconData _vehicleIcon(String v) => v == 'Car'
      ? Icons.directions_car
      : v == 'Bike'
          ? Icons.two_wheeler
          : Icons.electric_rickshaw;

  /// Gaariyon ki Roman-Urdu taglines — sab price-free hain (owner lock).
  static const Map<String, String> _vehicleTaglines = {
    'Rickshaw': 'Shehar ki sawari, sab ki pasand',
    'Bike': 'Jaib par halki, traffic ke liye behtareen',
    'Car': 'Aaram deh sawari, family ke liye behtareen',
  };

  /// Careem "Ride details" style vehicle row (v1.0.8): icon left, bold
  /// naam + grey Roman-Urdu tagline, radio circle right, selected row
  /// highlighted. Koi price NAHI — owner ka lock (v1.0.7 se barqarar):
  /// booking se pehle kiraya kahin nazar nahi aata; kul kiraya sirf
  /// ride pakki hone ke BAAD dikhta hai.
  Widget _vehicleRow({
    required String vehicle,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFFE7F2EC) : Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: selected ? Brand.green : Brand.fieldBorder,
              width: selected ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              Icon(_vehicleIcon(vehicle), color: Brand.green, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(vehicle,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(_vehicleTaglines[vehicle] ?? '',
                        style: const TextStyle(
                            fontSize: 12.5, color: Colors.black54)),
                  ],
                ),
              ),
              Container(
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: selected ? Brand.green : const Color(0xFFB9CFC6),
                    width: 2,
                  ),
                ),
                child: selected
                    ? Center(
                        child: Container(
                          width: 11,
                          height: 11,
                          decoration: const BoxDecoration(
                            color: Brand.green,
                            shape: BoxShape.circle,
                          ),
                        ),
                      )
                    : null,
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// "Qareebi Jagahen" row — Careem ke Nearby Locations jaisi: pin,
  /// bold zone naam, grey subtitle. Tap par zone manzil (drop) ban
  /// jata hai. Koi heart icon nahi.
  Widget _zoneRow(String zone) {
    final isDrop = _dropCtrl.text.trim() == zone;
    return InkWell(
      onTap: () {
        setState(() {
          _dropCtrl.text = zone;
          final c = kZoneCoords[zone];
          if (c != null) {
            _drop = c;
            _dropArmed = false;
          }
        });
        _refreshRoute();
      },
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: isDrop ? Brand.green : Brand.lightBg,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.location_on,
                  size: 19, color: isDrop ? Colors.white : Brand.green),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(zone,
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 14)),
                  Text(kZoneProvince[zone] ?? 'Pakistan',
                      style: const TextStyle(
                          fontSize: 12, color: Colors.black45)),
                ],
              ),
            ),
            if (isDrop)
              const Icon(Icons.check_circle, color: Brand.green, size: 20),
          ],
        ),
      ),
    );
  }

  // --- Booking view: full map + overlay sheet (inDrive style) ---------------

  Widget _bookingView() {
    final size = MediaQuery.of(context).size;
    return Stack(
      children: [
        Positioned.fill(
          child: SafarMapView(
            center: _pickup,
            initialZoom: 13.5,
            tilt: 50,
            pickup: _pickup,
            drop: _drop,
            routePoints: _routePoints,
            zonePoints: [
              for (final z in store.zoneNames)
                if (kZoneCoords[z] != null) kZoneCoords[z]!,
            ],
            interactive: true,
            fitToRoute: true,
            externalStyleControl: true,
            satellite: _satellite,
            onSatelliteChanged: (v) => setState(() => _satellite = v),
            onTapPoint: (p) {
              if (_dropArmed) {
                _placeDrop(p);
              } else {
                _setPickup(p);
              }
            },
            onLongPressPoint: _placeDrop,
            focusPoint: _focusPoint,
            focusSeq: _focusSeq,
          ),
        ),
        // Map quick actions
        Positioned(
          top: 10,
          right: 12,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              FloatingActionButton.small(
                heroTag: 'gps',
                onPressed: _myLocation,
                backgroundColor: Colors.white,
                foregroundColor: Brand.green,
                child: const Icon(Icons.my_location),
              ),
              const SizedBox(height: 4),
              const Text('Meri\nLocation',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
              const SizedBox(height: 10),
              FloatingActionButton.small(
                heroTag: 'droppin',
                onPressed: () => setState(() => _dropArmed = !_dropArmed),
                backgroundColor: _dropArmed ? Brand.gold : Colors.white,
                foregroundColor: Brand.green,
                child: const Icon(Icons.add_location_alt),
              ),
              const SizedBox(height: 4),
              const Text('Drop\nPin',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
              const SizedBox(height: 10),
              FloatingActionButton.small(
                heroTag: 'mapstyle',
                onPressed: () => setState(() => _satellite = !_satellite),
                backgroundColor: _satellite ? Brand.gold : Colors.white,
                foregroundColor: Brand.green,
                child: const Icon(Icons.layers),
              ),
              const SizedBox(height: 4),
              const Text('Map\nStyle',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Brand.greenDark)),
            ],
          ),
        ),
        Positioned(
          top: 10,
          left: 12,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.92),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Brand.gold),
            ),
            child: const Text(
              'Pickup: map par tap karein\nDrop: lamba dabayein ya Drop Pin button se',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
            ),
          ),
        ),
        // Booking sheet overlaid on the map — Careem style safed sheet
        // (v1.0.8): gol kinare, halki parchhai, andar drag handle.
        Positioned(
          left: 10,
          right: 10,
          bottom: 10,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(26),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.22),
                  blurRadius: 18,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: ConstrainedBox(
              constraints: BoxConstraints(maxHeight: size.height * 0.55),
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
                child: _bookingForm(),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _bookingForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Sheet ka drag handle (Careem style safed sheet, v1.0.8).
        Center(
          child: Container(
            width: 44,
            height: 5,
            decoration: BoxDecoration(
              color: Brand.fieldBorder,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Text('Kahan jana hai?',
            style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w900,
                color: Brand.greenDark)),
        const SizedBox(height: 4),
        const Text(
          'Pehle manzil (drop) chunein, phir pickup jagah. Kul kiraya booking pakki hone ke baad samne aayega — kiraya pakka hai, koi mol-bhav nahi.',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 12),
        // Drop / Pickup — Careem style: ek saaf card, dot-line markers,
        // manzil (drop) PEHLE, pickup doosra.
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Brand.fieldBorder),
          ),
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 4),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  const SizedBox(height: 17),
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: Brand.ajrakRed,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                  Container(
                    width: 2,
                    height: 36,
                    color: Brand.fieldBorder,
                  ),
                  Container(
                    width: 12,
                    height: 12,
                    decoration: const BoxDecoration(
                      color: Brand.green,
                      shape: BoxShape.circle,
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  children: [
                    TextField(
                      controller: _dropCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Drop jagah (manzil)',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                    const Divider(height: 1, color: Brand.fieldBorder),
                    TextField(
                      controller: _pickupCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Pickup jagah',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        const Text('Qareebi Jagahen',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 4),
        const Text(
          'Kisi zone par tap karein — wohi aap ki manzil (drop) ban jayegi.',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 6),
        // Backend zones: Master ne jo ilaqa band kiya ho woh is list
        // mein nahi ata; server na mile to local kZones hi dikhte hain.
        ...store.zoneNames.map((z) => _zoneRow(z)),
        const SizedBox(height: 8),
        Row(
          children: [
            const Text('Save jagah: ',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            ActionChip(
              label: const Text('Ghar'),
              onPressed: () => _applyPlace(true),
            ),
            const SizedBox(width: 6),
            ActionChip(
              label: const Text('Daftar'),
              onPressed: () => _applyPlace(false),
            ),
            const Spacer(),
            TextButton.icon(
              onPressed: () => _savePlace(true),
              icon: const Icon(Icons.edit, size: 15),
              label: const Text('Ghar set', style: TextStyle(fontSize: 12)),
            ),
            TextButton.icon(
              onPressed: () => _savePlace(false),
              icon: const Icon(Icons.edit, size: 15),
              label: const Text('Daftar set', style: TextStyle(fontSize: 12)),
            ),
          ],
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _nameCtrl,
          decoration: const InputDecoration(
              labelText: 'Aap ka naam', prefixIcon: Icon(Icons.person)),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _phoneCtrl,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
              labelText: 'Mobile number', prefixIcon: Icon(Icons.phone)),
        ),
        const SizedBox(height: 14),
        const Text('Ride ki Tafseel',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 8),
        ...kVehicles.map((v) => _vehicleRow(
              vehicle: v,
              selected: _vehicle == v,
              onTap: () => setState(() => _vehicle = v),
            )),
        // Safar ki doori (v1.2.2) — SIRF maloomat hai, kiraya nahi:
        // wohi _fareKm jo kiraaye ki bunyaad hai (route ki sadak wali
        // doori; route load hone se pehle seedhi doori). Drop pin lagte
        // hi nazar aati hai aur route aate hi khud update ho jati hai.
        // Kiraya (Rs) booking se pehle kahin NAHI dikhta — lock barkarar.
        if (_drop != null) ...[
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.route, size: 16, color: Brand.green),
              const SizedBox(width: 6),
              Text(
                'Safar ki doori: ${_fareKm.toStringAsFixed(1)} km',
                style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Brand.greenDark),
              ),
            ],
          ),
        ],
        const SizedBox(height: 6),
        TextField(
          controller: _noteCtrl,
          decoration: const InputDecoration(
            labelText: 'Driver ke liye note (gate number, samaan, bacche...)',
            prefixIcon: Icon(Icons.note_alt),
          ),
        ),
        const SizedBox(height: 10),
        // Waiting note — sirf ek halki si line (koi number/price nahi).
        const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.schedule, size: 15, color: Colors.black45),
            SizedBox(width: 6),
            Expanded(
              child: Text(
                'Driver ke pohanchnay ke baad thora intezaar bilkul muft hai — zyada intezaar par munasib waiting charges kul kiraya mein shamil ho jayenge.',
                style: TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        // EK bara full-width button — Careem ke "CHALO!" wali jagah par,
        // Safar ke apne gehre sabz rang mein.
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: _confirmBooking,
            style: ElevatedButton.styleFrom(
              backgroundColor: Brand.deepGreen,
              padding: const EdgeInsets.symmetric(vertical: 17),
              textStyle:
                  const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
            ),
            child: const Text('Ride Pakki Karein'),
          ),
        ),
        Center(
          child: TextButton(
            onPressed: _clearBookingForm,
            child: const Text('Rehne Dein'),
          ),
        ),
      ],
    );
  }

  // --- Meri Bookings ---------------------------------------------------------

  Future<void> _shareRide(Booking b) async {
    final p = store.profile;
    final text = 'Safar ride share:\n'
        'Driver: ${p.name} (${p.vehicle}${p.plate.isEmpty ? '' : ' · ${p.plate}'})\n'
        'Route: ${b.pickupLabel} → ${b.dropLabel}\n'
        'Kul kiraya: ${rs(b.total)}\n'
        'Waqt: ${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)}';
    final uri = Uri.parse('https://wa.me/?text=${Uri.encodeComponent(text)}');
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) _snack('WhatsApp nahi khul saka.');
  }

  Future<void> _callDriver() async {
    final phone = store.profile.phone.trim();
    if (phone.isEmpty) {
      _snack('Driver ka number abhi set nahi hai.');
      return;
    }
    final ok = await launchUrl(Uri.parse('tel:$phone'));
    if (!ok && mounted) _snack('Call nahi ho saki.');
  }

  /// Master ko Message screen (v1.2.7) — "Meri Bookings" ke neeche
  /// wale darwaze se khulti hai; booking wali screen/flow bilkul
  /// nahi chheri gayi (display lock).
  Future<void> _openMessages() async {
    await Navigator.of(context).push(
      MaterialPageRoute<bool>(
        builder: (_) => MasterMessagesScreen(store: store, role: 'passenger'),
      ),
    );
    if (mounted) setState(() {});
  }

  Widget _myBookingsView() {
    return Column(
      children: [
        // Master ko Message (v1.2.7): masla/shikayat seedha Master
        // (head) ko — hamesha nazar ane wala darwaza, bookings hon
        // ya na hon.
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
          child: Card(
            margin: EdgeInsets.zero,
            child: ListTile(
              leading: const Icon(Icons.mail_outline, color: Brand.green),
              title: const Text('Master ko Message',
                  style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text(
                  'Koi masla ya shikayat ho to seedha Master (head) ko message bhejein.'),
              trailing: const Icon(Icons.chevron_right),
              onTap: _openMessages,
            ),
          ),
        ),
        Expanded(child: _myBookingsList()),
      ],
    );
  }

  Widget _myBookingsList() {
    final list = store.bookings;
    if (list.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Abhi koi booking nahi hai.\nBooking wale hisse se pehli ride pakki karein.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15, color: Colors.black54),
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: list.length,
      itemBuilder: (context, i) {
        final b = list[i];
        final p = store.profile;
        final confirmed = b.status == 'accepted' || b.status == 'arrived';
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.route, color: Brand.green),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text('${b.pickupLabel} → ${b.dropLabel}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 15)),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  '${b.vehicle} · ${fmtDate(b.createdAt)} ${fmtTime(b.createdAt)}',
                  style: const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                if (b.note.isNotEmpty)
                  Text('Note: ${b.note}',
                      style: const TextStyle(fontSize: 12)),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Chip(
                      label: Text(kStatusUrdu[b.status] ?? b.status),
                      backgroundColor: confirmed
                          ? const Color(0xFFDFF5E6)
                          : b.status == 'completed'
                              ? const Color(0xFFE8F0FE)
                              : const Color(0xFFF3E9C8),
                      labelStyle: const TextStyle(fontSize: 12),
                    ),
                    const Spacer(),
                    Text(rs(b.total),
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 17)),
                  ],
                ),
                if (b.status == 'completed')
                  Text(
                    'Total kiraya: ${rs(b.total)} · Doori: ${b.distanceKm.toStringAsFixed(1)} km',
                    style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                if (confirmed) ...[
                  const Divider(),
                  const Text('Driver ki Pehchan',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text(
                      '${p.name} · ${p.vehicle}${p.plate.isEmpty ? '' : ' · Plate ${p.plate}'} · ${p.zone}'),
                  const Text(
                    'Driver CNIC-verified hai aur har booking record mein hai.',
                    style: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                  _DriverEtaLine(store: store, booking: b),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _callDriver,
                          icon: const Icon(Icons.call, size: 18),
                          label: const Text('Madad — Driver ko call karein'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Brand.ajrakRed,
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            textStyle: const TextStyle(
                                fontSize: 13, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () => _shareRide(b),
                      icon: const Icon(Icons.share, size: 18),
                      label: const Text('Ride ghar walon ko WhatsApp karein'),
                    ),
                  ),
                ],
                if (b.status == 'pending')
                  const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text(
                      'Booking driver ko bheji gayi hai — Driver Mode mein is ka jawab ayega.',
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  // --- Monthly package ---------------------------------------------------------

  bool get _monthlyReady =>
      _mPickupCtrl.text.trim().isNotEmpty &&
      _mDropCtrl.text.trim().isNotEmpty;

  int get _monthlyTotal =>
      Fares.monthlyAmount(_mVehicle, _mRouteKm, _mDays);

  Future<void> _confirmMonthly() async {
    if (!_monthlyReady) {
      _snack('Rozana pickup aur rozana drop dono likhein.');
      return;
    }
    final pkg = MonthlyPackage(
      id: store.newId(),
      passengerName: _nameCtrl.text.trim(),
      pickup: _mPickupCtrl.text.trim(),
      drop: _mDropCtrl.text.trim(),
      vehicle: _mVehicle,
      routeKm: _mRouteKm,
      days: _mDays,
      monthlyAmount: _monthlyTotal,
      createdAt: DateTime.now(),
    );
    await store.addMonthly(pkg);
    if (!mounted) return;
    // Kul monthly raqam PEHLI dafa yahin nazar aati hai — package pakka
    // hone ke BAAD (owner ka lock, v1.0.7). Form mein koi amount nahi.
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Brand.green, size: 26),
            SizedBox(width: 8),
            Text('Package Pakka Ho Gaya'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('${pkg.pickup} → ${pkg.drop}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text('${pkg.vehicle} · ${pkg.days} din',
                style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Brand.deepGreen,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                children: [
                  const Text('KUL MONTHLY RAQAM',
                      style: TextStyle(
                          color: Brand.goldLight,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.2)),
                  Text(rs(pkg.monthlyAmount),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 30,
                          fontWeight: FontWeight.w900)),
                ],
              ),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Theek Hai'),
          ),
        ],
      ),
    );
    if (!mounted) return;
    setState(() {});
  }

  void _clearMonthly() {
    setState(() {
      _mPickupCtrl.clear();
      _mDropCtrl.clear();
      _mVehicle = 'Rickshaw';
      _mRouteKm = 2.0;
      _mDays = 26;
    });
    _snack('Koi package nahi bana — sab saaf kar diya gaya.');
  }

  Widget _monthlyView() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text('Monthly Package',
            style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w900,
                color: Brand.greenDark)),
        const SizedBox(height: 4),
        const Text(
          'Rickshaw / gaari mahine ke liye pakki karein — school, office ya madrassa ke liye rozana wohi pehchana driver, wohi jagah, wohi waqt.',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _mPickupCtrl,
          decoration: const InputDecoration(
              labelText: 'Rozana PICKUP jagah',
              prefixIcon: Icon(Icons.home)),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _mDropCtrl,
          decoration: const InputDecoration(
              labelText: 'Rozana DROP jagah',
              prefixIcon: Icon(Icons.school)),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 10),
        const Text('Gaari',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        const SizedBox(height: 8),
        ...kVehicles.map((v) => _vehicleRow(
              vehicle: v,
              selected: _mVehicle == v,
              onTap: () => setState(() => _mVehicle = v),
            )),
        const SizedBox(height: 4),
        const Text('Mahine mein kitne din?',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: _dayChips
              .map((d) => ChoiceChip(
                    label: Text('$d din'),
                    selected: _mDays == d,
                    onSelected: (_) => setState(() => _mDays = d),
                  ))
              .toList(),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: _confirmMonthly,
                child: const Text('Monthly Package Pakka Karein'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton(
                onPressed: _clearMonthly,
                child: const Text('Rehne Dein'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        const Text('Mere Monthly Packages',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (store.monthlyPackages.isEmpty)
          const Text('Abhi koi monthly package nahi hai.',
              style: TextStyle(color: Colors.black54)),
        ...store.monthlyPackages.map((p) => Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: const Icon(Icons.calendar_month, color: Brand.green),
                title: Text('${p.pickup} → ${p.drop}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(
                    '${p.vehicle} · ${p.days} din · ${fmtDate(p.createdAt)}'),
                trailing: Text(rs(p.monthlyAmount),
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 15)),
              ),
            )),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// "Driver Dhoonda Ja Raha Hai" — Careem ki "Finding your Captain" style
// screen (v1.0.8). Ye booking ki HALAT wali screen hai: booking darj ho
// chuki hai aur driver ke jawab ka intezaar hai — koi jhooti driver
// assignment nahi dikhayi jati. Pops with 'bookings' ya 'cancelled'.
// ---------------------------------------------------------------------------

class _FindingDriverView extends StatelessWidget {
  final AppStore store;
  final Booking booking;
  const _FindingDriverView({required this.store, required this.booking});

  IconData _vehicleIcon(String v) => v == 'Car'
      ? Icons.directions_car
      : v == 'Bike'
          ? Icons.two_wheeler
          : Icons.electric_rickshaw;

  Future<void> _callDriver(BuildContext context) async {
    final phone = store.profile.phone.trim();
    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Driver ka number abhi set nahi hai.')),
      );
      return;
    }
    final ok = await launchUrl(Uri.parse('tel:$phone'));
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Call nahi ho saki.')),
      );
    }
  }

  Future<void> _showCancelSheet(BuildContext context) async {
    const reasons = [
      'Ab ride nahi chahiye',
      'Booking ki tafseel badalni hai',
      'Bohat dair ho gayi hai',
      'Koi aur wajah',
    ];
    var selected = -1;
    final confirmed = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetCtx) => StatefulBuilder(
        builder: (sheetCtx, setSheetState) => Padding(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 5,
                  decoration: BoxDecoration(
                    color: Brand.fieldBorder,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              const Text('Ride kyun mansookh kar rahe hain?',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w900,
                      color: Brand.greenDark)),
              const SizedBox(height: 8),
              ...reasons.asMap().entries.map((e) {
                final isSel = selected == e.key;
                return InkWell(
                  onTap: () => setSheetState(() => selected = e.key),
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 11),
                    child: Row(
                      children: [
                        Container(
                          width: 22,
                          height: 22,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: isSel
                                  ? Brand.green
                                  : const Color(0xFFB9CFC6),
                              width: 2,
                            ),
                          ),
                          child: isSel
                              ? Center(
                                  child: Container(
                                    width: 11,
                                    height: 11,
                                    decoration: const BoxDecoration(
                                      color: Brand.green,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                )
                              : null,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(e.value,
                              style: const TextStyle(fontSize: 15)),
                        ),
                      ],
                    ),
                  ),
                );
              }),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: selected < 0
                      ? null
                      : () => Navigator.pop(sheetCtx, true),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFDFF5E6),
                    foregroundColor: Brand.greenDark,
                    disabledBackgroundColor: Brand.lightBg,
                    disabledForegroundColor: Colors.black38,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    textStyle: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800),
                  ),
                  child: const Text('Jama Karein (Submit)'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (confirmed == true && context.mounted) {
      await store.cancelBooking(booking);
      if (context.mounted) Navigator.pop(context, 'cancelled');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final b = booking;
        final pickup = LatLng(b.pickupLat, b.pickupLng);
        final drop = LatLng(b.dropLat, b.dropLng);
        final searching = b.status == 'pending';
        final title = searching
            ? 'Driver Dhoonda Ja Raha Hai'
            : (kStatusUrdu[b.status] ?? b.status);
        return Scaffold(
          body: Stack(
            children: [
              Positioned.fill(
                child: SafarRouteMap(
                  pickup: pickup,
                  drop: b.hasDropPin ? drop : null,
                  interactive: true,
                ),
              ),
              // Safed sheet — Careem style, gol upar kinare + drag handle.
              Positioned(
                left: 10,
                right: 10,
                bottom: 10,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(26),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.22),
                        blurRadius: 18,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Center(
                        child: Container(
                          width: 44,
                          height: 5,
                          decoration: BoxDecoration(
                            color: Brand.fieldBorder,
                            borderRadius: BorderRadius.circular(3),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(title,
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              color: Brand.greenDark)),
                      if (searching) ...[
                        const SizedBox(height: 10),
                        const _FindingProgressLine(),
                        const SizedBox(height: 8),
                        const Text(
                          'Booking darj ho gayi hai — driver ke jawab ka intezaar karein.',
                          style:
                              TextStyle(fontSize: 12.5, color: Colors.black54),
                        ),
                      ] else ...[
                        const SizedBox(height: 4),
                        const Text(
                          'Booking ki halat upar likhi hai — tafseel neeche dekhein.',
                          style:
                              TextStyle(fontSize: 12.5, color: Colors.black54),
                        ),
                      ],
                      const SizedBox(height: 14),
                      // Route dots: grey = pickup, green = drop.
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            children: [
                              const SizedBox(height: 3),
                              Container(
                                width: 11,
                                height: 11,
                                decoration: const BoxDecoration(
                                  color: Colors.grey,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              Container(
                                width: 2,
                                height: 26,
                                color: Brand.fieldBorder,
                              ),
                              Container(
                                width: 11,
                                height: 11,
                                decoration: const BoxDecoration(
                                  color: Brand.green,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(b.pickupLabel,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14)),
                                const SizedBox(height: 20),
                                Text(b.dropLabel,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      const Text('Booking ki Tafseel',
                          style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                              color: Colors.black54)),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(_vehicleIcon(b.vehicle),
                              color: Brand.green, size: 26),
                          const SizedBox(width: 10),
                          Text(b.vehicle,
                              style: const TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w800)),
                          const Spacer(),
                          const Text('Total Kiraya: ',
                              style: TextStyle(
                                  fontSize: 13, color: Colors.black54)),
                          Text(rs(b.total),
                              style: const TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w900)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      _DriverEtaLine(store: store, booking: b),
                      InkWell(
                        onTap: () => _callDriver(context),
                        borderRadius: BorderRadius.circular(10),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 6),
                          child: Row(
                            children: [
                              Icon(Icons.headset_mic,
                                  color: Brand.ajrakRed, size: 21),
                              SizedBox(width: 10),
                              Text('Madad Chahiye?',
                                  style: TextStyle(
                                      color: Brand.ajrakRed,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 14)),
                              Spacer(),
                              Icon(Icons.call,
                                  color: Brand.ajrakRed, size: 18),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () =>
                              Navigator.pop(context, 'bookings'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Brand.deepGreen,
                            padding:
                                const EdgeInsets.symmetric(vertical: 15),
                          ),
                          child: const Text('Meri Bookings Dekhein'),
                        ),
                      ),
                      if (searching)
                        Center(
                          child: TextButton(
                            onPressed: () => _showCancelSheet(context),
                            style: TextButton.styleFrom(
                              foregroundColor: Brand.ajrakRed,
                            ),
                            child: const Text('Ride Mansookh Karein'),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Searching wali sabz progress line — bharti hui animation.
class _FindingProgressLine extends StatefulWidget {
  const _FindingProgressLine();

  @override
  State<_FindingProgressLine> createState() => _FindingProgressLineState();
}

class _FindingProgressLineState extends State<_FindingProgressLine>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1500),
  )..repeat();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(4),
      child: Container(
        height: 4,
        color: Brand.fieldBorder,
        alignment: Alignment.centerLeft,
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (context, _) => FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: 0.12 + 0.88 * _ctrl.value,
            child: Container(color: Brand.green),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Driver ki doori + aane ka waqt (ETA) — v1.2.4. Sirf ACCEPTED booking
// par dikhta hai (driver tay ho chuka aur aa raha hai); us se pehle
// (pending/searching) kuch nahi — booking se pehle wali "koi maloomat
// nahi" wali lock bilkul barkarar hai.
//
// Doori = driver ki akhri maloom GPS jagah (DriverProfile.lastLat/lng,
// jo Driver Mode ke refresh/qubool/nav-stream se taza hoti hai) se
// pickup tak ki seedhi doori (latlong Distance, 1 decimal km).
// Waqt = pehle OSRM route ka asal duration (RouteService cache/fetch,
// driver → pickup), woh na mile to sheher ki ausat raftaar se andaza
// (neeche wale INTERNAL constants; kabhi display nahi hote):
// Rickshaw 20, Bike 30, Car 25 km/h. Minute hamesha UP round, kam az
// kam 1. Koi jhoota countdown nahi — value sirf position/store ke
// taza hone par badalti hai.
// Driver ki position maloom hi na ho to saaf likha ata hai ke
// location jald nazar aayegi — koi number nahi banaya jata.
// ---------------------------------------------------------------------------

const Map<String, double> _kEtaCitySpeedKmh = {
  'Rickshaw': 20,
  'Bike': 30,
  'Car': 25,
};

class _DriverEtaLine extends StatefulWidget {
  final AppStore store;
  final Booking booking;
  const _DriverEtaLine({required this.store, required this.booking});

  @override
  State<_DriverEtaLine> createState() => _DriverEtaLineState();
}

class _DriverEtaLineState extends State<_DriverEtaLine> {
  String _sig = '';
  int? _osrmEtaMin;

  Booking get b => widget.booking;
  AppStore get store => widget.store;

  /// Driver ki jagah maloom ho aur booking ke paas pickup pin ho to
  /// seedhi doori (km); warna null (= koi number nahi dikhana).
  double? _driverKm() {
    final lat = store.profile.lastLat;
    final lng = store.profile.lastLng;
    if (lat == null || lng == null) return null;
    if (b.pickupLat == 0 && b.pickupLng == 0) return null;
    return const Distance().as(LengthUnit.Kilometer, LatLng(lat, lng),
        LatLng(b.pickupLat, b.pickupLng));
  }

  /// Is hisaab ki pehchan — booking, us ki halat, driver ki jagah
  /// (3 decimal tak) aur pickup. In mein se kuch badle to ETA dobara
  /// gina jata hai; warna purani value hi rehti hai (churn nahi).
  String _sigNow() {
    final lat = store.profile.lastLat;
    final lng = store.profile.lastLng;
    final pos = (lat == null || lng == null)
        ? 'none'
        : '${lat.toStringAsFixed(3)},${lng.toStringAsFixed(3)}';
    return '${b.id}|${b.status}|$pos|'
        '${b.pickupLat.toStringAsFixed(3)},${b.pickupLng.toStringAsFixed(3)}';
  }

  int _speedEtaMin(double km) {
    final speed = _kEtaCitySpeedKmh[b.vehicle] ?? 20;
    final mins = (km / speed * 60).ceil();
    return mins < 1 ? 1 : mins;
  }

  Future<void> _resolve() async {
    final sig = _sig;
    final lat = store.profile.lastLat;
    final lng = store.profile.lastLng;
    if (lat == null || lng == null) return;
    if (b.pickupLat == 0 && b.pickupLng == 0) return;
    try {
      final r = await RouteService.fetch(
          LatLng(lat, lng), LatLng(b.pickupLat, b.pickupLng));
      if (!mounted || _sig != sig) return;
      if (!r.isStraightFallback && r.durationS > 0) {
        final mins = (r.durationS / 60).ceil();
        setState(() => _osrmEtaMin = mins < 1 ? 1 : mins);
      }
    } catch (_) {
      // Khamosh — raftaar wala andaza hi rehta hai.
    }
  }

  @override
  void initState() {
    super.initState();
    _sig = _sigNow();
    unawaited(_resolve());
  }

  @override
  void didUpdateWidget(_DriverEtaLine oldWidget) {
    super.didUpdateWidget(oldWidget);
    final now = _sigNow();
    if (now != _sig) {
      _sig = now;
      _osrmEtaMin = null;
      unawaited(_resolve());
    }
  }

  @override
  Widget build(BuildContext context) {
    // Sirf tab jab driver tay ho aur aa raha ho. Arrived par driver
    // pohanch chuka hota hai — wahan halat wali line hi kaafi hai.
    if (b.status != 'accepted') return const SizedBox.shrink();
    final km = _driverKm();
    if (km == null) {
      return const Padding(
        padding: EdgeInsets.only(bottom: 10),
        child: Row(
          children: [
            Icon(Icons.near_me, size: 17, color: Colors.black45),
            SizedBox(width: 6),
            Expanded(
              child: Text('Driver ki location jald nazar aayegi',
                  style: TextStyle(fontSize: 13.5, color: Colors.black54)),
            ),
          ],
        ),
      );
    }
    final eta = _osrmEtaMin ?? _speedEtaMin(km);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          const Icon(Icons.near_me, size: 17, color: Brand.green),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              'Driver ${km.toStringAsFixed(1)} km door hai · '
              'Takreeban $eta minute mein pahunchega',
              style: const TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w800,
                  color: Brand.greenDark),
            ),
          ),
        ],
      ),
    );
  }
}
