import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'backend.dart';
import 'route_service.dart';
import 'store.dart';
import 'theme.dart';

/// =====================================================================
/// SELF-REPAIR / HEALTH ENGINE (P+D v1.4.26 — malik ka hukm
/// 2026-11-11: "app ke andar bhi aur master app ke andar bhi koi
/// aisa engine lagao ki koi bhi kharabi aati hai to yah khud se
/// repair kar le"; Master wala engine v1.4.12 mein bana tha,
/// ye usi design ka P+D roop hai).
///
/// Usool: app khud apni sehat jaanchti hai — backend se rabta,
/// session (passenger device link / driver session) ki haalat,
/// data sync ki taazgi, phone ke andar ke records ki saakht,
/// aur OUTBOX mein atki hui cheezein (registrations, bookings,
/// packages, messages, ratings). Jo kharabi app ke apne
/// ikhtiyar mein hai woh KHAMOSHI se khud theek ho jati hai;
/// har repair ka record sirf app ke andar ke Repair Log mein
/// rehta hai. User ko khabar SIRF tab milti hai jab amal usi
/// ka ho (masalan dobara OTP sign-in) — woh bhi saaf Roman
/// Urdu mein, koi error code KABHI NAHI.
///
/// IMAANDAR HADD: peeche ke system (server policies/settings)
/// ki kharabi app NAHI theek kar sakti. Aisi haalat pehchan
/// kar "App ki Haalat" par saaf likh di jati hai — jhoota
/// "khud theek kar diya" kabhi NAHI banta.
///
/// Koshishein mehdood aur sukoon se: jaanch app khulne par +
/// har ~15 minute (sirf jab app samne ho — background service
/// NAHI), har nakami par zyada se zyada EK backoff wali dobara
/// koshish. Loop mein atakna mumkin NAHI, battery/net par koi
/// mustaqil bojh NAHI.
/// =====================================================================

/// Jaanch ki qismein — "App ki Haalat" par har ek ki alag satar.
enum HealthCheckKind { backend, session, sync, localData, outbox }

/// Ek jaanch ka natija (screen ki ek satar).
class HealthCheckResult {
  final HealthCheckKind kind;

  /// true = saaf; false = kharabi mili (aur is dafa theek nahi
  /// ho saki — jo theek ho jati hai woh [repaired] ke saath
  /// ok aati hai).
  final bool ok;

  /// Is jaanch mein kharabi mili thi lekin engine ne khud
  /// theek kar di.
  final bool repaired;

  /// Screen ki satar (saaf Roman Urdu).
  final String title;

  /// Wajah/hal ki tafseel (saaf alfaaz — koi error code NAHI).
  final String detail;

  /// Hal ke liye user ka amal lazmi hai (masalan dobara OTP
  /// sign-in) — engine akele theek NAHI kar sakta.
  final bool needsUserAction;

  const HealthCheckResult({
    required this.kind,
    required this.ok,
    required this.title,
    required this.detail,
    this.repaired = false,
    this.needsUserAction = false,
  });
}

/// Repair Log ki ek satar — kab, kya kharab tha, kya kiya,
/// natija kya hua. Sirf app ke andar mehfooz rehti hai.
class RepairLogEntry {
  final DateTime at;
  final String problem;
  final String action;
  final bool success;
  const RepairLogEntry({
    required this.at,
    required this.problem,
    required this.action,
    required this.success,
  });

  Map<String, dynamic> toJson() => {
        'at': at.toIso8601String(),
        'problem': problem,
        'action': action,
        'success': success,
      };

  factory RepairLogEntry.fromJson(Map<String, dynamic> j) => RepairLogEntry(
        at: DateTime.tryParse(j['at']?.toString() ?? '') ?? DateTime.now(),
        problem: j['problem']?.toString() ?? '',
        action: j['action']?.toString() ?? '',
        success: j['success'] == true,
      );
}

/// Poori jaanch (+ jo repairs chalein) ka natija.
class HealthReport {
  final DateTime checkedAt;
  final List<HealthCheckResult> checks;

  /// Is dafa ki gayi (ya koshish ki gayi) repairs.
  final List<RepairLogEntry> repairs;

  /// Peeche ke system ki kharabi ka andesha ho to user ke
  /// liye saaf khabar — warna null. Ye SIRF screen/log par
  /// likha jata hai, kahin bheja NAHI jata.
  final String? serverIssueNote;

  const HealthReport({
    required this.checkedAt,
    required this.checks,
    required this.repairs,
    required this.serverIssueNote,
  });

  bool get allOk => checks.every((c) => c.ok);
  int get problemCount => checks.where((c) => !c.ok).length;
  int get repairedCount => checks.where((c) => c.repaired).length;

  /// Kisi jaanch mein user ka amal lazmi hai ya nahi.
  bool get needsUserAction => checks.any((c) => c.needsUserAction);
}

/// Phone ke andar ke mehfooz records ki saakht ki report —
/// [inspectPdStoredData] banata hai (khaalis function, tests
/// seedha parakh sakte hain).
class PdStoreIntegrityReport {
  /// Koi mehfooz record maujood hi hai ya nahi (saari keys
  /// ghayab hon to app abhi taaza hai — kharabi NAHI).
  final bool present;

  /// Kharab mile hisso (prefs keys) ke naam.
  final List<String> badSections;

  const PdStoreIntegrityReport({
    required this.present,
    required this.badSections,
  });

  bool get allOk => badSections.isEmpty;
}

/// Mehfooz data ki section-war jaanch — [raw] mein prefs key
/// → us ki mehfooz string (na ho to null). Usool wahi jo
/// [AppStore.load] ka hai: list wale hisse List hon, profile
/// Map ho, aur bookings/packages ki har satar par buniyadi
/// pehchan (id) maujood ho — is se kamzor data 'kharab' hai.
/// Khaalis function: na prefs parhta hai, na kuch badalta hai.
PdStoreIntegrityReport inspectPdStoredData(Map<String, String?> raw) {
  const listKeys = <String>[
    'bookings',
    'monthly',
    'txns',
    'master_messages',
    'notifications',
    'ratings',
    'push_attempts_v1',
  ];
  const idListKeys = <String>{'bookings', 'monthly'};
  final bad = <String>[];
  var present = false;

  bool sectionBad(String key, String value) {
    try {
      final decoded = jsonDecode(value);
      if (key == 'profile') return decoded is! Map;
      if (decoded is! List) return true;
      if (idListKeys.contains(key)) {
        for (final e in decoded) {
          if (e is! Map) return true;
          final id = e['id'];
          if (id == null || id.toString().isEmpty) return true;
        }
      }
      return false;
    } catch (_) {
      return true;
    }
  }

  for (final key in [...listKeys, 'profile']) {
    final value = raw[key];
    if (value == null) continue;
    present = true;
    if (sectionBad(key, value)) bad.add(key);
  }
  return PdStoreIntegrityReport(present: present, badSections: bad);
}

/// Mehfooz records ke user-ke-liye naam (screen/log mein
/// prefs key NAHI dikhti).
String pdStoreSectionLabel(String key) {
  switch (key) {
    case 'bookings':
      return 'bookings ka record';
    case 'monthly':
      return 'monthly packages ka record';
    case 'txns':
      return 'hisaab (wallet) ka record';
    case 'profile':
      return 'driver profile ka record';
    case 'master_messages':
      return 'Master messages ka record';
    case 'notifications':
      return 'notifications ka record';
    case 'ratings':
      return 'ratings ka record';
    case 'push_attempts_v1':
      return 'push koshishon ka record';
    default:
      return 'ek record';
  }
}

/// Jaanch/repair ke asal raste — default [Backend]/[AppStore]
/// se bante hain; tests nakli raste de kar engine ki logic
/// parakh sakte hain (na network chalta hai, na phone).
class HealthHooks {
  /// Backend tak halki parhai (settings_public ki ek row).
  final Future<bool> Function() probeBackend;

  /// Session ki asal haalat (hasSession/valid/canRefresh).
  final Future<BackendSessionState> Function() sessionState;

  /// Session taaza karne ki seedhi koshish — kamyabi par true.
  final Future<bool> Function() refreshSession;

  /// Backend se aakhri kamyab data parhai ka waqt (ms; 0 =
  /// is run mein abhi koi nahi hui).
  final int Function() lastFetchOkMs;

  /// Is phone par account ka nishan hai (driver registration
  /// mukammal ya passenger email verified) — ho to session ka
  /// ghayab/mara hona asal masla hai; na ho to aam haalat hai.
  final bool Function() accountFootprint;

  /// Taaza data pull (settings + driver status) — kamyabi
  /// par true.
  final Future<bool> Function() syncNow;

  /// Phone ke andar ke records ki saakht ki jaanch.
  final Future<PdStoreIntegrityReport> Function() inspectLocalData;

  /// Kharab local records ki repair (mehfooz copy dobara
  /// likhna) — repair hue hisso ki ginti.
  final Future<int> Function() repairLocalData;

  /// Route cache ke kharab entries ki safai — hataye gaye
  /// entries ki ginti.
  final Future<int> Function() pruneRouteCache;

  /// Outbox mein atki cheezon ki ginti.
  final Future<({int rides, int packages, int messages, int ratings})>
      Function() outboxCounts;

  /// Outbox ki ek dafa dobara koshish (maujooda sync raste).
  final Future<void> Function() retryOutbox;

  const HealthHooks({
    required this.probeBackend,
    required this.sessionState,
    required this.refreshSession,
    required this.lastFetchOkMs,
    required this.accountFootprint,
    required this.syncNow,
    required this.inspectLocalData,
    required this.repairLocalData,
    required this.pruneRouteCache,
    required this.outboxCounts,
    required this.retryOutbox,
  });

  factory HealthHooks.forStore(AppStore store) => HealthHooks(
        probeBackend: Backend.probeBackendReachable,
        sessionState: Backend.sessionState,
        refreshSession: Backend.tryRefreshSession,
        lastFetchOkMs: () => Backend.lastFetchOkMs,
        accountFootprint: () =>
            store.profile.registrationComplete || store.passengerEmailVerified,
        syncNow: () async {
          final ok = await Backend.refreshSettingsChecked();
          await Backend.refreshDriverStatus(store);
          return ok;
        },
        inspectLocalData: () async {
          final prefs = await SharedPreferences.getInstance();
          final raw = <String, String?>{};
          for (final key in const [
            'bookings',
            'monthly',
            'txns',
            'master_messages',
            'notifications',
            'ratings',
            'push_attempts_v1',
            'profile',
          ]) {
            raw[key] = prefs.getString(key);
          }
          return inspectPdStoredData(raw);
        },
        repairLocalData: () async {
          var repaired = await store.repairLocalStores();
          // pushLog store ka hissa NAHI hai — us ki kharab
          // copy seedha hata di jati hai (asal record backend
          // par hai, ye sirf koshishon ki jhalak hai)।
          try {
            final prefs = await SharedPreferences.getInstance();
            final raw = prefs.getString('push_attempts_v1');
            if (raw != null &&
                inspectPdStoredData({'push_attempts_v1': raw})
                    .badSections
                    .isNotEmpty) {
              await prefs.remove('push_attempts_v1');
              repaired++;
            }
          } catch (_) {
            // Safai na bhi ho to repair ka hisaab rukta nahi.
          }
          return repaired;
        },
        pruneRouteCache: RouteService.pruneCorruptCache,
        outboxCounts: () => Backend.outboxPendingCounts(store),
        retryOutbox: () => Backend.retryOutboxNow(store),
      );
}

String _fmtTime(DateTime t) =>
    '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

String _fmtDateTime(DateTime t) => '${t.day}/${t.month}/${t.year} ${_fmtTime(t)}';

/// Asal engine — ChangeNotifier, taake "App ki Haalat" wali
/// satar aur screen is ki khabar par khud taaza ho jayein.
class HealthEngine extends ChangeNotifier {
  static const String _kLogKey = 'bs_repair_log_v1';
  static const int _maxLogEntries = 50;

  /// Data parhai is se purani ho to 'purani' ginati hai aur
  /// engine khud taaza karne ki koshish karta hai.
  static const Duration staleSyncAfter = Duration(minutes: 30);

  /// Nakami par dobara koshish se pehle ki mohlat (backoff) —
  /// is ke baad agli koshish agli scheduled jaanch (~15 min)
  /// mein hogi. Tests isay ghata sakte hain.
  static Duration retryDelay = const Duration(seconds: 5);

  final HealthHooks hooks;
  HealthEngine(this.hooks);

  HealthReport? lastReport;
  DateTime? lastRunAt;
  bool running = false;

  /// Repair Log — taaza pehle, had [_maxLogEntries].
  final List<RepairLogEntry> repairLog = [];

  Timer? _timer;
  Timer? _firstTimer;
  bool _started = false;
  Future<HealthReport>? _inFlight;

  /// Khud-kar jaanch shuru: pehli jaanch chand lamhon baad
  /// (taake app start wale pehle sync ko mauqa mil jaye),
  /// phir har ~15 minute — sirf jab tak app samne zinda hai;
  /// background service NAHI hai, battery/net par koi
  /// mustaqil bojh NAHI. Dono timers [stop] se band hote
  /// hain (app ke root widget ke dispose par).
  void start() {
    if (_started) return;
    _started = true;
    _firstTimer = Timer(const Duration(seconds: 20), () {
      if (_started) unawaited(runNow());
    });
    _timer = Timer.periodic(
        const Duration(minutes: 15), (_) => unawaited(runNow()));
  }

  void stop() {
    _started = false;
    _firstTimer?.cancel();
    _firstTimer = null;
    _timer?.cancel();
    _timer = null;
  }

  /// App wapas samne aye to — aakhri jaanch purani ho (ya
  /// kabhi na hui ho) to dobara jaanch. Har resume par NAHI
  /// (bojh ki hadd barkarar).
  void onResume() {
    final last = lastRunAt;
    if (last == null ||
        DateTime.now().difference(last) > const Duration(minutes: 15)) {
      unawaited(runNow());
    }
  }

  /// Mehfooz Repair Log load karna (app start par).
  Future<void> loadLog() async {
    try {
      final sp = await SharedPreferences.getInstance();
      final raw = sp.getString(_kLogKey);
      if (raw == null) return;
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        repairLog
          ..clear()
          ..addAll([
            for (final e in decoded)
              if (e is Map)
                RepairLogEntry.fromJson(Map<String, dynamic>.from(e)),
          ]);
        notifyListeners();
      }
    } catch (_) {
      // Log kharab ho to khaali se shuru — app kabhi nahi rukti.
    }
  }

  Future<void> _appendLog(RepairLogEntry entry) async {
    repairLog.insert(0, entry);
    if (repairLog.length > _maxLogEntries) {
      repairLog.removeRange(_maxLogEntries, repairLog.length);
    }
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString(
          _kLogKey, jsonEncode(repairLog.map((e) => e.toJson()).toList()));
    } catch (_) {
      // Log save na bhi ho to jaanch nahi rukti.
    }
    notifyListeners();
  }

  /// Poori jaanch + mumkin repairs. Pehle se chal rahi ho to
  /// wohi koshish wapas (dobara hammer NAHI — backoff wala
  /// usool har satah par).
  Future<HealthReport> runNow() {
    final f = _inFlight;
    if (f != null) return f;
    final fut = _run();
    _inFlight = fut;
    fut.whenComplete(() {
      if (identical(_inFlight, fut)) _inFlight = null;
    });
    return fut;
  }

  Future<HealthReport> _run() async {
    running = true;
    notifyListeners();
    final repairs = <RepairLogEntry>[];

    Future<void> log(String problem, String action, bool success) async {
      final e = RepairLogEntry(
          at: DateTime.now(), problem: problem, action: action, success: success);
      repairs.add(e);
      await _appendLog(e);
    }

    try {
      // Sync taazgi ka faisla IS run ki pehli parhai se PEHLE
      // ke waqt par hoga — apni hi probe ko taazgi ka saboot
      // NAHI banayenge.
      final fetchBeforeMs = hooks.lastFetchOkMs();

      // Qadam 1: backend rabta.
      var backendOk = false;
      try {
        backendOk = await hooks.probeBackend();
      } catch (_) {
        backendOk = false;
      }

      // Qadam 2: session ki asal haalat — purana ho to
      // khamoshi se refresh ki koshish; kamyab ho jaye to
      // user ko koi khabar NAHI.
      var sessionOk = false;
      var sessionRepaired = false;
      var sessionNeedsUser = false;
      String sessionDetail;
      BackendSessionState? sess;
      try {
        sess = await hooks.sessionState();
      } catch (_) {
        sess = null;
      }
      if (sess == null) {
        sessionDetail =
            'Session ki jaanch nahi ho saki — agli jaanch mein dobara koshish hogi.';
      } else if (sess.valid) {
        sessionOk = true;
        sessionDetail = 'Login session durust hai — pehchan mehfooz hai.';
      } else if (sess.hasSession && sess.canRefresh) {
        var refreshed = false;
        try {
          refreshed = await hooks.refreshSession();
        } catch (_) {
          refreshed = false;
        }
        if (refreshed) {
          sessionOk = true;
          sessionRepaired = true;
          sessionDetail = 'Session purana ho gaya tha — khud taaza kar diya gaya hai.';
          await log(
            'Login session ki muddat khatam ho gayi thi',
            'Khud refresh kar ke session taaza kar diya',
            true,
          );
        } else {
          sessionNeedsUser = true;
          sessionDetail =
              'Session khatam ho gaya hai aur khud taaza nahi ho saka — dobara OTP se sign-in karna hoga (Profile tab mein apni email se OTP mangwayein). Baghair is ke kuch backend wale kaam ruk sakte hain.';
          await log(
            'Login session khatam ho gaya tha',
            'Khud taaza karne ki koshish ki — nakam rahi; dobara OTP sign-in chahiye',
            false,
          );
        }
      } else if (sess.hasSession) {
        // Refresh token hi maujood nahi — session asal mein
        // mar chuka hai.
        sessionNeedsUser = true;
        sessionDetail =
            'Session khatam ho gaya hai — dobara OTP se sign-in karna hoga (Profile tab mein apni email se OTP mangwayein).';
      } else if (hooks.accountFootprint()) {
        // Account ka nishan hai lekin session ghayab hai —
        // ye aam haalat NAHI hai.
        sessionNeedsUser = true;
        sessionDetail =
            'Is phone par aap ka account hai lekin login session mehfooz nahi hai — dobara OTP se sign-in karna hoga (Profile tab mein apni email se OTP mangwayein).';
      } else {
        sessionOk = true;
        sessionDetail =
            'Abhi is phone par koi login nahi hai — zaroorat par OTP se sign-in ho jayega.';
      }
      final sessionDead = sess != null && !sessionOk && sessionNeedsUser;

      // Qadam 3: sync ki taazgi — purani/na-hui ho aur
      // backend zinda ho to khud taaza karne ki koshish
      // (backoff ke saath EK dobara koshish).
      final fetchBefore = fetchBeforeMs <= 0
          ? null
          : DateTime.fromMillisecondsSinceEpoch(fetchBeforeMs);
      final syncStale = fetchBefore == null ||
          DateTime.now().difference(fetchBefore) > staleSyncAfter;
      var syncOkNow = !syncStale;
      var syncRepaired = false;
      if (syncStale && backendOk && !sessionDead) {
        var ok = false;
        try {
          ok = await hooks.syncNow();
        } catch (_) {
          ok = false;
        }
        if (!ok) {
          await Future.delayed(retryDelay);
          try {
            ok = await hooks.syncNow();
          } catch (_) {
            ok = false;
          }
        }
        syncOkNow = ok;
        if (ok) {
          syncRepaired = true;
          await log(
            fetchBefore == null
                ? 'Is dafa app khulne par backend se data aya hi nahi tha'
                : 'Data purana ho gaya tha (aakhri kamyab parhai ${_fmtTime(fetchBefore)})',
            'Khud dobara pull kar ke taaza data le liya',
            true,
          );
        } else {
          await log(
            'Data taaza nahi ho saka',
            'Dobara pull ki koshish ki — nakam rahi; agli jaanch mein phir koshish hogi',
            false,
          );
        }
      }

      // Qadam 4: andar ke records ki saakht — kharab hon to
      // mehfooz copy dobara likh kar (jo haalat load ne saaf
      // rakhi hai) durust karna; route cache ka kharab hissa
      // bhi yahin saaf hota hai.
      PdStoreIntegrityReport? integrity;
      try {
        integrity = await hooks.inspectLocalData();
      } catch (_) {
        integrity = null;
      }
      var prunedRoutes = 0;
      try {
        prunedRoutes = await hooks.pruneRouteCache();
      } catch (_) {
        prunedRoutes = 0;
      }
      if (prunedRoutes > 0) {
        await log(
          'Route cache mein $prunedRoutes kharab entries jama thi',
          'Kharab route entries saaf kar di — naye routes taaza baneinge',
          true,
        );
      }
      var localOk = false;
      var localRepaired = false;
      String localDetail;
      if (integrity == null) {
        localDetail =
            'Andar ke records ki jaanch nahi ho saki — agli jaanch mein dobara koshish hogi.';
      } else if (!integrity.present) {
        localOk = true;
        localDetail =
            'Abhi phone par koi mehfooz record nahi hai — pehli kamyab sync par ban jayega.';
      } else if (integrity.allOk) {
        localOk = true;
        localDetail = 'Phone ke andar ke tamam records durust parhe gaye.';
      } else {
        final badLabels =
            integrity.badSections.map(pdStoreSectionLabel).join(', ');
        var rebuilt = 0;
        try {
          rebuilt = await hooks.repairLocalData();
        } catch (_) {
          rebuilt = 0;
        }
        PdStoreIntegrityReport? after;
        try {
          after = await hooks.inspectLocalData();
        } catch (_) {
          after = null;
        }
        if (rebuilt > 0 && after != null && after.allOk) {
          localOk = true;
          localRepaired = true;
          localDetail =
              'Kharab record durust copy se dobara mehfooz kar diya gaya hai — asal data backend se har sync par taaza hota rehta hai.';
          await log(
            'Kharab record mila: $badLabels',
            'Durust copy dobara mehfooz kar ke record theek kar diya',
            true,
          );
        } else {
          localDetail =
              'Kuch records kharab hain ($badLabels) aur abhi theek nahi ho sake — app chalti rahegi, agli jaanch mein dobara koshish hogi.';
          await log(
            'Kharab record mila: $badLabels',
            'Theek karne ki koshish ki — nakam rahi',
            false,
          );
        }
      }

      // Qadam 5: OUTBOX — atki hui cheezein (bookings /
      // packages / messages / ratings jo backend tak nahi
      // pohanchi) ki dobara koshish, backoff ke saath zyada
      // se zyada DO martaba is run mein.
      ({int rides, int packages, int messages, int ratings})? counts;
      try {
        counts = await hooks.outboxCounts();
      } catch (_) {
        counts = null;
      }
      var outboxOk = false;
      var outboxRepaired = false;
      String outboxDetail;
      if (counts == null) {
        outboxDetail =
            'Atki hui cheezon ki ginti nahi ho saki — agli jaanch mein dobara koshish hogi.';
      } else {
        final totalBefore =
            counts.rides + counts.packages + counts.messages + counts.ratings;
        if (totalBefore == 0) {
          outboxOk = true;
          outboxDetail = 'Koi cheez atki hui nahi hai — sab backend tak pohanch chuka hai.';
        } else if (!backendOk) {
          outboxDetail =
              '$totalBefore cheez backend tak nahi pohanchi — rabta bante hi khud dobara koshish hogi.';
        } else if (sessionDead) {
          outboxDetail =
              '$totalBefore cheez backend tak nahi pohanchi — session theek honay par khud pohanch jayengi.';
        } else {
          var left = totalBefore;
          for (var attempt = 0; attempt < 2 && left > 0; attempt++) {
            if (attempt > 0) await Future.delayed(retryDelay);
            try {
              await hooks.retryOutbox();
            } catch (_) {
              // Har rasta andar khamosh hai — ginti hi jawab hai.
            }
            try {
              final c2 = await hooks.outboxCounts();
              left = c2.rides + c2.packages + c2.messages + c2.ratings;
            } catch (_) {
              // Ginti na ban sake to pehli haalat hi rakho.
            }
          }
          outboxOk = left == 0;
          outboxRepaired = left < totalBefore;
          if (left == 0) {
            outboxDetail =
                'Atki hui $totalBefore cheez khud dobara bhej kar mukammal kar di gayi hain.';
            await log(
              '$totalBefore cheez backend tak nahi pohanchi thi (atka hua outbox)',
              'Dobara bhej kar sab mukammal kar diya',
              true,
            );
          } else {
            outboxDetail =
                '$left cheez ab bhi atki hui hai — rabta durust honay par agli jaanch mein khud dobara koshish hogi. Aap ka data phone par mehfooz hai.';
            await log(
              '$totalBefore cheez backend tak nahi pohanchi thi (atka hua outbox)',
              'Dobara bhejne ki koshish ki — $left reh gayi',
              false,
            );
          }
        }
      }

      final checks = <HealthCheckResult>[
        HealthCheckResult(
          kind: HealthCheckKind.backend,
          ok: backendOk,
          title: 'Backend se rabta',
          detail: backendOk
              ? 'Peeche ke system se rabta durust hai.'
              : 'Backend se rabta nahi ho raha — internet band ho sakta hai ya peeche ka system band ho. Rabta bante hi jaanch khud dobara hogi.',
        ),
        HealthCheckResult(
          kind: HealthCheckKind.session,
          ok: sessionOk,
          repaired: sessionRepaired,
          title: 'Login session',
          detail: sessionDetail,
          needsUserAction: sessionNeedsUser,
        ),
        HealthCheckResult(
          kind: HealthCheckKind.sync,
          ok: syncOkNow,
          repaired: syncRepaired,
          title: 'Data ki taazgi',
          detail: syncRepaired
              ? 'Data purana tha — khud taaza kar diya gaya hai.'
              : !syncStale
                  ? 'Data taaza hai (aakhri kamyab parhai ${_fmtTime(fetchBefore)}).'
                  : sessionDead
                      ? 'Session khatam honay ki wajah se data taaza nahi ho saka — pehle dobara sign-in karein.'
                      : !backendOk
                          ? 'Backend se rabta na honay ki wajah se data taaza nahi ho saka — purani mehfooz maloomat hi chal rahi hai.'
                          : 'Data taaza karne ki koshish nakam rahi — purani mehfooz maloomat hi chal rahi hai; agli jaanch mein dobara koshish hogi.',
        ),
        HealthCheckResult(
          kind: HealthCheckKind.localData,
          ok: localOk,
          repaired: localRepaired,
          title: 'Phone ke andar ke records',
          detail: localDetail,
        ),
        HealthCheckResult(
          kind: HealthCheckKind.outbox,
          ok: outboxOk,
          repaired: outboxRepaired,
          title: 'Atki hui cheezein (outbox)',
          detail: outboxDetail,
        ),
      ];

      final report = HealthReport(
        checkedAt: DateTime.now(),
        checks: checks,
        repairs: repairs,
        serverIssueNote: !backendOk
            ? 'Agar internet durust hai aur phir bhi backend se rabta nahi ban raha, to ye kharabi peeche ke system mein hai — app isay khud theek NAHI kar sakti. Fikr na karein: aap ka data phone par mehfooz hai aur rabta bante hi sab khud pohanch jayega.'
            : null,
      );
      lastReport = report;
      return report;
    } catch (_) {
      // Jaanch khud kabhi app ko nahi rokegi — jo report
      // ban saki wohi kaafi hai.
      final report = HealthReport(
        checkedAt: DateTime.now(),
        checks: const [
          HealthCheckResult(
            kind: HealthCheckKind.backend,
            ok: false,
            title: 'Khud-jaanch',
            detail:
                'Jaanch mukammal nahi ho saki — agli jaanch mein dobara koshish hogi.',
          ),
        ],
        repairs: repairs,
        serverIssueNote: null,
      );
      lastReport = report;
      return report;
    } finally {
      running = false;
      lastRunAt = DateTime.now();
      notifyListeners();
    }
  }
}

/// Engine ka wahid maujooda namuna — main.dart app start par
/// banata hai, Madad/Profile wali satar aur screen wahin se
/// parhti hain.
class PdHealth {
  static HealthEngine? _engine;

  static HealthEngine engineFor(AppStore store) =>
      _engine ??= HealthEngine(HealthHooks.forStore(store));

  static HealthEngine? get maybeEngine => _engine;
}

/// =====================================================================
/// "APP KI HAALAT" — Madad tab ki chhoti satar (tile) aur poori
/// screen. Saaf Roman Urdu; koi technical error code NAHI.
/// Engine khamoshi se kaam karta hai — ye satar sirf ek jhalak
/// hai, aur screen par Repair Log ka rasta milta hai.
/// =====================================================================

/// Madad tab mein lagne wala card — aakhri jaanch ki ek satar
/// wali khabar; tap par poori "App ki Haalat" screen.
class AppHealthTile extends StatelessWidget {
  final AppStore store;
  const AppHealthTile({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final engine = PdHealth.engineFor(store);
    return ListenableBuilder(
      listenable: engine,
      builder: (context, _) {
        final report = engine.lastReport;
        final String subtitle;
        final IconData icon;
        final Color iconColor;
        if (engine.running) {
          subtitle = 'Khud-jaanch chal rahi hai…';
          icon = Icons.health_and_safety;
          iconColor = Brand.green;
        } else if (report == null) {
          subtitle = 'App apni sehat khud jaanchti hai — tafseel ke liye tap karein.';
          icon = Icons.health_and_safety;
          iconColor = Brand.green;
        } else if (report.needsUserAction) {
          subtitle = 'Ek kaam aap ke karne ka hai (dobara sign-in) — tafseel ke liye tap karein.';
          icon = Icons.error;
          iconColor = Brand.ajrakRed;
        } else if (!report.allOk) {
          subtitle = 'Kuch cheezein abhi theek nahi ho sakin — tafseel ke liye tap karein.';
          icon = Icons.error;
          iconColor = Brand.ajrakRed;
        } else if (report.repairedCount > 0) {
          subtitle =
              'Sab theek hai — ${report.repairedCount} cheez khud theek ki gayi (jaanch ${_fmtTime(report.checkedAt)}).';
          icon = Icons.build_circle;
          iconColor = Brand.brightGreen;
        } else {
          subtitle = 'Sab theek hai (jaanch ${_fmtTime(report.checkedAt)}).';
          icon = Icons.check_circle;
          iconColor = Brand.brightGreen;
        }
        return Card(
          margin: EdgeInsets.zero,
          child: ListTile(
            leading: Icon(icon, color: iconColor),
            title: const Text('App ki Haalat',
                style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(subtitle),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => AppHealthPage(store: store),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Poori sehat screen — har jaanch ki haalat, bara repair
/// button, aur Repair Log.
class AppHealthPage extends StatefulWidget {
  final AppStore store;
  const AppHealthPage({super.key, required this.store});

  @override
  State<AppHealthPage> createState() => _AppHealthPageState();
}

class _AppHealthPageState extends State<AppHealthPage> {
  @override
  void initState() {
    super.initState();
    // Screen khulte hi taaza jaanch (pehle se report ho aur
    // engine khud-kar jaanch kar chuka ho to wohi dikhega —
    // runNow chalti hui koshish ko dobara NAHI chalata).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (PdHealth.engineFor(widget.store).lastReport == null) {
        unawaited(PdHealth.engineFor(widget.store).runNow());
      }
    });
  }

  IconData _iconFor(HealthCheckResult c) => c.ok
      ? (c.repaired ? Icons.build_circle : Icons.check_circle)
      : Icons.error;

  Color _colorFor(HealthCheckResult c) =>
      c.ok ? Brand.brightGreen : Brand.ajrakRed;

  @override
  Widget build(BuildContext context) {
    final engine = PdHealth.engineFor(widget.store);
    return Scaffold(
      appBar: AppBar(
        title: const Text('App ki Haalat'),
        backgroundColor: Brand.deepGreen,
        foregroundColor: Colors.white,
      ),
      body: ListenableBuilder(
        listenable: engine,
        builder: (context, _) {
          final report = engine.lastReport;
          final serverNote = report?.serverIssueNote;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.health_and_safety,
                              color: Brand.green, size: 26),
                          SizedBox(width: 10),
                          Text('Khud-Jaanch aur Repair',
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'App apni sehat khud jaanchti hai — khulne par aur har thori dair baad. Jo chhoti kharabi app ke apne ikhtiyar mein hoti hai (purana session, purana data, kharab record, atki hui cheezein) woh khud theek ho jati hai; har theek ki gayi cheez ka record neeche Repair Log mein rehta hai.',
                        style: TextStyle(color: Brand.ink, fontSize: 13),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        report == null
                            ? (engine.running
                                ? 'Jaanch chal rahi hai…'
                                : 'Abhi tak jaanch nahi hui — neeche wala button dabayein.')
                            : report.allOk
                                ? 'Aakhri jaanch: ${_fmtDateTime(report.checkedAt)} — sab theek hai${report.repairedCount > 0 ? ' (${report.repairedCount} cheez khud theek ki gayi)' : ''}'
                                : 'Aakhri jaanch: ${_fmtDateTime(report.checkedAt)} — ${report.problemCount} masla mila',
                        style: TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w600,
                          color: report == null
                              ? Brand.ink
                              : report.allOk
                                  ? Brand.green
                                  : Brand.ajrakRed,
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: engine.running
                              ? null
                              : () => unawaited(engine.runNow()),
                          icon: engine.running
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2, color: Colors.white),
                                )
                              : const Icon(Icons.healing, size: 19),
                          label: Text(engine.running
                              ? 'Jaanch chal rahi hai…'
                              : 'Abhi Jaanch Kar Ke Theek Karein'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (report != null) ...[
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Column(
                      children: [
                        for (final c in report.checks)
                          ListTile(
                            leading: Icon(_iconFor(c), color: _colorFor(c)),
                            title: Text(c.title,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 15)),
                            subtitle: Text(c.detail,
                                style: const TextStyle(fontSize: 13)),
                            trailing: c.repaired
                                ? const Chip(
                                    label: Text('Khud theek',
                                        style: TextStyle(fontSize: 11)),
                                    visualDensity: VisualDensity.compact,
                                  )
                                : null,
                          ),
                      ],
                    ),
                  ),
                ),
              ],
              if (serverNote != null) ...[
                const SizedBox(height: 12),
                Card(
                  color: const Color(0xFFFFF4E0),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.cloud_off, color: Color(0xFFB26A00)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(serverNote,
                              style: const TextStyle(fontSize: 13)),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 16),
              const Text('Repair Log (sirf is app ke andar)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text(
                'Har khud-ki-gayi repair yahan darj hoti hai — kab, kya kharab tha, kya kiya gaya aur natija kya hua. Masla barqarar ho to Master ko message karte waqt ye tafseel bata dein, support ko asal haalat samajhne mein madad milegi.',
                style: TextStyle(fontSize: 12.5),
              ),
              const SizedBox(height: 8),
              if (engine.repairLog.isEmpty)
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(14),
                    child: Text(
                        'Abhi tak koi repair nahi hui — koi kharabi mili hi nahi.'),
                  ),
                )
              else
                Card(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Column(
                      children: [
                        for (final e in engine.repairLog)
                          ListTile(
                            dense: true,
                            leading: Icon(
                              e.success ? Icons.build : Icons.build_outlined,
                              color: e.success ? Brand.green : Brand.ajrakRed,
                              size: 20,
                            ),
                            title: Text(e.problem,
                                style: const TextStyle(fontSize: 13.5)),
                            subtitle: Text(
                              '${_fmtDateTime(e.at)} — ${e.action} (${e.success ? 'kamyab' : 'nakam'})',
                              style: const TextStyle(fontSize: 12),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              const SizedBox(height: 8),
              const Text(
                'Hadd: peeche ke system (server) ki kharabi app khud theek NAHI kar sakti — aisi haalat upar saaf likh di jati hai. Session khatam honay par dobara OTP sign-in aap ka hi amal hai.',
                style: TextStyle(fontSize: 12),
              ),
            ],
          );
        },
      ),
    );
  }
}
