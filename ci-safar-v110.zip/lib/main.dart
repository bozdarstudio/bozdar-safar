import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'store.dart';
import 'theme.dart';
import 'backend.dart';
import 'passenger.dart';
import 'driver.dart';

void main() {
  runApp(const BozdarSafarApp());
}

class BozdarSafarApp extends StatefulWidget {
  const BozdarSafarApp({super.key});

  @override
  State<BozdarSafarApp> createState() => _BozdarSafarAppState();
}

class _BozdarSafarAppState extends State<BozdarSafarApp> {
  final AppStore store = AppStore();

  /// Branded intro sirf cold start par EK dafa — ~2.3 second. Ye timer
  /// sirf UI ka hai: backend sync is se peeche background mein chalti
  /// rehti hai, intro use kabhi nahi rokti.
  bool _introDone = false;
  Timer? _introTimer;

  @override
  void initState() {
    super.initState();
    _introTimer = Timer(const Duration(milliseconds: 2300), () {
      if (mounted) setState(() => _introDone = true);
    });
    // Load ke baad ek dafa khamosh update check + backend sync —
    // dono fire-and-forget, intro se bilkul alag.
    store.load().then((_) {
      store.checkForUpdate();
      Backend.start(store);
    });
  }

  @override
  void dispose() {
    _introTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Safar',
      debugShowCheckedModeBanner: false,
      theme: Brand.theme(),
      home: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          final ready = store.loaded && _introDone;
          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 450),
            child: ready
                ? ModeShell(key: const ValueKey('shell'), store: store)
                : const IntroSplash(key: ValueKey('intro')),
          );
        },
      ),
    );
  }
}

/// Powerful branded intro (v1.1.0 — malik ka hukm): full-screen
/// deep-green par Pin-Rickshaw logo bara, neeche "SAFAR" sunahre
/// baray aksharon mein — scale-up + fade-in ke saath. Sirf logo +
/// naam, koi tagline nahi; kinare par brand ki apni AjrakStrip.
/// Mode badalne par ye dobara NAHI ati — sirf cold start par hai.
class IntroSplash extends StatefulWidget {
  const IntroSplash({super.key});

  @override
  State<IntroSplash> createState() => _IntroSplashState();
}

class _IntroSplashState extends State<IntroSplash>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1150),
  )..forward();
  late final Animation<double> _logoScale = Tween<double>(begin: 0.6, end: 1.0)
      .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack));
  late final Animation<double> _fade =
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
  late final Animation<double> _nameIn = CurvedAnimation(
    parent: _ctrl,
    curve: const Interval(0.35, 1.0, curve: Curves.easeOut),
  );

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Brand.deepGreen,
      body: Column(
        children: [
          const AjrakStrip(height: 14),
          Expanded(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  FadeTransition(
                    opacity: _fade,
                    child: ScaleTransition(
                      scale: _logoScale,
                      child: Image.asset(
                        'assets/safar-logo-mark.png',
                        width: 196,
                        height: 196,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  FadeTransition(
                    opacity: _nameIn,
                    child: ScaleTransition(
                      scale: Tween<double>(begin: 0.9, end: 1.0)
                          .animate(_nameIn),
                      child: const Text(
                        'SAFAR',
                        style: TextStyle(
                          color: Brand.gold,
                          fontSize: 48,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 7,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const AjrakStrip(height: 14),
        ],
      ),
    );
  }
}

/// ONE app, TWO fully separated sides. One tap replaces the whole
/// display; the other side never renders. Mode badalne ka SIRF EK
/// tareeqa hai (v1.0.8 — malik ka hukm): har side ke BrandHeader ke
/// foran neeche ek hi wazeh toggle button [ModeToggleButton], jis par
/// us mode ka naam likha hota hai jis mein jana hai ("Driver Mode" /
/// "Passenger Mode"). Kyunke ek waqt mein sirf ek side render hoti
/// hai, screen par hamesha ek hi mode button hota hai. Pehli dafa app
/// Passenger mode mein khulti hai.
class ModeShell extends StatefulWidget {
  final AppStore store;
  const ModeShell({super.key, required this.store});

  @override
  State<ModeShell> createState() => _ModeShellState();
}

class _ModeShellState extends State<ModeShell> {
  bool driverMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Brand.deepGreen,
      body: SafeArea(
        bottom: false,
        child: driverMode
            ? DriverSide(
                store: widget.store,
                onSwitchToPassenger: () {
                  setState(() => driverMode = false);
                  // Backend `devices` entry mein akhri mode taza.
                  unawaited(Backend.touchDevice(widget.store, 'passenger'));
                },
              )
            : PassengerSide(
                store: widget.store,
                onSwitchToDriver: () {
                  setState(() => driverMode = true);
                  unawaited(Backend.touchDevice(widget.store, 'driver'));
                },
              ),
      ),
    );
  }
}

/// THE single mode toggle (v1.0.8 — malik ka hukm: mode badalne ka
/// sirf yehi ek button hoga). Har side ke BrandHeader ke foran neeche
/// wazeh tor par lagta hai. Is par us mode ka naam likha hota hai jis
/// mein ye le jayega: Passenger mode mein "Driver Mode" (gaari/driver
/// icon ke saath), Driver mode mein "Passenger Mode" (sawari icon ke
/// saath). Ek tap = side badal gayi.
class ModeToggleButton extends StatelessWidget {
  final bool toDriver;
  final VoidCallback onTap;
  const ModeToggleButton(
      {super.key, required this.toDriver, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(
            toDriver
                ? Icons.drive_eta
                : Icons.airline_seat_recline_normal,
            size: 22),
        label: Text(toDriver ? 'Driver Mode' : 'Passenger Mode'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Brand.gold,
          foregroundColor: Brand.greenDark,
          padding: const EdgeInsets.symmetric(vertical: 13),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
        ),
      ),
    );
  }
}

/// Nayi update ka slim gold banner — dono sides ke home ke upar dikhta
/// hai. "Update karein" download link kholta hai; × dabane se sirf is
/// session ke liye chhup jata hai.
class UpdateBanner extends StatelessWidget {
  final AppStore store;
  const UpdateBanner({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: Brand.gold,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(
        children: [
          const Icon(Icons.system_update, size: 18, color: Brand.greenDark),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              'Safar ki nayi update aa gayi hai',
              style: TextStyle(
                  color: Brand.greenDark,
                  fontSize: 13,
                  fontWeight: FontWeight.w800),
            ),
          ),
          TextButton(
            onPressed: () => launchUrl(
              Uri.parse(kUpdateDownloadUrl),
              mode: LaunchMode.externalApplication,
            ),
            style: TextButton.styleFrom(
              backgroundColor: Brand.greenDark,
              foregroundColor: Brand.cream,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              minimumSize: Size.zero,
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: const Text('Update karein',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(width: 4),
          IconButton(
            onPressed: store.dismissUpdate,
            icon: const Icon(Icons.close, size: 18, color: Brand.greenDark),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
            tooltip: 'Band karein',
          ),
        ],
      ),
    );
  }
}
