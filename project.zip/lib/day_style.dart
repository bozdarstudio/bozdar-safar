// v1.4.59 (malik ki shikayat 2026-11-16): DIN wala map ab
// CARTO VECTOR style NAHI raha — kamzor mobile net (2–5 KB/s)
// par vector tiles ki gali-data pohanchta hi nahi tha, map
// sirf style ke khaali cream pas-manzar (#fbf8f3) par atka
// rehta tha: safed map, koi sadak NAHI। Ab basemap OpenStreetMap
// ki RASTER tiles hain (tile.openstreetmap.org) — har tile ek
// tasveer hai, hisso mein foran load hoti hai, sadkein apne
// ASAL rangon mein saaf aur moti nazar ati hain।
// CARTO RASTER istemal NAHI hua: us ki tiles par "API KEY
// REQUIRED" ka watermark ata hai (parent ne jaanch kar mana
// kiya hai)। CARTO se FONTS (glyphs) barkarar hain।
//
// v1.4.60 (malik ki shikayat 2026-11-16 02:38): raster tasveer
// mein bake hue jagah/sadak ke NAAM feeke (halke) parhte thay —
// "padhne mein maza aaye" ke liye ab ek LABELS-ONLY vector
// overlay (source "carto") raster ke UPAR hai: v1.4.58 wale
// asal CARTO style se sirf jagah (places) aur sadak-naam
// (roads) wale symbol layers liye gaye hain, GEHRE rang mein —
// din: taqreeban kaala text (#191920) + safed halo 2, taake
// naam har zoom par crystal-saaf aur dark parhe jayein।
// Geometry/fill/line layers vector se bilkul NAHI liye —
// sadkein ab bhi raster se hi ati hain (tez load barkarar)।
// Raster paint bhi halka retune: contrast 0.08 → 0.15।
// App ke apne overlay sources/layers (route, markers, A/B
// pin naam, teer ke maqam-naam) safar_map.dart mein code se
// bante hain aur in ke bhi UPAR rehte hain।
const String kDayStyleJson = r'''{
  "version": 8,
  "name": "Safar Day",
  "metadata": {},
  "sources": {
    "osm": {
      "type": "raster",
      "tiles": [
        "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
      ],
      "tileSize": 256,
      "attribution": "© OpenStreetMap contributors"
    },
    "carto": {
      "type": "vector",
      "tiles": [
        "https://tiles.basemaps.cartocdn.com/v/20261026-01/vectortiles/carto.streets/v2/{z}/{x}/{y}.mvt"
      ],
      "minzoom": 0,
      "maxzoom": 15,
      "attribution": "© OpenStreetMap contributors © CARTO"
    }
  },
  "sprite": "https://tiles.basemaps.cartocdn.com/v/20261026-01/gl/voyager-gl-style/sprite",
  "glyphs": "https://tiles.basemaps.cartocdn.com/v/20261026-01/fonts/{fontstack}/{range}.pbf",
  "layers": [
    {
      "id": "safar-bg",
      "type": "background",
      "paint": {
        "background-color": "#ece7db"
      }
    },
    {
      "id": "osm",
      "type": "raster",
      "source": "osm",
      "paint": {
        "raster-contrast": 0.15,
        "raster-saturation": 0.06
      }
    },
    {
      "id": "place_hamlet",
      "type": "symbol",
      "source": "carto",
      "source-layer": "places",
      "minzoom": 12,
      "maxzoom": 16,
      "layout": {
        "text-field": [
          "step",
          [
            "zoom"
          ],
          [
            "coalesce",
            [
              "get",
              "name:en"
            ],
            [
              "case",
              [
                "has",
                "name3"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ],
                " ",
                [
                  "get",
                  "name3"
                ]
              ],
              [
                "has",
                "name2"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ]
              ],
              [
                "get",
                "name"
              ]
            ]
          ],
          14,
          [
            "case",
            [
              "has",
              "name3"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ],
              " ",
              [
                "get",
                "name3"
              ]
            ],
            [
              "has",
              "name2"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ]
            ],
            [
              "get",
              "name"
            ]
          ]
        ],
        "text-font": [
          "Montserrat Medium",
          "Open Sans Regular",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              13,
              10.4
            ],
            [
              14,
              13.0
            ],
            [
              16,
              14.3
            ]
          ]
        },
        "text-anchor": "center",
        "text-max-width": 10,
        "text-keep-upright": true,
        "text-offset": [
          0.2,
          0.2
        ],
        "text-transform": {
          "stops": [
            [
              12,
              "none"
            ],
            [
              14,
              "uppercase"
            ]
          ]
        },
        "symbol-sort-key": [
          "-",
          [
            "*",
            [
              "coalesce",
              [
                "get",
                "min_zoom"
              ],
              20
            ],
            100
          ],
          [
            "coalesce",
            [
              "get",
              "population_rank"
            ],
            0
          ]
        ]
      },
      "paint": {
        "text-color": "#191920",
        "text-halo-color": "rgba(255,255,255,0.95)",
        "text-halo-width": 2
      },
      "filter": [
        "any",
        [
          "all",
          [
            "all",
            [
              "==",
              [
                "get",
                "kind"
              ],
              "neighbourhood"
            ],
            [
              "==",
              [
                "get",
                "kind_detail"
              ],
              "neighbourhood"
            ]
          ],
          [
            ">=",
            [
              "zoom"
            ],
            14
          ]
        ],
        [
          "all",
          [
            "==",
            [
              "get",
              "kind"
            ],
            "locality"
          ],
          [
            "==",
            [
              "get",
              "kind_detail"
            ],
            "hamlet"
          ]
        ]
      ]
    },
    {
      "id": "place_suburbs",
      "type": "symbol",
      "source": "carto",
      "source-layer": "places",
      "minzoom": 12,
      "maxzoom": 16,
      "layout": {
        "text-field": [
          "step",
          [
            "zoom"
          ],
          [
            "coalesce",
            [
              "get",
              "name:en"
            ],
            [
              "case",
              [
                "has",
                "name3"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ],
                " ",
                [
                  "get",
                  "name3"
                ]
              ],
              [
                "has",
                "name2"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ]
              ],
              [
                "get",
                "name"
              ]
            ]
          ],
          13,
          [
            "case",
            [
              "has",
              "name3"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ],
              " ",
              [
                "get",
                "name3"
              ]
            ],
            [
              "has",
              "name2"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ]
            ],
            [
              "get",
              "name"
            ]
          ]
        ],
        "text-font": [
          "Montserrat Medium",
          "Open Sans Regular",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              12,
              11.7
            ],
            [
              13,
              13.0
            ],
            [
              14,
              14.3
            ],
            [
              15,
              15.6
            ],
            [
              16,
              16.9
            ]
          ]
        },
        "text-anchor": "center",
        "text-max-width": 10,
        "text-keep-upright": true,
        "text-offset": [
          0.2,
          0.2
        ],
        "text-transform": {
          "stops": [
            [
              8,
              "none"
            ],
            [
              12,
              "uppercase"
            ]
          ]
        },
        "symbol-sort-key": [
          "-",
          [
            "*",
            [
              "coalesce",
              [
                "get",
                "min_zoom"
              ],
              20
            ],
            100
          ],
          [
            "coalesce",
            [
              "get",
              "population_rank"
            ],
            0
          ]
        ]
      },
      "paint": {
        "text-color": "#191920",
        "text-halo-color": "rgba(255,255,255,0.95)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "==",
          [
            "get",
            "kind"
          ],
          "neighbourhood"
        ],
        [
          "==",
          [
            "get",
            "kind_detail"
          ],
          "suburb"
        ]
      ]
    },
    {
      "id": "place_villages",
      "type": "symbol",
      "source": "carto",
      "source-layer": "places",
      "minzoom": 10,
      "maxzoom": 16,
      "layout": {
        "text-field": [
          "step",
          [
            "zoom"
          ],
          [
            "coalesce",
            [
              "get",
              "name:en"
            ],
            [
              "case",
              [
                "has",
                "name3"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ],
                " ",
                [
                  "get",
                  "name3"
                ]
              ],
              [
                "has",
                "name2"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ]
              ],
              [
                "get",
                "name"
              ]
            ]
          ],
          13,
          [
            "case",
            [
              "has",
              "name3"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ],
              " ",
              [
                "get",
                "name3"
              ]
            ],
            [
              "has",
              "name2"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ]
            ],
            [
              "get",
              "name"
            ]
          ]
        ],
        "text-font": [
          "Montserrat SemiBold",
          "Open Sans Bold",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              10,
              11.7
            ],
            [
              12,
              13.0
            ],
            [
              13,
              14.3
            ],
            [
              14,
              15.6
            ],
            [
              16,
              16.9
            ]
          ]
        },
        "text-anchor": "center",
        "text-max-width": 10,
        "text-keep-upright": true,
        "text-offset": [
          0.2,
          0.2
        ],
        "text-transform": "none",
        "symbol-sort-key": [
          "-",
          [
            "*",
            [
              "coalesce",
              [
                "get",
                "min_zoom"
              ],
              20
            ],
            100
          ],
          [
            "coalesce",
            [
              "get",
              "population_rank"
            ],
            0
          ]
        ]
      },
      "paint": {
        "text-color": "#191920",
        "text-halo-color": "rgba(255,255,255,0.95)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "==",
          [
            "get",
            "kind"
          ],
          "locality"
        ],
        [
          "==",
          [
            "get",
            "kind_detail"
          ],
          "village"
        ]
      ]
    },
    {
      "id": "place_town",
      "type": "symbol",
      "source": "carto",
      "source-layer": "places",
      "minzoom": 10,
      "maxzoom": 14,
      "layout": {
        "text-field": [
          "step",
          [
            "zoom"
          ],
          [
            "coalesce",
            [
              "get",
              "name:en"
            ],
            [
              "case",
              [
                "has",
                "name3"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ],
                " ",
                [
                  "get",
                  "name3"
                ]
              ],
              [
                "has",
                "name2"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ]
              ],
              [
                "get",
                "name"
              ]
            ]
          ],
          13,
          [
            "case",
            [
              "has",
              "name3"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ],
              " ",
              [
                "get",
                "name3"
              ]
            ],
            [
              "has",
              "name2"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ]
            ],
            [
              "get",
              "name"
            ]
          ]
        ],
        "text-font": [
          "Montserrat SemiBold",
          "Open Sans Bold",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              8,
              13.0
            ],
            [
              9,
              13.0
            ],
            [
              10,
              14.3
            ],
            [
              13,
              18.2
            ],
            [
              14,
              19.5
            ]
          ]
        },
        "text-anchor": "center",
        "text-max-width": 10,
        "text-keep-upright": true,
        "text-offset": [
          0.2,
          0.2
        ],
        "text-transform": "none",
        "symbol-sort-key": [
          "-",
          [
            "*",
            [
              "coalesce",
              [
                "get",
                "min_zoom"
              ],
              20
            ],
            100
          ],
          [
            "coalesce",
            [
              "get",
              "population_rank"
            ],
            0
          ]
        ]
      },
      "paint": {
        "text-color": "#191920",
        "text-halo-color": "rgba(255,255,255,0.95)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "==",
          [
            "get",
            "kind"
          ],
          "locality"
        ],
        [
          "==",
          [
            "get",
            "kind_detail"
          ],
          "town"
        ]
      ]
    },
    {
      "id": "place_city_r6",
      "type": "symbol",
      "source": "carto",
      "source-layer": "places",
      "minzoom": 10,
      "maxzoom": 15,
      "layout": {
        "text-field": [
          "step",
          [
            "zoom"
          ],
          [
            "coalesce",
            [
              "get",
              "name:en"
            ],
            [
              "case",
              [
                "has",
                "name3"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ],
                " ",
                [
                  "get",
                  "name3"
                ]
              ],
              [
                "has",
                "name2"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ]
              ],
              [
                "get",
                "name"
              ]
            ]
          ],
          13,
          [
            "case",
            [
              "has",
              "name3"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ],
              " ",
              [
                "get",
                "name3"
              ]
            ],
            [
              "has",
              "name2"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ]
            ],
            [
              "get",
              "name"
            ]
          ]
        ],
        "text-font": [
          "Montserrat SemiBold",
          "Open Sans Bold",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              8,
              15.6
            ],
            [
              9,
              16.9
            ],
            [
              10,
              18.2
            ],
            [
              13,
              22.1
            ],
            [
              14,
              26.0
            ]
          ]
        },
        "text-anchor": "center",
        "text-max-width": 10,
        "text-keep-upright": true,
        "text-offset": [
          0.2,
          0.2
        ],
        "text-transform": "uppercase",
        "symbol-sort-key": [
          "-",
          [
            "*",
            [
              "coalesce",
              [
                "get",
                "min_zoom"
              ],
              20
            ],
            100
          ],
          [
            "coalesce",
            [
              "get",
              "population_rank"
            ],
            0
          ]
        ]
      },
      "paint": {
        "text-color": "#191920",
        "text-halo-color": "rgba(255,255,255,0.95)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "all",
          [
            "==",
            [
              "get",
              "kind"
            ],
            "locality"
          ],
          [
            "==",
            [
              "get",
              "kind_detail"
            ],
            "city"
          ]
        ],
        [
          ">=",
          [
            "coalesce",
            [
              "get",
              "min_zoom"
            ],
            0
          ],
          7
        ]
      ]
    },
    {
      "id": "place_city_r5",
      "type": "symbol",
      "source": "carto",
      "source-layer": "places",
      "minzoom": 10,
      "maxzoom": 15,
      "layout": {
        "text-field": [
          "step",
          [
            "zoom"
          ],
          [
            "coalesce",
            [
              "get",
              "name:en"
            ],
            [
              "case",
              [
                "has",
                "name3"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ],
                " ",
                [
                  "get",
                  "name3"
                ]
              ],
              [
                "has",
                "name2"
              ],
              [
                "concat",
                [
                  "get",
                  "name"
                ],
                " ",
                [
                  "get",
                  "name2"
                ]
              ],
              [
                "get",
                "name"
              ]
            ]
          ],
          13,
          [
            "case",
            [
              "has",
              "name3"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ],
              " ",
              [
                "get",
                "name3"
              ]
            ],
            [
              "has",
              "name2"
            ],
            [
              "concat",
              [
                "get",
                "name"
              ],
              " ",
              [
                "get",
                "name2"
              ]
            ],
            [
              "get",
              "name"
            ]
          ]
        ],
        "text-font": [
          "Montserrat SemiBold",
          "Open Sans Bold",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              8,
              18.2
            ],
            [
              10,
              20.8
            ],
            [
              13,
              24.7
            ],
            [
              14,
              28.6
            ]
          ]
        },
        "text-anchor": "center",
        "text-max-width": 10,
        "text-keep-upright": true,
        "text-offset": [
          0.2,
          0.2
        ],
        "text-transform": "uppercase",
        "symbol-sort-key": [
          "-",
          [
            "*",
            [
              "coalesce",
              [
                "get",
                "min_zoom"
              ],
              20
            ],
            100
          ],
          [
            "coalesce",
            [
              "get",
              "population_rank"
            ],
            0
          ]
        ]
      },
      "paint": {
        "text-color": "#191920",
        "text-halo-color": "rgba(255,255,255,0.95)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "all",
          [
            "==",
            [
              "get",
              "kind"
            ],
            "locality"
          ],
          [
            "==",
            [
              "get",
              "kind_detail"
            ],
            "city"
          ]
        ],
        [
          "<=",
          [
            "coalesce",
            [
              "get",
              "min_zoom"
            ],
            0
          ],
          6
        ]
      ]
    },
    {
      "id": "roadname_minor",
      "type": "symbol",
      "source": "carto",
      "source-layer": "roads",
      "minzoom": 16,
      "layout": {
        "symbol-placement": "line",
        "text-font": [
          "Montserrat Medium",
          "Open Sans Regular",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": 11.7,
        "text-field": [
          "case",
          [
            "has",
            "name3"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ],
            " ",
            [
              "get",
              "name3"
            ]
          ],
          [
            "has",
            "name2"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ]
          ],
          [
            "get",
            "name"
          ]
        ],
        "symbol-avoid-edges": false,
        "symbol-spacing": 200,
        "text-pitch-alignment": "auto",
        "text-rotation-alignment": "auto",
        "text-justify": "center"
      },
      "paint": {
        "text-color": "#191920",
        "text-halo-color": "rgba(255,255,255,0.95)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "has",
          "name"
        ],
        [
          "any",
          [
            "all",
            [
              "!",
              [
                "in",
                [
                  "get",
                  "kind"
                ],
                [
                  "literal",
                  [
                    "path",
                    "highway",
                    "major_road"
                  ]
                ]
              ]
            ],
            [
              "in",
              [
                "get",
                "kind_detail"
              ],
              [
                "literal",
                [
                  "residential",
                  "unclassified",
                  "living_street",
                  "road",
                  "alley",
                  "driveway",
                  "parking_aisle"
                ]
              ]
            ]
          ],
          [
            "==",
            [
              "get",
              "kind_detail"
            ],
            "service"
          ]
        ]
      ]
    },
    {
      "id": "roadname_sec",
      "type": "symbol",
      "source": "carto",
      "source-layer": "roads",
      "minzoom": 15,
      "layout": {
        "symbol-placement": "line",
        "text-font": [
          "Montserrat Medium",
          "Open Sans Regular",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              15,
              11.7
            ],
            [
              16,
              14.3
            ],
            [
              18,
              15.6
            ]
          ]
        },
        "text-field": [
          "case",
          [
            "has",
            "name3"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ],
            " ",
            [
              "get",
              "name3"
            ]
          ],
          [
            "has",
            "name2"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ]
          ],
          [
            "get",
            "name"
          ]
        ],
        "symbol-avoid-edges": false,
        "symbol-spacing": 200,
        "text-pitch-alignment": "auto",
        "text-rotation-alignment": "auto",
        "text-justify": "center"
      },
      "paint": {
        "text-color": "#191920",
        "text-halo-color": "rgba(255,255,255,0.95)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "has",
          "name"
        ],
        [
          "any",
          [
            "in",
            [
              "get",
              "kind_detail"
            ],
            [
              "literal",
              [
                "secondary",
                "tertiary",
                "secondary_link",
                "tertiary_link"
              ]
            ]
          ],
          [
            "all",
            [
              "all",
              [
                "in",
                [
                  "get",
                  "kind"
                ],
                [
                  "literal",
                  [
                    "highway",
                    "major_road"
                  ]
                ]
              ],
              [
                "!",
                [
                  "in",
                  [
                    "get",
                    "kind_detail"
                  ],
                  [
                    "literal",
                    [
                      "motorway",
                      "motorway_link",
                      "trunk",
                      "trunk_link",
                      "primary",
                      "primary_link",
                      "secondary",
                      "secondary_link",
                      "tertiary",
                      "tertiary_link"
                    ]
                  ]
                ]
              ]
            ],
            [
              "==",
              [
                "get",
                "kind"
              ],
              "major_road"
            ],
            [
              ">=",
              [
                "coalesce",
                [
                  "get",
                  "min_zoom"
                ],
                0
              ],
              9
            ]
          ]
        ]
      ]
    },
    {
      "id": "roadname_pri",
      "type": "symbol",
      "source": "carto",
      "source-layer": "roads",
      "minzoom": 14,
      "layout": {
        "symbol-placement": "line",
        "text-font": [
          "Montserrat Medium",
          "Open Sans Regular",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              14,
              13.0
            ],
            [
              15,
              13.0
            ],
            [
              16,
              14.3
            ],
            [
              18,
              15.6
            ]
          ]
        },
        "text-field": [
          "case",
          [
            "has",
            "name3"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ],
            " ",
            [
              "get",
              "name3"
            ]
          ],
          [
            "has",
            "name2"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ]
          ],
          [
            "get",
            "name"
          ]
        ],
        "symbol-avoid-edges": false,
        "symbol-spacing": {
          "stops": [
            [
              6,
              200
            ],
            [
              16,
              250
            ]
          ]
        },
        "text-pitch-alignment": "auto",
        "text-rotation-alignment": "auto",
        "text-justify": "center",
        "text-letter-spacing": {
          "stops": [
            [
              14,
              0
            ],
            [
              16,
              0.2
            ]
          ]
        }
      },
      "paint": {
        "text-color": "#191920",
        "text-halo-color": "rgba(255,255,255,0.95)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "has",
          "name"
        ],
        [
          "in",
          [
            "get",
            "kind_detail"
          ],
          [
            "literal",
            [
              "primary",
              "primary_link"
            ]
          ]
        ]
      ]
    },
    {
      "id": "roadname_major",
      "type": "symbol",
      "source": "carto",
      "source-layer": "roads",
      "minzoom": 14,
      "layout": {
        "symbol-placement": "line",
        "text-font": [
          "Montserrat Medium",
          "Open Sans Regular",
          "Noto Sans Regular",
          "Noto Sans CJK JP Regular"
        ],
        "text-size": {
          "stops": [
            [
              14,
              13.0
            ],
            [
              15,
              13.0
            ],
            [
              16,
              14.3
            ],
            [
              18,
              15.6
            ]
          ]
        },
        "text-field": [
          "case",
          [
            "has",
            "name3"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ],
            " ",
            [
              "get",
              "name3"
            ]
          ],
          [
            "has",
            "name2"
          ],
          [
            "concat",
            [
              "get",
              "name"
            ],
            " ",
            [
              "get",
              "name2"
            ]
          ],
          [
            "get",
            "name"
          ]
        ],
        "symbol-avoid-edges": false,
        "symbol-spacing": {
          "stops": [
            [
              6,
              200
            ],
            [
              16,
              250
            ]
          ]
        },
        "text-pitch-alignment": "auto",
        "text-rotation-alignment": "auto",
        "text-justify": "center",
        "text-letter-spacing": {
          "stops": [
            [
              13,
              0
            ],
            [
              16,
              0.2
            ]
          ]
        }
      },
      "paint": {
        "text-color": "#191920",
        "text-halo-color": "rgba(255,255,255,0.95)",
        "text-halo-width": 2
      },
      "filter": [
        "all",
        [
          "has",
          "name"
        ],
        [
          "in",
          [
            "get",
            "kind_detail"
          ],
          [
            "literal",
            [
              "motorway",
              "trunk",
              "motorway_link",
              "trunk_link"
            ]
          ]
        ]
      ]
    }
  ]
}''';
