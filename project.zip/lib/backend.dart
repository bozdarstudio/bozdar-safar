import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:shared_preferences/shared_preferences.dart';
import 'store.dart';
import 'theme.dart' show rs;

/// SAFAR backend sync (v1.1.0) — Supabase REST, sirf dart:io HttpClient.
///
/// Usool:
/// - Local store hamesha asal sach hai; backend us ka AAINA (mirror) hai
///   taaki Master app mein sab kuch nazar aye.
/// - Har network kaam best-effort hai: offline/error par bilkul khamosh —
///   UI kabhi nahi rukti, koi error kabhi nahi dikhta, app crash nahi hota.
/// - Settings ka rukh sirf EK taraf hai: Master (backend) → app. Is app
///   mein settings ka koi editor nahi; server na mile to akhri cached
///   values, woh bhi na hon to built-in defaults chalte hain.
/// - Column/table naam backend-schema.sql ke ain mutabiq hain.
class Backend {
  static const String _base =
      'https://ndcnqotfqpgkgsngewug.supabase.co/rest/v1';
  // Publishable (client) key — apps mein embed karna mehfooz hai;
  // secret key kabhi app mein nahi jati.
  static const String _key =
      'sb_publishable_3TWtf4zT6xJzuyb0fsMuWQ_Fjkyk3LE';
  static const String _storageBase =
      'https://ndcnqotfqpgkgsngewug.supabase.co/storage/v1';
  static const Duration _timeout = Duration(seconds: 8);

  static AppStore? _store;
  static bool _started = false;

  /// App start par EK dafa — main.dart se. Store ke sync hook ko jodta
  /// hai aur pehla sync (device entry, settings, zones, driver status)
  /// background mein chalata hai. Dobara bulane par kuch nahi hota.
  static void start(AppStore store) {
    if (_started) return;
    _started = true;
    _store = store;
    store.syncHook = _onHook;
    unawaited(_startup(store));
  }

  static Future<void> _startup(AppStore store) async {
    // Pehle cached settings (offline ho to bhi Master ki akhri setting
    // chalti rahe), phir fresh pull.
    await _applyCachedSettings();
    await touchDevice(store, 'passenger');
    await _pullSettings();
    await _pullZones(store);
    await refreshDriverStatus(store);
    if (_registered(store)) await _pushDriver(store);
    // RC2 follow-through (v1.2.9): owners jinki registration is
    // machine par mukammal ho chuki hai lekin drivers row kabhi
    // bani hi nahi — ensureDriverRow woh qasr poora kar deta hai
    // taaki woh Master Tasdeeq mein nazar ayen.
    if (store.profile.registrationComplete) {
      await ensureDriverRow(store);
    }
    // Registration documents ki tasaveer (v1.2.8 — TASDEEQ): jo kind
    // abhi upload nahi hua (ya photo badal gayi hai) woh yahan
    // khamoshi se dobara koshish hota hai — Master har document asal
    // tasveer mein check karega, is ke baghair ID active nahi hogi.
    await syncDriverDocs(store);
    // Aaj ki selfie ki TASVEER agar pichli koshish mein upload nahi
    // ho saki thi to yahan khamoshi se dobara koshish (best-effort).
    if (store.profile.selfieToday &&
        store.profile.selfieUploadedDate != store.profile.selfieDate) {
      await _pushSelfie(store, store.profile.selfieDate);
    }
    // Master messages (v1.2.7): queued messages ki dobara koshish +
    // "Master ne parh liya" wali haalat pull.
    await syncMessages(store);
    // v1.4.0: purani unsent ratings ki dobara koshish, Master ke
    // elanaat (announcements) pull, apna rating ausat pull, aur
    // passenger ke liye pichli booking ki status snapshot ko backend
    // ki taaza haalat se seed karna. Sab best-effort — koi table/
    // column na ho to khamoshi se kuch nahi hota.
    await syncRatings(store);
    await _pullAnnouncements(store);
    await pullOwnRatingAverage(store);
    await _primePassengerRideStatuses(store);
  }

  // --- HTTP helpers (sab khamosh — fail = null/false) ------------------------

  static Future<dynamic> _get(String path) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client.getUrl(Uri.parse('$_base/$path')).timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      final resp = await req.close().timeout(_timeout);
      final body = await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode != 200) return null;
      return jsonDecode(body);
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  /// PK par upsert (insert ya update) — PostgREST merge-duplicates.
  /// Jo columns bheje jate hain sirf wohi likhe jate hain.
  static Future<bool> _upsert(String table, Map<String, dynamic> row) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req =
          await client.postUrl(Uri.parse('$_base/$table')).timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      req.headers.set('Prefer', 'resolution=merge-duplicates,return=minimal');
      req.write(jsonEncode(row));
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      return resp.statusCode >= 200 && resp.statusCode < 300;
    } catch (_) {
      return false;
    } finally {
      client?.close();
    }
  }

  /// Sirf diye hue columns ka PATCH (HOTFIX v1.2.9) — 'drivers' row
  /// par kisi EK cheez ki durusti ke liye, jab pura [_upsert] mirror
  /// chalana woh columns bhi bhej de jo is waqt ghalat/purane hon.
  /// Kamyabi par true.
  static Future<bool> _patch(String table, String id, Map<String, dynamic> fields) async {
    HttpClient? client;
    try {
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client
          .patchUrl(
              Uri.parse('$_base/$table?id=eq.${Uri.encodeComponent(id)}'))
          .timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'application/json');
      req.headers.set('Prefer', 'return=minimal');
      req.write(jsonEncode(fields));
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      return resp.statusCode >= 200 && resp.statusCode < 300;
    } catch (_) {
      return false;
    } finally {
      client?.close();
    }
  }

  // --- Devices ---------------------------------------------------------------

  /// Har app khulne par + mode badalne par: is phone ki entry taza.
  /// first_seen sirf pehli insert par banta hai (server default).
  static Future<void> touchDevice(AppStore store, String mode) async {
    if (store.deviceId.isEmpty) return;
    await _upsert('devices', {
      'device_id': store.deviceId,
      'last_seen': DateTime.now().toUtc().toIso8601String(),
      'last_mode': mode,
      'role': mode,
      'app_version': kAppVersion,
    });
  }

  // --- Settings (Master → app, ek rukh) --------------------------------------

  static Future<void> _applyCachedSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('srv_settings_json');
      if (raw == null) return;
      final j = jsonDecode(raw);
      if (j is Map<String, dynamic>) _applySettings(j);
    } catch (_) {
      // Cache kharab ho to defaults hi sahi.
    }
  }

  static Future<void> _pullSettings() async {
    final data = await _get('settings?select=*&id=eq.1');
    if (data is! List || data.isEmpty) return;
    final row = data.first;
    if (row is! Map<String, dynamic>) return;
    _applySettings(row);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('srv_settings_json', jsonEncode(row));
    } catch (_) {
      // Cache na likha jaye to koi baat nahi — values lag chuki hain.
    }
  }

  static void _applySettings(Map<String, dynamic> s) {
    Map<String, int>? intMap(dynamic v) {
      if (v is! Map) return null;
      final out = <String, int>{};
      v.forEach((k, val) {
        final n = val is num ? val.toInt() : int.tryParse('$val');
        if (n != null) out['$k'] = n;
      });
      return out;
    }

    Fares.applyServerSettings(
      feePercent: (s['fee_percent'] as num?)?.toDouble(),
      rates: intMap(s['rate_per_km']),
      waiting: intMap(s['waiting_per_min']),
      freeWaitingMin: (s['free_waiting_min'] as num?)?.toInt(),
      deposit: (s['joining_deposit'] as num?)?.toInt(),
    );
  }

  // --- Zones -----------------------------------------------------------------

  /// Server par band (open=false) zone passenger ki list se nikal jata
  /// hai. Server khaali mile to local [kZones] hi rehte hain.
  ///
  /// SIRF woh sheher dikhte hain jo local [kZones] mein hain — server
  /// sirf un ki KHULA/BAND haalat batata hai. Server par purani
  /// Karachi-ilaqa wali rows abhi baqi hain (aur Master koi aisa naam
  /// bhi bhej sakta hai jis ka is app mein map coordinate nahi) —
  /// aise na-waqif naam is list mein NAHI ate, warna passenger purane
  /// ilaqe dobara dekh leta (owner ka hukm 2026-11-07: zones = sirf
  /// Pakistan ke sheher).
  static Future<void> _pullZones(AppStore store) async {
    final data = await _get('zones?select=name,open');
    if (data is! List || data.isEmpty) return;
    final openByName = <String, bool>{};
    for (final r in data) {
      if (r is Map && r['name'] is String) {
        openByName[r['name'] as String] = r['open'] == true;
      }
    }
    if (openByName.isEmpty) return;
    final visible = <String>[
      ...kZones.where((z) => openByName[z] != false),
    ];
    store.applyServerZones(visible);
  }

  // --- Driver ----------------------------------------------------------------

  /// Registration tabhi mana jata hai jab profile mein naam + mobile
  /// dono mojood hon (Profile Save se ate hain).
  static bool _registered(AppStore store) =>
      store.driverId.isNotEmpty &&
      store.profile.name.trim().isNotEmpty &&
      store.profile.phone.trim().isNotEmpty;

  /// Driver row ka pura mirror — registration (status pending: active
  /// hamesha akhri maloom Master value hi bhejte hain taaki Master ki
  /// ACTIVE tasdeeq is upsert se mit na jaye), online/offline,
  /// wallet balance. Documents ki STATUS (cnic/licence/gaari_status)
  /// is mirror mein NAHI jati — woh Master-owned hai (neeche note).
  static Future<void> _pushDriver(AppStore store) async {
    if (!_registered(store)) return;
    final p = store.profile;
    final row = <String, dynamic>{
      'id': store.driverId,
      'name': p.name,
      'mobile': p.phone,
      'vehicle': p.vehicle,
      'plate': p.plate,
      'zone': p.zone,
      'active': p.masterActive,
      'online': p.online,
      'on_ride': store.bookings
          .any((b) => b.status == 'accepted' || b.status == 'arrived'),
      // HOTFIX v1.2.9: cnic_status / licence_status / gaari_status
      // ab MASTER-OWNED hain — driver app in columns ko KABHI nahi
      // bhejti. Pehle har _pushDriver Master ke Tasdeeq/Reject faisle
      // ko local (hamesha 'pending'/'rejected'-lagne wale) values se
      // overwrite kar deta tha. Ab ye sirf Master PATCH se badalte
      // hain; driver app inhein sirf refreshDriverStatus se PULL
      // karke Profile mein dikhati hai.
      'wallet_balance': p.walletBalance,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    };
    // Driver ki akhri GPS jagah — schema ke lat/lng columns pehle se
    // maujood hain (Master map inhi se asal jagah dikhata hai). Sirf
    // tab bhejte hain jab position maloom ho: null bhej kar kisi
    // purani achhi value ko kabhi mitaya nahi jata.
    if (p.lastLat != null && p.lastLng != null) {
      row['lat'] = p.lastLat;
      row['lng'] = p.lastLng;
    }
    // Password ka sirf FINGERPRINT (v1.2.5) — asal password kabhi
    // network par nahi jata. Sirf tab bhejte hain jab set ho.
    if (p.pwdFp.isNotEmpty) {
      row['pwd_fp'] = p.pwdFp;
    }
    // Registration wizard (v1.2.6) ki tafseel — columns migration
    // backend-migration-v126.sql se bante hain. Sirf bhari hui values
    // bhejte hain (khaali bhej kar purani value nahi mitate).
    // (v1.2.8: document tasaveer ab Storage bucket 'driver-docs'
    // mein bhi jati hain — neeche wale *_path columns dekhein.)
    if (p.cnicNumber.isNotEmpty) row['cnic_number'] = p.cnicNumber;
    if (p.licenceNumber.isNotEmpty) {
      row['licence_number'] = p.licenceNumber;
    }
    if (p.vehicleBrand.isNotEmpty) row['vehicle_brand'] = p.vehicleBrand;
    if (p.vehicleModel.isNotEmpty) row['vehicle_model'] = p.vehicleModel;
    if (p.vehicleYear > 0) row['vehicle_year'] = p.vehicleYear;
    if (p.vehicleColor.isNotEmpty) row['vehicle_color'] = p.vehicleColor;
    // Registration documents ke backend object paths (v1.2.8) — sirf
    // us kind ka path jata hai jis ki tasveer asal mein upload ho
    // chuki hai (docUploaded marker maujood hai); path ka pattern
    // tay hai: <driver_id>/<kind>.jpg. Columns migration
    // backend-migration-v128.sql se bante hain.
    String? docPath(String kind) =>
        (p.docUploaded[kind]?.isNotEmpty ?? false)
            ? '${store.driverId}/$kind.jpg'
            : null;
    final cnicFront = docPath('cnic_front');
    if (cnicFront != null) row['cnic_front_path'] = cnicFront;
    final cnicBack = docPath('cnic_back');
    if (cnicBack != null) row['cnic_back_path'] = cnicBack;
    final vehiclePhoto = docPath('vehicle');
    if (vehiclePhoto != null) row['vehicle_photo_path'] = vehiclePhoto;
    final vehicleReg = docPath('vehicle_reg');
    if (vehicleReg != null) row['vehicle_reg_path'] = vehicleReg;
    final licencePhoto = docPath('licence');
    if (licencePhoto != null) row['licence_photo_path'] = licencePhoto;
    final profilePhoto = docPath('profile');
    if (profilePhoto != null) row['profile_photo_path'] = profilePhoto;
    await _upsert('drivers', row);
  }

  /// Password UNIQUENESS check (v1.2.5): is fingerprint ke saath koi
  /// AUR driver backend par pehle se hai ya nahi.
  /// Returns: true = kisi aur ne ye password lagaya hua hai;
  /// false = khaali hai (ya sirf is driver ki apni row hai);
  /// null = backend tak pahuncha hi nahi (offline/error) — us surat
  /// mein check ko "pass" NAHI samjha jata; caller registration ko
  /// rok kar internet ka kehta hai.
  static Future<bool?> passwordFingerprintTaken(
      AppStore store, String fp) async {
    final data = await _get(
        'drivers?select=id&pwd_fp=eq.${Uri.encodeComponent(fp)}');
    if (data is! List) return null;
    for (final r in data) {
      if (r is Map && r['id'] != store.driverId) return true;
    }
    return false;
  }

  /// Master ne driver ko ACTIVE kiya hai ya nahi — app khulne par aur
  /// Profile ki refresh dabane par pull hota hai. Duty ka taala SIRF
  /// yahi [masterActive] hai — app apne aap ko KABHI active nahi
  /// karti; documents upload ho jana activation NAHI hai.
  /// Saath mein Master ki tasdeeq ki haalat (v1.2.8) bhi ati hai —
  /// sirf Profile ke display ke liye ('rejected' samait har value
  /// mehfooz hoti hai; koi local gate is se nahi badalta).
  static Future<void> refreshDriverStatus(AppStore store) async {
    if (store.driverId.isEmpty) return;
    final data = await _get(
        'drivers?select=active,cnic_status,gaari_status,licence_status&id=eq.${Uri.encodeComponent(store.driverId)}');
    if (data is! List || data.isEmpty) return;
    final row = data.first;
    if (row is Map) {
      store.setMasterActive(row['active'] == true);
      String st(String key) => row[key] is String ? row[key] as String : '';
      await store.applyMasterDocStatuses(
        cnic: st('cnic_status'),
        gaari: st('gaari_status'),
        licence: st('licence_status'),
      );
    }
  }

  // --- Store hooks → backend rows ---------------------------------------------

  static void _onHook(String kind, Object? payload) {
    final store = _store;
    if (store == null) return;
    switch (kind) {
      case 'booking':
        if (payload is Booking) unawaited(_pushRide(store, payload));
        break;
      case 'package':
        if (payload is MonthlyPackage) unawaited(_pushPackage(store, payload));
        break;
      case 'txn':
        if (payload is WalletTxn) unawaited(_pushLedger(store, payload));
        break;
      case 'profile':
        unawaited(_pushDriver(store));
        // Registration submit bhi isi hook se ata hai (store.save) —
        // document tasaveer bhi isi ke saath Master tak jati hain.
        unawaited(syncDriverDocs(store));
        // RC2 follow-through (v1.2.9): registration mukammal hote
        // hi drivers row durust tor par mojood hona bhi isi hook se
        // pakka hota hai (row na ho to banti hai, ho to registration
        // fields PATCH ho jate hain).
        if (store.profile.registrationComplete) {
          unawaited(ensureDriverRow(store));
        }
        break;
      case 'selfie':
        if (payload is String) unawaited(_pushSelfie(store, payload));
        break;
      case 'message':
        if (payload is MasterMessage) {
          unawaited(_pushMessage(store, payload));
        }
        break;
      case 'rating':
        if (payload is RideRating) {
          unawaited(_pushRating(store, payload));
        }
        break;
      case 'location':
        // Driver ki duty-wali live jagah — SIRF lat/lng/loc_at ki
        // halki PATCH (pura mirror nahi). Columns na hon (v129 se
        // pehle ki DB) to PATCH khamoshi se fail ho jata hai.
        unawaited(_pushDriverLocation(store));
        break;
    }
  }

  // --- Master messages (v1.2.7) ------------------------------------------------

  /// Ek message backend `messages` table mein bhejna. Kamyabi par
  /// store mein "sent" darj ho jata hai; nakami par message queued
  /// rehta hai aur [syncMessages] agli dafa dobara koshish karta hai —
  /// UI kabhi nahi rukti, koi error nahi dikhta.
  static Future<void> _pushMessage(AppStore store, MasterMessage m) async {
    final ok = await _upsert('messages', {
      'id': m.id,
      'sender_key': m.senderKey,
      'sender_role': m.senderRole,
      'sender_name': m.senderName,
      'sender_mobile': m.senderMobile,
      'sender_zone': m.senderZone,
      'category': m.category,
      'body': m.body,
      'is_read': m.isRead,
      'created_at': m.createdAt.toUtc().toIso8601String(),
    });
    if (ok) await store.markMessageSent(m.id);
  }

  /// Queued (abhi tak na bheje gaye) messages ki dobara koshish, phir
  /// apne tamam messages ki is_read haalat pull — app start par aur
  /// Master Messages screen khulne par chalti hai. Sab best-effort.
  static Future<void> syncMessages(AppStore store) async {
    for (final m in store.masterMessages.where((m) => !m.sent).toList()) {
      await _pushMessage(store, m);
    }
    final keys = <String>{
      for (final m in store.masterMessages)
        if (m.senderKey.isNotEmpty) m.senderKey,
    };
    for (final key in keys) {
      final data = await _get(
          'messages?select=id,is_read&sender_key=eq.${Uri.encodeComponent(key)}');
      if (data is! List) continue;
      for (final r in data) {
        if (r is Map && r['id'] is String) {
          await store.applyMessageRead(
              r['id'] as String, r['is_read'] == true);
        }
      }
    }
  }

  static Future<void> _pushRide(AppStore store, Booking b) async {
    await _upsert('rides', {
      'id': b.id,
      // Booking sirf passenger banata hai; driver tab jodta hai jab
      // is phone ke driver ne use qubool kiya ho.
      'driver_id':
          (b.status == 'pending' || b.status == 'cancelled')
              ? ''
              : store.driverId,
      'passenger_name': b.passengerName,
      'passenger_mobile': b.passengerPhone,
      'pickup': b.pickupLabel,
      'drop_off': b.dropLabel,
      'vehicle': b.vehicle,
      'km': b.distanceKm,
      'waiting_minutes': b.waitingMinutes,
      'fare': b.fare,
      'waiting_charges': b.waitingCharge,
      'fee': b.status == 'completed'
          ? Fares.serviceFee(b.fare + b.waitingCharge)
          : 0,
      'status': b.status,
      'date': b.createdAt.toUtc().toIso8601String(),
    });
  }

  static Future<void> _pushPackage(AppStore store, MonthlyPackage p) async {
    await _upsert('packages', {
      'id': p.id,
      'driver_id': '',
      'customer_name': p.passengerName,
      'customer_mobile': '',
      'pickup': p.pickup,
      'drop_off': p.drop,
      'vehicle': p.vehicle,
      'km': p.routeKm,
      'days': p.days,
      'amount': p.monthlyAmount,
      'fee': Fares.serviceFee(p.monthlyAmount),
      'date': p.createdAt.toUtc().toIso8601String(),
    });
  }

  static Future<void> _pushLedger(AppStore store, WalletTxn t) async {
    // Schema ke ledger mein balance ka column NAHI hai — is liye
    // balance-after note ke aakhir mein likha jata hai. Deposit
    // positive, service-charges ki katauti negative jati hai taaki
    // Master mein kul hisaab seedha jumla ho sake.
    await _upsert('ledger', {
      'id': t.id,
      'ts': t.date.toUtc().toIso8601String(),
      'type': t.type,
      'driver_id': store.driverId,
      'amount': t.type == 'fee' ? -t.amount : t.amount,
      'note': '${t.note} · Balance: ${rs(store.profile.walletBalance)}',
    });
  }

  /// Rozana selfie (v1.2.5): pehle (driver_id, date, done) wali CHECK
  /// row — wohi jo Master pehle se parhta hai — phir asal TASVEER
  /// Storage bucket 'selfies' mein upload karke us ka path
  /// driver_selfies.image_path mein darj hota hai, taaki Master par
  /// driver ki rozana selfie asal mein bhi nazar aye. Tasveer ka
  /// upload hamesha best-effort hai: nakami par selfieUploadedDate
  /// set NAHI hota, agli sync/startup par khud dobara koshish hoti
  /// hai — duty kabhi is par nahi rukti.
  static Future<void> _pushSelfie(AppStore store, String date) async {
    if (store.driverId.isEmpty || date.isEmpty) return;
    await _upsert('driver_selfies', {
      'driver_id': store.driverId,
      'date': date,
      'done': true,
    });
    final p = store.profile;
    if (p.selfieDate != date || p.selfieUploadedDate == date) return;
    if (p.selfiePath.isEmpty) return;
    final path = await _uploadSelfieImage(store);
    if (path == null) return;
    final recorded = await _upsert('driver_selfies', {
      'driver_id': store.driverId,
      'date': date,
      'done': true,
      'image_path': path,
    });
    // Path darj na ho saka ho to "uploaded" bhi nahi kehte — agli
    // sync par dobara koshish hogi.
    if (recorded) await store.markSelfieUploaded(date);
  }

  /// Selfie ki tasveer Storage bucket 'selfies' mein:
  /// path = selfies/<driver_id>/<yyyy-mm-dd>.jpg (upsert — dobara
  /// upload ho to wohi file taza ho jati hai). Safalta par object
  /// path, nakami par null. Bucket + policies migration
  /// backend-migration-v125.sql se bante hain.
  static Future<String?> _uploadSelfieImage(AppStore store) async {
    HttpClient? client;
    try {
      final file = File(store.profile.selfiePath);
      if (!await file.exists()) return null;
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) return null;
      final objectPath =
          '${store.driverId}/${store.profile.selfieDate}.jpg';
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client
          .postUrl(Uri.parse('$_storageBase/object/selfies/$objectPath'))
          .timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'image/jpeg');
      req.headers.set('x-upsert', 'true');
      req.add(bytes);
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode >= 200 && resp.statusCode < 300) {
        return objectPath;
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  /// Abhi liye/set kiye hue password ka fingerprint backend drivers
  /// row par foran darj karna (v1.2.9 follow-through) — duty-on par
  /// _SetPasswordDialog ke baad driver.dart yahan se bulata hai.
  /// Sirf pwd_fp PATCH hota hai (row na ho to khamosh nakami;
  /// registration mukammal ho to caller ensureDriverRow istemal
  /// karta hai). Hamesha best-effort aur khamosh.
  static Future<void> pushDriverFingerprint(AppStore store) async {
    if (store.driverId.isEmpty || store.profile.pwdFp.isEmpty) return;
    await _patch('drivers', store.driverId, {
      'pwd_fp': store.profile.pwdFp,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  /// RC2 follow-through (HOTFIX v1.2.9): owners jinka registration
  /// wizard se PEHLE ka hai, un ke backend rows kabhi bane hi nahi —
  /// kyunke registration ke sare purane raste upsert-style pushes
  /// (ledger/messages/waghaira) par munhasir thay, aur [_registered]
  /// ki gate (driverId + name + phone) pichli kisi push ke baghair
  /// pass nahi hoti. Nayi registration COMPLETE hote hi yahan se EK
  /// martaba row durust tor par banti hai: pehle GET (row hai ya
  /// nahi); hai to SIRF registration fields PATCH, nahi hai to
  /// mehfooz initial values ke saath full INSERT(_upsert).
  /// Kamyabi par true; offline/fail par false (khamosh, best-effort).
  static Future<bool> ensureDriverRow(AppStore store) async {
    if (store.driverId.isEmpty) return false;
    if (store.profile.name.trim().isEmpty ||
        store.profile.phone.trim().isEmpty) {
      return false;
    }
    final data = await _get(
        'drivers?select=id&id=eq.${Uri.encodeComponent(store.driverId)}');
    if (data is! List) return false;
    if (data.isNotEmpty) {
      // Row pehle se maujood hai — sirf registration ki maloomat
      // PATCH karein; status columns (Master-owned) ko hath NAHI.
      final p = store.profile;
      final fields = <String, dynamic>{
        'name': p.name,
        'mobile': p.phone,
        'vehicle': p.vehicle,
        'plate': p.plate,
        'zone': p.zone,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      };
      if (p.pwdFp.isNotEmpty) fields['pwd_fp'] = p.pwdFp;
      if (p.cnicNumber.isNotEmpty) fields['cnic_number'] = p.cnicNumber;
      if (p.licenceNumber.isNotEmpty) {
        fields['licence_number'] = p.licenceNumber;
      }
      if (p.vehicleBrand.isNotEmpty) fields['vehicle_brand'] = p.vehicleBrand;
      if (p.vehicleModel.isNotEmpty) fields['vehicle_model'] = p.vehicleModel;
      if (p.vehicleYear > 0) fields['vehicle_year'] = p.vehicleYear;
      if (p.vehicleColor.isNotEmpty) fields['vehicle_color'] = p.vehicleColor;
      return _patch('drivers', store.driverId, fields);
    }
    // Row maujood hi nahi — registration isi machine par mukammal
    // hui hai, to is phone ke store ki values is row ke liye durust
    // tareen hain. active hamesha false (tasdeeq Master ki hai);
    // document status columns bilkul NAHI bhejte (Master-owned,
    // backend ke apne defaults hi rahenge).
    final p = store.profile;
    await _pushDriver(store);
    final check = await _get(
        'drivers?select=id&id=eq.${Uri.encodeComponent(store.driverId)}');
    if (check is List && check.isNotEmpty) {
      // _pushDriver ne row upsert kar di (local masterActive is waqt
      // false hi hota hai — nayi registration kabhi khud active nahi
      // hoti; sirf token-race mehfooz karne ke liye active ko dobara
      // false par pakka kar dete hain).
      if (p.masterActive) {
        await _patch('drivers', store.driverId, {'active': false});
      }
      return true;
    }
    // Fallback: ghair-mutawaqqa surat (masalan _pushDriver ki write
    // kahin atak gayi ho) — zahir initial values ke saath khud
    // insert karein.
    final row = <String, dynamic>{
      'id': store.driverId,
      'name': p.name,
      'mobile': p.phone,
      'vehicle': p.vehicle,
      'plate': p.plate,
      'zone': p.zone,
      'active': false,
      'online': false,
      'on_ride': false,
      'wallet_balance': p.walletBalance,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    };
    if (p.pwdFp.isNotEmpty) row['pwd_fp'] = p.pwdFp;
    if (p.cnicNumber.isNotEmpty) row['cnic_number'] = p.cnicNumber;
    if (p.licenceNumber.isNotEmpty) row['licence_number'] = p.licenceNumber;
    if (p.vehicleBrand.isNotEmpty) row['vehicle_brand'] = p.vehicleBrand;
    if (p.vehicleModel.isNotEmpty) row['vehicle_model'] = p.vehicleModel;
    if (p.vehicleYear > 0) row['vehicle_year'] = p.vehicleYear;
    if (p.vehicleColor.isNotEmpty) row['vehicle_color'] = p.vehicleColor;
    if (p.lastLat != null && p.lastLng != null) {
      row['lat'] = p.lastLat;
      row['lng'] = p.lastLng;
    }
    return _upsert('drivers', row);
  }

  // --- Registration documents → Master Tasdeeq (v1.2.8) -----------------------

  static bool _docsSyncing = false;

  /// Registration ki document tasaveer Storage bucket 'driver-docs'
  /// mein bhejna taaki Master TASDEEQ screen mein har cheez asal
  /// tasveer mein check kar sake — baghair is ke koi ID chupke se
  /// active nahi hoti: driver app documents upload to kar sakti hai,
  /// lekin ACTIVE sirf Master karta hai (drivers.active, jo sirf
  /// [refreshDriverStatus] se pull hota hai).
  ///
  /// Har kind (cnic_front / cnic_back / vehicle / vehicle_reg /
  /// licence — sirf jab photo maujood ho — / profile) tab upload
  /// hota hai jab us ka local path khaali na ho AUR profile ke
  /// docUploaded marker se alag ho (matlab abhi upload nahi hua, ya
  /// photo dobara li gayi hai). Kamyabi par marker set hota hai aur
  /// aakhir mein _pushDriver drivers row par *_path columns likh
  /// deta hai. Sab best-effort: registration aur duty is par KABHI
  /// nahi rukti; nakami wali kind agli sync/startup par dobara
  /// koshish hoti hai.
  static Future<void> syncDriverDocs(AppStore store) async {
    if (_docsSyncing) return;
    if (!_registered(store)) return;
    final p = store.profile;
    final kinds = <String, String>{
      'cnic_front': p.cnicFrontPath,
      'cnic_back': p.cnicBackPath,
      'vehicle': p.vehiclePhotoPath,
      'vehicle_reg': p.vehicleRegPath,
      if (p.licencePhotoPath.isNotEmpty) 'licence': p.licencePhotoPath,
      'profile': p.profilePhotoPath,
    };
    final pending = kinds.entries
        .where((e) => e.value.isNotEmpty && p.docUploaded[e.key] != e.value)
        .toList();
    if (pending.isEmpty) return;
    _docsSyncing = true;
    try {
      var anyUploaded = false;
      for (final e in pending) {
        final objectPath = await _uploadDocImage(store, e.value, e.key);
        if (objectPath != null) {
          await store.markDocUploaded(e.key, e.value);
          anyUploaded = true;
        }
      }
      // Koi path naya bana ho to drivers row par bhi darj ho jaye —
      // Master Tasdeeq isi row se paths parhta hai.
      if (anyUploaded) await _pushDriver(store);
    } finally {
      _docsSyncing = false;
    }
  }

  /// Ek document ki tasveer bucket 'driver-docs' mein:
  /// path = driver-docs/<driver_id>/<kind>.jpg (upsert — dobara
  /// upload ho to wohi file taza ho jati hai). Safalta par object
  /// path, nakami par null. Bucket + policies migration
  /// backend-migration-v128.sql se bante hain. Bilkul
  /// [_uploadSelfieImage] wala andaaz.
  static Future<String?> _uploadDocImage(
      AppStore store, String localPath, String kind) async {
    HttpClient? client;
    try {
      final file = File(localPath);
      if (!await file.exists()) return null;
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) return null;
      final objectPath = '${store.driverId}/$kind.jpg';
      client = HttpClient();
      client.connectionTimeout = _timeout;
      final req = await client
          .postUrl(Uri.parse('$_storageBase/object/driver-docs/$objectPath'))
          .timeout(_timeout);
      req.headers.set('apikey', _key);
      req.headers.set(HttpHeaders.authorizationHeader, 'Bearer $_key');
      req.headers.set(HttpHeaders.contentTypeHeader, 'image/jpeg');
      req.headers.set('x-upsert', 'true');
      req.add(bytes);
      final resp = await req.close().timeout(_timeout);
      await resp.transform(utf8.decoder).join().timeout(_timeout);
      if (resp.statusCode >= 200 && resp.statusCode < 300) {
        return objectPath;
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      client?.close();
    }
  }

  // =========================================================================
  // v1.4.0 — Kami Fix Wave: live dispatch / ratings / announcements / polls
  //
  // Ye saare naye backend raaste migration backend-migration-v129.sql
  // par munhasir hain (tables: ratings, announcements; columns:
  // drivers.lat/lng/loc_at, rides.driver_lat/driver_lng). Migration
  // abhi NA chala ho to har request khamoshi se fail hoti hai —
  // koi crash nahi, koi UI asar nahi; local store hamesha asal sach
  // rehta hai aur same-device pilot bilkul waisa hi chalta hai.
  // =========================================================================

  /// Duty par driver ki live jagah — SIRF lat/lng (+loc_at) ki PATCH.
  /// loc_at column na ho to pehli koshish fail hoti hai aur dobara
  /// sirf lat/lng ke saath koshish hoti hai (purani schema mein bhi
  /// lat/lng maujood hain) — dono khamosh.
  static Future<void> _pushDriverLocation(AppStore store) async {
    if (store.driverId.isEmpty) return;
    final lat = store.profile.lastLat;
    final lng = store.profile.lastLng;
    if (lat == null || lng == null) return;
    final ok = await _patch('drivers', store.driverId, {
      'lat': lat,
      'lng': lng,
      'loc_at': DateTime.now().toUtc().toIso8601String(),
    });
    if (!ok) {
      await _patch('drivers', store.driverId, {'lat': lat, 'lng': lng});
    }
  }

  /// Chal rahi ride par driver ki mojooda jagah `rides.driver_lat/
  /// driver_lng` mein likhna — passenger ka ETA isi se banta hai.
  /// Ride row backend par maujood na ho (ya columns na hon) to
  /// khamosh nakami; passenger ka poll phir same-device wali maloom
  /// jagah par fallback kar deta hai.
  static Future<void> pushRideDriverPosition(
      AppStore store, String rideId, double lat, double lng) async {
    if (rideId.isEmpty) return;
    await _patch('rides', rideId, {
      'driver_lat': lat,
      'driver_lng': lng,
    });
  }

  /// Passenger ke liye EK ride row ki taaza haalat pull — status
  /// screen + Meri Bookings ka poll (~15s) isi par chalta hai.
  /// Sirf is phone ki local bookings mein maujood ride ki row ati
  /// hai; status + driver_lat/driver_lng wapas milte hain.
  /// Nakami/table na ho to null — caller same-device haalat par
  /// rehta hai, kuch crash nahi hota.
  static Future<Map<String, dynamic>?> fetchRideRow(String rideId) async {
    final data = await _get(
        'rides?select=id,status,driver_lat,driver_lng&id=eq.${Uri.encodeComponent(rideId)}');
    if (data is! List || data.isEmpty) return null;
    final row = data.first;
    return row is Map<String, dynamic> ? row : null;
  }

  /// Booking banate waqt TWO-PHONE dispatch ki maloomat: backend
  /// `drivers` mein active + online drivers ki taaza jagah se pickup
  /// tak ki sab se kam seedhi doori (km). Qareeb tareen driver
  /// [kDriverPickupRadiusKm] ke andar ho to us ki doori (warna null).
  /// Drivers ki list khaali/fail ho to bhi null — same-device pilot
  /// aur local flow is par KABHI nahi rukta. Sirf ittila hai —
  /// assignment driver ke qubool karne se hi hoti hai.
  static Future<double?> nearestOnlineDriverKm(
      double pickupLat, double pickupLng) async {
    final data = await _get(
        'drivers?select=id,lat,lng&active=eq.true&online=eq.true');
    if (data is! List) return null;
    double? best;
    for (final r in data) {
      if (r is! Map) continue;
      final lat = (r['lat'] as num?)?.toDouble();
      final lng = (r['lng'] as num?)?.toDouble();
      if (lat == null || lng == null) continue;
      final d = _straightKm(pickupLat, pickupLng, lat, lng);
      if (best == null || d < best) best = d;
    }
    if (best == null) return null;
    return best <= kDriverPickupRadiusKm ? best : null;
  }

  /// Do points ke darmiyan seedhi doori (km) — haversine (backend
  /// ke andar latlong package se bachne ke liye halki si hisaab).
  static double _straightKm(
      double lat1, double lng1, double lat2, double lng2) {
    const r = 6371.0;
    final dLat = (lat2 - lat1) * math.pi / 180;
    final dLng = (lng2 - lng1) * math.pi / 180;
    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1 * math.pi / 180) *
            math.cos(lat2 * math.pi / 180) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    return r * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  }

  /// Passenger ki ghair-final bookings ki backend wali taaza status
  /// Notification Centre ke diff engine ko dena — taaki band app ke
  /// doran doosre phone par badli haalat (masalan ride complete)
  /// app khulte hi EK notification ban sake. Status ko LOCAL booking
  /// par NAHI lagate — same-device pilot ki apni haalat hi local
  /// sach hai; ye sirf notification engine ka input hai.
  static Future<void> _primePassengerRideStatuses(AppStore store) async {
    final finals = <String>{'completed', 'cancelled', 'noshow'};
    final pending = store.bookings
        .where((b) => !finals.contains(b.status))
        .take(10)
        .toList();
    if (pending.isEmpty) return;
    final remote = <String, String>{};
    for (final b in pending) {
      final row = await fetchRideRow(b.id);
      if (row == null) continue;
      final st = row['status'];
      if (st is String && st.isNotEmpty) remote[b.id] = st;
    }
    if (remote.isNotEmpty) {
      await store.observeBookingStatuses('passenger',
          remoteStatus: remote);
    }
  }

  // --- Ratings (v1.4.0) --------------------------------------------------------

  /// Ek rating backend `ratings` table mein bhejna (upsert —
  /// booking_id hi pehchan hai). Table na ho to khamosh nakami;
  /// rating phone par mehfooz rehti hai aur [syncRatings] agli
  /// sync par dobara koshish karta hai.
  static Future<void> _pushRating(AppStore store, RideRating r) async {
    final ok = await _upsert('ratings', {
      'booking_id': r.bookingId,
      'driver_id': r.driverId,
      'driver_name': r.driverName,
      'passenger_name': r.passengerName,
      'stars': r.stars,
      'comment': r.comment,
      'created_at': r.createdAt.toUtc().toIso8601String(),
    });
    if (ok) await store.markRatingSent(r.bookingId);
  }

  /// Abhi tak na bheji gayi ratings ki dobara koshish (app start par).
  static Future<void> syncRatings(AppStore store) async {
    for (final r in store.ratings.where((r) => !r.sent).toList()) {
      await _pushRating(store, r);
    }
  }

  /// Is phone ke driver ka backend wala rating ausat — Driver
  /// Profile ke "Meri Rating" ke liye. Sirf stars pull hotay hain
  /// aur ausat yahin gina jata hai (koi RPC nahi chahiye). Table/
  /// data na ho to kuch nahi hota — Profile pehle wali haalat par
  /// rehta hai.
  static Future<void> pullOwnRatingAverage(AppStore store) async {
    if (store.driverId.isEmpty) return;
    final data = await _get(
        'ratings?select=stars&driver_id=eq.${Uri.encodeComponent(store.driverId)}');
    if (data is! List || data.isEmpty) return;
    var sum = 0, count = 0;
    for (final r in data) {
      if (r is Map) {
        final s = (r['stars'] as num?)?.toInt();
        if (s != null && s > 0) {
          sum += s;
          count++;
        }
      }
    }
    if (count > 0) {
      await store.applyBackendRating(sum / count, count);
    }
  }

  // --- Announcements (v1.4.0) --------------------------------------------------

  /// Master ke elanaat (backend `announcements`, sab se naye 20)
  /// Notification Centre ke liye pull. Table na ho to _get null
  /// deta hai aur kuch nahi hota. Pehli dafa sirf snapshot banta
  /// hai (store.applyAnnouncements ka usool) — purane elanaat par
  /// notification flood nahi ata.
  static Future<void> _pullAnnouncements(AppStore store) async {
    final data = await _get(
        'announcements?select=id,title,body,created_at&order=created_at.desc&limit=20');
    if (data is! List || data.isEmpty) return;
    final rows = <Map<String, dynamic>>[];
    for (final r in data) {
      if (r is Map<String, dynamic>) rows.add(r);
    }
    if (rows.isNotEmpty) await store.applyAnnouncements(rows);
  }

  /// Dono sides ke home/profile khulne par dobara elanaat check —
  /// siden ke apne lifecycle se halki si call. Sab best-effort.
  static Future<void> refreshAnnouncements(AppStore store) =>
      _pullAnnouncements(store);
}
