// v1.4.70 — AWAAZ WALI REHNUMAI (VoiceNavGuide) ke tests:
// marhala elan, OSRM maneuver ki ~200 m / mor-par wali
// awaaz, pohanchne ke jumle, aur steps na hon to bearing+
// doori wali fallback haddein। Sab saf hisaab hai — waqt
// har call par aage badha kar diya jata hai (minGap 6 s)।
import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'package:safar/route_service.dart';
import 'package:safar/voice_nav.dart';

RouteResult _route() => RouteResult(
      points: const [LatLng(24.8608, 67.0011), LatLng(24.8708, 67.0011)],
      distanceM: 1000,
      durationS: 300,
      steps: const [
        RouteStep(
          instruction: 'Chalna shuru karein',
          road: '',
          alongM: 0,
          at: LatLng(24.8608, 67.0011),
          type: 'depart',
        ),
        RouteStep(
          instruction: 'Daayein murein — M.A. Jinnah Road par',
          road: 'M.A. Jinnah Road',
          alongM: 500,
          at: LatLng(24.8658, 67.0011),
          type: 'turn',
          modifier: 'right',
        ),
        RouteStep(
          instruction: 'Manzil aa gayi',
          road: '',
          alongM: 1000,
          at: LatLng(24.8708, 67.0011),
          isArrive: true,
          type: 'arrive',
        ),
      ],
    );

void main() {
  group('voiceNavSpokenDist / direction', () {
    test('doori bolne wali shakal', () {
      expect(voiceNavSpokenDist(10), 'chand qadam');
      expect(voiceNavSpokenDist(204), '200 meter');
      expect(voiceNavSpokenDist(1200), '1.2 kilometer');
      expect(voiceNavSpokenDist(2000), '2 kilometer');
    });

    test('nisbat simt ke alfaaz', () {
      expect(voiceNavDirectionWord(0, 10), 'Seedha');
      expect(voiceNavDirectionWord(0, 90), 'Daayein taraf');
      expect(voiceNavDirectionWord(0, 270), 'Baayein taraf');
      expect(voiceNavDirectionWord(0, 180), 'Peeche ki taraf');
    });
  });

  group('VoiceNavGuide — steps wali rehnumai', () {
    test('pickup → mor → pohanchna → drop → mukammal jumla', () {
      final g = VoiceNavGuide();
      final route = _route();
      var t = DateTime(2026, 11, 22, 10, 0, 0);
      DateTime next() => t = t.add(const Duration(seconds: 10));

      String? upd({
        String status = 'accepted',
        bool started = false,
        double dist = 5000,
        double along = 0,
      }) =>
          g.update(
            status: status,
            rideStarted: started,
            distToTargetM: dist,
            route: route,
            alongM: along,
            headingDeg: 0,
            targetBearingDeg: 0,
            now: next(),
          );

      // Marhala shuru: sawari ki taraf wala elan।
      expect(upd(), contains('Sawari ki taraf chalein'));
      // Mor se 200 m pehle: doori ke saath hidayat।
      expect(upd(dist: 4800, along: 300),
          contains('200 meter par Daayein murein'));
      // Mor par: "Ab ..."।
      expect(upd(dist: 4600, along: 460), 'Ab daayein murein');
      // Pickup ke 40 m andar: pohanchne wala jumla।
      expect(upd(dist: 30, along: 990),
          'Aap manzil par pahunch gaye — sawari yahan khari hai');
      // Driver ne "Pahunch Gaya" dabaya — dobara elan NAHI।
      expect(upd(status: 'arrived', dist: 25, along: 995), isNull);
      // Ride shuru (code lag gaya) — manzil wala marhala।
      expect(upd(status: 'arrived', started: true, dist: 900, along: 0),
          contains('Ride shuru ho gayi hai'));
      // Manzil par pohanchna: complete + kiraya + intezaar।
      expect(
        upd(status: 'arrived', started: true, dist: 20, along: 995),
        'Aap manzil par pahunch gaye. Ride complete karein, '
        'musafir se kiraya lein, aur doosri ride ka intezaar karein',
      );
    });

    test('ek hi jumla dobara nahi bolta (dedupe + throttle)', () {
      final g = VoiceNavGuide();
      final route = _route();
      var t = DateTime(2026, 11, 22, 10, 0, 0);
      final first = g.update(
        status: 'accepted',
        rideStarted: false,
        distToTargetM: 5000,
        route: route,
        alongM: 0,
        headingDeg: 0,
        targetBearingDeg: 0,
        now: t,
      );
      expect(first, isNotNull);
      // 2 second baad wahi haalat — minGap ki wajah se khamoshi।
      final second = g.update(
        status: 'accepted',
        rideStarted: false,
        distToTargetM: 5000,
        route: route,
        alongM: 0,
        headingDeg: 0,
        targetBearingDeg: 0,
        now: t.add(const Duration(seconds: 2)),
      );
      expect(second, isNull);
    });
  });

  group('VoiceNavGuide — fallback (steps na hon)', () {
    test('500/200/100 m haddein simt ke saath', () {
      final g = VoiceNavGuide();
      var t = DateTime(2026, 11, 22, 10, 0, 0);
      DateTime next() => t = t.add(const Duration(seconds: 10));
      String? upd(double dist) => g.update(
            status: 'accepted',
            rideStarted: false,
            distToTargetM: dist,
            route: null,
            alongM: null,
            headingDeg: 0,
            targetBearingDeg: 90,
            now: next(),
          );

      expect(upd(3000), contains('Sawari ki taraf chalein'));
      expect(upd(480), contains('Daayein taraf chalein'));
      expect(upd(480), isNull); // wahi hadd dobara nahi
      expect(upd(190), contains('190 meter'));
      expect(upd(90), contains('90 meter'));
      // 40 m ke andar: pohanchne wala jumla।
      expect(upd(35), contains('sawari yahan khari hai'));
    });
  });
}
