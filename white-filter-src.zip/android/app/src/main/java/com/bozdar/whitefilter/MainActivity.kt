package com.bozdar.whitefilter

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView

/**
 * One big ON/OFF button.
 *
 * ON flow:
 *  1. Overlay permission (Settings.canDrawOverlays) — if missing, open Settings.
 *  2. Notification permission (Android 13+) — requested once, not blocking.
 *  3. MediaProjection consent dialog — on OK, start FilterService as a
 *     foreground service with the consent result.
 * OFF: send ACTION_STOP to the service.
 */
class MainActivity : Activity() {

    private lateinit var toggleButton: Button
    private lateinit var statusText: TextView

    private val projectionManager: MediaProjectionManager by lazy {
        getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toggleButton = findViewById(R.id.toggleButton)
        statusText = findViewById(R.id.statusText)

        toggleButton.setOnClickListener {
            if (FilterService.isRunning) {
                stopFilter()
            } else {
                startFilterFlow()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateUi()
    }

    private fun startFilterFlow() {
        // 1) Overlay permission.
        if (!Settings.canDrawOverlays(this)) {
            statusText.text = "Pehle 'Doosri apps ke upar dikhane' ki ijazat dein, phir wapas aa kar ON dabayein"
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }

        // 2) Notification permission (Android 13+). Ask once; the filter can
        // still run without it, the service notification just stays silent.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
            // Continue to the projection consent in the same tap.
        }

        // 3) MediaProjection consent.
        statusText.text = "Screen share ki ijazat dein…"
        @Suppress("DEPRECATION")
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    private fun stopFilter() {
        val intent = Intent(this, FilterService::class.java).apply {
            action = FilterService.ACTION_STOP
        }
        startService(intent)
        statusText.text = "Filter band ho raha hai…"
        toggleButton.text = "ON"
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PROJECTION) return

        if (resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, FilterService::class.java).apply {
                action = FilterService.ACTION_START
                putExtra(FilterService.EXTRA_RESULT_CODE, resultCode)
                putExtra(FilterService.EXTRA_RESULT_DATA, data)
            }
            // minSdk is 26, so startForegroundService is always available.
            startForegroundService(intent)
            statusText.text = "Filter chalu ho raha hai…"
        } else {
            statusText.text = "Ijazat nahi mili — filter band hai"
        }
    }

    private fun updateUi() {
        if (FilterService.isRunning) {
            toggleButton.text = "OFF"
            statusText.text = "Filter CHALU hai — log safed nazar aayenge"
        } else {
            toggleButton.text = "ON"
            statusText.text = "Filter band hai"
        }
    }

    companion object {
        private const val REQ_PROJECTION = 1001
        private const val REQ_NOTIFICATIONS = 1002
    }
}
