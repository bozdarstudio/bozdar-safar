// v1.4.38 WAVE tests — DEPOSIT SABOOT (SCREENSHOT): deposit
// khabar ke saath payment receipt ki photo lagane ka ikhtiyar।
// Photo LAZMI nahi hai; rasta wohi mojooda support-photo wala
// hai (MasterMessage.photoLocalPath → upload par photoPath,
// bucket 'driver-docs', messages.photo_path)। Body template
// (DEPOSIT KHABAR) bilkul NAHI badla — Master v1.4.20 ka ek-tap
// button usi ko parhta hai, is liye template yahan pin hai।
import 'package:flutter_test/flutter_test.dart';
import 'package:safar/lang.dart';

const _proofKeys = [
  'drv_dep_proof_btn',
  'drv_dep_proof_note',
  'drv_dep_proof_attached',
  'drv_dep_proof_remove',
];

void main() {
  group('v1.4.38 — Deposit saboot (screenshot)', () {
    test('proof keys dono zubaano mein maujood + number-free', () {
      for (final mode in ['ur', 'en']) {
        Lang.current = mode;
        for (final k in _proofKeys) {
          final v = tr(k);
          expect(v, isNot(k), reason: '$k ($mode) lang mein missing hai');
          expect(v.trim(), isNotEmpty, reason: '$k ($mode) khali hai');
          expect(v.contains('0312'), isFalse,
              reason: '$k ($mode) mein mobile number NAHI ana chahiye');
        }
      }
      Lang.current = 'ur';
    });

    test('proof note tasdeeq wali rehnumai deti hai', () {
      Lang.current = 'ur';
      expect(tr('drv_dep_proof_note').contains('tasdeeq'), isTrue);
      Lang.current = 'en';
      expect(
          tr('drv_dep_proof_note').toLowerCase().contains('verify'), isTrue);
      Lang.current = 'ur';
    });

    test('destination lock: paisa SIRF BankIslami account mein', () {
      for (final mode in ['ur', 'en']) {
        Lang.current = mode;
        final v = tr('drv_dep_only_bank');
        expect(v, isNot('drv_dep_only_bank'),
            reason: 'drv_dep_only_bank ($mode) lang mein missing hai');
        expect(v.contains('BankIslami'), isTrue,
            reason: 'drv_dep_only_bank ($mode) mein BankIslami lazmi hai');
        expect(v.contains('0312'), isFalse,
            reason: 'drv_dep_only_bank ($mode) mein number NAHI ana chahiye');
      }
      Lang.current = 'ur';
    });

    test('msg body template NAHI badla (Master ek-tap parse lock)', () {
      Lang.current = 'ur';
      final ur = tr('drv_dep_msg_body');
      expect(ur.startsWith('DEPOSIT KHABAR'), isTrue);
      expect(ur.contains('Rs {amount}'), isTrue);
      Lang.current = 'en';
      final en = tr('drv_dep_msg_body');
      expect(en.startsWith('DEPOSIT NOTICE'), isTrue);
      expect(en.contains('Rs {amount}'), isTrue);
      Lang.current = 'ur';
    });
  });
}
