import 'dart:async';
import 'package:flutter/material.dart';
import 'backend.dart';
import 'guide_audio.dart';
import 'lang.dart';
import 'theme.dart';

/// EMAIL + OTP (v1.4.7, spec §1) — teenon jagah mushtarka UI:
/// driver registration (Zaati Maloomat wala qadam), sawari ki
/// profile, aur logout ke baad dobara login wala darwaza
/// (OtpGatePage)।
///
/// Usool: Gmail LAZMI hai; 6-digit code usi email par jata hai
/// (Supabase Auth email OTP — email-proof ke liye; v1.4.14 se
/// verify par mila Auth session mehfooz bhi rehta hai aur
/// pehchan identity_links se bandhti hai — Backend ka session
/// wala section dekhein; app ka asal account system nahi
/// badalta)। Code verify hue baghair ID aage NAHI badhti।
/// Email galat ho to rasta Master se hai (pehchan
/// tasdeeq ke baad sudhar) — yahan sirf woh note dikhta hai।
class EmailOtpSection extends StatefulWidget {
  /// Email wala text field BAHAR se control hota hai taaki form
  /// (wizard/profile) apni value khud rakhe।
  final TextEditingController emailCtrl;

  /// Is email ki OTP tasdeeq pehle se ho chuki ho (profile mein
  /// verified email) to woh email — section "verify shuda" haalat
  /// se shuru hoti hai; email badalte hi tasdeeq khatam, naya
  /// code lazmi।
  final String alreadyVerifiedEmail;

  /// Verify kamyab hone par — verified email ke saath।
  final void Function(String email) onVerified;

  /// Wizard ke Zaati Maloomat qadam par email wali awaaz ki
  /// hidayat (guidance_email.mp3) khud chalti hai।
  final bool playGuideOnInit;

  const EmailOtpSection({
    super.key,
    required this.emailCtrl,
    required this.onVerified,
    this.alreadyVerifiedEmail = '',
    this.playGuideOnInit = false,
  });

  @override
  State<EmailOtpSection> createState() => _EmailOtpSectionState();
}

class _EmailOtpSectionState extends State<EmailOtpSection> {
  final _codeCtrl = TextEditingController();
  bool _sent = false;
  bool _busy = false;
  String? _error;
  String _verifiedEmail = '';

  // OTP SAKHTI (v1.4.13): ek code par zyada se zyada 5 ghalat
  // koshishen — us ke baad woh code band, naya code lazmi.
  // Code dobara bhejne par 60 second ka cooldown — button tab
  // tak band rehta hai aur label mein baqi second dikhte hain.
  static const int _maxAttempts = 5;
  static const int _resendCooldownSeconds = 60;
  int _failedAttempts = 0;
  bool _codeBlocked = false;
  int _cooldownLeft = 0;
  Timer? _cooldownTimer;

  String get _email => widget.emailCtrl.text.trim().toLowerCase();

  bool get _isVerified =>
      _verifiedEmail.isNotEmpty && _verifiedEmail == _email;

  @override
  void initState() {
    super.initState();
    _verifiedEmail = widget.alreadyVerifiedEmail.trim().toLowerCase();
    widget.emailCtrl.addListener(_onEmailChanged);
    if (widget.playGuideOnInit) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        unawaited(GuideAudio.play('guidance/guidance_email.mp3'));
      });
    }
  }

  @override
  void dispose() {
    widget.emailCtrl.removeListener(_onEmailChanged);
    _cooldownTimer?.cancel();
    _codeCtrl.dispose();
    super.dispose();
  }

  /// Dobara-bhejne ka 60-second cooldown shuru karna — button
  /// is doran band rehta hai, label mein baqi second ginte hain.
  void _startCooldown() {
    _cooldownTimer?.cancel();
    setState(() => _cooldownLeft = _resendCooldownSeconds);
    _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() {
        if (_cooldownLeft > 0) _cooldownLeft -= 1;
        if (_cooldownLeft <= 0) {
          _cooldownLeft = 0;
          t.cancel();
        }
      });
    });
  }

  void _onEmailChanged() {
    // Email badla to purani tasdeeq is email par nahi rehti —
    // naya code lazmi (setState sirf UI ke liye)।
    if (_verifiedEmail.isNotEmpty && _verifiedEmail != _email) {
      setState(() {
        _sent = false;
        _codeCtrl.clear();
      });
    }
  }

  bool _validEmail(String e) {
    return e.length >= 5 &&
        e.contains('@') &&
        e.split('@').last.contains('.');
  }

  Future<void> _sendCode() async {
    if (_cooldownLeft > 0) return;
    if (!_validEmail(_email)) {
      setState(() => _error = tr('otp_bad_email'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final ok = await Backend.sendEmailOtp(_email);
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (ok) {
        _sent = true;
        _error = null;
        // Naya code aya — purani ghalat-koshishon ki ginti aur
        // bandish khatam, ginti naye code ke liye zero se.
        _failedAttempts = 0;
        _codeBlocked = false;
      } else {
        _error = tr('otp_send_failed');
      }
    });
    if (ok) _startCooldown();
  }

  Future<void> _verify() async {
    if (_codeBlocked) {
      setState(() => _error = tr('otp_code_blocked_new'));
      return;
    }
    final code = _codeCtrl.text.trim();
    if (code.length != 6) {
      setState(() => _error = tr('otp_short_code'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final ok = await Backend.verifyEmailOtp(_email, code);
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (ok) {
        _verifiedEmail = _email;
        _error = null;
        _failedAttempts = 0;
        _codeBlocked = false;
      } else {
        _failedAttempts += 1;
        if (_failedAttempts >= _maxAttempts) {
          _codeBlocked = true;
          _error = tr('otp_five_failed');
        } else {
          _error = tr('otp_wrong_code');
        }
      }
    });
    if (ok) widget.onVerified(_email);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: widget.emailCtrl,
          keyboardType: TextInputType.emailAddress,
          decoration: InputDecoration(
            labelText: tr('otp_email_label'),
            hintText: tr('otp_email_hint'),
            prefixIcon: const Icon(Icons.email),
          ),
        ),
        const SizedBox(height: 8),
        if (_isVerified)
          Row(
            children: [
              const Icon(Icons.verified, color: Brand.green, size: 18),
              const SizedBox(width: 6),
              Expanded(
                child: Text(tr('otp_verified'),
                    style: const TextStyle(
                        color: Brand.green, fontWeight: FontWeight.w700)),
              ),
            ],
          )
        else ...[
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _codeCtrl,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  decoration: InputDecoration(
                    labelText: tr('otp_code_label'),
                    counterText: '',
                    prefixIcon: const Icon(Icons.pin),
                    isDense: true,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              OutlinedButton(
                onPressed: (_busy || _cooldownLeft > 0) ? null : _sendCode,
                child: Text(_cooldownLeft > 0
                    ? trf('otp_resend_after', {'n': '$_cooldownLeft'})
                    : (_sent ? tr('otp_resend') : tr('otp_send'))),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _busy ? null : _verify,
              icon: _busy
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.verified),
              label: Text(tr('otp_verify_btn')),
            ),
          ),
          Text(
            tr('otp_note'),
            style: const TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
        if (_error != null) ...[
          const SizedBox(height: 6),
          Text(_error!,
              style: const TextStyle(
                  color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
        ],
      ],
    );
  }
}

/// LOGIN OTP DARWAZA (v1.4.7, spec §1): logout ke baad dobara
/// login par — ya nayi device par — password ke baad ye screen
/// ati hai; jab tak usi Gmail par aya code verify na ho, ID aage
/// NAHI badhti। Kamyabi par true, band karne par false।
class OtpGatePage extends StatefulWidget {
  final String email;
  final String title;

  const OtpGatePage({super.key, required this.email, required this.title});

  @override
  State<OtpGatePage> createState() => _OtpGatePageState();
}

class _OtpGatePageState extends State<OtpGatePage> {
  late final _emailCtrl = TextEditingController(text: widget.email);

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.mark_email_read, size: 64, color: Brand.green),
          const SizedBox(height: 12),
          Text(
            tr('otp_gate_title'),
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          Text(
            tr('otp_gate_body'),
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 13.5, color: Colors.black87),
          ),
          const SizedBox(height: 18),
          EmailOtpSection(
            emailCtrl: _emailCtrl,
            onVerified: (_) => Navigator.of(context).pop(true),
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(tr('otp_not_now')),
          ),
        ],
      ),
    );
  }
}
