import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Ek OSRM maneuver — driver guidance banner isi se banta hai.
class RouteStep {
  /// Roman Urdu hidayat, bina doori ke (masalan
  /// "Daayein murein — M.A. Jinnah Road par").
  final String instruction;
  final String road;

  /// Route ke shuru se is maneuver tak ki doori (meters).
  final double alongM;
  final LatLng at;
  final bool isArrive;

  const RouteStep({
    required this.instruction,
    required this.road,
    required this.alongM,
    required this.at,
    this.isArrive = false,
  });

  Map<String, dynamic> toJson() => {
        'i': instruction,
        'r': road,
        'a': alongM,
        'lat': at.latitude,
        'lng': at.longitude,
        'arr': isArrive,
      };

  factory RouteStep.fromJson(Map<String, dynamic> j) => RouteStep(
        instruction: j['i'] as String,
        road: j['r'] as String? ?? '',
        alongM: (j['a'] as num).toDouble(),
        at: LatLng((j['lat'] as num).toDouble(), (j['lng'] as num).toDouble()),
        isArrive: j['arr'] as bool? ?? false,
      );
}

/// Route ki geometry par aage barhne ka hisaab (snapping + progress).
class RouteTrack {
  final List<LatLng> points;
  late final List<double> cumM;
  late final double totalM;

  RouteTrack(this.points) {
    cumM = List<double>.filled(points.length, 0);
    var acc = 0.0;
    for (var i = 1; i < points.length; i++) {
      acc += const Distance().as(LengthUnit.Meter, points[i - 1], points[i]);
      cumM[i] = acc;
    }
    totalM = acc;
  }

  double bearingBetween(LatLng a, LatLng b) {
    final lat1 = a.latitude * math.pi / 180;
    final lat2 = b.latitude * math.pi / 180;
    final dLng = (b.longitude - a.longitude) * math.pi / 180;
    final y = math.sin(dLng) * math.cos(lat2);
    final x = math.cos(lat1) * math.sin(lat2) -
        math.sin(lat1) * math.cos(lat2) * math.cos(dLng);
    return (math.atan2(y, x) * 180 / math.pi + 360) % 360;
  }

  /// [pos] ko route par sab se qareebi jagah par snap karke progress.
  ({LatLng snapped, double alongM, double bearingDeg}) progressAt(LatLng pos) {
    if (points.isEmpty) {
      return (snapped: pos, alongM: 0, bearingDeg: 0);
    }
    if (points.length == 1) {
      return (snapped: points.first, alongM: 0, bearingDeg: 0);
    }
    final cosLat = math.cos(pos.latitude * math.pi / 180);
    double px(LatLng p) => p.longitude * cosLat;
    double py(LatLng p) => p.latitude;
    var bestDist = double.infinity;
    var bestAlong = 0.0;
    var bestPoint = points.first;
    var bestBearing = 0.0;
    for (var i = 0; i < points.length - 1; i++) {
      final a = points[i];
      final b = points[i + 1];
      final ax = px(a), ay = py(a), bx = px(b), by = py(b);
      final dx = bx - ax, dy = by - ay;
      final len2 = dx * dx + dy * dy;
      var t = len2 == 0
          ? 0.0
          : ((px(pos) - ax) * dx + (py(pos) - ay) * dy) / len2;
      t = t.clamp(0.0, 1.0);
      final sx = ax + dx * t, sy = ay + dy * t;
      final ddx = px(pos) - sx, ddy = py(pos) - sy;
      final d2 = ddx * ddx + ddy * ddy;
      if (d2 < bestDist) {
        bestDist = d2;
        final segLen = cumM[i + 1] - cumM[i];
        bestAlong = cumM[i] + segLen * t;
        bestPoint = LatLng(sy, cosLat == 0 ? sx : sx / cosLat);
        bestBearing = bearingBetween(a, b);
      }
    }
    return (snapped: bestPoint, alongM: bestAlong, bearingDeg: bestBearing);
  }

  /// Kisi jagah se is polyline tak ki SAB SE KAM doori (meters)
  /// — v1.4.44 ROUTE OPTIONS: booking preview mein user ke tap
  /// se qareebi route pehchanne ke liye।
  double minDistanceTo(LatLng pos) {
    if (points.length < 2) return double.infinity;
    final cosLat = math.cos(pos.latitude * math.pi / 180);
    double px(LatLng p) => p.longitude * cosLat;
    double py(LatLng p) => p.latitude;
    var best = double.infinity;
    for (var i = 0; i < points.length - 1; i++) {
      final a = points[i];
      final b = points[i + 1];
      final ax = px(a), ay = py(a), bx = px(b), by = py(b);
      final dx = bx - ax, dy = by - ay;
      final len2 = dx * dx + dy * dy;
      var t = len2 == 0
          ? 0.0
          : ((px(pos) - ax) * dx + (py(pos) - ay) * dy) / len2;
      t = t.clamp(0.0, 1.0);
      final ddx = px(pos) - (ax + dx * t), ddy = py(pos) - (ay + dy * t);
      final d2 = ddx * ddx + ddy * ddy;
      if (d2 < best) best = d2;
    }
    // px/py "degree" space mein hain (lng cosLat se scale shuda)
    // — 1 degree ≈ 111195 m।
    return math.sqrt(best) * 111195;
  }
}

/// Ek mukammal route: asal sadak ki line + guidance steps.
/// [steps] khaali ho to ye sirf seedhi line hai (offline pehla istemal) —
/// guidance banner is par khaas offline jumla dikhata hai.
///
/// [distanceM] asal OSRM route ki SADAK wali doori hai (chune hue
/// route ke distance se, meters mein) — kiraya isi par banta hai.
/// Route ka intikhab [RouteService.pickOwnerRoute] karta hai: OWNER
/// RULE — sab se KAM distance wala route, basharte ke us ka duration
/// fastest route ke 1.6 guna se zyada na ho.
/// Sirf [isStraightFallback] wale natije mein ye seedhi (crow-flies)
/// doori hoti hai, kyunke woh asal route hai hi nahi.
class RouteResult {
  final List<LatLng> points;
  final double distanceM;
  final double durationS;
  final List<RouteStep> steps;

  /// True sirf tab jab ye natija asal OSRM route NAHI, balkay offline
  /// seedhi line hai (RouteService.straight). Cache mein sirf asal
  /// route save hote hain, is liye purane cache data mein ye flag na
  /// mile to false (asal route) hi samjha jata hai.
  final bool isStraightFallback;

  /// v1.4.44 ROUTE OPTIONS: is route ke ILAWA OSRM ke baqi asal
  /// routes — har ek mukammal RouteResult (geometry, doori,
  /// duration, steps ke saath)। Booking preview mein ye halki
  /// grey lines mein dikhte hain; user kisi par tap kare to
  /// WAHI route fare/line/steps ka wahid zariya ban jata hai।
  /// Har alternative ke apne alternatives khaali hote hain
  /// (nested nahi bante)।
  final List<RouteResult> alternatives;
  late final RouteTrack track = RouteTrack(points);

  RouteResult({
    required this.points,
    required this.distanceM,
    required this.durationS,
    required this.steps,
    this.isStraightFallback = false,
    this.alternatives = const [],
  });

  bool get hasSteps => steps.length > 1;

  /// Route ki doori kilometers mein — kiraaye ka hisaab isi se hota hai.
  double get distanceKm => distanceM / 1000;

  Map<String, dynamic> toJson() => {
        'pts': points.map((p) => [p.latitude, p.longitude]).toList(),
        'd': distanceM,
        't': durationS,
        'steps': steps.map((s) => s.toJson()).toList(),
        'fb': isStraightFallback,
        'alts': alternatives.map((a) => a.toJson()).toList(),
      };

  factory RouteResult.fromJson(Map<String, dynamic> j) => RouteResult(
        points: (j['pts'] as List)
            .map((e) => LatLng((e[0] as num).toDouble(), (e[1] as num).toDouble()))
            .toList(),
        distanceM: (j['d'] as num).toDouble(),
        durationS: (j['t'] as num).toDouble(),
        steps: ((j['steps'] as List?) ?? [])
            .map((e) => RouteStep.fromJson(e as Map<String, dynamic>))
            .toList(),
        isStraightFallback: j['fb'] as bool? ?? false,
        // Purane cache data mein 'alts' nahi hota — khaali hi sahi।
        alternatives: ((j['alts'] as List?) ?? [])
            .map((e) => RouteResult.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

/// "500 m" / "1.2 km" type saaf doori.
String fmtDist(double m) {
  if (m < 950) return '${(m / 10).round() * 10} m';
  return '${(m / 1000).toStringAsFixed(1)} km';
}

/// OSRM (muft, bina API key) se asal sadak ka route + steps/maneuvers.
/// Kamzor net ke liye: har route memory + SharedPreferences mein cache
/// hota hai — ek dafa bana hua route offline bhi line + steps ke saath
/// wapas mil jata hai. Network na mile aur cache bhi na ho to seedhi
/// line (bina steps) wapas hoti hai — jhooti position ya jhoota rasta
/// kabhi nahi banaya jata.
class RouteService {
  static final Map<String, RouteResult> _mem = {};
  static final Map<String, int> _memAt = {};

  /// CACHE EXPIRY (v1.4.27 — postmortem #23): route cache ki
  /// muddat 30 din — is se purani entry "taaza" nahi mani jati,
  /// dobara fetch hoti hai (band sadak khul jaye / naya rasta
  /// ban jaye to purana route hamesha ke liye chipka na rahe)।
  /// Purani entry sirf aakhri sahara hai: dobara fetch fail ho
  /// to seedhi (crow-flies) line ke bajaye wohi purana ASAL
  /// route milta hai। Har entry ke saath save ka waqt 'ts'
  /// (ms) darj hota hai; jin purani entries par 'ts' nahi woh
  /// expire hi mani jati hain।
  static const Duration cacheMaxAge = Duration(days: 30);

  /// Ek entry taaza hai ya nahi — khalis hisaab (tests ke liye)।
  static bool cacheEntryFresh(int? savedAtMs, int nowMs) {
    if (savedAtMs == null || savedAtMs <= 0) return false;
    return nowMs - savedAtMs < cacheMaxAge.inMilliseconds;
  }

  static String _key(LatLng a, LatLng b) =>
      'route_v2_${a.latitude.toStringAsFixed(3)},${a.longitude.toStringAsFixed(3)}'
      '|${b.latitude.toStringAsFixed(3)},${b.longitude.toStringAsFixed(3)}';

  static RouteResult straight(LatLng from, LatLng to) {
    final d = const Distance().as(LengthUnit.Meter, from, to);
    return RouteResult(
      points: [from, to],
      distanceM: d,
      durationS: 0,
      steps: const [],
      isStraightFallback: true,
    );
  }

  /// HEALTH ENGINE (v1.4.26): cache ke kharab entries ki safai —
  /// jo mehfooz route ab parha hi nahi jata (JSON kharab) woh
  /// hata diya jata hai taake agli fetch taaza route banaye.
  /// Hataye gaye entries ki ginti wapas milti hai. Durust
  /// entries ko hath NAHI lagta; [fetch] kharab entry par pehle
  /// se hi network ki taraf jata hai, ye sirf jama shuda
  /// kachra saaf karta hai.
  static Future<int> pruneCorruptCache() async {
    var removed = 0;
    try {
      final prefs = await SharedPreferences.getInstance();
      for (final key in prefs.getKeys().toList()) {
        if (!key.startsWith('route_v1_') && !key.startsWith('route_v2_')) continue;
        final raw = prefs.getString(key);
        if (raw == null) continue;
        var bad = false;
        try {
          final j = jsonDecode(raw);
          if (j is! Map<String, dynamic>) {
            bad = true;
          } else {
            RouteResult.fromJson(j);
          }
        } catch (_) {
          bad = true;
        }
        if (bad) {
          await prefs.remove(key);
          _mem.remove(key);
          _memAt.remove(key);
          removed++;
        }
      }
    } catch (_) {
      // Safai na bhi ho to app nahi rukti — ginti 0 hi sahi.
    }
    return removed;
  }

  static Future<RouteResult> fetch(LatLng from, LatLng to,
      {bool forceNetwork = false}) async {
    final key = _key(from, to);
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    RouteResult? stale;
    if (!forceNetwork) {
      final hit = _mem[key];
      if (hit != null && cacheEntryFresh(_memAt[key], nowMs)) return hit;
      if (hit != null) stale = hit;
      try {
        final prefs = await SharedPreferences.getInstance();
        final raw = prefs.getString(key);
        if (raw != null) {
          final j = jsonDecode(raw) as Map<String, dynamic>;
          final r = RouteResult.fromJson(j);
          if (cacheEntryFresh((j['ts'] as num?)?.toInt(), nowMs)) {
            _mem[key] = r;
            _memAt[key] = (j['ts'] as num?)?.toInt() ?? nowMs;
            return r;
          }
          // Expire shuda entry — taaza ki jagah nahi legi, lekin
          // network fail ho to aakhri sahara yahi hai।
          stale ??= r;
        }
      } catch (_) {
        // cache kharab ho to network ki taraf barhein
      }
    }
    try {
      final r = await _fetchOsrm(from, to);
      _mem[key] = r;
      _memAt[key] = nowMs;
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(
            key, jsonEncode({...r.toJson(), 'ts': nowMs}));
      } catch (_) {}
      return r;
    } catch (_) {
      if (stale != null) return stale;
      final cached = _mem[key];
      if (cached != null) return cached;
      return straight(from, to);
    }
  }

  /// OWNER ROUTE RULE (2026-11-13 04:13): alternatives mein se
  /// SAB SE KAM distance wala route — lekin agar us ka duration
  /// fastest route ke duration ke 1.6 guna se zyada ho (gali
  /// wala shortcut jo waqt bohat kha jaye) to FASTEST wala hi।
  /// Sirf ek route ho to wahi (index 0)। Khalis hisaab — tests
  /// ke liye alag rakha hai।
  static int pickRouteIndex(
      List<double> distancesM, List<double> durationsS) {
    if (distancesM.isEmpty || distancesM.length != durationsS.length) {
      return 0;
    }
    var fastest = 0;
    var shortest = 0;
    for (var i = 1; i < distancesM.length; i++) {
      if (durationsS[i] < durationsS[fastest]) fastest = i;
      if (distancesM[i] < distancesM[shortest]) shortest = i;
    }
    return durationsS[shortest] > durationsS[fastest] * 1.6
        ? fastest
        : shortest;
  }

  static Future<RouteResult> _fetchOsrm(LatLng from, LatLng to) async {
    final uri = Uri.parse(
        'https://router.project-osrm.org/route/v1/driving/'
        '${from.longitude},${from.latitude};${to.longitude},${to.latitude}'
        '?overview=full&geometries=geojson&steps=true&continue_straight=true'
        '&alternatives=3');
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    try {
      final req = await client.getUrl(uri);
      req.headers.set(HttpHeaders.userAgentHeader, 'SafarApp/1.2 (com.bozdar.safar)');
      final resp = await req.close().timeout(const Duration(seconds: 10));
      if (resp.statusCode != 200) {
        throw HttpException('OSRM ${resp.statusCode}');
      }
      final body = await resp.transform(utf8.decoder).join();
      final root = jsonDecode(body) as Map<String, dynamic>;
      final routes = root['routes'] as List?;
      if (routes == null || routes.isEmpty) {
        throw const HttpException('OSRM: no route');
      }
      // v1.4.44: SAARE alternatives parse hote hain — default
      // selection OWNER RULE se (sab se chhota, 1.6x duration
      // guard ke saath), baqi ROUTE OPTIONS ke tor par chune
      // hue route ke saath lag jate hain taake booking preview
      // mein user tap karke badal sake।
      final parsed = routes
          .map((e) => _parseRoute(e as Map<String, dynamic>, from))
          .toList(growable: false);
      if (parsed.length == 1) return parsed.first;
      final pick = pickRouteIndex(
        parsed.map((r) => r.distanceM).toList(),
        parsed.map((r) => r.durationS).toList(),
      );
      final chosen = parsed[pick];
      return RouteResult(
        points: chosen.points,
        distanceM: chosen.distanceM,
        durationS: chosen.durationS,
        steps: chosen.steps,
        alternatives: [
          for (var i = 0; i < parsed.length; i++)
            if (i != pick) parsed[i],
        ],
      );
    } finally {
      client.close(force: true);
    }
  }

  /// Ek OSRM route (JSON) → RouteResult: geometry (polyline) +
  /// guidance steps + doori/duration — sab ISI route ke, taake
  /// fare, line aur steps hamesha ek hi route ke hon।
  static RouteResult _parseRoute(Map<String, dynamic> route, LatLng from) {
    final coords =
        ((route['geometry'] as Map<String, dynamic>)['coordinates'] as List)
            .map((e) => LatLng((e[1] as num).toDouble(), (e[0] as num).toDouble()))
            .toList();
    final steps = <RouteStep>[];
    final legs = route['legs'] as List?;
    if (legs != null && legs.isNotEmpty) {
      final rawSteps =
          (legs.first as Map<String, dynamic>)['steps'] as List? ?? [];
      var along = 0.0;
      for (final s in rawSteps) {
        final st = s as Map<String, dynamic>;
        final man = (st['maneuver'] as Map<String, dynamic>?) ?? {};
        final loc = man['location'] as List?;
        final at = loc != null
            ? LatLng((loc[1] as num).toDouble(), (loc[0] as num).toDouble())
            : (coords.isNotEmpty ? coords.first : from);
        final type = man['type'] as String? ?? '';
        steps.add(RouteStep(
          instruction: _instruction(
            type: type,
            modifier: man['modifier'] as String?,
            exit: (man['exit'] as num?)?.toInt(),
            name: st['name'] as String? ?? '',
          ),
          road: st['name'] as String? ?? '',
          alongM: along,
          at: at,
          isArrive: type == 'arrive',
        ));
        along += (st['distance'] as num? ?? 0).toDouble();
      }
    }
    return RouteResult(
      points: coords,
      distanceM: (route['distance'] as num).toDouble(),
      durationS: (route['duration'] as num).toDouble(),
      steps: steps,
    );
  }

  /// OSRM maneuver → Roman Urdu hidayat (Google Maps walay andaaz mein).
  static String _instruction({
    required String type,
    String? modifier,
    int? exit,
    required String name,
  }) {
    final road = name.trim();
    final roadPart = road.isEmpty ? '' : ' — $road par';
    final m = modifier ?? '';
    String turn(String side) =>
        (side == 'left' ? 'Baayein murein' : 'Daayein murein') + roadPart;
    switch (type) {
      case 'depart':
        return 'Chalna shuru karein';
      case 'arrive':
        return 'Manzil aa gayi';
      case 'turn':
        switch (m) {
          case 'left':
            return turn('left');
          case 'right':
            return turn('right');
          case 'slight left':
            return 'Halki baayein murein$roadPart';
          case 'slight right':
            return 'Halki daayein murein$roadPart';
          case 'sharp left':
            return 'Tez baayein murein$roadPart';
          case 'sharp right':
            return 'Tez daayein murein$roadPart';
          case 'uturn':
            return 'U-turn lein$roadPart';
          default:
            return 'Seedha chalein$roadPart';
        }
      case 'new name':
      case 'continue':
        return 'Seedha chalein$roadPart';
      case 'merge':
        return 'Traffic mein shamil ho jayein$roadPart';
      case 'on ramp':
        return 'Ramp par chalein$roadPart';
      case 'off ramp':
        return m.contains('left')
            ? 'Ramp se baayein utrein$roadPart'
            : 'Ramp se daayein utrein$roadPart';
      case 'fork':
        return m.contains('left')
            ? 'Kaante par baayein rakhen$roadPart'
            : m.contains('right')
                ? 'Kaante par daayein rakhen$roadPart'
                : 'Seedha rakhen$roadPart';
      case 'end of road':
        return m.contains('left')
            ? 'Road ke aakhir par baayein murein$roadPart'
            : m.contains('right')
                ? 'Road ke aakhir par daayein murein$roadPart'
                : 'Road khatm ho rahi hai$roadPart';
      case 'roundabout':
      case 'rotary':
      case 'roundabout turn':
        const ord = ['', 'pehli', 'doosri', 'teesri', 'chauthi', 'panchwi'];
        final n = exit ?? 1;
        final word = n >= 1 && n < ord.length ? ord[n] : '$n wi';
        return 'Gol chowrangi se $word nikasi lein$roadPart';
      case 'exit roundabout':
      case 'exit rotary':
        return 'Gol chowrangi se bahar niklein$roadPart';
      default:
        return 'Seedha chalein$roadPart';
    }
  }
}
