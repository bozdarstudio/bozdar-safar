// v1.4.59 (malik ki shikayat 2026-11-16): DIN wala map ab
// CARTO VECTOR style NAHI raha — kamzor mobile net (2–5 KB/s)
// par vector tiles ki gali-data pohanchta hi nahi tha, map
// sirf style ke khaali cream pas-manzar (#fbf8f3) par atka
// rehta tha: safed map, koi sadak NAHI। Ab basemap OpenStreetMap
// ki RASTER tiles hain (tile.openstreetmap.org) — har tile ek
// tasveer hai, hisso mein foran load hoti hai, sadkein apne
// ASAL rangon mein saaf aur moti nazar ati hain (dhup mein
// bhi parhi jati hain — raster-contrast/saturation ka halka
// sa boost isi liye hai, wash-out bilkul NAHI)।
// CARTO RASTER istemal NAHI hua: us ki tiles par "API KEY
// REQUIRED" ka watermark ata hai (parent ne jaanch kar mana
// kiya hai)। CARTO se sirf FONTS (glyphs) barkarar hain —
// app ke apne label layers (A/B pin naam, teer/gaari ke
// maqam-naam) unhi se bante hain।
// App ke overlay sources/layers (route, markers, labels)
// safar_map.dart mein code se bante hain — is JSON mein
// sirf BASEMAP hai।
const String kDayStyleJson = r'''{
  "version": 8,
  "name": "Safar Day",
  "metadata": {},
  "sources": {
    "osm": {
      "type": "raster",
      "tiles": ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
      "tileSize": 256,
      "attribution": "© OpenStreetMap contributors"
    }
  },
  "sprite": "https://tiles.basemaps.cartocdn.com/v/20261026-01/gl/voyager-gl-style/sprite",
  "glyphs": "https://tiles.basemaps.cartocdn.com/v/20261026-01/fonts/{fontstack}/{range}.pbf",
  "layers": [
    {
      "id": "safar-bg",
      "type": "background",
      "paint": {"background-color": "#ece7db"}
    },
    {
      "id": "osm",
      "type": "raster",
      "source": "osm",
      "paint": {"raster-contrast": 0.08, "raster-saturation": 0.06}
    }
  ]
}''';
