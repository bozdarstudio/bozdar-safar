// =====================================================================
// lang.dart — DO ZUBAANEIN (owner hukm 2026-11-11 15:35)
// App Urdu (default, maujooda Roman Urdu wording) aur English —
// user Settings / menu se chunta hai; pasand store mein
// 'app_lang' ke naam se mehfooz rehti hai (band karke kholne par
// bhi wahi). Ek hi shared pasand dono modes (passenger + driver)
// par lagu hoti hai — store.setLang dono jagah se call hota hai।
//
// Tareeqa: tr('key') maujooda zubaan ki string deta hai;
// trf('key', {'x': ...}) {x} wali jagahain bhar deta hai।
// Zubaan badalte hi store notifyListeners karta hai aur main.dart
// ka root AnimatedBuilder poori UI foran dobara banata hai —
// restart NAHI chahiye।
//
// COVERAGE (v1.4.29): home/booking flow, driver request card,
// active-ride sheets, navigation view, complete/cash screen aur
// dono menus ke labels END-TO-END dono zubaano mein hain।
// Baqi gehri screens (history tafseel, support chat, documents
// waghera) abhi Urdu mein hain — tafseel MAPFLOW-WAVE-NOTES.md
// mein darj hai।
// =====================================================================

import 'package:flutter/material.dart';

/// Maujooda zubaan ka code: 'ur' (default) ya 'en'।
/// store._loadPrefs isay mehfooz pasand se bharta hai; setLang
/// badalta hai।
class Lang {
  static String current = 'ur';
  static bool get isEn => current == 'en';
}

/// Zubaan ke naam dono zubaano mein (chooser ke liye hamesha
/// dono dikhte hain)।
const String kLangNameUr = 'Urdu (اردو)';
const String kLangNameEn = 'English';

String tr(String key) {
  final m = Lang.isEn ? _en : _ur;
  return m[key] ?? _ur[key] ?? key;
}

String trf(String key, Map<String, String> args) {
  var s = tr(key);
  args.forEach((k, v) {
    s = s.replaceAll('{$k}', v);
  });
  return s;
}

/// v1.4.30: cancel/wajah wale tay-shuda options (kRideReasonOptions)
/// ki NUMAISH maujooda zubaan mein — lekin record mein hamesha
/// ASAL (canonical Roman Urdu) lafz hi mehfooz hota hai, taaki
/// Master ka record dono zubaano mein ek jaisa rahe. List se
/// bahir ki wajah waisa hi dikhta hai jaisa hai।
String reasonOptionLabel(String canonical) {
  switch (canonical) {
    case 'Plan badal gaya':
      return tr('r_plan_changed');
    case 'Driver dair se aaya':
      return tr('r_driver_late');
    case 'Ghalat jagah aa gaya':
      return tr('r_wrong_place');
    case 'Yahan kaam tha':
      return tr('r_work_here');
    case 'Manzil badal gayi':
      return tr('r_dest_changed');
    case 'Emergency':
      return tr('r_emergency');
    case 'Doosri wajah':
      return tr('r_other');
  }
  return canonical;
}

const Map<String, String> _ur = {
  // --- Aam / menus ---
  'language': 'Zubaan / Language',
  'radius_title': 'Pickup Ka Daira (Radius)',
  'radius_hint': 'Sirf itni doori ke andar ki rides aap ko ayengi. Shuru mein 2 km hai — 5 km tak badha sakte hain, 2 se kam nahi.',
  'radius_saved': 'Radius save ho gaya',
  'language_sub': 'App ki zubaan chunein — Urdu ya English',
  'my_rides': 'Meri Rides',
  'my_info': 'Meri Maloomat',
  'support': 'Madad / Support',
  'app_health': 'App Ki Haalat',
  'logout': 'Logout',
  'history': 'Tareekh (History)',
  'home': 'Home',
  // --- Booking flow (passenger) ---
  'where_to': 'Kahan Jana Hai?',
  'pickup_point': 'Pickup jagah',
  'drop_point': 'Drop jagah (manzil)',
  'choose_vehicle': 'Gaari Chunein',
  'book_ride': 'Ride Pakki Karein',
  'pin_mode': 'Pin Mode',
  'type_address': 'Pata Likhein',
  'set_on_map': 'Map par jagah lagayein',
  'searching_driver': 'Driver dhoondh rahe hain…',
  'driver_found': 'Driver mil gaya!',
  'cancel_ride': 'Ride Cancel Karein',
  'fare_after_booking': 'Kiraya booking pakki honay ke baad nazar ayega',
  'min_fare_note': 'Kam se kam kiraya Rs 150 hai',
  'search_busy': 'Jagahen dhoondh rahe hain…',
  'search_failed': 'Jagahen nahi mil sakein — internet check karein, ya map par pin lagayein.',
  'search_no_results': 'Is naam ki koi jagah nahi mili.',
  // --- Driver tabs ---
  'tab_trips': 'Trips',
  'tab_pool': 'Pool',
  'tab_money': 'Paisay',
  'tab_chats': 'Chats',
  'tab_profile': 'Profile',
  // --- Driver request card ---
  'new_ride': 'Nayi Ride',
  'accept_ride': 'Ride Uthayein',
  'pickup': 'Pickup',
  'dropoff': 'Manzil (Drop)',
  'pickup_eta_prefix': 'Pickup tak andaza waqt: ',
  'ride_fare': 'Kiraya',
  'passenger': 'Sawari',
  // --- Active ride sheet ---
  'target_pickup': 'Pickup',
  'target_drop': 'Manzil (Drop)',
  'total_fare': 'KUL KIRAYA',
  'call': 'Call',
  'waiting': 'Waiting',
  'waiting_sub_arrived': 'Waiting ki tafseel dekhein',
  'waiting_sub_before': 'Pohanchne par waiting timer khud shuru hota hai',
  'route_in_navigator': 'Route in Navigator',
  'route_in_navigator_sub': 'Bahari navigation app mein rasta kholein',
  'cancel_ride_driver': 'Ride Cancel Karein',
  'cancel_reason_sub': 'Wajah ke saath record hoga',
  'arrived_slide': 'Pohanch Gaya — slide karein',
  'complete_slide': 'Ride Mukammal — slide karein',
  'start_slide': 'Start Trip — slide karein',
  'start_legacy_slide': 'Ride Shuru Karein — slide karein',
  'no_show': 'Sawari Nahi Aayi (No-show)',
  'waiting_started_snack': 'Waiting timer shuru — pehle {n} minute muft hain.',
  'waiting_title': 'Waiting',
  'waiting_free_note': 'Pehle {n} minute muft hain — us ke baad har minute ka charge kiraye mein judta hai.',
  'no_number': 'Sawari ka number maujood nahi hai.',
  'call_failed': 'Call nahi ho saki.',
  'nav_failed': 'Navigator nahi khul saka.',
  // --- Navigation view ---
  'open_other_nav': 'Doosri navigation app kholein',
  'gps_searching': 'GPS signal dhoondh rahe hain…',
  'route_finding': 'Rasta dhoondh rahe hain…',
  'go_straight': 'Seedha chalte rahen',
  'arrived_destination': 'Aap manzil par pohanch gaye',
  'remaining': 'baqi',
  'arrived_pickup': 'Pickup par pohanch gaye',
  'location_waiting': 'Location ka intezaar ho raha hai… position milte hi guidance shuru ho jayegi.',
  'gps_needed': 'Guidance ke liye location on karein aur ijazat dein — baghair asal position ke na arrow dikhega, na banner.',
  // --- Cash screen ---
  'passenger_will_pay': 'Sawari {amt} degi',
  'collect_cash': 'Naqad Wasooli',
  'trip_completed': 'Trip mukammal',
  'trip_price': 'Trip price',
  'waiting_charge': 'Waiting charge',
  'fee_record_note': 'Fee ka record khud ban gaya hai — ye raqam sawari se cash lein.',
  'done': 'Done',
  'cancel_btn': 'Booking Mansookh Karein',
  'cancel_why_passenger': 'Ride kyun mansookh kar rahe hain?',
  'cancel_title_arrived': 'Driver pohanch kar intezaar kar raha hai — cancel ki wajah LAZMI hai',
  'expired_title': 'Booking ka waqt khatm',
  'expired_msg': 'Waqt khatm — koi driver nahi mila',
  'noshow_rule_hint': 'Pehle 5 minute intezaar MUFT hai. Us ke baad: waiting chalu rakh sakte hain (charges jurenge) ya "Sawari Nahi Aayi" se cancel — ye cancel aap ke record mein kharabi NAHI gini jayegi.',
  'help': 'Madad',
  'pin_mode_btn': 'Map Se Pin Lagayein',
  'trip_distance': 'Safar ki doori: {km} km',
  'route_finding_p': 'Route maloom kiya ja raha hai…',
  'waiting_sub_live': '{mins} minute · {amt} (pehle {n} min muft)',
  'waiting_live_line': '{mins} minute ho gaye hain — ab tak ka waiting charge {amt} hai.',
  'cancel_why': 'Ye ride kyun cancel kar rahe hain?',
  'ride_cancelled': 'Ride cancel ho gayi.',
  'new_booking_chip': 'NAYI BOOKING',
  'waiting_explain': 'Waiting timer "Pohanch Gaya" dabate hi khud shuru ho jata hai aur ride mukammal hone tak chalta hai. Pehle {n} minute muft hain, us ke baad gaari ke hisab se charges judte hain. Sawari beech raaste mein ruke to woh waqt bhi isi timer mein gina jata hai.',
  'waiting_timer_label': 'WAITING TIMER — RIDE ABHI JARI HAI',
  // --- v1.4.30: wajah wala sheet (ride-flow i18n mukammal) ---
  'reason_note': 'Wajah ride ke record ke saath mehfooz rahegi — taaki company ko asal baat pata chale.',
  'reason_own_words': 'Apni baat (ikhtiyari)',
  'reason_own_hint': 'Kuch aur batana ho to yahan likhein…',
  'reason_submit': 'Jama Karein (Submit)',
  'reason_back_no_cancel': 'Wapas — cancel NAHI karna',
  'end_here_title': 'Ride yahan kyun khatam kar rahe hain?',
  'end_here_submit': 'Ride Yahan Khatam Karein',
  'driver_decline_title': 'Ye ride kyun nahi le rahe?',
  'r_plan_changed': 'Plan badal gaya',
  'r_driver_late': 'Driver dair se aaya',
  'r_wrong_place': 'Ghalat jagah aa gaya',
  'r_work_here': 'Yahan kaam tha',
  'r_dest_changed': 'Manzil badal gayi',
  'r_emergency': 'Emergency',
  'r_other': 'Doosri wajah',
  // --- v1.4.30: Sahulat ---
  'sahulat_title': 'Aap ki Sahulat',
  'sahulat_progress': '{done} / {target} rides mukammal — {left} aur rides ke baad 3 Muft Rides (3 km tak) milengi.',
  'sahulat_free_ready': 'Aap ke paas {n} Muft Rides hain (har ek 3 km tak) — booking par "Muft Ride" chunein, kiraya Rs 0.',
  'sahulat_use_free': 'Muft Ride istemal karein (Rs 0)',
  'sahulat_free_driver_note': 'Ye company ki muft ride hai — aap ka hissa company degi',
  'sahulat_first_discount': 'Pehli ride riayat: Rs {amt} (fee se) — driver ko poora paisa milega',
  // --- v1.4.30: Display (Din/Raat) + 3D ---
  'display_day': 'Din',
  'display_night': 'Raat',
  'display_auto': 'Khud-ba-khud',
  'map_3d': '3D',
  'next_road': 'Agli gali',
};

const Map<String, String> _en = {
  // --- Common / menus ---
  'language': 'Language / Zubaan',
  'radius_title': 'Pickup Radius',
  'radius_hint': 'You will only get rides within this distance. It starts at 2 km — you can raise it up to 5 km, never below 2 km.',
  'radius_saved': 'Radius saved',
  'language_sub': 'Choose the app language — English or Urdu',
  'my_rides': 'My Rides',
  'my_info': 'My Information',
  'support': 'Support / Help',
  'app_health': 'App Health',
  'logout': 'Logout',
  'history': 'History',
  'home': 'Home',
  // --- Booking flow (passenger) ---
  'where_to': 'Where do you want to go?',
  'pickup_point': 'Pickup point',
  'drop_point': 'Drop point (destination)',
  'choose_vehicle': 'Choose a Vehicle',
  'book_ride': 'Confirm Ride',
  'pin_mode': 'Pin Mode',
  'type_address': 'Type Address',
  'set_on_map': 'Set location on the map',
  'searching_driver': 'Finding a driver…',
  'driver_found': 'Driver found!',
  'cancel_ride': 'Cancel Ride',
  'fare_after_booking': 'The fare will be shown after the booking is confirmed',
  'min_fare_note': 'Minimum fare is Rs 150',
  'search_busy': 'Searching places…',
  'search_failed': 'Could not search places — please check your internet, or set the pin on the map.',
  'search_no_results': 'No place found with this name.',
  // --- Driver tabs ---
  'tab_trips': 'Trips',
  'tab_pool': 'Pool',
  'tab_money': 'Money',
  'tab_chats': 'Chats',
  'tab_profile': 'Profile',
  // --- Driver request card ---
  'new_ride': 'New Ride',
  'accept_ride': 'Accept Ride',
  'pickup': 'Pickup',
  'dropoff': 'Drop (Destination)',
  'pickup_eta_prefix': 'Time to pickup (approx): ',
  'ride_fare': 'Fare',
  'passenger': 'Passenger',
  // --- Active ride sheet ---
  'target_pickup': 'Pickup',
  'target_drop': 'Drop (Destination)',
  'total_fare': 'TOTAL FARE',
  'call': 'Call',
  'waiting': 'Waiting',
  'waiting_sub_arrived': 'See waiting details',
  'waiting_sub_before': 'The waiting timer starts by itself when you arrive',
  'route_in_navigator': 'Route in Navigator',
  'route_in_navigator_sub': 'Open the route in an outside navigation app',
  'cancel_ride_driver': 'Cancel Ride',
  'cancel_reason_sub': 'It will be recorded with a reason',
  'arrived_slide': 'I Have Arrived — slide to confirm',
  'complete_slide': 'Complete Ride — slide to confirm',
  'start_slide': 'Start Trip — slide to confirm',
  'start_legacy_slide': 'Start Ride — slide to confirm',
  'no_show': 'Passenger Did Not Come (No-show)',
  'waiting_started_snack': 'Waiting timer started — the first {n} minutes are free.',
  'waiting_title': 'Waiting',
  'waiting_free_note': 'The first {n} minutes are free — after that, each minute is added to the fare.',
  'no_number': 'The passenger has no phone number.',
  'call_failed': 'The call could not be made.',
  'nav_failed': 'The navigator could not be opened.',
  // --- Navigation view ---
  'open_other_nav': 'Open another navigation app',
  'gps_searching': 'Looking for GPS signal…',
  'route_finding': 'Finding the route…',
  'go_straight': 'Keep going straight',
  'arrived_destination': 'You have reached your destination',
  'remaining': 'left',
  'arrived_pickup': 'You have reached the pickup point',
  'location_waiting': 'Waiting for your location… guidance will start as soon as your position is found.',
  'gps_needed': 'Please turn on location and allow permission for guidance — without your real position, neither the arrow nor the banner can be shown.',
  // --- Cash screen ---
  'passenger_will_pay': 'The passenger will pay {amt}',
  'collect_cash': 'Collect Cash',
  'trip_completed': 'Trip completed',
  'trip_price': 'Trip price',
  'waiting_charge': 'Waiting charge',
  'fee_record_note': 'The fee record has been made by itself — please take this amount in cash from the passenger.',
  'done': 'Done',
  'cancel_btn': 'Cancel Booking',
  'cancel_why_passenger': 'Why are you cancelling this ride?',
  'cancel_title_arrived': 'The driver has arrived and is waiting — a reason for cancelling is REQUIRED',
  'expired_title': 'Booking time over',
  'expired_msg': 'Time over — no driver was found',
  'noshow_rule_hint': 'The first 5 minutes of waiting are FREE. After that: you may keep waiting (charges will be added) or cancel with "Passenger Did Not Come" — this cancel will NOT be counted as a fault on your record.',
  'help': 'Help',
  'pin_mode_btn': 'Set Pin on Map',
  'trip_distance': 'Trip distance: {km} km',
  'route_finding_p': 'Finding the route…',
  'waiting_sub_live': '{mins} min · {amt} (first {n} min free)',
  'waiting_live_line': '{mins} minutes so far — the waiting charge so far is {amt}.',
  'cancel_why': 'Why are you cancelling this ride?',
  'ride_cancelled': 'The ride has been cancelled.',
  'new_booking_chip': 'NEW BOOKING',
  'waiting_explain': 'The waiting timer starts by itself as soon as you tap "I Have Arrived" and runs until the ride is completed. The first {n} minutes are free; after that, charges are added according to the vehicle. If the passenger stops somewhere on the way, that time is also counted in this timer.',
  'waiting_timer_label': 'WAITING TIMER — RIDE IN PROGRESS',
  // --- v1.4.30: reason sheet (ride-flow i18n complete) ---
  'reason_note': 'The reason stays saved with the ride record — so the company knows what actually happened.',
  'reason_own_words': 'Your own words (optional)',
  'reason_own_hint': 'Write anything else here…',
  'reason_submit': 'Submit',
  'reason_back_no_cancel': 'Back — do NOT cancel',
  'end_here_title': 'Why are you ending the ride here?',
  'end_here_submit': 'End Ride Here',
  'driver_decline_title': 'Why are you not taking this ride?',
  'r_plan_changed': 'Plan changed',
  'r_driver_late': 'Driver came late',
  'r_wrong_place': 'Went to the wrong place',
  'r_work_here': 'Had work here',
  'r_dest_changed': 'Destination changed',
  'r_emergency': 'Emergency',
  'r_other': 'Another reason',
  // --- v1.4.30: Sahulat (passenger benefits) ---
  'sahulat_title': 'Your Benefits',
  'sahulat_progress': '{done} / {target} rides completed — {left} more rides and you earn 3 Free Rides (up to 3 km each).',
  'sahulat_free_ready': 'You have {n} Free Rides (up to 3 km each) — choose "Free Ride" when booking, fare Rs 0.',
  'sahulat_use_free': 'Use a Free Ride (Rs 0)',
  'sahulat_free_driver_note': 'This is a company free ride — the company will pay your share',
  'sahulat_first_discount': 'First-ride discount: Rs {amt} (from the fee) — the driver gets the full amount',
  // --- v1.4.30: Display (Day/Night) + 3D ---
  'display_day': 'Day',
  'display_night': 'Night',
  'display_auto': 'Auto',
  'map_3d': '3D',
  'next_road': 'Next street',
};

/// Zubaan chune ka dialog — dono jagah (passenger menu aur
/// driver profile) se yehi khulta hai। Chunne par [onPick]
/// chalta hai (store.setLang) aur UI foran refresh hoti hai।
Future<void> showLanguageChooser(
  BuildContext context, {
  required String current,
  required void Function(String) onPick,
}) async {
  final picked = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(tr('language')),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          RadioListTile<String>(
            value: 'ur',
            groupValue: current,
            title: const Text(kLangNameUr),
            onChanged: (v) => Navigator.of(ctx).pop(v),
          ),
          RadioListTile<String>(
            value: 'en',
            groupValue: current,
            title: const Text(kLangNameEn),
            onChanged: (v) => Navigator.of(ctx).pop(v),
          ),
        ],
      ),
    ),
  );
  if (picked != null && picked != current) onPick(picked);
}
