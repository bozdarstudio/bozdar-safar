package com.bozdar.safar

import android.content.Intent
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

// AGENT DEEP LINK (v1.4.7, spec §6): bozdarsafar://register?agent=CODE
// — koi nayi Flutter dependency NAHI; sirf ye MethodChannel hai.
// Cold start ka link stash ho jata hai (Dart getInitialLink se le
// leta hai); garam app par naya intent foran 'onLink' se Dart ko
// jata hai (channel abhi ready na ho to stash hi kaam ata hai —
// Dart agle getInitialLink par utha leta hai).
class MainActivity : FlutterActivity() {

    private var channel: MethodChannel? = null
    private var pendingLink: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingLink = intent?.dataString ?: pendingLink
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val link = intent.dataString ?: return
        pendingLink = link
        channel?.invokeMethod("onLink", link)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        channel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            "bozdar_safar/deeplink"
        )
        channel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "getInitialLink" -> {
                    result.success(pendingLink)
                    pendingLink = null
                }
                else -> result.notImplemented()
            }
        }
    }
}
