import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'route_service.dart';

/// =====================================================================
/// AWAAZ WALI REHNUMAI (VOICE NAVIGATION) — v1.4.70 (malik ka hukm
/// 2026-11-22): map driver ko BOL kar batata rahe — kahan murna hai,
/// sawari kahan khari hai, pickup par pohanchna, manzil tak ka safar,
/// aur aakhir mein ride complete karke kiraya lene aur doosri ride ke
/// intezaar ka elan.
///
/// Zariya: OSRM route ke ASAL maneuver steps (route_service.dart —
/// RouteStep.instruction pehle se Roman Urdu hai, masalan "Daayein
/// murein — M.A. Jinnah Road par") + device ka apna TTS
/// (voice.dart ka Voice.speak — MainActivity wala native channel,
/// ur-PK pehle, warna default awaaz; naya package NAHI joda gaya
/// taake proven rasta hi chale)।
///
/// Route steps na hon (offline seedhi line) to bearing + doori wali
/// rehnumai: hadaf ki simt (seedha/daayein/baayein) aur 500/200/100 m
/// par doori ke elan.
///
/// Usool:
///  - Rehnumai sirf IZAFA hai — ride flow, kiraya, gates sab pehle
///    jaisay; TTS fail ho to khamoshi, app kabhi NAHI rukti
///    (Voice.speak khud kabhi throw nahi karta)।
///  - Throttle: do elano ke darmiyan kam az kam 6 second; har mor
///    ka elan ~200 m pehle EK dafa aur mor par (~45 m) EK dafa;
///    doori ke elan sirf hadd (threshold) paar hone par ya safar
///    ke doran har ~55 second mein ek taaza hisaab।
///  - Toggle: [VoiceNavPrefs] — default ON, SharedPreferences mein
///    mehfooz; DriverNavView ke map par speaker wala pill.
/// =====================================================================

/// Awaaz wali rehnumai ki pasand (ON/OFF) — default ON।
class VoiceNavPrefs {
  static const String _key = 'voice_nav_enabled_v1';
  static final ValueNotifier<bool> notifier = ValueNotifier<bool>(true);
  static bool _loaded = false;

  static bool get enabled => notifier.value;

  /// Mehfooz pasand parhna — idempotent, kabhi throw nahi karta।
  static Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      notifier.value = prefs.getBool(_key) ?? true;
    } catch (_) {
      // Na parha jaye to default ON hi sahi।
    }
  }

  static Future<void> setEnabled(bool v) async {
    notifier.value = v;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_key, v);
    } catch (_) {
      // Save na bhi ho to is session mein pasand chalti rahegi।
    }
  }
}

/// Doori ko BOLNE wali shakal: "200 meter", "1.2 kilometer" —
/// fmtDist wali "200 m"/"1.2 km" TTS parhi to jaati hai, lekin ye
/// shakal zyada saaf bolti hai।
String voiceNavSpokenDist(double m) {
  if (m < 20) return 'chand qadam';
  if (m < 1000) return '${(m / 10).round() * 10} meter';
  final km = m / 1000;
  if (km >= 10) return '${km.round()} kilometer';
  final s = km.toStringAsFixed(1);
  return '${s.endsWith('.0') ? s.substring(0, s.length - 2) : s} kilometer';
}

/// Hadaf ki nisbat simt ka lafz — heading aur hadaf-bearing ke
/// farq se: seedha / daayein taraf / baayein taraf / peeche।
String voiceNavDirectionWord(double headingDeg, double targetBearingDeg) {
  var d = (targetBearingDeg - headingDeg) % 360;
  if (d > 180) d -= 360;
  if (d < -180) d += 360;
  if (d.abs() <= 35) return 'Seedha';
  if (d > 35 && d <= 150) return 'Daayein taraf';
  if (d < -35 && d >= -150) return 'Baayein taraf';
  return 'Peeche ki taraf';
}

/// Rehnumai ka dimagh (saf hisaab + haalat) — DriverNavView har
/// GPS fix par [update] bulata hai; jo jumla bolna bane woh wapas
/// milta hai, warna null। Widget/TTS se koi ta'alluq nahi — test
/// isi par hote hain।
class VoiceNavGuide {
  /// Do aam elano ke darmiyan kam az kam faasla।
  static const Duration minGap = Duration(seconds: 6);

  /// Safar ke doran taaza doori-elan ka waqfa।
  static const Duration refreshEvery = Duration(seconds: 55);

  /// Pohanchne ki pehchan (meter) — task ki hadd ~40 m।
  static const double arriveM = 40;

  String _phase = ''; // '' | 'pickup' | 'atPickup' | 'drop'
  int _routeId = 0;
  final Map<int, Set<String>> _stepStages = {};
  final Set<int> _remainingCalled = {};
  final Set<int> _fallbackCalled = {};
  bool _arrivalPickupSpoken = false;
  bool _arrivalDropSpoken = false;
  DateTime? _lastSpeakAt;
  String _lastLine = '';

  /// Naya hadaf (pickup → drop waghera) — saari haalat saaf।
  void reset() {
    _phase = '';
    _routeId = 0;
    _stepStages.clear();
    _remainingCalled.clear();
    _fallbackCalled.clear();
    _arrivalPickupSpoken = false;
    _arrivalDropSpoken = false;
    _lastSpeakAt = null;
    _lastLine = '';
  }

  String? _say(String line, DateTime now, {bool urgent = false}) {
    if (line == _lastLine) return null;
    final last = _lastSpeakAt;
    if (!urgent && last != null && now.difference(last) < minGap) {
      return null;
    }
    _lastSpeakAt = now;
    _lastLine = line;
    return line;
  }

  /// Ek GPS update par rehnumai ka faisla।
  ///
  /// [status]/[rideStarted] booking ki asal haalat hai:
  /// 'accepted' = sawari ki taraf; 'arrived' + !rideStarted =
  /// pickup par khada; 'arrived' + rideStarted = manzil ki taraf।
  /// [distToTargetM] driver se maujooda hadaf tak ki seedhi doori;
  /// [route]/[alongM] hon to route wali baqi doori aur maneuvers
  /// chalte hain, warna bearing+doori wali rehnumai।
  String? update({
    required String status,
    required bool rideStarted,
    required double distToTargetM,
    required RouteResult? route,
    required double? alongM,
    required double? headingDeg,
    required double? targetBearingDeg,
    required DateTime now,
  }) {
    final phase = status == 'accepted'
        ? 'pickup'
        : status == 'arrived'
            ? (rideStarted ? 'drop' : 'atPickup')
            : '';
    if (phase.isEmpty) return null;

    // Route badle to mor wale elan dobara tayyar (naye steps)।
    final rid = route == null ? 0 : identityHashCode(route);
    if (rid != _routeId) {
      _routeId = rid;
      _stepStages.clear();
      _remainingCalled.clear();
      _fallbackCalled.clear();
    }

    final noun = phase == 'drop' ? 'Manzil' : 'Sawari';

    // --- Marhala badla: pehla elan ------------------------------
    if (phase != _phase) {
      _phase = phase;
      _stepStages.clear();
      _remainingCalled.clear();
      _fallbackCalled.clear();
      if (phase == 'pickup') {
        return _say(
          'Sawari ki taraf chalein — sawari '
          '${voiceNavSpokenDist(distToTargetM)} par khari hai',
          now,
          urgent: true,
        );
      }
      if (phase == 'atPickup') {
        if (_arrivalPickupSpoken) return null;
        _arrivalPickupSpoken = true;
        return _say(
          'Aap manzil par pahunch gaye — sawari yahan khari hai',
          now,
          urgent: true,
        );
      }
      // phase == 'drop'
      return _say(
        'Ride shuru ho gayi hai — manzil ki taraf chalein',
        now,
        urgent: true,
      );
    }

    // --- Pohanchna (doori se pehchan) ---------------------------
    double effective = distToTargetM;
    if (route != null && alongM != null) {
      final remaining = math.max(0.0, route.track.totalM - alongM);
      if (remaining < effective) effective = remaining;
    }
    if (phase == 'pickup' &&
        effective <= arriveM &&
        !_arrivalPickupSpoken) {
      _arrivalPickupSpoken = true;
      return _say(
        'Aap manzil par pahunch gaye — sawari yahan khari hai',
        now,
        urgent: true,
      );
    }
    if (phase == 'drop' && effective <= arriveM && !_arrivalDropSpoken) {
      _arrivalDropSpoken = true;
      return _say(
        'Aap manzil par pahunch gaye. Ride complete karein, '
        'musafir se kiraya lein, aur doosri ride ka intezaar karein',
        now,
        urgent: true,
      );
    }
    if (phase == 'atPickup') return null; // khada hai — khamoshi

    // --- Maneuvers (asal OSRM steps) ----------------------------
    if (route != null && route.hasSteps && alongM != null) {
      var nextIdx = -1;
      for (var i = 0; i < route.steps.length; i++) {
        final s = route.steps[i];
        if (!s.isArrive && s.alongM > alongM + 10) {
          nextIdx = i;
          break;
        }
      }
      if (nextIdx >= 0) {
        final step = route.steps[nextIdx];
        final d = step.alongM - alongM;
        final stages = _stepStages.putIfAbsent(nextIdx, () => <String>{});
        if (d <= 230 && !stages.contains('early')) {
          final line = _say(
            '${voiceNavSpokenDist(d)} par ${step.instruction}',
            now,
          );
          if (line != null) stages.add('early');
          return line;
        }
        if (d <= 45 && !stages.contains('now')) {
          final head = step.instruction.split(' — ').first.trim();
          final line = _say(
            head.isEmpty
                ? 'Ab murein'
                : 'Ab ${head[0].toLowerCase()}${head.substring(1)}',
            now,
          );
          if (line != null) stages.add('now');
          return line;
        }
        // Taaza hisaab: 55 second khamoshi ho to agle mor ki
        // taaza doori ek dafa (1.2 km ke andar ho tab)।
        final last = _lastSpeakAt;
        if (d <= 1200 &&
            last != null &&
            now.difference(last) >= refreshEvery) {
          return _say(
            '${voiceNavSpokenDist(d)} par ${step.instruction}',
            now,
          );
        }
        return null;
      }
      // Sirf arrive step baqi — baqi doori ki haddein।
      final remaining = math.max(0.0, route.track.totalM - alongM);
      for (final t in const [1000, 500]) {
        if (remaining <= t && !_remainingCalled.contains(t)) {
          final line = _say(
            '$noun ${voiceNavSpokenDist(remaining)} door hai',
            now,
          );
          if (line != null) _remainingCalled.add(t);
          return line;
        }
      }
      return null;
    }

    // --- Fallback: bearing + doori (steps na hon) ---------------
    for (final t in const [500, 200, 100]) {
      if (distToTargetM <= t && !_fallbackCalled.contains(t)) {
        final dir = (headingDeg != null && targetBearingDeg != null)
            ? '${voiceNavDirectionWord(headingDeg, targetBearingDeg)} chalein — '
            : '';
        final line = _say(
          '$dir$noun ${voiceNavSpokenDist(distToTargetM)} door hai',
          now,
        );
        if (line != null) _fallbackCalled.add(t);
        return line;
      }
    }
    final last = _lastSpeakAt;
    if (last != null && now.difference(last) >= refreshEvery) {
      final dir = (headingDeg != null && targetBearingDeg != null)
          ? '${voiceNavDirectionWord(headingDeg, targetBearingDeg)} chalein — '
          : '';
      return _say(
        '$dir$noun ${voiceNavSpokenDist(distToTargetM)} door hai',
        now,
      );
    }
    return null;
  }
}
