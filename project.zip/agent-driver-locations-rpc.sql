-- =====================================================================
-- Boz Safar — v1.4.55 · AGENT DRIVER LOCATIONS RPC
--   (agent_driver_locations)
--
-- Agent apni app mein SIRF APNE drivers ki live haalat dekhta
-- hai: kaun online hai aur us ki aakhri GPS jagah (drivers
-- table ke online / lat / lng / updated_at — driver ki app
-- duty par yahi columns taaza karti hai, Master ka map bhi
-- inhi se chalta hai)।
--
-- Ye RPC is liye hai ke drivers table ki seedhi parhai Phase-4
-- ke baad har Auth user ke liye khuli NAHI rehti — agent ko
-- doosre drivers (ya doosre agents ke drivers) ka data KABHI
-- nahi milna chahiye। SECURITY DEFINER function andar hi
-- sakht taala lagata hai:
--   * Sirf AUTHENTICATED session।
--   * Caller ki pehchan p_code wale agent se bandhi honi
--     chahiye — agent_heartbeat wala hi DO-saboot usool:
--       (1) JWT email == agents.email, YA
--       (2) identity_links mein kind='agent' row is Auth user
--           ki, subject_id = is agent ki id (link_agent ka
--           record)।
--     Guard fail ho to KHAALI set — koi error, koi data nahi।
--   * Jawab mein SIRF: driver id, naam, gaari, plate, ID
--     active hai ya nahi, online hai ya nahi, lat/lng aur
--     updated_at। Paisay ka koi column (fare/fee/wallet)
--     is function mein HAI HI NAHI — agent ko paisay ka
--     data kabhi nahi dikhta (owner ka lock)।
--   * Archived agent ke liye bhi khaali set।
--
-- ADDITIVE ONLY: sirf naya function — koi table/policy/data
-- change NAHI। Idempotent (CREATE OR REPLACE)।
--
-- Rollback: drop function public.agent_driver_locations(text);
-- =====================================================================

create or replace function public.agent_driver_locations(p_code text)
returns table (
  driver_id  text,
  name       text,
  vehicle    text,
  plate      text,
  active     boolean,
  online     boolean,
  lat        double precision,
  lng        double precision,
  updated_at timestamptz
)
language plpgsql security definer set search_path = public as $$
declare
  v_uid   uuid := auth.uid();
  v_email text := lower(coalesce(auth.jwt() ->> 'email', ''));
  v_agent public.agents%rowtype;
begin
  -- Tasdeeq ki shartein — fail ho to khaali set (return)।
  if auth.role() <> 'authenticated' or v_uid is null then
    return;
  end if;

  select * into v_agent
    from public.agents
   where code = upper(btrim(coalesce(p_code, '')))
   limit 1;
  if not found then
    return;
  end if;
  if coalesce(v_agent.archived, false) then
    return;
  end if;

  if not (
    (v_email <> '' and lower(coalesce(v_agent.email, '')) = v_email)
    or exists (
      select 1 from public.identity_links il
       where il.kind = 'agent'
         and il.auth_user_id = v_uid
         and il.subject_id = v_agent.id
    )
  ) then
    return;
  end if;

  -- Sirf IS agent ke drivers (drivers.agent_code = us ka code)।
  return query
    select d.id::text,
           coalesce(d.name, '')::text,
           concat_ws(' · ',
             nullif(btrim(coalesce(d.vehicle, '')), ''),
             nullif(btrim(coalesce(d.vehicle_brand, '')), ''),
             nullif(btrim(coalesce(d.vehicle_model, '')), ''))::text,
           coalesce(d.plate, '')::text,
           coalesce(d.active, false),
           coalesce(d.online, false),
           d.lat,
           d.lng,
           d.updated_at
      from public.drivers d
     where d.agent_code = v_agent.code
     order by d.name asc;
end $$;

revoke execute on function public.agent_driver_locations(text)
  from public;
grant execute on function public.agent_driver_locations(text)
  to authenticated;
