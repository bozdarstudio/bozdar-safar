import 'dart:async';
import 'package:flutter/material.dart';
import 'backend.dart';
import 'guide_audio.dart';
import 'theme.dart';

/// EMAIL + OTP (v1.4.7, spec §1) — teenon jagah mushtarka UI:
/// driver registration (Zaati Maloomat wala qadam), sawari ki
/// profile, aur logout ke baad dobara login wala darwaza
/// (OtpGatePage)।
///
/// Usool: Gmail LAZMI hai; 6-digit code usi email par jata hai
/// (Supabase Auth email OTP — sirf email-proof; app ka asal
/// account system nahi badalta)। Code verify hue baghair ID aage
/// NAHI badhti। Email galat ho to rasta Master se hai (pehchan
/// tasdeeq ke baad sudhar) — yahan sirf woh note dikhta hai।
class EmailOtpSection extends StatefulWidget {
  /// Email wala text field BAHAR se control hota hai taaki form
  /// (wizard/profile) apni value khud rakhe।
  final TextEditingController emailCtrl;

  /// Is email ki OTP tasdeeq pehle se ho chuki ho (profile mein
  /// verified email) to woh email — section "verify shuda" haalat
  /// se shuru hoti hai; email badalte hi tasdeeq khatam, naya
  /// code lazmi।
  final String alreadyVerifiedEmail;

  /// Verify kamyab hone par — verified email ke saath।
  final void Function(String email) onVerified;

  /// Wizard ke Zaati Maloomat qadam par email wali awaaz ki
  /// hidayat (guidance_email.mp3) khud chalti hai।
  final bool playGuideOnInit;

  const EmailOtpSection({
    super.key,
    required this.emailCtrl,
    required this.onVerified,
    this.alreadyVerifiedEmail = '',
    this.playGuideOnInit = false,
  });

  @override
  State<EmailOtpSection> createState() => _EmailOtpSectionState();
}

class _EmailOtpSectionState extends State<EmailOtpSection> {
  final _codeCtrl = TextEditingController();
  bool _sent = false;
  bool _busy = false;
  String? _error;
  String _verifiedEmail = '';

  // OTP SAKHTI (v1.4.13): ek code par zyada se zyada 5 ghalat
  // koshishen — us ke baad woh code band, naya code lazmi.
  // Code dobara bhejne par 60 second ka cooldown — button tab
  // tak band rehta hai aur label mein baqi second dikhte hain.
  static const int _maxAttempts = 5;
  static const int _resendCooldownSeconds = 60;
  int _failedAttempts = 0;
  bool _codeBlocked = false;
  int _cooldownLeft = 0;
  Timer? _cooldownTimer;

  String get _email => widget.emailCtrl.text.trim().toLowerCase();

  bool get _isVerified =>
      _verifiedEmail.isNotEmpty && _verifiedEmail == _email;

  @override
  void initState() {
    super.initState();
    _verifiedEmail = widget.alreadyVerifiedEmail.trim().toLowerCase();
    widget.emailCtrl.addListener(_onEmailChanged);
    if (widget.playGuideOnInit) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        unawaited(GuideAudio.play('guidance/guidance_email.mp3'));
      });
    }
  }

  @override
  void dispose() {
    widget.emailCtrl.removeListener(_onEmailChanged);
    _cooldownTimer?.cancel();
    _codeCtrl.dispose();
    super.dispose();
  }

  /// Dobara-bhejne ka 60-second cooldown shuru karna — button
  /// is doran band rehta hai, label mein baqi second ginte hain.
  void _startCooldown() {
    _cooldownTimer?.cancel();
    setState(() => _cooldownLeft = _resendCooldownSeconds);
    _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() {
        if (_cooldownLeft > 0) _cooldownLeft -= 1;
        if (_cooldownLeft <= 0) {
          _cooldownLeft = 0;
          t.cancel();
        }
      });
    });
  }

  void _onEmailChanged() {
    // Email badla to purani tasdeeq is email par nahi rehti —
    // naya code lazmi (setState sirf UI ke liye)।
    if (_verifiedEmail.isNotEmpty && _verifiedEmail != _email) {
      setState(() {
        _sent = false;
        _codeCtrl.clear();
      });
    }
  }

  bool _validEmail(String e) {
    return e.length >= 5 &&
        e.contains('@') &&
        e.split('@').last.contains('.');
  }

  Future<void> _sendCode() async {
    if (_cooldownLeft > 0) return;
    if (!_validEmail(_email)) {
      setState(() => _error = 'Durust Gmail likhein — masalan naam@gmail.com');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final ok = await Backend.sendEmailOtp(_email);
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (ok) {
        _sent = true;
        _error = null;
        // Naya code aya — purani ghalat-koshishon ki ginti aur
        // bandish khatam, ginti naye code ke liye zero se.
        _failedAttempts = 0;
        _codeBlocked = false;
      } else {
        _error =
            'Code nahi bheja ja saka — internet check karke dobara koshish karein.';
      }
    });
    if (ok) _startCooldown();
  }

  Future<void> _verify() async {
    if (_codeBlocked) {
      setState(() => _error =
          'Is code par 5 ghalat koshishen ho chuki hain — naya code mangwa kar phir koshish karein.');
      return;
    }
    final code = _codeCtrl.text.trim();
    if (code.length != 6) {
      setState(() => _error = 'Email par aya hua 6-digit code pura likhein.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final ok = await Backend.verifyEmailOtp(_email, code);
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (ok) {
        _verifiedEmail = _email;
        _error = null;
        _failedAttempts = 0;
        _codeBlocked = false;
      } else {
        _failedAttempts += 1;
        if (_failedAttempts >= _maxAttempts) {
          _codeBlocked = true;
          _error =
              '5 ghalat koshishen ho gayi hain — ye code ab nahi chalega. Naya code mangwa kar dobara koshish karein.';
        } else {
          _error =
              'Ye code durust nahi hai ya purana ho gaya hai — naya code mangwa kar dobara likhein.';
        }
      }
    });
    if (ok) widget.onVerified(_email);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: widget.emailCtrl,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(
            labelText: 'Gmail (lazmi) — OTP code isi par jayega',
            hintText: 'masalan: naam@gmail.com',
            prefixIcon: Icon(Icons.email),
          ),
        ),
        const SizedBox(height: 8),
        if (_isVerified)
          const Row(
            children: [
              Icon(Icons.verified, color: Brand.green, size: 18),
              SizedBox(width: 6),
              Expanded(
                child: Text('Email verify ho gaya hai — ID aage badh sakti hai.',
                    style: TextStyle(
                        color: Brand.green, fontWeight: FontWeight.w700)),
              ),
            ],
          )
        else ...[
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _codeCtrl,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  decoration: const InputDecoration(
                    labelText: 'Email par aya code',
                    counterText: '',
                    prefixIcon: Icon(Icons.pin),
                    isDense: true,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              OutlinedButton(
                onPressed: (_busy || _cooldownLeft > 0) ? null : _sendCode,
                child: Text(_cooldownLeft > 0
                    ? 'Dobara $_cooldownLeft second baad'
                    : (_sent ? 'Code dobara bhejein' : 'Code bhejein')),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _busy ? null : _verify,
              icon: _busy
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.verified),
              label: const Text('Code Verify Karein'),
            ),
          ),
          const Text(
            'Code aap ki Gmail par jata hai — Spam/Promotions folder bhi check kar lein. Email hi galat ho jaye to Master pehchan ki tasdeeq ke baad use theek kar dega (Madad se message kar dein).',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
        if (_error != null) ...[
          const SizedBox(height: 6),
          Text(_error!,
              style: const TextStyle(
                  color: Brand.ajrakRed, fontWeight: FontWeight.w700)),
        ],
      ],
    );
  }
}

/// LOGIN OTP DARWAZA (v1.4.7, spec §1): logout ke baad dobara
/// login par — ya nayi device par — password ke baad ye screen
/// ati hai; jab tak usi Gmail par aya code verify na ho, ID aage
/// NAHI badhti। Kamyabi par true, band karne par false।
class OtpGatePage extends StatefulWidget {
  final String email;
  final String title;

  const OtpGatePage({super.key, required this.email, required this.title});

  @override
  State<OtpGatePage> createState() => _OtpGatePageState();
}

class _OtpGatePageState extends State<OtpGatePage> {
  late final _emailCtrl = TextEditingController(text: widget.email);

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.mark_email_read, size: 64, color: Brand.green),
          const SizedBox(height: 12),
          const Text(
            'Ek aur tasdeeq — aap ki Gmail par code jayega',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          const Text(
            'Aap logout karke dobara aa rahe hain, is liye pehchan ki tasdeeq ke liye aap ki apni Gmail par code bhejna lazmi hai. Apne band phone par roz ke istemal mein (bina logout) code NAHI manga jata.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13.5, color: Colors.black87),
          ),
          const SizedBox(height: 18),
          EmailOtpSection(
            emailCtrl: _emailCtrl,
            onVerified: (_) => Navigator.of(context).pop(true),
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Abhi nahi — wapas jayein'),
          ),
        ],
      ),
    );
  }
}
