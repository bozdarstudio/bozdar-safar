// v1.4.28 — BOOKING FIX + YANGO-STYLE FLOW ke tests:
// progressive disclosure ka usool (pin + asal route se pehle
// tafseel NAHI), pin par label ka usool, pichhli jagahon ki
// tartib, aur source-level pakki jaanch (banner tasveer
// booking screen se gayab, home bar maujood, OSM attribution
// har map par)।
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:safar/booking_flow.dart';
import 'package:safar/store.dart';

Booking _booking({
  required String id,
  required String dropLabel,
  bool hasDropPin = true,
}) =>
    Booking(
      id: id,
      passengerName: 'Sawari',
      passengerPhone: '03000000000',
      pickupLabel: 'Pickup',
      dropLabel: dropLabel,
      pickupLat: 24.87,
      pickupLng: 67.01,
      dropLat: 24.90,
      dropLng: 67.05,
      hasDropPin: hasDropPin,
      vehicle: 'Rickshaw',
      distanceKm: 3,
      fare: 150,
      note: '',
      status: 'completed',
      createdAt: DateTime(2026, 11, 11),
    );

void main() {
  group('bookingDetailsReady — progressive disclosure ka gate', () {
    test('(a) drop pin se pehle tafseel NAHI khulti', () {
      expect(
        bookingDetailsReady(
            hasDropPin: false, routeKm: 3.2, routeSigMatches: true),
        isFalse,
      );
      expect(
        bookingDetailsReady(
            hasDropPin: false, routeKm: null, routeSigMatches: false),
        isFalse,
      );
    });

    test('pin lag jaye lekin asal route na aye to bhi NAHI', () {
      expect(
        bookingDetailsReady(
            hasDropPin: true, routeKm: null, routeSigMatches: false),
        isFalse,
      );
    });

    test('purani jori ka route (sig mismatch) tafseel NAHI kholta', () {
      expect(
        bookingDetailsReady(
            hasDropPin: true, routeKm: 3.2, routeSigMatches: false),
        isFalse,
      );
    });

    test('(b) drop pin + asal route + sig match = tafseel khulti hai', () {
      expect(
        bookingDetailsReady(
            hasDropPin: true, routeKm: 3.2, routeSigMatches: true),
        isTrue,
      );
    });
  });

  group('pinLabelIfEmpty — pin par label ka usool', () {
    test('khaali field ko saaf pin label milta hai', () {
      expect(pinLabelIfEmpty(''), kPinPlaceLabel);
      expect(pinLabelIfEmpty('   '), kPinPlaceLabel);
      expect(kPinPlaceLabel, 'Map Pin Wali Jagah');
    });

    test('user ka likha hua naam kabhi NAHI badalta', () {
      expect(pinLabelIfEmpty('Saddar'), 'Saddar');
      expect(pinLabelIfEmpty('  Clifton  '), '  Clifton  ');
    });
  });

  group('recentDropPlaces — pichhli jagahon ki list', () {
    test('newest-first tartib barkarar, dohrao (case farq) hatta hai', () {
      final list = recentDropPlaces([
        _booking(id: '1', dropLabel: 'Saddar'),
        _booking(id: '2', dropLabel: 'Clifton'),
        _booking(id: '3', dropLabel: 'saddar'),
      ]);
      expect(list.map((b) => b.id).toList(), ['1', '2']);
    });

    test('pin ke baghair wali purani booking list mein NAHI ati', () {
      final list = recentDropPlaces([
        _booking(id: '1', dropLabel: 'Saddar', hasDropPin: false),
        _booking(id: '2', dropLabel: 'Clifton'),
      ]);
      expect(list.map((b) => b.id).toList(), ['2']);
    });

    test('khaali label wali booking NAHI ati; hadd (limit) lagti hai', () {
      final list = recentDropPlaces([
        _booking(id: '0', dropLabel: '  '),
        _booking(id: '1', dropLabel: 'A'),
        _booking(id: '2', dropLabel: 'B'),
        _booking(id: '3', dropLabel: 'C'),
        _booking(id: '4', dropLabel: 'D'),
        _booking(id: '5', dropLabel: 'E'),
      ]);
      expect(list.map((b) => b.id).toList(), ['1', '2', '3', '4']);
    });
  });

  group('Flow ke asal jumle — lafz pakke', () {
    test('pin-mode patti aur button ke label', () {
      expect(kPinModeHint, 'Apni manzil ki jagah map par tap karein');
      expect(kPinModeButtonLabel, 'Map Se Pin Lagayein');
    });

    test('OSM attribution ka asal jumla', () {
      expect(kOsmAttribution, '© OpenStreetMap contributors © CARTO');
    });
  });

  group('Source jaanch — screen ki asal haalat', () {
    final passenger = File('lib/passenger.dart').readAsStringSync();
    final safarMap = File('lib/safar_map.dart').readAsStringSync();

    test('(c) ladki + rickshaw wali banner booking screen par NAHI hai',
        () {
      expect(
        passenger.contains(
            "ModeBanner(asset: 'assets/mode-passenger.png')"),
        isFalse,
      );
    });

    test('Home bar: "Kahan Jana Hai?" + gaari tiles maujood hain', () {
      // v1.4.29: home bar ki string ab lang.dart ke map mein
      // hai (do zubaanein) — passenger tr('where_to') istemal
      // karta hai aur asal jumla lang.dart mein maujood hai।
      final lang = File('lib/lang.dart').readAsStringSync();
      expect(passenger.contains("tr('where_to')"), isTrue);
      expect(lang.contains('Kahan Jana Hai?'), isTrue);
      expect(passenger.contains('_vehicleTile'), isTrue);
      expect(passenger.contains('_openFlow'), isTrue);
    });

    test('pin-mode ki patti + Wapas passenger screen mein hai', () {
      expect(passenger.contains('kPinModeHint'), isTrue);
      expect(passenger.contains('_enterPinMode'), isTrue);
      expect(passenger.contains('_exitPinMode'), isTrue);
    });

    test('OSM attribution map widget mein maujood hai (har map)', () {
      expect(safarMap.contains('kOsmAttribution'), isTrue);
      expect(
          safarMap
              .contains("import 'booking_flow.dart' show kOsmAttribution;"),
          isTrue);
    });

    test('passenger screens par attribution footer bhi hai '
        '(sheet map ko dhakti hai)', () {
      // Home bar + booking form + tracking sheet — teen jagah।
      expect('kOsmAttribution'.allMatches(passenger).length,
          greaterThanOrEqualTo(3));
    });
  });

  group('Passenger MENU — mukammal tartib maujood hai', () {
    final passenger = File('lib/passenger.dart').readAsStringSync();

    test('menu Profile tab mein hai aur purana Profile body '
        'Settings screen mein barkarar hai', () {
      expect(passenger.contains('_menuView()'), isTrue);
      expect(passenger.contains('PassengerProfileScreen'), isTrue);
    });

    test('lazmi rows sab maujood hain', () {
      // v1.4.29: kuch labels ab lang.dart ke map mein hain
      // (do zubaanein) — label passenger.dart YA lang.dart
      // mein maujood hona lazmi hai।
      final lang = File('lib/lang.dart').readAsStringSync();
      for (final label in [
        'Meri Rides',
        'Madad / Support',
        'Saved Places',
        'Payment',
        'Driver Mode',
        'Safety',
        'Kiraye Ki List',
        'App Ki Haalat',
        'Meri Profile aur Settings',
        'Maloomat / About',
      ]) {
        expect(passenger.contains(label) || lang.contains(label), isTrue,
            reason: 'row gayab: $label');
      }
    });

    test('shortcut gol buttons chaar hain (Rides/Madad/Pate/Settings)',
        () {
      // v1.4.29: shortcut labels bhi ab tr() se ate hain
      // (do zubaanein) — keys maujood hona lazmi hai।
      expect(passenger.contains("label: tr('my_rides')"), isTrue);
      expect(passenger.contains("label: tr('help')"), isTrue);
      expect(passenger.contains("label: 'Mere Pate'"), isTrue);
      expect(passenger.contains("label: 'Settings'"), isTrue);
    });

    test('Payment sirf Cash hai — card ka jhoota option NAHI', () {
      expect(passenger.contains('sirf CASH chalta hai'), isTrue);
      expect(passenger.contains('Card se pay'), isFalse);
    });

    test('Kiraye ki list asal Fares.perKm se ati hai (computed '
        'fare NAHI)', () {
      expect(passenger.contains('Fares.perKm'), isTrue);
    });
  });
}
