import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'store.dart';
import 'theme.dart';
import 'legal.dart';
import 'backend.dart';

/// Driver REGISTRATION WIZARD (v1.2.6 — malik ka hukm: "Register form
/// waise hi banao jaise Yango ka hai").
///
/// Yango Pro ke driver registration jaisi qadam-ba-qadam (step-by-step)
/// full-screen form: mobile → zaati maloomat/CNIC → password → gaari →
/// licence (ikhtiyari) → live selfie → ilaqa + jaiza → Register.
/// Driver Mode mein jab tak registration mukammal nahi, ye form khud
/// bhi khulta hai aur Profile se bhi dobara khul sakta hai (tafseel
/// mukammal/badlein). Purani Profile-wali save is ki jagah NAHI leti —
/// pehli registration yahin se hoti hai; Profile sirf editing ke liye.
///
/// Usool jo nahi badle:
/// - Password: v1.2.5 ke wohi usool (kam az kam 6 haroof, sirf
///   fingerprint, ek password sirf ek driver — backend uniqueness
///   check, internet ke baghair check skip NAHI hota).
/// - Licence OPTIONAL hai: "Licence nahi hai — skip karein" se aage
///   barh sakte hain; CNIC lazmi hai.
/// - Tasaveer sirf phone par rehti hain; backend par numbers/tafseel
///   aur documents ki STATUS jati hai (mojooda pattern).
/// - Register hone par darkhwast Master ke paas jati hai — duty ki
///   asal tasdeeq masterActive (Master app) se hi ati hai.
class RegistrationWizard extends StatefulWidget {
  final AppStore store;
  const RegistrationWizard({super.key, required this.store});

  @override
  State<RegistrationWizard> createState() => _RegistrationWizardState();
}

class _RegistrationWizardState extends State<RegistrationWizard> {
  static const _titles = [
    'Mobile Number',
    'Zaati Maloomat',
    'Password',
    'Gaari ki Maloomat',
    'Driving Licence',
    'Live Selfie',
    'Ilaqa aur Jaiza',
  ];

  static const _brandSuggestions = <String, List<String>>{
    'Rickshaw': ['Sazgar', 'New Asia', 'Vespa', 'Super Power', 'Tez Raftaar'],
    'Bike': ['Honda', 'Yamaha', 'Suzuki', 'United', 'Super Star'],
    'Car': ['Suzuki', 'Toyota', 'Honda', 'Kia', 'Hyundai'],
    'Taxi': ['Suzuki', 'Toyota', 'Honda', 'Hyundai'],
    'Van': ['Suzuki Bolan', 'Toyota HiAce', 'Suzuki APV', 'Suzuki Every', 'Changan Karvaan'],
  };

  final ImagePicker _picker = ImagePicker();
  int _step = 0;
  bool _busy = false;
  bool _done = false;
  String? _error;

  AppStore get store => widget.store;
  DriverProfile get p => store.profile;

  // --- Form state (profile se shuru — edit par purani values dikhti hain)
  late final _mobileCtrl = TextEditingController(text: p.phone);
  late final _nameCtrl = TextEditingController(text: p.name);
  late final _cnicCtrl = TextEditingController(text: p.cnicNumber);
  late final _pwdCtrl = TextEditingController();
  late final _pwd2Ctrl = TextEditingController();
  late final _brandCtrl = TextEditingController(text: p.vehicleBrand);
  late final _modelCtrl = TextEditingController(text: p.vehicleModel);
  late final _colorCtrl = TextEditingController(text: p.vehicleColor);
  late final _plateCtrl = TextEditingController(text: p.plate);
  late final _licenceCtrl = TextEditingController(text: p.licenceNumber);

  late String _vehicle = p.vehicle;
  late int? _year = p.vehicleYear > 0 ? p.vehicleYear : null;
  // FORM USOOL (owner, 2026-11-08): sheher pehle se set NAHI hota —
  // profile mein zone darj ho to wohi, warna khaali (null) aur
  // driver aakhri qadam mein apna sheher KHUD chunta hai. Pehle
  // yahan khamoshi se 'Karachi' lag jata tha — woh khatam.
  late String _zone = kZones.contains(p.zone) ? p.zone : '';
  late String _cnicFront = p.cnicFrontPath;
  late String _cnicBack = p.cnicBackPath;
  late String _vehiclePhoto = p.vehiclePhotoPath;
  late String _vehicleReg = p.vehicleRegPath;
  late final _imeiCtrl = TextEditingController(text: p.imei);
  late String _licencePhoto = p.licencePhotoPath;
  late String _selfie = p.profilePhotoPath;
  late bool _licenceSkip =
      !(p.licenceStatus == 'has' || p.licenceNumber.isNotEmpty);

  /// Sharait ki qubooliyat (v1.4.4 LEGAL): review wale aakhri
  /// qadam par driver "Mein ne parh liya, qabool hai" par nishan
  /// lagata hai — baghair is ke register NAHI hota. Nishan lagte
  /// hi waqt profile mein darj ho jata hai (aur save par backend
  /// drivers.terms_accepted_at mein Master ke saboot ke liye
  /// jata hai). Pehle se qabool shuda ho to nishan laga hua ata hai.
  late bool _termsChecked = p.termsAcceptedAtMs > 0;

  /// Password jo is wizard mein uniqueness check PASS kar chuka hai —
  /// us ka fingerprint. Register dabane par profile mein lagta hai.
  /// (Profile par pehle se password ho to ye null rehta hai aur
  /// password wala qadam sirf maloomat dikhata hai.)
  String? _stagedFp;

  /// Jo password text check pass kar chuka hai — wohi dobara likha
  /// jaye to backend check dobara nahi chalta.
  String _checkedPw = '';

  @override
  void dispose() {
    _mobileCtrl.dispose();
    _nameCtrl.dispose();
    _cnicCtrl.dispose();
    _imeiCtrl.dispose();
    _pwdCtrl.dispose();
    _pwd2Ctrl.dispose();
    _brandCtrl.dispose();
    _modelCtrl.dispose();
    _colorCtrl.dispose();
    _plateCtrl.dispose();
    _licenceCtrl.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  // --- Tasveer chunna --------------------------------------------------------

  /// Camera ya gallery se tasveer — selfie wale qadam ke ilawa har
  /// jagah dono option hain (mojooda app ka image picking pattern).
  Future<void> _pickPhoto(void Function(String path) apply,
      {bool cameraOnly = false}) async {
    ImageSource? src = cameraOnly ? ImageSource.camera : null;
    if (!cameraOnly) {
      src = await showModalBottomSheet<ImageSource>(
        context: context,
        builder: (ctx) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt, color: Brand.green),
                title: const Text('Camera se tasveer lein'),
                onTap: () => Navigator.pop(ctx, ImageSource.camera),
              ),
              ListTile(
                leading:
                    const Icon(Icons.photo_library, color: Brand.green),
                title: const Text('Gallery se chunein'),
                onTap: () => Navigator.pop(ctx, ImageSource.gallery),
              ),
            ],
          ),
        ),
      );
    }
    if (src == null || !mounted) return;
    try {
      final img = await _picker.pickImage(source: src, imageQuality: 85);
      if (img == null) {
        // HOTFIX v1.2.9 (RC3): camera/gallery band karne par
        // khamoshi se wapas NAHI — wajah batao (duty selfie wala
        // wohi jumla/andaaz).
        if (mounted) {
          _snack(
              'Selfie nahi li gayi — camera band ho gaya ya permission nahi mili. Dobara koshish karein.');
        }
        return;
      }
      if (mounted) setState(() => apply(img.path));
    } catch (_) {
      if (mounted) _snack('Tasveer nahi li ja saki.');
    }
  }

  // --- Validation -------------------------------------------------------------

  String _digits(String s) => s.replaceAll(RegExp(r'[^0-9]'), '');

  bool _fail(String msg) {
    setState(() => _error = msg);
    return false;
  }

  /// IMEI ki durusti: 15 digits + Luhn check digit (aakhri digit
  /// baqion se hisaab hota hai — ek digit ki typo bhi pakri jati
  /// hai). Ye sirf TYPO ki jaanch hai; PTA-approved hai ya nahi,
  /// ye faisla Master Tasdeeq mein 8484/DIRBS check se karta hai.
  bool _validImei(String d) {
    if (d.length != 15) return false;
    var sum = 0;
    for (var i = 0; i < 15; i++) {
      var n = int.tryParse(d[i]) ?? -1;
      if (n < 0) return false;
      if (i.isOdd) {
        n *= 2;
        if (n > 9) n -= 9;
      }
      sum += n;
    }
    return sum % 10 == 0;
  }

  Future<bool> _validateStep() async {
    setState(() => _error = null);
    switch (_step) {
      case 0:
        final d = _digits(_mobileCtrl.text);
        if (!(d.length == 11 && d.startsWith('03'))) {
          return _fail(
              'Durust mobile number likhein — 03 se shuru, kul 11 number (masalan 03123456789).');
        }
        return true;
      case 1:
        if (_nameCtrl.text.trim().length < 3) {
          return _fail('Apna pura naam likhein (CNIC wala naam).');
        }
        if (_digits(_cnicCtrl.text).length != 13) {
          return _fail(
              'CNIC number durust likhein — XXXXX-XXXXXXX-X (kul 13 number).');
        }
        // EK CNIC = EK ACCOUNT (malik ka hukm 2026-11-08):
        // account shakhs (CNIC) ka hota hai, number/SIM ka nahi.
        // Ye CNIC kisi aur driver account mein pehle se darj ho
        // to doosra/fake account yahin ruk jata hai. Password
        // wale qadam wala hi usool: internet na mile to check
        // pass NAHI mana jata.
        setState(() => _busy = true);
        final cnicTaken = await Backend.cnicTakenByOther(
            _digits(_cnicCtrl.text), store.driverId);
        if (!mounted) return false;
        setState(() => _busy = false);
        if (cnicTaken == null) {
          return _fail(
              'CNIC ki jaanch ke liye internet chahiye — net on karke dobara koshish karein.');
        }
        if (cnicTaken) {
          return _fail(
              'Ye CNIC pehle se ek driver account mein darj hai — ek CNIC par sirf EK hi driver account ban sakta hai. Account shakhs (CNIC) ka hota hai, number ya SIM ka nahi. Agar ye aap ka apna purana account hai to naya account nahi banega — Master se rabta karein.');
        }
        if (_cnicFront.isEmpty) {
          return _fail('CNIC ki SAMNE wali tasveer lazmi hai.');
        }
        if (_cnicBack.isEmpty) {
          return _fail('CNIC ki PEECHE wali tasveer lazmi hai.');
        }
        return true;
      case 2:
        return _validatePasswordStep();
      case 3:
        if (_brandCtrl.text.trim().isEmpty) {
          return _fail('Gaari ki company/brand likhein (masalan Sazgar).');
        }
        if (_modelCtrl.text.trim().isEmpty) {
          return _fail('Gaari ka model likhein.');
        }
        if (_year == null) return _fail('Gaari ka saal (year) chunein.');
        if (_colorCtrl.text.trim().isEmpty) {
          return _fail('Gaari ka rang likhein.');
        }
        if (_plateCtrl.text.trim().isEmpty) {
          return _fail('Gaari ka number plate likhein.');
        }
        if (_vehiclePhoto.isEmpty) {
          return _fail('Gaari ki tasveer lazmi hai.');
        }
        if (_vehicleReg.isEmpty) {
          return _fail('Gaari ke kaghaz (registration) ki tasveer lazmi hai.');
        }
        // PTA Proof: IMEI ki shart Master ke switch par hai
        // (settings.pta_required, migration v133; Fares.ptaRequired).
        // Default BAND hai — IMEI filhal IKHTIYARI hai: khaali ho
        // to koi rok nahi; LIKHA jaye to durust (15 digits + Luhn
        // check digit — typo yahin pakra jata hai) hona lazmi hai.
        // Master switch ON kare to IMEI lazmi ho jata hai.
        final imeiDigits = _digits(_imeiCtrl.text);
        if (Fares.ptaRequired &&
            (imeiDigits.length != 15 || !_validImei(imeiDigits))) {
          return _fail(
              'PTA Proof: durust IMEI likhein — *#06# dial karke 15 digits ka IMEI bilkul waisa hi likhein. IMEI ghalat ho to ID nahi banti.');
        }
        if (!Fares.ptaRequired &&
            imeiDigits.isNotEmpty &&
            (imeiDigits.length != 15 || !_validImei(imeiDigits))) {
          return _fail(
              'PTA Proof: IMEI likha hai to durust likhein — *#06# dial karke 15 digits ka IMEI bilkul waisa hi likhein, warna khaali chhor dein — filhal ye ikhtiyari hai.');
        }
        return true;
      case 4:
        if (_licenceSkip) return true;
        if (_licenceCtrl.text.trim().isEmpty) {
          return _fail(
              'Licence number likhein — ya neeche "Licence nahi hai — skip karein" dabayein.');
        }
        return true;
      case 5:
        if (_selfie.isEmpty) {
          return _fail(
              'Live selfie lazmi hai — camera se abhi tasveer lein.');
        }
        return true;
      case 6:
        // FORM USOOL: sheher driver khud chunta hai — khaali ho to
        // register aage nahi barhta (koi default sheher NAHI lagta).
        if (_zone.isEmpty) {
          return _fail('Apna sheher (ilaqa) chunein — upar wale list se.');
        }
        // v1.4.4 LEGAL: Sharait ki qubooliyat lazmi hai — baghair
        // "Mein ne parh liya, qabool hai" ke register NAHI hota.
        if (!_termsChecked && store.profile.termsAcceptedAtMs == 0) {
          return _fail(
              'Sharait qabool karna lazmi hai — neeche Sharait parh kar "Mein ne parh liya, qabool hai" par nishan lagayein.');
        }
        return true;
      default:
        return true;
    }
  }

  /// Password wala qadam — v1.2.5 ke AIN usool: min 6, match, aur
  /// backend uniqueness check (internet ke baghair aage nahi).
  Future<bool> _validatePasswordStep() async {
    if (p.pwdFp.isNotEmpty) return true; // pehle se set hai
    final pw = _pwdCtrl.text;
    if (pw.isNotEmpty && pw == _checkedPw && _stagedFp != null) {
      return true; // yehi password pehle check pass kar chuka hai
    }
    if (pw.length < 6) {
      return _fail('Password kam az kam 6 haroof ka ho.');
    }
    if (pw != _pwd2Ctrl.text) {
      return _fail('Dono password ek jaise nahi hain.');
    }
    setState(() => _busy = true);
    final fp = passwordFingerprint(pw);
    final taken = await Backend.passwordFingerprintTaken(store, fp);
    if (!mounted) return false;
    setState(() => _busy = false);
    if (taken == null) {
      return _fail(
          'Password ki safety check ke liye internet chahiye — net on karke dobara koshish karein.');
    }
    if (taken) {
      _pwdCtrl.clear();
      _pwd2Ctrl.clear();
      _stagedFp = null;
      _checkedPw = '';
      return _fail(
          'Ye password kisi aur ne lagaya hua hai, aap koi aur password lagayen');
    }
    _stagedFp = fp;
    _checkedPw = pw;
    return true;
  }

  Future<void> _next() async {
    if (_busy) return;
    if (!await _validateStep()) return;
    if (!mounted) return;
    setState(() {
      _error = null;
      if (_step < 6) _step++;
    });
  }

  void _back() {
    setState(() {
      _error = null;
      if (_step > 0) _step--;
    });
  }

  // --- Register (submit) ------------------------------------------------------

  Future<void> _submit() async {
    final v = store.profile;
    // NUMBER TABDEELI = 12 GHANTE BLOCK (malik ka hukm
    // 2026-11-08): pehle se registered driver apna number badle
    // to ID khud-ba-khud 12 ghante block — na online, na ride.
    // Waqt poora hote hi block khud khatam ho jata hai. Pehli
    // registration (purana number khaali) par ye NAHI lagta.
    final oldPhone = v.phone;
    final newPhone = _digits(_mobileCtrl.text);
    if (v.registrationDone &&
        oldPhone.isNotEmpty &&
        newPhone.isNotEmpty &&
        newPhone != oldPhone) {
      v.numberBlockedUntilMs =
          DateTime.now().millisecondsSinceEpoch + 12 * 3600 * 1000;
    }
    v.phone = newPhone;
    v.name = _nameCtrl.text.trim();
    v.cnicNumber = _formatCnic(_digits(_cnicCtrl.text));
    v.cnicFrontPath = _cnicFront;
    v.cnicBackPath = _cnicBack;
    if (_stagedFp != null) {
      v.pwdFp = _stagedFp!;
      v.pwdFailCount = 0;
      v.pwdLockUntilMs = 0;
    }
    v.vehicle = _vehicle;
    v.vehicleBrand = _brandCtrl.text.trim();
    v.vehicleModel = _modelCtrl.text.trim();
    v.vehicleYear = _year ?? 0;
    v.vehicleColor = _colorCtrl.text.trim();
    v.plate = _plateCtrl.text.trim();
    v.vehiclePhotoPath = _vehiclePhoto;
    v.vehicleRegPath = _vehicleReg;
    // PTA Proof — IMEI: badla ho to Master ka pta_status dobara
    // 'pending' (v131 trigger pta_resubmit_at se) taaki naya IMEI
    // dobara check ho — driver *_status khud NAHI likhta (lock).
    final newImei = _digits(_imeiCtrl.text);
    if (newImei.isNotEmpty && v.imei.isNotEmpty && newImei != v.imei) {
      v.docResubmitAt['pta'] = DateTime.now().toUtc().toIso8601String();
    }
    v.imei = newImei;
    if (_licenceSkip) {
      v.licenceStatus = 'none';
      v.licenceVerified = false;
      v.licenceNumber = '';
      v.licencePhotoPath = '';
    } else {
      final newNumber = _licenceCtrl.text.trim();
      if (newNumber != v.licenceNumber) v.licenceVerified = false;
      v.licenceStatus = 'has';
      v.licenceNumber = newNumber;
      v.licencePhotoPath = _licencePhoto;
    }
    v.profilePhotoPath = _selfie;
    v.zone = _zone;
    v.registrationDone = true;
    // Kagazat ki rukawatein registration ke waqt hi saaf (v1.2.9):
    // purane self-attestation wale local jhande nayi tasaveer par
    // dobara 'pending' ho jate hain — faisla ab sirf Master ka hai.
    v.cnicStatus = 'pending';
    v.vehiclePapers = 'pending';
    // store.save() → 'profile' hook → backend drivers row (numbers,
    // tafseel, fingerprint) Master tak mirror ho jata hai. Document
    // STATUS columns is mirror mein NAHI jate (Master-owned hain).
    await store.save();
    if (mounted) setState(() => _done = true);
  }

  static String _formatCnic(String d) {
    if (d.length != 13) return d;
    return '${d.substring(0, 5)}-${d.substring(5, 12)}-${d.substring(12)}';
  }

  // --- Build ------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Driver Registration'),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: _done ? _doneView() : _formView(),
    );
  }

  Widget _doneView() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.check_circle, color: Brand.green, size: 84),
          const SizedBox(height: 16),
          const Text('Registration Mukammal!',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          const Text(
            'Darkhwast Master ke paas chali gayi hai — tasdeeq ke baad aap online ho sakenge.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Theek hai'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _formView() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
          child: Row(
            children: [
              Text('Qadam ${_step + 1} / 7',
                  style: const TextStyle(
                      fontWeight: FontWeight.w800, color: Brand.greenDark)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(_titles[_step],
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w900)),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: LinearProgressIndicator(
            value: (_step + 1) / 7,
            color: Brand.gold,
            backgroundColor: Brand.fieldBorder,
            minHeight: 6,
            borderRadius: BorderRadius.circular(3),
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _stepBody(),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!,
                    style: const TextStyle(
                        color: Brand.ajrakRed,
                        fontWeight: FontWeight.w700,
                        fontSize: 14)),
              ],
            ],
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Row(
              children: [
                if (_step > 0)
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _busy ? null : _back,
                      child: const Text('Peeche'),
                    ),
                  ),
                if (_step > 0) const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: _step == 6
                      ? ElevatedButton(
                          onPressed: () async {
                            // Register se pehle aakhri qadam ki
                            // jaanch (sheher lazmi hai — FORM USOOL).
                            if (await _validateStep()) _submit();
                          },
                          child: const Text('Register Karein'),
                        )
                      : ElevatedButton(
                          onPressed: _busy ? null : _next,
                          child:
                              Text(_busy ? 'Check ho raha hai…' : 'Aage'),
                        ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _stepBody() {
    switch (_step) {
      case 0:
        return _stepMobile();
      case 1:
        return _stepPersonal();
      case 2:
        return _stepPassword();
      case 3:
        return _stepVehicle();
      case 4:
        return _stepLicence();
      case 5:
        return _stepSelfie();
      default:
        return _stepReview();
    }
  }

  // --- Step 1: Mobile ---------------------------------------------------------

  Widget _stepMobile() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Apna mobile number likhein — isi number par sawari aur Master rabta karenge.',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _mobileCtrl,
          keyboardType: TextInputType.phone,
          maxLength: 11,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(
            labelText: 'Mobile number (03XXXXXXXXX)',
            prefixIcon: Icon(Icons.phone),
          ),
        ),
      ],
    );
  }

  // --- Step 2: Zaati maloomat ---------------------------------------------------

  Widget _stepPersonal() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: _nameCtrl,
          decoration: const InputDecoration(
            labelText: 'Pura naam (CNIC wala)',
            prefixIcon: Icon(Icons.person),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _cnicCtrl,
          keyboardType: TextInputType.number,
          inputFormatters: [_CnicInputFormatter()],
          decoration: const InputDecoration(
            labelText: 'CNIC number (XXXXX-XXXXXXX-X)',
            prefixIcon: Icon(Icons.badge),
          ),
        ),
        const SizedBox(height: 16),
        const Text('CNIC ki tasaveer',
            style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: _photoSlot(
                label: 'CNIC — Samne',
                path: _cnicFront,
                icon: Icons.credit_card,
                onPick: () => _pickPhoto((v) => _cnicFront = v),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _photoSlot(
                label: 'CNIC — Peeche',
                path: _cnicBack,
                icon: Icons.credit_card,
                onPick: () => _pickPhoto((v) => _cnicBack = v),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // --- Step 3: Password ---------------------------------------------------------

  Widget _stepPassword() {
    if (p.pwdFp.isNotEmpty) {
      return const Card(
        child: ListTile(
          leading: Icon(Icons.lock, color: Brand.green),
          title: Text('Password pehle se set hai',
              style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(
              'Aap ka password laga hua hai — ek password sirf aap ka hai. Badalna ho to Profile se badlein.'),
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Apna password khud lagayein. Ek password sirf ek hi driver ka hota hai — jo pehle lag jaye, wohi us ka ho jata hai. Duty shuru karne par yahi password manga jayega.',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _pwdCtrl,
          obscureText: true,
          decoration: const InputDecoration(
            labelText: 'Password (kam az kam 6 haroof)',
            prefixIcon: Icon(Icons.lock),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _pwd2Ctrl,
          obscureText: true,
          decoration: const InputDecoration(
            labelText: 'Password dobara likhein',
            prefixIcon: Icon(Icons.lock_outline),
          ),
        ),
      ],
    );
  }

  // --- Step 4: Gaari ki maloomat ----------------------------------------------

  Widget _stepVehicle() {
    final years = <int>[
      for (var y = DateTime.now().year + 1; y >= 1990; y--) y
    ];
    final suggestions = _brandSuggestions[_vehicle] ?? const <String>[];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Gaari ki qisam',
            style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Row(
          children: [
            for (final v in kVehicles) ...[
              Expanded(child: _vehicleCard(v)),
              if (v != kVehicles.last) const SizedBox(width: 10),
            ],
          ],
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _brandCtrl,
          decoration: const InputDecoration(
            labelText: 'Company / Brand (masalan Sazgar)',
            prefixIcon: Icon(Icons.factory),
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: suggestions
              .map((s) => ChoiceChip(
                    label: Text(s),
                    selected: _brandCtrl.text.trim() == s,
                    onSelected: (_) =>
                        setState(() => _brandCtrl.text = s),
                  ))
              .toList(),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _modelCtrl,
          decoration: const InputDecoration(
            labelText: 'Model (masalan 150cc, Mehran VX)',
            prefixIcon: Icon(Icons.directions_car),
          ),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<int>(
          value: _year,
          isExpanded: true,
          decoration: const InputDecoration(
            labelText: 'Saal (Year)',
            prefixIcon: Icon(Icons.calendar_month),
          ),
          items: years
              .map((y) => DropdownMenuItem(value: y, child: Text('$y')))
              .toList(),
          onChanged: (v) => setState(() => _year = v),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _colorCtrl,
          decoration: const InputDecoration(
            labelText: 'Rang (Color)',
            prefixIcon: Icon(Icons.palette),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _plateCtrl,
          decoration: const InputDecoration(
            labelText: 'Number plate',
            prefixIcon: Icon(Icons.pin),
          ),
        ),
        const SizedBox(height: 16),
        const Text('Gaari ki tasaveer',
            style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: _photoSlot(
                label: 'Gaari ki tasveer',
                path: _vehiclePhoto,
                icon: Icons.photo_camera,
                onPick: () => _pickPhoto((v) => _vehiclePhoto = v),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _photoSlot(
                label: 'Kaghaz (Registration)',
                path: _vehicleReg,
                icon: Icons.description,
                onPick: () => _pickPhoto((v) => _vehicleReg = v),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        const Text('PTA Proof',
            style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Text(
          Fares.ptaRequired
              ? 'Apne mobile ka IMEI number likhein — *#06# dial karne se IMEI screen par a jata hai, bilkul waisa hi yahan likh dein. '
                  'ID sirf tab OK (Active) hogi jab ye IMEI check hone par PTA-approved nikle. IMEI ghalat ya mobile PTA-approved na ho to ID NAHI banti. '
                  'Master Tasdeeq mein is IMEI ko 8484/DIRBS par check karke faisla karega.'
              : 'Apne mobile ka IMEI number likh dein — *#06# dial karne se IMEI screen par a jata hai, bilkul waisa hi yahan likh dein. '
                  'Filhal ye IKHTIYARI hai — na likhein to bhi ID ban sakti hai; likh dein to Master Tasdeeq mein is IMEI ko 8484/DIRBS par check kar sakta hai. '
                  'Jab Master "PTA Proof lazmi" ON karega, tab IMEI lazmi ho jayega.',
          style: const TextStyle(
              fontSize: 12.5, height: 1.45, color: Colors.black87),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _imeiCtrl,
          keyboardType: TextInputType.number,
          maxLength: 15,
          decoration: const InputDecoration(
            labelText: 'IMEI Number (15 digits)',
            prefixIcon: Icon(Icons.verified),
            counterText: '',
          ),
        ),
      ],
    );
  }

  Widget _vehicleCard(String v) {
    final selected = _vehicle == v;
    final icon = v == 'Bike'
        ? Icons.two_wheeler
        : v == 'Car'
            ? Icons.directions_car
            : Icons.airport_shuttle;
    return InkWell(
      onTap: () => setState(() => _vehicle = v),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: selected ? Brand.green : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: selected ? Brand.gold : Brand.fieldBorder, width: 2),
        ),
        child: Column(
          children: [
            Icon(icon,
                size: 32,
                color: selected ? Colors.white : Brand.green),
            const SizedBox(height: 6),
            Text(v,
                style: TextStyle(
                    fontWeight: FontWeight.w800,
                    color: selected ? Colors.white : Brand.ink)),
          ],
        ),
      ),
    );
  }

  // --- Step 5: Driving licence (OPTIONAL) ---------------------------------------

  Widget _stepLicence() {
    if (_licenceSkip) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Card(
            child: ListTile(
              leading: Icon(Icons.info_outline, color: Brand.green),
              title: Text('Licence skip hai',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(
                  'Koi baat nahi — CNIC se registration ho jayegi. Licence ho to neeche se tafseel likh dein.'),
            ),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => setState(() {
              _licenceSkip = false;
              _error = null;
            }),
            icon: const Icon(Icons.badge),
            label: const Text('Licence hai — tafseel likhein'),
          ),
        ],
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Licence hai to number aur tasveer dein. Licence NA ho to registration nahi rukti — CNIC hi kafi hai.',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _licenceCtrl,
          decoration: const InputDecoration(
            labelText: 'Licence number',
            prefixIcon: Icon(Icons.badge),
          ),
        ),
        const SizedBox(height: 16),
        _photoSlot(
          label: 'Licence ki tasveer',
          path: _licencePhoto,
          icon: Icons.badge,
          onPick: () => _pickPhoto((v) => _licencePhoto = v),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: () => setState(() {
              _licenceSkip = true;
              _error = null;
              if (_step < 6) _step++;
            }),
            child: const Text('Licence nahi hai — skip karein'),
          ),
        ),
      ],
    );
  }

  // --- Step 6: Live selfie ------------------------------------------------------

  Widget _stepSelfie() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Apni asal tasveer — ye aap ki registration profile photo hai. Camera se hi hogi, gallery se nahi. (Rozana wali duty selfie is se alag hoti hai.)',
          style: TextStyle(fontSize: 13, color: Colors.black54),
        ),
        const SizedBox(height: 18),
        Center(
          child: ClipOval(
            child: _selfie.isNotEmpty && File(_selfie).existsSync()
                ? Image.file(File(_selfie),
                    width: 170, height: 170, fit: BoxFit.cover)
                : Container(
                    width: 170,
                    height: 170,
                    color: Brand.fieldBorder,
                    child: const Icon(Icons.face,
                        size: 80, color: Brand.green),
                  ),
          ),
        ),
        const SizedBox(height: 18),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: () =>
                _pickPhoto((v) => _selfie = v, cameraOnly: true),
            icon: const Icon(Icons.camera_alt),
            label:
                Text(_selfie.isEmpty ? 'Live Selfie Lein' : 'Dobara Lein'),
          ),
        ),
      ],
    );
  }

  // --- Step 7: Ilaqa + Jaiza -----------------------------------------------------

  Widget _stepReview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Apna sheher (ilaqa) chunein',
            style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        // Sheher pehle se set NAHI hota (FORM USOOL 2026-11-08):
        // _zone khaali ho to dropdown khaali (hint) dikhta hai aur
        // driver apna sheher khud chunta hai.
        DropdownButtonFormField<String>(
          value: _zone.isEmpty ? null : _zone,
          isExpanded: true,
          hint: const Text('Apna sheher chunein'),
          items: kZones
              .map((z) => DropdownMenuItem(value: z, child: Text(z)))
              .toList(),
          onChanged: (v) => setState(() => _zone = v ?? _zone),
          decoration: const InputDecoration(labelText: 'Sheher (Zone)'),
        ),
        const SizedBox(height: 18),
        const Text('Jaiza — apni maloomat check kar lein',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        _reviewRow('Mobile', _digits(_mobileCtrl.text)),
        _reviewRow('Naam', _nameCtrl.text.trim()),
        _reviewRow('CNIC', _formatCnic(_digits(_cnicCtrl.text))),
        _reviewRow(
            'Password', p.pwdFp.isNotEmpty || _stagedFp != null ? 'Set hai' : '—'),
        _reviewRow('Gaari',
            '$_vehicle · ${_brandCtrl.text.trim()} ${_modelCtrl.text.trim()}'),
        _reviewRow('Saal / Rang',
            '${_year ?? '—'} · ${_colorCtrl.text.trim()}'),
        _reviewRow('Number plate', _plateCtrl.text.trim()),
        _reviewRow(
            'Licence',
            _licenceSkip
                ? 'Licence nahi hai'
                : (_licenceCtrl.text.trim().isEmpty
                    ? '—'
                    : _licenceCtrl.text.trim())),
        _reviewRow('Zone', _zone),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            _thumb('CNIC Samne', _cnicFront),
            _thumb('CNIC Peeche', _cnicBack),
            _thumb('Gaari', _vehiclePhoto),
            _thumb('Kaghaz', _vehicleReg),
            if (!_licenceSkip && _licencePhoto.isNotEmpty)
              _thumb('Licence', _licencePhoto),
            _thumb('Selfie', _selfie),
          ],
        ),
        const SizedBox(height: 14),
        const Text(
          'Register karne par ye maloomat Master ke paas chali jayegi. Tasdeeq ke baad account active hoga.',
          style: TextStyle(fontSize: 12, color: Colors.black54),
        ),
        const SizedBox(height: 16),
        // v1.4.4 LEGAL: Sharait ki qubooliyat — aakhri qadam ki
        // lazmi shart. Qabool karne ka waqt darj ho jata hai aur
        // Master ko backend par saboot ke tor par nazar ata hai.
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Brand.lightBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Brand.fieldBorder),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(Icons.description, size: 19, color: Brand.green),
                  SizedBox(width: 8),
                  Text('Bozdar Safar ki Sharait',
                      style: TextStyle(
                          fontWeight: FontWeight.w900, fontSize: 14.5)),
                ],
              ),
              const SizedBox(height: 4),
              const Text(
                'Driver ki tamam sharait — gaari ke kaghaz, traffic qanoon, hadse ki soorat, 10% service fee aur haftawar hisaab ke usool samait — parh lein. Register karne ke liye sharait qabool karna lazmi hai.',
                style: TextStyle(fontSize: 12.5, color: Colors.black54),
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                        builder: (_) => const TermsPage()),
                  ),
                  icon: const Icon(Icons.menu_book, size: 17),
                  label: const Text('Sharait Parhein'),
                ),
              ),
              CheckboxListTile(
                value: _termsChecked,
                onChanged: (v) async {
                  setState(() => _termsChecked = v ?? false);
                  if (v == true) {
                    // Qabool karte hi waqt darj (profile + backend).
                    await store.acceptDriverTerms();
                  }
                },
                title: const Text('Mein ne parh liya, qabool hai',
                    style: TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 14)),
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.zero,
                dense: true,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _reviewRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(label,
                style: const TextStyle(
                    fontWeight: FontWeight.w700, color: Colors.black54)),
          ),
          Expanded(
            child: Text(value.isEmpty ? '—' : value,
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _thumb(String label, String path) {
    final ok = path.isNotEmpty && File(path).existsSync();
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: ok
              ? Image.file(File(path),
                  width: 64, height: 64, fit: BoxFit.cover)
              : Container(
                  width: 64,
                  height: 64,
                  color: Brand.fieldBorder,
                  child: const Icon(Icons.image_not_supported,
                      color: Brand.ajrakRed),
                ),
        ),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(fontSize: 10)),
      ],
    );
  }

  // --- Photo slot (tasveer wali jagah) ------------------------------------------

  Widget _photoSlot({
    required String label,
    required String path,
    required IconData icon,
    required VoidCallback onPick,
  }) {
    final ok = path.isNotEmpty && File(path).existsSync();
    return InkWell(
      onTap: onPick,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: ok ? Brand.green : Brand.fieldBorder,
              width: ok ? 1.8 : 1.2),
        ),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: ok
                  ? Image.file(File(path),
                      width: double.infinity, height: 92, fit: BoxFit.cover)
                  : Container(
                      width: double.infinity,
                      height: 92,
                      color: Brand.lightBg,
                      child: Icon(icon, size: 40, color: Brand.green),
                    ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(ok ? Icons.check_circle : Icons.add_a_photo,
                    size: 16,
                    color: ok ? Brand.green : Brand.ajrakRed),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(label,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.w700)),
                ),
              ],
            ),
            Text(ok ? 'Badalne ke liye dabayein' : 'Tasveer lazmi hai',
                style:
                    const TextStyle(fontSize: 10, color: Colors.black54)),
          ],
        ),
      ),
    );
  }
}

/// CNIC ka input formatter: sirf number, kul 13, khud-ba-khud
/// XXXXX-XXXXXXX-X ki shakal (5-7-1) banata hai.
class _CnicInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    var d = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.length > 13) d = d.substring(0, 13);
    final buf = StringBuffer();
    for (var i = 0; i < d.length; i++) {
      if (i == 5 || i == 12) buf.write('-');
      buf.write(d[i]);
    }
    final out = buf.toString();
    return TextEditingValue(
      text: out,
      selection: TextSelection.collapsed(offset: out.length),
    );
  }
}
