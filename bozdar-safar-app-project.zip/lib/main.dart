import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'store.dart';
import 'theme.dart';
import 'passenger.dart';
import 'driver.dart';

void main() {
  runApp(const BozdarSafarApp());
}

class BozdarSafarApp extends StatefulWidget {
  const BozdarSafarApp({super.key});

  @override
  State<BozdarSafarApp> createState() => _BozdarSafarAppState();
}

class _BozdarSafarAppState extends State<BozdarSafarApp> {
  final AppStore store = AppStore();

  @override
  void initState() {
    super.initState();
    // Load ke baad ek dafa khamosh update check (fire-and-forget).
    store.load().then((_) => store.checkForUpdate());
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Safar',
      debugShowCheckedModeBanner: false,
      theme: Brand.theme(),
      home: AnimatedBuilder(
        animation: store,
        builder: (context, _) {
          if (!store.loaded) {
            return const Scaffold(
              backgroundColor: Brand.deepGreen,
              body: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.local_taxi, color: Brand.gold, size: 56),
                    SizedBox(height: 14),
                    Text(
                      'SAFAR',
                      style: TextStyle(
                        color: Brand.gold,
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.4,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Your ride, your people.',
                      style: TextStyle(color: Brand.cream, fontSize: 13),
                    ),
                  ],
                ),
              ),
            );
          }
          return ModeShell(store: store);
        },
      ),
    );
  }
}

/// ONE app, TWO fully separated sides. Exactly ONE switch button exists on
/// each side — never a two-option toggle:
///  - Passenger side: one button "Driver Mode mein jayein"
///  - Driver side:    one button "Passenger Mode mein jayein"
/// One tap replaces the whole display; the other side never renders.
class ModeShell extends StatefulWidget {
  final AppStore store;
  const ModeShell({super.key, required this.store});

  @override
  State<ModeShell> createState() => _ModeShellState();
}

class _ModeShellState extends State<ModeShell> {
  bool driverMode = false;

  @override
  Widget build(BuildContext context) {
    if (driverMode) {
      return DriverSide(
        store: widget.store,
        onSwitchToPassenger: () => setState(() => driverMode = false),
      );
    }
    return PassengerSide(
      store: widget.store,
      onSwitchToDriver: () => setState(() => driverMode = true),
    );
  }
}

/// The single mode-switch button. [toDriver] decides its label/direction.
class SwitchModeButton extends StatelessWidget {
  final bool toDriver;
  final VoidCallback onTap;
  const SwitchModeButton(
      {super.key, required this.toDriver, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(toDriver ? Icons.drive_eta : Icons.person, size: 20),
        label: Text(toDriver
            ? 'Driver Mode mein jayein'
            : 'Passenger Mode mein jayein'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Brand.gold,
          foregroundColor: Brand.greenDark,
          padding: const EdgeInsets.symmetric(vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
        ),
      ),
    );
  }
}

/// Nayi update ka slim gold banner — dono sides ke home ke upar dikhta
/// hai. "Update karein" download link kholta hai; × dabane se sirf is
/// session ke liye chhup jata hai.
class UpdateBanner extends StatelessWidget {
  final AppStore store;
  const UpdateBanner({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: Brand.gold,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(
        children: [
          const Icon(Icons.system_update, size: 18, color: Brand.greenDark),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              'Safar ki nayi update aa gayi hai',
              style: TextStyle(
                  color: Brand.greenDark,
                  fontSize: 13,
                  fontWeight: FontWeight.w800),
            ),
          ),
          TextButton(
            onPressed: () => launchUrl(
              Uri.parse(kUpdateDownloadUrl),
              mode: LaunchMode.externalApplication,
            ),
            style: TextButton.styleFrom(
              backgroundColor: Brand.greenDark,
              foregroundColor: Brand.cream,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              minimumSize: Size.zero,
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: const Text('Update karein',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(width: 4),
          IconButton(
            onPressed: store.dismissUpdate,
            icon: const Icon(Icons.close, size: 18, color: Brand.greenDark),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
            tooltip: 'Band karein',
          ),
        ],
      ),
    );
  }
}
