-- =====================================================================
-- ZONE-ANNOUNCE (malik ka hukm 2026-11-21)
--
-- Maqsad: jab malik Master app se koi sheher/ilaqa KHOLTA hai to usi
-- sheher ke tamam users (sawari + driver) ko app ke andar khud
-- elaan pohanch jaye — malik ko alag se message na karna pade.
--
-- Tabdeeli:
--   1) announcements.zone     — elaan kis sheher ke liye hai.
--      NULL/khaali = purana rawaiya (sab sheher, sab users).
--      Bhara ho to P+D apps sirf usi sheher ke user ko dikhati hain
--      (driver ka darj sheher drivers.zone se, sawari ka
--      passengers.zone / local passengerZone se match hota hai).
--   2) announcements.audience — 'all' | 'passenger' | 'driver'.
--      Default 'all' = purani tamam rows ka rawaiya barkarar.
--   3) passengers.zone        — sawari ka darj sheher. Pehle ye
--      column maujood hi NAHI tha (sawari ka koi sheher record hi
--      nahi hota tha); app ab booking ke pickup sheher se ise
--      bharti hai (Backend.pushPassengerZone).
--
-- RLS: koi policy tabdeeli NAHI chahiye — announcements par apps ki
-- SELECT aur Master ki INSERT policies pehle se maujood hain, naye
-- columns unhi policies ke andar ate hain. passengers par sawari ki
-- apni row ka upsert pehle se chalta hai.
--
-- Lagane ka tareeqa: Supabase Dashboard → SQL Editor mein ye poori
-- file ek dafa chalayein. Idempotent hai (if not exists) — dobara
-- chalane se koi nuqsan nahi.
-- =====================================================================

alter table public.announcements
  add column if not exists zone text;

alter table public.announcements
  add column if not exists audience text not null default 'all';

do $$
begin
  alter table public.announcements
    add constraint announcements_audience_check
    check (audience in ('all', 'passenger', 'driver'));
exception
  when duplicate_object then null;
end $$;

create index if not exists idx_announcements_zone
  on public.announcements (zone);

alter table public.passengers
  add column if not exists zone text;
