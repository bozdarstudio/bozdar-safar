import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'lang.dart';
import 'store.dart';

/// =====================================================================
/// AWAAZ (VOICE) — UPDATE KA AWAAZ WALA ELAN (v1.4.35, malik ka hukm
/// 2026-11-12; audit ke baad wali wave)
///
/// Device ka apna text-to-speech: koi pub package NAHI — MainActivity
/// mein ek chhota MethodChannel 'bozdar_safar/tts' hai jo Android ke
/// apne TextToSpeech engine ko chalata hai (Master v1.4.18 ke
/// lib/voice.dart wala wohi proven pattern, P+D ke package ke
/// mutabiq). Urdu locale (ur-PK) pehle try hota hai; na mile to
/// phone ki default awaaz — text maujooda app zubaan mein hai.
///
/// ⭐ ASAL-JAANKARI LOCK: elan SIRF tab hota hai jab asal
/// update-check (UpdatePolicy — backend settings se lagne wali
/// asal haddien) bataye ke naya update dastiyab hai (level 1 ya 2).
/// Update na ho to bilkul khamoshi — koi jhoota elan NAHI. Awaaz
/// dastiyab na ho (engine na mile) to bhi khamoshi — app kabhi
/// "bol diya" ka jhoota dawa NAHI karti aur kabhi rukti NAHI.
/// =====================================================================
class Voice {
  static const MethodChannel _channel = MethodChannel('bozdar_safar/tts');

  /// [text] bol kar sunana. [queue] true ho to chalti hui awaaz ke
  /// BAAD lagega; warna pehle wali rok kar ye chalega. Nateeja:
  /// true = engine ne bolna shuru kar diya; false = is phone par
  /// awaaz dastiyab NAHI. Kabhi throw NAHI karta.
  static Future<bool> speak(String text, {bool queue = false}) async {
    final t = text.trim();
    if (t.isEmpty) return false;
    try {
      final ok = await _channel.invokeMethod<bool>('speak', {
        'text': t,
        'queue': queue,
      });
      return ok == true;
    } catch (e) {
      debugPrint('[Voice] speak nahi ho saka: $e');
      return false;
    }
  }

  /// Chalti hui awaaz band karna. Kabhi throw NAHI karta.
  static Future<void> stop() async {
    try {
      await _channel.invokeMethod<void>('stop');
    } catch (_) {
      // Awaaz band na bhi ho to app kabhi nahi rukti.
    }
  }
}

String _dayKey(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

/// Update elan ka jumla — [level] UpdatePolicy.level hai:
/// 2 (mandatory) par malik wala sakht jumla, 1 (recommended) par
/// naram elan. Zubaan maujooda app zubaan ke mutabiq.
String updateVoiceText(int level, {required bool english}) {
  if (level >= 2) {
    return english
        ? 'Brother, please update the app — only then you will get good rides.'
        : 'Bhai, app update karein — tabhi aap ko achi wali rides milengi';
  }
  return english
      ? 'Brother, a new update of the Safar app has arrived — please update.'
      : 'Bhai, Safar app ka naya update aa gaya hai — update kar lein.';
}

/// Saf taur par jaanch (pure — test yahin hote hain): aaj ka elan
/// hona chahiye ya nahi. Shartein: asal update level kam az kam 1
/// ho, is session mein pehle na bola ho, aur aaj ke din ka record
/// pehle se maujood na ho.
bool shouldSpeakUpdateToday({
  required int level,
  required bool sessionDone,
  required String? lastSpokenDay,
  required String today,
}) {
  if (level < 1) return false;
  if (sessionDone) return false;
  if (lastSpokenDay == today) return false;
  return true;
}

/// ---------------------------------------------------------------------
/// UPDATE KI AWAAZ: asal update-check (UpdatePolicy.level >= 1)
/// bataye ke naya update hai to din mein EK dafa awaaz mein elan —
/// dono sides (Driver + Passenger) isi ek HomeShell se chalte hain,
/// is liye elan dono par lagu hai. Din ka record SharedPreferences
/// mein; dobara NAHI. Elan sirf tab "ho gaya" gina jata hai jab
/// engine asal mein bol de (Voice.speak true) — warna agli jaanch
/// par dobara koshish hogi, jhoota record NAHI banta.
/// ---------------------------------------------------------------------
class UpdateVoice {
  static const String _kSpokenDay = 'voice_update_spoken_day';
  static bool _spokenThisSession = false;

  static Future<void> checkOnceDaily() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final today = _dayKey(DateTime.now());
      if (!shouldSpeakUpdateToday(
        level: UpdatePolicy.level,
        sessionDone: _spokenThisSession,
        lastSpokenDay: prefs.getString(_kSpokenDay),
        today: today,
      )) {
        return;
      }
      final ok = await Voice.speak(
        updateVoiceText(UpdatePolicy.level, english: Lang.isEn),
        queue: true,
      );
      if (ok) {
        await prefs.setString(_kSpokenDay, today);
        _spokenThisSession = true;
      }
    } catch (_) {
      // Elan na ho to banner/notification maujood hai hi — app
      // kabhi nahi rukti.
    }
  }
}
