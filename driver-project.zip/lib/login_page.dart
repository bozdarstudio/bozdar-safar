import 'dart:async';
import 'package:flutter/material.dart';
import 'backend.dart';
import 'lang.dart';
import 'otp.dart';
import 'store.dart';
import 'theme.dart';

/// DRIVER LOGIN (v1.4.47 — malik ka hukm 2026-11-22): maujooda
/// account walon ke liye saaf, numaya login darwaza — khaas
/// taur par naye phone par, jahan pehle banda majbooran
/// registration form mein phans jata tha (malik khud phansa
/// tha)।
///
/// Do raste — dono ke peeche wohi maujooda mechanism hai
/// (Supabase Auth email OTP: Backend.sendEmailOtp /
/// verifyEmailOtp + EmailOtpSection); koi naya auth system
/// NAHI bana:
///  (a) MOBILE NUMBER: drivers record mein number dhoondha
///      jata hai; account ke saath Gmail juda ho to tasdeeq
///      ke liye code USI Gmail par jata hai (Gmail sirf
///      masked dikhta hai — plan §7.3 ka wohi usool)।
///  (b) GMAIL: pehle record ki talash, phir EmailOtpSection
///      se OTP tasdeeq; verify ke baad bandha hua driver
///      record (email / identity_links) is phone par apnaya
///      jata hai (store.adoptRecoveredDriver)।
/// Record NA mile to saaf paigham + wapas registration ka
/// rasta — maujooda account wala dobara registration bharne
/// par majboor NAHI hota, aur jhooti kamyabi bhi NAHI banti:
/// server ki parhai RLS se band ho to adopt nahi hota aur
/// paigham mein Master se rabte ki rehnumai milti hai।
class DriverLoginPage extends StatefulWidget {
  final AppStore store;

  const DriverLoginPage({super.key, required this.store});

  @override
  State<DriverLoginPage> createState() => _DriverLoginPageState();
}

class _DriverLoginPageState extends State<DriverLoginPage> {
  // 0 = mobile rasta, 1 = Gmail rasta।
  int _mode = 0;

  final _mobileCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();

  bool _busy = false;
  String? _error;
  bool _showRegister = false;

  // Mobile raste par mila hua account — OTP is ke email par
  // jayega (poora email screen par NAHI dikhta, sirf masked)।
  Map<String, dynamic>? _foundRow;
  String _foundEmail = '';
  bool _codeSent = false;

  @override
  void dispose() {
    _mobileCtrl.dispose();
    _emailCtrl.dispose();
    _codeCtrl.dispose();
    super.dispose();
  }

  String _maskEmail(String e) {
    final at = e.indexOf('@');
    if (at <= 0) return e;
    final head = e.substring(0, at);
    final shown = head.length <= 2 ? head : head.substring(0, 2);
    return '$shown•••${e.substring(at)}';
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  // --- Mobile rasta -----------------------------------------------------------

  Future<void> _findByMobile() async {
    final digits = _mobileCtrl.text.replaceAll(RegExp(r'[^0-9]'), '');
    setState(() {
      _error = null;
      _showRegister = false;
      _foundRow = null;
      _codeSent = false;
      _codeCtrl.clear();
    });
    if (digits.length < 10) {
      setState(() => _error = tr('login_not_found_mobile'));
      return;
    }
    setState(() => _busy = true);
    final res = await Backend.findDriverRowByMobile(digits);
    if (!mounted) return;
    setState(() => _busy = false);
    if (!res.answered) {
      setState(() => _error = tr('login_net_err'));
      return;
    }
    final row = res.row;
    if (row == null) {
      setState(() {
        _error = tr('login_not_found_mobile');
        _showRegister = true;
      });
      return;
    }
    final email = (row['email']?.toString() ?? '').trim().toLowerCase();
    if (email.isEmpty || !email.contains('@')) {
      setState(() => _error = tr('login_no_email'));
      return;
    }
    setState(() {
      _foundRow = row;
      _foundEmail = email;
    });
  }

  Future<void> _sendCodeToFound() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    final ok = await Backend.sendEmailOtp(_foundEmail);
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (ok) {
        _codeSent = true;
      } else {
        _error = tr('login_net_err');
      }
    });
  }

  Future<void> _verifyFoundCode() async {
    final row = _foundRow;
    if (row == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final ok =
        await Backend.verifyEmailOtp(_foundEmail, _codeCtrl.text.trim());
    if (!mounted) return;
    if (!ok) {
      setState(() {
        _busy = false;
        _error = tr('login_bad_code');
      });
      return;
    }
    await _adopt(row, _foundEmail);
  }

  // --- Gmail rasta ------------------------------------------------------------

  /// EmailOtpSection ki tasdeeq ke baad: bandha hua driver
  /// record dhoondh kar apnana। Record na mile to saaf
  /// paigham (registration ki taraf rehnumai ke saath)।
  Future<void> _afterGmailVerified(String email) async {
    setState(() {
      _busy = true;
      _error = null;
      _showRegister = false;
    });
    final row = await Backend.recoverDriverRowByEmail(email);
    if (!mounted) return;
    if (row == null) {
      setState(() {
        _busy = false;
        _error = tr('login_not_found_email');
        _showRegister = true;
      });
      return;
    }
    await _adopt(row, email);
  }

  // --- Apnana (adopt) -----------------------------------------------------------

  Future<void> _adopt(Map<String, dynamic> row, String email) async {
    await widget.store.adoptRecoveredDriver(row, email);
    // Pehchan bandhna (identity_links) — maujooda mechanism,
    // khamosh best-effort।
    unawaited(Backend.linkIdentities(widget.store));
    if (!mounted) return;
    setState(() => _busy = false);
    _snack(tr('login_success'));
    Navigator.of(context).pop(true);
  }

  // --- UI ---------------------------------------------------------------------

  Widget _modeButton(int mode, IconData icon, String label) {
    final selected = _mode == mode;
    return Expanded(
      child: SizedBox(
        height: 48,
        child: selected
            ? ElevatedButton.icon(
                onPressed: null,
                icon: Icon(icon, size: 19),
                label: Text(label,
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              )
            : OutlinedButton.icon(
                onPressed: _busy
                    ? null
                    : () => setState(() {
                          _mode = mode;
                          _error = null;
                          _showRegister = false;
                        }),
                icon: Icon(icon, size: 19),
                label: Text(label,
                    style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('login_heading'))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.login, size: 60, color: Brand.green),
          const SizedBox(height: 10),
          Text(
            tr('login_heading'),
            textAlign: TextAlign.center,
            style:
                const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 6),
          Text(
            tr('login_sub'),
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 13.5,
                height: 1.45,
                color: Theme.of(context).colorScheme.onSurfaceVariant),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              _modeButton(0, Icons.phone_android, tr('login_tab_mobile')),
              const SizedBox(width: 10),
              _modeButton(1, Icons.email, tr('login_tab_gmail')),
            ],
          ),
          const SizedBox(height: 18),
          if (_mode == 0) ..._mobileSection(),
          if (_mode == 1) ..._gmailSection(),
          if (_error != null) ...[
            const SizedBox(height: 14),
            Text(
              _error!,
              style: const TextStyle(
                  color: Colors.red,
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                  height: 1.45),
            ),
          ],
          if (_showRegister) ...[
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () => Navigator.of(context).pop(false),
              icon: const Icon(Icons.app_registration, size: 19),
              label: Text(tr('login_go_register')),
            ),
          ],
          if (_busy) ...[
            const SizedBox(height: 16),
            const Center(child: CircularProgressIndicator()),
          ],
        ],
      ),
    );
  }

  List<Widget> _mobileSection() {
    final found = _foundRow != null;
    return [
      TextField(
        controller: _mobileCtrl,
        keyboardType: TextInputType.phone,
        decoration: InputDecoration(
          labelText: tr('login_mobile_label'),
          hintText: tr('login_mobile_hint'),
          prefixIcon: const Icon(Icons.phone_android),
        ),
      ),
      const SizedBox(height: 12),
      SizedBox(
        width: double.infinity,
        height: 50,
        child: ElevatedButton.icon(
          onPressed: _busy ? null : _findByMobile,
          icon: const Icon(Icons.search, size: 19),
          label: Text(tr('login_find_btn'),
              style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      ),
      if (found) ...[
        const SizedBox(height: 16),
        Text(
          '${tr('login_otp_to')} ${_maskEmail(_foundEmail)}',
          style: const TextStyle(
              fontSize: 14, fontWeight: FontWeight.w700, height: 1.4),
        ),
        const SizedBox(height: 10),
        if (!_codeSent)
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton.icon(
              onPressed: _busy ? null : _sendCodeToFound,
              icon: const Icon(Icons.mark_email_read, size: 19),
              label: Text(tr('login_send_code'),
                  style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
          )
        else ...[
          TextField(
            controller: _codeCtrl,
            keyboardType: TextInputType.number,
            maxLength: 6,
            decoration: InputDecoration(
              labelText: tr('login_code_label'),
              prefixIcon: const Icon(Icons.pin),
              counterText: '',
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton.icon(
              onPressed: _busy ? null : _verifyFoundCode,
              icon: const Icon(Icons.login, size: 19),
              label: Text(tr('login_verify_btn'),
                  style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
          ),
        ],
      ],
    ];
  }

  List<Widget> _gmailSection() {
    return [
      // Wohi maujooda EmailOtpSection jo registration aur
      // login gates mein chalti hai — code bhejna/verify
      // karna usi ka kaam hai; verify kamyab ho to yahan
      // bandha hua driver record apnaya jata hai।
      EmailOtpSection(
        emailCtrl: _emailCtrl,
        onVerified: (email) => unawaited(_afterGmailVerified(email)),
      ),
    ];
  }
}
