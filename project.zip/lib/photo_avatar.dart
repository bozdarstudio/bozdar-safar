import 'package:flutter/material.dart';

import 'backend.dart';
import 'theme.dart';

/// Doosre fareeq / apni backend-wali profile photo ka avatar
/// (v1.4.27 — postmortem #20)।
///
/// Private buckets se photo sirf signed URL se ati hai
/// (Backend.fetchSignedPhotoUrl → Edge Function sign-doc-url)।
/// Amal: widget bante hi (aur path badalne par) URL mangwaya
/// jata hai; URL mile aur tasveer load ho jaye to wohi dikhti
/// hai — tab tak, ya URL/load na mile to, naam ke pehle harf
/// wala initials circle (jaali photo kabhi NAHI)।
class RemotePhotoAvatar extends StatefulWidget {
  final String bucket;
  final String path;
  final String name;
  final double radius;
  const RemotePhotoAvatar({
    super.key,
    required this.bucket,
    required this.path,
    required this.name,
    this.radius = 20,
  });

  @override
  State<RemotePhotoAvatar> createState() => _RemotePhotoAvatarState();
}

class _RemotePhotoAvatarState extends State<RemotePhotoAvatar> {
  String? _url;
  bool _imgFailed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(RemotePhotoAvatar old) {
    super.didUpdateWidget(old);
    if (old.bucket != widget.bucket || old.path != widget.path) {
      _url = null;
      _imgFailed = false;
      _load();
    }
  }

  Future<void> _load() async {
    final u = await Backend.fetchSignedPhotoUrl(widget.bucket, widget.path);
    if (!mounted) return;
    setState(() => _url = u);
  }

  String get _initial =>
      widget.name.trim().isEmpty ? '?' : widget.name.trim()[0].toUpperCase();

  @override
  Widget build(BuildContext context) {
    final d = widget.radius * 2;
    final url = _url;
    if (url != null && !_imgFailed) {
      return ClipOval(
        child: Image.network(
          url,
          width: d,
          height: d,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) {
            // Tasveer load na ho to initials — khaali ghera nahi।
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (mounted) setState(() => _imgFailed = true);
            });
            return _initials(d);
          },
        ),
      );
    }
    return _initials(d);
  }

  Widget _initials(double d) => CircleAvatar(
        radius: widget.radius,
        backgroundColor: Brand.green,
        child: Text(
          _initial,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            fontSize: d * 0.42,
          ),
        ),
      );
}
